#ifndef LCMET_FUNCTION_H__
#define LCMET_FUNCTION_H__

/**@file LcmetFunction.h

   @brief Functions related to meteorological calculations

   DOC Reference: [1] RTP project - "RTP Diseño Funcional.docx", chapter 4.2.2


   - std::string setWetness(const std::string &signficantWeatherPhenomenon);

   - bool setDeicing(const double &airTemperature, const std::string &Phenomenon

   - double beta(const double &lat1, const double &lon1,
                 const double &lat2, const double &lon2);

   - double tailWind(const double &windSpeed, 
                     const double &windDirection,
		     const double &beta);

   - double crossWind(const double &windSpeed, 
                      const double &windDirection,
		      const double &beta);

   - template <typename T>  const T flipWindDirection(const T &windDirection);

 */


#include <LcmetConstants.h>

#include <string>
#include <vector>


namespace lcmeteo
{
    
  //----------------------------------------------------------------------------
  /**@fn setWetness

     [1].4.2.2 - Humedad (Wetness)

     @return DRY/WET condition.
  */
  std::string setWetness(const std::string &signficantWeatherPhenomenon);

      
  //----------------------------------------------------------------------------
  /**@fn bool setDeicing
     @return true, if Phenomenon requires deicing activation; false otherwise.
  */
  bool setDeicing(const double &airTemperature, const std::string &Phenomenon);

  
  //----------------------------------------------------------------------------
  /**@fn bool setLVPActivation

     [1].4.2.2 - Procedimientos de baja visibilidad
  */
  bool setLVPActivation
    (const TYPE_CLOUD_BASE &cloud_base,
     const TYPE_CLOUD_BASE &LVP_ConditionCloudBase,
     const TYPE_HORIZONTAL_VISIVILITY &horizontal_visibility,
     const TYPE_HORIZONTAL_VISIVILITY &LVP_ConditionHorizontalVisibility,
     const std::vector<TYPE_RVR> &rvr_values,
     const TYPE_RVR &LVP_ConditionRVR);

  //----------------------------------------------------------------------------

  /**@fn beta

     @param lat1 = firstThresholdLatitude   (begin rw) ; units: [deg]
     @parma lon1 = firstThresholdLongitude             ; units: [deg]
     @parma lat2 = secondThresholdLatitude  (end rw)   ; units: [deg]
     @parma lon2 = secondThresholdLongitude            ; units: [deg]

     @return angle of a runway relative to the North; units: [rad]

     [1].4.2.2 - viento

   */
  double beta(const double &lat1, const double &lon1,
	      const double &lat2, const double &lon2);

  //----------------------------------------------------------------------------

  /**@fn tailWind

     @param windSpeed         [kt]
     @param windDirection (ø) [rad]
     @param beta;             [rad]

     @return longitudinal conponent of the windVector  [kt]
     
     Tailwind = W* cos (ø –ß); see [1].4.2.2 - viento.

   */
  TYPE_TAILWIND tailWind(const double &windSpeed,
		  const double &windDirection,
		  const double &beta);

  //----------------------------------------------------------------------------


  /**@fn crossWind

     @param windSpeed         [kt]
     @param windDirection (ø) [rad]
     @param beta;             [rad]

     @return traversal conponent of the windVector  [kt]

     Crosswind = |W* cos (ø –ß - 90º)|  ; see [1].4.2.2 - viento.

   */
  TYPE_CROSSWIND crossWind(const double &windSpeed,
		   const double &windDirection,
		   const double &beta);

  //----------------------------------------------------------------------------

  /* flipWindDirection

     @param wind_direction (α): wind geographic orientation. Angle relative
            to the geographic North, FROM which the wind blows; [deg]

     @return ø [deg]; Flips the wind direction by 180º to represent
             the angle value as a "TO direction".

	     where ø:
	     ø = α + 180º, si α < 180ºw
	     ø = α - 180º, si α > 180º
	     ø = 180º, si α = 180º

    Usage: create WindVector = (W, ø); (see WindVector at LcmTypes.h)

  */
  template <typename T> 
    inline const T flipWindDirection(const T &windDirection)
  {
    if(windDirection < 180)
    {
      return(windDirection + 180);
    }
    else if(windDirection > 180)
    {
      return(windDirection - 180);
    }
    else
    {
      return(0);
    }
  }

  //----------------------------------------------------------------------------
  
}//end-namespace

#endif

