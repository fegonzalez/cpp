#ifndef LPDDCONNCOMPONENT_H_
#define LPDDCONNCOMPONENT_H_

#include "LpiExecutionMode.h"
#include "LpdDConnBaseComponent.h"
#include "LpdDConnBusinessLogicFacade.h"
#include "LpiCreateDemandForecast.h"



class LpdDConnComponent : public LpdDConnBaseComponent
{
   public:

      static LpdDConnComponent& Get(void)
      {
         static LpdDConnComponent component;
         return component;
      }

      // Events consumed
      virtual void create();
      virtual void initialise();
      virtual void complete();
      virtual void notify();

      const LpiExecutionMode::LpiEnum & getExecutionMode() const;
      int getMinutesUpdatePeriod();

      virtual void sendInputDemandForecast();
      virtual void publishDemandForecast();

      virtual void updateFlightPlan (LpiFlightPlanEventType::LpiEnum operation,
                                     const LpiDemandFlightPlan & fp);

      virtual void updateFlightPlanBlock(const vector<LpiDemandFlightPlan> & fps);

      void resetDataBase(); //erases data received from AOP source

      bool isAsyncrhonusSending() const
      { return r_asynchronousSending; }

      // Services provided

   protected:

   private:

      LpdDConnComponent() {}
      LpdDConnComponent(const LpdDConnComponent&);
      LpdDConnComponent& operator=(const LpdDConnComponent&);

      LpdDConnBusinessLogicFacade r_businessLogic;

      LpiExecutionMode::LpiEnum r_executionMode;
      bool r_asynchronousSending;
      int r_hoursWindow;

      //To ensure one calculation on event reception at a time
      boost::mutex r_mutex;
};


#endif // LPDDCONNCOMPONENT_H_
