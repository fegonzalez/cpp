#ifndef LPDDCONNBASECOMPONENT_H_
#define LPDDCONNBASECOMPONENT_H_

#include <LpiDConnUsers.h>
#include <LpiDConnInterfaces.h>
#include <LpiDConnEvents.h>
#include <LpiDConnPublishers.h>
#include <LpiDConnConsumers.h>
#include <LpiDConnResult.h>
#include <LpiDemandConnectorConfiguration.h>
#include <LpiCreateDemandForecast.h>

#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/make_shared.hpp>


class LpdDConnBaseComponent : public LpiIDConnLifeCycle,
                              public LpiIGetAirportInfoSrvDelegateUser,
                              public LpiIGetAirportInfo,
                              public LpiIGetDemandConnectorConfigurationSrvDelegateUser,
                              public LpiIGetDemandConnectorConfiguration,
                              public LpiIGetInputDemandSrvDelegateUser,
                              public LpiIGetInputDemand,
                              public LpiIDConnUpdateDemandForecastEvtPublisher,
                              public LpiIPublishDemandForecast,
                              public LpiIUpdateFlightPlanEvtConsumer,
                              public LpiIDConnObserver
{
   public:

      LpdDConnBaseComponent();
      virtual ~LpdDConnBaseComponent();

      // Consumed events notification
      virtual void consume(const LpiDConnUpdateFlightPlanEvt & event);
      virtual void consume(const LpiDConnUpdateFlightPlanBlockEvt & event);

      // Required services notification

      // Delegate publisher subscription
      virtual void delegatePublisher(LpiIDConnUpdateDemandForecastEvtPublisher & publisher);

      // Delegate user subscription
      virtual void delegateUser(LpiIGetAirportInfoSrvUser & user);
      virtual void delegateUser(LpiIGetDemandConnectorConfigurationSrvUser & user);
      virtual void delegateUser(LpiIGetInputDemandSrvUser & user);


      // Events consumed
      virtual void updateFlightPlan (LpiFlightPlanEventType::LpiEnum operation,
                                     const LpiDemandFlightPlan & fp) = 0;

      virtual void updateFlightPlanBlock(const vector<LpiDemandFlightPlan> & fps) = 0;

      // Events published
      virtual void publish(const LpiDConnUpdateDemandForecastEvt & event);

      // Services provided

      // Services used

      virtual void getConfiguration(LpiDemandConnectorConfiguration & configuration,
    		  LpiDConnResult & result);
      virtual void getInputDemand(LpiCreateDemandForecastList & demand,
    		  LpiDConnResult        & result);
      virtual void getAirportInfo(std::string & airportName,
    		  LpiDConnResult &result);

   protected:
      // published events to delegate publisher

      // Required services to delegate user

      virtual void use(LpiGetDemandConnectorConfigurationReply & reply);

      virtual void use(LpiGetInputDemandReply & reply);

      virtual void use(LpiGetAirportInfoReply & reply);

   private:

      //Service users (delegated from component)
      boost::shared_ptr<LpiGetDemandConnectorConfigurationSrvDelegateUser>
      	  	  	  	  	  	  r_pGetDemandConnectorConfigurationSrvDelegateUser;
      boost::shared_ptr<LpiGetInputDemandSrvDelegateUser>
      	  	  	  	  	  	  r_pGetInputDemandSrvDelegateUser;
      boost::shared_ptr<LpiGetAirportInfoSrvDelegateUser>
      	  	  	  	  	  	  r_pGetAirportInfoSrvDelegateUser;

      //Event publishers (delegated from component)
      boost::shared_ptr<LpiIDConnUpdateDemandForecastEvtDelegatePublisher>
      	  	  	  	  	  	  r_pUpdateDemandForecastEvtDelegatePublisher;
};

#endif // LPDDCONNBASECOMPONENT_H_
