
#include "LpdDConnBaseComponent.h"
#include <LclogStream.h>

#include <iostream>

LpdDConnBaseComponent::LpdDConnBaseComponent() :
   r_pGetDemandConnectorConfigurationSrvDelegateUser(
		   boost::make_shared<LpiGetDemandConnectorConfigurationSrvDelegateUser>()),
   r_pGetInputDemandSrvDelegateUser(
		   boost::make_shared<LpiGetInputDemandSrvDelegateUser>()),
   r_pGetAirportInfoSrvDelegateUser(
		   boost::make_shared<LpiGetAirportInfoSrvDelegateUser>()),
   r_pUpdateDemandForecastEvtDelegatePublisher(
		   boost::make_shared<LpiUpdateDemandForecastEvtDelegatePublisher>())
{}

LpdDConnBaseComponent::~LpdDConnBaseComponent()
{}

// Get Configuration parameters service utilization
void LpdDConnBaseComponent::use(LpiGetDemandConnectorConfigurationReply & reply)
{
   this->r_pGetDemandConnectorConfigurationSrvDelegateUser->use(reply);
}

// Get Input demand file service utilization
void LpdDConnBaseComponent::use(LpiGetInputDemandReply & reply)
{
   this->r_pGetInputDemandSrvDelegateUser->use(reply);
}

//Get Airport name from adaptation
void LpdDConnBaseComponent::use(LpiGetAirportInfoReply & reply)
{
   this->r_pGetAirportInfoSrvDelegateUser->use(reply);
}

void LpdDConnBaseComponent::delegateUser(LpiIGetAirportInfoSrvUser &user)
{
   this->r_pGetAirportInfoSrvDelegateUser->delegateUser(user);
}

void LpdDConnBaseComponent::delegateUser(LpiIGetDemandConnectorConfigurationSrvUser &user)
{
   this->r_pGetDemandConnectorConfigurationSrvDelegateUser->delegateUser(user);
}

void LpdDConnBaseComponent::delegateUser(LpiIGetInputDemandSrvUser &user)
{
   this->r_pGetInputDemandSrvDelegateUser->delegateUser(user);
}

//Publish demand forecast update event
void LpdDConnBaseComponent::delegatePublisher(LpiIDConnUpdateDemandForecastEvtPublisher & publisher)
{
   this->r_pUpdateDemandForecastEvtDelegatePublisher->delegatePublisher(publisher);
}

void LpdDConnBaseComponent::consume(const LpiDConnUpdateFlightPlanEvt & event)
{
   updateFlightPlan(event.getEventType().getType(), event.getFlightPlan());
}

void LpdDConnBaseComponent::consume(const LpiDConnUpdateFlightPlanBlockEvt & event)
{
   updateFlightPlanBlock(event.getFlightPlanBlock());
}

void LpdDConnBaseComponent::publish(const LpiDConnUpdateDemandForecastEvt & event)
{
   this->r_pUpdateDemandForecastEvtDelegatePublisher->publish(event);
}

void LpdDConnBaseComponent::getConfiguration(
                           LpiDemandConnectorConfiguration & configuration,
						   LpiDConnResult                  & result)
{
   LpiGetDemandConnectorConfigurationReply     reply;

   use(reply);

   result.setResult(reply.getResult());
   configuration = reply.getConfiguration();
}

void LpdDConnBaseComponent::getInputDemand (LpiCreateDemandForecastList & demand,
		LpiDConnResult        & result)
{
   LpiGetInputDemandReply reply;

   use(reply);

   result.setResult(reply.getResult());
   demand = reply.getDemandForecastList();
}

void LpdDConnBaseComponent::getAirportInfo(
                            std::string & airportName,
							LpiDConnResult & result)
{
   LpiGetAirportInfoReply reply;

   use(reply);

   result.setResult(reply.getResult());
   airportName = reply.getAirportName();
}
