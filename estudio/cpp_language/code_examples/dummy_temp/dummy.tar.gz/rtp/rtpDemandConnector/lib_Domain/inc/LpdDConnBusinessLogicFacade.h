#ifndef LPDDCONNBUSINESSLOGICFACADE_H_
#define LPDDCONNBUSINESSLOGICFACADE_H_

#include <LpiDConnInterfaces.h>


class LpdDConnBusinessLogicFacade : public LpiIDConnLifeCycle,
                                    public LpiIGetDemandConnectorConfiguration,
                                    public LpiIFlightPlanLifeCycle,
                                    public LpiIGenerateDemandForecast
{
   public:

      LpdDConnBusinessLogicFacade();
      ~LpdDConnBusinessLogicFacade();


      virtual void getConfiguration(LpiDemandConnectorConfiguration & configuration,
    		  LpiDConnResult & result);

      virtual void create();
      virtual void initialise();
      virtual void complete();

      void createFP(const LpiDemandFlightPlan & fp);
      void updateFP(const LpiDemandFlightPlan & fp);
      void eraseFP (const LpiDemandFlightPlan & fp);

      void generateDemandForecast(LpiDemandForecast & forecast, int hoursWindow);
      void resetDataBase();

   protected:

   private:

};


#endif // LRDDCONNBUSINESSLOGICFACADE_H_
