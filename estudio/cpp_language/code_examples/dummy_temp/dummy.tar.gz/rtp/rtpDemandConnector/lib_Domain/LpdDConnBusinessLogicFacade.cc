#include <boost/foreach.hpp>

#include "LctimTimeUtils.h"
#include <LctimVirtualClock.h>
#include "LpdDConnBusinessLogicFacade.h"
#include "LpdDConnComponent.h"

#include <LpdbDemandConnectorDataBase.h>

#include <LclogStream.h>

#include <iostream>
#include <ctime>


LpdDConnBusinessLogicFacade::LpdDConnBusinessLogicFacade()
{
}


LpdDConnBusinessLogicFacade::~LpdDConnBusinessLogicFacade()
{
}

void LpdDConnBusinessLogicFacade::getConfiguration(LpiDemandConnectorConfiguration & configuration,
		LpiDConnResult & result)
{
   LpdDConnComponent::Get().getConfiguration(configuration,
                                             result);
}


void LpdDConnBusinessLogicFacade::create()
{
}


void LpdDConnBusinessLogicFacade::initialise()
{
}


void LpdDConnBusinessLogicFacade::complete()
{
}


void LpdDConnBusinessLogicFacade::createFP(const LpiDemandFlightPlan & fp)
{
  /* LpdbDemandConnectorDataBase::FPTable & fpTable= LpdbDemandConnectorDataBase::Get().getFPTable();

   string fpKey = fp.getUniqueKey();

   if (fpTable.exists(fpKey) == false)
   {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Added " << fpKey << " to DB" << std::endl;
#endif
      fpTable.addElement(fpKey, fp);
   }
   else
   {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Updated " << fpKey << " in DB" << std::endl;
#endif
      fpTable.updateElement(fpKey, fp);
   }*/
}


void LpdDConnBusinessLogicFacade::updateFP(const LpiDemandFlightPlan & fp)
{
  /* LpdbDemandConnectorDataBase::FPTable & fpTable= LpdbDemandConnectorDataBase::Get().getFPTable();

   string fpKey = fp.getUniqueKey();

   if (fpTable.exists(fpKey) == false)
   {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Added " << fpKey << " to DB" << std::endl;
#endif
      fpTable.addElement(fpKey, fp);
   }
   else
   {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Updated " << fpKey << " in DB" << std::endl;
#endif
      fpTable.updateElement(fpKey, fp);
   }*/
}


void LpdDConnBusinessLogicFacade::eraseFP (const LpiDemandFlightPlan & fp)
{
   /*LpdbDemandConnectorDataBase::FPTable & fpTable= LpdbDemandConnectorDataBase::Get().getFPTable();

   string fpKey = fp.getUniqueKey();

   if (fpTable.exists(fpKey))
   {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Deleted " << fpKey << " in DB" << std::endl;
#endif
      fpTable.deleteElement(fpKey);
   }
   else
   {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Trying to delete " << fpKey << " in DB (doesn't exist)" << std::endl;
#endif
   }*/
}


void LpdDConnBusinessLogicFacade::generateDemandForecast(LpiDemandForecast & forecast, int hoursWindow)
{
   //Set forecast time and date, with specific format

  /* boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();

   boost::posix_time::ptime epoch(date(1970, 1, 1));

   time_duration diff = now - epoch;
   unsigned long secondsSinceEpoch = diff.total_seconds();

   string forecastTimestamp = LctimTimeUtils::formatTime(now, "%H%M/%d%m%y");
   forecast.setForecastTimeAndDate(forecastTimestamp);

   unsigned long limitTime = secondsSinceEpoch + (hoursWindow * 60 * 60);


   LpdbDemandConnectorDataBase::FPTable & fpTable= LpdbDemandConnectorDataBase::Get().getFPTable();
   vector<string> fpKeys = fpTable.getAllIds();

   BOOST_FOREACH(string & key, fpKeys)
   {
      if (fpTable.exists(key))
      {
         LpiDConnFlightPlan fp = fpTable[key];

         if (hoursWindow > 0)
         {
            if(fp.isInWindow(secondsSinceEpoch, limitTime))
            {
               forecast.addFPToForecast(fp);
#ifdef TRACE_OUT
               LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Added " << key << " to demand forecast" << std::endl;
#endif
            }
            else
            {
#ifdef TRACE_OUT
               LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << fp.getUniqueKey() << "is not in window...not added to forecast" << std::endl;
#endif
            }
         }
         else
         {
            forecast.addFPToForecast(fp);
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Added " << key << " to demand forecast" << std::endl;
#endif
         }
      }
   }*/
}


void LpdDConnBusinessLogicFacade::resetDataBase()
{
   LpdbDemandConnectorDataBase::FPTable & fpTable= LpdbDemandConnectorDataBase::Get().getFPTable();

   fpTable.clear();
}
