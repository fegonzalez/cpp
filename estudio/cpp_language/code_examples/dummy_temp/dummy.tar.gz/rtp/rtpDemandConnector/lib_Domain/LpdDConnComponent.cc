#include <LclogStream.h>
#include "LpdDConnComponent.h"

//Events consumed
void LpdDConnComponent::create()
{
    r_businessLogic.create();
}

void LpdDConnComponent::initialise()
{
    r_businessLogic.initialise();

    LpiDemandConnectorConfiguration configuration;
    LpiDConnResult res;

    getConfiguration(configuration, res);

    r_executionMode = configuration.getExecutionMode();
    r_hoursWindow = configuration.getForecastHoursWindow();

    if (configuration.getMinutesUpdatePeriod() == 0)
    {
        r_asynchronousSending = true;
    }
}

void LpdDConnComponent::complete()
{
    r_businessLogic.complete();
}

void LpdDConnComponent::notify()
{
    r_mutex.lock();

    publishDemandForecast();

    r_mutex.unlock();
}

const LpiExecutionMode::LpiEnum & LpdDConnComponent::getExecutionMode() const
{
    return r_executionMode;
}

int LpdDConnComponent::getMinutesUpdatePeriod()
{
    LpiDemandConnectorConfiguration configuration;
    LpiDConnResult res;

    getConfiguration(configuration, res);

    return configuration.getMinutesUpdatePeriod();
}

void LpdDConnComponent::sendInputDemandForecast()
{
    LpiCreateDemandForecastList forecastList;
    LpiDConnResult res;

    getInputDemand(forecastList, res);

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "Demand read from file:" << std::endl;
    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << forecastList << std::endl;
#endif

    LpiDConnUpdateDemandForecastEvt demandEvent;

    demandEvent.setDemandForecastList(forecastList);

    LpdDConnComponent::Get().publish(demandEvent);
}

// Ensure mutual exclusion between read (publishDemandForecast) and write (updateFlightPlan) FP's operations
// via r_mutex
void LpdDConnComponent::publishDemandForecast()
{
    LpiCreateDemandForecastList forecastList;
    LpiCreateDemandForecast forecast;

    //r_businessLogic.generateDemandForecast(forecast, r_hoursWindow);
    forecastList.push_back(forecast);
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "Demand to publish, size = " << forecast.sizeFP() << ":" << std::endl;
    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << forecast << std::endl;

    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "Forecast published at: " << forecast.getDemandStartTimeAndDate() << std::endl;
#endif

    LpiDConnUpdateDemandForecastEvt demandEvent;

    demandEvent.setDemandForecastList(forecastList);
    LpdDConnComponent::Get().publish(demandEvent);
}

void LpdDConnComponent::updateFlightPlan(LpiFlightPlanEventType::LpiEnum operation, const LpiDemandFlightPlan & fp)
{
    r_mutex.lock();

    switch(operation)
    {
        case LpiFlightPlanEventType::E_CREATE:
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Received FP Create Event type" << std::endl;
#endif
            r_businessLogic.createFP(fp);
            break;
        case LpiFlightPlanEventType::E_UPDATE:
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Received FP Update Event type" << std::endl;
#endif
            r_businessLogic.updateFP(fp);
            break;
        case LpiFlightPlanEventType::E_DELETE:
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Received FP Delete Event type" << std::endl;
#endif
            r_businessLogic.eraseFP(fp);
            break;
        case LpiFlightPlanEventType::E_UNKNOWN:
        default:
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "Received Unknown Event type" << std::endl;
#endif
            break;
    }

    r_mutex.unlock();
}

void LpdDConnComponent::updateFlightPlanBlock(const vector<LpiDemandFlightPlan> & fps)
{
    r_mutex.lock();

    if (fps.size() > 0)
    {
        resetDataBase();

#ifdef TRACE_OUT
        LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "Erased FPs from database due to new demand forecast" << std::endl;
#endif
    }

    for (unsigned int i = 0; i < fps.size(); ++i)
    {
        r_businessLogic.updateFP(fps[i]);

#ifdef TRACE_OUT
        LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "FP processed:\n" << fps[i] << std::endl;
#endif
    }

    if (r_asynchronousSending)
    {
        publishDemandForecast();
    }

    r_mutex.unlock();
}

void LpdDConnComponent::resetDataBase()
{
    r_businessLogic.resetDataBase();
}
