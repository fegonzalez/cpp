/*
 * LpaAirportInfo.cc
 *
 */

#include "LpaAirportInfo.h"
#include <string>
#include <boost/algorithm/string/trim.hpp>


void LpaAirportInfo::ConvertXml2AirportInfo(const SM_AIRPORT_INFO::AirportElement  & airportInfoElement,
                                            std::string  & airportName)
{
   //NOTE: We only need airport name from adaptation
   std::string name = airportInfoElement().name();

   boost::algorithm::trim(name);
   airportName = name;
}
