/*
 * LpaGetAirportInfoServiceUser.h
 *
 */

#ifndef LRAGETAIRPORTINFOSERVICEUSER_H_
#define LRAGETAIRPORTINFOSERVICEUSER_H_

#include <LpiIDConnServiceUsers.h>
#include <daortp_dao_sm_airport_info_xsd.h>
#include <LpaAirportInfo.h>

class LpaGetAirportInfoServiceUser : public LpiIGetAirportInfoSrvUser
{
   public:

      LpaGetAirportInfoServiceUser() {}

      void init(const std::string &name)
      {
         this->r_airportInfo.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() <<"Initialized File: "<<name<<std::endl;
#endif

         LpdDConnComponent::Get().delegateUser(*this);
      }

      virtual void use(LpiGetAirportInfoReply &reply)
      {
         std::string airportName;

         LpaAirportInfo::ConvertXml2AirportInfo(r_airportInfo, airportName);

         reply.setAirportName(airportName);
         reply.setResult(LpiDConnResult::E_OK);
      }

   private:

      SM_AIRPORT_INFO::AirportElement r_airportInfo;
};


#endif /* LRAGETAIRPORTINFOSERVICEUSER_H_ */
