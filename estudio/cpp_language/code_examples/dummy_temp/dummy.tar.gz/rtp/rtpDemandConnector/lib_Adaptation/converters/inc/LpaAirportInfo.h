/*
 * LpaAirportInfo.h
 *
 */

#ifndef LRAAIRPORTINFO_H_
#define LRAAIRPORTINFO_H_

#include <daortp_dao_sm_airport_info_xsd.h>

class LpaAirportInfo
{
   public:

       static void ConvertXml2AirportInfo(const SM_AIRPORT_INFO::AirportElement  & airportInfoElement,
                                          std::string  & airportName);

};


#endif /* LRAAIRPORTINFO_H_ */
