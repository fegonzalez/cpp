/*
 * LpaDConnAdaptationManager.h
 *
 */

#ifndef LRADCONNADAPTATIONMANAGER_H_
#define LRADCONNADAPTATIONMANAGER_H_

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/property_tree/exceptions.hpp>

#include <LpaGetAirportInfoServiceUser.h>


class LpaDConnAdaptationManager
{
   public:

      static LpaDConnAdaptationManager & Get(void)
      {
         static LpaDConnAdaptationManager manager;
         return manager;
      }

      /**@warning No se está llamando a esta función nunca. En el
	 main.cc del demand connector está comentada la línea que llama.
       */
      void initialise(void)
      {
	///@warnig No adaptation in RTP
         /* try */
         /* { */
	 /*   // Este fichero no existe en RTP ... */
	 /*   //            r_getAirportInfoServiceUser->init("DAORTP_adap/DAORTP_dao_sm_airport_info.xml"); */

	 /*   // ... podría ser este ? */
	 /*   r_getAirportInfoServiceUser->init */
	 /*     (std::string(rtp_constants::CFGDIR_ADAP + "/" +  */
	 /* 		  rtp_constants::FILENAME_DAORTP_AIRPORTS_INFO)); */
         /* } */
         /* catch(std::exception & ex) */
         /* { */
         /*    std::cerr << "[ERROR]: Please, check the adaptation file " */
	 /* 	      << rtp_constants::FILENAME_DAORTP_AIRPORTS_INFO  */
	 /* 	      << std::endl; */

         /*    std::cerr << "[ERROR]: " << ex.what() << std::endl; */
         /*    exit(EXIT_FAILURE); */
         /* } */
        
      }

   private:

      LpaDConnAdaptationManager():
      r_getAirportInfoServiceUser(new LpaGetAirportInfoServiceUser())
      {}

      boost::shared_ptr<LpaGetAirportInfoServiceUser> r_getAirportInfoServiceUser;
};


#endif /* LRADISTADAPTATIONMANAGER_H_ */
