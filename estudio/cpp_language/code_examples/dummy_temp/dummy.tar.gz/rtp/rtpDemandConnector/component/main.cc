#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <iostream>

#include <LplcTypeConstants.h>
#include <LpiDConnResult.h>
#include <LpdDConnComponent.h>
#include <LpiDConnUsers.h>
#include <LclogStream.h>
#include <LpcDConnCommunicationsManager.h>
#include <LpcfgDConnConfigurationManager.h>
//#include <LpaDConnAdaptationManager.h>
#include <LpnDConnInputManager.h>
#include <LctimTimeUtils.h>
#include <LctimVirtualClock.h>
#include <LctimNotificationTimer.h>
#include <LclogStream.h>

int main(int argc, char * argv[])
{
    std::string processName(argv[0]);

    for (int ii = 1; ii < argc; ii++)
    {
        processName = processName + " " + argv[ii];
    }

    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << "DEMMAND CONNECTOR" << std::endl;

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << processName << " initialized" << std::endl;
#endif

    LpdDConnComponent::Get().create();

    LpcfgDConnConfigurationManager::Get().initialise();

    ///@warnig No adaptation in RTP
    //LpaDConnAdaptationManager::Get().initialise();

    LpdDConnComponent::Get().initialise();

    LpdDConnComponent::Get().complete();

    LpiExecutionMode::LpiEnum mode = LpdDConnComponent::Get().getExecutionMode();

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() 
      << "EXECUTION MODE:" << mode << std::endl;
#endif

    if (mode == LpiExecutionMode::E_DUMMY)
    {
        if (argc == 2)
        {
            LpndDConnInputManager::Get().initialise(argv[1]);

            LpcDConnCommunicationsManager::Get().initialise();

            LpdDConnComponent::Get().sendInputDemandForecast();
        }
        else
        {
            std::cerr << "Usage: " << argv[0] 
		      << " <example_demand_input_file.xml> or <./directoy/>" 
		      << std::endl;
            exit(EXIT_FAILURE);
        }
    }
    else if (mode == LpiExecutionMode::E_CONNECTOR)
    {
        //Virtual clock management
        LctimVirtualClock::ExecutionMode mode = LctimVirtualClock::E_REAL;

        boost::posix_time::ptime startTime;

        if (argc > 1)
        {
            std::string simulationDate(argv[1]);

            startTime = LctimTimeUtils::getFromString(simulationDate);

            if (startTime.is_not_a_date_time())
            {
                std::cerr << "Error: " << argv[1] << " is not a valid date/time format. Usage: " << argv[0]
                          << " dd/mm/YYYY HH:MM" << std::endl;
                exit(EXIT_FAILURE);
            }

            mode = LctimVirtualClock::E_SIMULATED;
        }
        else
        {
            startTime = boost::posix_time::second_clock::local_time();
        }

        boost::posix_time::ptime realStartTime = second_clock::local_time();

        LctimVirtualClock::Get().setParameters(mode, realStartTime, startTime);

        //Create timer if sending configured synchronous: minutesUpdatePeriod > 0

        if (LpdDConnComponent::Get().isAsyncrhonusSending())
        {
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "Asynchronous sending configured, periodic timer not started." << std::endl;
#endif

            //Wait for iMASBlue events
            LpcDConnCommunicationsManager::Get().waitForEvents();
        }
        else
        {
#ifdef TRACE_OUT
            LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() << "Synchronous sending configured, periodic timer started." << std::endl;
#endif

            //Create timer object
            //int publishPeriod = LpdDConnComponent::Get().getMinutesUpdatePeriod();

            //Asio Timer creation
            boost::asio::io_service io;

            // LctimNotificationTimer periodicTimer(io, LpdDConnComponent::Get(), publishPeriod*60, publishPeriod*60);
            //periodicTimer.start();

            //Wait for iMASBlue event reception
            LpcDConnCommunicationsManager::Get().waitForEvents();

            //periodicTimer.stop();
        }

    }
    else
    {
      std::cerr << "Unknown execution mode, please check the config. file "
		<< rtp_constants::FILENAME_DCONN_PARAMETERS
		<< std::endl;
      LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).error()
	<< "Unknown execution mode, please check the config. file "
	<< rtp_constants::FILENAME_DCONN_PARAMETERS
	<< std::endl;
    }

    return 0;
}
