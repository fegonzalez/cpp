/*
 * LpcfgDemandConnectorConfiguration.h
 *
 */

#ifndef LRFDEMANDCONNECTORCONFIGURATION_H_
#define LRFDEMANDCONNECTORCONFIGURATION_H_

#include <LpiDemandConnectorConfiguration.h>
#include "daortp_demandconnectorparameters_xsd.h"

class LpcfgDemandConnectorConfiguration
{
   public:

      static void Convert2Configuration(const DemandConnectorParameters::ParametersElement & parameters,
                                        LpiDemandConnectorConfiguration & output);
};




#endif /* LRFDEMANDCONNECTORCONFIGURATION_H_ */
