/*
 * LpcfgDemandConnectorConfiguration.cc
 *
 */

#include "LpiExecutionMode.h"
#include "LpcfgDemandConnectorConfiguration.h"


void LpcfgDemandConnectorConfiguration::Convert2Configuration(const DemandConnectorParameters::ParametersElement & parameters,
                                                            LpiDemandConnectorConfiguration & output)
{
	//DemandConnectorParameters::ExecutionMode mode = parameters().mode();


//-----------------------------****
    output.setExecutionMode(LpiExecutionMode::E_DUMMY);
   /*switch (mode)
   {
      case DemandConnectorParameters::ExecutionMode::DUMMY:
         output.setExecutionMode(LpiExecutionMode::E_DUMMY);
      break;

      case DemandConnectorParameters::ExecutionMode::CONNECTOR:
         output.setExecutionMode(LpiExecutionMode::E_CONNECTOR);
      break;

      default:
         output.setExecutionMode(LpiExecutionMode::E_UNKNOWN);
      break;
   }*/

   output.setMinutesUpdatePeriod(parameters().minutesUpdatePeriod());
   output.setForecastHoursWindow(parameters().forecastHoursWindow());

}

