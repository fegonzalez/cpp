/*
 * LpcfgGetDemandConnectorConfigurationServiceUser.h
 *
 */

#ifndef LRFGETDEMANDCONNECTORCONFIGURATIONSERVICEUSER_H_
#define LRFGETDEMANDCONNECTORCONFIGURATIONSERVICEUSER_H_

#include <LpiIDConnServiceUsers.h>
#include <LpcfgDemandConnectorConfiguration.h>

class LpcfgGetDemandConnectorConfigurationServiceUser : public LpiIGetDemandConnectorConfigurationSrvUser
{
   public:

      LpcfgGetDemandConnectorConfigurationServiceUser() {}

      void init(const std::string &name)
      {
         this->r_parameters.open(name);
         LpdDConnComponent::Get().delegateUser(*this);

#ifdef TRACE_OUT
         LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() <<"Initialized File: "<<name<<std::endl;
#endif
      }

      virtual void use(LpiGetDemandConnectorConfigurationReply &reply)
      {
         LpiDemandConnectorConfiguration connectorParameters;
         LpcfgDemandConnectorConfiguration::Convert2Configuration(this->r_parameters, connectorParameters);

         reply.setConfiguration(connectorParameters);
         reply.setResult(LpiDConnResult::E_OK);
      }

   private:

      DemandConnectorParameters::ParametersElement r_parameters;
};


#endif /* LRFGETDEMANDCONNECTORCONFIGURATIONSERVICEUSER_H_ */
