/*
 * LpcfgDConnConfigurationManager.h
 *
 */

#ifndef LRFDCONNCONFIGURATIONMANAGER_H_
#define LRFDCONNCONFIGURATIONMANAGER_H_

#include <LpcfgGetDemandConnectorConfigurationServiceUser.h>
#include <LplcTypeConstants.h>

#include <boost/shared_ptr.hpp>

class LpcfgDConnConfigurationManager
{
   public:

      static LpcfgDConnConfigurationManager & Get(void)
      {
         static LpcfgDConnConfigurationManager manager;
         return manager;
      }

      void initialise(void)
      {
         try
         {
	   _getDemandConnectorConfigurationServiceUser->init
	     (std::string(rtp_constants::CFGDIR_DCONN + "/" + 
			  rtp_constants::FILENAME_DCONN_PARAMETERS));
         }
         catch(std::exception& ex)
         {
            std::cerr << "[ERROR]: Please, check the configuration file "
		      << rtp_constants::FILENAME_DCONN_PARAMETERS
		      << std::endl;
            std::cerr << "[ERROR]: " << ex.what() << std::endl;
            exit(EXIT_FAILURE);
         }
      }

   private:

      LpcfgDConnConfigurationManager ():
         _getDemandConnectorConfigurationServiceUser(new LpcfgGetDemandConnectorConfigurationServiceUser())
      {}

      boost::shared_ptr<LpcfgGetDemandConnectorConfigurationServiceUser>
                                                 _getDemandConnectorConfigurationServiceUser;
};



#endif /* LRFCONFIGURATIONMANAGER_H_ */

