#include "LpdbDemandConnectorDataBase.h"


std::ostream& operator<<(std::ostream &os, const LpdbDemandConnectorDataBase & db)
{
   os << db.getFPTable();
   os.flush();

   return os;
}
