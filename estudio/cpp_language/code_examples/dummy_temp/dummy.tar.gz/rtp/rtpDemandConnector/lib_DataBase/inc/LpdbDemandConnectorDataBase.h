#ifndef LRBDEMANDCONNECTORDATABASE_H_
#define LRBDEMANDCONNECTORDATABASE_H_

#include <iostream>
#include <map>
#include <set>
#include <string>

#include "LpiDConnFlightPlan.h"
#include "LpdbDConnDataTable.h"

using std::string;

class LpdbDemandConnectorDataBase
{
   public:

      typedef LpdbDConnDataTable<string, LpiDConnFlightPlan> FPTable;

      static LpdbDemandConnectorDataBase& Get(void)
      {
         static LpdbDemandConnectorDataBase database;
         return database;
      }

      FPTable & getFPTable()
      { return r_fpsTable; }

      const FPTable & getFPTable() const
      { return r_fpsTable; }

   private:

      LpdbDemandConnectorDataBase() {}
      LpdbDemandConnectorDataBase(const LpdbDemandConnectorDataBase &);
      LpdbDemandConnectorDataBase & operator=(const LpdbDemandConnectorDataBase &);

      FPTable r_fpsTable;
};

std::ostream& operator<<(std::ostream &os, const LpdbDemandConnectorDataBase & db);

#endif // LRBDEMANDCONNECTORDATABASE_H_
