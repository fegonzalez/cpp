/*
 * LpcUpdateFlightPlanEvtConsumer.h
 *
 *  Created on: 27/04/2015
 */

#ifndef __LRC_UPDATE_FLIGHT_PLAN_EVT_CONSUMER_H__
#define __LRC_UPDATE_FLIGHT_PLAN_EVT_CONSUMER_H__

#include <IOFplEventsiBContract.h>
#include <LclogStream.h>


class LpcUpdateFlightPlanEvtConsumer : public iBG::IOFplEvents::FlightPlanEventSSubscriberListener
{
   public:

      void init();
      void on_data_available(iBG::IOFplEvents::FlightPlanEventSSubscriber & sub);
};


#endif /* __LRC_UPDATE_FLIGHT_PLAN_EVT_CONSUMER_H__ */
