/*
 * LpcDConnCommunicationsManager.h
 *
 */

#ifndef LPCDCONNCOMMUNICATIONSMANAGER_H_
#define LPCDCONNCOMMUNICATIONSMANAGER_H_


#include <LpcUpdateFlightPlanEvtConsumer.h>
#include <LpcUpdateDemandForecastEvtPublisher.h>

#include <boost/thread.hpp>

class LpcDConnCommunicationsManager
{
   public:

      static LpcDConnCommunicationsManager & Get();
      void initialise();
      void waitForEvents (void);

   private:

      LpcDConnCommunicationsManager();

      boost::shared_ptr<LpcUpdateFlightPlanEvtConsumer> r_updateFlightPlanEvtConsumer;
      boost::shared_ptr<LpcUpdateDemandForecastEvtPublisher> r_updateDemandForecastEvtPublisher;
};

#endif /* LPCDCONNCOMMUNICATIONSMANAGER_H_ */
