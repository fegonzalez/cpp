/*
 *  LpcUpdateDemandForecastEvtPublisher.cc
 *
 *  Created on: 27/04/2015
 *
 *  Author:
 */

#include <LcuStringArrayConvUtils.h>

#include <LpdDConnComponent.h>
#include <LclogStream.h>

#include <IODemandEvents.h>
#include <IODemand.h>
#include <LpcDemandForecast.h>
#include <LpcUpdateDemandForecastEvtPublisher.h>


void LpcUpdateDemandForecastEvtPublisher::init()
{
   iB::PublisherId pid("IODemandEvents::CreateDemandEventList");
   iB::PublicationProfile pprofile;

   r_publisher = &iBG::IODemandEvents::CreateDemandEventListCreatePublisher(pid, pprofile);

   LpdDConnComponent::Get().delegatePublisher(*this);
}


void LpcUpdateDemandForecastEvtPublisher::publish(const LpiDConnUpdateDemandForecastEvt & evt)
{
   ::IODemandEvents::CreateDemandEventList data;

   //::IODemandEvents::CreateDemandEventTypeSupport::initialize_data(&data);

   data.flightPlans.ensure_length(evt.getDemandForecastList().size(), evt.getDemandForecastList().size());

   std::vector<LpiCreateDemandForecast> list = evt.getDemandForecastList();
   for (unsigned int i = 0; i < list.size(); i++){
	   IODemandRTP::Demand demand;
	   LpcDemandForecast::Convert2IODemandForecast(list[i], demand);
	   data.flightPlans.set_at(i, demand);
   }


   //data.flightPlan = demand;

   r_publisher->push(data);

   ::IODemandEvents::CreateDemandEventListTypeSupport::finalize_data(&data);

   LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).info() << evt.getDemandForecastList() << std::endl;


   LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).notify() << "[PUBLISHED DEMAND FORECAST]" << std::endl;
}

