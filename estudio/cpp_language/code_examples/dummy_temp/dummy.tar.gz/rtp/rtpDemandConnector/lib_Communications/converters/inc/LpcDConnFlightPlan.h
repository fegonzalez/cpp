/*
 * LpcDConnFlightPlan.h
 *
 *  Created on: 05/05/2015
 *      Author: mbegega
 */

#ifndef LRCDCONNFLIGHTPLAN_H_
#define LRCDCONNFLIGHTPLAN_H_

#include <boost/optional.hpp>

#include <IOFpl.h>
#include "LpiDemandFlightPlan.h"


class LpcDConnFlightPlan
{
   public:

      static void ConvertIO2FlightPlan(const IOFpl::FlightPlanS & in, LpiDemandFlightPlan & out);

   private:

      static void ConvertDepartureInfoIO2FlightPlan(const IOFpl::DepartureInformationS & in, LpiDemandFlightPlan & out);
      static void ConvertArrivalInfoIO2FlightPlan(const IOFpl::ArrivalInformationS & in, LpiDemandFlightPlan & out);

      static void ConvertOptionalTimeIO2Epoch(const IOTim::OptionalTimeU & optionalTime,
                                              boost::optional<unsigned long> & epochTime);
};


#endif /* LRCDCONNFLIGHTPLAN_H_ */
