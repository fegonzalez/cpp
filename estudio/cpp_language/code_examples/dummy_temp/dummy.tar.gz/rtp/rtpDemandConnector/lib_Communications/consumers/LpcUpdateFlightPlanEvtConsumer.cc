/*
 * LpcUpdateFlightPlanEvtConsumer.h
 *
 *  Created on: 27/04/2015
 */

#include "LpcUpdateFlightPlanEvtConsumer.h"

#include <LpiDConnUpdateFlightPlanEvt.h>
#include "LpcFlightPlanEvent.h"
#include <LpdDConnComponent.h>
#include <IOFpl.h>
#include <IOFplEvents.h>

#include <LclogStream.h>

void LpcUpdateFlightPlanEvtConsumer::init()
{
   iB::SubscriberId sid("IOFplEvents::FlightPlanEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOFplEvents::FlightPlanEventSSubscriber &subscriber =
             iBG::IOFplEvents::FlightPlanEventSCreateSubscriber(sid, sprofile);

   subscriber.addListener(this);
}


void LpcUpdateFlightPlanEvtConsumer::on_data_available(
                        iBG::IOFplEvents::FlightPlanEventSSubscriber & sub)
{
   iBG::IOFplEvents::FlightPlanEventSSubscriber::DataList dl;

   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOFplEvents::FlightPlanEventSSubscriber::DataList::iterator dit
                                                               = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {
      if(iit->isValid())
      {
         //Obtain data
         IOFplEvents::FlightPlanEventS flightPlanEventIO;
         memset(&flightPlanEventIO, 0, sizeof(IOFplEvents::FlightPlanEventS));
         flightPlanEventIO = *dit;

         //Internal type conversion
         LpiDConnUpdateFlightPlanEvt event;

         LpcFlightPlanEvent::ConvertIO2FPEvent(flightPlanEventIO, event);

         //Event
         LpdDConnComponent::Get().consume(event);
      }
   }
}

