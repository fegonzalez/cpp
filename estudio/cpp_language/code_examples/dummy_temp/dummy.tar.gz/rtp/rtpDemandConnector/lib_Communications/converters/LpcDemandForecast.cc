

#include <IOConstant.h>

#include "LpcDemandForecast.h"
#include <LcuStringArrayConvUtils.h>


void LpcDemandForecast::Convert2IODemandForecast(const LpiCreateDemandForecast & in, IODemandRTP::Demand & out)
{

	LcuStringArrayConvUtils::String2Array<IOConst::AEROD_SIZE>(in.getNameAirport(), out.airport);

	LcuStringArrayConvUtils::String2Array<IOConst::DATE_SIZE>(in.getDemandStartTimeAndDate(), out.demandStartTimeAndDate);
	LcuStringArrayConvUtils::String2Array<IOConst::DATE_SIZE>(in.getDemandEndTimeAndDate(), out.demandEndTimeAndDate);

   out.fligthPlanList.ensure_length(in.sizeFP(), in.sizeFP());

   for (unsigned int i = 0; i < in.sizeFP(); i++)
   {
      const LpiDemandFlightPlan & fp = in[i];

      IODemandRTP::FlightPlanS flightPlanIO;

      LpcDemandForecast::Convert2IODepartureTimes(fp.getDepartureTimes(), flightPlanIO.depInfo);

      LpcDemandForecast::Convert2IOArrivalTimes(fp.getArrivalTimes(), flightPlanIO.arrInfo);

      LcuStringArrayConvUtils::String2Array<IOConst::CALLSIGN_SIZE>(fp.getCallsign(), flightPlanIO.fpKey.callsign);

      LcuStringArrayConvUtils::String2Array<IOConst::AEROD_SIZE>(fp.getDepartureAerodrome(), flightPlanIO.fpKey.depAerodrome);

      LcuStringArrayConvUtils::String2Array<IOConst::AEROD_SIZE>(fp.getArrivalAerodrome(), flightPlanIO.fpKey.arrAerodrome);

      LcuStringArrayConvUtils::String2Array<IOConst::ACTYPE_SIZE>(fp.getAircraftType(), flightPlanIO.acType);

      LcuStringArrayConvUtils::String2Array<12>(fp.getRegistration(), flightPlanIO.registration);

      LcuStringArrayConvUtils::String2Array<IOConst::WTC_SIZE>(fp.getWtc(), flightPlanIO.wtc);

      LcuStringArrayConvUtils::String2Array<IOConst::PROCED_SIZE>(fp.getSID(), flightPlanIO.sid);

      LcuStringArrayConvUtils::String2Array<IOConst::PROCED_SIZE>(fp.getSTAR(), flightPlanIO.star);

      LcuStringArrayConvUtils::String2Array<IOConst::VFR_SIZE>(fp.getVFR(), flightPlanIO.vfr);

      out.fligthPlanList.set_at(i, flightPlanIO);
   }

}


void LpcDemandForecast::Convert2IODepartureTimes(const LpiDepartureTimes & in, IODemandRTP::DepartureInfo & out)
{
   //eobt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getEobt(), out.eobt);

   //sobt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getSobt(), out.sobt);

   //tobt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getTobt(), out.tobt);

   //etot
   LpcDemandForecast::Convert2OptionalTimeIO(in.getEtot(), out.etot);

   //ttot
   LpcDemandForecast::Convert2OptionalTimeIO(in.getTtot(), out.ttot);

   //stot
   LpcDemandForecast::Convert2OptionalTimeIO(in.getStot(), out.stot);

   //atot
   LpcDemandForecast::Convert2OptionalTimeIO(in.getAtot(), out.atot);

   //ctot
   LpcDemandForecast::Convert2OptionalTimeIO(in.getCtot(), out.ctot);

   //utot
   LpcDemandForecast::Convert2OptionalTimeIO(in.getUtot(), out.utot);
}


void LpcDemandForecast::Convert2IOArrivalTimes(const LpiArrivalTimes & in, IODemandRTP::ArrivalInfo & out)
{
   //eldt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getEldt(), out.eldt);

   //tldt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getTldt(), out.tldt);

   //aldt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getAldt(), out.aldt);

   //sldt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getSldt(), out.sldt);

   //sibt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getSibt(), out.sibt);

   //uldt
   LpcDemandForecast::Convert2OptionalTimeIO(in.getUldt(), out.uldt);
}


void LpcDemandForecast::Convert2OptionalTimeIO(const boost::optional<unsigned long> & in,
                                               IOTim::OptionalTimeU & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
      out._u.value = 0;
   }
}


