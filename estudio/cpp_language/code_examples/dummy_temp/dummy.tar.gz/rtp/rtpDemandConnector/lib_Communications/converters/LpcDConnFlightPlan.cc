/*
 * LpcDConnFlightPlan.cc
 *
 *  Created on: 05/05/2015
 *      Author: mbegega
 */

#include <string>
#include <boost/algorithm/string/trim.hpp>

#include "LpcDConnFlightPlan.h"


void LpcDConnFlightPlan::ConvertDepartureInfoIO2FlightPlan(const IOFpl::DepartureInformationS & in, LpiDemandFlightPlan & out)
{
   LpiDemandDepartureTimes departureTimes;

   boost::optional<unsigned long> eobt;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.eobt, eobt);
   if (eobt)
   {
      departureTimes.setEobt(*eobt);
   }

   boost::optional<unsigned long> aobt;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.aobt, aobt);
   if (aobt)
   {
      departureTimes.setAobt(*aobt);
   }

   boost::optional<unsigned long> tobt;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.tobt, tobt);
   if (tobt)
   {
      departureTimes.setTobt(*tobt);
   }

   boost::optional<unsigned long> ctot;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.ctot, ctot);
   if (ctot)
   {
      departureTimes.setCtot(*ctot);
   }

   boost::optional<unsigned long> etot;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.etot, etot);
   if (etot)
   {
      departureTimes.setEtot(*etot);
   }

   boost::optional<unsigned long> atot;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.atot, atot);
   if (atot)
   {
      departureTimes.setAtot(*atot);
   }

   out.setDepartureTimes(departureTimes);

   // Departure aerodrome
   string departureAerodromeName(in.adep, IOAsm::AIRPORT_ST_SIZE);
   boost::algorithm::trim(departureAerodromeName);
   out.setDepartureAerodrome(departureAerodromeName);

   //SID
   string sidProcedure;
   if (in.sid._d)
   {
      sidProcedure = string(in.sid._u.sidName, IOAsm::SID_SIZE);
      boost::algorithm::trim(sidProcedure);
   }
   out.setSID(sidProcedure);
}


void LpcDConnFlightPlan::ConvertArrivalInfoIO2FlightPlan(const IOFpl::ArrivalInformationS & in, LpiDemandFlightPlan & out)
{
   // Arrival times
   LpiDemandArrivalTimes arrivalTimes;

   boost::optional<unsigned long> eldt;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.eldt, eldt);
   if (eldt)
   {
      arrivalTimes.setEldt(*eldt);
   }

   boost::optional<unsigned long> aldt;
   LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(in.aldt, aldt);
   if (aldt)
   {
      arrivalTimes.setAldt(*aldt);
   }

   out.setArrivalTimes(arrivalTimes);

   // Destination aerodrome
   string arrivalAerodromeName(in.ades, IOAsm::AIRPORT_ST_SIZE);
   boost::algorithm::trim(arrivalAerodromeName);
   out.setArrivalAerodrome(arrivalAerodromeName);

   // STAR
   string starProcedure;
   if (in.star._d)
   {
      starProcedure = string(in.star._u.starName, IOAsm::STAR_SIZE);
      boost::algorithm::trim(starProcedure);
   }
   out.setSTAR(starProcedure);
}


void LpcDConnFlightPlan::ConvertIO2FlightPlan(const IOFpl::FlightPlanS &in, LpiDemandFlightPlan &out)
{
   // Callsign
   string callsign(in.callsign, IOFpl::CALLSIGN_SIZE);
   boost::algorithm::trim(callsign);
   out.setCallsign(callsign);


   // Aircraft type
   string aircraftType(in.aircraft.acType, IOAct::ACTYPE_SIZE);
   boost::algorithm::trim(aircraftType);
   out.setAircraftType(aircraftType);

   // WTC
   string wtc(in.aircraft.wtc, IOAct::WTC_SIZE);
   boost::algorithm::trim(wtc);
   out.setWtc(wtc);

   // Departure information
   LpcDConnFlightPlan::ConvertDepartureInfoIO2FlightPlan(in.depInfo, out);

   // Arrival information
   LpcDConnFlightPlan::ConvertArrivalInfoIO2FlightPlan(in.arrInfo, out);

   out.setSource(LpiFlightPlanSource::E_NOVA);
}


void LpcDConnFlightPlan::ConvertOptionalTimeIO2Epoch(const IOTim::OptionalTimeU & optionalTime,
                                                     boost::optional<unsigned long> & epochTime)
{
   if(optionalTime._d == true)
   {
      //epochTime = static_cast<unsigned long>(optionalTime._u.value);
   }
   else
   {
      epochTime = boost::none;
   }
}


