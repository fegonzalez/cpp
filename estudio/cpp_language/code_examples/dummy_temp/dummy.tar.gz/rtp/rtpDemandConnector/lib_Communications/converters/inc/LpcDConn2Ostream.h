
#ifndef LRCDCONN2OSTREAM_H_
#define LRCDCONN2OSTREAM_H_

#include <iostream>
#include <IOTimOut.h>


std::ostream & operator<<(std::ostream &,
                          const IOTimOut::TimeS &);

std::ostream & operator<<(std::ostream &,
                          const IOTimOut::OptionalTimeU &);







#endif /* LRCDCONN2OSTREAM_H_ */
