/*
 * LpcFlightPlanEventType.cc
 *
 *  Created on: 05/05/2015
 *      Author: mbegega
 */

#include "LpcDConnFlightPlan.h"
#include "LpcFlightPlanEvent.h"


void LpcFlightPlanEvent::ConvertIO2FPEvent(const IOFplEvents::FlightPlanEventS & in, LpiDConnUpdateFlightPlanEvt & out)
{

   LpiFlightPlanEventType eventType;
   LpiDemandFlightPlan fp;

   switch (in.eventData._d)
   {
      case IOFplEvents::CREATE:
         eventType.setType(LpiFlightPlanEventType::E_CREATE);
         LpcDConnFlightPlan::ConvertIO2FlightPlan(in.eventData._u.createdFlightPlan, fp);
      break;

      case IOFplEvents::UPDATE:
         eventType.setType(LpiFlightPlanEventType::E_UPDATE);
         LpcDConnFlightPlan::ConvertIO2FlightPlan(in.eventData._u.updatedFlightPlan, fp);
      break;

      case IOFplEvents::REMOVE:
         eventType.setType(LpiFlightPlanEventType::E_DELETE);
         LpcDConnFlightPlan::ConvertIO2FlightPlan(in.eventData._u.removedFlightPlan, fp);
      break;

      default:
         eventType.setType(LpiFlightPlanEventType::E_UNKNOWN);
      break;
   }

   out.setEventType(eventType);
   out.setFlightPlan(fp);
}
