
#ifndef LRCUPDATEDEMANDFORECASTEVTPUBLISHER_H_
#define LRCUPDATEDEMANDFORECASTEVTPUBLISHER_H_

#include <LpiIDConnEventPublishers.h>
#include <LclogStream.h>
#include <IODemandEvents.h>
#include <IODemandEventsiBContract.h>


class LpcUpdateDemandForecastEvtPublisher : public LpiIDConnUpdateDemandForecastEvtPublisher
{
   public:

      void init();

      virtual void publish(const LpiDConnUpdateDemandForecastEvt & evt);

      virtual ~LpcUpdateDemandForecastEvtPublisher()
      {
      }

   private:

      iBG::IODemandEvents::CreateDemandEventListPublisher * r_publisher;

};



#endif /* LRCUPDATEDEMANDFORECASTEVTPUBLISHER_H_ */
