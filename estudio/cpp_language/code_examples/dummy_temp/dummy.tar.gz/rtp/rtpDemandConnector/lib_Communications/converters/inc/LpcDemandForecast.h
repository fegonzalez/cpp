/*
 * LpcDemandForecast.h
 *
 *  Created on: 30/04/2015
 *      Author: mbegega
 */

#ifndef LRCDEMANDFORECAST_H_
#define LRCDEMANDFORECAST_H_

#include <IODemand.h>
#include <IODemandRTP.h>
#include <LpiDemandFlightPlan.h>
#include <LpiCreateDemandForecast.h>

#include <boost/optional.hpp>

class LpcDemandForecast
{
   public:

      static void Convert2IODemandForecast(const LpiCreateDemandForecast & in, IODemandRTP::Demand & out);

   private:

      static void Convert2IODepartureTimes(const LpiDepartureTimes & in, IODemandRTP::DepartureInfo & out);

      static void Convert2IOArrivalTimes(const LpiArrivalTimes & in, IODemandRTP::ArrivalInfo & out);

      static void Convert2OptionalTimeIO(const boost::optional<unsigned long> & in,
                                         IOTim::OptionalTimeU & out);
};


#endif /* LRCDEMANDFORECAST_H_ */
