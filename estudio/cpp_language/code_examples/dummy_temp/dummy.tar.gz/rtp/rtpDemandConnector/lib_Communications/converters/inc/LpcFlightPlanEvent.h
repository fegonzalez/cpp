/*
 * LpcFlightPlanEvent.h
 *
 *  Created on: 05/05/2015
 *      Author: mbegega
 */

#ifndef LRCFLIGHTPLANEVEN_H_
#define LRCFLIGHTPLANEVENT_H_

#include <IOFplEvents.h>
#include "LpiDConnUpdateFlightPlanEvt.h"


class LpcFlightPlanEvent
{
   public:

      static void ConvertIO2FPEvent(const IOFplEvents::FlightPlanEventS & in, LpiDConnUpdateFlightPlanEvt & out);

   private:
};



#endif /* LRCFLIGHTPLANEVENT_H_ */
