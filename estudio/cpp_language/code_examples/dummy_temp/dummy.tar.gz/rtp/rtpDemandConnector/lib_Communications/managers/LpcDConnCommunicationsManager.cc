/*
 * LpcdDConnCommunicationsManager.cc
 *
 */

#include <LclogStream.h>
#include "LpcDConnCommunicationsManager.h"


void wait()
{
   while (1)
   {
      boost::this_thread::sleep(boost::posix_time::milliseconds(500));
   }
}

LpcDConnCommunicationsManager& LpcDConnCommunicationsManager::Get()
{
   static LpcDConnCommunicationsManager manager;
   return manager;
}


void LpcDConnCommunicationsManager::initialise()
{
   r_updateDemandForecastEvtPublisher->init();
   r_updateFlightPlanEvtConsumer->init();
}


LpcDConnCommunicationsManager::LpcDConnCommunicationsManager ():
   r_updateFlightPlanEvtConsumer(new LpcUpdateFlightPlanEvtConsumer()),
   r_updateDemandForecastEvtPublisher(new LpcUpdateDemandForecastEvtPublisher())
{

}

void LpcDConnCommunicationsManager::waitForEvents()
{
   boost::thread _waitThread(&wait);
   LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).notify() << "Demand Connector Ready: Waiting for Events..." << std::endl;
   std::cout << "Demand Connector Ready: Waiting for Events..." << std::endl;
   _waitThread.join();
}

