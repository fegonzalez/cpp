
#include "LpcDConn2Ostream.h"
#include <LcuStringArrayConvUtils.h>


std::ostream & operator<<(std::ostream & out,
                          const IOTimOut::TimeS & timeS)
{
   return out << "[SEC:" << timeS.sec
              << "|USC:" << timeS.usec << ']';
}


std::ostream & operator<<(std::ostream & out,
                          const IOTimOut::OptionalTimeU & oTime)
{
   return out << "[OFD:" << oTime._d
              << "|OFU:[VAL:" << oTime._u.value
              << "|FLD:" << oTime._u.field
              << "]]";
}

