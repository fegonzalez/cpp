
#include "LpiFlightPlanEventType.h"


LpiFlightPlanEventType::LpiFlightPlanEventType(): r_type(E_UNKNOWN)
{}


std::string LpiFlightPlanEventType::ToString(LpiFlightPlanEventType::LpiEnum fpEventType)
{
   std::string result;

   switch (fpEventType)
   {
      case LpiFlightPlanEventType::E_UNKNOWN:
         result = "UNKNOWN";
      break;

      case LpiFlightPlanEventType::E_CREATE:
         result = "CREATE";
      break;

      case LpiFlightPlanEventType::E_UPDATE:
         result = "UPDATE";
      break;

      case LpiFlightPlanEventType::E_DELETE:
         result = "DELETE";
      break;

      default:
         result = "UNKNOWN";
      break;
   }

   return result;
}


std::ostream & operator<<(std::ostream & os, const LpiFlightPlanEventType & fpEvent)
{
   os << "EVT TYPE: " << LpiFlightPlanEventType::ToString(fpEvent.getType());

   return os;
}

