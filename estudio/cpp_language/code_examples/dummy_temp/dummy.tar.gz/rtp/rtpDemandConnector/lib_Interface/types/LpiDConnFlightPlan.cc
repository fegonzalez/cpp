/*
 * LpiDConnFlightPlan.cpp
 *
 *  Created on: 27/04/2015
 *      Author: mbegega
 */

#include <iostream>

#include "LctimTimeUtils.h"
#include "LpiDConnFlightPlan.h"

// LpiDemandDepartureTimes method implementations
/*

LpiDemandDepartureTimes::LpiDemandDepartureTimes()
:  r_eobt(), r_sobt(), r_tobt(),
   r_etot(), r_ttot(), r_stot(),
   r_atot(), r_ctot(), r_aobt(),
   r_utot(), r_itot()
{
}


LpiDemandDepartureTimes::LpiDemandDepartureTimes(const LpiDemandDepartureTimes& source)
:  r_eobt(source.r_eobt), r_sobt(source.r_sobt), r_tobt(source.r_tobt),
   r_etot(source.r_etot), r_ttot(source.r_ttot), r_stot(source.r_stot),
   r_atot(source.r_atot), r_ctot(source.r_ctot), r_aobt(source.r_aobt),
   r_utot(source.r_utot), r_itot(source.r_itot)
{
}


LpiDemandDepartureTimes::LpiDemandDepartureTimes(unsigned long eobt,
      unsigned long sobt, unsigned long tobt, unsigned long etot,
      unsigned long ttot, unsigned long stot, unsigned long atot,
      unsigned long ctot, unsigned long aobt, unsigned long utot)
:  r_eobt(eobt), r_sobt(sobt), r_tobt(tobt),
   r_etot(etot), r_ttot(ttot), r_stot(stot),
   r_atot(atot), r_ctot(ctot), r_aobt(aobt),
   r_utot(utot), r_itot()
{
}


LpiDemandDepartureTimes& LpiDemandDepartureTimes::operator =(const LpiDemandDepartureTimes& source)
{
   if (this != &source)
   {
     if(source.r_eobt) { r_eobt= source.r_eobt; }
     if(source.r_sobt) { r_sobt= source.r_sobt; }
     if(source.r_tobt) { r_tobt= source.r_tobt; }
     if(source.r_etot) { r_etot= source.r_etot; }
     if(source.r_ttot) { r_ttot= source.r_ttot; }
     if(source.r_stot) { r_stot= source.r_stot; }
     if(source.r_atot) { r_atot= source.r_atot; }
     if(source.r_ctot) { r_ctot= source.r_ctot; }
     if(source.r_aobt) { r_aobt= source.r_aobt; }
     if(source.r_utot) { r_utot= source.r_utot; }
     if(source.r_itot) { r_itot= source.r_itot; }
   }
   return *this;
}


void LpiDemandDepartureTimes::setEobt (unsigned long timestamp)
{
   r_eobt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getEobt () const
{
   return r_eobt;
}


void LpiDemandDepartureTimes::setSobt (unsigned long timestamp)
{
   r_sobt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getSobt () const
{
   return r_sobt;
}

void LpiDemandDepartureTimes::setTobt (unsigned long timestamp)
{
   r_tobt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getTobt () const
{
   return r_tobt;
}

void LpiDemandDepartureTimes::setEtot (unsigned long timestamp)
{
   r_etot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getEtot () const
{
   return r_etot;
}

void LpiDemandDepartureTimes::setTtot (unsigned long timestamp)
{
   r_ttot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getTtot () const
{
   return r_ttot;
}



void LpiDemandDepartureTimes::setStot (unsigned long timestamp)
{
   r_stot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getStot () const
{
   return r_stot;
}

void LpiDemandDepartureTimes::setAtot (unsigned long timestamp)
{
   r_atot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getAtot () const
{
   return r_atot;
}

void LpiDemandDepartureTimes::setCtot (unsigned long timestamp)
{
   r_ctot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getCtot () const
{
   return r_ctot;
}


void LpiDemandDepartureTimes::setAobt (unsigned long timestamp)
{
   r_aobt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getAobt () const
{
   return r_aobt;
}


void LpiDemandDepartureTimes::setUtot (unsigned long timestamp)
{
   r_utot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getUtot () const
{
   return r_utot;
}


void LpiDemandDepartureTimes::setItot (unsigned long timestamp)
{
   r_itot= timestamp;
}


const boost::optional<unsigned long> & LpiDemandDepartureTimes::getItot () const
{
   return r_itot;
}


bool LpiDemandDepartureTimes::isInWindow(unsigned long windowStart, unsigned long windowEnd) const
{
   return (r_eobt && LpiDConnFlightPlan::isInWindow(*r_eobt, windowStart, windowEnd)) ||
          (r_sobt && LpiDConnFlightPlan::isInWindow(*r_sobt, windowStart, windowEnd)) ||
          (r_tobt && LpiDConnFlightPlan::isInWindow(*r_tobt, windowStart, windowEnd)) ||
          (r_etot && LpiDConnFlightPlan::isInWindow(*r_etot, windowStart, windowEnd)) ||
          (r_ttot && LpiDConnFlightPlan::isInWindow(*r_ttot, windowStart, windowEnd)) ||
          (r_stot && LpiDConnFlightPlan::isInWindow(*r_stot, windowStart, windowEnd)) ||
          (r_atot && LpiDConnFlightPlan::isInWindow(*r_atot, windowStart, windowEnd)) ||
          (r_ctot && LpiDConnFlightPlan::isInWindow(*r_ctot, windowStart, windowEnd)) ||
          (r_aobt && LpiDConnFlightPlan::isInWindow(*r_aobt, windowStart, windowEnd)) ||
          (r_utot && LpiDConnFlightPlan::isInWindow(*r_utot, windowStart, windowEnd));
}


std::ostream& operator<< (std::ostream & out, const LpiDemandDepartureTimes & dep)
{
   boost::optional<unsigned long> eobt = dep.getEobt();
   boost::optional<unsigned long> sobt = dep.getSobt();
   boost::optional<unsigned long> tobt = dep.getTobt();
   boost::optional<unsigned long> etot = dep.getEtot();
   boost::optional<unsigned long> ttot = dep.getTtot();
   boost::optional<unsigned long> stot = dep.getStot();
   boost::optional<unsigned long> atot = dep.getAtot();
   boost::optional<unsigned long> ctot = dep.getCtot();
   boost::optional<unsigned long> aobt = dep.getAobt();
   boost::optional<unsigned long> utot = dep.getUtot();

   boost::optional<unsigned long> itot = dep.getItot();

   out << '[';
   if (eobt) { out << "EOBT: "   << *eobt; }
   if (sobt) { out << " |SOBT: " << *sobt; }
   if (tobt) { out << " |TOBT: " << *tobt; }
   if (etot) { out << " |ETOT: " << *etot; }
   if (ttot) { out << " |TTOT: " << *ttot; }
   if (stot) { out << " |STOT: " << *stot; }
   if (atot) { out << " |ATOT: " << *atot; }
   if (ctot) { out << " |CTOT: " << *ctot; }
   if (aobt) { out << " |AOBT: " << *aobt; }
   if (utot) { out << " |UTOT: " << *utot; }
   if (itot) { out << " |ITOT: " << *itot; }
   out << ']';

   return out;
}


// LpiDemandArrivalTimes method implementations

LpiDemandArrivalTimes::LpiDemandArrivalTimes()
:  r_eldt(), r_tldt(), r_aldt(),
   r_sldt(), r_sibt(), r_uldt(),
   r_ildt()
{
}


LpiDemandArrivalTimes::LpiDemandArrivalTimes(const LpiDemandArrivalTimes& source)
:  r_eldt(source.r_eldt), r_tldt(source.r_tldt), r_aldt(source.r_aldt),
   r_sldt(source.r_sldt), r_sibt(source.r_sibt), r_uldt(source.r_uldt),
   r_ildt(source.r_ildt)
{
}


LpiDemandArrivalTimes::LpiDemandArrivalTimes(unsigned long eldt, unsigned long tldt,
                                 unsigned long aldt, unsigned long sldt,
                                 unsigned long sibt, unsigned long uldt)
:  r_eldt(eldt), r_tldt(tldt), r_aldt(aldt),
   r_sldt(sldt), r_sibt(sibt), r_uldt(uldt)
{
}


LpiDemandArrivalTimes& LpiDemandArrivalTimes::operator =(const LpiDemandArrivalTimes& source)
{
   if (this != &source)
   {
      if(source.r_eldt){r_eldt= source.r_eldt;}
      if(source.r_tldt){r_tldt= source.r_tldt;}
      if(source.r_aldt){r_aldt= source.r_aldt;}
      if(source.r_sldt){r_sldt= source.r_sldt;}
      if(source.r_sibt){r_sibt= source.r_sibt;}
      if(source.r_uldt){r_uldt= source.r_uldt;}
      if(source.r_ildt){r_ildt= source.r_ildt;}
   }

   return *this;
}


void LpiDemandArrivalTimes::setIldt (unsigned long timestamp)
{
   r_ildt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getIldt () const
{
   return r_ildt;
}


void LpiDemandArrivalTimes::setEldt (unsigned long timestamp)
{
   r_eldt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getEldt () const
{
   return r_eldt;
}

void LpiDemandArrivalTimes::setTldt (unsigned long timestamp)
{
   r_tldt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getTldt () const
{
   return r_tldt;
}

void LpiDemandArrivalTimes::setAldt (unsigned long timestamp)
{
   r_aldt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getAldt () const
{
   return r_aldt;
}


void LpiDemandArrivalTimes::setSldt (unsigned long timestamp)
{
   r_sldt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getSldt () const
{
   return r_sldt;
}


void LpiDemandArrivalTimes::setSibt (unsigned long timestamp)
{
   r_sibt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getSibt () const
{
   return r_sibt;
}


void LpiDemandArrivalTimes::setUldt(unsigned long timestamp)
{
   r_uldt= timestamp;
}


const boost::optional<unsigned long> & LpiDemandArrivalTimes::getUldt() const
{
   return r_uldt;
}


bool LpiDemandArrivalTimes::isInWindow(unsigned long windowStart, unsigned long windowEnd) const
{
   return (r_eldt && LpiDConnFlightPlan::isInWindow(*r_eldt, windowStart, windowEnd)) ||
          (r_tldt && LpiDConnFlightPlan::isInWindow(*r_tldt, windowStart, windowEnd)) ||
          (r_aldt && LpiDConnFlightPlan::isInWindow(*r_aldt, windowStart, windowEnd)) ||
          (r_sldt && LpiDConnFlightPlan::isInWindow(*r_sldt, windowStart, windowEnd)) ||
          (r_sibt && LpiDConnFlightPlan::isInWindow(*r_sibt, windowStart, windowEnd)) ||
          (r_uldt && LpiDConnFlightPlan::isInWindow(*r_uldt, windowStart, windowEnd));
}


// std::ostream& operator<< (std::ostream & out, const LpiDemandArrivalTimes & dep)
// {
//    boost::optional<unsigned long> eldt = dep.getEldt();
//    boost::optional<unsigned long> tldt = dep.getTldt();
//    boost::optional<unsigned long> aldt = dep.getAldt();
//    boost::optional<unsigned long> sldt = dep.getSldt();
//    boost::optional<unsigned long> sibt = dep.getSibt();
//    boost::optional<unsigned long> uldt = dep.getUldt();

//    boost::optional<unsigned long> ildt = dep.getIldt();

//    out << '[';
//    if (eldt) { out << "ELDT: "   << *eldt; }
//    if (tldt) { out << " |TLDT: " << *tldt; }
//    if (aldt) { out << " |ALDT: " << *aldt; }
//    if (sldt) { out << " |SLDT: " << *sldt; }
//    if (sibt) { out << " |SIBT: " << *sibt; }
//    if (uldt) { out << " |ULDT: " << *uldt; }
//    if (ildt) { out << " |ILDT: " << *ildt; }
//    out << ']';

//    return out;
// }


//LpdbFlightPlan method implementations

LpiDConnFlightPlan::LpiDConnFlightPlan()
:  r_callsign(""),
   r_departure_aerodrome(""),
   r_arrival_aerodrome(""),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_flightKey_Nova(""),
   r_company(""),
   r_departure_times(),
   r_arrival_times(),
   r_source(LpiFlightPlanSource::E_UNKNOWN)
{
}


LpiDConnFlightPlan::LpiDConnFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome)
:  r_callsign(callsign),
   r_departure_aerodrome(dep_aerodrome),
   r_arrival_aerodrome(arr_aerodrome),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_flightKey_Nova(""),
   r_company(""),
   r_departure_times(),
   r_arrival_times(),
   r_source(LpiFlightPlanSource::E_UNKNOWN)
{
}


LpiDConnFlightPlan::LpiDConnFlightPlan(const LpiDConnFlightPlan& source)
:  r_callsign(source.r_callsign),
   r_departure_aerodrome(source.r_departure_aerodrome),
   r_arrival_aerodrome(source.r_arrival_aerodrome),
   r_aircraft_type(source.r_aircraft_type),
   r_registration(source.r_registration),
   r_wtc(source.r_wtc),
   r_sid(source.r_sid),
   r_star(source.r_star),
   r_flightKey_Nova(source.r_flightKey_Nova),
   r_company(source.r_company),
   r_departure_times(source.r_departure_times),
   r_arrival_times(source.r_arrival_times),
   r_source(source.r_source)
{
}


LpiDConnFlightPlan& LpiDConnFlightPlan::operator =(const LpiDConnFlightPlan& source)
{
   if (this != &source)
   {
      r_callsign = source.r_callsign;
      r_departure_aerodrome = source.r_departure_aerodrome;
      r_arrival_aerodrome = source.r_arrival_aerodrome;
      r_aircraft_type = source.r_aircraft_type;
      r_registration = source.r_registration;
      r_wtc = source.r_wtc;
      r_sid = source.r_sid;
      r_star = source.r_star;
      r_flightKey_Nova = source.r_flightKey_Nova;
      r_company = source.r_company;
      r_departure_times = source.r_departure_times;
      r_arrival_times = source.r_arrival_times;
      r_source = source.r_source;
   }

   return *this;
}


string LpiDConnFlightPlan::getAircraftType() const
{
   return r_aircraft_type;
}

void LpiDConnFlightPlan::setAircraftType(string aircraftType)
{
   r_aircraft_type = aircraftType;
}


string LpiDConnFlightPlan::getArrivalAerodrome() const
{
   return r_arrival_aerodrome;
}


void LpiDConnFlightPlan::setArrivalAerodrome(string arrivalAerodrome)
{
   r_arrival_aerodrome = arrivalAerodrome;
}


LpiDemandArrivalTimes LpiDConnFlightPlan::getArrivalTimes() const
{
   return r_arrival_times;
}


void LpiDConnFlightPlan::setArrivalTimes(LpiDemandArrivalTimes arrivalTimes)
{
   r_arrival_times = arrivalTimes;
}

string LpiDConnFlightPlan::getCallsign() const
{
   return r_callsign;
}


void LpiDConnFlightPlan::setCallsign(string callsign)
{
   r_callsign = callsign;
}


string LpiDConnFlightPlan::getDepartureAerodrome() const
{
   return r_departure_aerodrome;
}


void LpiDConnFlightPlan::setDepartureAerodrome(string departureAerodrome)
{
   r_departure_aerodrome = departureAerodrome;
}


LpiDemandDepartureTimes LpiDConnFlightPlan::getDepartureTimes() const
{
   return r_departure_times;
}


void LpiDConnFlightPlan::setDepartureTimes(LpiDemandDepartureTimes departureTimes)
{
   r_departure_times = departureTimes;
}


string LpiDConnFlightPlan::getRegistration() const
{
   return r_registration;
}


void LpiDConnFlightPlan::setRegistration(string registration)
{
   r_registration = registration;
}


string LpiDConnFlightPlan::getWtc() const
{
   return r_wtc;
}


void LpiDConnFlightPlan::setWtc(string wtc) {
   r_wtc = wtc;
}


string LpiDConnFlightPlan::getSID() const
{
   return r_sid;
}


void LpiDConnFlightPlan::setSID(string sid)
{
   r_sid = sid;
}


string LpiDConnFlightPlan::getSTAR() const
{
   return r_star;
}


void LpiDConnFlightPlan::setSTAR(string star)
{
   r_star = star;
}


const string & LpiDConnFlightPlan::getFlightKeyNova() const
{
   return r_flightKey_Nova;
}


void LpiDConnFlightPlan::setFlightKeyNova(const string & key)
{
   r_flightKey_Nova = key;
}


const string & LpiDConnFlightPlan::getCompany() const
{
   return r_company;
}


void LpiDConnFlightPlan::setCompany(const string & company)
{
   r_company = company;
}

*/


string LpiDConnFlightPlan::getUniqueKey() const
{
   string key = r_callsign;
   key += r_departure_aerodrome;
   key += r_arrival_aerodrome;


   ///@todo FIXME RMAN's code
   //   string stringifiedEobt;
   // if (r_departure_times.getEobt())
   // {
   //    unsigned long eobt = *(r_departure_times.getEobt());

   //    try
   //    {
   //       stringifiedEobt = boost::lexical_cast<std::string>(eobt);
   //    }
   //    catch(...)
   //    {
   //       stringifiedEobt = "";
   //    }
   // }
   // if (stringifiedEobt.size() > 0)
   // {
   //    key += stringifiedEobt;
   // }

   return key;
}

/*
const LpiFlightPlanSource::LpiEnum & LpiDConnFlightPlan::getSource() const
{
   return r_source;
}


void LpiDConnFlightPlan::setSource(const LpiFlightPlanSource::LpiEnum & source)
{
   r_source = source;
}


bool LpiDConnFlightPlan::isInWindow(unsigned long windowStart, unsigned long windowEnd) const
{
   return r_departure_times.isInWindow(windowStart, windowEnd) ||
          r_arrival_times.isInWindow(windowStart, windowEnd);
}


bool LpiDConnFlightPlan::isInWindow(unsigned long fpTime, unsigned long windowStart, unsigned long windowEnd)
{
   return (fpTime >= windowStart) &&
          (fpTime <= windowEnd);
}

*/
std::ostream& operator<< (std::ostream & out, const LpiDConnFlightPlan & fp)
{

out << "[KEY: " << fp.getUniqueKey()
       << " |CSGN: " << fp.getCallsign();
return out;


   /*std::stringstream out_stream;

   if (fp.getAircraftType().size() > 0)
   {
      out_stream << " |AT: " << fp.getAircraftType();
   }

   if (fp.getWtc().size() > 0)
   {
      out_stream << " |WTC: " << fp.getWtc();
   }

   if (fp.getRegistration().size() > 0)
   {
      out_stream << " |REG: " << fp.getRegistration();
   }

   if (fp.getSID().size() > 0)
   {
      out_stream << " |SID: " << fp.getSID();
   }
   else if (fp.getSTAR().size() > 0)
   {
      out_stream << " |STAR: " << fp.getSTAR();
   }

   if (fp.getFlightKeyNova().size() > 0)
   {
      out_stream << " |FLIGHT_ID: " << fp.getFlightKeyNova();
   }

   out << "[KEY: " << fp.getUniqueKey()
       << " |CSGN: " << fp.getCallsign()
       << " |DEP: " << fp.getDepartureAerodrome()
       << " |ARR: " << fp.getArrivalAerodrome()
       << " |DEP_TIMES: " << fp.getDepartureTimes()
       << " |ARR_TIMES: " << fp.getArrivalTimes()
       << out_stream.str();
   out << "|SOURCE: " << LpiFlightPlanSource::ToString(fp.getSource());
   out << ']';
*/
   return out;
}

