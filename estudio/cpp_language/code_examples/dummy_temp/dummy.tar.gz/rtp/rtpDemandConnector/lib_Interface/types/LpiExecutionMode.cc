
#include "LpiExecutionMode.h"

std::ostream & operator<<(std::ostream & out,
                          const LpiExecutionMode::LpiEnum & executionMode)
{
   switch (executionMode)
   {
      case LpiExecutionMode::E_UNKNOWN:
         out << "UNKNOWN";
      break;
      case LpiExecutionMode::E_DUMMY:
         out << "DUMMY";
      break;
      case LpiExecutionMode::E_CONNECTOR:
         out << "CONNECTOR";
      break;
      default:
         out << "UNKNOWN";
      break;
   }

   return out;
}

