#if !defined(__LRI_DCONN_SERVICE_DELEGATE_USERS_IMPL__)
#define __LRI_DCONN_SERVICE_DELEGATE_USERS_IMPL__

#include "LpiDConnServiceDelegateUserImpl.h"
#include "LpiDConnRequests.h"
#include "LpiDConnReplies.h"

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetDemandConnectorConfigurationReply
> LpiGetDemandConnectorConfigurationSrvDelegateUser;


typedef LpiReplyServiceDelegateUserImpl<
   LpiGetInputDemandReply
> LpiGetInputDemandSrvDelegateUser;


typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAirportInfoReply
>LpiGetAirportInfoSrvDelegateUser;


#endif // __LRI_SERVICE_DELEGATE_USERS_IMPL__
