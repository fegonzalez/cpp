#if !defined(__LRI_DConn_I_EVENT_CONSUMER__)
#define __LRI_DConn_I_EVENT_CONSUMER__

// Interface abstracto para un consumidor de eventos
template<typename TEvent>
class LpiDConnIEventConsumer
{
public:
   LpiDConnIEventConsumer() {}
   virtual ~LpiDConnIEventConsumer() {}
   virtual void consume(const TEvent &data) = 0;
};

#endif // __LRI_I_EVENT_CONSUMER__
