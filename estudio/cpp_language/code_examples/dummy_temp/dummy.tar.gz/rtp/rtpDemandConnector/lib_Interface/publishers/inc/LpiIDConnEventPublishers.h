#ifndef LRI_DCONN_EVENT_PUBLISHERS_H_
#define LRI_DCONN_EVENT_PUBLISHERS_H_

#include "LpiIDConnEventPublisher.h"
#include "LpiDConnEvents.h"

typedef LpiIDConnEventPublisher<
   LpiDConnUpdateDemandForecastEvt
> LpiIDConnUpdateDemandForecastEvtPublisher;


#endif /* LRI_DCONEVENT_PUBLISHERS_H_ */
