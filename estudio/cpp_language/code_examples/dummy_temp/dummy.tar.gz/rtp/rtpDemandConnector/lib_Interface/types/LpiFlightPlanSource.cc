
#include "LpiFlightPlanSource.h"


LpiFlightPlanSource::LpiFlightPlanSource(): r_source(E_UNKNOWN)
{}


std::string LpiFlightPlanSource::ToString(LpiFlightPlanSource::LpiEnum fpSource)
{
   std::string result;

   switch (fpSource)
   {
      case LpiFlightPlanSource::E_UNKNOWN:
         result = "UNKNOWN";
      break;

      case LpiFlightPlanSource::E_NOVA:
         result = "NOVA";
      break;

      case LpiFlightPlanSource::E_AOP:
         result = "AOP";
      break;

      default:
         result = "UNKNOWN";
      break;
   }

   return result;
}


std::ostream & operator<<(std::ostream & os, const LpiFlightPlanSource & fpSource)
{
   os << LpiFlightPlanSource::ToString(fpSource.getSource());

   return os;
}

