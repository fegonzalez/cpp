#if !defined(__LRI_DCONN_CONSUMERS__)
#define __LRI_DCONN_CONSUMERS__

#include "LpiDConnIEventConsumers.h"

#endif // __LRI_CONSUMERS__
