
#if !defined(__LPI_DCONN_RESULT__)
#define __LPI_DCONN_RESULT__


#include <iostream>

class LpiDConnResult
{
   public:
	LpiDConnResult();

      enum LpiEnum
      {
         E_NONE = 0,
         E_OK,
         E_NO_OK
      };

      const LpiDConnResult::LpiEnum getResult(void) const {return this->_result;}
      void setResult(LpiDConnResult::LpiEnum value) {this->_result = value;}

   private:
       LpiEnum _result;
};


std::ostream & operator<<(std::ostream & os, const LpiDConnResult & result);


#endif // __LRI_RESULT__
