
#ifndef LRIGETDEMANDCONNECTORCONFIGURATIONREPLY_H_
#define LRIGETDEMANDCONNECTORCONFIGURATIONREPLY_H_

#include <LpiDemandConnectorConfiguration.h>
#include <LpiDConnResult.h>


class LpiGetDemandConnectorConfigurationReply
{
   public:

      const LpiDemandConnectorConfiguration & getConfiguration() const
      { return this->r_configuration; }

      const LpiDConnResult::LpiEnum & getResult() const
      { return this->r_result; }

      void setConfiguration(const LpiDemandConnectorConfiguration & value)
      { this->r_configuration = value; }

      void setResult(const LpiDConnResult::LpiEnum & result)
      { this->r_result = result; }

   private:

      LpiDemandConnectorConfiguration r_configuration;
      LpiDConnResult::LpiEnum              r_result;
};


#endif /* LRIGETDEMANDCONNECTORCONFIGURATIONREPLY_H_ */
