/*
 * LpiDConnFlightPlan.h
 *
 *  Created on: 27/04/2015
 *      Author: mbegega
 */

#ifndef LPIDCONNFLIGHTPLAN_H_
#define LPIDCONNFLIGHTPLAN_H_


#include <iostream>
#include <string>
#include <vector>

#include <boost/optional/optional.hpp>
#include <boost/foreach.hpp>

#include "LpiFlightPlanSource.h"

using std::string;
using std::vector;


class LpiDConnFlightPlan
{
   public:

  LpiDConnFlightPlan ();
     LpiDConnFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome);
      LpiDConnFlightPlan (const LpiDConnFlightPlan & source);

      virtual ~LpiDConnFlightPlan () {}

      LpiDConnFlightPlan & operator= (const LpiDConnFlightPlan & source);

      //Getters and Setters
      string getAircraftType() const;
      void setAircraftType(string aircraftType);

      string getArrivalAerodrome() const;
      void setArrivalAerodrome(string arrivalAerodrome);

      //      LpiDemandArrivalTimes getArrivalTimes() const;
      //      void setArrivalTimes(LpiDemandArrivalTimes arrivalTimes);

      string getCallsign() const;
      void setCallsign(string callsign);

      string getDepartureAerodrome() const;
      void setDepartureAerodrome(string departureAerodrome);

      string getRegistration() const;
      void setRegistration(string registration);

      string getWtc() const;
      void setWtc(string wtc);

      string getSID() const;
      void setSID(string sid);

      string getSTAR() const;
      void setSTAR(string star);

      const string & getFlightKeyNova() const;
      void setFlightKeyNova(const string & key);

      const string & getCompany() const;
      void setCompany(const string & key);


      const LpiFlightPlanSource::LpiEnum & getSource() const;
      void setSource(const LpiFlightPlanSource::LpiEnum & source);


      //Returns an unique identification, for example, for DB storing
      //Key used: "callsign departure arrival"
      string getUniqueKey() const;

   //   bool isInWindow(unsigned long windowStart, unsigned long windowEnd) const;

      //Utility method
   //   static bool isInWindow(unsigned long fpTime, unsigned long windowStart, unsigned long windowEnd);

   protected:

      string             r_callsign;
      string             r_departure_aerodrome;
      string             r_arrival_aerodrome;
      string             r_aircraft_type;
      string             r_registration;
      string             r_wtc;    // "Light, Medium, Heavy"
      string             r_sid;
      string             r_star;

      //NOVA specific fields
      string             r_flightKey_Nova; //NOVA Specific flight unique ID
      string             r_company;


      LpiFlightPlanSource::LpiEnum r_source;
};


std::ostream& operator<< (std::ostream & out, const LpiDConnFlightPlan & fp);


#endif /* LRIDCONNFLIGHTPLAN_H_ */
