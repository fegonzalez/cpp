/*
 * LpiIGetDemandConnectorConfiguration.h
 *
 */

#ifndef LRIIGETDEMANDCONNECTORCONFIGURATION_H_
#define LRIIGETDEMANDCONNECTORCONFIGURATION_H_

#include "LpiDemandConnectorConfiguration.h"
#include "LpiDConnResult.h"

class LpiIGetDemandConnectorConfiguration
{
   public:
      virtual ~LpiIGetDemandConnectorConfiguration() {}
      virtual void getConfiguration(LpiDemandConnectorConfiguration & parameters,
    		  LpiDConnResult & result) = 0;
};



#endif /* LRIIGETDEMANDCONNECTORCONFIGURATION_H_ */
