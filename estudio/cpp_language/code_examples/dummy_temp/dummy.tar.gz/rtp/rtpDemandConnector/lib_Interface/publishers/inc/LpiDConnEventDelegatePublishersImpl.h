#if !defined(__LRI_DConn_EVENT_DELEGATE_PUBLISHERS_IMPL__)
#define __LRI_DConn_EVENT_DELEGATE_PUBLISHERS_IMPL__

#include "LpiDConnEventDelegatePublisherImpl.h"
#include "LpiDConnEvents.h"

typedef LpiDConnEventDelegatePublisherImpl<
   LpiDConnUpdateDemandForecastEvt
> LpiUpdateDemandForecastEvtDelegatePublisher;

#endif // __LRI_EVENT_DELEGATE_PUBLISHERS_IMPL__
