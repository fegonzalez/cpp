#if !defined(__LRI_I_DCONN_SERVICE_DELEGATE_USERS__)
#define __LRI_I_DCONN_SERVICE_DELEGATE_USERS__

#include "LpiIDConnServiceDelegateUser.h"
#include "LpiDConnRequests.h"
#include "LpiDConnReplies.h"


typedef LpiIReplyServiceDelegateUser<
    LpiGetDemandConnectorConfigurationReply
> LpiIGetDemandConnectorConfigurationSrvDelegateUser;


typedef LpiIReplyServiceDelegateUser<
   LpiGetInputDemandReply
>LpiIGetInputDemandSrvDelegateUser;


typedef LpiIReplyServiceDelegateUser<
   LpiGetAirportInfoReply
>LpiIGetAirportInfoSrvDelegateUser;

#endif // __LXI_I_SERVICE_DELEGATE_USERS__
