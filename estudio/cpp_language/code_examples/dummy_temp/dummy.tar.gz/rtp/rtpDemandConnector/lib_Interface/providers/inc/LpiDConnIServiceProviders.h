#if !defined(__LRI_DCONN_I_SERVICE_PROVIDERS__)
#define __LRI_DCONN_I_SERVICE_PROVIDERS__


#include "LpiDConnIServiceProvider.h"
#include "LpiDConnRequests.h"
#include "LpiDConnReplies.h"


#endif // __LRI_I_SERVICE_PROVIDERS__
