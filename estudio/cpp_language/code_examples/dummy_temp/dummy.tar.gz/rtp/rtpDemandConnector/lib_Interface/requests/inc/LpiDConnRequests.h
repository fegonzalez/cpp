#if !defined(__LRI_DCONN_REQUESTS__)
#define __LRI_DCONN_REQUESTS__

#include "LpiGetDemandConnectorConfigurationRequest.h"
#include "LpiGetInputDemandRequest.h"

#endif // __LRI_REQUESTS__
