#ifndef LRI_I_PUBLISHDEMANDFORECAST_H__
#define LRI_I_PUBLISHDEMANDFORECAST_H__


class LpiIPublishDemandForecast
{
   public:

      LpiIPublishDemandForecast() {}
      virtual ~LpiIPublishDemandForecast() {}

      virtual void sendInputDemandForecast() = 0;
      virtual void publishDemandForecast() = 0;
};

#endif // LRI_I_PUBLISHDEMANDFORECAST_H__
