#if !defined(__LRI_I_DConn_DELEGATE_PUBLISHER__)
#define __LRI_I_DConn_DELEGATE_PUBLISHER__

template<typename TDelegate>
class LpiIDConnDelegatePublisher
{
public:
   LpiIDConnDelegatePublisher() {}
   virtual ~LpiIDConnDelegatePublisher() {}
   virtual void delegatePublisher(TDelegate &data) = 0;
};

#endif // __LRI_I_DELEGATE_PUBLISHER__
