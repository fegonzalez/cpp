#if !defined(__LRI_I_DConn_EVENT_DELEGATE_PUBLISHER__)
#define __LRI_I_DConn_EVENT_DELEGATE_PUBLISHER__

#include "LpiIDConnEventPublisher.h"
#include "LpiIDConnDelegatePublisher.h"
#include "LpiIDConnEventPublisher.h"

template<typename TEvent>
class LpiIDConnEventDelegatePublisher : public LpiIDConnEventPublisher<TEvent>,
                                   public LpiIDConnDelegatePublisher<LpiIDConnEventPublisher<TEvent> >
{
public:
   LpiIDConnEventDelegatePublisher() {}
   virtual ~LpiIDConnEventDelegatePublisher() {}
   virtual void delegatePublisher(LpiIDConnEventPublisher<TEvent> &data) = 0;
   virtual void publish(const TEvent &data) = 0;
};

#endif // __LRI_I_EVENT_DELEGATE_PUBLISHER__
