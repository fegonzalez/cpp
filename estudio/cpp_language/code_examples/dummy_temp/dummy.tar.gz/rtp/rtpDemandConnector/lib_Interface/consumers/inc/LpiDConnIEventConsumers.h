#if !defined(__LRI_DConn_I_EVENT_CONSUMERS__)
#define __LRI_DConn_I_EVENT_CONSUMERS__

#include "LpiDConnEvents.h"
#include "LpiDConnIEventConsumer.h"


typedef LpiDConnIEventConsumer<
	LpiDConnUpdateFlightPlanEvt
> LpiIUpdateFlightPlanEvtConsumer;


#endif // __LRI_I_EVENT_CONSUMERS__
