#ifndef LPIDConnDEMANDFORECASTEVT_H_
#define LPIDConnDEMANDFORECASTEVT_H_


#include <LpiCreateDemandForecast.h>

class LpiDConnUpdateDemandForecastEvt
{
   public:

      const LpiCreateDemandForecastList & getDemandForecastList () const
      { return r_demandForecastList; }

      void setDemandForecastList(const LpiCreateDemandForecastList & forecast)
      { r_demandForecastList = forecast; }

   private:

      LpiCreateDemandForecastList r_demandForecastList;
};

#endif // LPIDEMANDFORECASTEVT_H_
