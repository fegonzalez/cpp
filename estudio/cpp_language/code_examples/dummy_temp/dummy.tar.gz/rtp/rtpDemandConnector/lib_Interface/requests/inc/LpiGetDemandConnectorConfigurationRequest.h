
#ifndef LRIGETDEMANDCONNECTORCONFIGURATIONREQUEST_H_
#define LRIGETDEMANDCONNECTORCONFIGURATIONREQUEST_H_

#include "LpiDemandConnectorConfiguration.h"

class LpiGetDemandConnectorConfigurationRequest
{
   public:

      const LpiDemandConnectorConfiguration & getConfiguration() const
      { return this->r_configuration; }

      void setConfigurationParameters(const LpiDemandConnectorConfiguration & configuration)
      { this->r_configuration = configuration; }

   private:

      LpiDemandConnectorConfiguration r_configuration;
};


#endif /* LRIGETDEMANDCONNECTORCONFIGURATIONREQUEST */
