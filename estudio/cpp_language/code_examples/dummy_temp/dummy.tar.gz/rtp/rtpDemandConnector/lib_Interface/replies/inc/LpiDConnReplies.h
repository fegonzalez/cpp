#if !defined(__LRI_DCONN_REPLIES__)
#define __LRI_DCONN_REPLIES__

#include "LpiGetDemandConnectorConfigurationReply.h"
#include "LpiGetInputDemandReply.h"
#include "LpiGetAirportInfoReply.h"

#endif // __LRI_REPLIES__
