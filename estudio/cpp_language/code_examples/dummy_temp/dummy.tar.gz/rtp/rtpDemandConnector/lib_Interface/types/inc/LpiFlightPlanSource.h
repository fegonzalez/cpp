
#ifndef LPI_FLIGHTPLAN_SOURCE_H_
#define LPI_FLIGHTPLAN_SOURCE_H_

#include <iostream>
#include <string>

class LpiFlightPlanSource
{
   public:

      LpiFlightPlanSource();

      enum LpiEnum
      {
         E_UNKNOWN = 0,
         E_NOVA,
         E_AOP
      };

      const LpiFlightPlanSource::LpiEnum & getSource() const { return r_source; }
      void setSource(LpiFlightPlanSource::LpiEnum value) { r_source = value; }

      static std::string ToString(LpiFlightPlanSource::LpiEnum fpSource);

   private:

      LpiEnum r_source;
};


std::ostream & operator<<(std::ostream & os, const LpiFlightPlanSource & fpSource);


#endif // LRI_FLIGHTPLAN_SOURCE_H_
