#if !defined(__LRI_DConn_EVENT_DELEGATE_PUBLISHER_IMPL__)
#define __LRI_DConn_EVENT_DELEGATE_PUBLISHER_IMPL__

template<typename TEvent>
class LpiDConnEventDelegatePublisherImpl : public LpiIDConnEventDelegatePublisher<TEvent >
{
public:
	LpiDConnEventDelegatePublisherImpl() {}
   virtual ~LpiDConnEventDelegatePublisherImpl() {}

   virtual void delegatePublisher(LpiIDConnEventPublisher<TEvent> &delegate)
   {
      this->_pDelegate = &delegate;
   }

   virtual void publish(const TEvent &data)
   {
      this->_pDelegate->publish(data);
   }

private:
   LpiIDConnEventPublisher<TEvent> *_pDelegate;
};

#endif // __LRI_EVENT_DELEGATE_PUBLISHER_IMPL__
