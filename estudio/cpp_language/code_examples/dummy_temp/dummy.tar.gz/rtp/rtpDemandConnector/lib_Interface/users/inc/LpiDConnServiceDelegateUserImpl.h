#if !defined(__LRI_DConn_SERVICE_DELEGATE_USER_IMPL__)
#define __LRI_DConn_SERVICE_DELEGATE_USER_IMPL__

#include "LpiIDConnServiceUser.h"
#include "LpiIDConnDelegateUser.h"
#include <iostream>

template<typename TRequest, typename TReply>
class LpiDConnServiceDelegateUserImpl : public LpiIDConnServiceUser<TRequest, TReply>,
                                   public LpiIDConnDelegateUser<LpiIDConnServiceUser<TRequest, TReply> >
{
   public:

      LpiDConnServiceDelegateUserImpl() {}
      virtual ~LpiDConnServiceDelegateUserImpl() {}

      virtual void delegateUser(LpiIDConnServiceUser<TRequest, TReply> &user)
      {
         this->_pUser = &user;
      }

      virtual void use(const TRequest &request, TReply &reply)
      {
         this->_pUser->use(request, reply);
      }

   private:

      LpiIDConnServiceUser<TRequest, TReply>* _pUser;
};


template<typename TReply>
class LpiReplyServiceDelegateUserImpl : public LpiIReplyServiceUser<TReply>,
                                        public LpiIDConnDelegateUser<LpiIReplyServiceUser<TReply> >
{
   public:
      LpiReplyServiceDelegateUserImpl() {}
      virtual ~LpiReplyServiceDelegateUserImpl() {}

      virtual void delegateUser(LpiIReplyServiceUser<TReply> &user)
      {
         this->_pUser = &user;
      }

      virtual void use(TReply &reply)
      {
         this->_pUser->use(reply);
      }

   private:
      LpiIReplyServiceUser<TReply>* _pUser;
};
#endif // __LRI_SERVICE_DELEGATE_USER_IMPL__
