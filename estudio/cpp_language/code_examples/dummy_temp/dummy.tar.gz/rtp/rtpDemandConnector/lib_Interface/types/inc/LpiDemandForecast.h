/*
 * LpiDemandForecast.h
 *
 *  Created on: 29/04/2015
 *      Author: mbegega
 */

#ifndef LPIDEMANDFORECAST_H_
#define LPIDEMANDFORECAST_H_

#include <vector>
#include <string>
#include <iostream>
#include "LpiDConnFlightPlan.h"

class LpiDemandForecast
{
   public:

      LpiDemandForecast() : r_forecastTimeAndDate(), r_forecast()
      {}

      void reset();
      void addFPToForecast(const LpiDConnFlightPlan & fp);

      const std::vector<LpiDConnFlightPlan> & getForecast() const
      { return r_forecast; }

      void setForecastTimeAndDate(const std::string & forecastTime)
      { r_forecastTimeAndDate = forecastTime; }

      const std::string & getForecastTimeAndDate() const
      { return r_forecastTimeAndDate; }

      unsigned int sizeFP() const;
      const LpiDConnFlightPlan & operator[] (int index) const; //only for reading

   protected:

      std::string r_forecastTimeAndDate;
      std::vector<LpiDConnFlightPlan> r_forecast;
};

typedef std::vector<LpiDemandForecast> LpiDemandForecastList;

std::ostream & operator<< (std::ostream & out, const LpiDemandForecastList & forecastList);
std::ostream & operator<< (std::ostream & out, const LpiDemandForecast & forecast);


#endif /* LRIDEMANDFORECAST_H_ */
