/*
 * LpiDemandForecast.cc
 *
 *  Created on: 29/04/2015
 *      Author: mbegega
 */

#include "LpiDemandForecast.h"


unsigned int LpiDemandForecast::sizeFP() const {
	return r_forecast.size();
}

const LpiDConnFlightPlan & LpiDemandForecast::operator[](int index) const {
	return r_forecast[index];
}

void LpiDemandForecast::reset() {
	r_forecast.clear();
}

void LpiDemandForecast::addFPToForecast(const LpiDConnFlightPlan & fp) {
	r_forecast.push_back(fp);
}

std::ostream & operator<<(std::ostream & out, const LpiDemandForecastList & forecastList) {

	for (unsigned int i = 0; i < forecastList.size(); ++i) {
		out << "[TIME: " << forecastList[i].getForecastTimeAndDate()
				<< "\n| FPs:\n";

		for (unsigned int j = 0; j < forecastList[i].sizeFP(); ++j) {
			out << forecastList[i].getForecast()[j] << "\n";
		}

		out << "\n]";
	}
	return out;
}

std::ostream & operator<<(std::ostream & out, const LpiDemandForecast & forecast) {
	out << "[TIME: " << forecast.getForecastTimeAndDate() << "\n| FPs:\n";

	for (unsigned int i = 0; i < forecast.sizeFP(); ++i) {
		out << forecast[i] << "\n";
	}

	out << "\n]";

	return out;
}
