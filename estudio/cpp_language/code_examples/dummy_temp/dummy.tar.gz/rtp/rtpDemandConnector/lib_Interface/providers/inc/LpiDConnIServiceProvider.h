#if !defined(__LRI_DCONN_I_SERVICE_PROVIDER__)
#define __LRI_DCONN_I_SERVICE_PROVIDER__

template<typename TRequest, typename TReply>
class LpiDConnIServiceProvider
{
public:
   LpiDConnIServiceProvider() {}
   virtual ~LpiDConnIServiceProvider() {}
   virtual void provide(const TRequest& request, TReply &reply) = 0;
};

#endif // __LRI_I_SERVICE_PROVIDER__
