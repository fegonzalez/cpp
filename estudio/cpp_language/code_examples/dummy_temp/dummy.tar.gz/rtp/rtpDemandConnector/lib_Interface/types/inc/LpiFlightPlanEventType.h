
#ifndef LPI_FLIGHTPLAN_EVTTYPE_H_
#define LPI_FLIGHTPLAN_EVTTYPE_H_

#include <iostream>
#include <string>

class LpiFlightPlanEventType
{
   public:

      LpiFlightPlanEventType();

      enum LpiEnum
      {
         E_UNKNOWN = 0,
         E_CREATE,
         E_UPDATE,
         E_DELETE
      };

      const LpiFlightPlanEventType::LpiEnum & getType() const { return this->r_type; }
      void setType(LpiFlightPlanEventType::LpiEnum value) {this->r_type = value;}

      static std::string ToString(LpiFlightPlanEventType::LpiEnum fpEventType);

   private:

      LpiEnum r_type;
};


std::ostream & operator<<(std::ostream & os, const LpiFlightPlanEventType & fpEvent);


#endif // LRI_FLIGHTPLAN_EVTTYPE_H_
