#ifndef LRI_I_GENERATEDEMANDFORECAST_H__
#define LRI_I_GENERATEDEMANDFORECAST_H__


class LpiDemandForecast;

class LpiIGenerateDemandForecast
{
   public:

      LpiIGenerateDemandForecast() {}
      virtual ~LpiIGenerateDemandForecast() {}

      virtual void generateDemandForecast(LpiDemandForecast & forecast,
                                          int hoursWindow) = 0;
};

#endif // LRI_I_GENERATEDEMANDFORECAST_H__
