/*
 * LpiIUpdateFlightPlan.h *
 *
 * Created: 06/05/2015
 * Author: mbegega
 *
 */

#ifndef __LPI_IUPDATE_FLIGHTPLAN_H__
#define __LPI_IUPDATE_FLIGHTPLAN_H__

#include "LpiFlightPlanEventType.h"
#include "LpiDemandFlightPlan.h"


class LpiIUpdateFlightPlan
{
   public:

      virtual ~LpiIUpdateFlightPlan () {}
      virtual void updateFlightPlan (LpiFlightPlanEventType::LpiEnum operation,
                                     const LpiDemandFlightPlan & fp) = 0;

      virtual void updateFlightPlanBlock(const vector<LpiDemandFlightPlan> & fps) = 0;
};


#endif /* __LPI_IUPDATE_FLIGHTPLAN_H__ */
