#if !defined(__LRI_I_DConn_DELEGATE__)
#define __LRI_I_DConn_DELEGATE__

template<typename TDelegate>
class LpiIDConnDelegate
{
public:
   LpiIDConnDelegate() {}
   virtual ~LpiIDConnDelegate() {}
   virtual void delegate(TDelegate &data) = 0;
};

#endif // __LRI_I_DELEGATE__
