
#ifndef __LRI_INPUT_DEMAND_REQUEST_H__
#define __LRI_INPUT_DEMAND_REQUEST_H__

#include "LpiDemandForecast.h"

class LpiGetInputDemandRequest
{
   public:

      const LpiDemandForecast & getDemandForecast() const
      { return this->r_demandForecast; }

      void getRSChangeCostTable (const LpiDemandForecast & forecast)
      { this->r_demandForecast = forecast; }

   private:

      LpiDemandForecast r_demandForecast;
};


#endif /* __LRI_INPUT_DEMAND_REQUEST_H__ */
