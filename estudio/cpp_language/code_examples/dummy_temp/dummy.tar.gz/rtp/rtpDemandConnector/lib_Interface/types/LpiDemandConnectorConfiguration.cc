
#include "LpiDemandConnectorConfiguration.h"


std::ostream & operator<<(std::ostream & out, const LpiDemandConnectorConfiguration & confParams)
{
   return out << "[MODE:" << confParams.getExecutionMode()
              << "| UPDATE PERIOD (MINS): " << confParams.getMinutesUpdatePeriod()
              << "| FORECAST WINDOW (HOURS): " << confParams.getForecastHoursWindow()
              << ']';
}
