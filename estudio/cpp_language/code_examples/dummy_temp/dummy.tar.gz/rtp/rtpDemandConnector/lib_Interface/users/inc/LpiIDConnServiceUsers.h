#if !defined(__LRI_I_DCONN_SERVICE_USERS__)
#define __LRI_I_DCONN_SERVICE_USERS__

#include "LpiIDConnServiceUser.h"
#include "LpiDConnRequests.h"
#include "LpiDConnReplies.h"


typedef LpiIReplyServiceUser<
   LpiGetDemandConnectorConfigurationReply
> LpiIGetDemandConnectorConfigurationSrvUser;


typedef LpiIReplyServiceUser<
   LpiGetInputDemandReply
> LpiIGetInputDemandSrvUser;


typedef LpiIReplyServiceUser<
   LpiGetAirportInfoReply
>LpiIGetAirportInfoSrvUser;


#endif // __LRI_I_SERVICE_USERS__
