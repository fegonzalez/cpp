/*
 * LpiDemandFlightPlan.cpp
 *
 *  Created on: 23/05/2018
 *      Author: ctudela
 */

#include "LpiDemandFlightPlan.h"

#include <iostream>
#include "LctimTimeUtils.h"

// LpiDepartureTimes method implementations

LpiDepartureTimes::LpiDepartureTimes()
:  r_eobt(), r_sobt(), r_tobt(),
   r_etot(), r_ttot(), r_stot(),
   r_atot(), r_ctot(), r_aobt(),
   r_utot(), r_itot()
{
}


LpiDepartureTimes::LpiDepartureTimes(const LpiDepartureTimes& source)
:  r_eobt(source.r_eobt), r_sobt(source.r_sobt), r_tobt(source.r_tobt),
   r_etot(source.r_etot), r_ttot(source.r_ttot), r_stot(source.r_stot),
   r_atot(source.r_atot), r_ctot(source.r_ctot), r_aobt(source.r_aobt),
   r_utot(source.r_utot), r_itot(source.r_itot)
{
}


LpiDepartureTimes::LpiDepartureTimes(unsigned long eobt,
      unsigned long sobt, unsigned long tobt, unsigned long etot,
      unsigned long ttot, unsigned long stot, unsigned long atot,
      unsigned long ctot, unsigned long aobt, unsigned long utot)
:  r_eobt(eobt), r_sobt(sobt), r_tobt(tobt),
   r_etot(etot), r_ttot(ttot), r_stot(stot),
   r_atot(atot), r_ctot(ctot), r_aobt(aobt),
   r_utot(utot), r_itot()
{
}


LpiDepartureTimes& LpiDepartureTimes::operator =(const LpiDepartureTimes& source)
{
   if (this != &source)
   {
     if(source.r_eobt) { r_eobt= source.r_eobt; }
     if(source.r_sobt) { r_sobt= source.r_sobt; }
     if(source.r_tobt) { r_tobt= source.r_tobt; }
     if(source.r_etot) { r_etot= source.r_etot; }
     if(source.r_ttot) { r_ttot= source.r_ttot; }
     if(source.r_stot) { r_stot= source.r_stot; }
     if(source.r_atot) { r_atot= source.r_atot; }
     if(source.r_ctot) { r_ctot= source.r_ctot; }
     if(source.r_aobt) { r_aobt= source.r_aobt; }
     if(source.r_utot) { r_utot= source.r_utot; }
     if(source.r_itot) { r_itot= source.r_itot; }
   }
   return *this;
}


void LpiDepartureTimes::setEobt (unsigned long timestamp)
{
   r_eobt= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getEobt () const
{
   return r_eobt;
}


void LpiDepartureTimes::setSobt (unsigned long timestamp)
{
   r_sobt= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getSobt () const
{
   return r_sobt;
}

void LpiDepartureTimes::setTobt (unsigned long timestamp)
{
   r_tobt= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getTobt () const
{
   return r_tobt;
}

void LpiDepartureTimes::setEtot (unsigned long timestamp)
{
   r_etot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getEtot () const
{
   return r_etot;
}

void LpiDepartureTimes::setTtot (unsigned long timestamp)
{
   r_ttot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getTtot () const
{
   return r_ttot;
}



void LpiDepartureTimes::setStot (unsigned long timestamp)
{
   r_stot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getStot () const
{
   return r_stot;
}

void LpiDepartureTimes::setAtot (unsigned long timestamp)
{
   r_atot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getAtot () const
{
   return r_atot;
}

void LpiDepartureTimes::setCtot (unsigned long timestamp)
{
   r_ctot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getCtot () const
{
   return r_ctot;
}


void LpiDepartureTimes::setAobt (unsigned long timestamp)
{
   r_aobt= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getAobt () const
{
   return r_aobt;
}


void LpiDepartureTimes::setUtot (unsigned long timestamp)
{
   r_utot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getUtot () const
{
   return r_utot;
}


void LpiDepartureTimes::setItot (unsigned long timestamp)
{
   r_itot= timestamp;
}


const boost::optional<unsigned long> & LpiDepartureTimes::getItot () const
{
   return r_itot;
}


std::ostream& operator<< (std::ostream & out, const LpiDepartureTimes & dep)
{
   boost::optional<unsigned long> eobt = dep.getEobt();
   boost::optional<unsigned long> sobt = dep.getSobt();
   boost::optional<unsigned long> tobt = dep.getTobt();
   boost::optional<unsigned long> etot = dep.getEtot();
   boost::optional<unsigned long> ttot = dep.getTtot();
   boost::optional<unsigned long> stot = dep.getStot();
   boost::optional<unsigned long> atot = dep.getAtot();
   boost::optional<unsigned long> ctot = dep.getCtot();
   boost::optional<unsigned long> aobt = dep.getAobt();
   boost::optional<unsigned long> utot = dep.getUtot();

   boost::optional<unsigned long> itot = dep.getItot();

   out << '[';
   if (eobt) { out << "EOBT: "   << *eobt; }
   if (sobt) { out << " |SOBT: " << *sobt; }
   if (tobt) { out << " |TOBT: " << *tobt; }
   if (etot) { out << " |ETOT: " << *etot; }
   if (ttot) { out << " |TTOT: " << *ttot; }
   if (stot) { out << " |STOT: " << *stot; }
   if (atot) { out << " |ATOT: " << *atot; }
   if (ctot) { out << " |CTOT: " << *ctot; }
   if (aobt) { out << " |AOBT: " << *aobt; }
   if (utot) { out << " |UTOT: " << *utot; }
   if (itot) { out << " |ITOT: " << *itot; }
   out << ']';

   return out;
}


// LpiArrivalTimes method implementations

LpiArrivalTimes::LpiArrivalTimes()
:  r_eldt(), r_tldt(), r_aldt(),
   r_sldt(), r_sibt(), r_uldt(),
   r_ildt()
{
}


LpiArrivalTimes::LpiArrivalTimes(const LpiArrivalTimes& source)
:  r_eldt(source.r_eldt), r_tldt(source.r_tldt), r_aldt(source.r_aldt),
   r_sldt(source.r_sldt), r_sibt(source.r_sibt), r_uldt(source.r_uldt),
   r_ildt(source.r_ildt)
{
}


LpiArrivalTimes::LpiArrivalTimes(unsigned long eldt, unsigned long tldt,
                                 unsigned long aldt, unsigned long sldt,
                                 unsigned long sibt, unsigned long uldt)
:  r_eldt(eldt), r_tldt(tldt), r_aldt(aldt),
   r_sldt(sldt), r_sibt(sibt), r_uldt(uldt)
{
}


LpiArrivalTimes& LpiArrivalTimes::operator =(const LpiArrivalTimes& source)
{
   if (this != &source)
   {
      if(source.r_eldt){r_eldt= source.r_eldt;}
      if(source.r_tldt){r_tldt= source.r_tldt;}
      if(source.r_aldt){r_aldt= source.r_aldt;}
      if(source.r_sldt){r_sldt= source.r_sldt;}
      if(source.r_sibt){r_sibt= source.r_sibt;}
      if(source.r_uldt){r_uldt= source.r_uldt;}
      if(source.r_ildt){r_ildt= source.r_ildt;}
   }

   return *this;
}


void LpiArrivalTimes::setIldt (unsigned long timestamp)
{
   r_ildt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getIldt () const
{
   return r_ildt;
}


void LpiArrivalTimes::setEldt (unsigned long timestamp)
{
   r_eldt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getEldt () const
{
   return r_eldt;
}

void LpiArrivalTimes::setTldt (unsigned long timestamp)
{
   r_tldt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getTldt () const
{
   return r_tldt;
}

void LpiArrivalTimes::setAldt (unsigned long timestamp)
{
   r_aldt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getAldt () const
{
   return r_aldt;
}


void LpiArrivalTimes::setSldt (unsigned long timestamp)
{
   r_sldt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getSldt () const
{
   return r_sldt;
}


void LpiArrivalTimes::setSibt (unsigned long timestamp)
{
   r_sibt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getSibt () const
{
   return r_sibt;
}


void LpiArrivalTimes::setUldt(unsigned long timestamp)
{
   r_uldt= timestamp;
}


const boost::optional<unsigned long> & LpiArrivalTimes::getUldt() const
{
   return r_uldt;
}


std::ostream& operator<< (std::ostream & out, const LpiArrivalTimes & dep)
{
   boost::optional<unsigned long> eldt = dep.getEldt();
   boost::optional<unsigned long> tldt = dep.getTldt();
   boost::optional<unsigned long> aldt = dep.getAldt();
   boost::optional<unsigned long> sldt = dep.getSldt();
   boost::optional<unsigned long> sibt = dep.getSibt();
   boost::optional<unsigned long> uldt = dep.getUldt();

   boost::optional<unsigned long> ildt = dep.getIldt();

   out << '[';
   if (eldt) { out << "ELDT: "   << *eldt; }
   if (tldt) { out << " |TLDT: " << *tldt; }
   if (aldt) { out << " |ALDT: " << *aldt; }
   if (sldt) { out << " |SLDT: " << *sldt; }
   if (sibt) { out << " |SIBT: " << *sibt; }
   if (uldt) { out << " |ULDT: " << *uldt; }
   if (ildt) { out << " |ILDT: " << *ildt; }
   out << ']';

   return out;
}


//LpiDemandFlightPlan method implementations

LpiDemandFlightPlan::LpiDemandFlightPlan()
:  r_callsign(""),
   r_departure_aerodrome(""),
   r_arrival_aerodrome(""),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_departure_times(),
   r_arrival_times(),
   r_source(LpiFlightPlanSource::E_UNKNOWN)
{
}


LpiDemandFlightPlan::LpiDemandFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome)
:  r_callsign(callsign),
   r_departure_aerodrome(dep_aerodrome),
   r_arrival_aerodrome(arr_aerodrome),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_departure_times(),
   r_arrival_times(),
   r_source(LpiFlightPlanSource::E_UNKNOWN)
{
}


LpiDemandFlightPlan::LpiDemandFlightPlan(const LpiDemandFlightPlan& source)
:  r_callsign(source.r_callsign),
   r_departure_aerodrome(source.r_departure_aerodrome),
   r_arrival_aerodrome(source.r_arrival_aerodrome),
   r_aircraft_type(source.r_aircraft_type),
   r_registration(source.r_registration),
   r_wtc(source.r_wtc),
   r_sid(source.r_sid),
   r_star(source.r_star),
   r_departure_times(source.r_departure_times),
   r_arrival_times(source.r_arrival_times),
   r_source(source.r_source)
{
}


LpiDemandFlightPlan& LpiDemandFlightPlan::operator =(const LpiDemandFlightPlan& source)
{
   if (this != &source)
   {
      r_callsign = source.r_callsign;
      r_departure_aerodrome = source.r_departure_aerodrome;
      r_arrival_aerodrome = source.r_arrival_aerodrome;
      r_aircraft_type = source.r_aircraft_type;
      r_registration = source.r_registration;
      r_wtc = source.r_wtc;
      r_sid = source.r_sid;
      r_star = source.r_star;
      r_departure_times = source.r_departure_times;
      r_arrival_times = source.r_arrival_times;
      r_source = source.r_source;
   }

   return *this;
}


string LpiDemandFlightPlan::getAircraftType() const
{
   return r_aircraft_type;
}

void LpiDemandFlightPlan::setAircraftType(string aircraftType)
{
   r_aircraft_type = aircraftType;
}


string LpiDemandFlightPlan::getArrivalAerodrome() const
{
   return r_arrival_aerodrome;
}


void LpiDemandFlightPlan::setArrivalAerodrome(string arrivalAerodrome)
{
   r_arrival_aerodrome = arrivalAerodrome;
}


LpiArrivalTimes LpiDemandFlightPlan::getArrivalTimes() const
{
   return r_arrival_times;
}


void LpiDemandFlightPlan::setArrivalTimes(LpiArrivalTimes arrivalTimes)
{
   r_arrival_times = arrivalTimes;
}

string LpiDemandFlightPlan::getCallsign() const
{
   return r_callsign;
}


void LpiDemandFlightPlan::setCallsign(string callsign)
{
   r_callsign = callsign;
}


string LpiDemandFlightPlan::getDepartureAerodrome() const
{
   return r_departure_aerodrome;
}


void LpiDemandFlightPlan::setDepartureAerodrome(string departureAerodrome)
{
   r_departure_aerodrome = departureAerodrome;
}


LpiDepartureTimes LpiDemandFlightPlan::getDepartureTimes() const
{
   return r_departure_times;
}


void LpiDemandFlightPlan::setDepartureTimes(LpiDepartureTimes departureTimes)
{
   r_departure_times = departureTimes;
}


string LpiDemandFlightPlan::getRegistration() const
{
   return r_registration;
}


void LpiDemandFlightPlan::setRegistration(string registration)
{
   r_registration = registration;
}


string LpiDemandFlightPlan::getWtc() const
{
   return r_wtc;
}


void LpiDemandFlightPlan::setWtc(string wtc) {
   r_wtc = wtc;
}


string LpiDemandFlightPlan::getSID() const
{
   return r_sid;
}


void LpiDemandFlightPlan::setSID(string sid)
{
   r_sid = sid;
}


string LpiDemandFlightPlan::getSTAR() const
{
   return r_star;
}


void LpiDemandFlightPlan::setSTAR(string star)
{
   r_star = star;
}

string LpiDemandFlightPlan::getVFR() const
{
   return r_vfr;
}


void LpiDemandFlightPlan::setVFR(string vfr)
{
   r_vfr = vfr;
}


string LpiDemandFlightPlan::getUniqueKey() const
{
   return r_callsign + " " + r_departure_aerodrome + " " + r_arrival_aerodrome;
}


const LpiFlightPlanSource::LpiEnum & LpiDemandFlightPlan::getSource() const
{
   return r_source;
}


void LpiDemandFlightPlan::setSource(const LpiFlightPlanSource::LpiEnum & source)
{
   r_source = source;
}


std::ostream& operator<< (std::ostream & out, const LpiDemandFlightPlan & fp)
{
   std::stringstream out_stream;

   if (fp.getAircraftType().size() > 0)
   {
      out_stream << " |AT: " << fp.getAircraftType();
   }

   if (fp.getWtc().size() > 0)
   {
      out_stream << " |WTC: " << fp.getWtc();
   }

   if (fp.getRegistration().size() > 0)
   {
      out_stream << " |REG: " << fp.getRegistration();
   }

   if (fp.getSID().size() > 0)
   {
      out_stream << " |SID: " << fp.getSID();
   }
   else if (fp.getSTAR().size() > 0)
   {
      out_stream << " |STAR: " << fp.getSTAR();
   }

   out_stream << " |VFR: " << fp.getVFR();

   out << "[CSGN: " << fp.getCallsign()
       << " |DEP: " << fp.getDepartureAerodrome()
       << " |ARR: " << fp.getArrivalAerodrome()
       << " |DEP_TIMES: " << fp.getDepartureTimes()
       << " |ARR_TIMES: " << fp.getArrivalTimes()
       << out_stream.str();
   out << "|SOURCE: " << LpiFlightPlanSource::ToString(fp.getSource());
   out << ']';

   return out;
}

