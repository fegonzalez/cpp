/*
 * LpiIGetAirportInfo.h
 *
*/

#ifndef LRIIGETAIRPORTINFO_H_
#define LRIIGETAIRPORTINFO_H_

#include "LpiDConnResult.h"

class LpiIGetAirportInfo
{
   public:

      virtual ~LpiIGetAirportInfo() {}
      virtual void getAirportInfo(std::string & airportName,
    		  LpiDConnResult & result) = 0;
};


#endif /* LRIIGETAIRPORTINFO_H_ */
