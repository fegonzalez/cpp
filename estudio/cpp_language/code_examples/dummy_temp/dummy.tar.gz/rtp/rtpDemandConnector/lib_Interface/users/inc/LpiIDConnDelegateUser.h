#if !defined(__LRI_I_DCONN_DELEGATE_USER__)
#define __LRI_I_DCONN_DELEGATE_USER__

template<typename TDelegate>
class LpiIDConnDelegateUser
{
   public:

	LpiIDConnDelegateUser() {}
      virtual ~LpiIDConnDelegateUser() {}
      virtual void delegateUser(TDelegate &data) = 0;
};

#endif // __LRI_I_DELEGATE_USER__
