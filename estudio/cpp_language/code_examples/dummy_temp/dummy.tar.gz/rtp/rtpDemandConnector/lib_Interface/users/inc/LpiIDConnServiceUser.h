#if !defined(__LRI_I_DCONN_SERVICE_USER__)
#define __LRI_I_DCONN_SERVICE_USER__

#include <iostream>

template<typename TRequest, typename TReply>
class LpiIDConnServiceUser
{
   public:
	LpiIDConnServiceUser() { }
      virtual ~LpiIDConnServiceUser() {}

      virtual void use(const TRequest& request, TReply &reply) = 0;
};


template<typename TReply>
class LpiIReplyServiceUser
{
   public:
      LpiIReplyServiceUser() { }
      virtual ~LpiIReplyServiceUser() {}

      virtual void use(TReply &reply) = 0;
};


#endif // __LRI_I_SERVICE_USER__
