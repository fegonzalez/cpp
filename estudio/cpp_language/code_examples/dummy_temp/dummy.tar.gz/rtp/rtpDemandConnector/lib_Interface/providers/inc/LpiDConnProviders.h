#if !defined(__LRI_DCONN_PROVIDERS__)
#define __LRI_DCONN_PROVIDERS__

#include "LpiIServiceProviders.h"

#endif // __LRI_PROVIDERS__
