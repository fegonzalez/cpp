/*
 * LpiIExternalEvtConsumer.h
 *
 *  Created on: 23/09/2015
 *      Author: mbegega
 */

#ifndef LRI_I_EXTERNAL_EVT_LISTENER_H__
#define LRI_I_EXTERNAL_EVT_LISTENER_H__

#include <string>
using std::string;

class LpiIExternalEvtListener
{
   public:

      LpiIExternalEvtListener() {}
      virtual ~LpiIExternalEvtListener() {}

      virtual void on_data_available(string & data) = 0;
};

#endif // LRI_I_EXTERNAL_EVT_LISTENER_H__
