/*
 * LpiIFlightPlanLifeCycle.h
 *
 *  Created on: 05/05/2015
 *      Author: mbegega
 */


#include "LpiDemandFlightPlan.h"

#ifndef LPI_I_FPLIFE_CYCLE_H__
#define LPI_I_FPLIFE_CYCLE_H__

class LpiIFlightPlanLifeCycle
{
   public:

      LpiIFlightPlanLifeCycle() {}
      virtual ~LpiIFlightPlanLifeCycle() {}

      virtual void createFP(const LpiDemandFlightPlan & fp) = 0;
      virtual void updateFP(const LpiDemandFlightPlan & fp) = 0;
      virtual void eraseFP (const LpiDemandFlightPlan & fp) = 0;
};

#endif // LRI_I_FPLIFE_CYCLE_H__
