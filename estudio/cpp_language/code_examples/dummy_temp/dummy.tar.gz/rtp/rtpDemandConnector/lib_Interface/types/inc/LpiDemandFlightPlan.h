/*
 * LpiDemandFlightPlan.h
 *
 *  Created on: 23/05/2018
 *      Author: ctudela
 */

#ifndef LPIDEMANDNFLIGHTPLAN_H_
#define LPIDEMANDNFLIGHTPLAN_H_


#include <iostream>
#include <string>
#include <vector>

#include <boost/optional/optional.hpp>
#include <boost/foreach.hpp>

#include "LpiFlightPlanSource.h"

using std::string;
using std::vector;


class LpiDepartureTimes
{
   public:

      LpiDepartureTimes ();
      LpiDepartureTimes(unsigned long eobt, unsigned long sobt,
                        unsigned long tobt, unsigned long etot,
                        unsigned long ttot, unsigned long stot,
                        unsigned long atot, unsigned long ctot,
                        unsigned long aobt, unsigned long utot);

      LpiDepartureTimes (const LpiDepartureTimes & source);
      virtual ~LpiDepartureTimes () {}

      LpiDepartureTimes & operator= (const LpiDepartureTimes & source);

      void setEobt (unsigned long timestamp);
      const boost::optional<unsigned long> & getEobt () const;

      void setSobt (unsigned long timestamp);
      const boost::optional<unsigned long> & getSobt () const;

      void setTobt (unsigned long timestamp);
      const boost::optional<unsigned long> & getTobt () const;

      void setEtot (unsigned long timestamp);
      const boost::optional<unsigned long> & getEtot () const;

      void setTtot (unsigned long timestamp);
      const boost::optional<unsigned long> & getTtot () const;

      void setStot (unsigned long timestamp);
      const boost::optional<unsigned long> & getStot () const;

      void setAtot (unsigned long timestamp);
      const boost::optional<unsigned long> & getAtot () const;

      void setCtot (unsigned long timestamp);
      const boost::optional<unsigned long> & getCtot () const;

      void setAobt (unsigned long timestamp);
      const boost::optional<unsigned long> & getAobt() const;

      void setUtot (unsigned long timestamp);
      const boost::optional<unsigned long> & getUtot() const;

      void setItot (unsigned long timestamp);
      const boost::optional<unsigned long> & getItot () const;

      bool isInWindow(unsigned long windowStart, unsigned long windowEnd) const;

   protected:

      //Off-Block Times
      boost::optional<unsigned long> r_eobt;
      boost::optional<unsigned long> r_sobt;
      boost::optional<unsigned long> r_tobt;

      //Take-Off Times
      boost::optional<unsigned long> r_etot;
      boost::optional<unsigned long> r_ttot;
      boost::optional<unsigned long> r_stot;
      boost::optional<unsigned long> r_atot;
      boost::optional<unsigned long> r_ctot;

      //NOVA specific times
      boost::optional<unsigned long> r_aobt;

      //User assigned take-off time
      boost::optional<unsigned long> r_utot;

      //Intentional Time
      boost::optional<unsigned long> r_itot; //set to null invoking ".reset()"
};

std::ostream& operator<< (std::ostream & out, const LpiDepartureTimes & dep);


class LpiArrivalTimes
{
   public:

      LpiArrivalTimes ();
      LpiArrivalTimes(unsigned long eldt, unsigned long tldt,
                      unsigned long aldt, unsigned long sldt,
                      unsigned long sibt, unsigned long uldt);
      LpiArrivalTimes(const LpiArrivalTimes& source);
      virtual ~LpiArrivalTimes (){}

      LpiArrivalTimes & operator= (const LpiArrivalTimes & source);

      void setIldt (unsigned long timestamp);
      const boost::optional<unsigned long> & getIldt () const;
      void setEldt (unsigned long timestamp);
      const boost::optional<unsigned long> & getEldt () const;
      void setTldt (unsigned long timestamp);
      const boost::optional<unsigned long> & getTldt () const;
      void setAldt (unsigned long timestamp);
      const boost::optional<unsigned long> & getAldt () const;
      void setSldt (unsigned long timestamp);
      const boost::optional<unsigned long> & getSldt () const;
      void setSibt (unsigned long timestamp);
      const boost::optional<unsigned long> & getSibt() const;
      void setUldt (unsigned long timestamp);
      const boost::optional<unsigned long> & getUldt() const;

      bool isInWindow(unsigned long windowStart, unsigned long windowEnd) const;

   protected:

      //Landing Times
      boost::optional<unsigned long> r_eldt;
      boost::optional<unsigned long> r_tldt;
      boost::optional<unsigned long> r_aldt;
      boost::optional<unsigned long> r_sldt;

      //In-Block Times
      boost::optional<unsigned long> r_sibt;

      //User assigned landing time
      boost::optional<unsigned long> r_uldt;

      //Intentional Time
      boost::optional<unsigned long> r_ildt; //set to null invoking ".reset()"
};


std::ostream& operator<< (std::ostream & out, const LpiArrivalTimes & arr);


class LpiDemandFlightPlan
{
   public:

	  LpiDemandFlightPlan ();
	  LpiDemandFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome);
	  LpiDemandFlightPlan (const LpiDemandFlightPlan & source);

      virtual ~LpiDemandFlightPlan () {}

      LpiDemandFlightPlan & operator= (const LpiDemandFlightPlan & source);

      //Getters and Setters
      string getCallsign() const;
      void setCallsign(string callsign);

      string getDepartureAerodrome() const;
      void setDepartureAerodrome(string departureAerodrome);

      string getArrivalAerodrome() const;
      void setArrivalAerodrome(string arrivalAerodrome);

      string getAircraftType() const;
      void setAircraftType(string aircraftType);

      string getRegistration() const;
      void setRegistration(string registration);

      string getWtc() const;
      void setWtc(string wtc);

      string getSID() const;
      void setSID(string sid);

      string getSTAR() const;
      void setSTAR(string star);

      string getVFR() const;
      void setVFR(string vfr);

      LpiDepartureTimes getDepartureTimes() const;
      void setDepartureTimes(LpiDepartureTimes departureTimes);

      LpiArrivalTimes getArrivalTimes() const;
      void setArrivalTimes(LpiArrivalTimes arrivalTimes);

      const LpiFlightPlanSource::LpiEnum & getSource() const;
      void setSource(const LpiFlightPlanSource::LpiEnum & source);


      //Returns an unique identification, for example, for DB storing
      //Key used: "callsign departure arrival"
      string getUniqueKey() const;


   protected:

      string             r_callsign;
      string             r_departure_aerodrome;
      string             r_arrival_aerodrome;
      string             r_aircraft_type;
      string             r_registration;
      string             r_wtc;    // "Light, Medium, Heavy"
      string             r_sid;
      string             r_star;
      string             r_vfr;


      LpiDepartureTimes r_departure_times;
      LpiArrivalTimes   r_arrival_times;

      LpiFlightPlanSource::LpiEnum r_source;
};


std::ostream& operator<< (std::ostream & out, const LpiDemandFlightPlan & fp);


#endif /* LRIDEMANDFLIGHTPLAN_H_ */
