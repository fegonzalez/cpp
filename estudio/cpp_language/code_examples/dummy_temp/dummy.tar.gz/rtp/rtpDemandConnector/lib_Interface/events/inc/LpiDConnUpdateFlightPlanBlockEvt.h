#ifndef LPIDConnUPDATEFLIGHTPLANBLOCKEVT_H_
#define LPIDConnUPDATEFLIGHTPLANBLOCKEVT_H_

#include <vector>
#include "LpiDemandFlightPlan.h"

using std::vector;


class LpiDConnUpdateFlightPlanBlockEvt
{
   public:

      const vector<LpiDemandFlightPlan> & getFlightPlanBlock() const
      { return r_flightPlanBlock; }

      void setFlightPlanBlock(const vector<LpiDemandFlightPlan> & fps)
      { r_flightPlanBlock = fps; }

   private:

      vector<LpiDemandFlightPlan> r_flightPlanBlock;
};

#endif // LPIDConnUPDATEFLIGHTPLANBLOCKEVT_H_
