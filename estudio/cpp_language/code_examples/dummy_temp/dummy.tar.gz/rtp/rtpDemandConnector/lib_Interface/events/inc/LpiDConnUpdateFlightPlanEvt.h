#ifndef LPIDConnUPDATEFLIGHTPLANEVT_H_
#define LPIDConnUPDATEFLIGHTPLANEVT_H_

#include "LpiFlightPlanEventType.h"
#include "LpiDemandFlightPlan.h"

class LpiDConnUpdateFlightPlanEvt
{
   public:

	  LpiDemandFlightPlan getFlightPlan () const
      { return r_flightPlan; }

      void setFlightPlan(const LpiDemandFlightPlan & fp)
      { r_flightPlan = fp; }

      void setEventType(const LpiFlightPlanEventType & eventType)
      { r_eventType = eventType; }

      const LpiFlightPlanEventType & getEventType() const
      { return r_eventType; }

   private:

      LpiFlightPlanEventType r_eventType;
      LpiDemandFlightPlan     r_flightPlan;
};

#endif // LPIDConnUPDATEFLIGHTPLANEVT_H_
