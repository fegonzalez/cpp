#if !defined(__LRI_I_DCONN_OBSERVER_H__)
#define __LRI_I_DCONN_OBSERVER_H__

class LpiIDConnObserver
{
public:
   LpiIDConnObserver() {}
   virtual ~LpiIDConnObserver() {}

   virtual void notify() = 0;
};

#endif // __LRI_I_OBSERVER_H__
