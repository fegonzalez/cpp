
#ifndef LRIGETAIRPORTINFOREPLY_H_
#define LRIGETAIRPORTINFOREPLY_H_

#include <string>
#include <LpiDConnResult.h>


class LpiGetAirportInfoReply
{
   public:

      const std::string & getAirportName() const
      { return r_airportName; }

      const LpiDConnResult::LpiEnum & getResult() const
      { return r_result; }

      void setAirportName(const std::string & name)
      { r_airportName = name; }

      void setResult(const LpiDConnResult::LpiEnum & result)
      { r_result = result; }

   private:

      std::string        r_airportName;
      LpiDConnResult::LpiEnum r_result;
};


#endif /* LRIGETAIRPORTINFOREPLY_H_ */
