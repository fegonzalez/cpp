#if !defined(__LRI_DConn_EVENT_DELEGATE_PUBLISHERS__)
#define __LRI_DConn_EVENT_DELEGATE_PUBLISHERS__

#include "LpiIDConnEventDelegatePublisher.h"
#include "LpiDConnEvents.h"


typedef LpiIDConnEventDelegatePublisher<
   LpiDConnUpdateDemandForecastEvt
> LpiIDConnUpdateDemandForecastEvtDelegatePublisher;


#endif // __LRI_EVENT_DELEGATE_PUBLISHERS__
