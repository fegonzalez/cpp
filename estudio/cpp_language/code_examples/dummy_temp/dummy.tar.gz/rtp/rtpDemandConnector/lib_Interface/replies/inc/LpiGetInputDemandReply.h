
#ifndef __LPI_INPUT_DEMAND_REPLY_H__
#define __LPI_INPUT_DEMAND_REPLY_H__

#include "LpiCreateDemandForecast.h"
#include "LpiDConnResult.h"


class LpiGetInputDemandReply
{
   public:

      const LpiCreateDemandForecastList & getDemandForecastList() const
      { return r_demandForecastList; }

      void setDemandForecastList (const LpiCreateDemandForecastList & forecast)
      { r_demandForecastList = forecast;}

      const LpiDConnResult::LpiEnum & getResult () const
      { return r_result; }

      void setResult(const LpiDConnResult::LpiEnum & result)
      { r_result = result; }

   private:

      LpiCreateDemandForecastList  r_demandForecastList;
      LpiDConnResult::LpiEnum r_result;
};


#endif /* __LPI_INPUT_DEMAND_REPLY_H__ */
