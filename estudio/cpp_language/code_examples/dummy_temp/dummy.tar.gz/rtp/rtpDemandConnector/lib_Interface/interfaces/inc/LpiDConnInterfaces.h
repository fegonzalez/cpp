#if !defined(__LRI_DConn_INTERFACES__)
#define __LRI_DConn_INTERFACES__

#include "LpiIDConnLifeCycle.h"
#include "LpiIGetDemandConnectorConfiguration.h"
#include "LpiIGetInputDemand.h"
#include "LpiIPublishDemandForecast.h"
#include "LpiIFlightPlanLifeCycle.h"
#include "LpiIUpdateFlightPlan.h"
#include "LpiIGenerateDemandForecast.h"
#include "LpiIDConnObserver.h"
#include "LpiIGetAirportInfo.h"

#endif // __LRI_INTERFACES__
