#if !defined(__LRI_DConn_EVENT_PUBLISHER__)
#define __LRI_DConn_EVENT_PUBLISHER__

template<typename TEvent>
class LpiIDConnEventPublisher
{
public:
   LpiIDConnEventPublisher() {}
   virtual ~LpiIDConnEventPublisher() {}
   virtual void publish(const TEvent &data) = 0;
};

#endif // __LRI_EVENT_PUBLISHER__
