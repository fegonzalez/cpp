#if !defined(__LRI_I_DCONN_SERVICE_DELEGATE_USER__)
#define __LRI_I_DCONN_SERVICE_DELEGATE_USER__

#include "LpiIDConnServiceUser.h"
#include "LpiIDConnDelegateUser.h"

template<typename TRequest, typename TReply>
class LpiIDConnServiceDelegateUser : public LpiIDConnServiceUser<TRequest, TReply>,
                                public LpiIDConnDelegateUser<LpiIDConnServiceUser<TRequest, TReply> >
{
   public:
	LpiIDConnServiceDelegateUser() {}
      virtual ~LpiIDConnServiceDelegateUser() {}
      virtual void delegateUser(LpiIDConnServiceUser<TRequest, TReply> &data) = 0;
      virtual void use(const TRequest& request, TReply &reply) = 0;
};


template<typename TReply>
class LpiIReplyServiceDelegateUser : public LpiIReplyServiceUser<TReply>,
                                     public LpiIDConnDelegateUser<LpiIReplyServiceUser<TReply> >
{
   public:
      LpiIReplyServiceDelegateUser() {}
      virtual ~LpiIReplyServiceDelegateUser() {}
      virtual void delegateUser(LpiIReplyServiceUser<TReply> &data) = 0;
      virtual void use(TReply &reply) = 0;
};


#endif // __LRI_I_SERVICE_DELEGATE_USER__
