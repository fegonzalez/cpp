
#ifndef LPIDEMANDCONNECTORCONFIGURATION_H_
#define LPIDEMANDCONNECTORCONFIGURATION_H_

#include <vector>
#include <iostream>

#include "LpiExecutionMode.h"

class LpiDemandConnectorConfiguration
{
   public:

      LpiDemandConnectorConfiguration(){}

      LpiDemandConnectorConfiguration(int minutes, LpiExecutionMode::LpiEnum mode, int hoursWindow)
      : r_minutesUpdatePeriod(minutes), r_mode(mode), r_forecastHoursWindow(hoursWindow)
      {}

      int getMinutesUpdatePeriod() const
      { return r_minutesUpdatePeriod; }

      LpiExecutionMode::LpiEnum getExecutionMode() const
      { return r_mode; }

      int getForecastHoursWindow() const
      { return r_forecastHoursWindow; }

      void setMinutesUpdatePeriod(int minutes)
      { r_minutesUpdatePeriod = minutes; }

      void setExecutionMode(LpiExecutionMode::LpiEnum mode)
      { r_mode = mode; }

      void setForecastHoursWindow(int hoursWindow)
      { r_forecastHoursWindow = hoursWindow; }

   private:

      int r_minutesUpdatePeriod;

      LpiExecutionMode::LpiEnum r_mode;

      int r_forecastHoursWindow;
};


std::ostream & operator<<(std::ostream & out,
                          const LpiDemandConnectorConfiguration & confParams);


#endif /* LRICONFIGURATIONPARAMETERS_H_ */
