/*
 * LpiIGetInputDemand.h *
 */

#ifndef __LPI_IGET_INPUTDEMAND_H__
#define __LPI_IGET_INPUTDEMAND_H__

#include "LpiCreateDemandForecast.h"
#include "LpiDConnResult.h"

class LpiIGetInputDemand
{
   public:

      virtual ~LpiIGetInputDemand () {}
      virtual void getInputDemand (LpiCreateDemandForecastList & demand,
    		  LpiDConnResult        & result) = 0;
};


#endif /* __LPI_IGET_INPUTDEMAND_H__ */
