/*
 * LpiCreateDemandForecast.h
 *
 *  Created on: 23/05/2018
 *      Author: ctudela
 */

#ifndef LPICREATEDEMANDFORECAST_H_
#define LPICREATEDEMANDFORECAST_H_

#include <vector>
#include <string>
#include <iostream>

#include "LpiDemandFlightPlan.h"

class LpiCreateDemandForecast {
public:

	LpiCreateDemandForecast() {}

	const std::vector<LpiDemandFlightPlan> & getForecast() const {
		return r_forecast;
	}

	void setNameAirport(const std::string & nameAirport) {
		r_nameAirport = nameAirport;
	}
	const std::string & getNameAirport() const {
		return r_nameAirport;
	}

	void setDemandStartTimeAndDate(const std::string & startTime) {
		r_demandStartTimeAndDate = startTime;
	}
	const std::string & getDemandStartTimeAndDate() const {
		return r_demandStartTimeAndDate;
	}

	void setDemandEndTimeAndDate(const std::string & endTime) {
		r_demandEndTimeAndDate = endTime;
	}
	const std::string & getDemandEndTimeAndDate() const {
		return r_demandEndTimeAndDate;
	}

	void reset();
	void addFPToForecast(const LpiDemandFlightPlan & fp);

	unsigned int sizeFP() const;
	const LpiDemandFlightPlan & operator[](int index) const; //only for reading

protected:

	std::string r_nameAirport;
	std::string r_demandStartTimeAndDate;
	std::string r_demandEndTimeAndDate;
	std::vector<LpiDemandFlightPlan> r_forecast;
};


typedef std::vector<LpiCreateDemandForecast> LpiCreateDemandForecastList;


std::ostream & operator<<(std::ostream & out, const LpiCreateDemandForecast & forecast);

std::ostream & operator<<(std::ostream & out, const LpiCreateDemandForecastList & forecastList);

#endif /* LPIDEMANDFORECAST_H_ */
