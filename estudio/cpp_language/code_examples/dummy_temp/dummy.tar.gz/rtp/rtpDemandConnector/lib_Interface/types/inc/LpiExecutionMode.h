
#ifndef LPIEXECUTIONMODE_H_
#define LPIEXECUTIONMODE_H_

#include <iostream>

class LpiExecutionMode
{
   public:

      enum LpiEnum
      {
         E_UNKNOWN = 0,
         E_DUMMY,
         E_CONNECTOR
   };
};


std::ostream & operator<<(std::ostream & out,
                          const LpiExecutionMode::LpiEnum & executionMode);


#endif /* LRIEXECUTIONMODE_H_ */
