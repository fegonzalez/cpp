/*
 * LpiCreateDemandForecast.cc
 *
 *  Created on: 23/05/2018
 *      Author: ctudela
 */

#include "LpiCreateDemandForecast.h"

void LpiCreateDemandForecast::reset() {
	r_forecast.clear();
}

void LpiCreateDemandForecast::addFPToForecast(const LpiDemandFlightPlan & fp) {
	r_forecast.push_back(fp);
}

unsigned int LpiCreateDemandForecast::sizeFP() const {
	return r_forecast.size();
}

const LpiDemandFlightPlan & LpiCreateDemandForecast::operator[](int index) const {
	return r_forecast[index];
}

std::ostream & operator<<(std::ostream & out, const LpiCreateDemandForecast & forecast) {
	out << "[AIRPORT: " << forecast.getNameAirport()
					<< "| START_TIME: " << forecast.getDemandStartTimeAndDate()
					<< "| END_TIME: " << forecast.getDemandEndTimeAndDate()
					<< "\n| FPs:\n";

	for (unsigned int i = 0; i < forecast.sizeFP(); ++i) {
		out << forecast[i] << "\n";
	}

	out << "\n]";

	return out;
}


std::ostream & operator<<(std::ostream & out, const LpiCreateDemandForecastList & forecastList) {

	for (unsigned int i = 0; i < forecastList.size(); ++i) {
		out << "[AIRPORT: " << forecastList[i].getNameAirport()
				<< "| START_TIME: " << forecastList[i].getDemandStartTimeAndDate()
				<< "| END_TIME: " << forecastList[i].getDemandEndTimeAndDate()
				<< "\n| FPs:\n";

		for (unsigned int j = 0; j < forecastList[i].sizeFP(); ++j) {
			out << forecastList[i].getForecast()[j] << "\n";
		}

		out << "\n]";
	}
	return out;
}

