#if !defined(__LRI_I_DCONN_LIFE_CYCLE_H__)
#define __LRI_I_DCONN_LIFE_CYCLE_H__

class LpiIDConnLifeCycle
{
   public:

	LpiIDConnLifeCycle() {}
      virtual ~LpiIDConnLifeCycle() {}

      virtual void create() = 0;
      virtual void initialise() = 0;
      virtual void complete() = 0;
};

#endif // __LRI_I_LIFE_CYCLE_H__
