
#include "LpiDConnResult.h"


LpiDConnResult::LpiDConnResult(): _result(E_NONE)
{}


std::ostream & operator<<(std::ostream & os, const LpiDConnResult & result)
{
   os << "Result: " <<result.getResult();
   return os;
}

