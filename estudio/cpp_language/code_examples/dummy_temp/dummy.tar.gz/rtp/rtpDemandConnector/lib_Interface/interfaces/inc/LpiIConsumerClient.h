/*
 * LpiIConsumerClient.h
 *
 *  Created on: 24/09/2015
 *      Author: mbegega
 */


#ifndef LRI_I_CONSUMER_CLIENT_H__
#define LRI_I_CONSUMER_CLIENT_H__

#include <string>
using std::string;

class LpiIConsumerClient
{
   public:

      LpiIConsumerClient() {}
      virtual ~LpiIConsumerClient() {}

      virtual void start() = 0;
      virtual void receive() = 0;
      virtual void stop() = 0;
};

#endif // LRI_I_CONSUMER_CLIENT_H__
