/*
 * LpnInputDemand.h
 *
 */

#ifndef __LPNINPUTDEMAND_H__
#define __LPNINPUTDEMAND_H__

#include <daortp_demandconnectorinput_xsd.h>
#include <LpiCreateDemandForecast.h>

class LpnInputDemand
{
   public:

       static void Convert2DemandForecast (const DemandConnectorInput::FlightPlansElement & flightPlanList,
    		   	   	   	   	   	   	   	   LpiCreateDemandForecast & output);

   private:

       static void Convert2DepartureTimes (const DemandConnectorInput::DepartureInfo & departureInfo,
                                           LpiDepartureTimes & output);

       static void Convert2ArrivalTimes (const DemandConnectorInput::ArrivalInfo & arrivalInfo,
                                         LpiArrivalTimes & output);

       static unsigned long ToSeconds(unsigned long microseconds);

       static const unsigned long E_USEC_PER_SEC = 1 / 1000000;
};


#endif /* __LRNINPUTDEMAND_H__ */
