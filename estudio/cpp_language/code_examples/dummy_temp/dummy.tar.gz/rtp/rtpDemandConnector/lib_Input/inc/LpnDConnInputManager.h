/*
 * LpnInputManager.h
 *
 * Manages input data files received from command line
 *
 */

#ifndef LRNDCONNINPUTMANAGER_H_
#define LRNCONNINPUTMANAGER_H_

#include <iostream>
#include <dirent.h>

#include <boost/shared_ptr.hpp>
#include <boost/property_tree/exceptions.hpp>

#include <LpnGetInputDemandServiceUser.h>


class LpndDConnInputManager
{
   public:

      static LpndDConnInputManager & Get(void)
      {
         static LpndDConnInputManager manager;
         return manager;
      }

      void initialise(const std::string & fileName)
      {
    	  if(contains(fileName, ".xml")) //if fileName is a demand XML file
    	  {
    		  try
    		  {
    			  r_getInputDemandServiceUser->init(fileName);
    		  }
    		  catch(std::exception& ex)
    		  {
    			  std::cerr << "[ERROR]: Please, check the adaptation file "
    					  	  << fileName << std::endl;
    			  std::cerr << "[ERROR]: " << ex.what() << std::endl;
    			  exit(EXIT_FAILURE);
    		  }
    	  }
    	  else //if fileName is a directory that contains demand XML files
    	  {
    		  std::string dir = fileName;
    		  std::cerr << "Lee todos los archivos del directorio: " << dir<< std::endl;
    		  try {
    			  DIR *directorio;
    			  struct dirent *elemento;
    			  std::string elem;

    			  directorio = opendir(dir.c_str());
    			  if (directorio)
    			  {
    				  elemento = readdir(directorio);
    				  while (elemento)
    				  {
						elem = elemento->d_name;
						if (contains(elem, "xml"))
						{
							std::cerr << dir << elem << std::endl;
							r_getInputDemandServiceUser->init(dir + elem);
						}
						elemento = readdir(directorio);
    				  }
    			  }
    			  closedir(directorio);
    		  } catch (std::exception& ex) {
    			  std::cerr << "[ERROR]: Please, check the directory "
    					  << fileName << " and its files" << std::endl;
    			  std::cerr << "[ERROR]: " << ex.what() << std::endl;
    			  exit(EXIT_FAILURE);
    		  }
    	  }

         /*		RMAN:

         try
         {
            r_getInputDemandServiceUser->init(fileName);
         }
         catch(std::exception& ex)
         {
            std::cerr << "[ERROR]: Please, check input file "
                  << fileName << std::endl;
            std::cerr << "[ERROR]: " << ex.what() << std::endl;
            exit(EXIT_FAILURE);
         }*/
      }

   private:

      bool contains(std::string elem, std::string str){
    	  std::size_t found = elem.find(str);
    	  if (found != std::string::npos) {
    		  return true;
    	  }
    	  return false;
      }

      LpndDConnInputManager ():
      r_getInputDemandServiceUser(new LpnGetInputDemandServiceUser())
      {}

      boost::shared_ptr<LpnGetInputDemandServiceUser>
                                         r_getInputDemandServiceUser;
};


#endif /* LRNINPUTMANAGER_H_ */
