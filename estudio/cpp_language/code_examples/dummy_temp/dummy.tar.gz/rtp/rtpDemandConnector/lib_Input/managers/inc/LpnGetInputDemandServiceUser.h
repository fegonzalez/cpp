/*
 * LpnGetInputDemandServiceUser.h
 *
 */

#ifndef __LPN_GET_INPUT_DEMAND_SERVICEUSER_H__
#define __LPN_GET_INPUT_DEMAND_SERVICEUSER_H__

#include <LpiIDConnServiceUsers.h>
#include <daortp_demandconnectorinput_xsd.h>
#include <LpnInputDemand.h>

#include <LclogStream.h>

class LpnGetInputDemandServiceUser : public LpiIGetInputDemandSrvUser
{
   public:

      LpnGetInputDemandServiceUser() {}

      void init (const std::string & name)
      {
         r_flightPlans.open(name);
#ifdef TRACE_OUT
         LclogStream::instance(LclogConfig::E_RTP_DEMAND_CONNECTOR).debug() 
	   <<"Read File: " << name 
	   << " :  File: " << __FILE__
	   << " ; fn: " << __func__
	   << " ; line: " << __LINE__
	   << std::endl;
#endif
         r_flightPlansList.push_back(r_flightPlans);

         LpdDConnComponent::Get().delegateUser(*this);
      }


      virtual void use (LpiGetInputDemandReply & reply)
      {
    	 LpiCreateDemandForecastList demandList;
    	 for(unsigned int i = 0; i< r_flightPlansList.size(); i++){
    		 LpiCreateDemandForecast forecast;
    		 LpnInputDemand::Convert2DemandForecast(r_flightPlansList[i], forecast);

    		 demandList.push_back(forecast);
    	 }
         reply.setDemandForecastList(demandList);
         reply.setResult(LpiDConnResult::E_OK);
      }

   private:

      DemandConnectorInput::FlightPlansElement  r_flightPlans;

      vector<DemandConnectorInput::FlightPlansElement> r_flightPlansList;
};


#endif /* __LRA_GET_INPUT_DEMAND_SERVICEUSER_H__ */
