/*
 * LpnInputDemand.cc
 *
 */

#include <boost/algorithm/string/trim.hpp>
#include "LpnInputDemand.h"


void LpnInputDemand::Convert2DemandForecast (const DemandConnectorInput::FlightPlansElement & flightPlanList,
											LpiCreateDemandForecast & output)
{
	output.setNameAirport(flightPlanList().intentionalDemand().nameAirport());
	output.setDemandStartTimeAndDate(flightPlanList().intentionalDemand().messageStartTimeAndDate());
	output.setDemandEndTimeAndDate(flightPlanList().intentionalDemand().messageEndTimeAndDate());

   for (unsigned int i = 0; i< flightPlanList().intentionalDemand().flightPlan().size(); i++)
   {
       DemandConnectorInput::FlightPlan inputFP = flightPlanList().intentionalDemand().flightPlan(i);

      //Departure Times Information
       DemandConnectorInput::DepartureInfo departureInfo = inputFP.depInfo();
      LpiDepartureTimes departureTimes;
      LpnInputDemand::Convert2DepartureTimes(departureInfo, departureTimes);

      //Arrival Times Information
      DemandConnectorInput::ArrivalInfo arrivalInfo = inputFP.arrInfo();
      LpiArrivalTimes arrivalTimes;
      LpnInputDemand::Convert2ArrivalTimes(arrivalInfo, arrivalTimes);

      LpiDemandFlightPlan fp;

      fp.setCallsign(inputFP.flightKey().callsign());
      fp.setDepartureAerodrome(inputFP.flightKey().depAerodrome());
      fp.setArrivalAerodrome(inputFP.flightKey().arrAerodrome());
      fp.setAircraftType(inputFP.acType());
      fp.setRegistration(inputFP.registration());
      fp.setWtc(inputFP.wtc());
      fp.setSID(inputFP.sid());
      fp.setSTAR(inputFP.star());
      fp.setVFR(inputFP.vfr());

      fp.setDepartureTimes(departureTimes);
      fp.setArrivalTimes(arrivalTimes);

      output.addFPToForecast(fp);
   }
}


void LpnInputDemand::Convert2DepartureTimes (const DemandConnectorInput::DepartureInfo & departureInfo,
                                             LpiDepartureTimes & output)
{

   //eobt
   if (departureInfo.eobt().valid())
   {
      output.setEobt(departureInfo.eobt().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.eobt().value().usec()));
   }

   //sobt
   if (departureInfo.sobt().valid())
   {
      output.setSobt(departureInfo.sobt().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.sobt().value().usec()));
   }

   //tobt
   if (departureInfo.tobt().valid())
   {
      output.setTobt(departureInfo.tobt().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.tobt().value().usec()));
   }

   //etot
   if (departureInfo.etot().valid())
   {
      output.setEtot(departureInfo.etot().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.etot().value().usec()));
   }

   //ttot
   if (departureInfo.ttot().valid())
   {
      output.setTtot(departureInfo.ttot().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.ttot().value().usec()));
   }

   //stot
   if (departureInfo.stot().valid())
   {
      output.setStot(departureInfo.stot().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.stot().value().usec()));
   }

   //atot
   if (departureInfo.atot().valid())
   {
      output.setAtot(departureInfo.atot().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.atot().value().usec()));
   }

   //ctot
   if (departureInfo.ctot().valid())
   {
      output.setCtot(departureInfo.ctot().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.ctot().value().usec()));
   }

   //utot
   if (departureInfo.utot().valid())
   {
      output.setUtot(departureInfo.utot().value().sec() +
                     LpnInputDemand::ToSeconds(departureInfo.utot().value().usec()));
   }


}


void LpnInputDemand::Convert2ArrivalTimes (const DemandConnectorInput::ArrivalInfo & arrivalInfo,
                                           LpiArrivalTimes & output)
{

   //eldt
   if (arrivalInfo.eldt().valid())
   {
      output.setEldt(arrivalInfo.eldt().value().sec() +
            LpnInputDemand::ToSeconds(arrivalInfo.eldt().value().usec()));
   }

   //tldt
   if (arrivalInfo.tldt().valid())
   {
      output.setTldt(arrivalInfo.tldt().value().sec() +
            LpnInputDemand::ToSeconds(arrivalInfo.tldt().value().usec()));
   }

   //aldt
   if (arrivalInfo.aldt().valid())
   {
      output.setAldt(arrivalInfo.aldt().value().sec() +
            LpnInputDemand::ToSeconds(arrivalInfo.aldt().value().usec()));
   }

   //sldt
   if (arrivalInfo.sldt().valid())
   {
      output.setSldt(arrivalInfo.sldt().value().sec() +
            LpnInputDemand::ToSeconds(arrivalInfo.sldt().value().usec()));
   }

   //sibt
   if (arrivalInfo.sibt().valid())
   {
      output.setSibt(arrivalInfo.sibt().value().sec() +
            LpnInputDemand::ToSeconds(arrivalInfo.sibt().value().usec()));
   }

   //uldt
   if (arrivalInfo.uldt().valid())
   {
      output.setUldt(arrivalInfo.uldt().value().sec() +
            LpnInputDemand::ToSeconds(arrivalInfo.uldt().value().usec()));
   }
}


unsigned long LpnInputDemand::ToSeconds(unsigned long microseconds)
{
   return microseconds * E_USEC_PER_SEC;
}
