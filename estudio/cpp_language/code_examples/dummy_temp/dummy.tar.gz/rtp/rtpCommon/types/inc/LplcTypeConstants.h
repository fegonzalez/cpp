#ifndef LPLC_TYPECONSTANTS_H__
#define LPLC_TYPECONSTANTS_H__

/*
 * DOC Reference: [1] "RTP Diseño Funcional.docx"
 */


#include <string>
#include <limits>


namespace rtp_constants
{

  // adap file names
  const std::string CFGDIR_ADAP = {"adap"};
  const std::string FILENAME_DAORTP_ALERT_KPI = {"DAORTP_Alert_KPI.xml"};
  const std::string FILENAME_DAORTP_AIRPORTS_INFO = 
    {"DAORTP_AirportsInfo.xml"};
  const std::string FILENAME_DAORTP_ASSIGNMENT_PREFERENCE = 
    {"DAORTP_AssignmentPreference.xml"};
  const std::string FILENAME_DAORTP_FP_PRIORITY = {"DAORTP_FpPriority.xml"};
  const std::string FILENAME_DAORTP_MRTM_INFO = {"DAORTP_MrtmInfo.xml"};
  const std::string FILENAME_DAORTP_WAKEVORTEX_CPACITY =
    {"DAORTP_WakevortexCapacityReductions.xml"};


  // config file names
  const std::string CFGDIR_CONFIG = {"config"}; 
  const std::string FILENAME_RTP_CORE_PARAMETERS = {"DAORTP_Parameters.xml"};
  const std::string FILENAME_RTP_HMI_PARAMETERS = {"DAORTP_HMI_Parameters.xml"};
  const std::string CFGDIR_DCONN = CFGDIR_CONFIG;
  const std::string FILENAME_DCONN_PARAMETERS = 
    {"DAORTP_DCONN_Parameters.xml"};


  // config core const (see [1].3.2.1)
  const unsigned int CORECONFIG_HOURS_WINDOW_DEFAULT_VALUE = 6;         // [h]
  const unsigned int CORECONFIG_MINUTES_SUBINTERVAL_DEFAULT_VALUE = 30; // [m]
  const unsigned int CORECONFIG_MINUTES_FROZEN_DEFAULT_VALUE = 60;      // [m]
  const unsigned int CORECONFIG_MINUTES_FROZEN_FOR_CLOCK_DEFAULT_VALUE = 300;      // [m]
  const unsigned int CORECONFIG_MINUTES_FP_EXPIRATION_TIME_DEFAULT_VALUE = 60;     // [m]

  ///adap const
  const unsigned int ADAP_MINUTES_MRTM_STAY_TIME_DEFAULT_VALUE = 60; // [m] see [1].3.1.2


  ////////////////////////////////////////
  /// Generic KPI data
  ////////////////////////////////////////

  const double MIN_ISA_WORKLOAD_VALUE = 0.0;
  const double MAX_ISA_WORKLOAD_VALUE = 5.0;

  const double DEFAULT_TOTALMOVS_KPI_VALUE = 0.0;


  ////////////////////////////////////////
  /// Capacity data
  ////////////////////////////////////////
  ///@warning nominal capacity = values per hour
  const unsigned int TMA_NOMINAL_CAPACITY_DEFAULT = 0;
  const unsigned int TWY_NOMINAL_CAPACITY_DEFAULT = 0;
  const unsigned int AIRPORT_NOMINAL_CAPACITY_DEFAULT = 0;

  ////////////////////////////////////////
  /// Complexity data
  ////////////////////////////////////////
  typedef double TYPE_COMPLEXITY;// because operations mix different types
  const TYPE_COMPLEXITY MIN_COMPLEXITY_VALUE = 0.0;
  const TYPE_COMPLEXITY MAX_COMPLEXITY_VALUE = 1.0;
  //ISA-Workload scale:[0-5]
  const TYPE_COMPLEXITY MIN_COMPLEXITY_ISA_WORKLOAD_VALUE =
    MIN_ISA_WORKLOAD_VALUE;
  const TYPE_COMPLEXITY MAX_COMPLEXITY_ISA_WORKLOAD_VALUE =
    MAX_ISA_WORKLOAD_VALUE;
  const TYPE_COMPLEXITY DEFAULT_COMPLEXITY_VALUE = MIN_COMPLEXITY_VALUE;


  ////////////////////////////////////////
  /// Schedule data
  ////////////////////////////////////////

  typedef int TYPE_SCHEDULE_COST;
  const TYPE_SCHEDULE_COST MAX_SCHEDULE_COST = std::numeric_limits<TYPE_SCHEDULE_COST>::infinity();
  const TYPE_SCHEDULE_COST NOPREFERENCE_SCHEDULE_COST = static_cast<TYPE_SCHEDULE_COST>(100);
  const TYPE_SCHEDULE_COST FORBID_SCHEDULE_COST = static_cast<TYPE_SCHEDULE_COST>(10000);
  const unsigned int SCH_MAX_ATS_ALLOWED = 2;
  const unsigned int SCH_MAX_AFIS_ALLOWED = 3;

}

#endif

