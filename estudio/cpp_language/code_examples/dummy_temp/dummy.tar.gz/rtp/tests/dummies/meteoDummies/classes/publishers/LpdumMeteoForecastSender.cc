/* meteoForecastSender.cc
 *
 */

#include <LpdumMeteoForecastSender.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <LcuStringArrayConvUtils.h>
#include <LctimTimeUtils.h>
#include <daortp_meteoforecast_xsd.h>
#include <LpdumMeteoInfoConverterMultiple.h>
#include <LclogStream.h>

#include <iostream>
#include <iterator>
#include <cassert>


//-----------------------------------------------------------------------------

void LpdumMeteoForecastSender::addInput(const std::string &fileName)
{
  // load XML file into memory
  MeteoForecast::MeteorologicalForecastElement meteo_input(fileName.c_str());   
  r_meteoInputList.push_back(meteo_input());


  LclogStream::instance(LclogConfig::E_RTP_TEST).notify()
    << "Adding meteo file: <" << fileName << "<"
    << " ; Meteo XML - Version: "  << meteo_input().version()
    << " ; Meteo XML - number of files: " << numFiles()
    << "  : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
}

//-----------------------------------------------------------------------------

void LpdumMeteoForecastSender::notify(unsigned int waitBeforeSending, 
				      unsigned int waitAfterSending)
{
  publishEvent(waitBeforeSending, waitAfterSending);
}

//-----------------------------------------------------------------------------

void LpdumMeteoForecastSender::publishEvent(unsigned int waitBeforeSending,
				      unsigned int waitAfterSending)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_TEST).debug()
    //std::cerr << "\n"
    << "MeteoForecast Connector [PUBLISHED METEO FORECAST]"
    << " :  File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  
  // STEP-1: getting the data

  ///@warning Each XML file could have several Airport data: 2 substeps required
  /// Two steps because we MUST set the length of r_meteoAirportList 
  /// to pass to it to data.meteos.ensure_length.


  // step-1.1 save each airport data from each XML file as a IOMeteoInfo::Meteo 
  for (unsigned int i = 0; i < numFiles(); i++)
  {    

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_TEST).debug()
    << "MeteoForecast Connector [PUBLISHED METEO FORECAST] file."
    << " :  File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

    //argument (r_meteoInputList[i].meteoForecast): list of MeteoForecastAirport
    //
    //returned: std::vector<IOMeteoInfo::Meteo> r_meteoList;
    //
    LpdumMeteoInfoConverterMultiple meteoInformation
      (r_meteoInputList[i].
       meteoForecast()); // vector<MeteoForecast::MeteoForecastAirport>


    for(unsigned int mi = 0; mi < meteoInformation.size(); ++mi)
    {
      addData(meteoInformation[mi]);
    }

  }//end-for-step-1.1


  // step-1.2 data = ALL saved forecast information (IOMeteoInfo::Meteo)
  
  ::IOMeteoInfoEvents::CreateMeteoForecastEventList data;//list of IOMeteoInfo
  ::IOMeteoInfoEvents::CreateMeteoForecastEventListTypeSupport::initialize_data(&data);
  data.meteos.ensure_length(numMeteoInfo(), numMeteoInfo());
  for (unsigned int i = 0; i < numMeteoInfo(); i++)
  {
    data.meteos.set_at(i, getData(i)); 
  }
  
  // STEP-2: publish the data (IDL msg.) to the server. IDEM meteoNowcast.

  sleep(waitBeforeSending);
  
  iB::PublisherId pid("IOMeteoInfoEvents::CreateMeteoForecastEventList");
  iB::PublicationProfile pprofile;
  iBG::IOMeteoInfoEvents::CreateMeteoForecastEventListPublisher &publisher =
    iBG::IOMeteoInfoEvents::CreateMeteoForecastEventListCreatePublisher
    (pid, pprofile);

  publisher.push(data);
  
  ::IOMeteoInfoEvents::CreateMeteoForecastEventListTypeSupport::finalize_data(&data);

  LclogStream::instance(LclogConfig::E_RTP_TEST).notify() 
    << "MeteoForecast Connector [PUBLISHED METEO FORECAST]" 
    << " :  File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__ 
    << std::endl;

  sleep(waitAfterSending);

}

//=============================================================================

const IOMeteoInfo::Meteo&
LpdumMeteoForecastSender::getData(unsigned int index)const 
{
  assert(index < numMeteoInfo());
  return r_meteoInfo[index];
}

//-----------------------------------------------------------------------------

 void LpdumMeteoForecastSender::addData(const IOMeteoInfo::Meteo& newdata)
 {
   r_meteoInfo.push_back(newdata);
 }
   
//-----------------------------------------------------------------------------
