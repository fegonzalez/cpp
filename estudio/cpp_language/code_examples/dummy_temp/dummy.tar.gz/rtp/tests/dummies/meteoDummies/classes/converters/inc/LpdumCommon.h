
#ifndef LPDUM_COMMON_H_
#define LPDUM_COMMON_H_


//#include <IOMeteoInfoEventsiBContract.h>
#include <daortp_meteoinfo_xsd.h>
#include <daortp_meteoforecast_xsd.h> // MeteoForecast::MeteoForecastAirport;
#include <daortp_meteonowcast_xsd.h>  // MeteoNowcast::MeteoNowcastAirport;
#include <IOMeteoInfo.h>



void string_to_DDS_Char_array(DDS_Char dest[], std::string str, 
			                  unsigned int length);


void fillMessageIdentification(const MeteoInfo::MessageIdentification &input,
			                   IOMeteoInfo::MessageIndentificacion &retval);

void fillBodyInformationList(const MeteoForecast::MeteoForecastAirport &input,
			                 IOMeteoInfo::Meteo &retval);


IOMeteoInfo::BodyInformation fillBodyInformation(const MeteoInfo::BodyInformation &information);

  
#endif

