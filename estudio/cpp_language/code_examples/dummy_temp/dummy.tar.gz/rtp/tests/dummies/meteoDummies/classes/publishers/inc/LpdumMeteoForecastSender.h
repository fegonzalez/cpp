 /* LpdumMeteoForecastSender.h
 *
 */
#ifndef METEOFORECASTSENDER_H_
#define METEOFORECASTSENDER_H_

#include <IOMeteoInfoEventsiBContract.h>
#include <daortp_meteoforecast_xsd.h>

#include <string>
#include <vector>


class LpdumMeteoForecastSender
{
 public:
  LpdumMeteoForecastSender() = default;
  LpdumMeteoForecastSender(const LpdumMeteoForecastSender&) = delete;
  LpdumMeteoForecastSender& operator=(const LpdumMeteoForecastSender &)= delete;
  virtual  ~LpdumMeteoForecastSender() = default;

  ///@brief load ONE  XML file into memory
  void addInput(const std::string &fileName);

  ///@brief Send all the meteo data to the RTP
  void notify(unsigned int waitBeforeSending,
	      unsigned int waitAfterSending);

  
 private:

  // data

  // XML files (xsd data type)
  // <xs:element name="meteorologicalForecast" type="MeteoForecastElement"/>
  std::vector<MeteoForecast::MeteoForecastElement> r_meteoInputList;

  // Airport data (<meteoForecast> tag): 1 or more per XML file.
  std::vector<IOMeteoInfo::Meteo> r_meteoInfo;

  
  // fns

  ///@brief Logic of the notify() action.
  void publishEvent(unsigned int waitBeforeSending, 
		    unsigned int waitAfterSending);
  
  ///@brief number of different XML files loaded
  unsigned int numFiles()const { return r_meteoInputList.size(); }
  
  ///@brief number of different meteo inputs (already converted to idl format)
  unsigned int numMeteoInfo()const { return r_meteoInfo.size(); }

  const IOMeteoInfo::Meteo& getData(unsigned int index)const ;

  void addData(const IOMeteoInfo::Meteo& newdata);
  
};

#endif
