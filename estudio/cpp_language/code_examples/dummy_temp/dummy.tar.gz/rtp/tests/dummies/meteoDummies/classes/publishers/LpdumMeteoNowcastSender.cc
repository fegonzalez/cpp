/* meteoNowcastSender.cc
 *
 */

#include <LpdumMeteoNowcastSender.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <LcuStringArrayConvUtils.h>
#include <LctimTimeUtils.h>
#include <daortp_meteonowcast_xsd.h>
#include <LpdumMeteoInfoConverterMultiple.h>
#include <LclogStream.h>

#include <iostream>
#include <iterator>
#include <cassert>


//-----------------------------------------------------------------------------

void LpdumMeteoNowcastSender::addInput(const std::string &fileName)
{
    // load XML file into memory
    MeteoNowcast::MeteorologicalNowcastElement meteo_input(fileName.c_str());   
    r_meteoInputList.push_back(meteo_input());


    LclogStream::instance(LclogConfig::E_RTP_TEST).notify()
      << "Adding meteo file: <" << fileName << "<"
      << " ; Meteo XML - Version: "  << meteo_input().version()
      << " ; Meteo XML - number of files: " << this->numFiles()
      << "  : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
}

//-----------------------------------------------------------------------------

void LpdumMeteoNowcastSender::notify(unsigned int waitBeforeSending, 
				unsigned int waitAfterSending)
{
  publishEvent(waitBeforeSending, waitAfterSending);
}

//-----------------------------------------------------------------------------

void LpdumMeteoNowcastSender::publishEvent(unsigned int waitBeforeSending,
				      unsigned int waitAfterSending)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_TEST).debug()
    //std::cerr << "\n"
    << "MeteoNowcast Connector [PUBLISHED METEO NOWCAST]"
    << " :  File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  
  // STEP-1: getting the data

  ///@warning Each XML file could have several Airport data: 2 substeps required
  /// Two steps because we MUST set the length of r_meteoAirportList 
  /// to pass to it to data.meteos.ensure_length.


  // step-1.1 save each airport data from each XML file as a IOMeteoInfo::Meteo 
  for (unsigned int i = 0; i < numFiles(); i++)
  {    

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_TEST).debug()
    << "MeteoNowcast Connector [PUBLISHED METEO NOWCAST] file."
    << " :  File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

    //argument (r_meteoInputList[i].meteoNowcast): list of MeteoNowcastAirport
    //
    //returned: std::vector<IOMeteoInfo::Meteo> r_meteoList;
    //
    LpdumMeteoInfoConverterMultiple meteoInformation
      (r_meteoInputList[i].
       meteoNowcast()); // vector<MeteoNowcast::MeteoNowcastAirport>


    for(unsigned int mi = 0; mi < meteoInformation.size(); ++mi)
    {
      addData(meteoInformation[mi]);
    }

  }//end-for-step-1.1


  // step-1.2 data = ALL saved nowcast information (IOMeteoInfo::Meteo)
  
  ::IOMeteoInfoEvents::CreateMeteoNowcastEventList data;//list of IOMeteoInfo
  ::IOMeteoInfoEvents::CreateMeteoNowcastEventListTypeSupport::initialize_data(&data);
  data.meteos.ensure_length(numMeteoInfo(), numMeteoInfo());
  for (unsigned int i = 0; i < numMeteoInfo(); i++)
  {
    data.meteos.set_at(i, getData(i)); 
  }

  // STEP-2: publish the data (sent to the server via IDL msg.)

  sleep(waitBeforeSending);

  iB::PublisherId pid("IOMeteoInfoEvents::CreateMeteoNowcastEventList");
  iB::PublicationProfile pprofile;
  iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListPublisher &publisher =
    iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListCreatePublisher
    (pid, pprofile);
  
  publisher.push(data);
  
  ::IOMeteoInfoEvents::CreateMeteoNowcastEventListTypeSupport::finalize_data(&data);

  LclogStream::instance(LclogConfig::E_RTP_TEST).notify() 
    << "MeteoNowcast Connector [PUBLISHED METEO NOWCAST]" 
    << " :  File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__ 
    << std::endl;

  sleep(waitAfterSending);

}

//=============================================================================

const IOMeteoInfo::Meteo&
LpdumMeteoNowcastSender::getData(unsigned int index)const 
{
  assert(index < numMeteoInfo());
  return r_meteoInfo[index];
}

//-----------------------------------------------------------------------------

 void LpdumMeteoNowcastSender::addData(const IOMeteoInfo::Meteo& newdata)
 {
   r_meteoInfo.push_back(newdata);
 }
   
//-----------------------------------------------------------------------------

