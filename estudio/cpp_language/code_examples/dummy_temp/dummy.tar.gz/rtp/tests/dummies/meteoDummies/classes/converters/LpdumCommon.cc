
#include <LpdumCommon.h>
#include <daortp_meteoforecast_xsd.h>

//#include <LclogStream.h>

#include <iostream>


//------------------------------------------------------------------------------

void string_to_DDS_Char_array
(DDS_Char dest[], std::string str, unsigned int length)
{
   unsigned int i = 0;
   if(str.length() < length)
   {
      for(i = 0 ; i < str.length(); i++)
      {
         dest[i]= str[i];
      }
      for(i = str.length(); i < length; i++)
      {
         dest[i]= ' ';
      }
   }
   else
   {
      for(i = 0; i < length; i++)
      {
         dest[i]= str[i];
      }
   }
}

//------------------------------------------------------------------------------

// return retval = input
void fillMessageIdentification(const MeteoInfo::MessageIdentification &input,
			       IOMeteoInfo::MessageIndentificacion &retval)
{

  string_to_DDS_Char_array(retval.airport,
			   input.airport(),
			   sizeof(input.airport()));

  string_to_DDS_Char_array(retval.timeAndDate,
			   input.messageTimeAndDate(),
			   sizeof(input.messageTimeAndDate()));
}

//------------------------------------------------------------------------------

void fillBodyInformationList(const MeteoForecast::MeteoForecastAirport &input,
			                 IOMeteoInfo::Meteo &retval)
{
  retval.bodyInformation.ensure_length(input.information().size(),
                                       input.information().size());

   for(unsigned int loopi = 0;
       loopi < input.information().size();
       ++loopi)
   {

     retval.bodyInformation.set_at
       (loopi, fillBodyInformation(input.information(loopi)));
   }
}

//------------------------------------------------------------------------------

IOMeteoInfo::BodyInformation
fillBodyInformation(const MeteoInfo::BodyInformation &information)
{

  IOMeteoInfo::BodyInformation retval;
 
  //periodInformation
  string_to_DDS_Char_array(retval.periodInformation.startTimeAndDate,
                           information.periodInformation().startTimeAndDate(),
                           sizeof(retval.periodInformation.startTimeAndDate));

  string_to_DDS_Char_array(retval.periodInformation.endTimeAndDate,
                           information.periodInformation().endTimeAndDate(),
                           sizeof(retval.periodInformation.endTimeAndDate));

  retval.periodInformation.probability =
    information.periodInformation().probability();


  //MeteorologicalInformation
   retval.meteorologicalInformation.meteorological.windDirection =
     information.meteorologicalInformation().windDirection();

   retval.meteorologicalInformation.meteorological.windSpeed =
     information.meteorologicalInformation().windSpeed();

   retval.meteorologicalInformation.meteorological.gustDirection =
     information.meteorologicalInformation().gustDirection();

   retval.meteorologicalInformation.meteorological.gustSpeed =
     information.meteorologicalInformation().gustSpeed();

   retval.meteorologicalInformation.meteorological.airTemperature =
     information.meteorologicalInformation().airTemperature();

   retval.meteorologicalInformation.meteorological.dewPointTemperature =
     information.meteorologicalInformation().dewPointTemperature();

   retval.meteorologicalInformation.meteorological.horizontalVisibility =
     information.meteorologicalInformation().horizontalVisibility();

   retval.meteorologicalInformation.meteorological.qnh =
     information.meteorologicalInformation().qnh();


   retval.meteorologicalInformation.meteorological.cloudBase =
     information.meteorologicalInformation().cloudBase();

   string_to_DDS_Char_array
     (retval.meteorologicalInformation.meteorological.significantWeather,
      information.meteorologicalInformation().significantWeather(),
      sizeof(retval.meteorologicalInformation.meteorological.
	     significantWeather));


   retval.meteorologicalInformation.rvrPerRunway.ensure_length
     (information.meteorologicalInformation().rvrPerRunway().rvr().size(),
      information.meteorologicalInformation().rvrPerRunway().rvr().size());

   IOMeteoInfo::RVRperRunway rvrPerRunway;

   for(unsigned int k = 0; 
       k < information.meteorologicalInformation().rvrPerRunway().rvr().size(); 
       ++k)
   {

     string_to_DDS_Char_array(rvrPerRunway.name,
			      information.meteorologicalInformation().
			      rvrPerRunway().rvr(k).runway(),
			      sizeof(rvrPerRunway.name));
     
     rvrPerRunway.rvr = information.meteorologicalInformation().rvrPerRunway().
       rvr(k).runwayVisualRange();

     retval.meteorologicalInformation.rvrPerRunway.set_at(k, rvrPerRunway);

   }


 return retval; 
}

//------------------------------------------------------------------------------
