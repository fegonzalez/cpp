/* meteoForecastPublisher.cc
 *
 *  Created on: 23/01/2014
 *      Author: gpfernandez 
 */
#include <LpdumMeteoForecastSender.h>
#include <daortp_meteoforecast_xsd.h>

#include <IOMeteoInfoEventsiBContract.h>
#include <LclogStream.h>

#include <QString>
#include <boost/lexical_cast.hpp>

#include <dirent.h>
#include <string>
#include <iostream>
#include <exception>
#include <sstream>


int main(int argc, char *argv[])
{
    if (argc < 4)   // Program name + input file
    {
        const std::string ERR_BAD_INPUT = "[Meteo-Forecast-Connector]: Usage"
          +  std::string(argv[0])
          + " <fileName>.xml <before_send_secs> <after_send_secs>";

        LclogStream::instance(LclogConfig::E_RTP_TEST).error() << ERR_BAD_INPUT
    		  << " ; File: " << __FILE__
    		  << " ; fn: " << __func__
    		  << " ; line: " << __LINE__
    		  << std::endl;

        std::cerr << "\nDEBUG: [MeteoForecast-Connector]: "
    	      << ERR_BAD_INPUT
    	      << " ; File: " << __FILE__
    	      << " ; fn: " << __func__
    	      << " ; line: " << __LINE__
    	      << std::endl;
        exit(EXIT_FAILURE);
    }

    unsigned int waitBeforeSending = boost::lexical_cast<unsigned int>(argv[2]);
    unsigned int waitAfterSending = boost::lexical_cast<unsigned int>(argv[3]);

    try
    {
        QString file = argv[1];

	// case 1: loading  single XML file

        if(file.contains("xml"))
        {

	  LclogStream::instance(LclogConfig::E_RTP_TEST).info()
	    << "\nDEBUG: archivo: <"
	    << file.toStdString() << ">"
	    << " : file: " << __FILE__
	    << " ; FN: " << __func__
	    << " ; LINE:  " << __LINE__
	    << std::endl;

            LpdumMeteoForecastSender forecast;
	    forecast.addInput(argv[1]);

            LclogStream::instance(LclogConfig::E_RTP_TEST).info()
	      << "File Name: " << argv[1] << std::endl;
            LclogStream::instance(LclogConfig::E_RTP_TEST).info()
	      << "Waiting before sending " << waitBeforeSending
	      << " secs, after sending " << waitAfterSending << std::endl;

            forecast.notify(waitBeforeSending, waitAfterSending);
        }


	// case 2: loading directory containing one or more XML meteo files

        else 
	{
	  std::string dir = file.toStdString();

	  LclogStream::instance(LclogConfig::E_RTP_TEST).info()
	    << "\nDEBUG:[ MeteoForecast-Connector]:  "
	    << "Leyendo todos los archivos del dir: <" << dir << ">"
	    << " : file: " << __FILE__
	    << " ; FN: " << __func__
	    << " ; LINE:  " << __LINE__
	    << std::endl;


            DIR *directorio;
            struct dirent *elemento;
            std::string elem;

            directorio = opendir(dir.c_str());
            if (directorio)
            {
	      LpdumMeteoForecastSender forecast;

                elemento = readdir(directorio);
                while (elemento)
                {
                  elem = elemento->d_name;
                  if (QString::fromStdString(elem).contains("xml"))
                  {
                      char result[100];
                      const char* concat = elem.c_str(); // XML-file name
                      strcpy(result, argv[1]); // directory path 
                      strcat(result, concat);

#ifdef TRACE_OUT    
		      std::stringstream total_file_name("");
		      total_file_name << argv[1] << elem.c_str();
		      LclogStream::instance(LclogConfig::E_RTP_TEST).debug()
			<< "\nDEBUG: Loading input file: <"
			<< total_file_name.str() << ">"
			<< " : File: " << __FILE__
			<< " ; fn: " << __func__
			<< " ; line: " << __LINE__ 
			<< std::endl;
#endif

		    //handle finput file: "dir/file.xml"
		    forecast.addInput(result);		    
                  }
                  elemento = readdir(directorio);
                }//end-while

		forecast.notify(waitBeforeSending, waitAfterSending);
            }
        }//end-case 2
    }
    catch(std::exception& e)
    {
      LclogStream::instance(LclogConfig::E_RTP_TEST).info()
	<< "[MESSAGE METEOROLOGICAL FORECAST WILL BE DISCARDED]"
	<< std::endl;
      LclogStream::instance(LclogConfig::E_RTP_TEST).error()
	<< "Please, check the input file " << argv[1] << std::endl;
      LclogStream::instance(LclogConfig::E_RTP_TEST).error()
	<< e.what() << std::endl;
    }
    
    return 0;
}

