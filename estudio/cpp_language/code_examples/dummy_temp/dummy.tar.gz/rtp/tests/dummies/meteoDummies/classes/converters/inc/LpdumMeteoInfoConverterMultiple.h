/* LpdumMeteoInfoConverterMultiple.h
 *
 * Converter to handle the case: Multiple Airports in the same XML (meteo) file.
 * 
 * Can convert both nowcast and forecast messages.
 */

#ifndef LPDUM_METEOINFOCONVERTER_MULTIPLE_H_
#define LPDUM_METEOINFOCONVERTER_MULTIPLE_H_


#include <IOMeteoInfoEventsiBContract.h>
#include <daortp_meteoinfo_xsd.h>
#include <daortp_meteoforecast_xsd.h>  // MeteoForecast::MeteoForecastAirport;
#include <daortp_meteonowcast_xsd.h>  // MeteoNowcast::MeteoNowcastAirport;
#include <IOMeteoInfo.h>

#include <vector>


class LpdumMeteoInfoConverterMultiple
{
 public:

  //setters: (meteo connector) XSD types => (iMASBlue's meteo) IDL types


  explicit LpdumMeteoInfoConverterMultiple
    (const std::vector<MeteoForecast::MeteoForecastAirport> &input);

  explicit LpdumMeteoInfoConverterMultiple
    (const std::vector<MeteoNowcast::MeteoNowcastAirport> &input);

  
  LpdumMeteoInfoConverterMultiple() = delete;
  virtual  ~LpdumMeteoInfoConverterMultiple () = default;  
  LpdumMeteoInfoConverterMultiple& operator=
    (const LpdumMeteoInfoConverterMultiple&) = delete;

  
  unsigned int size() const { return r_meteoList.size(); }
  const IOMeteoInfo::Meteo& operator[](unsigned int index) const;
  void push_back(const IOMeteoInfo::Meteo& new_val) { r_meteoList.push_back(new_val); }

  
 private:

  /**@param r_meteoList: IDL type 
     (typedef sequence<IOMeteoInfo::Meteo, 100> MeteoList;
     common for Nowcast & Forecast msg.
  */
  std::vector<IOMeteoInfo::Meteo> r_meteoList;
  
  void set (const std::vector<MeteoForecast::MeteoForecastAirport> &input);
  void set (const std::vector<MeteoNowcast::MeteoNowcastAirport> &input);
  
};

#endif

