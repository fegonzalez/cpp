
 /* meteoInfo.cc
 *
 */

#include <LpdumMeteoInfoConverterMultiple.h>
#include <LpdumCommon.h>
#include <daortp_meteoforecast_xsd.h>  // MeteoForecast::MeteoForecastAirport;
#include <daortp_meteonowcast_xsd.h>  // MeteoNowcast::MeteoNowcastAirport;

#include <LclogStream.h>

#include <iostream>



// input is a list of MeteoForecast::MeteoForecastAirport
LpdumMeteoInfoConverterMultiple::LpdumMeteoInfoConverterMultiple
(const std::vector<MeteoForecast::MeteoForecastAirport> &input)
{
 this->set(input);
}

//-----------------------------------------------------------------------------

LpdumMeteoInfoConverterMultiple::LpdumMeteoInfoConverterMultiple
(const std::vector<MeteoNowcast::MeteoNowcastAirport> &input)
{
 this->set(input);
}

//-----------------------------------------------------------------------------

const IOMeteoInfo::Meteo&
LpdumMeteoInfoConverterMultiple::operator[](unsigned int index)const
{
 assert(index < size());
 return r_meteoList[index];
}

//-----------------------------------------------------------------------------

// input is a list of MeteoForecast::MeteoForecastAirport
//
// cada elemeto de la lista contiene:
//
//  1 MeteoInfo::MessageIdentification
//
//  n MeteoInfo::BodyInformation
void LpdumMeteoInfoConverterMultiple::set
(const std::vector<MeteoForecast::MeteoForecastAirport> &input)
{

 for (unsigned int index = 0; index < input.size(); ++index)
 {

   IOMeteoInfo::Meteo new_val;
   fillMessageIdentification(input[index].messageIdentification(),
		                     new_val.messageIdentification);

   fillBodyInformationList(input[index], new_val);

   this->push_back(new_val);
 }

}

//-----------------------------------------------------------------------------

// input is a list of MeteoNowcast::MeteoNowcastAirport
//
// cada elemeto de la lista contiene:
//
//  1 MeteoInfo::MessageIdentification
//
//  1 MeteoInfo::BodyInformation
void LpdumMeteoInfoConverterMultiple::set
(const std::vector<MeteoNowcast::MeteoNowcastAirport> &input)
{
 for (unsigned int index = 0; index < input.size(); ++index)
 {
   IOMeteoInfo::Meteo new_val;
   fillMessageIdentification(input[index].messageIdentification(),
		                     new_val.messageIdentification);

   new_val.bodyInformation.ensure_length(1,1);
   new_val.bodyInformation.set_at(0, fillBodyInformation(input[index].information()));

   this->push_back(new_val);
 }
}

//-----------------------------------------------------------------------------

