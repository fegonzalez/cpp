#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    //Q_IMPORT_PLUGIN(QODBCDriverPlugin)
    //Q_IMPORT_PLUGIN(QWindowsIntegrationPlugin)
    ui->setupUi(this);
    QPalette p = ui->textEdit->palette();
    p.setColor(QPalette::Base, Qt::black);
    p.setColor(QPalette::Text, Qt::white);
    ui->textEdit->setPalette(p);
    QDateTime dateTime = QDateTime::currentDateTime();
    if(dateTime.time().hour() < 10)
        ui->Hour->setText("0" + QString::number(dateTime.time().hour()));
    else
        ui->Hour->setText(QString::number(dateTime.time().hour()));
    if(dateTime.time().minute() < 10)
        ui->Minute->setText("0" + QString::number(dateTime.time().minute()));
    else
        ui->Minute->setText(QString::number(dateTime.time().minute()));
    if(dateTime.date().day() < 10)
        ui->Day->setText("0" + QString::number(dateTime.date().day()));
    else
        ui->Day->setText(QString::number(dateTime.date().day()));
    if(dateTime.date().month() < 10)
        ui->Month->setText("0" + QString::number(dateTime.date().month()));
    else
        ui->Month->setText(QString::number(dateTime.date().month()));
    if(dateTime.date().year() < 10)
        ui->Year->setText("0" + QString::number(dateTime.date().year()).right(2));
    else
        ui->Year->setText(QString::number(dateTime.date().year()).right(2));
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::setExcelFileName()
{
    _excelFileName = QFileDialog::getOpenFileName(this,
        tr("Open Demand Excel File"), QDir::currentPath(), tr("Demand Excel file (*.xls)"));

    if (!_excelFileName.isEmpty())
    {
        ui->lineEdit->setText(_excelFileName);
        ui->botonSeleccionDirXML->setEnabled(true);
        return true;
    }
    else
    {
        ui->lineEdit->clear();
        _excelFileName = QString("");
        ui->botonSeleccionDirXML->setEnabled(false);
        ui->botonGenerar->setEnabled(false);
        return false;
    }
}

bool MainWindow::setXMLDirName()
{
    _XMLDirFileName = QFileDialog::getExistingDirectory(this,
        tr("Open Demand XML Directory"), QDir::currentPath(), QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    if (!_XMLDirFileName.isEmpty())
    {
        ui->lineEdit_2->setText(_XMLDirFileName);
        ui->botonGenerar->setEnabled(true);
        return true;
    }
    else
    {
        ui->lineEdit_2->clear();
        _XMLDirFileName = QString("");
        ui->botonGenerar->setEnabled(false);
        return false;
    }
}

bool MainWindow::generateXMLFile()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);

    ui->textEdit->append("Reading demand Excel file: [" + _excelFileName + "]\n");

    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("DRIVER={Microsoft Excel Driver (*.xls)};DBQ=" + QString(_excelFileName));
    if(db.open())
    {
        ui->textEdit->append("Excel file opened.\n");

        QString xmlFile = _XMLDirFileName + "/demand.xml";

        QFile fileDemandXML(xmlFile);

        if (fileDemandXML.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            fileDemandXML.setTextModeEnabled(false);

            QTextStream out(&fileDemandXML);

            ui->textEdit->append("XML file opened.\n");

            out << "<flightPlans version=\"1.0\">\n";

            QSqlQuery query("select * from [" + QString("day1") + "$]");

            int row = 0;

            out << "<intentionalDemand>\n";

            out << "    <messageTimeAndDate>" + ui->Hour->text() + ui->Minute->text() + "/" + ui->Day->text() + ui->Month->text() + ui->Year->text() + "</messageTimeAndDate>\n";
            ui->textEdit->append("    <messageTimeAndDate>" + ui->Hour->text() + ui->Minute->text() + "/" + ui->Day->text() + ui->Month->text() + ui->Year->text() + "</messageTimeAndDate>\n");

            while (query.next())
            {
                if(row>=0)
                {
                    // Sacamos la fecha
                    QString fecha= query.value(0).toString();
                    // Sacamos el callsign
                    QString callsign = query.value(1).toString();
                    // Sacamos el depaerod
                    QString depaerod = query.value(2).toString();
                    // Sacamos el arraerod
                    QString arraerod = query.value(3).toString();
                    // Sacamos el aircraftType
                    QString aircraftType = query.value(4).toString();
                    // Sacamos el registration
                    QString registration = query.value(5).toString();
                    // Sacamos el wtc
                    QString wtc = query.value(6).toString();
                    // Sacamos el SID
                    QString SID = query.value(7).toString();
                    // Sacamos el STAR
                    QString STAR = query.value(8).toString();
                    // Sacamos el EOBT
                    QString EOBT = query.value(9).toString();
                    // Sacamos el SOBT
                    QString SOBT = query.value(10).toString();
                    // Sacamos el TOBT
                    QString TOBT = query.value(11).toString();
                    // Sacamos el ETOT
                    QString ETOT = query.value(12).toString();
                    // Sacamos el TTOT
                    QString TTOT = query.value(13).toString();
                    // Sacamos el STOT
                    QString STOT = query.value(14).toString();
                    // Sacamos el ATOT
                    QString ATOT = query.value(15).toString();
                    // Sacamos el CTOT
                    QString CTOT = query.value(16).toString();

                    //Fase 3: Vuelos con condiciones especiales
                    // Sacamos el UTOT
                    QString UTOT = query.value(17).toString();

                    // Sacamos el ELDT
                    QString ELDT = query.value(18).toString();
                    // Sacamos el TLDT
                    QString TLDT = query.value(19).toString();
                    // Sacamos el ALDT
                    QString ALDT = query.value(20).toString();
                    // Sacamos el SLDT
                    QString SLDT = query.value(21).toString();
                    // Sacamos el SIBT
                    QString SIBT = query.value(22).toString();

                    //Fase 3: Vuelos con condiciones especiales
                    // Sacamos el UTOT
                    QString ULDT = query.value(23).toString();

                    ui->textEdit->append("Reading row [" + QString::number(row) + "]\n");
                    ui->textEdit->append("--Date: [" + fecha + "]\n");
                    ui->textEdit->append("--Callsign: [" + callsign + "]\n");
                    ui->textEdit->append("--Departure aerodrome: [" + depaerod + "]\n");
                    ui->textEdit->append("--Arrival aerodrome: [" + arraerod + "]\n");
                    ui->textEdit->append("--Aircraft type: [" + aircraftType + "]\n");
                    ui->textEdit->append("--Registration: [" + registration + "]\n");
                    ui->textEdit->append("--Wake turbulence category: [" + wtc + "]\n");
                    ui->textEdit->append("--SID: [" + SID + "]\n");
                    ui->textEdit->append("--STAR: [" + STAR + "]\n");
                    ui->textEdit->append("--EOBT: [" + EOBT + "]\n");
                    ui->textEdit->append("--SOBT: [" + SOBT + "]\n");
                    ui->textEdit->append("--TOBT: [" + TOBT + "]\n");
                    ui->textEdit->append("--ETOT: [" + ETOT + "]\n");
                    ui->textEdit->append("--TTOT: [" + TTOT + "]\n");
                    ui->textEdit->append("--STOT: [" + STOT + "]\n");
                    ui->textEdit->append("--ATOT: [" + ATOT + "]\n");
                    ui->textEdit->append("--CTOT: [" + CTOT + "]\n");
                    ui->textEdit->append("--UTOT: [" + UTOT + "]\n");
                    ui->textEdit->append("--ELDT: [" + ELDT + "]\n");
                    ui->textEdit->append("--TLDT: [" + TLDT + "]\n");
                    ui->textEdit->append("--ALDT: [" + ALDT + "]\n");
                    ui->textEdit->append("--SLDT: [" + SLDT + "]\n");
                    ui->textEdit->append("--SIBT: [" + SIBT + "]\n");
                    ui->textEdit->append("--ULDT: [" + ULDT + "]\n\n");

                    if(fecha.compare("")==0)
                        ui->textEdit->show();
                    ui->textEdit->append("Conversion to XML element.");
                    // Conversion fecha
                    // Sacamos los datos de la fecha
                    QString dia, mes, anyo = QString("");
                    //QRegExp rx("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                    QRegExp rx("([0-9][0-9])/([0-9][0-9])/([0-9][0-9][0-9][0-9])");
                    rx.indexIn(fecha);
                    QStringList list = rx.capturedTexts();
                    QStringList::iterator it = list.begin();
                    int contador = 0;
                    while (it != list.end())
                    {
                        if (contador ==3)
                        {
                            anyo = *it;
                        }
                        else if (contador ==2)
                        {
                            mes = *it;
                        }
                        else if (contador ==1)
                        {
                            dia = *it;
                        }
                        ++contador;
                        ++it;
                    }
                    // Iniciamos escritura de elemento XML
                    out << "    <flightPlan>\n";
                    ui->textEdit->append("<flightPlan>\n");
                    // out << "    <messageTimeAndDate>" + ui->Hour->text() + ui->Minute->text() + "/" + ui->Day->text() + ui->Month->text() + ui->Year->text() + "</messageTimeAndDate>\n";
                    // ui->textEdit->append("    <messageTimeAndDate>" + ui->Hour->text() + ui->Minute->text() + "/" + ui->Day->text() + ui->Month->text() + ui->Year->text() + "</messageTimeAndDate>\n");
                    out << "        <flightKey>\n";
                    ui->textEdit->append("  <flightKey>\n");
                    out << "            <callsign>" + callsign + "</callsign>\n";
                    ui->textEdit->append("      <callsign>" + callsign + "</callsign>\n");
                    out << "            <depAerodrome>" + depaerod + "</depAerodrome>\n";
                    ui->textEdit->append("      <depAerodrome>" + depaerod + "</depAerodrome>\n");
                    out << "            <arrAerodrome>" + arraerod + "</arrAerodrome>\n";
                    ui->textEdit->append("      <arrAerodrome>" + arraerod + "</arrAerodrome>\n");
                    out << "        </flightKey>\n";
                    ui->textEdit->append("  </flightKey>\n");
                    out << "        <acType>" + aircraftType + "</acType>\n";
                    ui->textEdit->append("  <acType>" + aircraftType + "</acType>\n");
                    out << "        <registration>" + registration + "</registration>\n";
                    ui->textEdit->append("  <registration>" + registration + "</registration>\n");
                    out << "        <wtc>" + wtc + "</wtc>\n";
                    ui->textEdit->append("  <wtc>" + wtc + "</wtc>\n");
                    out << "        <sid>" + SID + "</sid>\n";
                    ui->textEdit->append("  <sid>" + SID + "</sid>\n");
                    out << "        <star>" + STAR + "</star>\n";
                    ui->textEdit->append("  <star>" + STAR + "</star>\n");
                    out << "        <depInfo>\n";
                    ui->textEdit->append("  <depInfo>\n");

                    out << "            <eobt>\n";
                    ui->textEdit->append("      <eobt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(EOBT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx2("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx2("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx2.indexIn(EOBT);
                        QStringList list2 = rx2.capturedTexts();
                        QStringList::iterator it2 = list2.begin();
                        int contador2 = 0;
                        while (it2 != list2.end())
                        {
                            if (contador2 ==1)
                            {
                                hora = *it2;
                            }
                            else if (contador2 ==2)
                            {
                                minutos = *it2;
                            }
                            ++contador2;
                            ++it2;
                        }
                        // Convertimos a QDateTime
                        ui->textEdit->append("EOBT previa conversion: [" + anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00]\n");
                        QDateTime dtEOBT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochEOBT = QString::number(dtEOBT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochEOBT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochEOBT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(EOBT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </eobt>\n";
                    ui->textEdit->append("      </eobt>\n");

                    out << "            <sobt>\n";
                    ui->textEdit->append("      <sobt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(SOBT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        //QRegExp rx3("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx3("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx3.indexIn(SOBT);
                        QStringList list3 = rx3.capturedTexts();
                        QStringList::iterator it3 = list3.begin();
                        int contador3 = 0;
                        while (it3 != list3.end())
                        {
                            if (contador3 ==1)
                            {
                                hora = *it3;
                            }
                            else if (contador3 ==2)
                            {
                                minutos = *it3;
                            }
                            ++contador3;
                            ++it3;
                        }
                        ui->textEdit->append("SOBT previa conversion: [" + anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00]\n");
                        // Convertimos a QDateTime
                        QDateTime dtSOBT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochSOBT = QString::number(dtSOBT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochSOBT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochSOBT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(SOBT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </sobt>\n";
                    ui->textEdit->append("      </sobt>\n");

                    out << "            <tobt>\n";
                    ui->textEdit->append("      <tobt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(TOBT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx4("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx4("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx4.indexIn(TOBT);
                        QStringList list4 = rx4.capturedTexts();
                        QStringList::iterator it4 = list4.begin();
                        int contador4 = 0;
                        while (it4 != list4.end())
                        {
                            if (contador4 ==1)
                            {
                                hora = *it4;
                            }
                            else if (contador4 ==2)
                            {
                                minutos = *it4;
                            }
                            ++contador4;
                            ++it4;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtTOBT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochTOBT = QString::number(dtTOBT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochTOBT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochTOBT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(TOBT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </tobt>\n";
                    ui->textEdit->append("      </tobt>\n");

                    out << "            <etot>\n";
                    ui->textEdit->append("      <etot>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(ETOT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx5("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx5("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx5.indexIn(ETOT);
                        QStringList list5 = rx5.capturedTexts();
                        QStringList::iterator it5 = list5.begin();
                        int contador5 = 0;
                        while (it5 != list5.end())
                        {
                            if (contador5 ==1)
                            {
                                hora = *it5;
                            }
                            else if (contador5 ==2)
                            {
                                minutos = *it5;
                            }
                            ++contador5;
                            ++it5;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtETOT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochETOT = QString::number(dtETOT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochETOT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochETOT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(ETOT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </etot>\n";
                    ui->textEdit->append("      </etot>\n");

                    out << "            <ttot>\n";
                    ui->textEdit->append("      <ttot>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(TTOT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx6("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx6("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx6.indexIn(TTOT);
                        QStringList list6 = rx6.capturedTexts();
                        QStringList::iterator it6 = list6.begin();
                        int contador6 = 0;
                        while (it6 != list6.end())
                        {
                            if (contador6 ==1)
                            {
                                hora = *it6;
                            }
                            else if (contador6 ==2)
                            {
                                minutos = *it6;
                            }
                            ++contador6;
                            ++it6;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtTTOT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochTTOT = QString::number(dtTTOT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochTTOT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochTTOT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(TTOT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </ttot>\n";
                    ui->textEdit->append("      </ttot>\n");

                    out << "            <stot>\n";
                    ui->textEdit->append("      <stot>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(STOT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx7("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx7("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx7.indexIn(STOT);
                        QStringList list7 = rx7.capturedTexts();
                        QStringList::iterator it7 = list7.begin();
                        int contador7 = 0;
                        while (it7 != list7.end())
                        {
                            if (contador7 ==1)
                            {
                                hora = *it7;
                            }
                            else if (contador7 ==2)
                            {
                                minutos = *it7;
                            }
                            ++contador7;
                            ++it7;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtSTOT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochSTOT = QString::number(dtSTOT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochSTOT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochSTOT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(STOT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </stot>\n";
                    ui->textEdit->append("      </stot>\n");

                    out << "            <atot>\n";
                    ui->textEdit->append("      <atot>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(ATOT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx8("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx8("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx8.indexIn(ATOT);
                        QStringList list8 = rx8.capturedTexts();
                        QStringList::iterator it8 = list8.begin();
                        int contador8 = 0;
                        while (it8 != list8.end())
                        {
                            if (contador8 ==1)
                            {
                                hora = *it8;
                            }
                            else if (contador8 ==2)
                            {
                                minutos = *it8;
                            }
                            ++contador8;
                            ++it8;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtATOT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochATOT = QString::number(dtATOT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochATOT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochATOT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(ATOT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </atot>\n";
                    ui->textEdit->append("      </atot>\n");

                    out << "            <ctot>\n";
                    ui->textEdit->append("      <ctot>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(CTOT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx9("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx9("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx9.indexIn(CTOT);
                        QStringList list9 = rx9.capturedTexts();
                        QStringList::iterator it9 = list9.begin();
                        int contador9 = 0;
                        while (it9 != list9.end())
                        {
                            if (contador9 == 1)
                            {
                                hora = *it9;
                            }
                            else if (contador9 ==2)
                            {
                                minutos = *it9;
                            }
                            ++contador9;
                            ++it9;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtCTOT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochCTOT = QString::number(dtCTOT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochCTOT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochCTOT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(CTOT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </ctot>\n";
                    ui->textEdit->append("      </ctot>\n");

                    //UTOT: New departure time field
                    out << "            <utot>\n";
                    ui->textEdit->append("      <utot>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(UTOT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");

                        QRegExp rxUtot("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rxUtot.indexIn(UTOT);
                        QStringList listUtot = rxUtot.capturedTexts();
                        QStringList::iterator itUtot = listUtot.begin();
                        int contadorUtot = 0;
                        while (itUtot != listUtot.end())
                        {
                            if (contadorUtot == 1)
                            {
                                hora = *itUtot;
                            }
                            else if (contadorUtot ==2)
                            {
                                minutos = *itUtot;
                            }
                            ++contadorUtot;
                            ++itUtot;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtUTOT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochUTOT = QString::number(dtUTOT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochUTOT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochUTOT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(UTOT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </utot>\n";
                    ui->textEdit->append("      </utot>\n");
                    //UTOT: End processing

                    out << "        </depInfo>\n";
                    ui->textEdit->append("  </depInfo>\n");

                    out << "        <arrInfo>\n";
                    ui->textEdit->append("  <arrInfo>\n");

                    out << "            <eldt>\n";
                    ui->textEdit->append("      <eldt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(ELDT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx10("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx10("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx10.indexIn(ELDT);
                        QStringList list10 = rx10.capturedTexts();
                        QStringList::iterator it10 = list10.begin();
                        int contador10 = 0;
                        while (it10 != list10.end())
                        {
                            if (contador10 ==1)
                            {
                                hora = *it10;
                            }
                            else if (contador10 ==2)
                            {
                                minutos = *it10;
                            }
                            ++contador10;
                            ++it10;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtELDT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochELDT = QString::number(dtELDT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochELDT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochELDT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(ELDT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </eldt>\n";
                    ui->textEdit->append("      </eldt>\n");

                    out << "            <tldt>\n";
                    ui->textEdit->append("      <tldt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(TLDT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx11("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx11("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx11.indexIn(TLDT);
                        QStringList list11 = rx11.capturedTexts();
                        QStringList::iterator it11 = list11.begin();
                        int contador11 = 0;
                        while (it11 != list11.end())
                        {
                            if (contador11 ==1)
                            {
                                hora = *it11;
                            }
                            else if (contador11 ==2)
                            {
                                minutos = *it11;
                            }
                            ++contador11;
                            ++it11;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtTLDT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochTLDT = QString::number(dtTLDT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochTLDT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochTLDT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(TLDT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </tldt>\n";
                    ui->textEdit->append("      </tldt>\n");

                    out << "            <aldt>\n";
                    ui->textEdit->append("      <aldt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(ALDT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx12("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx12("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx12.indexIn(ALDT);
                        QStringList list12 = rx12.capturedTexts();
                        QStringList::iterator it12 = list12.begin();
                        int contador12 = 0;
                        while (it12 != list12.end())
                        {
                            if (contador12 ==1)
                            {
                                hora = *it12;
                            }
                            else if (contador12 ==2)
                            {
                                minutos = *it12;
                            }
                            ++contador12;
                            ++it12;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtATLDT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochALDT = QString::number(dtATLDT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochALDT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochALDT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(ALDT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </aldt>\n";
                    ui->textEdit->append("      </aldt>\n");

                    out << "            <sldt>\n";
                    ui->textEdit->append("      <sldt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(SLDT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx13("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx13("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx13.indexIn(SLDT);
                        QStringList list13 = rx13.capturedTexts();
                        QStringList::iterator it13 = list13.begin();
                        int contador13 = 0;
                        while (it13 != list13.end())
                        {
                            if (contador13 ==1)
                            {
                                hora = *it13;
                            }
                            else if (contador13 ==2)
                            {
                                minutos = *it13;
                            }
                            ++contador13;
                            ++it13;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtSLDT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochSLDT = QString::number(dtSLDT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochSLDT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochSLDT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(SLDT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </sldt>\n";
                    ui->textEdit->append("      </sldt>\n");

                    out << "            <sibt>\n";
                    ui->textEdit->append("      <sibt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(SIBT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");
                        // QRegExp rx15("([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])");
                        QRegExp rx15("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rx15.indexIn(SIBT);
                        QStringList list15 = rx15.capturedTexts();
                        QStringList::iterator it15 = list15.begin();
                        int contador15 = 0;
                        while (it15 != list15.end())
                        {
                            if (contador15 ==1)
                            {
                                hora = *it15;
                            }
                            else if (contador15 ==2)
                            {
                                minutos = *it15;
                            }
                            ++contador15;
                            ++it15;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtSIBT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochSIBT = QString::number(dtSIBT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochSIBT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochSIBT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(SIBT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </sibt>\n";
                    ui->textEdit->append("      </sibt>\n");

                    //ULDT: New departure time field
                    out << "            <uldt>\n";
                    ui->textEdit->append("      <uldt>\n");
                    out << "                <value>\n";
                    ui->textEdit->append("          <value>\n");
                    if(ULDT.compare("")!=0)
                    {
                        // Conversion hora
                        // Sacamos los datos de la hora
                        QString hora, minutos = QString("");

                        QRegExp rxUldt("([0-9]+):([0-9]+)(:([0-9]+))?");
                        rxUldt.indexIn(ULDT);
                        QStringList listUldt = rxUldt.capturedTexts();
                        QStringList::iterator itUldt = listUldt.begin();
                        int contadorUldt = 0;
                        while (itUldt != listUldt.end())
                        {
                            if (contadorUldt == 1)
                            {
                                hora = *itUldt;
                            }
                            else if (contadorUldt ==2)
                            {
                                minutos = *itUldt;
                            }
                            ++contadorUldt;
                            ++itUldt;
                        }
                        // Convertimos a QDateTime
                        QDateTime dtULDT = QDateTime::fromString(anyo + "-" + mes + "-" + dia + " " + hora + ":" + minutos + ":00" , "yyyy-MM-dd hh:mm:ss");
                        QString epochULDT = QString::number(dtULDT.toMSecsSinceEpoch()/1000);

                        out << "                    <sec>" + epochULDT + "</sec>\n";
                        ui->textEdit->append("              <sec>" + epochULDT + "</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    else
                    {
                        out << "                    <sec>0</sec>\n";
                        ui->textEdit->append("              <sec>0</sec>\n");
                        out << "                    <usec>0</usec>\n";
                        ui->textEdit->append("              <usec>0</usec>\n");
                    }
                    out << "                </value>\n";
                    ui->textEdit->append("          </value>\n");
                    if(ULDT.compare("")!=0)
                    {
                        out << "                <valid>1</valid>\n";
                        ui->textEdit->append("          <valid>1</valid>\n");
                    }
                    else
                    {
                        out << "                <valid>0</valid>\n";
                        ui->textEdit->append("          <valid>0</valid>\n");
                    }
                    out << "            </uldt>\n";
                    ui->textEdit->append("      </uldt>\n");
                    //UTOT: End processing


                    out << "        </arrInfo>\n";
                    ui->textEdit->append("  </arrInfo>\n");

                    // Finalizamos escritura de elemento XML
                    out << "    </flightPlan>\n";
                    ui->textEdit->append("</flightPlan>\n");
                }
                row++;
            }

            out << "</intentionalDemand>\n";

            out << "</flightPlans>";
            fileDemandXML.close();

            ui->textEdit->append("\n Demand XML file generated.\n");

            QApplication::restoreOverrideCursor();

            return true;
        }
        else
        {
            ui->textEdit->append("Demand XML file can't be created.\n");
            QApplication::restoreOverrideCursor();
            return false;
        }
    }
    else
    {
        ui->textEdit->append("Demand Excel file can't be opened.\n");
        ui->textEdit->append(db.lastError().text() + "\n");
        QApplication::restoreOverrideCursor();
        return false;
    }

}
