#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore/QDateTime>
#include <QFileDialog>
#include <QDir>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QTextStream>
#include <QSqlError>
#include <QDateTime>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    bool setExcelFileName();
    bool setXMLDirName();
    bool generateXMLFile();

private:
    Ui::MainWindow *ui;
    QString _excelFileName;
    QString _XMLDirFileName;
};

#endif // MAINWINDOW_H
