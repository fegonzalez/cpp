/*
 * LpwHmiCommon.h
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#ifndef LPCHMICOMMON_H_
#define LPCHMICOMMON_H_

class LpcHmiCommon
{


public:
    enum enumTypeSchedule
       {
          ACTIVE,
          OPTIMAL
       };


};



#endif /* C___SRC_RTP_RTPHMI_LIB_WINDOWS_INC_LPWHMICOMMON_H_ */
