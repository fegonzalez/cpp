/*
 * LpmodHmiAirportScheduleModel.cc
 *
 *  Created on: Oct 1, 2018
 *      Author: srperez
 */
#include <iostream>

#include "LpmodHmiAirportScheduleModel.h"
#include <QFont>
#include <QColor>
#include <QSize>


LpmodHmiAirportScheduleModel::LpmodHmiAirportScheduleModel()
        : QAbstractTableModel()
{
	complexity = true;
	simOps = false;
	totalMov = false;
}

int LpmodHmiAirportScheduleModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
	return 4; // 1 row for the timeline + number of mrtm
}

int LpmodHmiAirportScheduleModel::columnCount(const QModelIndex &parent) const
{
//    Q_UNUSED(parent);
//    if (runwaySystemList.size() == 0)
//    {
//        return 0;
//    }
//
//    return ConstantsRmanHmi::numberOfIntervals;
	return 16; // number or intervals of timeline
}

bool LpmodHmiAirportScheduleModel::setdata(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole)
{
	return setData(index, value, role);
}



bool LpmodHmiAirportScheduleModel::insertColumns(int column,
                                     int count,
                                     const QModelIndex &parent)
{
    beginInsertColumns(parent, column, column + count - 1);
    endInsertColumns();
    return true;
}

bool LpmodHmiAirportScheduleModel::removeColumns(int column,
                                     int count,
                                     const QModelIndex &parent)
{
    beginRemoveColumns(parent, column, column + count - 1);
    endRemoveColumns();
    return true;
}

void LpmodHmiAirportScheduleModel::checkComplexity()
{
	complexity = true;
	simOps = false;
	totalMov = false;
}

void LpmodHmiAirportScheduleModel::checkSimOps()
{
	simOps = true;
	complexity = false;
	totalMov = false;
}

void LpmodHmiAirportScheduleModel::checkTotalMov()
{
	totalMov = true;
	complexity = false;
	simOps = false;
}
