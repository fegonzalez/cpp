// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 23 Aug 09:00:19 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpmodHmiGraphicTotalMovModel.h"
#include <QDateTime>

LpmodHmiGraphicTotalMovModel::LpmodHmiGraphicTotalMovModel():
LpmodHmiGenericGraphicModel()
{

}

QVariant LpmodHmiGraphicTotalMovModel::data(const QModelIndex &index, int role) const
{
    if((!index.isValid()) ||
            (index.row() >= rowCount(index)))
    {
        return QVariant();
    }

    if(role == Qt::DisplayRole)
    {
        if(index.column() == 0)
        {
            //return "06:00";
            QString modelDateTime = QString::fromStdString("0600/151117");

            //takes 1900 by default with 2 digit year
            QDateTime dateTimeToShow = QDateTime::fromString(modelDateTime, "HHmm/ddMMyy").addYears(100);

            return dateTimeToShow.toString("dd/MM/yyyy HH:mm");
        }

        else if(index.column() == 1)
        {
            return 1+rand()%(9-1);

        }

        return QVariant();
    }
    else if(role == Qt::BackgroundRole)
    {
        if(index.column() == 1)
        {
            return QColor("#58A0D0");
        }
    }
    else if(role == Qt::SizeHintRole)
    {
        if(index.column() == 1)
        {
            //const Hmi::Demand_ForecastList& forecast = intervalListRman.getDemandForecastList();
            //int intentionalDemand = forecast.getDemandForecast(index.row()).getDemandForecast().getOverall();
            LpmodHmiHtmlUtils htmlString;
            htmlString.openHtml();
            htmlString.openTable("225");
            htmlString.addRow("ARRIVALS", 12, "flights");
            htmlString.addRow("DEPARTURES", 7, "flights");
            htmlString.closeTable();
            htmlString.closeHtml();
            return htmlString;
        }


    }
    else if (role == Qt::EditRole)
    {
        if (index.column() == 1)
        {
            return QString("COMPLEXITY");
        }
    }
    return QVariant();
}
