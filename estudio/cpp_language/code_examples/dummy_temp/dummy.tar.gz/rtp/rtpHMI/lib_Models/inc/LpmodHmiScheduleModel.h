/*
 * LpmodHmiScheduleModel.h
 *
 *  Created on: Oct 1, 2018
 *      Author: srperez
 */

#ifndef LPMODHMISCHEDULEMODEL_H_
#define LPMODHMISCHEDULEMODEL_H_

#include <QAbstractTableModel>

class LpmodHmiScheduleModel : public QAbstractTableModel
{

public:
	LpmodHmiScheduleModel();
	virtual ~LpmodHmiScheduleModel(){}
	int rowCount(const QModelIndex &parent) const;
	int columnCount(const QModelIndex &parent) const;
	virtual QVariant data(const QModelIndex &index, int role) const override = 0;
	bool insertColumns(int column, int count, const QModelIndex &parent);
	bool removeColumns(int column, int count, const QModelIndex &parent);
	virtual bool setdata(const QModelIndex &index, const QVariant &value, int role);

};



#endif /* LPMODHMISCHEDULEMODEL_H_ */
