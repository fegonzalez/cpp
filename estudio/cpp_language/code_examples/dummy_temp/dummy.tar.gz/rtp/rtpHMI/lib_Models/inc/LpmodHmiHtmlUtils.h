// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):     icima
 Created:   1/12/2014 9:36:26 2014
 Release:   $Revision$
 Modified:  $Date$
 Path:      $Source$

 (c) Copyright 2013, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPMODHMIHTMLUTILS_H_
#define LPMODHMIHTMLUTILS_H_

#include <QString>

class LpmodHmiHtmlUtils : public QString
{
    public:
    LpmodHmiHtmlUtils();
    virtual ~LpmodHmiHtmlUtils(){};
    void openHtml();
    void closeHtml();
    void openTable(QString lenght);
    void closeTable();
    void addRow(QString label);
    void addRow(QString label, int value);
    void addRow(QString label, QString value, QString unit);
    void addRow(QString label, int value, QString unit);

};

#endif /* LPMODHMIHTMLUTILS_H_ */
