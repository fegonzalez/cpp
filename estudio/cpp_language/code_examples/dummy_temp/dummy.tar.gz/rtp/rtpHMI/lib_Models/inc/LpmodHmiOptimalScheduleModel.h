/*
 * LpmodHmiActiveSchedule.h
 *
 *  Created on: Oct 4, 2018
 *      Author: srperez
 */

#ifndef LPMODHMIOPTIMALSCHEDULE_H_
#define LPMODHMIOPTIMALSCHEDULE_H_

#include "LpmodHmiScheduleModel.h"
#include "LpdHmiConfigurationHmiParameters.h"

class LpmodHmiOptimalScheduleModel : public LpmodHmiScheduleModel
{

public:
	LpmodHmiOptimalScheduleModel();
	virtual ~LpmodHmiOptimalScheduleModel(){}
	virtual QVariant data(const QModelIndex &index, int role) const override;

};



#endif /* C___SRC_RTP_RTPHMI_LIB_MODELS_INC_LPMODHMIACTIVESCHEDULE_H_ */
