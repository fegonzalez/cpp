// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 23 Aug 08:58:57 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPMODHMIGRAPHICSIMOPSMODEL_H_
#define LPMODHMIGRAPHICSIMOPSMODEL_H_

#include "LpmodHmiGenericGraphicModel.h"

class LpmodHmiGraphicSimOpsModel : public LpmodHmiGenericGraphicModel
{


public:
    LpmodHmiGraphicSimOpsModel();
    virtual ~LpmodHmiGraphicSimOpsModel(){}

    virtual QVariant data(const QModelIndex &index, int role) const override ;

protected:
};



#endif /* LPMODHMIGRAPHICSIMOPSMODEL_H_ */
