/*
 * LpmodHmiAirportActiveScheduleModel.h
 *
 *  Created on: Oct 5, 2018
 *      Author: srperez
 */

#ifndef LPMODHMIAIRPORTACTIVESCHEDULEMODEL_H_
#define LPMODHMIAIRPORTACTIVESCHEDULEMODEL_H_


#include "LpmodHmiAirportScheduleModel.h"
#include "LpdHmiConfigurationHmiParameters.h"
#include <LpdComponent.h>
#include "LpmodPartition.h"

class LpmodHmiAirportActiveScheduleModel : public LpmodHmiAirportScheduleModel
{

public:
	LpmodHmiAirportActiveScheduleModel(QString);
	virtual ~LpmodHmiAirportActiveScheduleModel(){}
	virtual QVariant data(const QModelIndex &index, int role) const override;

private:
	QString _mrtm;
};



#endif /* C___SRC_RTP_RTPHMI_LIB_MODELS_INC_LPMODHMIAIRPORTACTIVESCHEDULEMODEL_H_ */
