// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 02 Aug 10:42:52 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPMODHMIGENERICGRAPHICMODEL_H_
#define LPMODHMIGENERICGRAPHICMODEL_H_


#include <QAbstractTableModel>
#include "LpmodHmiHtmlUtils.h"
#include <QColor>


class LpmodHmiGenericGraphicModel : public QAbstractTableModel
{


public:
    LpmodHmiGenericGraphicModel();
    virtual ~LpmodHmiGenericGraphicModel(){}

    int rowCount(const QModelIndex &) const ;
    int columnCount(const QModelIndex &) const ;
    bool insertRows(int row, int count, const QModelIndex &parent);
    bool removeRows(int row, int count, const QModelIndex &parent);

    virtual QVariant data(const QModelIndex &index, int role) const override = 0;
    bool setData(const QModelIndex &index, const QVariant &value, int role);
    void numberOfIntervals();

    QString getValueToShow();


protected:
    int numIntervals;

};


#endif /* LPMODHMIGENERICGRAPHICMODEL_H_ */
