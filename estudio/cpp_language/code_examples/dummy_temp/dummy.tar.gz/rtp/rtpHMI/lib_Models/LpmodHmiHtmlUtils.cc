#include "LpmodHmiHtmlUtils.h"

LpmodHmiHtmlUtils::LpmodHmiHtmlUtils()
{
}

void LpmodHmiHtmlUtils::openHtml()
{
    append("<html>");
}

void LpmodHmiHtmlUtils::closeHtml()
{
    append("</html>");
}

void LpmodHmiHtmlUtils::openTable(QString length)
{
    append("<table border=\"0\"width=\"" + length + "\">");
}

void LpmodHmiHtmlUtils::closeTable()
{
    append("</table>");
}

void LpmodHmiHtmlUtils::addRow(QString text)
{
    append("<tr>");
    append("<td valign=\"top\" >");
    append("<b>" + text + "</b>");
    append("</td>");
    append("</tr>");
}

void LpmodHmiHtmlUtils::addRow(QString label, QString value, QString unit)
{
    append("<tr>");
    append("<td valign=\"top\" >");
    append("<b>" + label + "</b>");
    append("</td>");
    append("<td> = </td>");
    append("<td>");
    append(value);
    append(" ");
    append(unit);
    append("</td>");
    append("</tr>");
}

void LpmodHmiHtmlUtils::addRow(QString label, int value)
{
    append("<tr>");
    append("<td valign=\"top\" >");
    append("<b>" + label + "</b>");
    append("</td>");
    append("<td> = </td>");
    append("<td>");
    append(QString::number(value));
    append(" ");
    append("</td>");
    append("</tr>");
}

void LpmodHmiHtmlUtils::addRow(QString label, int  value, QString unit)
{
    QString valueString = QString::number(value);
    addRow(label, valueString, unit);
}
