#include <LpmodFlightPlanModel.h>

QVariant LpmodFlightPlanModel::data(const QModelIndex &index, int role) const
{
    if (role == Qt::BackgroundColorRole)
    {
        switch (index.column()) {
        case 0:
            return QColor("#EBEBEB");
        case 1:
            return QColor("#EBEBEB");
        case 7:
            return QColor("#EBEBEB");
        case 8:
            return QColor("#EBEBEB");
        default:
            return {};
        };
    }

	if (role == Qt::TextAlignmentRole)
	    return Qt::AlignCenter;

	if (role != Qt::DisplayRole && role != Qt::EditRole)
		return {};

	const auto & fp = m_data[index.row()];
	switch (index.column()) {
	case 0:
		return fp.module();
	case 1:
		return fp.status();
	case 2:
		return fp.callsign();
	case 3:
		return fp.ac_type();
	case 4:
	    return fp.vfr_ifr();
	case 5:
		return fp.departure_aerodrome();
	case 6:
		return fp.etot();
	case 7:
	    return fp.itot();
	case 8:
		return fp.eldt();
	case 9:
		return fp.arrival_aerodrome();
	default:
		return {};
	};
}

QVariant LpmodFlightPlanModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role == Qt::SizeHintRole)
        return QSize(0, 30);

    if (role == Qt::BackgroundColorRole)
    {
        switch (section) {
        case 0:
            return QColor("#EBEBEB");
        case 1:
            return QColor("#EBEBEB");
        case 7:
            return QColor("#EBEBEB");
        case 8:
            return QColor("#EBEBEB");
        default:
            return {};
        };
    }

	if (orientation != Qt::Horizontal || role != Qt::DisplayRole)
		return {};

	switch (section) {
	case 0:
		return "Module";
	case 1:
		return "Status";
	case 2:
		return "Callsign";
	case 3:
		return "A/C Type";
	case 4:
	    return "VFR/IFR";
	case 5:
		return "ADEP";
	case 6:
		return "ETOT";
	case 7:
	    return "ITOT";
	case 8:
		return "ELDT";
	case 9:
		return "ADES";
	default:
		return {};
	}
}

void LpmodFlightPlanModel::append(const LpmodFlightPlan & fp)
{
	beginInsertRows( { }, m_data.count(), m_data.count());
	m_data.append(fp);
	endInsertRows();
}
