// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 23 Aug 08:58:57 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPMODHMIGRAPHICTOTALMOVMODEL_H_
#define LPMODHMIGRAPHICTOTALMOVMODEL_H_

#include "LpmodHmiGenericGraphicModel.h"

class LpmodHmiGraphicTotalMovModel : public LpmodHmiGenericGraphicModel
{


public:
    LpmodHmiGraphicTotalMovModel();
    virtual ~LpmodHmiGraphicTotalMovModel(){}

    virtual QVariant data(const QModelIndex &index, int role) const override ;

protected:
};



#endif /* LPMODHMIGRAPHICTOTALMOVMODEL_H_ */
