// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 02 Aug 10:45:29 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------


#include "LpmodHmiGenericGraphicModel.h"
#include "LctimTimeUtils.h"

LpmodHmiGenericGraphicModel::LpmodHmiGenericGraphicModel():
    QAbstractTableModel()
{
    //intervalListRman = LrdHmiDemandObservable::GetInstance()->getDemand();
    numIntervals = 50;
}



int LpmodHmiGenericGraphicModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return numIntervals;
}

int LpmodHmiGenericGraphicModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return 2;
}



void LpmodHmiGenericGraphicModel::numberOfIntervals()
{
    /*
    if (intervalListRman.getDemandForecastList().getDemandForecastVector().size()
            == 0)
    {
        numIntervals = 0;
    }
    else
    {
    */
    //   numIntervals = 39;//ConstantsRmanHmi::numberOfIntervals;
    //}
}

bool LpmodHmiGenericGraphicModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    Q_UNUSED(value);
    Q_UNUSED(role);
    Q_UNUSED(index);

    if(numIntervals)
     {
        removeRows(0, numIntervals, QModelIndex());
     }
    //intervalListRman = LrdHmiDemandObservable::GetInstance()->getDemand();
    numberOfIntervals();
    if(numIntervals)
    {
        insertRows(0, numIntervals, QModelIndex());
    }
    emit dataChanged(QModelIndex(), QModelIndex());
    return true;
}

bool LpmodHmiGenericGraphicModel::insertRows(int row,
                                            int count,
                                            const QModelIndex &parent)
{

    beginInsertRows(parent, row, row + count - 1);
    endInsertRows();
    return true;
}

bool LpmodHmiGenericGraphicModel::removeRows(int row,
                                            int count,
                                            const QModelIndex &parent)
{

    Q_UNUSED(parent);
    beginRemoveRows(QModelIndex(), row, row + count - 1);
    endRemoveRows();
    return true;
}

