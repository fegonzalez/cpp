// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 23 Aug 08:58:57 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPMODHMIGRAPHICVFRMODEL_H_
#define LPMODHMIGRAPHICVFRMODEL_H_

#include "LpmodHmiGenericGraphicModel.h"

class LpmodHmiGraphicVFRModel : public LpmodHmiGenericGraphicModel
{


public:
    LpmodHmiGraphicVFRModel();
    virtual ~LpmodHmiGraphicVFRModel(){}

    virtual QVariant data(const QModelIndex &index, int role) const override ;

protected:
};



#endif /* LPMODHMIGRAPHICVFRMODEL_H_ */
