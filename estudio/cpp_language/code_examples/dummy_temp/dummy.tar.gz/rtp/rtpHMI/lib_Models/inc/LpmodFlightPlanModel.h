/*
 * LpmodFlightPlanModel.h
 *
 *  Created on: Jun 4, 2018
 *      Author: srperez
 */

#ifndef _LPMODFLIGHTPLANMODEL_H_
#define _LPMODFLIGHTPLANMODEL_H_

#include <QtWidgets>
#include "LpmodFlightPlan.h"

class LpmodFlightPlanModel : public QAbstractTableModel {
   QList<LpmodFlightPlan> m_data;

public:
   LpmodFlightPlanModel(QObject * parent = {}) : QAbstractTableModel{parent} {}

   int rowCount(const QModelIndex &) const override { return m_data.count(); }
   int columnCount(const QModelIndex &) const override { return 10; }

   QVariant data(const QModelIndex &index, int role) const override;
   QVariant headerData(int section, Qt::Orientation orientation, int role) const override;
   void append(const LpmodFlightPlan & fp);
   int getRows()  { return m_data.count(); }
};

#endif /* _LPMFLIGHTPLAN_H_ */
