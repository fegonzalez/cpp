/*
 * LpmodHmiActiveSchedule.cc
 *
 *  Created on: Oct 4, 2018
 *      Author: srperez
 */


#include "LpmodHmiScheduleModel.h"
#include "LpmodHmiOptimalScheduleModel.h"
#include "LpcfgConfigurationHmiParameters.h"
#include <QFont>
#include <QSize>
#include <QColor>

LpmodHmiOptimalScheduleModel::LpmodHmiOptimalScheduleModel()
        : LpmodHmiScheduleModel()
{


}

QVariant LpmodHmiOptimalScheduleModel::data(const QModelIndex &index, int role) const
{

	if ((!index.isValid()) || (index.row() >= rowCount(index)))
	{
		return QVariant();
	}

	QStringList list {"10:00", "10:20", "10:40", "11:00", "11:20", "11:40", "12:00", "12:20", "12:40", "13:00", "13:20", "13:40", "14:00", "14:20", "14:40", "15:00"};
	if (role == Qt::DisplayRole)
	{
		if (index.row() == 0 && index.column() > 0)
		{
			for(int i = 0; i < list.size(); i++)
			{
				if(index.column() == i)
					return list[i];
			}
		}

		if(index.column() == 0)
		{
			if(index.row() == 1)
				return QString("MRTM 1");
			if(index.row() == 2)
				return QString("MRTM 2");
			if(index.row() == 3)
				return QString("MRTM 3");
			if(index.row() == 4)
				return QString("MRTM 4");
			if(index.row() == 5)
				return QString("MRTM 5");
			if(index.row() == 6)
				return QString("MRTM 6");
		}
	}

	else if (role == Qt::FontRole)
	{
		if (index.column() == 0)
		{
			QFont boldFont;
			boldFont.setBold(true);
			return boldFont;
		}
	}
/*
	if (role == Qt::BackgroundRole)
	{
		if (index.row() == 1)
		{
			if(index.column() == 3)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorWarningThreshold()));
		}

		if (index.row() == 2)
		{
			if(index.column() == 1)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}

		if (index.row() == 3)
		{
			if(index.column() == 6)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(index.column() == 8)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(index.column() == 9)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorWarningThreshold()));
		}


	}
*/
	else if (role == Qt::TextAlignmentRole)
	{
		return Qt::AlignCenter;
	}

    return QVariant();
}
