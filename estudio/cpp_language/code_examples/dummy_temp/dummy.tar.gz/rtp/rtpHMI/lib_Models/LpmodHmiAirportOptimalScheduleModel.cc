/*
 * LpmodHmiAirportOptimalScheduleModel.cc
 *
 *  Created on: Oct 5, 2018
 *      Author: srperez
 */

#include "LpmodHmiAirportScheduleModel.h"
#include "LpmodHmiAirportOptimalScheduleModel.h"
#include <QFont>
#include <QSize>
#include <QColor>

LpmodHmiAirportOptimalScheduleModel::LpmodHmiAirportOptimalScheduleModel(QString mrtm)
        : LpmodHmiAirportScheduleModel()
{
	_mrtm = mrtm;
}

QVariant LpmodHmiAirportOptimalScheduleModel::data(const QModelIndex &index, int role) const
{
	QStringList list {"10:00", "10:20", "10:40", "11:00", "11:20", "11:40", "12:00", "12:20", "12:40", "13:00", "13:20", "13:40", "14:00", "14:20", "14:40", "15:00"};
	if ((!index.isValid()) || (index.row() >= rowCount(index)))
	{
		return QVariant();
	}

	if (role == Qt::DisplayRole)
	{
		if (index.row() == 0 && index.column() > 0)
		{
			for(int i = 0; i < list.size(); i++)
			{
				if(index.column() == i)
					return list[i];
			}
		}

		if(index.column() == 0)
		{
			if(index.row() == 0)
				return QString(_mrtm);
			if(index.row() == 1)
			{
				if(_mrtm == "MRTM 1")
					return QString("ENNA");
				if(_mrtm == "MRTM 2")
					return QString("ENHM");
				if(_mrtm == "MRTM 3")
					return QString("ENRS");
			}
			if(index.row() == 2)
			{
				if(_mrtm == "MRTM 1")
					return QString("ENBO");
				if(_mrtm == "MRTM 2")
					return QString("ENKH");
				if(_mrtm == "MRTM 3")
					return QString("ENBL");
			}
			if(index.row() == 3)
			{
				if(_mrtm == "MRTM 1")
					return QString("ENWQ");
				if(_mrtm == "MRTM 2")
					return QString("ENTR");
				if(_mrtm == "MRTM 3")
					return QString("ENML");
			}
		}
	}

	else if (role == Qt::FontRole)
    {
		if (index.column() == 0)
		{
			QFont boldFont;
			boldFont.setBold(true);
			return boldFont;
		}
    }

	else if (role == Qt::TextAlignmentRole)
	{
		return Qt::AlignCenter;
	}

	if (role == Qt::BackgroundRole)
	{
		if (index.row() == 1)
		{
			if(_mrtm == "MRTM 1" && index.column() == 3)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 3" && index.column() == 6)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}

		if (index.row() == 2)
		{
			if(_mrtm == "MRTM 1" && index.column() == 3)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 2" && index.column() == 1)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 3" && index.column() == 8)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 3" && index.column() == 9)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}

		if (index.row() == 3)
		{
			if(_mrtm == "MRTM 3" && index.column() == 9)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}
	}

	if(role == Qt::ToolTipRole)
	{
		if(complexity)
		{
			if(_mrtm == "MRTM 3" && index.row() == 3 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENML");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("Complexity: 0.9");
				htmlString.addRow("Complexity of the MRTM 3: 2.1");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}

			if(_mrtm == "MRTM 3" && index.row() == 2 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENBL");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("Complexity: 0.5");
				htmlString.addRow("Complexity of the MRTM 3: 1.7");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}
		}

		else if(simOps)
		{
			if(_mrtm == "MRTM 3" && index.row() == 3 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENML");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("SimOps: 0.9");
				htmlString.addRow("SimOps of the MRTM 3: 2.1");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}
		}

		else if(totalMov)
		{
			if(_mrtm == "MRTM 3" && index.row() == 3 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENML");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("TotalMov: 0.9");
				htmlString.addRow("TotalMov of the MRTM 3: 2.1");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}
		}
	}

    return QVariant();
}
