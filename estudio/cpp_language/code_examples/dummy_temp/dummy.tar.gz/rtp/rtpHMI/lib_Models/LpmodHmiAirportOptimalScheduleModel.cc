/*
 * LpmodHmiAirportOptimalScheduleModel.cc
 *
 *  Created on: Oct 5, 2018
 *      Author: srperez
 */

#include "LpmodHmiAirportScheduleModel.h"
#include "LpmodHmiAirportOptimalScheduleModel.h"
#include <QFont>
#include <QSize>
#include <QColor>

LpmodHmiAirportOptimalScheduleModel::LpmodHmiAirportOptimalScheduleModel(QString mrtm)
        : LpmodHmiAirportScheduleModel()
{
	_mrtm = mrtm;
}

QVariant LpmodHmiAirportOptimalScheduleModel::data(const QModelIndex &index, int role) const
{
	//std::vector<std::string> li = LpschDefaultSchedule::Get().getDefaultSchedule();
	//std::cout << "ssss " << li.size() << std::endl;
	QStringList list {"10:00", "10:20", "10:40", "11:00", "11:20", "11:40", "12:00", "12:20", "12:40", "13:00", "13:20", "13:40", "14:00", "14:20", "14:40", "15:00"};
	if ((!index.isValid()) || (index.row() >= rowCount(index)))
	{
		return QVariant();
	}

	if (role == Qt::DisplayRole)
	{
		if (index.row() == 0 && index.column() > 0)
		{
			for(int i = 0; i < list.size(); i++)
			{
				if(index.column() == i)
					return list[i];
			}
		}

		std::vector<std::string> li = { "ENNA ENRO", "ENBO ENHD", "ENRS ENMH ENHK", "ENRM ENSH ENML", "ENSG ENSS ENNM", "ENBV ENBL"};
		if(index.column() == 0)
		{
			if(index.row() == 0)
				return QString(_mrtm);

			for(unsigned int i = 0; i < li.size(); i++)
			{
				QStringList liA = QString::fromStdString(li.at(i)).split(" ");
				if(index.row() == 1)
				{
					if(_mrtm == "MRTM 1")
						return QString::fromStdString(li.at(0)).split(" ").at(0);
					if(_mrtm == "MRTM 2")
						return QString::fromStdString(li.at(1)).split(" ").at(0);
					if(_mrtm == "MRTM 3")
						return QString::fromStdString(li.at(2)).split(" ").at(0);
					if(_mrtm == "MRTM 4")
						return QString::fromStdString(li.at(3)).split(" ").at(0);
					if(_mrtm == "MRTM 5")
						return QString::fromStdString(li.at(4)).split(" ").at(0);
					if(_mrtm == "MRTM 6")
						return QString::fromStdString(li.at(5)).split(" ").at(0);
				}
				if(index.row() == 2)
				{
					if(_mrtm == "MRTM 1")
						return QString::fromStdString(li.at(0)).split(" ").at(1);
					if(_mrtm == "MRTM 2")
						return QString::fromStdString(li.at(1)).split(" ").at(1);
					if(_mrtm == "MRTM 3")
						return QString::fromStdString(li.at(2)).split(" ").at(1);
					if(_mrtm == "MRTM 4")
						return QString::fromStdString(li.at(3)).split(" ").at(1);
					if(_mrtm == "MRTM 5")
						return QString::fromStdString(li.at(4)).split(" ").at(1);
					if(_mrtm == "MRTM 6")
						return QString::fromStdString(li.at(5)).split(" ").at(1);
				}
				if(index.row() == 3)
				{
					if(QString::fromStdString(li.at(0)).split(" ").size() == 3)
						if(_mrtm == "MRTM 1")
							return QString::fromStdString(li.at(0)).split(" ").at(2);
					if(QString::fromStdString(li.at(1)).split(" ").size() == 3)
						if(_mrtm == "MRTM 2")
							return QString::fromStdString(li.at(1)).split(" ").at(2);
					if(QString::fromStdString(li.at(2)).split(" ").size() == 3)
						if(_mrtm == "MRTM 3")
							return QString::fromStdString(li.at(2)).split(" ").at(2);
					if(QString::fromStdString(li.at(3)).split(" ").size() == 3)
						if(_mrtm == "MRTM 4")
							return QString::fromStdString(li.at(3)).split(" ").at(2);
					if(QString::fromStdString(li.at(4)).split(" ").size() == 3)
						if(_mrtm == "MRTM 5")
							return QString::fromStdString(li.at(4)).split(" ").at(2);
					if(QString::fromStdString(li.at(5)).split(" ").size() == 3)
						if(_mrtm == "MRTM 6")
							return QString::fromStdString(li.at(5)).split(" ").at(2);
				}

			}
		}
	}

	else if (role == Qt::FontRole)
    {
		if (index.column() == 0 || index.row() == 0)
		{
			QFont boldFont;
			boldFont.setBold(true);
			return boldFont;
		}
    }

	else if (role == Qt::TextAlignmentRole)
	{
		return Qt::AlignCenter;
	}
/*
	if (role == Qt::BackgroundRole)
	{
		if (index.row() == 1)
		{
			if(_mrtm == "MRTM 1" && index.column() == 3)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 3" && index.column() == 6)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}

		if (index.row() == 2)
		{
			if(_mrtm == "MRTM 1" && index.column() == 3)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 2" && index.column() == 1)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 3" && index.column() == 8)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
			if(_mrtm == "MRTM 3" && index.column() == 9)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}

		if (index.row() == 3)
		{
			if(_mrtm == "MRTM 3" && index.column() == 9)
				return QColor(QString::fromStdString(LpdHmiConfigurationHmiParameters::GetInstance()->
						getConfigurationHmiParameters().getColorsRtpHmi().getAlarmColors().getColorAlarmThreshold()));
		}
	}

	if(role == Qt::ToolTipRole)
	{
		if(complexity)
		{
			if(_mrtm == "MRTM 3" && index.row() == 3 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENML");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("Complexity: 0.9");
				htmlString.addRow("Complexity of the MRTM 3: 2.1");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}

			if(_mrtm == "MRTM 3" && index.row() == 2 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENBL");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("Complexity: 0.5");
				htmlString.addRow("Complexity of the MRTM 3: 1.7");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}
		}

		else if(simOps)
		{
			if(_mrtm == "MRTM 3" && index.row() == 3 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENML");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("SimOps: 0.9");
				htmlString.addRow("SimOps of the MRTM 3: 2.1");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}
		}

		else if(totalMov)
		{
			if(_mrtm == "MRTM 3" && index.row() == 3 && index.column() == 9)
			{
				LpmodHmiHtmlUtils htmlString;
				htmlString.openHtml();
				htmlString.openTable("225");
				htmlString.addRow("Airport: ENML");
				htmlString.addRow("Period: 10:00-10:00");
				htmlString.addRow("TotalMov: 0.9");
				htmlString.addRow("TotalMov of the MRTM 3: 2.1");
				htmlString.closeTable();
				htmlString.closeHtml();
				return htmlString;
			}
		}
	}
*/

    return QVariant();
}
