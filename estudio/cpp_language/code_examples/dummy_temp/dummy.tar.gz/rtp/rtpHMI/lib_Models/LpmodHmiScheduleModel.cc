/*
 * LpmodHmiScheduleModel.cc
 *
 *  Created on: Oct 1, 2018
 *      Author: srperez
 */
#include "LpmodHmiScheduleModel.h"
#include <QFont>
#include <QSize>
#include <QColor>

LpmodHmiScheduleModel::LpmodHmiScheduleModel()
        : QAbstractTableModel()
{


}

int LpmodHmiScheduleModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
	return 4;
}

int LpmodHmiScheduleModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
//    if (runwaySystemList.size() == 0)
//    {
//        return 0;
//    }
//
//    return ConstantsRmanHmi::numberOfIntervals;
    return 16;
}

bool LpmodHmiScheduleModel::setdata(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole)
{
	return setData(index, value, role);
}

bool LpmodHmiScheduleModel::insertColumns(int column,
                                     int count,
                                     const QModelIndex &parent)
{
    beginInsertColumns(parent, column, column + count - 1);
    endInsertColumns();
    return true;
}

bool LpmodHmiScheduleModel::removeColumns(int column,
                                     int count,
                                     const QModelIndex &parent)
{
    beginRemoveColumns(parent, column, column + count - 1);
    endRemoveColumns();
    return true;
}
