// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 23 Aug 09:00:19 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpmodHmiGraphicComplexityModel.h"
#include "LctimTimeUtils.h"
#include <QDateTime>

LpmodHmiGraphicComplexityModel::LpmodHmiGraphicComplexityModel():
LpmodHmiGenericGraphicModel()
{

}

QVariant LpmodHmiGraphicComplexityModel::data(const QModelIndex &index, int role) const
{
    if((!index.isValid()) ||
            (index.row() >= rowCount(index)))
    {
        return QVariant();
    }

    if(role == Qt::DisplayRole)
    {
        if(index.column() == 0)
        {
            //return "18:10";

            QString modelDateTime = QString::fromStdString("1000/151117");

            //takes 1900 by default with 2 digit year
            QDateTime dateTimeToShow = QDateTime::fromString(modelDateTime, "HHmm/ddMMyy").addYears(100);

            return dateTimeToShow.toString("dd/MM/yyyy HH:mm");
        }

        else if(index.column() == 1)
        {
            return 1+rand()%(9-1);

        }

        return QVariant();
    }
    else if(role == Qt::BackgroundRole)
    {
        if(index.column() == 1)
        {
            return QColor("#94C14B");
        }
    }
    else if(role == Qt::SizeHintRole)
    {
        if(index.column() == 1)
        {
            //const Hmi::Demand_ForecastList& forecast = intervalListRman.getDemandForecastList();
            //int intentionalDemand = forecast.getDemandForecast(index.row()).getDemandForecast().getOverall();
            LpmodHmiHtmlUtils htmlString;
            htmlString.openHtml();
            htmlString.openTable("225");
            htmlString.addRow("Level of complexity", 5);
            htmlString.closeTable();
            htmlString.closeHtml();
            return htmlString;
        }


    }
    else if (role == Qt::EditRole)
    {
        if (index.column() == 1)
        {
            return QString("COMPLEXITY");
        }
    }
    return QVariant();
}
