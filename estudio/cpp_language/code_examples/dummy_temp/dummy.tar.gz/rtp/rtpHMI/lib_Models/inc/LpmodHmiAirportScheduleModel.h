/*
 * LpmodHmiAirportScheduleModel.h
 *
 *  Created on: Oct 1, 2018
 *      Author: srperez
 */

#ifndef LPMODHMIAIRPORTSCHEDULEMODEL_H_
#define LPMODHMIAIRPORTSCHEDULEMODEL_H_


#include <QAbstractTableModel>
#include "LpmodHmiHtmlUtils.h"
#include "LpdHmiConfigurationHmiParameters.h"

class LpmodHmiAirportScheduleModel : public QAbstractTableModel
{

public:
	LpmodHmiAirportScheduleModel();
	virtual ~LpmodHmiAirportScheduleModel(){}
	int rowCount(const QModelIndex &parent) const;
	int columnCount(const QModelIndex &parent) const;
	virtual QVariant data(const QModelIndex &index, int role) const override = 0;
	bool insertColumns(int column, int count, const QModelIndex &parent);
	bool removeColumns(int column, int count, const QModelIndex &parent);
	virtual bool setdata(const QModelIndex &index, const QVariant &value, int role);
	void checkComplexity();
	void checkSimOps();
	void checkTotalMov();
	bool getComplexity() { return complexity; }
	bool getSimOps() { return simOps; }
	bool getTotalMov() { return totalMov; }

protected:
	bool complexity;
	bool simOps;
	bool totalMov;
};



#endif /* LPMODHMIAIRPORTSCHEDULEMODEL_H_ */
