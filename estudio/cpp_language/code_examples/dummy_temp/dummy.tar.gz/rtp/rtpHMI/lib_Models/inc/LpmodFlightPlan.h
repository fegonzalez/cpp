/*
 * LpmodFlightPlan.h
 *
 *  Created on: Jun 4, 2018
 *      Author: srperez
 */

#ifndef RTPHMI_LPMFLIGHTPLAN_H_
#define RTPHMI_LPMFLIGHTPLAN_H_

#include <QtWidgets>

class LpmodFlightPlan {

	QString r_module, r_status, r_callsign, r_actype, r_vfr_ifr,
			r_departure_aerodrome, r_etot, r_itot, r_eldt,
			r_arrival_aerodrome;

public:
	LpmodFlightPlan(const QString & module, const QString & status,
					const QString & callsign, const QString & actype,
					const QString & vfr_ifr, const QString & departure_aerodrome,
					const QString & etot, const QString itot,
					const QString & eldt, const QString & arrival_aerodrome):
			r_module{module}, r_status{status}, r_callsign{callsign},
			r_actype{actype}, r_vfr_ifr{vfr_ifr}, r_departure_aerodrome{departure_aerodrome},
			r_etot{etot}, r_itot{itot}, r_eldt{eldt}, r_arrival_aerodrome{arrival_aerodrome} {}
	~LpmodFlightPlan() {}

	QString module() const { return r_module; }
	QString status() const { return r_status; }
	QString callsign() const { return r_callsign; }
	QString ac_type() const { return r_actype; }
	QString vfr_ifr() const { return r_vfr_ifr; }
	QString departure_aerodrome() const { return r_departure_aerodrome; }
	QString etot() const { return r_etot; }
	QString itot() const { return r_itot; }
	QString eldt() const { return r_eldt; }
	QString arrival_aerodrome() const { return r_arrival_aerodrome; }
};

#endif
