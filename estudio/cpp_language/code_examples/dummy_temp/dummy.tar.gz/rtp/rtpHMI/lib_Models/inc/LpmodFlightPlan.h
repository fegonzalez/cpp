/*
 * LpmodFlightPlan.h
 *
 *  Created on: Jun 4, 2018
 *      Author: srperez
 */

#ifndef RTPHMI_LPMFLIGHTPLAN_H_
#define RTPHMI_LPMFLIGHTPLAN_H_

#include <QtWidgets>

class LpmodFlightPlan {

	QString r_module, r_operation, r_callsign, r_departure_aerodrome,
	r_arrival_aerodrome, r_eobt,  r_eldt, r_itot, r_actype, r_vfr_ifr;

public:
	LpmodFlightPlan(const QString & module, const QString & operation,
					const QString & callsign, const QString & departure_aerodrome,
					const QString & arrival_aerodrome, const QString & eobt,
					const QString & eldt, const QString itot, const QString & actype,
					const QString & vfr_ifr):

			r_module{module}, r_operation{operation}, r_callsign{callsign},
			r_departure_aerodrome{departure_aerodrome}, r_arrival_aerodrome{arrival_aerodrome},
			r_eobt{eobt}, r_eldt{eldt}, r_itot{itot}, r_actype{actype}, r_vfr_ifr{vfr_ifr}
			   {}
	~LpmodFlightPlan() {}

	QString module() const { return r_module; }
	QString operation() const { return r_operation; }
	QString callsign() const { return r_callsign; }
	QString departure_aerodrome() const { return r_departure_aerodrome; }
	QString arrival_aerodrome() const { return r_arrival_aerodrome; }
	QString eobt() const { return r_eobt; }
	QString eldt() const { return r_eldt; }
	QString itot() const { return r_itot; }
	QString ac_type() const { return r_actype; }
	QString vfr_ifr() const { return r_vfr_ifr; }





};

#endif
