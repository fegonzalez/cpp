/*
 * LpmodHmiAirportOptimalScheduleModel.h
 *
 *  Created on: Oct 5, 2018
 *      Author: srperez
 */

#ifndef LPMODHMIAIRPORTOPTIMALSCHEDULEMODEL_H_
#define LPMODHMIAIRPORTOPTIMALSCHEDULEMODEL_H_


#include "LpmodHmiAirportScheduleModel.h"
#include "LpdHmiConfigurationHmiParameters.h"

class LpmodHmiAirportOptimalScheduleModel : public LpmodHmiAirportScheduleModel
{

public:
	LpmodHmiAirportOptimalScheduleModel(QString);
	virtual ~LpmodHmiAirportOptimalScheduleModel(){}
	virtual QVariant data(const QModelIndex &index, int role) const override;

private:
	QString _mrtm;
};



#endif /* C___SRC_RTP_RTPHMI_LIB_MODELS_INC_LPMODHMIAIRPORTOPTIMALSCHEDULEMODEL_H_ */
