#include <iostream>
#include "LpsigSignalsHmi.h"


LpsigSignalsHmi::LpsigSignalsHmi()
{
}

LpsigSignalsHmi::~LpsigSignalsHmi()
{
}

//void LpsSignalsHmi::connectRtpHmi(const RtpMain& w)
//{
//    connect(this,SIGNAL(mySignalDemand()), &w, SLOT(notifyDemand()));
//    connect(this,SIGNAL(mySignalMeteoFore()), &w, SLOT(notifyMeteoFore()));
//    connect(this,SIGNAL(mySignalMeteoNow()), &w, SLOT(notifyMeteoNow()));
//    connect(this,SIGNAL(mySignalOptimalScheduleAndKpis()), &w, SLOT(notifyOptimalScheduleAndKpis()));
//    connect(this,SIGNAL(mySignalScheduleAndKpisWhatIF()), &w, SLOT(notifyScheduleAndKpisWhatIF()));
//    connect(this,SIGNAL(mySignalUpdateActivateScheduleAndKpis()), &w, SLOT(notifyUpdateActivateScheduleAndKpis()));
//    connect(this,SIGNAL(mySignalComparisonSchedulesCalculate()), &w, SLOT(notifyComparisonSchedulesCalculate()));
//}

void LpsigSignalsHmi::fillMeteoThresholds(QString airport)
{
    emit mySignalMeteoThresholds(airport);
}

void LpsigSignalsHmi::openAnalysis()
{
    emit mySignalOpenAnalysis();
}

void LpsigSignalsHmi::openMonitoring()
{
    emit mySignalOpenMonitoring();
}

void LpsigSignalsHmi::openConfiguration()
{
    emit mySignalOpenConfiguration();
}

void LpsigSignalsHmi::emitSignalChangeTabToMeteo()
{
    emit mySignalChangeTabToMeteo();
}

void LpsigSignalsHmi::emitSignalChangeTabToFlightList()
{
    emit mySignalChangeTabToFlightList();
}

void LpsigSignalsHmi::emitSignalChangeTabToSummary()
{
    emit mySignalChangeTabToSummary();
}

void LpsigSignalsHmi::emitSignalDefaultSchedule()
{
    emit mySignalDefaultSchedule();
}

void LpsigSignalsHmi::emitSignalDemand()
{
    emit mySignalDemand();
}

void LpsigSignalsHmi::emitSignalMeteoFore()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug() << "MY SIGNAL METEO FORE --- " << std::endl;
    emit mySignalMeteoFore();
}

void LpsigSignalsHmi::emitSignalMeteo()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug() << "MY SIGNAL METEO NOW --- " << std::endl;
    emit mySignalMeteo();
}

void LpsigSignalsHmi::emitSignalOptimalScheduleAndKpis()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "MY SIGNAL OPTIMAL SCHEDULES AND KPIs --- " << std::endl;
    emit mySignalOptimalScheduleAndKpis();
}

void LpsigSignalsHmi::emitSignalUpdateActivateScheduleAndKpis()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "MY SIGNAL UPDATE ACTIVATE SCHEDULE AND KPIs --- " << std::endl;
    emit mySignalUpdateActivateScheduleAndKpis();
}

void LpsigSignalsHmi::emitSignalScheduleAndKpisWhatIF()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "MY SIGNAL SCHEDULE AND KPIs WHAT IF --- " << std::endl;
    emit mySignalScheduleAndKpisWhatIF();
}

void LpsigSignalsHmi::emitSignalComparisonSchedulesCalculate()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "MY SIGNAL COMPARISON SCHEDULES CALCULATE --- " << std::endl;
    emit mySignalComparisonSchedulesCalculate();
}

void LpsigSignalsHmi::emitSignalScheduleAutomaticDelete()
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "MY SIGNAL SCHEDULE AUTOMATIC DELETE --- " << std::endl;
    emit mySignalScheduleAutomaticDelete();
}
