#ifndef LPSIGSIGNALS_H
#define LPSIGSIGNALS_H

#include <LclogStream.h>

#include <QObject>

class LpsigSignalsHmi : public QObject
{
Q_OBJECT
public:

    static LpsigSignalsHmi& Get(void)
    {
        static LpsigSignalsHmi component;
        return component;
    }

    LpsigSignalsHmi();
    virtual ~LpsigSignalsHmi();

    //void connectRtpHmi(const RtpMain& w);
public slots:
    void fillMeteoThresholds(QString);
    void openAnalysis();
    void openMonitoring();
    void openConfiguration();
    void emitSignalActiveSchedule();
    void emitSignalOptimalSchedule();
    void emitSignalDemand();
    void emitSignalMeteoFore();
    void emitSignalMeteo();
    void emitSignalOptimalScheduleAndKpis(void);
    void emitSignalScheduleAndKpisWhatIF(void);
    void emitSignalUpdateActivateScheduleAndKpis(void);
    void emitSignalComparisonSchedulesCalculate(void);
    void emitSignalScheduleAutomaticDelete(void);
    void emitSignalChangeTabToMeteo();
    void emitSignalChangeTabToFlightList();
    void emitSignalChangeTabToSummary();
    void emitScheduleActivation();

signals:
    void mySignalMeteoThresholds(QString);
    void mySignalOpenAnalysis();
    void mySignalOpenMonitoring();
    void mySignalOpenConfiguration();
    void mySignalActiveSchedule();
    void mySignalOptimalSchedule();
    void mySignalDemand();
    void mySignalMeteoFore();
    void mySignalMeteo();
    void mySignalOptimalScheduleAndKpis(void);
    void mySignalScheduleAndKpisWhatIF(void);
    void mySignalUpdateActivateScheduleAndKpis(void);
    void mySignalComparisonSchedulesCalculate(void);
    void mySignalScheduleAutomaticDelete(void);
    void mySignalChangeTabToMeteo();
    void mySignalChangeTabToFlightList();
    void mySignalChangeTabToSummary();
    void mySignalScheduleActivation();

private:

};

#endif // LPSSIGNALS_H
