#if !defined(__LPI_METEOFORE_EVT__)
#define __LPI_METEOFORE_EVT__

#include <LpiMeteoInfo.h>

class LpiMeteoForeEvt
{
public:

  const LpiUpdateMeteoList & getMeteoFore(void) const {return this->_meteolist;}
  void setMeteoFore(const LpiUpdateMeteoList &meteolist) {this->_meteolist = meteolist;}

private:
  LpiUpdateMeteoList _meteolist;  ///@warning LpiUpdateMeteoList defined in the rtpServer

};

#endif // __LPI_METEOFORE_EVT__
