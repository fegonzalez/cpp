/*
 * LpiDemandEvt.h
 *
 *  Created on: Sep 11, 2018
 *      Author: srperez
 */

#ifndef LPIDEMANDEVT_H_
#define LPIDEMANDEVT_H_

#include <LpiHmiDemand.h>

class LpiHmiDemandEvt
{
public:
   const LpiHmiDemandList& getDemand(void) const {return this->_de;}
   void setDemand(const LpiHmiDemandList &de) {this->_de = de;}
private:
   LpiHmiDemandList _de;
};




#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_EVENTS_INC_LPIDEMANDEVT_H_ */
