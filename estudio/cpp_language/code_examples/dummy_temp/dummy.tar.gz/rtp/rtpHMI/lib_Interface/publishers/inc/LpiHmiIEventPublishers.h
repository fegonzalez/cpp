/*
 * LpiHmiIEventPublishers.h
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#ifndef LPIHMIIEVENTPUBLISHERS_H_
#define LPIHMIIEVENTPUBLISHERS_H_

#include <LpiHmiActivateScheduleEvt.h>
#include "LpiHmiIEventPublisher.h"

typedef LpiHmiIEventPublisher<
   LpiHmiActivateScheduleEvt
> LpiHmiIActivateScheduleEvtPublisher;


#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_PUBLISHERS_INC_LPIHMIIEVENTPUBLISHERS_H_ */
