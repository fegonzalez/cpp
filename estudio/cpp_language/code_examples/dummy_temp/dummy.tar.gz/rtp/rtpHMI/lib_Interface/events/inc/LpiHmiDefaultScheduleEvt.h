/*
 * LpiHmiDefaultScheduleEvt.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPIHMIDEFAULTSCHEDULEEVT_H_
#define LPIHMIDEFAULTSCHEDULEEVT_H_
#include <string>
#include <vector>

class LpiHmiDefaultScheduleEvt
{
public:
   const std::vector<std::vector<std::string>> & getDefaultSchedule(void) const {return this->_defaultSchedule;}
   void setDefaultSchedule(const std::vector<std::vector<std::string>> &defSchedule) {this->_defaultSchedule = defSchedule;}
private:
   std::vector<std::vector<std::string>> _defaultSchedule;
};



#endif /* LPIHMIDEFAULTSCHEDULEEVT_H_ */
