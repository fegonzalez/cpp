#include <iostream>
#include <sstream>
#include <boost/algorithm/string/trim.hpp>

#include "LpiMeteoTimeLineHmi.h"

MeteoInfo::MeteoInfo()
        : wetness(""),
          ilsCategory("")
{
}

MeteoInfo::MeteoInfo(boost::optional<float> horizontalVisibility,
        std::string wetness,
        std::string ilsCategory,
        boost::optional<bool> lvpActivation,
        boost::optional<bool> deicingRequired,
        boost::optional<float> crosswind,
        boost::optional<float> tailwind,
        boost::optional<int> windSpeed,
        boost::optional<int> windDirection)
{
    this->horizontalVisibility = horizontalVisibility;
    this->wetness = boost::algorithm::trim_right_copy(wetness);
    this->ilsCategory = boost::algorithm::trim_right_copy(ilsCategory);
    this->lvpActivation = lvpActivation;
    this->deicingRequired = deicingRequired;
    this->crosswind = crosswind;
    this->tailwind = tailwind;
    this->windSpeed = windSpeed;
    this->windDirection = windDirection;
}

MeteoInfo& MeteoInfo::operator=(const MeteoInfo& source)
{
    if (this != &source)
    {
        horizontalVisibility = source.horizontalVisibility;
        wetness = source.wetness;
        ilsCategory = source.ilsCategory;
        lvpActivation = source.lvpActivation;
        deicingRequired = source.deicingRequired;
        crosswind = source.crosswind;
        tailwind = source.tailwind;
        windSpeed = source.windSpeed;
        windDirection = source.windDirection;
    }

    return *this;
}

std::ostream& operator<<(std::ostream & out, const MeteoInfo & meteo)
{
    MeteoInfo meteoInfoAux = meteo;
    return out;
}

LpiMeteoTimeLineHmi::LpiMeteoTimeLineHmi()
        : intervalName(""),
          startTimeAndDate(""),
          endTimeAndDate("")
{
}
LpiMeteoTimeLineHmi& LpiMeteoTimeLineHmi::operator=(const LpiMeteoTimeLineHmi& source)
{
    if (this != &source)
    {
        intervalName = source.intervalName;
        startTimeAndDate = source.startTimeAndDate;
        endTimeAndDate = source.endTimeAndDate;
        meteoInfo = source.meteoInfo;
    }

    return *this;
}

std::ostream& operator<<(std::ostream & out,
                         const LpiMeteoTimeLineHmi & meteo)
{
    LpiMeteoTimeLineHmi meteoTimeLineAux = meteo;
    return out;
}

