#include <iostream>
#include <sstream>

#include "inc/LpiMeteoInfoHmi.h"


RVRperRunwayList::RVRperRunwayList()
{
}

RVRperRunway::RVRperRunway () :
    name(""),
    rvr(0),
    crosswind(0.0),
    tailwind(0.0)
{
}
RVRperRunway & RVRperRunway::operator= (const RVRperRunway & source)
{
    if(this != &source)
    {
        name      = source.name;
        rvr       = source.rvr;
        crosswind = source.crosswind;
        tailwind  = source.tailwind;
    }
    return *this;
}

RVRperRunwayList & RVRperRunwayList::operator=(const RVRperRunwayList & source)
{
    rVRperRunway.clear();
    for(unsigned int i=0; i<source.rVRperRunway.size(); i++)
    {
        rVRperRunway.push_back(source.rVRperRunway[i]);
    }
    return *this;
}

MessageIdentification::MessageIdentification() :
    aerodrome("")
{
    time_t now = time(NULL);
    timeAndDate = boost::posix_time::from_time_t(now);
}

MessageIdentification &MessageIdentification::operator=(const MessageIdentification & source){
    if(this != &source)
    {
        aerodrome = source.aerodrome;
        timeAndDate = source.timeAndDate;
    }
    return *this;
}

PeriodInformation::PeriodInformation():
    probability(0.0)
{
    time_t now = time(NULL);
    endTimeAndDate = boost::posix_time::from_time_t(now);
    startTimeAndDate = boost::posix_time::from_time_t(now);
}

void PeriodInformation::reset()
{
    time_t now = time(NULL);
    endTimeAndDate = boost::posix_time::from_time_t(now);
    startTimeAndDate = boost::posix_time::from_time_t(now);
    probability = 0.0;
}

PeriodInformation &PeriodInformation::operator=(const PeriodInformation & source){
    if(this != &source)
    {
        endTimeAndDate = source.endTimeAndDate;
        probability = source.probability;
        startTimeAndDate = source.startTimeAndDate;
    }
    return *this;
}

MeteorologicalInformation::MeteorologicalInformation() :
    windDirection(0),
    windSpeed(0),
    gustSpeed(0),
    gustDirection(0),
    airTemperature(0.0),
    dewPointTemperature(0.0),
    horizontalVisibility(0.0),
    qnh(0),
    cloudBase(0),
    significantWeather(""),
    wetness(""),
    lvp_Activation(false),
    required_ILS_Category(""),
    de_icing_required(false)
{
}

void MeteorologicalInformation::reset()
{
    windDirection = 0;
    windSpeed = 0;
    gustSpeed = 0;
    gustDirection = 0;
    airTemperature = 0.0;
    dewPointTemperature = 0.0;
    horizontalVisibility = 0.0;
    qnh = 0;
    cloudBase = 0;
    significantWeather = "";
    wetness = "";
    lvp_Activation = false;
    required_ILS_Category = "";
    de_icing_required = false;
    rvrperRunway.getRVRperRunway().clear();
}

MeteorologicalInformation & MeteorologicalInformation::operator= (const MeteorologicalInformation & source)
{
    if(this != &source)
    {
        airTemperature = source.airTemperature;
        cloudBase = source.cloudBase;
        de_icing_required = source.de_icing_required;
        dewPointTemperature = source.dewPointTemperature;
        gustDirection = source.gustDirection;
        gustSpeed = source.gustSpeed;
        horizontalVisibility = source.horizontalVisibility;
        lvp_Activation = source.lvp_Activation;
        qnh = source.qnh;
        required_ILS_Category = source.required_ILS_Category;
        significantWeather = source.significantWeather;
        wetness = source.wetness;
        windDirection = source.windDirection;
        windSpeed = source.windSpeed;
        rvrperRunway = source.rvrperRunway;
    }
    return *this;

}

BodyInformation::BodyInformation()
{

}

void BodyInformation::reset()
{
    meteorologicalInfomation.reset();
    periodInformation.reset();
}

BodyInformation & BodyInformation::operator= (const BodyInformation & source)
{
    if(this != &source)
    {
        meteorologicalInfomation = source.meteorologicalInfomation;
        periodInformation = source.periodInformation;
    }
    return *this;

}

BodyInformationList::BodyInformationList()
{
}

void BodyInformationList::reset()
{
    for(unsigned  int i=0; i<bodyInfoList.size(); i++)
    {
        bodyInfoList[i].reset();
    }
    bodyInfoList.clear();
}

BodyInformationList& BodyInformationList::operator=(const BodyInformationList& source)
{
   if(this != &source)
   {
       bodyInfoList.clear();
       for(unsigned  int i=0; i<source.bodyInfoList.size(); i++)
       {
           bodyInfoList.push_back(source.bodyInfoList[i]);
       }
   }
   return *this;
}

//LpiMeteoInfoHmi method implementations

LpiMeteoInfoHmi::LpiMeteoInfoHmi ()
{
    calculationReason = LpiCalculationReason::E_INIT;
    timeLine.clear();
}
LpiMeteoInfoHmi& LpiMeteoInfoHmi::operator=(const LpiMeteoInfoHmi& source)
{
   if(this != &source)
   {
       messageIdentification = source.messageIdentification;
       calculationReason = source.calculationReason;
       bodyInformation = source.bodyInformation;
       timeLine = source.timeLine;
   }

   return *this;
 }

 std::ostream& operator<< (std::ostream & out, const RVRperRunwayList & rvrrunway)
 {
     RVRperRunwayList rvrrunwayAux = rvrrunway;
     return out;
 }

 std::ostream& operator<< (std::ostream & out, const LpiMeteoInfoHmi & meteo)
 {
     LpiMeteoInfoHmi meteoAux = meteo;
     return out;
 }

