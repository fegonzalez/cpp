/*
 * LpiHmiMessageBox.h
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#ifndef LPIHMIMESSAGEBOX_H_
#define LPIHMIMESSAGEBOX_H_


#include <QMessageBox>

class LpiHmiMessageBox: public QMessageBox
{
public:
	LpiHmiMessageBox(QString, QVector<StandardButton>&);
	virtual ~LpiHmiMessageBox();
	void setTextButton(StandardButton);
};


#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_TYPES_INC_LPIHMIMESSAGEBOX_H_ */
