#ifndef LpiMeteoInfo_H
#define LpiMeteoInfo_H

#include <string>
#include <vector>
#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiTime.h"
#include "LpiCalculationReason.h"
#include "LpiMeteoTimeLineHmi.h"

using namespace boost;

class MessageIdentification
    {
        public:
            MessageIdentification();
            MessageIdentification &operator=(const MessageIdentification & source);
            posix_time::ptime getTimeAndDate(void) const
            {
                return timeAndDate;
            }
            void setTimeAndDate(posix_time::ptime timeDate)
            {
                timeAndDate = timeDate;
            }
            std::string getAerodrome(void) const
            {
                return aerodrome;
            }
            void setAerodrome(const std::string aerodromeAux)
            {
                aerodrome = aerodromeAux;
            }

        private:
            posix_time::ptime timeAndDate;
            std::string aerodrome;
    };

    class PeriodInformation
    {
        public:
            PeriodInformation();
            PeriodInformation & operator=(const PeriodInformation & source);
            void reset();
            posix_time::ptime getStartTimeAndDate(void) const
            {
                return startTimeAndDate;
            }
            void setStartTimeAndDate(posix_time::ptime startTimeDate)
            {
                startTimeAndDate = startTimeDate;
            }
            posix_time::ptime getEndTimeAndDate(void) const
            {
                return endTimeAndDate;
            }
            void setEndTimeAndDate(posix_time::ptime endTimeDate)
            {
                endTimeAndDate = endTimeDate;
            }
            float getProbability(void) const
            {
                return probability;
            }
            void setProbability(const float probabilityAux)
            {
                probability = probabilityAux;
            }

        private:
            posix_time::ptime startTimeAndDate;
            posix_time::ptime endTimeAndDate;
            float probability;
    };

    class RVRperRunway
    {
        public:
            RVRperRunway();
            virtual ~RVRperRunway()
            {
            }

            RVRperRunway & operator=(const RVRperRunway & source);
            std::string getName(void) const
            {
                return name;
            }
            void setName(const std::string nameAux)
            {
                name = nameAux;
            }
            int getRvr(void) const
            {
                return rvr;
            }
            void setRvr(const int rvrAux)
            {
                rvr = rvrAux;
            }
            float getCrosswind(void) const
            {
                return crosswind;
            }
            void setCrosswind(const float crosswindAux)
            {
                crosswind = crosswindAux;
            }
            float getTailwind(void) const
            {
                return tailwind;
            }
            void setTailwind(const float tailwindAux)
            {
                tailwind = tailwindAux;
            }
        private:
            std::string name;
            int rvr;
            float crosswind;
            float tailwind;
    };

    class RVRperRunwayList
    {
        public:
            RVRperRunwayList();
            virtual ~RVRperRunwayList()
            {
            }

            RVRperRunwayList & operator=(const RVRperRunwayList & source);
            // getters
            const std::vector<RVRperRunway>& getRVRperRunway(void) const
            {
                return rVRperRunway;
            }
            std::vector<RVRperRunway>& getRVRperRunway(void)
            {
                return rVRperRunway;
            }
            const RVRperRunway& getRVRperRunway(unsigned int index) const
            {
                return rVRperRunway[index];
            }

            // setters
            void setRVRPerRunway(const RVRperRunway &value)
            {
                rVRperRunway.push_back(value);
            }
        private:
            std::vector<RVRperRunway> rVRperRunway;
    };

    class MeteorologicalInformation
    {
        public:
            MeteorologicalInformation();
            MeteorologicalInformation & operator=(const MeteorologicalInformation & source);
            void reset();
            int getWindDirection(void)
            {
                return windDirection;
            }
            void setWindDirection(const int windDirectioAux)
            {
                windDirection = windDirectioAux;
            }
            int getWindSpeed(void)
            {
                return windSpeed;
            }
            void setWindSpeed(const int windSpeedAux)
            {
                windSpeed = windSpeedAux;
            }
            int getGustSpeed(void)
            {
                return gustSpeed;
            }
            void setGustSpeed(const int gustSpeedAux)
            {
                gustSpeed = gustSpeedAux;
            }
            int getGustDirection(void)
            {
                return gustDirection;
            }
            void setGustDirection(const int gustDirectionAux)
            {
                gustDirection = gustDirectionAux;
            }
            float getAirTemperature(void)
            {
                return airTemperature;
            }
            void setAirTemperature(const float airTemperatureAux)
            {
                airTemperature = airTemperatureAux;
            }
            float getDewPointTemperature(void)
            {
                return dewPointTemperature;
            }
            void setDewPointTemperature(const float dewPointTemperatureAux)
            {
                dewPointTemperature = dewPointTemperatureAux;
            }
            float getHorizontalVisibility()
            {
                return horizontalVisibility;
            }
            void setHorizontalVisibility(const float horizontalVisibilityAux)
            {
                horizontalVisibility = horizontalVisibilityAux;
            }
            int getQNH(void)
            {
                return qnh;
            }
            void setQNH(const int qnhAux)
            {
                qnh = qnhAux;
            }
            int getCloudBase(void)
            {
                return cloudBase;
            }
            void setCloudBase(const int cloudBaseAux)
            {
                cloudBase = cloudBaseAux;
            }
            std::string getSignificantWeather(void)
            {
                return significantWeather;
            }
            void setSignificantWeather(const std::string significantWeatherAux)
            {
                significantWeather = significantWeatherAux;
            }
            std::string getWetness(void)
            {
                return wetness;
            }
            void setWetness(const std::string wetnessAux)
            {
                wetness = wetnessAux;
            }
            bool getLvp_Activation(void)
            {
                return lvp_Activation;
            }
            void setLvp_Activation(const bool lvp_ActivationAux)
            {
                lvp_Activation = lvp_ActivationAux;
            }
            std::string getRequired_ILS_Category(void)
            {
                return required_ILS_Category;
            }
            void setRequired_ILS_Category(const std::string required_ILS_CategoryAux)
            {
                required_ILS_Category = required_ILS_CategoryAux;
            }
            bool getDe_icing_required(void) const
            {
                return de_icing_required;
            }
            void setDe_icing_required(const bool de_icing_requiredAux)
            {
                de_icing_required = de_icing_requiredAux;
            }
            RVRperRunwayList& getRvrperRunway(void)
            {
                return rvrperRunway;
            }
            void setRvrperRunway(const RVRperRunwayList& rvrperRunwayAux)
            {
                rvrperRunway = rvrperRunwayAux;
            }

        private:
            int windDirection;
            int windSpeed;
            int gustSpeed;
            int gustDirection;
            float airTemperature;
            float dewPointTemperature;
            float horizontalVisibility;
            int qnh;
            int cloudBase;
            std::string significantWeather;
            std::string wetness;
            bool lvp_Activation;
            std::string required_ILS_Category;
            bool de_icing_required;
            RVRperRunwayList rvrperRunway;
    };

    class BodyInformation
    {
        public:
            BodyInformation();
            BodyInformation & operator=(const BodyInformation & source);
            void reset();
            PeriodInformation& getPeriodInformation(void)
            {
                return periodInformation;
            }
            MeteorologicalInformation& getMeteorologicalInformation(void)
            {
                return meteorologicalInfomation;
            }
        private:
            PeriodInformation periodInformation;
            MeteorologicalInformation meteorologicalInfomation;
    };

    class BodyInformationList
    {
        public:
            BodyInformationList();
            void reset();
            BodyInformationList & operator=(const BodyInformationList & source);
            // getters
            std::vector<BodyInformation>& getBodyInformationVector(void)
            {
                return bodyInfoList;
            }
            BodyInformation& getBodyInformation(unsigned int index)
            {
                return bodyInfoList[index];
            }

            // setters
            void setBodyInformation(const BodyInformation &value)
            {
                bodyInfoList.push_back(value);
            }

        private:
            std::vector<BodyInformation> bodyInfoList;
    };

    class LpiMeteoInfoHmi
    {
        public:
        LpiMeteoInfoHmi();
        LpiMeteoInfoHmi & operator=(const LpiMeteoInfoHmi & source);
            MessageIdentification& getMessageIdentification(void)
            {
                return messageIdentification;
            }

            BodyInformationList& getBodyInformationList(void)
            {
                return bodyInformation;
            }

            BodyInformationList getBodyInformationList(void) const
            {
                return bodyInformation;
            }

            LpiCalculationReason::LpiEnum getCalculationReason() const
            {
                return calculationReason;
            }

            LpiCalculationReason::LpiEnum& getCalculationReason()
            {
                return calculationReason;
            }

            void setCalculationReason(LpiCalculationReason::LpiEnum calculationReason)
            {
                this->calculationReason = calculationReason;
            }

            const std::vector<LpiMeteoTimeLineHmi>& getTimeLine() const
            {
                return timeLine;
            }

            void setTimeLine(const std::vector<LpiMeteoTimeLineHmi>& timeLine)
            {
                this->timeLine = timeLine;
            }

            void setTimeLineItem(const LpiMeteoTimeLineHmi& timeLineItem)
            {
                this->timeLine.push_back(timeLineItem);
            }

        private:
            MessageIdentification messageIdentification;
            LpiCalculationReason::LpiEnum calculationReason;
            BodyInformationList bodyInformation;
            std::vector<LpiMeteoTimeLineHmi> timeLine;
    };

    std::ostream& operator<<(std::ostream & out,
                             const RVRperRunwayList & rvrrunway);

    std::ostream& operator<<(std::ostream & out,
                             const LpiMeteoInfoHmi & meteoInfo);



#endif // LpiMeteoInfo_H
