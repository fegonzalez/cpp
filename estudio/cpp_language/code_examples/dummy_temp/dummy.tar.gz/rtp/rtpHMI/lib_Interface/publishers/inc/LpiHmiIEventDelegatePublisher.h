#if !defined(__LpiHMI_I_EVENT_DELEGATE_PUBLISHER__)
#define __LpiHMI_I_EVENT_DELEGATE_PUBLISHER__

#include "LpiHmiIDelegatePublisher.h"
#include "LpiHmiIEventPublisher.h"
#include "LpiHmiIEventPublisher.h"

template<typename TEvent>
class LpiHmiIEventDelegatePublisher : public LpiHmiIEventPublisher<TEvent>,
                                   public LpiHmiIDelegatePublisher<LpiHmiIEventPublisher<TEvent> >
{
public:
   LpiHmiIEventDelegatePublisher() {}
   virtual ~LpiHmiIEventDelegatePublisher() {}
   virtual void delegatePublisher(LpiHmiIEventPublisher<TEvent> &data) = 0;
   virtual void publish(const TEvent &data) = 0;
};

#endif // __LpiHMI_I_EVENT_DELEGATE_PUBLISHER__
