/*
 * LpiHmiActivateScheduleEvt.h
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#ifndef LPIHMIACTIVATESCHEDULEEVT_H_
#define LPIHMIACTIVATESCHEDULEEVT_H_

#include "LpiHmiActivateSchedule.h"

class LpiHmiActivateScheduleEvt
{
public:
   const LpiHmiActivateSchedule& getActivateSchedule(void) const {return this->_as;}
   void setActivateSchedule(const LpiHmiActivateSchedule &as) {this->_as = as;}
private:
   LpiHmiActivateSchedule _as;
};


#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_EVENTS_INC_LPIHMIACTIVATESCHEDULEEVT_H_ */
