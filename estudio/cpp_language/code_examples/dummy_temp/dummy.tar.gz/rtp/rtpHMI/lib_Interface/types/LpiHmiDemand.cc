/*
 * LpiHmiDemand.cc
 *
 *  Created on: Sep 11, 2018
 *      Author: srperez
 */


#include "LpiHmiDemand.h"

Fps::Fps() :
    fp(""),
    itot_ildt(""),
    stot_sldt(""),
    etot_eldt(""),
    ttot_tldt(""),
    utot_uldt(""),
    ctot_sibt(""),
    acType(""),
    opType(""),
    proeced("")
{

}

void Fps::reset()
{
    fp = "";
    itot_ildt = "";
    stot_sldt = "";
    etot_eldt = "";
    ttot_tldt = "";
    utot_uldt = "";
    ctot_sibt = "";
    acType = "";
    opType = "";
    proeced = "";
}

Fps & Fps::operator= (const Fps & source)
{
    if(this != &source)
    {
        fp = source.fp;
        itot_ildt = source.itot_ildt;
        stot_sldt = source.stot_sldt;
        etot_eldt = source.etot_eldt;
        ttot_tldt = source.ttot_tldt;
        utot_uldt = source.utot_uldt;
        ctot_sibt = source.ctot_sibt;
        acType = source.acType;
        opType = source.opType;
        proeced = source.proeced;
    }
    return *this;
}

/*Hmi::FPs & Hmi::FPs::operator= (const Hmi::FPs & source)
{
    if(this != &source)
    {
        fps = source.fps;
    }
    return *this;
}*/

FpsList::FpsList()
{
}

void FpsList::reset()
{
    for (unsigned int i = 0; i < fpsList.size(); i++)
    {
        fpsList[i].reset();
    }
    fpsList.clear();
}

FpsList& FpsList::operator=(const FpsList& source)
{
   if(this != &source)
   {
       fpsList.clear();
       for(unsigned int i=0; i<source.fpsList.size(); i++)
       {
           fpsList.push_back(source.fpsList[i]);
       }

   }
   return *this;
}

Demand_Forecast::Demand_Forecast() :
    name(""),
    startTimeAndDate(""),
    endTimeAndDate("")
{
}

Demand_Forecast::Demand_Forecast(std::string       nameAux,
                                      std::string       startTimeAndDateAux,
                                      std::string       endTimeAndDateAux,
                                      LpiHmiVectorAdo      demand_forecastAux,
                                      LpiHmiVectorAdo      ratioAux,
									  LpiHmiVectorAdo      vfrAux,
                                      FpsList      fpAux)
{
    name = nameAux;
    startTimeAndDate = startTimeAndDateAux;
    endTimeAndDate = endTimeAndDateAux;LpiHmiVectorAdo      ratio;
    demand_forecast = demand_forecastAux;
    ratio = ratioAux;
    vfr = vfrAux;
    fp = fpAux;
}

void Demand_Forecast::reset()
{
    name = "";
    startTimeAndDate = "";
    endTimeAndDate = "";
    demand_forecast.reset();
    ratio.reset();
    vfr.reset();
    fp.reset();

}

Demand_Forecast & Demand_Forecast::operator= (const Demand_Forecast & source)
{
    if(this != &source)
    {
        name = source.name;
        startTimeAndDate = source.startTimeAndDate;
        endTimeAndDate = source.endTimeAndDate;
        demand_forecast = source.demand_forecast;
        ratio = source.ratio;
        vfr = source.vfr;
        fp = source.fp;
    }
    return *this;
}

Demand_ForecastList::Demand_ForecastList()
{
}

Demand_ForecastList& Demand_ForecastList::operator=(const Demand_ForecastList& source)
{
   if(this != &source)
   {
       demandForecastList.clear();
       for(unsigned int i=0; i<source.demandForecastList.size(); i++)
       {
           demandForecastList.push_back(source.demandForecastList[i]);
       }
   }
   return *this;
}
LpiHmiDemand::LpiHmiDemand()
{
    time_t now = time(NULL);
    timeAndDate = boost::posix_time::from_time_t(now);
}

const LpiFlightPlanList & LpiHmiDemand::getFlightPlanList() const {
	return flightPlanList;
}

void LpiHmiDemand::setFlightPlanlist(const LpiFlightPlanList & fpList)
{
	for(unsigned int i = 0; i< fpList.size(); i++)
	{
		flightPlanList.push_back(fpList[i]);
	}
}

LpiHmiDemand& LpiHmiDemand::operator=(const LpiHmiDemand& source)
{
   if(this != &source)
   {
       timeAndDate = source.timeAndDate;
       calculationReason = source.calculationReason;
       demandForecast = source.demandForecast;
       total_demand_forecast = source.total_demand_forecast;
       total_ratio = source.total_ratio;
       total_vfr = source.total_vfr;

       nameAirport = source.nameAirport;
       demandStartTimeAndDate = source.demandStartTimeAndDate;
       demandEndTimeAndDate = source.demandEndTimeAndDate;
       flightPlanList = source.flightPlanList;
   }
   return *this;
}


