#if !defined(__LpiHMI_I_DELEGATE_PUBLISHER__)
#define __LpiHMI_I_DELEGATE_PUBLISHER__

template<typename TDelegate>
class LpiHmiIDelegatePublisher
{
public:
   LpiHmiIDelegatePublisher() {}
   virtual ~LpiHmiIDelegatePublisher() {}
   virtual void delegatePublisher(TDelegate &data) = 0;
};

#endif // __LpiHMI_I_DELEGATE_PUBLISHER__
