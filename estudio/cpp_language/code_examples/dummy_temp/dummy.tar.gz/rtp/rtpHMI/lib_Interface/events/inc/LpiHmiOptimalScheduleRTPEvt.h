/*
 * LpiHmiDefaultScheduleEvt.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPIHMIOPTIMALSCHEDULEEVT_H_
#define LPIHMIOPTIMALSCHEDULEEVT_H_
#include <string>
#include <vector>
#include <LpiScheduleRTP.h>

class LpiHmiOptimalScheduleRTPEvt
{
public:
   const LpiScheduleRTP & getSchedule(void) const {return this->_schedule;}
   void setSchedule(const LpiScheduleRTP &schedule) {this->_schedule = schedule;}
private:
   LpiScheduleRTP _schedule;
};



#endif /* LPIHMIDEFAULTSCHEDULEEVT_H_ */
