/*
 * LpiHmiActivateSchedule.cc
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#include "LpiHmiActivateSchedule.h"

LpiHmiActivateSchedule::LpiHmiActivateSchedule() :
    sch_id(0),
    activationType(LpiActivationType::E_PREFERENTIAL)
{}

LpiHmiActivateSchedule & LpiHmiActivateSchedule::operator=(const LpiHmiActivateSchedule & source)
{
    if(this != &source)
    {
        sch_id = source.sch_id;
        activationType = source.activationType;
    }
    return *this;
}




