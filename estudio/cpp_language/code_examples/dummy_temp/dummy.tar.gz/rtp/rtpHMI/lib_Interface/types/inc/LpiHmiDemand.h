/*
 * LpiHmiDemand.h
 *
 *  Created on: Sep 11, 2018
 *      Author: srperez
 */

#ifndef RTPHMI_LIB_INTERFACE_TYPES_INC_LPIHMIDEMAND_H_
#define RTPHMI_LIB_INTERFACE_TYPES_INC_LPIHMIDEMAND_H_


#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/algorithm/string/trim.hpp>
#include "LpiHmiVectorAdo.h"
#include "LpiCalculationReason.h"
#include "LpiFlightPlan.h"

using namespace boost;
   class Fps
   {
      public:
         Fps();
         Fps & operator= (const Fps & source);

         void reset();

         std::string     getFp(void) const {return fp;}
         void            setFp( const std::string fpAux){fp = boost::algorithm::trim_right_copy(fpAux);}
         std::string     getItotIldt(void) const {return itot_ildt;}
         void            setItotIldt( const std::string itot_ildtAux){itot_ildt = itot_ildtAux;}
         std::string     getStotSldt(void) const {return stot_sldt;}
         void            setStotSldt( const std::string stot_sldtAux){stot_sldt = stot_sldtAux;}
         std::string     getEtotEldt(void) const {return etot_eldt;}
         void            setEtotEldt( const std::string etot_eldtAux){etot_eldt = etot_eldtAux;}
         std::string     getTtotTldt(void) const {return ttot_tldt;}
         void            setTtotTldt( const std::string ttot_tldtAux){ttot_tldt = ttot_tldtAux;}
         std::string     getUtotUldt(void) const {return utot_uldt;}
         void            setUtotUldt( const std::string utot_uldtAux){utot_uldt = utot_uldtAux;}
         std::string     getCtotSibt(void) const {return ctot_sibt;}
         void            setCtotSibt( const std::string ctot_sibtAux){ctot_sibt = ctot_sibtAux;}
         std::string     getAcType(void) const {return acType;}
         void            setAcType( const std::string acTypeAux){acType = acTypeAux;}
         std::string     getOpType(void) const {return opType;}
         void            setOpType( const std::string opTypeAux){opType = opTypeAux;}
         std::string     getProeced(void) const {return proeced;}
         void            setProeced( const std::string proecedAux){proeced = boost::algorithm::trim_right_copy(proecedAux);}

      private:
         std::string    fp;
         std::string    itot_ildt;
         std::string    stot_sldt;
         std::string    etot_eldt;
         std::string    ttot_tldt;
         std::string    utot_uldt;
         std::string    ctot_sibt;
         std::string    acType;
         std::string    opType;
         std::string    proeced;
   };

   class FpsList
   {
      public:
         FpsList ();
         virtual  ~FpsList () {}

         void reset();

         FpsList & operator=(const FpsList & source);
         // getters
         std::vector<Fps>& getFpsList(void) {return fpsList;}
         const std::vector<Fps>& getFpsList(void) const {return fpsList;}
         Fps& getFPs(unsigned int index) {return fpsList[index];}
         const Fps& getFPs(unsigned int index) const {return fpsList[index];}

         // setters
         void setFPs(const Fps &value) {fpsList.push_back(value);}
      private:
         std::vector<Fps> fpsList;
   };

   class Demand_Forecast
   {
      public:
         Demand_Forecast();
         Demand_Forecast(std::string       nameAux,
                         std::string       startTimeAndDateAux,
                         std::string       endTimeAndDateAux,
                         LpiHmiVectorAdo      demand_forecastAux,
                         LpiHmiVectorAdo      ratioAux,
						 LpiHmiVectorAdo      vfrAux,
                         FpsList           fpAux);
         Demand_Forecast & operator= (const Demand_Forecast & source);

         std::string getName(void) const {return name;}
         void setName( const std::string nameAux){name = nameAux;}

         std::string getStartTimeAndDate(void) const {return startTimeAndDate;}
         void setStartTimeAndDate( const std::string startTimeDate){startTimeAndDate = startTimeDate;}
         std::string getEndTimeAndDate(void) const {return endTimeAndDate;}
         void setEndTimeAndDate( const std::string endTimeDate){endTimeAndDate = endTimeDate;}

         LpiHmiVectorAdo& getDemandForecast(void)  {return demand_forecast;}
         const LpiHmiVectorAdo& getDemandForecast(void) const {return demand_forecast;}
         void setDemandForecast(const LpiHmiVectorAdo demand_forecastAux){
            demand_forecast = demand_forecastAux;}

         LpiHmiVectorAdo& getRatio(void)  {return ratio;}
         const LpiHmiVectorAdo& getRatio(void) const {return ratio;}
         void setRatio(const LpiHmiVectorAdo ratioAux){
            ratio = ratioAux;}

         LpiHmiVectorAdo& getVFR(void)  {return vfr;}
         const LpiHmiVectorAdo& getVFR(void) const {return vfr;}
         void setVFR(const LpiHmiVectorAdo vfrAux){
        	 vfr = vfrAux;}

         FpsList& getFpList(void){return fp;}
         const FpsList& getFpList(void) const {return fp;}

         void reset();

      private:
         std::string       name;
         std::string       startTimeAndDate;
         std::string       endTimeAndDate;
         LpiHmiVectorAdo      demand_forecast;
         LpiHmiVectorAdo      ratio;
         LpiHmiVectorAdo      vfr;
         FpsList           fp;
   };

   class Demand_ForecastList
   {
      public:
         Demand_ForecastList ();
         virtual  ~Demand_ForecastList () {}

         Demand_ForecastList & operator=(const Demand_ForecastList & source);
         // getters
         std::vector<Demand_Forecast>& getDemandForecastVector(void){return demandForecastList;}
         const std::vector<Demand_Forecast>& getDemandForecastVector(void) const {return demandForecastList;}
         Demand_Forecast& getDemandForecast(unsigned int index) {return demandForecastList[index];}
         const Demand_Forecast& getDemandForecast(unsigned int index) const {return demandForecastList[index];}

         // setters
         void setDemandForecast(const Demand_Forecast &value) {demandForecastList.push_back(value);}
      private:
         std::vector<Demand_Forecast> demandForecastList;
   };

   class LpiHmiDemand
   {
      public:
	   LpiHmiDemand();
	   LpiHmiDemand & operator= (const LpiHmiDemand & source);
         posix_time::ptime getTimeAndDate(void) const {return timeAndDate;}
         void setTimeAndDate( const posix_time::ptime timeDate){timeAndDate = timeDate;}

         LpiHmiVectorAdo&        getTotalDemandForecast(void)  {return total_demand_forecast;}
         LpiHmiVectorAdo getTotalDemandForecast(void) const {return total_demand_forecast;}
         void            setTotalDemandForecast( const LpiHmiVectorAdo total_demand_forecastAux){
            total_demand_forecast = total_demand_forecastAux;}

         LpiHmiVectorAdo&        getTotalRatio(void)  {return total_ratio;}
         LpiHmiVectorAdo getTotalRatio(void) const {return total_ratio;}
         void            setTotalRatio( const LpiHmiVectorAdo total_ratioAux){
            total_ratio = total_ratioAux;}

         LpiHmiVectorAdo&        getTotalVFR(void)  {return total_vfr;}
         LpiHmiVectorAdo getTotalVFR(void) const {return total_vfr;}
         void            setTotalVFR( const LpiHmiVectorAdo total_vfrAux){
        	 total_vfr = total_vfrAux;}

         Demand_ForecastList& getDemandForecastList(void){return demandForecast;}

         const Demand_ForecastList& getDemandForecastList(void) const {return demandForecast;}

     LpiCalculationReason::LpiEnum getCalculationReason() const{ return calculationReason; }

     LpiCalculationReason::LpiEnum& getCalculationReason(){ return calculationReason; }

     void setCalculationReason(LpiCalculationReason::LpiEnum calculationReason)
     {
        this->calculationReason = calculationReason;
     }


     void setNameAirport(const std::string & _nameAirport) {
    	 nameAirport = _nameAirport;
     }
     const std::string & getNameAirport() const {
    	 return nameAirport;
     }

     void setDemandStartTimeAndDate(const posix_time::ptime & startTime) {
    	 demandStartTimeAndDate = startTime;
     }
     const posix_time::ptime & getDemandStartTimeAndDate() const {
    	 return demandStartTimeAndDate;
     }

     void setDemandEndTimeAndDate(const posix_time::ptime & endTime) {
    	 demandEndTimeAndDate = endTime;
     }
     const posix_time::ptime & getDemandEndTimeAndDate() const {
    	 return demandEndTimeAndDate;
     }

     const LpiFlightPlanList & getFlightPlanList() const;
     void setFlightPlanlist(const LpiFlightPlanList & fpList);

      private:
         posix_time::ptime timeAndDate;
         LpiCalculationReason::LpiEnum calculationReason;
         Demand_ForecastList  demandForecast;
         LpiHmiVectorAdo  total_demand_forecast;
         LpiHmiVectorAdo  total_ratio;
         LpiHmiVectorAdo  total_vfr;

         std::string 				nameAirport;
         posix_time::ptime 		demandStartTimeAndDate;
         posix_time::ptime 		demandEndTimeAndDate;
         LpiFlightPlanList         flightPlanList;
   };

   typedef std::vector<LpiHmiDemand> LpiHmiDemandList;


#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_TYPES_INC_LPIHMIDEMAND_H_ */
