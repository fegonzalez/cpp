#if !defined(__LRIHMI_EVENT_DELEGATE_PUBLISHERS_IMPL__)
#define __LRIHMI_EVENT_DELEGATE_PUBLISHERS_IMPL__

#include "LpiHmiEventDelegatePublisherImpl.h"
#include <LpiHmiActivateScheduleEvt.h>

typedef LpiHmiEventDelegatePublisherImpl<
   LpiHmiActivateScheduleEvt
> LpiHmiActivateScheduleEvtDelegatePublisher;

//typedef LriHmiEventDelegatePublisherImpl<
//   LriHmiOptimizationCriteriaEvt
//> LriHmiOptimizationCriteriaEvtDelegatePublisher;
//
//typedef LriHmiEventDelegatePublisherImpl<
//   LriHmiCapacityReductionsEvt
//> LriHmiCapacityReductionsEvtDelegatePublisher;


//typedef LriHmiEventDelegatePublisherImpl<
//   LriHmiDeleteScheduleEvt
//> LriHmiDeleteScheduleEvtDelegatePublisher;
//
//typedef LriHmiEventDelegatePublisherImpl<
//   LriHmiManualEditionEvt
//> LriHmiManualEditionEvtDelegatePublisher;
//
//typedef LriHmiEventDelegatePublisherImpl<
//   LriHmiComparisonSchedulesEvt
//> LriHmiComparisonSchedulesEvtDelegatePublisher;
//
//typedef LriHmiEventDelegatePublisherImpl<
//   LriHmiRunwayClosuresEvt
//> LriHmiRunwayClosuresEvtDelegatePublisher;

#endif // __LRIHMI_EVENT_DELEGATE_PUBLISHERS_IMPL__
