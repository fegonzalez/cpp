/*
 * LpiHmiVectorAdo.cc
 *
 *  Created on: Sep 11, 2018
 *      Author: srperez
 */

#include "LpiHmiVectorAdo.h"

LpiHmiVectorAdo::LpiHmiVectorAdo() :
    arrivals(0),
    departures(0),
    overall(0)
{
}

LpiHmiVectorAdo::LpiHmiVectorAdo(int arr, int dep, int ove)
{
    arrivals = arr;
    departures = dep;
    overall = ove;
}

LpiHmiVectorAdo::LpiHmiVectorAdo(float arr, float dep, float ove)
{
    arrivals = arr;
    departures = dep;
    overall = ove;
}

LpiHmiVectorAdo::LpiHmiVectorAdo(double arr, double dep, double ove)
{
    arrivals = arr;
    departures = dep;
    overall = ove;
}

LpiHmiVectorAdo & LpiHmiVectorAdo::operator= (const LpiHmiVectorAdo & source)
{
    if(this != &source)
    {
       arrivals = source.arrivals;
       departures = source.departures;
       overall = source.overall;
    }
    return *this;
}

float LpiHmiVectorAdo::getValueAdoByIndex(int index) const
{
    switch (index){
    case 0:
        return arrivals;
    case 1:
        return departures;
    case 2:
        return overall;
    default:
        return 0.0;
    }
}

void LpiHmiVectorAdo::reset(){
    arrivals = 0;
    departures = 0;
    overall = 0;
}



