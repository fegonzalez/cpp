/*
 * LpiHmiVectorAdo.h
 *
 *  Created on: Sep 11, 2018
 *      Author: srperez
 */

#ifndef LPIHMIVECTORADO_H_
#define LPIHMIVECTORADO_H_

#include <IOTim.h>

#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <iostream>

using namespace boost;

class LpiHmiVectorAdo
{
public:
	LpiHmiVectorAdo();
	LpiHmiVectorAdo(int, int, int);
	LpiHmiVectorAdo(float, float, float);
	LpiHmiVectorAdo(double, double, double);
	LpiHmiVectorAdo & operator= (const LpiHmiVectorAdo & source);

    float           getArrivals(void) const {return arrivals;}
    void            setArrivals( const float arrivalsAux){arrivals = arrivalsAux;}
    float           getDepartures(void) const {return departures;}
    void            setDepartures( const float departureAux){departures = departureAux;}
    float           getOverall(void) const  {return overall;}
    void            setOverall( const float overallAux){overall = overallAux;}

    float           getValueAdoByIndex(int index) const;

    void            reset();

    static void OptionalTime2Posix_time(const IOTim::OptionalTimeU & optionaltime,
                                 boost::optional<posix_time::ptime> & pos_time)
    {
            if (optionaltime._d == true)
            {
            	pos_time = posix_time::from_time_t(optionaltime._u.value);
            }
            else
            {
                pos_time = boost::none;
            }
    }

private:
    float arrivals;
    float departures;
    float overall;

};


#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_TYPES_INC_LPIHMIVECTORADO_H_ */
