/*
 * LpiHmiAcivateSchedule.h
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#ifndef LPIHMIACTIVATESCHEDULE_H_
#define LPIHMIACTIVATESCHEDULE_H_

#include <LpiActivationType.h>

class LpiHmiActivateSchedule
    {
public:

	LpiHmiActivateSchedule();
	LpiHmiActivateSchedule & operator=(const LpiHmiActivateSchedule & source);
	int getSchID() const {return sch_id;}
	void setSchID(int value){sch_id = value;}

	LpiActivationType::ActivationType getActivationType() const{return activationType;}
	void setActivationType(LpiActivationType::ActivationType activationType){this->activationType = activationType;}



    private:
        int sch_id;
        LpiActivationType::ActivationType activationType;
    };


#endif /* C___SRC_RTP_RTPHMI_LIB_INTERFACE_TYPES_INC_LPIHMIACIVATESCHEDULE_H_ */
