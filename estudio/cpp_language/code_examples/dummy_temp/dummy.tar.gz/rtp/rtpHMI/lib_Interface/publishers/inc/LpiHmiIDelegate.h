#if !defined(__LpiHMI_I_DELEGATE__)
#define __LpiHMI_I_DELEGATE__

template<typename TDelegate>
class LpiHmiIDelegate
{
public:
   LpiHmiIDelegate() {}
   virtual ~LpiHmiIDelegate() {}
   virtual void delegate(TDelegate &data) = 0;
};

#endif // __LpiHMI_I_DELEGATE__
