#if !defined(__LpiHMI_EVENT_PUBLISHER__)
#define __LpiHMI_EVENT_PUBLISHER__

template<typename TEvent>
class LpiHmiIEventPublisher
{
public:
   LpiHmiIEventPublisher() {}
   virtual ~LpiHmiIEventPublisher() {}
   virtual void publish(const TEvent &data) = 0;
};

#endif // __LpiHMI_EVENT_PUBLISHER__
