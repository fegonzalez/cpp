#ifndef LpiMeteoTimeLine_H
#define LpiMeteoTimeLine_H

#include <string>
#include <vector>
#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiTime.h"

using namespace boost;

class MeteoInfo
   {
       public:
           MeteoInfo ();
           virtual  ~MeteoInfo () {}

           MeteoInfo (boost::optional<float> horizontalVisibility,
           std::string            wetness,
           std::string            ilsCategory,
           boost::optional<bool>  lvpActivation,
           boost::optional<bool>  deicingRequired,
           boost::optional<float> crosswind,
           boost::optional<float> tailwind,
           boost::optional<int>   windSpeed,
           boost::optional<int>   windDirection);

           MeteoInfo & operator= (const MeteoInfo & source);

            const boost::optional<float>& getCrosswind() const
            {
                return crosswind;
            }

            void setCrosswind(const boost::optional<float>& crosswind)
            {
                this->crosswind = crosswind;
            }

            const boost::optional<bool>& getDeicingRequired() const
            {
                return deicingRequired;
            }

            void setDeicingRequired(const boost::optional<bool>& deicingRequired)
            {
                this->deicingRequired = deicingRequired;
            }

            const boost::optional<float>& getHorizontalVisibility() const
            {
                return horizontalVisibility;
            }

            void setHorizontalVisibility(const boost::optional<float>& horizontalVisibility)
            {
                this->horizontalVisibility = horizontalVisibility;
            }

            const std::string& getIlsCategory() const
            {
                return ilsCategory;
            }

            void setIlsCategory(const std::string& ilsCategory)
            {
                this->ilsCategory = ilsCategory;
            }

            const boost::optional<bool>& getLvpActivation() const
            {
                return lvpActivation;
            }

            void setLvpActivation(const boost::optional<bool>& lvpActivation)
            {
                this->lvpActivation = lvpActivation;
            }

            const boost::optional<float>& getTailwind() const
            {
                return tailwind;
            }

            void setTailwind(const boost::optional<float>& tailwind)
            {
                this->tailwind = tailwind;
            }

            const std::string& getWetness() const
            {
                return wetness;
            }

            void setWetness(const std::string& wetness)
            {
                this->wetness = wetness;
            }

            const boost::optional<int>& getWindDirection() const
            {
                return windDirection;
            }

            void setWindDirection(const boost::optional<int>& windDirection)
            {
                this->windDirection = windDirection;
            }

            const boost::optional<int>& getWindSpeed() const
            {
                return windSpeed;
            }

            void setWindSpeed(const boost::optional<int>& windSpeed)
            {
                this->windSpeed = windSpeed;
            }

       private:
           boost::optional<float> horizontalVisibility;
           std::string            wetness;
           std::string            ilsCategory;
           boost::optional<bool>  lvpActivation;
           boost::optional<bool>  deicingRequired;
           boost::optional<float> crosswind;
           boost::optional<float> tailwind;
           boost::optional<int>   windSpeed;
           boost::optional<int>   windDirection;

   };

    class LpiMeteoTimeLineHmi
   {
      public:
    LpiMeteoTimeLineHmi ();
           virtual  ~LpiMeteoTimeLineHmi () {}

           LpiMeteoTimeLineHmi & operator= (const LpiMeteoTimeLineHmi & source);

            const std::string& getEndTimeAndDate() const
            {
                return endTimeAndDate;
            }

            void setEndTimeAndDate(const std::string& endTimeAndDate)
            {
                this->endTimeAndDate = endTimeAndDate;
            }

            const std::string& getIntervalName() const
            {
                return intervalName;
            }

            void setIntervalName(const std::string& intervalName)
            {
                this->intervalName = intervalName;
            }

            const MeteoInfo& getMeteoInfo() const
            {
                return meteoInfo;
            }

            void setMeteoInfo(const MeteoInfo& meteoInfo)
            {
                this->meteoInfo = meteoInfo;
            }

            const std::string& getStartTimeAndDate() const
            {
                return startTimeAndDate;
            }

            void setStartTimeAndDate(const std::string& startTimeAndDate)
            {
                this->startTimeAndDate = startTimeAndDate;
            }

      private:
           std::string          intervalName;
           std::string          startTimeAndDate;
           std::string          endTimeAndDate;
           MeteoInfo            meteoInfo;
   };

   std::ostream& operator<< (std::ostream & out, const LpiMeteoTimeLineHmi & meteoInfo);



#endif // LpiMeteoTimeLine_H
