#if !defined(__LPIHMI_EVENT_DELEGATE_PUBLISHER_IMPL__)
#define __LPIHMI_EVENT_DELEGATE_PUBLISHER_IMPL__

#include <LpiHmiIEventDelegatePublisher.h>

template<typename TEvent>
class LpiHmiEventDelegatePublisherImpl : public LpiHmiIEventDelegatePublisher<TEvent >
{
public:
   LpiHmiEventDelegatePublisherImpl() {}
   virtual ~LpiHmiEventDelegatePublisherImpl() {}

   virtual void delegatePublisher(LpiHmiIEventPublisher<TEvent> &delegate)
   {
      this->_pDelegate = &delegate;
   }

   virtual void publish(const TEvent &data)
   {
      this->_pDelegate->publish(data);
   }

private:
   LpiHmiIEventPublisher<TEvent> *_pDelegate;
};

#endif // __LpiHMI_EVENT_DELEGATE_PUBLISHER_IMPL__
