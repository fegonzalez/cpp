/*
 * LpiHmiMessageBox.cc
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#include "LpiHmiMessageBox.h"
#include <QIcon>
#include <QAbstractButton>

LpiHmiMessageBox::LpiHmiMessageBox(QString text, QVector<StandardButton>& listButtons)
{
    setWindowTitle(" ");
    setWindowFlags(Qt::WindowStaysOnTopHint | Qt::Dialog);
    setText(text);
    //setWindowModality(Qt::WindowModal);
    setInformativeText("");
    for(int i = 0; i < listButtons.size(); i++)
    {
        addButton(listButtons[i]);
        button(listButtons[i])->setIcon(QIcon());
        button(listButtons[i])->setFocusPolicy(Qt::NoFocus);
        setTextButton(listButtons[i]);
    }
}

LpiHmiMessageBox::~LpiHmiMessageBox()
{
}

void LpiHmiMessageBox::setTextButton(StandardButton standardButton)
{
    switch(standardButton){
        case NoButton:
            break;
        case Ok:
            button(standardButton)->setText("OK");
            break;
        case Save:
        case SaveAll:
            button(standardButton)->setText("Save");
            break;
        case Open:
            button(standardButton)->setText("Open");
            break;
        case Yes:
        case YesToAll:
            button(standardButton)->setText("Yes");
            break;
        case No:
        case NoToAll:
            button(standardButton)->setText("No");
            break;
        case Abort:
            button(standardButton)->setText("Abort");
            break;
        case Retry:
            button(standardButton)->setText("Retry");
            break;
        case Ignore:
            button(standardButton)->setText("Ignore");
            break;
        case Close:
            button(standardButton)->setText("Close");
            break;
        case Cancel:
            button(standardButton)->setText("Cancel");
            break;
        case Discard:
            button(standardButton)->setText("Discard");
            break;
        case Help:
            button(standardButton)->setText("Help");
            break;
        case Apply:
            button(standardButton)->setText("Apply");
            break;
        case Reset:
            button(standardButton)->setText("Reset");
            break;
        case RestoreDefaults:
            button(standardButton)->setText("Restore");
            break;
        default:
            break;
    }
}
