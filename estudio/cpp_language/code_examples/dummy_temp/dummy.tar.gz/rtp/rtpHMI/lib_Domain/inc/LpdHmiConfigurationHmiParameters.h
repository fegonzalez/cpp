/*
 * LpdHmiConfigurationHmiParameters.h
 *
 *  Created on: Oct 4, 2018
 *      Author: srperez
 */

#ifndef LPDHMICONFIGURATIONHMIPARAMETERS_H_
#define LPDHMICONFIGURATIONHMIPARAMETERS_H_


#include <LpiConfigurationHmiParameters.h>

class LpdHmiConfigurationHmiParameters
{
public:
    static LpdHmiConfigurationHmiParameters* GetInstance();
    LpiConfigurationHmiParameters getConfigurationHmiParameters();
    virtual ~LpdHmiConfigurationHmiParameters();
private:
    LpdHmiConfigurationHmiParameters();
    static LpdHmiConfigurationHmiParameters* instance;
    LpiConfigurationHmiParameters configurationHmiParameters;
};


#endif /* C___SRC_RTP_RTPHMI_LIB_DOMAIN_INC_LPDHMICONFIGURATIONHMIPARAMETERS_H_ */
