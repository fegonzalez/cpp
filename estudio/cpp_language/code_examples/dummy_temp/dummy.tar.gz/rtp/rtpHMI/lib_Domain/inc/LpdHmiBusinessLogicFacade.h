#if !defined(__LPD_HMI_BUSINESS_LOGIC_FACADE_H__)
#define __LPD_HMI_BUSINESS_LOGIC_FACADE_H__


#include <LpiInterfaces.h>
#include <LpiHmiDemand.h>
#include <LpiMeteoInfo.h>
#include <LpiScheduleRTP.h>

class LpdHmiBusinessLogicFacade : public LpiILifeCycle{

public:
	LpdHmiBusinessLogicFacade();
   ~LpdHmiBusinessLogicFacade();

   // Eventos consumidos
   virtual void updateDemand(const LpiHmiDemandList &data);
   virtual void updateMeteoNow(const LpiUpdateMeteoList &data);
   virtual void updateMeteoFore(const LpiUpdateMeteoList &data);
   virtual void updateActiveScheduleRTP(const LpiScheduleRTP &de);
   virtual void updateOptimalScheduleRTP(const LpiScheduleRTP &de);
   
   // Eventos Publicados (implementados en BaseComponent)

   // Servicios Proporcionados

   // Servicios Usados  (implementados en BaseComponent)


   virtual void create(void);
   virtual void initialise(void);
   virtual void complete(void);


protected:

private:

};


#endif // __LPD_BUSINESS_LOGIC_FACADE_H__
