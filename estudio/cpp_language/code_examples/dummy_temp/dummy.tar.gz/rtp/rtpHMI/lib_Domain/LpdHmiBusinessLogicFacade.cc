#include "LpdHmiBusinessLogicFacade.h"
#include <LpiMeteoInfo.h>
#include <LpiMeteoInfoHmi.h> //@todo MeteoForecast (remove include after update)
#include <LpiHmiDemand.h>
#include <LpdHmiComponent.h>
//#include <LriRunwayClosures.h>
#include <LpdbDemandObservable.h>
#include <LpdbMeteoNowObservable.h>
#include <LpdbMeteoForeObservable.h>
#include <LclogStream.h>

#include <iostream>
#ifdef TRACE_OUT
#include <vector>
#include <iterator>
#endif


LpdHmiBusinessLogicFacade::LpdHmiBusinessLogicFacade()
{
}

LpdHmiBusinessLogicFacade::~LpdHmiBusinessLogicFacade()
{
}

void LpdHmiBusinessLogicFacade::create(void)
{
}

void LpdHmiBusinessLogicFacade::initialise(void)
{
  // LrbOptimalScheduleObservable::GetInstance()->getOptimalData()->getRunwaySystemMessasge().clear();
   // LrbOptimalScheduleObservable::GetInstance()->getOptimalData()->getTimeLineKpisMessasge().clear();
}

void LpdHmiBusinessLogicFacade::complete(void)
{

}


void LpdHmiBusinessLogicFacade::updateDemand(const LpiHmiDemandList &data)
{
    LpdbDemandObservable::GetInstance()->setDemand(data);
}

void LpdHmiBusinessLogicFacade::updateMeteoNow(const LpiUpdateMeteoList &data)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
      << "######## HMI: Update meteo info (nowcast): ########\n"
      << "File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;

    std::for_each(std::begin(data),
		  std::end(data),
		  [](const LpiUpdateMeteo &val)
		  { LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
		      << val << std::endl;});
#endif


    LpdbMeteoNowObservable::GetInstance()->setInfo(data);
}

void LpdHmiBusinessLogicFacade::updateMeteoFore(const LpiUpdateMeteoList &data)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
      << "######## HMI: Update meteo info (forecast): ########\n"
      << "File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;

    std::for_each(std::begin(data),
		  std::end(data),
		  [](const LpiUpdateMeteo &val)
		  { LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
		      << val << std::endl;});
#endif

    LpdbMeteoForeObservable::GetInstance()->setInfo(data);
}


