#ifndef __LPDHmi_COMPONENT_H__
#define __LPDHmi_COMPONENT_H__

#include "LpdHmiBaseComponent.h"
#include "LpdHmiBusinessLogicFacade.h"


class LpdHmiComponent : public LpdHmiBaseComponent
{
public:
   static LpdHmiComponent& Get(void)
   {
      static LpdHmiComponent component;
      return component;
   }

   // Eventos consumidos
   virtual void updateDemand(const LpiHmiDemandList &de);
   virtual void updateMeteoNow(const LpiUpdateMeteoList &de);
   virtual void updateMeteoFore(const LpiUpdateMeteoList &de);
   virtual void updateActiveScheduleRTP(const LpiScheduleRTP &de);
   virtual void updateOptimalScheduleRTP(const LpiScheduleRTP &de);

   // Servicios Proporcionados
   virtual void create(void);
   virtual void initialise(void);
   virtual void complete(void);

protected:

private:
   LpdHmiComponent() {}
   LpdHmiComponent(const LpdHmiComponent&);
   LpdHmiComponent& operator=(const LpdHmiComponent&);
   LpdHmiBusinessLogicFacade _businessLogic;


};

#endif // __LPD_COMPONENT_H__
