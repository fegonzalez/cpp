
#include "LpdHmiBaseComponent.h"

#include <LclogStream.h>

#include <iostream>
#include "LpsigSignalsHmi.h"

LpdHmiBaseComponent::LpdHmiBaseComponent():

	_pActivateScheduleEvtDelegatePublisher(
           boost::make_shared<LpiHmiActivateScheduleEvtDelegatePublisher>())
{

}


LpdHmiBaseComponent::~LpdHmiBaseComponent()
{}

void LpdHmiBaseComponent::consume(const LpiHmiActiveScheduleRTPEvt  &event)
{
   updateActiveScheduleRTP(event.getSchedule());

   LpsigSignalsHmi::Get().emitSignalActiveSchedule();

}

void LpdHmiBaseComponent::consume(const LpiHmiOptimalScheduleRTPEvt  &event)
{
   updateOptimalScheduleRTP(event.getSchedule());

   LpsigSignalsHmi::Get().emitSignalOptimalSchedule();

}

/**
 * Consumo del evento de actualizacion de la demanda de PVs
 * @param event es evento a gestionar
 */
void LpdHmiBaseComponent::consume(const LpiHmiDemandEvt  &event)
{
   updateDemand(event.getDemand());

   LpsigSignalsHmi::Get().emitSignalDemand();

}

void LpdHmiBaseComponent::consume(const LpiMeteoNowEvt  &event)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
      << "[HMI-METEO-NOWCAST] consume"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

   updateMeteoNow(event.getMeteoNowcast());

   LpsigSignalsHmi::Get().emitSignalMeteo();

}


void LpdHmiBaseComponent::consume(const LpiMeteoForeEvt  &event)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
      << "[HMI-METEO-FORECAST] consume"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif
    
   updateMeteoFore(event.getMeteoFore());

   LpsigSignalsHmi::Get().emitSignalMeteoFore();

}

void LpdHmiBaseComponent::publish(const LpiHmiActivateScheduleEvt &data)
{
   this->_pActivateScheduleEvtDelegatePublisher->publish(data);
}

void LpdHmiBaseComponent::delegatePublisher(LpiHmiIActivateScheduleEvtPublisher &publisher)
{
   this->_pActivateScheduleEvtDelegatePublisher->delegatePublisher(publisher);
}


