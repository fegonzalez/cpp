/*
 * LpdHmiConfigurationHmiParameters.cc
 *
 *  Created on: Oct 4, 2018
 *      Author: srperez
 */



#include "LpdHmiConfigurationHmiParameters.h"
#include <LpdComponent.h>

LpdHmiConfigurationHmiParameters* LpdHmiConfigurationHmiParameters::instance = NULL;

LpdHmiConfigurationHmiParameters::LpdHmiConfigurationHmiParameters()
{

    LpiResult result;
    LpdComponent::Get().getConfigurationHmiParameters(configurationHmiParameters,result);
    if(result.getResult() == LpiResult::E_OK)
    {
    }
    else
    {
        exit(0);
    }
}

LpdHmiConfigurationHmiParameters::~LpdHmiConfigurationHmiParameters()
{

}

LpdHmiConfigurationHmiParameters* LpdHmiConfigurationHmiParameters::GetInstance()
{
    if(instance == NULL){
        instance = new LpdHmiConfigurationHmiParameters();
    }

    return  instance;
}

LpiConfigurationHmiParameters LpdHmiConfigurationHmiParameters::getConfigurationHmiParameters()
{
    return configurationHmiParameters;
}


