#ifndef LPD_HMI_BASE_COMPONENT_H
#define LPD_HMI_BASE_COMPONENT_H

#include <LpiInterfaces.h>
#include <LpiFlightPlan.h>
#include <LpiHmiDemand.h>
#include <LpiMeteoInfo.h>
#include <LpiUpdateDemandEvt.h>
#include <LpiMeteoNowEvt.h>
#include <LpiMeteoForeEvt.h>
#include "LpiHmiDemandEvt.h"
#include "LpiHmiDefaultScheduleEvt.h"

class LpdHmiBaseComponent : public LpiILifeCycle
{
public:
   LpdHmiBaseComponent();
   virtual ~LpdHmiBaseComponent();

   // Notificacion de eventos consumidos
   virtual void consume(const LpiHmiDemandEvt  &event);
   virtual void consume(const LpiMeteoNowEvt  &event);
   virtual void consume(const LpiMeteoForeEvt  &event);
   virtual void consume(const LpiHmiDefaultScheduleEvt &event);

   // Notificacion de servicios requeridos

   // Subscripcion del publicador delegado



   // Subscripcion del user delegado


   // Eventos consumidos
   virtual void updateDemand(const LpiHmiDemandList &de) = 0;
   virtual void updateMeteoNow(const LpiUpdateMeteoList &de) = 0;
   virtual void updateMeteoFore(const LpiUpdateMeteoList &de) = 0;
   virtual void updateDefaultSchedule(const std::vector<std::vector<std::string>> &de) = 0;

   // Eventos publicados


   // Servicios proporcionados


   // Servicios usados


//Ojo  comentar para pruebas protected
protected:
   // Eventos publicados hacia el publicador delegado


   // Servicios requeridos hacia el user delegado



private:



 };

#endif // LPD_BASE_COMPONENT_H
