
#include "LpdHmiComponent.h"

#include <LclogStream.h>

#include <iostream>
#include <ctime>




void LpdHmiComponent::updateDemand(const LpiHmiDemandList &de)
{
   this->_businessLogic.updateDemand(de);
}

void LpdHmiComponent::updateMeteoNow(const LpiUpdateMeteoList &de)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
      << "File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

   this->_businessLogic.updateMeteoNow(de);
}

void LpdHmiComponent::updateMeteoFore(const LpiUpdateMeteoList &de)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
      << "File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

   this->_businessLogic.updateMeteoFore(de);
}

/**
 * Creacion del componenteLpdHmiBaseComponent.cc
*/
void LpdHmiComponent::create(void)
{
   //this->_rules.create();
}

/**
 * Inicializacion del componente
*/
void LpdHmiComponent::initialise(void)
{
   this->_businessLogic.initialise();
}

/**
 * Finalizacion del procesado del componente
*/
void LpdHmiComponent::complete(void)
{
   this->_businessLogic.complete();
}




