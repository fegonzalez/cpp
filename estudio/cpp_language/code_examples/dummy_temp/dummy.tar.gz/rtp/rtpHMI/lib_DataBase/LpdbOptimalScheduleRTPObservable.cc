/*
 * LpdbDefaultScheduleObservable.cc
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */


#include "LpdbOptimalScheduleRTPObservable.h"

LpdbOptimalScheduleRTPObservable* LpdbOptimalScheduleRTPObservable::instance = NULL;

LpdbOptimalScheduleRTPObservable::LpdbOptimalScheduleRTPObservable()
{
//	for(unsigned int i = 0; i < demand.size(); i++)
//	{
//		demand.at(i).getTotalDemandForecast().reset();
//		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
//		{
//			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
//		}
//		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
//	}
}

LpdbOptimalScheduleRTPObservable::~LpdbOptimalScheduleRTPObservable()
{
//	for(unsigned int i = 0; i < demand.size(); i++)
//	{
//		demand.at(i).getTotalDemandForecast().reset();
//		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
//		{
//			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
//		}
//		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
//	}
}

LpdbOptimalScheduleRTPObservable* LpdbOptimalScheduleRTPObservable::GetInstance()
{
    if(instance == NULL){
        instance = new LpdbOptimalScheduleRTPObservable();
    }

    return  instance;
}

void LpdbOptimalScheduleRTPObservable::Trigger()
{
    this->NotifyObservers();
}
