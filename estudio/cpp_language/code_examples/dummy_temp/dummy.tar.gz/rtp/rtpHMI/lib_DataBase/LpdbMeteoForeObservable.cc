#include "LpdbMeteoForeObservable.h"
#include <cassert>

LpdbMeteoForeObservable* LpdbMeteoForeObservable::instance = NULL;

LpdbMeteoForeObservable::LpdbMeteoForeObservable()
{
}

LpdbMeteoForeObservable::~LpdbMeteoForeObservable()
{
}

LpdbMeteoForeObservable* LpdbMeteoForeObservable::GetInstance()
{
    if(instance == NULL){
        instance = new LpdbMeteoForeObservable();
    }

    return  instance;
}

void LpdbMeteoForeObservable::Trigger()
{
    this->NotifyObservers();
}

LpiUpdateMeteo& LpdbMeteoForeObservable::getInfo(unsigned int index)
{
  assert(index < meteoInfo.size());
  return meteoInfo[index];
}
