/*
 * LpdbDefaultScheduleObservable.cc
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */


#include "LpdbDefaultScheduleObservable.h"

LpdbDefaultScheduleObservable* LpdbDefaultScheduleObservable::instance = NULL;

LpdbDefaultScheduleObservable::LpdbDefaultScheduleObservable()
{
//	for(unsigned int i = 0; i < demand.size(); i++)
//	{
//		demand.at(i).getTotalDemandForecast().reset();
//		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
//		{
//			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
//		}
//		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
//	}
}

LpdbDefaultScheduleObservable::~LpdbDefaultScheduleObservable()
{
//	for(unsigned int i = 0; i < demand.size(); i++)
//	{
//		demand.at(i).getTotalDemandForecast().reset();
//		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
//		{
//			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
//		}
//		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
//	}
}

LpdbDefaultScheduleObservable* LpdbDefaultScheduleObservable::GetInstance()
{
    if(instance == NULL){
        instance = new LpdbDefaultScheduleObservable();
    }

    return  instance;
}

void LpdbDefaultScheduleObservable::Trigger()
{
    this->NotifyObservers();
}
