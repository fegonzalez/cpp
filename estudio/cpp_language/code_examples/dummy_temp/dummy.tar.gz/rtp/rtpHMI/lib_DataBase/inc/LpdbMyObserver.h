#ifndef LPDBMYOBSERVER_H
#define LPDBMYOBSERVER_H

class LpdbMyObserver
{
public:
    virtual void Notify() = 0;
    virtual ~LpdbMyObserver(){}
};

#endif // LPDBMYOBSERVER_H
