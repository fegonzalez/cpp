/*
 * LpdbDefaultScheduleObservable.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPDBOPTIMALSCHEDULEOBSERVABLE_H_
#define LPDBOPTIMALSCHEDULEOBSERVABLE_H_

#include <QVector>
#include "LpdbMyObservable.h"
#include "LpiScheduleRTP.h"

class LpdbOptimalScheduleRTPObservable : public LpdbMyObservable
{
public:
    static LpdbOptimalScheduleRTPObservable* GetInstance(void);
    LpiScheduleRTP& getOptimalScheduleRTP(void) {return sch;}

    void setOptimalScheduleRTP(const LpiScheduleRTP& schAux){sch = schAux;}
    void Trigger();

    virtual ~LpdbOptimalScheduleRTPObservable();

private:
    LpdbOptimalScheduleRTPObservable();
    static LpdbOptimalScheduleRTPObservable* instance;
    LpiScheduleRTP sch;
};



#endif /* LPDBDEFAULTSCHEDULEOBSERVABLE_H_ */
