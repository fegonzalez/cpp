/*
 * LpdbDefaultScheduleObservable.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPDBDEFAULTSCHEDULEOBSERVABLE_H_
#define LPDBDEFAULTSCHEDULEOBSERVABLE_H_

#include <QVector>
#include "LpdbMyObservable.h"
#include "LpiScheduleRTP.h"

class LpdbActiveScheduleRTPObservable : public LpdbMyObservable
{
public:
    static LpdbActiveScheduleRTPObservable* GetInstance(void);
    LpiScheduleRTP& getActiveScheduleRTP(void) {return sch;}

    void setActiveScheduleRTP(const LpiScheduleRTP& schAux){sch = schAux;}
    void Trigger();

    virtual ~LpdbActiveScheduleRTPObservable();

private:
    LpdbActiveScheduleRTPObservable();
    static LpdbActiveScheduleRTPObservable* instance;
    LpiScheduleRTP sch;
};



#endif /* LPDBDEFAULTSCHEDULEOBSERVABLE_H_ */
