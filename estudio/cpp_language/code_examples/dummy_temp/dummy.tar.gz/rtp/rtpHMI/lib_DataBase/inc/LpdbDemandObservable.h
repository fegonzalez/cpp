#ifndef LPBDEMANDOBSERVABLE_H
#define LPBDEMANDOBSERVABLE_H

#include <LpiHmiDemand.h>
#include <QVector>
#include "LpdbMyObservable.h"

class LpdbDemandObservable : public LpdbMyObservable
{
public:

    static LpdbDemandObservable* GetInstance(void);
    LpiHmiDemandList& getDemand(void) {return demand;}

    void setDemand(const LpiHmiDemandList& demandAux){demand = demandAux;}
    void Trigger();

    virtual ~LpdbDemandObservable();

private:
    LpdbDemandObservable();
    static LpdbDemandObservable* instance;
    LpiHmiDemandList demand;
};

#endif // LPBDEMANDOBSERVABLE_H
