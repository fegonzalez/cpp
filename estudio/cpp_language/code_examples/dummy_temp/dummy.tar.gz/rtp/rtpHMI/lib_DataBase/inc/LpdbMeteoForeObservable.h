#ifndef LPDBMETEOFOREOBSERVABLE_H
#define LPDBMETEOFOREOBSERVABLE_H

#include <LpdbMyObservable.h>
#include <LpiMeteoInfo.h> // LpiUpdateMeteoList


class LpdbMeteoForeObservable : public LpdbMyObservable
{
public:

    static LpdbMeteoForeObservable* GetInstance(void);

    LpiUpdateMeteoList& getInfo() { return meteoInfo; }

    LpiUpdateMeteo& getInfo(unsigned int index);
    
    void setInfo(const LpiUpdateMeteoList &meteoInfoAux)
    { meteoInfo = meteoInfoAux; }
    
    void Trigger();
    virtual ~LpdbMeteoForeObservable();

private:
    LpdbMeteoForeObservable();
    static LpdbMeteoForeObservable* instance;
    LpiUpdateMeteoList meteoInfo;
};

#endif // LPBMETEOINFOOBSERVABLE_H
