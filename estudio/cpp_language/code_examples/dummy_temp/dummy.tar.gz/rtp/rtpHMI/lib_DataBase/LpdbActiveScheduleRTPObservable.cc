/*
 * LpdbDefaultScheduleObservable.cc
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */


#include "LpdbActiveScheduleRTPObservable.h"

LpdbActiveScheduleRTPObservable* LpdbActiveScheduleRTPObservable::instance = NULL;

LpdbActiveScheduleRTPObservable::LpdbActiveScheduleRTPObservable()
{
//	for(unsigned int i = 0; i < demand.size(); i++)
//	{
//		demand.at(i).getTotalDemandForecast().reset();
//		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
//		{
//			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
//		}
//		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
//	}
}

LpdbActiveScheduleRTPObservable::~LpdbActiveScheduleRTPObservable()
{
//	for(unsigned int i = 0; i < demand.size(); i++)
//	{
//		demand.at(i).getTotalDemandForecast().reset();
//		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
//		{
//			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
//		}
//		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
//	}
}

LpdbActiveScheduleRTPObservable* LpdbActiveScheduleRTPObservable::GetInstance()
{
    if(instance == NULL){
        instance = new LpdbActiveScheduleRTPObservable();
    }

    return  instance;
}

void LpdbActiveScheduleRTPObservable::Trigger()
{
    this->NotifyObservers();
}
