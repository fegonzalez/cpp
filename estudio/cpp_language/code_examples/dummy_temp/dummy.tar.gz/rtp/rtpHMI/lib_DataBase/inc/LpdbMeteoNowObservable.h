#ifndef LPBMETEONOWOBSERVABLE_H
#define LPBMETEONOWOBSERVABLE_H

#include <LpdbMyObservable.h>
#include <LpiMeteoInfo.h> // LpiUpdateMeteoList


class LpdbMeteoNowObservable : public LpdbMyObservable
{
public:

    static LpdbMeteoNowObservable* GetInstance(void);

    LpiUpdateMeteoList& getInfo() { return meteoInfo; }

    LpiUpdateMeteo& getInfo(unsigned int index);

    void setInfo(const LpiUpdateMeteoList &meteoInfoAux)
    { meteoInfo = meteoInfoAux; }

    void Trigger();
    virtual ~LpdbMeteoNowObservable();

private:
    LpdbMeteoNowObservable();
    static LpdbMeteoNowObservable* instance;
    LpiUpdateMeteoList meteoInfo;
};

#endif // LPBMETEOINFOOBSERVABLE_H
