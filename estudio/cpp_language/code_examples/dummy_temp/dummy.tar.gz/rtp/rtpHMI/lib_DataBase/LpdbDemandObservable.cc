#include "LpdbDemandObservable.h"

LpdbDemandObservable* LpdbDemandObservable::instance = NULL;

LpdbDemandObservable::LpdbDemandObservable()
{
	for(unsigned int i = 0; i < demand.size(); i++)
	{
		demand.at(i).getTotalDemandForecast().reset();
		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
		{
			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
		}
		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
	}
}

LpdbDemandObservable::~LpdbDemandObservable()
{
	for(unsigned int i = 0; i < demand.size(); i++)
	{
		demand.at(i).getTotalDemandForecast().reset();
		for (unsigned int j = 0; j < demand.at(i).getDemandForecastList().getDemandForecastVector().size(); j++)
		{
			demand.at(i).getDemandForecastList().getDemandForecast(j).reset();
		}
		demand.at(i).getDemandForecastList().getDemandForecastVector().clear();
	}
}

LpdbDemandObservable* LpdbDemandObservable::GetInstance()
{
    if(instance == NULL){
        instance = new LpdbDemandObservable();
    }

    return  instance;
}

void LpdbDemandObservable::Trigger()
{
    this->NotifyObservers();
}
