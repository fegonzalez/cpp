#ifndef LPDBMYOBSERVABLE_H
#define LPDBMYOBSERVABLE_H

#include <vector>
#include "LpdbMyObserver.h"

class LpdbMyObservable
{
public:
    void AddObserver (LpdbMyObserver* o);
    //void RemoveObserver(LpdbMyObserver*);
    virtual void NotifyObservers();
    virtual ~LpdbMyObservable(){}

private:
    std::vector<LpdbMyObserver*> observers;
};

#endif // LPDBMYOBSERVABLE_H
