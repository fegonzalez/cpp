/*
 * LpdbDefaultScheduleObservable.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPDBDEFAULTSCHEDULEOBSERVABLE_H_
#define LPDBDEFAULTSCHEDULEOBSERVABLE_H_

#include <QVector>
#include "LpdbMyObservable.h"

class LpdbDefaultScheduleObservable : public LpdbMyObservable
{
public:
    static LpdbDefaultScheduleObservable* GetInstance(void);
    std::vector<std::vector<std::string>>& getDefaultSchedule(void) {return defaultSch;}

    void setDefaultSchedule(const std::vector<std::vector<std::string>>& defaultSchAux){defaultSch = defaultSchAux;}
    void Trigger();

    virtual ~LpdbDefaultScheduleObservable();

private:
    LpdbDefaultScheduleObservable();
    static LpdbDefaultScheduleObservable* instance;
    std::vector<std::vector<std::string>> defaultSch;
};



#endif /* LPDBDEFAULTSCHEDULEOBSERVABLE_H_ */
