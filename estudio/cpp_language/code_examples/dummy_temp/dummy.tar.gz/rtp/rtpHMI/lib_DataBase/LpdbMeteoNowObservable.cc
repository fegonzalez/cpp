#include "LpdbMeteoNowObservable.h"
#include <cassert>

LpdbMeteoNowObservable* LpdbMeteoNowObservable::instance = NULL;

LpdbMeteoNowObservable::LpdbMeteoNowObservable()
{
    //meteoInfo.clear();
}

LpdbMeteoNowObservable::~LpdbMeteoNowObservable()
{
    //meteoInfo.clear();
}

LpdbMeteoNowObservable* LpdbMeteoNowObservable::GetInstance()
{
    if(instance == NULL){
        instance = new LpdbMeteoNowObservable();
    }

    return  instance;
}

void LpdbMeteoNowObservable::Trigger()
{
    this->NotifyObservers();
}

LpiUpdateMeteo& LpdbMeteoNowObservable::getInfo(unsigned int index)
{
  assert(index < meteoInfo.size());
  return meteoInfo[index];
}
