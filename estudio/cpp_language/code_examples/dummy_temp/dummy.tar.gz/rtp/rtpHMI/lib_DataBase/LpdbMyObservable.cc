#include "LpdbMyObservable.h"

#include <iostream>

void LpdbMyObservable::AddObserver(LpdbMyObserver* o)
{
    observers.push_back(o);
}

/*void LpdbMyObservable::RemoveObserver(LpdbMyObserver* o)
{

    std::vector<LpdbMyObserver*>::iterator it;
    for(it = observers.begin(); it < observers.end(); it++)
    {
        if(it == o)
        {
            observers.erase(it);
            break;
        }
    }
    if(it == observers.end())
    {
    }
}*/

void LpdbMyObservable::NotifyObservers()
{
    std::vector<LpdbMyObserver*>::iterator it;
    for(it = observers.begin(); it < observers.end(); it++)
    {
        (*it)->Notify();
    }
}
