<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES" sourcelanguage="en_GB">
<context>
    <name>RtpBaseDownSide</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asedownside.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asedownside.ui" line="29"/>
        <source>FLIGHT LIST</source>
        <translation>Lista de vuelos</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asedownside.ui" line="61"/>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="45"/>
        <source>ADEP</source>
        <translation>ADEP</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asedownside.ui" line="87"/>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="46"/>
        <source>ADES</source>
        <translation>ADES</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="44"/>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="44"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="44"/>
        <source>Callsign</source>
        <translation>Señal llamada</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="45"/>
        <source>A/C Type</source>
        <translation>Tipo A/C</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="45"/>
        <source>ETOT</source>
        <translation>ETOT</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="46"/>
        <source>ELDT</source>
        <translation>ELDT</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_asedownside.cpp" line="62"/>
        <source>Could not open file for reading</source>
        <translation>No se puede abrir el fichero</translation>
    </message>
</context>
<context>
    <name>RtpBaseUpSide</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="26"/>
        <source>METEO</source>
        <translation>METEO</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="56"/>
        <source>Airport</source>
        <translation>Aeropuerto</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="109"/>
        <source>Tab 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="126"/>
        <location filename="DAORTP_miSource/DAORTP_aseupside.cpp" line="25"/>
        <source>METAR</source>
        <translation>METAR</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="174"/>
        <source>TAF</source>
        <translation>TAF</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="197"/>
        <source>Tab 2</source>
        <translation>Notam</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_aseupside.ui" line="211"/>
        <source>NOTAMs</source>
        <translation></translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_aseupside.cpp" line="26"/>
        <source>NOTAM</source>
        <translation>NOTAM</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_aseupside.cpp" line="34"/>
        <source>Could not open file for reading</source>
        <translation>No se puede abrir el fichero</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_aseupside.cpp" line="86"/>
        <source>5h 2m ago</source>
        <translation>Hace 5h 2m</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_aseupside.cpp" line="88"/>
        <source>3h 25m ago</source>
        <translation>Hace 3h 25m</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_aseupside.cpp" line="90"/>
        <source>In progress</source>
        <translation>En progreso</translation>
    </message>
</context>
<context>
    <name>RtpMain</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ain.ui" line="20"/>
        <source>RtpMain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RtpbaseCentral</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="196"/>
        <source>New Sandbox</source>
        <translation>Nuevo Sanbox</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="375"/>
        <source>Delete Sandbox</source>
        <translation>Borrar Sanbox</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="554"/>
        <source>Commit Sandbox</source>
        <translation>Commit Sandbox</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="746"/>
        <source>Traffic Workload</source>
        <translation>Carga de trabajo</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="925"/>
        <source>Simultaneous Movements</source>
        <translation>Movimientos simultáneos</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="1104"/>
        <source>METEO</source>
        <translation>METEO</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="1283"/>
        <source>ALPHA</source>
        <translation>ALPHA</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="1462"/>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="1668"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_asecentral.ui" line="1847"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
</context>
<context>
    <name>DAORTP_ase</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ase.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DAORTP_hart</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_hart.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DAORTP_ilterFlightList</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ilterflightlist.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_ilterflightlist.cpp" line="10"/>
        <source>Select the airports: </source>
        <translation>Selecciona el aeropuerto:</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_ilterflightlist.cpp" line="15"/>
        <source>Could not open file for reading</source>
        <translation>No se puede abrir el fichero</translation>
    </message>
</context>
<context>
    <name>DAORTP_ooter</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="79"/>
        <source>CONFIGURATION</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="125"/>
        <source>MONITORING</source>
        <translation>Monitorización</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="145"/>
        <source>ANALYSIS MODE</source>
        <translation>Modo análisis</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="202"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="221"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="237"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="253"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="269"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_ooter.ui" line="296"/>
        <source>CUSTOMISATION</source>
        <translation>Personalización</translation>
    </message>
</context>
<context>
    <name>DAORTP_eader</name>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="113"/>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="135"/>
        <source>USER</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="164"/>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="171"/>
        <source>SUPERVISOR</source>
        <translation>Supervisor</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="229"/>
        <source>Current Date &amp; Time</source>
        <translation>Fecha y hora actual</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="236"/>
        <source>10:10:51</source>
        <translation></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="243"/>
        <source>01/11/2018</source>
        <translation></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="279"/>
        <source>Allocation</source>
        <translation>Asginación</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="286"/>
        <source>GROUND NORTH</source>
        <translation>Norte</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="495"/>
        <source>FP</source>
        <translation>FP</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="681"/>
        <source>METEO</source>
        <translation>METEO</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="867"/>
        <source>XXX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="903"/>
        <source>System Messages</source>
        <translation>Mensajes del sistema</translation>
    </message>
    <message>
        <location filename="DAORTP_miUserInterface/DAORTP_eader.ui" line="967"/>
        <source>Logout</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_eader.cpp" line="17"/>
        <source>THE SYSTEM IS OK1</source>
        <translation>El sistema es OK 1</translation>
    </message>
    <message>
        <location filename="DAORTP_miSource/DAORTP_eader.cpp" line="18"/>
        <source>THE SYSTEM IS OK2</source>
        <translation>El sistema es OK 2</translation>
    </message>
</context>
</TS>
