#include "LpwHmiMain.h"

#include "LpdComponent.h"
#include "LpaAdaptationManager.h"
#include "LpcfgConfigurationManager.h"

#include <QApplication>
#include <QFile>
#include <iostream>
#include <QDebug>
#include <QTranslator>
#include <QInputDialog>

#include <LpcHmiCommunicationsManager.h>

#include <LclogStream.h>
#include <rtpHmiResources.rcc>


int main(int argc, char *argv[])
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).notify() << "starting RTP-HMI" << std::endl;

//    ///@warning Upgrading iMASBlue capacity; goal is remove event creation bug.
//    DDS_DomainParticipantFactoryQos factoryQoS;
//    DDSTheParticipantFactory->get_qos(factoryQoS);
//    /* increase max_objects_per_thread as needed.
//       The default is 1024 (512 for 4.4c and below).*/
//    factoryQoS.resource_limits.max_objects_per_thread = 4096;
//    DDSTheParticipantFactory->set_qos(factoryQoS);

    QApplication the_qapp(argc, argv);

    LclogStream::instance(LclogConfig::E_RTP_HMI);

    QTranslator T;
    QStringList langs;
    langs << "English" << "Español";

    QFile filebasic(":/resources/basicStyleSheet.css");
    QFile filecustom(":/resources/customStyleSheet.css");
    filebasic.open(QFile::ReadOnly);
    filecustom.open(QFile::ReadOnly);
    QString styleb = QLatin1String(filebasic.readAll());
    QString stylec = QLatin1String(filecustom.readAll());

    QFile file("combineStyleSheet.css");
    QTextStream out(&file);

    if (file.open(QFile::WriteOnly | QFile::Text))
    {
        out << styleb;
        out << stylec;
        file.close();
    }
    else
        LclogStream::instance(LclogConfig::E_RTP_HMI).error() << "Error open file";

    file.open(QFile::ReadOnly);
    QString style = QLatin1String(file.readAll());
    the_qapp.setStyleSheet(style);

    // Uncomment or comment the next 3 lines if you want the app internationalized or not

    //QString lang = QInputDialog::getItem(NULL, " ", "Select the language", langs);
    //if (lang == "Español") T.load(":/resources/espanol.qm");
    //if (lang != "English") the_qapp.installTranslator(&T);

    // End of the part for the internationalization
    LpaAdaptationManager::Get().initialise();

    LpcfgConfigurationManager::Get().initialise();



    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
     		<< " : File: " << __FILE__
 			<< " ; fn: " << __func__
 			<< " ; line: " << __LINE__
 			<< std::endl;

    LpcHmiCommunicationsManager::Get().initialise();

    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
     		<< " : File: " << __FILE__
 			<< " ; fn: " << __func__
 			<< " ; line: " << __LINE__
 			<< std::endl;

    LpcHmiCommunicationsManager::Get().waitForEvents();

    LclogStream::instance(LclogConfig::E_RTP_HMI).notify() << "[ HMI: COMMUNICATIONS INITIALIZATED ----]" << std::endl;

    LpwHmiMain w;
    w.setWindowFlags(Qt::FramelessWindowHint);
    w.showFullScreen();

    return the_qapp.exec();


}
