// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):     icima
 Created:   23/3/2015 9:29:51 2015
 Release:   $Revision$
 Modified:  $Date$
 Path:      $Source$
*/
//---------------------------------------------------------------------------
#ifndef LPCMETEOTIMELINEHMI_H_
#define LPCMETEOTIMELINEHMI_H_

#include <IOMeteoTimeline.h>
#include "LpiMeteoTimeLineHmi.h"


class LpcMeteoTimeLineHmi
{
public:
    static void convertIO2LpiMeteoTimeLine(const IOMeteoTimeline::MeteoTimeIntervalData &in, LpiMeteoTimeLineHmi &out);

};

#endif /* LPCMETEOTIMELINE_H_ */
