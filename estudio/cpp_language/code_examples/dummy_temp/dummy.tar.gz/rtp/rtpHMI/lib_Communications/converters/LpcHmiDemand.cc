#include <LcuStringArrayConvUtils.h>

#include <IOConstant.h>
#include <LctimTimeUtils.h>
#include <LpcHmiCalculationReason.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/algorithm/string/trim.hpp>
#include "LpcHmiDemand.h"
#include "LpcHmiVectorAdo.h"

void OptionalTime2Posix_time(const IOTim::OptionalTimeU & optionaltime,
                             boost::optional<posix_time::ptime> & pos_time)
{
   if(optionaltime._d == true)
   {
      pos_time = posix_time::from_time_t(optionaltime._u.value);
   }
   else
   {
      pos_time = boost::none;
   }
}

posix_time::ptime convertDate(std::string date)
{
	std::string dia = date.substr(0, 2);
	std::string mes = date.substr(2, 2);
	std::string anio = "20" + date.substr(4, 2);
	std::string hora = date.substr(6, 2);
	std::string minuto = date.substr(8, 2);

	std::string startDate = anio + mes + dia + " " + hora + ":" + minuto;


	const std::locale loc = std::locale(std::locale::classic(), new boost::posix_time::time_input_facet("%Y%m%d %H:%M%f"));
	std::istringstream is(startDate);
	is.imbue(loc);
	boost::posix_time::ptime t;
	is >> t;
	return t;
}

void LpcHmiDemand::convert2Demand(const IOUpdateDemandRTP::Demand &in, LpiHmiDemand &out)
{
    posix_time::ptime timeAndDate;
    timeAndDate =
            LctimTimeUtils::getFromString(in.timeAndDate);
    out.setTimeAndDate(timeAndDate);

    LpcHmiCalculationReason::convertIO2LpiCalculationReason(in.calculationReason, out.getCalculationReason());

    out.setTotalDemandForecast(LpcHmiVectorAdo::IOADO2LpiHmiVectorAdo(in.total_demand_forecast));
    out.setTotalRatio(LpcHmiVectorAdo::IOADO2LpiHmiVectorAdo(in.total_ratio));
    out.setTotalVFR(LpcHmiVectorAdo::IOADO2LpiHmiVectorAdo(in.total_vfr));

    out.setNameAirport(in.airport);

    std::string demandStartTimeAndDate;
    demandStartTimeAndDate += in.demandStartTimeAndDate;
    boost::posix_time::ptime startConverted = convertDate(demandStartTimeAndDate.substr(5, 10));
	out.setDemandStartTimeAndDate(startConverted);

	std::string demandEndTimeAndDate;
	demandEndTimeAndDate += in.demandEndTimeAndDate;
	boost::posix_time::ptime endConverted = convertDate(demandEndTimeAndDate.substr(5, 10));
	out.setDemandEndTimeAndDate(endConverted);

    LpiFlightPlanList fpList;
    for(int x = 0; x <in.fligthPlanList.length(); x++)
    {
    	LpiFlightPlan fp;
		fp.setCallsign(in.fligthPlanList.get_at(x).fpKey.callsign);
		fp.setDepartureAerodrome(in.fligthPlanList.get_at(x).fpKey.depAerodrome);
		fp.setArrivalAerodrome(in.fligthPlanList.get_at(x).fpKey.arrAerodrome);
		fp.setAircraftType(in.fligthPlanList.get_at(x).acType);

		LpiDepartureTimes depTimes;
		boost::optional<posix_time::ptime> eobt_time;
		boost::optional<posix_time::ptime> sobt_time;
		boost::optional<posix_time::ptime> tobt_time;
		boost::optional<posix_time::ptime> etot_time;
		boost::optional<posix_time::ptime> ttot_time;
		boost::optional<posix_time::ptime> stot_time;
		boost::optional<posix_time::ptime> atot_time;
		boost::optional<posix_time::ptime> ctot_time;
		boost::optional<posix_time::ptime> utot_time;

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.eobt, eobt_time);
		if (eobt_time)
		  depTimes.setEobt(*eobt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.sobt, sobt_time);
		if (sobt_time)
		  depTimes.setSobt(*sobt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.tobt, tobt_time);
		if (tobt_time)
		  depTimes.setTobt(*tobt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.etot, etot_time);
		if (etot_time)
		  depTimes.setEtot(*etot_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.ttot, ttot_time);
		if (ttot_time)
		  depTimes.setTtot(*ttot_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.stot, stot_time);
		if (stot_time)
		  depTimes.setStot(*stot_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.atot, atot_time);
		if (atot_time)
		  depTimes.setAtot(*atot_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.ctot, ctot_time);
		if (ctot_time)
		  depTimes.setCtot(*ctot_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).depInfo.utot, utot_time);
		if (utot_time)
		  depTimes.setUtot(*utot_time);

		fp.setDepartureTimes(depTimes);


		LpiArrivalTimes arrTimes;
		boost::optional<posix_time::ptime> eldt_time;
		boost::optional<posix_time::ptime> tldt_time;
		boost::optional<posix_time::ptime> aldt_time;
		boost::optional<posix_time::ptime> sldt_time;
		boost::optional<posix_time::ptime> sibt_time;
		boost::optional<posix_time::ptime> uldt_time;

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).arrInfo.eldt, eldt_time);
		if (eldt_time)
			arrTimes.setEldt(*eldt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).arrInfo.tldt, tldt_time);
		if (tldt_time)
			arrTimes.setTldt(*tldt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).arrInfo.aldt, aldt_time);
		if (aldt_time)
			arrTimes.setAldt(*aldt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).arrInfo.sldt, sldt_time);
		if (sldt_time)
			arrTimes.setSldt(*sldt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).arrInfo.sibt, sibt_time);
		if (sibt_time)
			arrTimes.setSibt(*sibt_time);

		OptionalTime2Posix_time(in.fligthPlanList.get_at(x).arrInfo.uldt, uldt_time);
		if (uldt_time)
			arrTimes.setUldt(*uldt_time);

		fp.setArrivalTimes(arrTimes);

		fpList.push_back(fp);
    }
    out.setFlightPlanlist(fpList);

    out.getDemandForecastList().getDemandForecastVector().clear();
    for(int i=0; i<in.demandForecast.length(); i++)
    {
        Demand_Forecast demand;

        std::string startTimeAndDate;
        LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).starTimeAndDate, startTimeAndDate);
        demand.setStartTimeAndDate(boost::algorithm::trim_right_copy(startTimeAndDate));

        std::string endTimeAndDate;
        LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).endTimeAndDate, endTimeAndDate);
        demand.setEndTimeAndDate(boost::algorithm::trim_right_copy(endTimeAndDate));

        std::string name;
        LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).intervalName, name);
        demand.setName(name);

        demand.setDemandForecast(LpcHmiVectorAdo::IOADO2LpiHmiVectorAdo(
                    in.demandForecast.get_at(i).demand_forecast));

        demand.setRatio(LpcHmiVectorAdo::IOADO2LpiHmiVectorAdo(
                    in.demandForecast.get_at(i).ratio));
        demand.setVFR(LpcHmiVectorAdo::IOADO2LpiHmiVectorAdo(
					in.demandForecast.get_at(i).vfr));

        Fps fp;
        for(int j=0; j<in.demandForecast.get_at(i).fp.arrivals.length(); j++)
        {
            std::string acType;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.arrivals.get_at(j).acType, acType);
            fp.setAcType(acType);
            std::string fpAux;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.arrivals.get_at(j).fp, fpAux);
            fp.setFp(fpAux);


            boost::optional<posix_time::ptime> time;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.arrivals.get_at(j).itot_ildt, time);
            if(time)
            {
                fp.setItotIldt(
                        LctimTimeUtils::formatTime(*time, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setItotIldt("");
            }

            boost::optional<posix_time::ptime> time2;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.arrivals.get_at(j).stot_sldt, time2);
            if(time2)
            {
                fp.setStotSldt(
                        LctimTimeUtils::formatTime(*time2, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setStotSldt("");
            }

            boost::optional<posix_time::ptime> time3;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.arrivals.get_at(j).etot_eldt, time3);
            if(time3)
            {
                fp.setEtotEldt(
                        LctimTimeUtils::formatTime(*time3, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setEtotEldt("");
            }

            boost::optional<posix_time::ptime> time4;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.arrivals.get_at(j).ttot_tldt, time4);
            if(time4)
            {
                fp.setTtotTldt(
                        LctimTimeUtils::formatTime(*time4, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setTtotTldt("");
            }

            boost::optional<posix_time::ptime> time6;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.arrivals.get_at(j).utot_uldt, time6);
            if(time6)
            {
                fp.setUtotUldt(
                        LctimTimeUtils::formatTime(*time6, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setUtotUldt("");
            }

            boost::optional<posix_time::ptime> time5;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.arrivals.get_at(j).ctot_sibt, time5);
            if(time5)
            {
                fp.setCtotSibt(
                        LctimTimeUtils::formatTime(*time5, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setCtotSibt("");
            }

            std::string opType;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.arrivals.get_at(j).opType, opType);
            fp.setOpType(opType);
            std::string proced;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.arrivals.get_at(j).proced, proced);
            fp.setProeced(proced);
            demand.getFpList().setFPs(fp);

        }
        for(int j=0; j<in.demandForecast.get_at(i).fp.departure.length(); j++)
        {
            std::string acType;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.departure.get_at(j).acType, acType);
            fp.setAcType(acType);
            std::string fpAux;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.departure.get_at(j).fp, fpAux);
            fp.setFp(fpAux);

            boost::optional<posix_time::ptime> time;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.departure.get_at(j).itot_ildt, time);
            if(time)
            {
                fp.setItotIldt(
                        LctimTimeUtils::formatTime(*time, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setItotIldt("");
            }

            boost::optional<posix_time::ptime> time2;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.departure.get_at(j).stot_sldt, time2);
            if(time2)
            {
                fp.setStotSldt(
                        LctimTimeUtils::formatTime(*time2, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setStotSldt("");
            }

            boost::optional<posix_time::ptime> time3;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.departure.get_at(j).etot_eldt, time3);
            if(time3)
            {
                fp.setEtotEldt(
                        LctimTimeUtils::formatTime(*time3, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setEtotEldt("");
            }

            boost::optional<posix_time::ptime> time4;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.departure.get_at(j).ttot_tldt, time4);
            if(time4)
            {
                fp.setTtotTldt(
                        LctimTimeUtils::formatTime(*time4, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setTtotTldt("");
            }

            boost::optional<posix_time::ptime> time6;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.departure.get_at(j).utot_uldt, time6);
            if(time6)
            {
                fp.setUtotUldt(
                        LctimTimeUtils::formatTime(*time6, "%d/%m/Y% %H:%M"));
            }
            else
            {
                fp.setUtotUldt("");
            }

            boost::optional<posix_time::ptime> time5;
            LpiHmiVectorAdo::OptionalTime2Posix_time(in.demandForecast.get_at(i).fp.departure.get_at(j).ctot_sibt, time5);
            if(time5)
            {
                fp.setCtotSibt(
                        LctimTimeUtils::formatTime(*time5, "%d/%m/%Y %H:%M"));
            }
            else
            {
                fp.setCtotSibt("");
            }

            std::string opType;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.departure.get_at(j).opType, opType);
            fp.setOpType(opType);
            std::string proced;
            LcuStringArrayConvUtils::Array2String(in.demandForecast.get_at(i).fp.departure.get_at(j).proced, proced);
            fp.setProeced(proced);
            demand.getFpList().setFPs(fp);
        }
        out.getDemandForecastList().setDemandForecast(demand);

    }

}
