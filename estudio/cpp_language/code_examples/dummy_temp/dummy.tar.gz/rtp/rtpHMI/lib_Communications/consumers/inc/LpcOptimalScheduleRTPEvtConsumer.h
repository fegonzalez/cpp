/*
 * LpcDefaultScheduleEvtConsumer.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPCOPTIMALSCHEDULEEVTCONSUMER_H_
#define LPCOPTIMALSCHEDULEEVTCONSUMER_H_


#include <IOScheduleRTPEventsiBContract.h>



class LpcOptimalScheduleRTPEvtConsumer : public iBG::IOScheduleRTPEvents::OptimalScheduleActivationSubscriberListener
{
public:
    void init(void);

    void on_data_available(iBG::IOScheduleRTPEvents::OptimalScheduleActivationSubscriber &sub);
};


#endif /* LPCDEFAULTSCHEDULEEVTCONSUMER_H_ */
