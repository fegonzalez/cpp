/*
 * LpcHmiCommunicationsManager.cc
 *
 */

#include "LpcHmiCommunicationsManager.h"

#include <LclogStream.h>

#include <boost/make_shared.hpp>




void wait()
{
    while (1)
    {
        boost::this_thread::sleep(boost::posix_time::milliseconds(500));
    }
}

LpcHmiCommunicationsManager& LpcHmiCommunicationsManager::Get(void)
{
    static LpcHmiCommunicationsManager manager;
    return manager;
}

void LpcHmiCommunicationsManager::initialise(void)
{
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif


    _meteoNowEvtConsumer->init();


#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

    _meteoForeEvtConsumer->init();

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif



	_demandEvtConsumer->init();


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
	<< " : File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
#endif

  _activeScheduleRTPEvtConsumer->init();


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
	<< " : File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
#endif

  _optimalScheduleRTPEvtConsumer->init();


  #ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
  	<< " : File: " << __FILE__
  	<< " ; fn: " << __func__
  	<< " ; line: " << __LINE__
  	<< std::endl;
  #endif

}

LpcHmiCommunicationsManager::LpcHmiCommunicationsManager()
//        : _demandEvtConsumer(new LpcDemandEvtConsumer())
//        , _meteoNowEvtConsumer(new LpcMeteoNowEvtConsumer())
//        , _meteoForeEvtConsumer(new LpcMeteoForeEvtConsumer())
: _demandEvtConsumer(boost::make_shared<LpcDemandEvtConsumer>()),
  _meteoNowEvtConsumer(boost::make_shared<LpcMeteoNowEvtConsumer>()),
  _meteoForeEvtConsumer(boost::make_shared<LpcMeteoForeEvtConsumer>()),

  _activeScheduleRTPEvtConsumer(boost::make_shared<LpcActiveScheduleRTPEvtConsumer>()),
  _optimalScheduleRTPEvtConsumer(boost::make_shared<LpcOptimalScheduleRTPEvtConsumer>())
{

}

void LpcHmiCommunicationsManager::waitForEvents()
{
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

    boost::thread _waitThread(&wait);

    std::cout << "RTP HMI Ready: Waiting for Events..." << std::endl;
    LclogStream::instance(LclogConfig::E_RTP_HMI).notify() << "RTP HMI Server Ready: Waiting for Events..." << std::endl;
}

