
#include "LpcDemandEvtConsumer.h"

#include <IODemandEvents.h>
#include <LpiFlightPlan.h>
#include <LpiDemand.h>
#include <LcuStringArrayConvUtils.h>
#include <LctimTimeUtils.h>
#include <LclogStream.h>

#include <LpcHmiDemand.h>
#include <LpiUpdateDemandEvt.h>
#include <LpdHmiComponent.h>

#include <string>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/algorithm/string/trim.hpp>




void LpcDemandEvtConsumer::init(void)
{
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

	iB::SubscriberId sid("IODemandEvents::UpdateDemandEventList");
	iB::SubscriptionProfile sprofile;


#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__                   // último log escrito en RTP
       << std::endl;
#endif

	   try
	   {
	   iBG::IODemandEvents::UpdateDemandEventListSubscriber &subscriber =
			   iBG::IODemandEvents::UpdateDemandEventListCreateSubscriber(sid,   ///@error En madrid de aquí no pasa
					   sprofile);

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

	subscriber.addListener(this);

	   }
	   catch(std::runtime_error &err)
	   {
		   LclogStream::instance(LclogConfig::E_RTP_HMI).error()
		    		   << err.what()
					   << " : File: " << __FILE__
					   << " ; fn: " << __func__
					   << " ; line: " << __LINE__
					   << std::endl;

		   std::cerr << "\nERROR: "
				   << "std::runtime_error exception imasblue dentro de: UpdateDemandEventListCreateSubscriber / createSubscriber"
	    		   << err.what()
				   << " : File: " << __FILE__
				   << " ; fn: " << __func__
				   << " ; line: " << __LINE__
				   << std::endl;
		   exit(22);
	   }

	   catch(...)
	   {
		   LclogStream::instance(LclogConfig::E_RTP_HMI).error()
		    		   << " : File: " << __FILE__
					   << " ; fn: " << __func__
					   << " ; line: " << __LINE__
					   << std::endl;

		   std::cerr << "\nERROR: "
				   << "exception imasblue dentro de: UpdateDemandEventListCreateSubscriber / createSubscriber"
				   << " : File: " << __FILE__
				   << " ; fn: " << __func__
				   << " ; line: " << __LINE__
				   << std::endl;
		   exit(33);
	   }


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
    << "[RTP-HMI-CONSUMER: METEO-NOWCAST EVENT CONSUMER] (init)"
    << " : file: " << __FILE__
    << " ; fn: " << __func__
    << " ; line:  " << __LINE__
    << std::endl << std::endl << std::endl;
#endif
}


void LpcDemandEvtConsumer::on_data_available(iBG::IODemandEvents::UpdateDemandEventListSubscriber &sub)
{
  LclogStream::instance(LclogConfig::E_RTP_HMI).notify()
    << "[DEMAND EVENT CONSUMER] BEGIN"
    << "\t file: " << __FILE__
    << " ; FN: " << __func__
    << " ; LINE:  " << __LINE__
    << std::endl;

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
    << " : file: " << __FILE__
    << " ; fn: " << __func__
    << " ; line:  " << __LINE__
    << std::endl << std::endl << std::endl;
#endif


  std::cout << "[DEMAND EVENT CONSUMER] BEGIN" << std::endl;


   iBG::IODemandEvents::UpdateDemandEventListSubscriber::DataList dl;
   iB::DIList il;
   sub.getData(dl, il);

   //LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "DataList size:" << dl.size()
     //            << ", DIList size:" << il.size() << '\n';

   iBG::IODemandEvents::UpdateDemandEventListSubscriber::DataList::iterator dit
                                                                  = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;
   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {
      if(iit->isValid())
      {
    	  IODemandEvents::UpdateDemandList ioDemandList;
    	  ioDemandList = dit->demands;

    	  LpiHmiDemandList demandList;
    	  for (int x = 0; x < ioDemandList.length(); x++)
    	  {
				//Obtain data
				IOUpdateDemandRTP::Demand iodemand;
				iodemand = ioDemandList.get_at(x);
				
				//Create demand
				LpiHmiDemand demand;
				
				LpcHmiDemand::convert2Demand(iodemand, demand);

				demandList.push_back(demand);
			}
			
          //Event
    	  LpiHmiDemandEvt event;
          event.setDemand(demandList);
          LpdHmiComponent::Get().consume(event);

      }

   }

   std::cout << "[DEMAND EVENT CONSUMER] END" << std::endl;
  LclogStream::instance(LclogConfig::E_RTP_HMI).info()
    << "[DEMAND EVENT CONSUMER] END"
    << "\t file: " << __FILE__
    << " ; FN: " << __func__
    << " ; LINE:  " << __LINE__
    << std::endl;

}

