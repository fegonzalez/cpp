/*
 * LpcHmiScheduleRTP.cc
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#include "LpcHmiScheduleRTP.h"
#include <iostream>
#include <LcuStringArrayConvUtils.h>

void LpcHmiScheduleRTP::convert2DefaultSchedule(const IOScheduleRTP::Schedule &in, std::vector<std::vector<std::string>> &out)
{
	for(int i = 0; i < in.scheduleAirports.length(); i++)
	{
		IOScheduleRTP::MRTM mrtm = in.scheduleAirports.get_at(i);
		std::vector<std::string> mrtmStd;
		for(int j = 0; j < mrtm.mrtmAirports.length(); j++)
		{
			IOScheduleRTP::Airport airport = mrtm.mrtmAirports.get_at(j);
			std::string airportStd = airport.airportID;
			mrtmStd.push_back(airportStd);
		}
		out.push_back(mrtmStd);
	}
}
