/*
 * LpcHmiScheduleRTP.cc
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#include "LpcHmiScheduleRTP.h"
#include <iostream>
#include <LcuStringArrayConvUtils.h>

void LpcHmiScheduleRTP::convert2Schedule(const IOScheduleRTP::Schedule &in, LpiScheduleRTP &out)
{
	MRTMList mrtmListOut;
	for(int i = 0; i < in.scheduleAirports.length(); i++)
	{
		IOScheduleRTP::MRTM mrtmIn = in.scheduleAirports.get_at(i);
		MRTM mrtmOut;
		AirportsList airpListOut;

		for(int j = 0; j < mrtmIn.mrtmAirports.length(); j++)
		{
			IOScheduleRTP::Airport airportIn = mrtmIn.mrtmAirports.get_at(j);
			AirportSch airportOut;
			airportOut.setAirportID(airportIn.airportID);
			airpListOut.push_back(airportOut);

		}
		mrtmOut.setAirportsList(airpListOut);
		mrtmListOut.push_back(mrtmOut);
	}
	out.setMrtmsList(mrtmListOut);





}
