/*
 * LpcDefaultScheduleEvtConsumer.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPCDEFAULTSCHEDULEEVTCONSUMER_H_
#define LPCDEFAULTSCHEDULEEVTCONSUMER_H_


#include <IOScheduleRTPEventsiBContract.h>



class LpcDefaultScheduleEvtConsumer : public iBG::IOScheduleRTPEvents::ScheduleActivationSubscriberListener
{
public:
    void init(void);

    void on_data_available(iBG::IOScheduleRTPEvents::ScheduleActivationSubscriber &sub);
};


#endif /* LPCDEFAULTSCHEDULEEVTCONSUMER_H_ */
