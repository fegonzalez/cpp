// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):     icima
 Created:   23/3/2015 9:29:51 2015
 Release:   $Revision$
 Modified:  $Date$
 Path:      $Source$
*/
//---------------------------------------------------------------------------
#include "IOCommonTypes.h"
#include "LpcMeteoTimeLineHmi.h"
#include "LpcUtils.h"
#include "LpiMeteoTimeLineHmi.h"


void IOOptionalBool2OptionalBool(const IOCommonTypes::OptionalBool & optional,
                             boost::optional<bool> & optionalBool)
{
   if(optional._d == true)
   {
       optionalBool = optional._u.value;
   }
   else
   {
       optionalBool = boost::none;
   }
}

void IOOptionalInt2OptionalInt(const IOCommonTypes::OptionalInt & optional,
                            boost::optional<int> & optionalInt)
{
   if(optional._d == true)
   {
       optionalInt = optional._u.value;
   }
   else
   {
       optionalInt = boost::none;
   }
}

void IOOptionalFloat2OptionalFloat(const IOCommonTypes::OptionalFloat & optional,
                              boost::optional<float> & optionalFloat)
{
   if(optional._d == true)
   {
       optionalFloat = optional._u.value;
   }
   else
   {
       optionalFloat = boost::none;
   }
}

void LpcMeteoTimeLineHmi::convertIO2LpiMeteoTimeLine(const IOMeteoTimeline::MeteoTimeIntervalData &in, LpiMeteoTimeLineHmi &out)
{
    std::string intervalName;
    LpcUtils::Array2String(in.intervalName,intervalName);
    out.setIntervalName(intervalName);

    std::string startTimeAndDate;
    LpcUtils::Array2String(in.startTimeAndDate,startTimeAndDate);
    out.setStartTimeAndDate(startTimeAndDate);

    std::string endTimeAndDate;
    LpcUtils::Array2String(in.endTimeAndDate,endTimeAndDate);
    out.setEndTimeAndDate(endTimeAndDate);

    boost::optional<float> horizontalVisibility;
    IOOptionalFloat2OptionalFloat(in.meteoInfo.horizontalVisibility, horizontalVisibility);
    std::string wetness;
    LpcUtils::Array2String(in.meteoInfo.wetness,wetness);
    std::string ilsCategory;
    LpcUtils::Array2String(in.meteoInfo.ilsCategory,ilsCategory);
    boost::optional<bool> lvpActivation;
    IOOptionalBool2OptionalBool(in.meteoInfo.lvpActivation, lvpActivation);
    boost::optional<bool> deicingRequired;
    IOOptionalBool2OptionalBool(in.meteoInfo.deicingRequired, deicingRequired);
    boost::optional<float> crosswind;
    IOOptionalFloat2OptionalFloat(in.meteoInfo.crosswind, crosswind);
    boost::optional<float> tailwind;
    IOOptionalFloat2OptionalFloat(in.meteoInfo.tailwind, tailwind);
    boost::optional<int> windSpeed;
    IOOptionalInt2OptionalInt(in.meteoInfo.windSpeed, windSpeed);
    boost::optional<int> windDirection;
    IOOptionalInt2OptionalInt(in.meteoInfo.windDirection, windDirection);

    MeteoInfo meteoInfo(horizontalVisibility,
                             wetness,
                             ilsCategory,
                             lvpActivation,
                             deicingRequired,
                             crosswind,
                             tailwind,
                             windSpeed,
                             windDirection);

    out.setMeteoInfo(meteoInfo);
}

