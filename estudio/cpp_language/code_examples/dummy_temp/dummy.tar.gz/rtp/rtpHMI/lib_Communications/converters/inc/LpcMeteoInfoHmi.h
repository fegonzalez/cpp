// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 11 Jun 10:23:50 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCMETEOINFOHMI_H_
#define LPCMETEOINFOHMI_H_

#include <IOMeteoInfo.h>
#include <IOUpdateMeteoInfo.h>
#include <LpiMeteoInfoHmi.h>
#include <IOTim.h>
#include <string>
#include <LpdComponent.h>

class LpcMeteoInfoHmi
{
   public:

    static void convert2Meteo(const IOUpdateMeteoInfo::Meteo &in, LpiMeteoInfoHmi &out);
    private:

};

#endif /* LPCMETEOINFOHMI_H_ */
