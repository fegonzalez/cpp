#include "LpcMeteoNowEvtConsumer.h"
#include "LpiMeteoNowEvt.h"
#include <IOUpdateMeteoInfo.h>
#include <IOMeteoInfoEvents.h>
#include <LpiMeteoInfo.h>
#include <LpcMeteoInfo.h>
#include <LpdHmiComponent.h>
#include <LclogStream.h>
//#include <Lpc2Ostream.h> // IOTim::TimeS & OptionalTimeU  operator<<()

#ifdef TRACE_OUT
#include <iostream>
#endif


//------------------------------------------------------------------------------

void LpcMeteoNowEvtConsumer::init(void)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP_HMI).debug() 
    << "[RTP-HMI-CONSUMER: METEO-NOWCAST EVENT CONSUMER] (init)"
    << " : file: " << __FILE__
    << " ; fn: " << __func__
    << " ; line:  " << __LINE__
    << std::endl << std::endl << std::endl;
#endif

   iB::SubscriberId sid("IOMeteoInfoEvents::UpdateMeteoNowcastEventList");
   iB::SubscriptionProfile sprofile;

   iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListSubscriber &subscriber =
     iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListCreateSubscriber
     (sid, sprofile);
   subscriber.addListener(this);
}

//------------------------------------------------------------------------------

/*
 * received data: IOMeteoInfoEvents::MeteoUpdateList
 *
 * saved data:    LpiUpdateMeteoList 
 *                (typedef std::vector<LpiUpdateMeteo> LpiUpdateMeteoList;)
 */
void LpcMeteoNowEvtConsumer::on_data_available
(iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListSubscriber &sub)
{
  LclogStream::instance(LclogConfig::E_RTP_HMI).notify() 
    << "[RTP-HMI-CONSUMER: METEO-NOWCAST EVENT CONSUMER] (on_data_available)"
    << " file: " << __FILE__
    << " ; fn: " << __func__
    << " ; line:  " << __LINE__
    << " )"
    << std::endl;

   iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListSubscriber::DataList dl;
   iB::DIList il;
   sub.getData(dl, il);

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP_HMI).debug() 
     << "DataList size:" << dl.size()
     << ", DIList size:" << il.size() << "  ("
     << " file: " << __FILE__
     << " ; fn: " << __func__
     << " ; line:  " << __LINE__
     << " )"
     << std::endl;
#endif


   iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListSubscriber::
     DataList::iterator dit = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {
      if(iit->isValid())
      {
	IOMeteoInfoEvents::MeteoUpdateList ioMeteoList = dit->meteoUpdates;
	LpiUpdateMeteoList report_list; // list of meteo reports
	                                 // (one per airport)

	for (int x = 0; x < ioMeteoList.length(); ++x) 
	{
	  report_list.push_back(handle_one_meteo_data(ioMeteoList.get_at(x)));
	}

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
	  //std::cerr
	  << "\nDEBUG: file: " << __FILE__
	  << " ; fn: " << __func__
	  << " ; line:  " << __LINE__
	  << "  [RTP-HMI-CONSUMER]: report_list: "
	  << "; size = " << report_list.size()
	  << "; list: ["<< report_list << "]"
	  << std::endl;
#endif

	LpiMeteoNowEvt event;
	event.setMeteoNow(report_list);
	LpdHmiComponent::Get().consume(event);

      }
      
   }//end-for


}

//------------------------------------------------------------------------------

LpiUpdateMeteo  LpcMeteoNowEvtConsumer::handle_one_meteo_data
(const IOUpdateMeteoInfo::Meteo &next_meteo_data)
{

  LpiUpdateMeteo new_meteo;
  LpcMeteoInfo::convert2Meteo(next_meteo_data, new_meteo);

  return new_meteo;
}

//------------------------------------------------------------------------------
