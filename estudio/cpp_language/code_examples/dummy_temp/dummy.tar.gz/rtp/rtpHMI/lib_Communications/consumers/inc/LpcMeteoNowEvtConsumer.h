// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 07 Jun 16:14:17 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCMETEONOWEVTCONSUMER_H
#define LPCMETEONOWEVTCONSUMER_H

#include <IOMeteoInfoEventsiBContract.h>
#include <LpiMeteoInfo.h>
#include <IOUpdateMeteoInfo.h>


class LpcMeteoNowEvtConsumer : public iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListSubscriberListener
{
public:
    void init(void);

    void on_data_available(iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListSubscriber &sub);

private:
    LpiUpdateMeteo handle_one_meteo_data(const IOUpdateMeteoInfo::Meteo &next_meteo_data);

};

#endif // LPCMETEONOWEVTCONSUMER_H
