#ifndef LRCHMIACTIVATESCHEDULE_H
#define LRCHMIACTIVATESCHEDULE_H

#include <IOScheduleRTPEvents.h>
#include <LpiHmiActivateSchedule.h>

class LpcHmiActivateSchedule
{
public:

    static void convert2ScheduleActivation(const LpiHmiActivateSchedule &in, IOScheduleRTPEvents::ActivateScheduleFromHmi &out);
};

#endif // LRCHMIACTIVATESCHEDULE_H
