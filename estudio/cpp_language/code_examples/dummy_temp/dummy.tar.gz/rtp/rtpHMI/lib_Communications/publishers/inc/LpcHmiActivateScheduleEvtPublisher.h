/*
 * LpcHmiActivateScheduleEvtPublisher.h
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#ifndef LPCHMIACTIVATESCHEDULEEVTPUBLISHER_H_
#define LPCHMIACTIVATESCHEDULEEVTPUBLISHER_H_

#include <LpiHmiIEventPublishers.h>
#include <IOScheduleRTPEventsiBContract.h>
#include <IOScheduleRTPEvents.h>
#include <IOTim.h>

class LpcHmiActivateScheduleEvtPublisher : public LpiHmiIActivateScheduleEvtPublisher
{
public:

   void init(void);

   virtual void publish(const LpiHmiActivateScheduleEvt &data);

private:

   iBG::IOScheduleRTPEvents::ActivateScheduleFromHmiPublisher *_publisher;

};

#endif /* C___SRC_RTP_RTPHMI_LIB_COMMUNICATIONS_PUBLISHERS_INC_LPCHMIACTIVATESCHEDULEEVTPUBLISHER_H_ */
