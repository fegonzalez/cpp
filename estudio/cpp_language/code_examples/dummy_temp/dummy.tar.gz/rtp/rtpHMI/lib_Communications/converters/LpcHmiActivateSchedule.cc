#include "LpcHmiActivateSchedule.h"
#include "LpcActivationType.h"

void LpcHmiActivateSchedule::convert2ScheduleActivation(
        const LpiHmiActivateSchedule &in, IOScheduleRTPEvents::ActivateScheduleFromHmi &out)
{
    out.sch_id = in.getSchID();
    out.activationType = LpcActivationType::LpiToIOType(in.getActivationType());
}
