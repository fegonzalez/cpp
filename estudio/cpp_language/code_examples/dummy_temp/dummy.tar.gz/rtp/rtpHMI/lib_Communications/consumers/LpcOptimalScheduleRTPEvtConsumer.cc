/*
 * LpcDefaultScheduleEvtConsumer.cc
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */
#include <IOScheduleRTPEvents.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <LclogStream.h>
#include <LpdHmiComponent.h>
#include <LpcHmiScheduleRTP.h>
#include <LpiScheduleRTP.h>
#include "LpcOptimalScheduleRTPEvtConsumer.h"
#include "LpiHmiOptimalScheduleRTPEvt.h"


void LpcOptimalScheduleRTPEvtConsumer::init(void)
{
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

	iB::SubscriberId sid("IOScheduleRTPEvents::OptimalScheduleActivation");
	iB::SubscriptionProfile sprofile;


#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__                   // último log escrito en RTP
       << std::endl;
#endif

	   try
	   {
	   iBG::IOScheduleRTPEvents::OptimalScheduleActivationSubscriber &subscriber =
			   iBG::IOScheduleRTPEvents::OptimalScheduleActivationCreateSubscriber(sid,   ///@error En madrid de aquí no pasa
					   sprofile);

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

	subscriber.addListener(this);

	   }
	   catch(std::runtime_error &err)
	   {
		   LclogStream::instance(LclogConfig::E_RTP_HMI).error()
		    		   << err.what()
					   << " : File: " << __FILE__
					   << " ; fn: " << __func__
					   << " ; line: " << __LINE__
					   << std::endl;

		   std::cerr << "\nERROR: "
				   << "std::runtime_error exception imasblue dentro de: OptimalScheduleActivation"
	    		   << err.what()
				   << " : File: " << __FILE__
				   << " ; fn: " << __func__
				   << " ; line: " << __LINE__
				   << std::endl;
		   exit(22);
	   }

	   catch(...)
	   {
		   LclogStream::instance(LclogConfig::E_RTP_HMI).error()
		    		   << " : File: " << __FILE__
					   << " ; fn: " << __func__
					   << " ; line: " << __LINE__
					   << std::endl;

		   std::cerr << "\nERROR: "
				   << "exception imasblue dentro de: OptimalScheduleActivation"
				   << " : File: " << __FILE__
				   << " ; fn: " << __func__
				   << " ; line: " << __LINE__
				   << std::endl;
		   exit(33);
	   }

}

void LpcOptimalScheduleRTPEvtConsumer::on_data_available(iBG::IOScheduleRTPEvents::OptimalScheduleActivationSubscriber &sub)
{
	  LclogStream::instance(LclogConfig::E_RTP_HMI).notify()
	    << "[OPTIMAL SCHEDULE EVENT CONSUMER] BEGIN"
	    << "\t file: " << __FILE__
	    << " ; FN: " << __func__
	    << " ; LINE:  " << __LINE__
	    << std::endl;

	#ifdef TRACE_OUT
	  LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
	    << " : file: " << __FILE__
	    << " ; fn: " << __func__
	    << " ; line:  " << __LINE__
	    << std::endl << std::endl << std::endl;
	#endif

	  iBG::IOScheduleRTPEvents::OptimalScheduleActivationSubscriber::DataList dl;
	  iB::DIList il;
	  sub.getData(dl, il);

	  iBG::IOScheduleRTPEvents::OptimalScheduleActivationSubscriber::DataList::iterator dit
	                                                                    = dl.begin();
	  iB::DIList::iterator iit = il.begin();
	  int pos = 0;

	  for(;
	         (dit != dl.end()) && (iit != il.end());
	         ++dit, ++iit, pos++)
	  {
		  if(iit->isValid())
		  {
			  IOScheduleRTP::Schedule ioSchedule;
			  ioSchedule = dit->schedule;

			  LpiScheduleRTP _schedule;

			  LpcHmiScheduleRTP::convert2Schedule(ioSchedule, _schedule);

			  LpiHmiOptimalScheduleRTPEvt event;
			  event.setSchedule(_schedule);
			  LpdHmiComponent::Get().consume(event);
		  }

	  }

	  LclogStream::instance(LclogConfig::E_RTP_HMI).info()
			  << "[OPTIMAL SCHEDULE EVENT CONSUMER] END"
			  << "\t file: " << __FILE__
			  << " ; FN: " << __func__
			  << " ; LINE:  " << __LINE__
			  << std::endl;
}
