
#ifndef LPCMETEOFOREEVTCONSUMER_H
#define LPCMETEOFOREEVTCONSUMER_H

#include <IOMeteoInfoEventsiBContract.h>
#include <LpiMeteoInfo.h>
#include <IOUpdateMeteoInfo.h>


class LpcMeteoForeEvtConsumer : public iBG::IOMeteoInfoEvents::UpdateMeteoForecastEventListSubscriberListener
{
public:
    void init(void);

    void on_data_available(iBG::IOMeteoInfoEvents::UpdateMeteoForecastEventListSubscriber &sub);

private:
    LpiUpdateMeteo handle_one_meteo_data(const IOUpdateMeteoInfo::Meteo &next_meteo_data);
};

#endif // LPCMETEOFOREEVTCONSUMER_H
