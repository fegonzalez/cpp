/*
 * LpcHmiCommunicationsManager.h
 *
 */

#ifndef LPCHMICOMMUNICATIONSMANAGER_H_
#define LPCHMICOMMUNICATIONSMANAGER_H_


#include <LpcDemandEvtConsumer.h>
#include <LpcMeteoNowEvtConsumer.h>
#include <LpcMeteoForeEvtConsumer.h>
#include <LpcDefaultScheduleEvtConsumer.h>

#include <boost/thread.hpp>

class LpcHmiCommunicationsManager
{
public:

   static LpcHmiCommunicationsManager& Get(void);
   void initialise(void);
   void waitForEvents (void);

private:

   LpcHmiCommunicationsManager ();

   boost::shared_ptr<LpcDemandEvtConsumer> _demandEvtConsumer;
   boost::shared_ptr<LpcMeteoNowEvtConsumer> _meteoNowEvtConsumer;
   boost::shared_ptr<LpcMeteoForeEvtConsumer> _meteoForeEvtConsumer;
   boost::shared_ptr<LpcDefaultScheduleEvtConsumer> _defScheduleEvtConsumer;
};

#endif /* LPCHMICOMMUNICATIONSMANAGER_H_ */
