/*
 * LpcHmiCommunicationsManager.h
 *
 */

#ifndef LPCHMICOMMUNICATIONSMANAGER_H_
#define LPCHMICOMMUNICATIONSMANAGER_H_


#include <LpcDemandEvtConsumer.h>
#include <LpcMeteoNowEvtConsumer.h>
#include <LpcMeteoForeEvtConsumer.h>
#include <boost/thread.hpp>
#include "LpcActiveScheduleRTPEvtConsumer.h"
#include "LpcOptimalScheduleRTPEvtConsumer.h"

#include "LpcHmiActivateScheduleEvtPublisher.h"

class LpcHmiCommunicationsManager
{
public:

   static LpcHmiCommunicationsManager& Get(void);
   void initialise(void);
   void waitForEvents (void);

private:

   LpcHmiCommunicationsManager ();

   boost::shared_ptr<LpcDemandEvtConsumer> _demandEvtConsumer;
   boost::shared_ptr<LpcMeteoNowEvtConsumer> _meteoNowEvtConsumer;
   boost::shared_ptr<LpcMeteoForeEvtConsumer> _meteoForeEvtConsumer;
   boost::shared_ptr<LpcActiveScheduleRTPEvtConsumer> _activeScheduleRTPEvtConsumer;
   boost::shared_ptr<LpcOptimalScheduleRTPEvtConsumer> _optimalScheduleRTPEvtConsumer;

   boost::shared_ptr<LpcHmiActivateScheduleEvtPublisher> _activateScheduleEvtPublisher;
};

#endif /* LPCHMICOMMUNICATIONSMANAGER_H_ */
