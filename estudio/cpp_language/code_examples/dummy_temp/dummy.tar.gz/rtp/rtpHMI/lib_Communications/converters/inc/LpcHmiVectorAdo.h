/*
 * LpcHmiVectorAdo.h
 *
 *  Created on: Sep 12, 2018
 *      Author: srperez
 */

#ifndef LPCHMIVECTORADO_H_
#define LPCHMIVECTORADO_H_

#include <LclogStream.h>
#include "LcuStringArrayConvUtils.h"
#include "LpiHmiVectorAdo.h"
#include <IOConstant.h>
#include <IOKPIs.h>

class LpcHmiVectorAdo
{
    public:

        static LpiHmiVectorAdo IOADO2LpiHmiVectorAdo(const IOConst::VectorADO & iOvector)
        {
            LpiHmiVectorAdo lpivector(float(iOvector.arrivals),
                    float(iOvector.departures), float(iOvector.overall));

            return lpivector;
        }

};



#endif /* C___SRC_RTP_RTPHMI_LIB_COMMUNICATIONS_CONVERTERS_INC_LPCHMIVECTORADO_H_ */
