// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 11 Jun 10:22:34 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpcMeteoInfoHmi.h"
#include <LcuStringArrayConvUtils.h>
#include <LctimTimeUtils.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <LpdComponent.h>
#include <math.h>

#include <LpiMeteoTimeline.h>
#include "LpcMeteoTimeLineHmi.h"
#include "LpcCalculationReason.h"
#include "LpcMeteoTimeline.h"
#include "LpcUtils.h"
#include "LctimTimeUtils.h"
#include "LpcCalculationReasonInHmi.h"

void LpcMeteoInfoHmi::convert2Meteo(const IOUpdateMeteoInfo::Meteo &in,
                                    LpiMeteoInfoHmi &out)
{
    LpcCalculationReasonInHmi::convertIO2LpiCalculationReason(
            in.calculationReason, out.getCalculationReason());
    if (out.getCalculationReason() != LpiCalculationReason::E_CLOCK)
    {
        //-------------------------------------------------------------------------------
        //MESSAGE IDENTIFICATION
        std::string aerodrome;
        LpcUtils::Array2String(in.messageIdentification.airport, aerodrome);
        out.getMessageIdentification().setAerodrome(aerodrome);
        posix_time::ptime timeAndDate;
        timeAndDate = LctimTimeUtils::getFromString(
                in.messageIdentification.timeAndDate);
        out.getMessageIdentification().setTimeAndDate(timeAndDate);
        //---------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------
        //BODY INFORMATION
        //-----------period information-----------------------------------------------------
        for (int j = 0; j < in.bodyInformation.length(); j++)
        {
            BodyInformation bodyInf;
            posix_time::ptime startTimeAndDate;
            startTimeAndDate =
                    LctimTimeUtils::getFromString(
                            in.bodyInformation.get_at(j).periodInformation.startTimeAndDate);
            bodyInf.getPeriodInformation().setStartTimeAndDate(
                    startTimeAndDate);
            posix_time::ptime endTimeAndDate;
            endTimeAndDate =
                    LctimTimeUtils::getFromString(
                            in.bodyInformation.get_at(j).periodInformation.endTimeAndDate);
            bodyInf.getPeriodInformation().setEndTimeAndDate(endTimeAndDate);
            bodyInf.getPeriodInformation().setProbability(
                    in.bodyInformation.get_at(j).periodInformation.probability);
            //-----------meteorological information---------------------------------------------
            bodyInf.getMeteorologicalInformation().setWindDirection(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.windDirection);
            bodyInf.getMeteorologicalInformation().setWindSpeed(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.windSpeed);
            bodyInf.getMeteorologicalInformation().setGustDirection(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.gustDirection);
            bodyInf.getMeteorologicalInformation().setGustSpeed(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.gustSpeed);
            bodyInf.getMeteorologicalInformation().setAirTemperature(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.airTemperature);
            bodyInf.getMeteorologicalInformation().setDewPointTemperature(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.dewPointTemperature);
            bodyInf.getMeteorologicalInformation().setHorizontalVisibility(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.horizontalVisibility);
            bodyInf.getMeteorologicalInformation().setQNH(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.qnh);
            bodyInf.getMeteorologicalInformation().setCloudBase(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.cloudBase);
            std::string significantWeather;
            LpcUtils::Array2String(
                    in.bodyInformation.get_at(j).meteorologicalInformation.meterological.significantWeather,
                    significantWeather);
            bodyInf.getMeteorologicalInformation().setSignificantWeather(
                    significantWeather);
            std::string wetness;
            LpcUtils::Array2String(
                    in.bodyInformation.get_at(j).meteorologicalInformation.wetness,
                    wetness);
            bodyInf.getMeteorologicalInformation().setWetness(wetness);
            bodyInf.getMeteorologicalInformation().setLvp_Activation(
                    in.bodyInformation.get_at(j).meteorologicalInformation.lvp_Activation);
            std::string required_ILS_Category;
            LpcUtils::Array2String(
                    in.bodyInformation.get_at(j).meteorologicalInformation.required_ILS_Category,
                    required_ILS_Category);
            bodyInf.getMeteorologicalInformation().setRequired_ILS_Category(
                    boost::algorithm::trim_right_copy(required_ILS_Category));
            bodyInf.getMeteorologicalInformation().setDe_icing_required(
                    in.bodyInformation.get_at(j).meteorologicalInformation.de_icing_required);
            RVRperRunway rvrrunways;

            for (int i = 0;
                    i
                            < in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.length();
                    i++)
            {
                std::string name;
                LpcUtils::Array2String(
                        in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(
                                i).RVRperRunway.name, name);
                rvrrunways.setName(name);
                rvrrunways.setCrosswind(
                        in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(
                                i).crosswind);
                rvrrunways.setRvr(
                        in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(
                                i).RVRperRunway.rvr);
                rvrrunways.setTailwind(
                        in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(
                                i).tailwind);
                bodyInf.getMeteorologicalInformation().getRvrperRunway().setRVRPerRunway(
                        rvrrunways);
            }
            out.getBodyInformationList().setBodyInformation(bodyInf);
        }
    }
    //METEO TIMELINE
    for (int i = 0; i < in.timeline.length(); ++i)
    {
        LpiMeteoTimeLineHmi meteoTimeLine;
        LpcMeteoTimeLineHmi::convertIO2LpiMeteoTimeLine(in.timeline.get_at(i),
                meteoTimeLine);
        out.setTimeLineItem(meteoTimeLine);
    }

    //-----------------------------------------------------------------------------------------------------------

}
