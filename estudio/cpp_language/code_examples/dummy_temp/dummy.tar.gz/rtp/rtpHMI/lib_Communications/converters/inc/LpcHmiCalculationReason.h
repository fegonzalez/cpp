/*
 * LpcHmiCalculationReason.h
 *
 *  Created on: Sep 12, 2018
 *      Author: srperez
 */

#ifndef LPCHMICALCULATIONREASON_H_
#define LPCHMICALCULATIONREASON_H_

#include <IOCommonTypes.h>
#include <LpiCalculationReason.h>

class LpcHmiCalculationReason
{
    public:
       static void convertIO2LpiCalculationReason(const IOCommonTypes::CalculationReason &in,
                                                  LpiCalculationReason::LpiEnum & out);
};

#endif /* C___SRC_RTP_RTPHMI_LIB_COMMUNICATIONS_CONVERTERS_INC_LPCHMICALCULATIONREASON_H_ */
