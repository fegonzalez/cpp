#ifndef LPCCALCULATIONREASONINHMI_H_
#define LPCCALCULATIONREASONINHMI_H_

#include <IOCommonTypes.h>
#include <LpiCalculationReason.h>

class LpcCalculationReasonInHmi
{
    public:
       static void convertIO2LpiCalculationReason(const IOCommonTypes::CalculationReason &in,
                                                  LpiCalculationReason::LpiEnum & out);
};

#endif /* LPCCALCULATIONREASONINHMI_H_ */
