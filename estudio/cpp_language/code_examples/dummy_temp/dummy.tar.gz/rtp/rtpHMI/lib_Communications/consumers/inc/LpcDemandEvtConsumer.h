#ifndef LPCDEMANDEVTCONSUMER_H
#define LPCDEMANDEVTCONSUMER_H

#include <IODemandEventsiBContract.h>



class LpcDemandEvtConsumer : public iBG::IODemandEvents::UpdateDemandEventListSubscriberListener
{
public:
    void init(void);

    void on_data_available(iBG::IODemandEvents::UpdateDemandEventListSubscriber &sub);
};

#endif // LPCDEMANDEVTCONSUMER_H
