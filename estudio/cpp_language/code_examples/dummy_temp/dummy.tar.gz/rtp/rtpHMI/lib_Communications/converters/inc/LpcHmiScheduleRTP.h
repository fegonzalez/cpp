/*
 * LpcHmiScheduleRTP.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPCHMISCHEDULERTP_H_
#define CLPCHMISCHEDULERTP_H_

#include <IOScheduleRTP.h>
#include <LpiScheduleRTP.h>
#include <string>
#include <vector>

class LpcHmiScheduleRTP
{
public:
	static void convert2Schedule(const IOScheduleRTP::Schedule &in, LpiScheduleRTP &out);
};



#endif /* LPCHMISCHEDULERTP_H_ */
