/*
 * LpcHmiScheduleRTP.h
 *
 *  Created on: Nov 12, 2018
 *      Author: srperez
 */

#ifndef LPCHMISCHEDULERTP_H_
#define CLPCHMISCHEDULERTP_H_

#include <IOScheduleRTP.h>
#include <string>
#include <vector>

class LpcHmiScheduleRTP
{
public:
	static void convert2DefaultSchedule(const IOScheduleRTP::Schedule &in, std::vector<std::vector<std::string>> &out);
};



#endif /* LPCHMISCHEDULERTP_H_ */
