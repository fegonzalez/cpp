#include "LpcCalculationReasonInHmi.h"

void LpcCalculationReasonInHmi::convertIO2LpiCalculationReason(const IOCommonTypes::CalculationReason &in,
                                                          LpiCalculationReason::LpiEnum& out)
{
    switch (in)
    {
    case IOCommonTypes::E_INIT:
        out = LpiCalculationReason::LpiEnum::E_INIT;
        break;
    case IOCommonTypes::E_NEW_METEO_NOWCAST:
        out = LpiCalculationReason::LpiEnum::E_NEW_METEO_NOWCAST;
        break;
    case IOCommonTypes::E_NEW_METEO_FORECAST:
        out = LpiCalculationReason::LpiEnum::E_NEW_METEO_FORECAST;
        break;
    case IOCommonTypes::E_NEW_DEMAND:
        out = LpiCalculationReason::LpiEnum::E_NEW_DEMAND;
        break;
    case IOCommonTypes::E_CLOCK:
        out = LpiCalculationReason::LpiEnum::E_CLOCK;
        break;
    case IOCommonTypes::E_MANUAL_ACTIVATION:
        out = LpiCalculationReason::LpiEnum::E_MANUAL_ACTIVATION;
        break;
    case IOCommonTypes::E_AIRPORT_OPERATIONAL_STATUS_CHANGE:
        out = LpiCalculationReason::LpiEnum::E_AIRPORT_OPERATIONAL_STATUS_CHANGE;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_CRITERIA:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_CRITERIA;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_CRITERIA_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_CRITERIA_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_MANUAL_EDITION:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_MANUAL_EDITION;
        break;
    case IOCommonTypes::E_WHAT_IF_MANUAL_EDITION_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_MANUAL_EDITION_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_DELETION:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_DELETION;
        break;
    case IOCommonTypes::E_WHAT_IF_APPLY_ON_ACTIVE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_APPLY_ON_ACTIVE;
        break;
    case IOCommonTypes::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_OPTIMAL:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_OPTIMAL;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_OPTIMAL_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_OPTIMAL_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT_FOR_ACTIVE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT_FOR_ACTIVE_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE_UPDATE;
        break;
    default:
        break;
    }
}
