/*
 * LpcHmiActivateScheduleEvtPublisher.cc
 *
 *  Created on: Nov 16, 2018
 *      Author: srperez
 */

#include "LpcHmiActivateScheduleEvtPublisher.h"
#include <LcuStringArrayConvUtils.h>
#include <LpcHmiActivateSchedule.h>
#include <LpdHmiComponent.h>
#include <LclogStream.h>
#include <iostream>

void LpcHmiActivateScheduleEvtPublisher::init(void)
{

    iB::PublisherId pid("IOScheduleRTPEvents::ActivateScheduleFromHmi");

    iB::PublicationProfile pprofile;

    _publisher = &iBG::IOScheduleRTPEvents::ActivateScheduleFromHmiCreatePublisher(
                                                                                    pid,
                                                                                    pprofile);
    LpdHmiComponent::Get().delegatePublisher(*this);
}

void LpcHmiActivateScheduleEvtPublisher::publish(const LpiHmiActivateScheduleEvt &data)
{
    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "[SCHEDULE ACTIVATION EVENT PUBLISHER] BEGIN\n";

    IOScheduleRTPEvents::ActivateScheduleFromHmi ddsSeqEvt;
    memset(&ddsSeqEvt, 0, sizeof(IOScheduleRTPEvents::ActivateScheduleFromHmi));
    IOScheduleRTPEvents::ActivateScheduleFromHmiTypeSupport::initialize_data(&ddsSeqEvt);

    IOScheduleRTPEvents::ActivateScheduleFromHmi out;
    memset(&out, 0, sizeof( IOScheduleRTPEvents::ActivateScheduleFromHmi));
    LpcHmiActivateSchedule::convert2ScheduleActivation(data.getActivateSchedule(),out);
    ddsSeqEvt = out;

    _publisher->push(ddsSeqEvt);
    IOScheduleRTPEvents::ActivateScheduleFromHmiTypeSupport::finalize_data(&ddsSeqEvt);

    LclogStream::instance(LclogConfig::E_RTP_HMI).info() << "[SCHEDULE ACTIVATION EVENT PUBLISHER] END\n";
}



