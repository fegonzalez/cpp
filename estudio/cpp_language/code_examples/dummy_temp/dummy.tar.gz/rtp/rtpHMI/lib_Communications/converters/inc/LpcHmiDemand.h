/*
 * LpcHmiDemand.h
 *
 *  Created on: 28/05/2018
 *      Author: ctudela
 */

#ifndef LPCHMIDEMAND_H_
#define LPCHMIDEMAND_H_

#include <LpiFlightPlan.h>
#include <LpiHmiDemand.h>
#include <IOUpdateDemandRTP.h>
#include <IODemand.h>
#include <string>

class LpcHmiDemand
{
public:
   static void convert2Demand(const IOUpdateDemandRTP::Demand &in, LpiHmiDemand &out);
};


#endif /* LPCDEMANDHMI_H_ */
