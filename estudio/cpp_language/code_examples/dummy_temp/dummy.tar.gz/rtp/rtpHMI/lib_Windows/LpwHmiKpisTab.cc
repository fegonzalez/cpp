#include "LpwHmiKpisTab.h"
#include "ui_rtpkpistab.h"
#include <iostream>

LpwHmiKpisTab::LpwHmiKpisTab(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiKpisTab)
{
    ui->setupUi(this);

    ui->cbSchedule->addItem("ACTIVE");
    ui->cbSchedule->addItem("OPTIMAL");

    ui->rbMrtmSch->setChecked(true);
    ui->cbAirportSch->setEnabled(false);
    ui->rbTotalSch->setChecked(true);
    ui->cbIntervalSch->setEnabled(false);

    connect(ui->rbAirportSch, SIGNAL(clicked()), this, SLOT(hideSimOps()));
    connect(ui->rbMrtmSch, SIGNAL(clicked()), this, SLOT(showSimOps()));
    connect(ui->rbTotalSch, SIGNAL(clicked()), this, SLOT(hideInterval()));
    connect(ui->rbIntervalSch, SIGNAL(clicked()), this, SLOT(showInterval()));

    chartComplex = new LcgobChartsWidget("COMPLEXITY", 8, 40, false);
    ui->glComplexGraphic->addWidget(chartComplex);
    modelComplex = new LpmodHmiGraphicComplexityModel();
    chartComplex->setModel(modelComplex);

    QItemSelectionModel *selectionComplexity = new QItemSelectionModel(modelComplex);
    chartComplex->setSelectionModel(selectionComplexity);
    chartComplex->paintChartBar();


    chartSimMov = new LcgobChartsWidget("SIM. OPS", 8, 40, false);
    ui->glSimGraphic->addWidget(chartSimMov);
    modelSimMov = new LpmodHmiGraphicSimOpsModel();
    chartSimMov->setModel(modelSimMov);

    QItemSelectionModel *selectionSimOps = new QItemSelectionModel(modelSimMov);
    chartSimMov->setSelectionModel(selectionSimOps);
    chartSimMov->paintChartBar();


    chartTotalMov = new LcgobChartsWidget("TOTAL MOV", 8, 40, false);
    ui->glTotalGraphic->addWidget(chartTotalMov);
    modelTotalMov = new LpmodHmiGraphicTotalMovModel();
    chartTotalMov->setModel(modelTotalMov);

    QItemSelectionModel *selectionTotalMov = new QItemSelectionModel(modelTotalMov);
    chartTotalMov->setSelectionModel(selectionTotalMov);
    chartTotalMov->paintChartBar();


    chartVFR = new LcgobChartsWidget("VFR", 8, 40, false);
    ui->glVFRGraphic->addWidget(chartVFR);
    modelVFR = new LpmodHmiGraphicVFRModel();
    chartVFR->setModel(modelVFR);

    QItemSelectionModel *selectionVFR = new QItemSelectionModel(modelVFR);
    chartVFR->setSelectionModel(selectionVFR);
    chartVFR->paintChartBar();
}

void LpwHmiKpisTab::showSimOps()
{
   ui->frameSimKpis->show();
   ui->cbAirportSch->setEnabled(false);
}

void LpwHmiKpisTab::hideSimOps()
{
   ui->frameSimKpis->hide();
   ui->cbAirportSch->setEnabled(true);
}

void LpwHmiKpisTab::showInterval()
{
    ui->cbIntervalSch->setEnabled(true);
}

void LpwHmiKpisTab::hideInterval()
{
    ui->cbIntervalSch->setEnabled(false);
}

LpwHmiKpisTab::~LpwHmiKpisTab()
{
    delete ui;
}


