// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 03 Sep 13:57:58 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPWHMICONFIGMETEO_H_
#define LPWHMICONFIGMETEO_H_

#include <QWidget>
#include <QTableWidget>
#include "LpiAdaptationAirportsInfo.h"

namespace Ui {
class LpwHmiConfigMeteo;
}

class LpwHmiConfigMeteo : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiConfigMeteo(QWidget *parent = 0);
    ~LpwHmiConfigMeteo();

public slots:
    void fillMeteoThresholds(QString);
    void updateCbAirport(QString);

private slots:
    void fillLvpActConditions(QString);
    void configTableILS(QString);
    void configTableWindThresholds(QString);
    void configTableVisibilityThresholds(QString);
    void initDataAirport();
    void configAlignFontTables(QTableWidget *table);

private:
    Ui::LpwHmiConfigMeteo *ui;
    QHash<QString, Airport> mapAirports;
    LpiAdaptationAirportsInfo parameters;
    QFont font;
    QFont bold;
};


#endif /* C___SRC_RTP_RTPHMI_LIB_WINDOWS_INC_LPWHMICONFIGMETEO_H_ */
