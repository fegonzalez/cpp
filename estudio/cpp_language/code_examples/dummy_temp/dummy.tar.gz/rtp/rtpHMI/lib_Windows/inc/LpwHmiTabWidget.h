#ifndef LPWHMITABWIDGET_H
#define LPWHMITABWIDGET_H

#include <QTabWidget>
#include <QWidget>

namespace Ui {
class LpwHmiTabWidget;
}

class LpwHmiTabWidget : public QWidget
{
    Q_OBJECT

public:



    static LpwHmiTabWidget& Get(void)
    {
        static LpwHmiTabWidget component;
        return component;
    }

    explicit LpwHmiTabWidget(QWidget *parent = 0);
    ~LpwHmiTabWidget();

    QTabWidget* getTab();
    enum tabs{tabSummary, tabMeteo, tabFlightPlans, tabAirportInfo};


public slots:
    void changeTabToMeteo();
    void changeTabToFlightList();
    void changeTabToSummary();
    void removeLabelCalculatinDefSch();

private:
    Ui::LpwHmiTabWidget *ui;


};

#endif // LPWHMITABWIDGET_H
