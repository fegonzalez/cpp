// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 03 Sep 13:58:08 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpwHmiConfigMeteo.h"
#include "ui_rtpconfigurationmeteo.h"

#include "LpsigSignalsHmi.h"
#include "LpwHmiAirportInfo.h"
#include "LpdComponent.h"

LpwHmiConfigMeteo::LpwHmiConfigMeteo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiConfigMeteo)
{
    ui->setupUi(this);

    LpiResult result;
    LpdComponent::Get().getAdaptationAirportsInfo(parameters, result);

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoThresholds(QString)), this, SLOT(fillMeteoThresholds(QString)));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoThresholds(QString)), this, SLOT(fillLvpActConditions(QString)));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoThresholds(QString)), this, SLOT(configTableVisibilityThresholds(QString)));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoThresholds(QString)), this, SLOT(configTableILS(QString)));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoThresholds(QString)), this, SLOT(configTableWindThresholds(QString)));

    ui->cbAirportNameTab->setEnabled(false);
    ui->leAirportType->setEnabled(false);
    ui->leMaxILSC->setEnabled(false);

    font.setPointSize(10);
    bold.setBold(true);
    initDataAirport();

    connect(ui->cbAirportNameTab, SIGNAL(currentTextChanged(QString)), this, SLOT(updateCbAirport(QString)));

}

void LpwHmiConfigMeteo::updateCbAirport(QString airport)
{
	fillMeteoThresholds(airport);
	fillLvpActConditions(airport);
	configTableILS(airport);
	configTableVisibilityThresholds(airport);
	configTableWindThresholds(airport);
}

void LpwHmiConfigMeteo::initDataAirport()
{
    for(unsigned int i = 0 ; i < parameters.getAirport().size(); i++)
    {
        mapAirports.insert(QString::fromStdString(parameters.getAirport().at(i).getAirportName()),
                                                  parameters.getAirport().at(i));
    }
    ui->cbAirportNameTab->addItem(QString::fromStdString(parameters.getAirport().at(0).getAirportName()));
    fillMeteoThresholds(QString::fromStdString(parameters.getAirport().at(0).getAirportName()));
    fillLvpActConditions(QString::fromStdString(parameters.getAirport().at(0).getAirportName()));
    configTableILS(QString::fromStdString(parameters.getAirport().at(0).getAirportName()));
    configTableVisibilityThresholds(QString::fromStdString(parameters.getAirport().at(0).getAirportName()));
    configTableWindThresholds(QString::fromStdString(parameters.getAirport().at(0).getAirportName()));
}

void LpwHmiConfigMeteo::fillLvpActConditions(QString airport)
{

	ui->twLVPActCond->setRowCount(4);
	ui->twLVPActCond->setColumnCount(2);
	ui->twLVPActCond->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->twLVPActCond->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->twLVPActCond->horizontalHeader()->hide();
	ui->twLVPActCond->verticalHeader()->hide();

	ui->twLVPActCond->setSpan(0, 1, 1, ui->twLVPActCond->columnCount());

	ui->twLVPActCond->setItem(0, 0, new QTableWidgetItem(""));
	ui->twLVPActCond->setItem(0, 1, new QTableWidgetItem("ACTIVATION THRESHOLDS"));
	ui->twLVPActCond->setItem(1, 0, new QTableWidgetItem("CLOUD BASE"));
	ui->twLVPActCond->setItem(2, 0, new QTableWidgetItem("HORIZONTAL VISIBILITY"));
	ui->twLVPActCond->setItem(3, 0, new QTableWidgetItem("RVR"));

    for (unsigned int i = 0; i < mapAirports[airport].getLvpActivationConditions().size(); i++)
    {
        if(QString::fromStdString(mapAirports[airport].getLvpActivationConditions().at(i).getConditionName()).contains("CloudBase"))
        	ui->twLVPActCond->setItem(1, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getLvpActivationConditions().at(i).getConditionValue())));
        else  if(QString::fromStdString(mapAirports[airport].getLvpActivationConditions().at(i).getConditionName()).contains("HorizontalVisibility"))
        	ui->twLVPActCond->setItem(2, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getLvpActivationConditions().at(i).getConditionValue())));
        else if(QString::fromStdString(mapAirports[airport].getLvpActivationConditions().at(i).getConditionName()).contains("RVR"))
        	ui->twLVPActCond->setItem(3, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getLvpActivationConditions().at(i).getConditionValue())));
    }

    configAlignFontTables(ui->twLVPActCond);

    for(int j = 0; j < ui->twLVPActCond->columnCount(); j++)
	{
		ui->twLVPActCond->item(0, j)->setBackgroundColor("#C0C0C0");
		ui->twLVPActCond->item(0, j)->setFont(bold);
	}


	for(int i = 0; i < ui->twLVPActCond->rowCount(); i++)
	{
		ui->twLVPActCond->item(i, 0)->setBackgroundColor("#C0C0C0");
		ui->twLVPActCond->item(i, 0)->setFont(bold);
	}
}


void LpwHmiConfigMeteo::fillMeteoThresholds(QString airport)
{
    ui->cbAirportNameTab->setItemText(0, airport);

    if(mapAirports[airport].getAirportType() == AirportType::EnumAirportType::AFIS)
        ui->leAirportType->setText("AFIS");
    else if(mapAirports[airport].getAirportType() == AirportType::EnumAirportType::ATS)
           ui->leAirportType->setText("ATS");

    if(mapAirports[airport].getAirportMaxILsCategory() == RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory::CAT_I)
            ui->leMaxILSC->setText("CAT_I");
    else if(mapAirports[airport].getAirportMaxILsCategory() == RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory::CAT_II)
                ui->leMaxILSC->setText("CAT_II");
    else if(mapAirports[airport].getAirportMaxILsCategory() == RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory::CAT_III_A)
                ui->leMaxILSC->setText("CAT_III_A");
    else if(mapAirports[airport].getAirportMaxILsCategory() == RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory::CAT_III_B)
                ui->leMaxILSC->setText("CAT_III_B");
    else if(mapAirports[airport].getAirportMaxILsCategory() == RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory::CAT_III_C)
                ui->leMaxILSC->setText("CAT_III_C");
}

void LpwHmiConfigMeteo::configTableVisibilityThresholds(QString airport)
{
    ui->twVisibThresholds->setRowCount(4);
    ui->twVisibThresholds->setColumnCount(3);

    ui->twVisibThresholds->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->twVisibThresholds->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->twVisibThresholds->setSpan(0, 1, 1, ui->twLVPActCond->columnCount());
    ui->twVisibThresholds->setSpan(0, 0, 2, 1);

    ui->twVisibThresholds->verticalHeader()->hide();
    ui->twVisibThresholds->horizontalHeader()->hide();

    ui->twVisibThresholds->setItem(0, 0, new QTableWidgetItem("RUNWAY"));
    ui->twVisibThresholds->setItem(0, 1, new QTableWidgetItem("HORIZONTAL VISIBILITY (m)"));
    ui->twVisibThresholds->setItem(0, 2, new QTableWidgetItem(""));

    ui->twVisibThresholds->setItem(1, 0, new QTableWidgetItem(""));
    ui->twVisibThresholds->setItem(1, 1, new QTableWidgetItem("LOWER THRESHOLD"));
    ui->twVisibThresholds->setItem(1, 2, new QTableWidgetItem("UPPER THRESHOLD"));

    ui->twVisibThresholds->setItem(2, 0, new QTableWidgetItem(QString::fromStdString(mapAirports[airport].getRunways().at(0).getRunwayName())));
    ui->twVisibThresholds->setItem(2, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(0).getHorizontalVisibilityLoweThreshold())));
    ui->twVisibThresholds->setItem(2, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(0).getHorizontalVisibilityUpperThreshold())));

    ui->twVisibThresholds->setItem(3, 0, new QTableWidgetItem(QString::fromStdString(mapAirports[airport].getRunways().at(1).getRunwayName())));
    ui->twVisibThresholds->setItem(3, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(1).getHorizontalVisibilityLoweThreshold())));
    ui->twVisibThresholds->setItem(3, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(1).getHorizontalVisibilityUpperThreshold())));

    configAlignFontTables(ui->twVisibThresholds);

    for(int i = 0; i < 2; i++)
	{
		for(int j = 0; j < ui->twVisibThresholds->columnCount(); j++)
		{
			if(ui->twVisibThresholds->item(i, j) != NULL)
			{
				ui->twVisibThresholds->item(i, j)->setBackgroundColor("#C0C0C0");
				ui->twVisibThresholds->item(i, j)->setFont(bold);
			}

		}
	}

	for(int i = 0; i < ui->twVisibThresholds->rowCount(); i++)
	{
		if(ui->twVisibThresholds->item(i, 0) != NULL)
		{
			ui->twVisibThresholds->item(i, 0)->setBackgroundColor("#C0C0C0");
			ui->twVisibThresholds->item(i, 0)->setFont(bold);
		}
	}
}

void LpwHmiConfigMeteo::configTableILS(QString airport)
{
    ui->tvReqIlsCat->setRowCount(6);
    ui->tvReqIlsCat->setColumnCount(4);

    ui->tvReqIlsCat->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tvReqIlsCat->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tvReqIlsCat->horizontalHeader()->setFixedHeight(30);
    ui->tvReqIlsCat->horizontalHeader()->hide();
    ui->tvReqIlsCat->verticalHeader()->hide();

    ui->tvReqIlsCat->setItem(0, 0, new QTableWidgetItem("ILS Category"));
    ui->tvReqIlsCat->setItem(0, 1, new QTableWidgetItem("Cloud Base"));
    ui->tvReqIlsCat->setItem(0, 2, new QTableWidgetItem("RVR"));
    ui->tvReqIlsCat->setItem(0, 3, new QTableWidgetItem("Horizontal Visibility"));

    ui->tvReqIlsCat->setItem(1, 0, new QTableWidgetItem("CAT_I"));
    ui->tvReqIlsCat->setItem(2, 0, new QTableWidgetItem("CAT_II"));
    ui->tvReqIlsCat->setItem(3, 0, new QTableWidgetItem("CAT_III_A"));
    ui->tvReqIlsCat->setItem(4, 0, new QTableWidgetItem("CAT_III_B"));
    ui->tvReqIlsCat->setItem(5, 0, new QTableWidgetItem("CAT_III_C"));

    ui->tvReqIlsCat->setItem(1, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(0).
                        getCloudBase().get().getLowerBound()) + "ft < CB < " + QString::number(mapAirports[airport]
                        .getCatILs().at(0).getCloudBase().get().getUpperBound()) + "ft"));
    ui->tvReqIlsCat->setItem(1, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(0).
                        getRvrType().getLowerBound()) + "m < RVR < " + QString::number(mapAirports[airport]
                        .getCatILs().at(0).getRvrType().getUpperBound()) + "m"));
    ui->tvReqIlsCat->setItem(1, 3, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(0).
                        getHorizontalVisibility().get().getLowerBound()) + "m < HV < " + QString::number(mapAirports[airport]
                        .getCatILs().at(0).getHorizontalVisibility().get().getUpperBound()) + "m"));

    ui->tvReqIlsCat->setItem(2, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(1).
                        getCloudBase().get().getLowerBound()) + "ft < CB < " + QString::number(mapAirports[airport]
                        .getCatILs().at(1).getCloudBase().get().getUpperBound()) + "ft"));
    ui->tvReqIlsCat->setItem(2, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(1).
                        getRvrType().getLowerBound()) + "m < RVR < " + QString::number(mapAirports[airport]
                        .getCatILs().at(1).getRvrType().getUpperBound()) + "m"));
    ui->tvReqIlsCat->setItem(2, 3, new QTableWidgetItem("N/A"));

    ui->tvReqIlsCat->setItem(3, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(2).
                        getCloudBase().get().getLowerBound()) + "ft < CB < " + QString::number(mapAirports[airport]
                        .getCatILs().at(2).getCloudBase().get().getUpperBound()) + "ft"));
    ui->tvReqIlsCat->setItem(3, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(2).
                        getRvrType().getLowerBound()) + "m < RVR < " + QString::number(mapAirports[airport]
                        .getCatILs().at(2).getRvrType().getUpperBound()) + "m"));
    ui->tvReqIlsCat->setItem(3, 3, new QTableWidgetItem("N/A"));

    ui->tvReqIlsCat->setItem(4, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(3).
                        getCloudBase().get().getLowerBound()) + "ft < CB < " + QString::number(mapAirports[airport]
                        .getCatILs().at(3).getCloudBase().get().getUpperBound()) + "ft"));
    ui->tvReqIlsCat->setItem(4, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(3).
                        getRvrType().getLowerBound()) + "m < RVR < " + QString::number(mapAirports[airport]
                        .getCatILs().at(3).getRvrType().getUpperBound()) + "m"));
    ui->tvReqIlsCat->setItem(4, 3, new QTableWidgetItem("N/A"));

    ui->tvReqIlsCat->setItem(5, 1, new QTableWidgetItem("N/A"));
    ui->tvReqIlsCat->setItem(5, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getCatILs().at(4).
                        getRvrType().getLowerBound()) + "m < RVR < " + QString::number(mapAirports[airport]
                        .getCatILs().at(4).getRvrType().getUpperBound()) + "m"));
    ui->tvReqIlsCat->setItem(5, 3, new QTableWidgetItem("N/A"));

    configAlignFontTables(ui->tvReqIlsCat);
	for(int i = 0; i < ui->tvReqIlsCat->columnCount(); i++)
	{
		ui->tvReqIlsCat->item(0, i)->setBackgroundColor("#C0C0C0");
		ui->tvReqIlsCat->item(0, i)->setFont(bold);
	}


}

void LpwHmiConfigMeteo::configTableWindThresholds(QString airport)
{
    ui->twWindThresholds->setRowCount(5);
    ui->twWindThresholds->setColumnCount(9);

    ui->twWindThresholds->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->twWindThresholds->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->twWindThresholds->horizontalHeader()->hide();
    ui->twWindThresholds->verticalHeader()->hide();

    ui->twWindThresholds->setSpan(0, 1, 1, 4);
    ui->twWindThresholds->setSpan(0, 5, 1, 4);
    ui->twWindThresholds->setSpan(1, 1, 1, 2);
	ui->twWindThresholds->setSpan(1, 3, 1, 2);
	ui->twWindThresholds->setSpan(1, 5, 1, 2);
	ui->twWindThresholds->setSpan(1, 7, 1, 2);
	ui->twWindThresholds->setSpan(0, 0, 3, 1);

	ui->twWindThresholds->setItem(0, 0, new QTableWidgetItem("RUNWAY"));
	ui->twWindThresholds->setItem(0, 1, new QTableWidgetItem("CROSSWIND (kt)"));
	ui->twWindThresholds->setItem(0, 5, new QTableWidgetItem("TAILWIND (kt)"));
	ui->twWindThresholds->setItem(1, 1, new QTableWidgetItem("LOWER THRESHOLD"));
	ui->twWindThresholds->setItem(1, 3, new QTableWidgetItem("UPPER THRESHOLD"));
	ui->twWindThresholds->setItem(1, 5, new QTableWidgetItem("LOWER THRESHOLD"));
	ui->twWindThresholds->setItem(1, 7, new QTableWidgetItem("UPPER THRESHOLD"));

	ui->twWindThresholds->setItem(2, 1, new QTableWidgetItem("DRY"));
	ui->twWindThresholds->setItem(2, 2, new QTableWidgetItem("WET"));
	ui->twWindThresholds->setItem(2, 3, new QTableWidgetItem("DRY"));
	ui->twWindThresholds->setItem(2, 4, new QTableWidgetItem("WET"));
	ui->twWindThresholds->setItem(2, 5, new QTableWidgetItem("DRY"));
	ui->twWindThresholds->setItem(2, 6, new QTableWidgetItem("WET"));
	ui->twWindThresholds->setItem(2, 7, new QTableWidgetItem("DRY"));
	ui->twWindThresholds->setItem(2, 8, new QTableWidgetItem("WET"));

	for(int i = 3; i < ui->twWindThresholds->rowCount(); i++)
	{
		ui->twWindThresholds->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(mapAirports[airport].getRunways().at(i-3).getRunwayName())));
		ui->twWindThresholds->setItem(i, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getCrosswindLowerThresholdDry())));
		ui->twWindThresholds->setItem(i, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getCrosswindLowerThresholdWet())));
		ui->twWindThresholds->setItem(i, 3, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getCrosswindUpperThresholdDry())));
		ui->twWindThresholds->setItem(i, 4, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getCrosswindUpperThresholdWet())));
		ui->twWindThresholds->setItem(i, 5, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getTailwindLowerThresholdDry())));
		ui->twWindThresholds->setItem(i, 6, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getTailwindLowerThresholdWet())));
		ui->twWindThresholds->setItem(i, 7, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getTailwindUpperThresholdDry())));
		ui->twWindThresholds->setItem(i, 8, new QTableWidgetItem(QString::number(mapAirports[airport].getRunways().at(i-3).getTailwindUpperThresholdWet())));
	}


    configAlignFontTables(ui->twWindThresholds);

    for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < ui->twWindThresholds->columnCount(); j++)
		{
			if(ui->twWindThresholds->item(i, j) != NULL)
			{
				ui->twWindThresholds->item(i, j)->setBackgroundColor("#C0C0C0");
				ui->twWindThresholds->item(i, j)->setFont(bold);
			}
		}
	}

	for(int i = 0; i < ui->twWindThresholds->rowCount(); i++)
	{
		if(ui->twWindThresholds->item(i, 0) != NULL)
		{
			ui->twWindThresholds->item(i, 0)->setBackgroundColor("#C0C0C0");
			ui->twWindThresholds->item(i, 0)->setFont(bold);
		}
	}
}

void LpwHmiConfigMeteo::configAlignFontTables(QTableWidget *table)
{
    for(int i = 0; i < table->rowCount(); i++)
    {
        for(int j = 0; j < table->columnCount(); j++)
        {
        	if(table->item(i, j) != NULL)
        	{
				table->item(i, j)->setTextAlignment(Qt::AlignCenter);
				table->item(i, j)->setFont(font);
				table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        	}
        }
    }
}

LpwHmiConfigMeteo::~LpwHmiConfigMeteo()
{
    delete ui;
}
