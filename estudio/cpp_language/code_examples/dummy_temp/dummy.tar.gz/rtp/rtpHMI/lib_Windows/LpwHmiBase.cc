#include "LpwHmiBase.h"
#include "ui_rtpbase.h"
#include "LpsigSignalsHmi.h"

LpwHmiBase::LpwHmiBase(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiBase)
{
    ui->setupUi(this);
}

LpwHmiBase::~LpwHmiBase()
{
    delete ui;
}
