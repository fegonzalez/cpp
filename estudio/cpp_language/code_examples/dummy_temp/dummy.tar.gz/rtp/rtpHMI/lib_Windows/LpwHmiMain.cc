#include "LpwHmiMain.h"
#include "ui_rtpmain.h"
#include <iostream>
#include <QScreen>
#include <QApplication>
#include <LpaAdaptationMrtmInfo.h>
#include "LpsigSignalsHmi.h"


LpwHmiMain::LpwHmiMain(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LpwHmiMain)
{
    ui->setupUi(this);
    setWindowTitle("RTP HMI");

    ui->widgetAnalysis->hide();
    ui->widgetConfiguration->hide();

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalOpenAnalysis()), this, SLOT(openAnalysisTab()));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalOpenMonitoring()), this, SLOT(openMonitoringTab()));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalOpenConfiguration()), this, SLOT(openConfigurationTab()));
}

void LpwHmiMain::openAnalysisTab()
{
    ui->widgetCentral->hide();
    ui->widgetConfiguration->hide();
    ui->widgetAnalysis->show();
}

void LpwHmiMain::openMonitoringTab()
{
    ui->widgetAnalysis->hide();
    ui->widgetConfiguration->hide();
    ui->widgetCentral->show();
}

void LpwHmiMain::openConfigurationTab()
{
    ui->widgetAnalysis->hide();
    ui->widgetCentral->hide();
    ui->widgetConfiguration->show();
}

LpwHmiMain::~LpwHmiMain()
{
    delete ui;
}

