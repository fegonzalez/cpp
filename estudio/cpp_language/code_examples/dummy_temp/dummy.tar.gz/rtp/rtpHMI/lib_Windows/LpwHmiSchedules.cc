// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Tue 07 Aug 14:24:27 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpwHmiSchedules.h"
#include "ui_rtpschedules.h"

#include <QList>
#include "LpsigSignalsHmi.h"
#include <QScrollBar>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include <QList>
#include <QFile>
#include <QTextStream>


LpwHmiSchedules::LpwHmiSchedules(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiSchedules)
{
    ui->setupUi(this);
    ui->rbComplexity->setChecked(true);

    configActiveSchedule();
    configOptimalSchedule();

	connect(ui->tvActiveSch, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableActiveClicked(const QModelIndex &)));
	connect(ui->tvOptimalSch, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableOptimalClicked(const QModelIndex &)));

	connect(ui->rbComplexity, SIGNAL(clicked()), this, SLOT(checkComplexity()));
	connect(ui->rbSimOps, SIGNAL(clicked()), this, SLOT(checkSimOps()));
	connect(ui->rbTotalMov, SIGNAL(clicked()), this, SLOT(checkTotalMov()));


}



void LpwHmiSchedules::configActiveSchedule()
{
	ui->tvActiveSch->horizontalHeader()->hide();
	ui->tvActiveSch->verticalHeader()->hide();
	ui->tvActiveSch->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->tvActiveSchDetails->horizontalHeader()->hide();
	ui->tvActiveSchDetails->verticalHeader()->hide();
	ui->tvActiveSchDetails->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	activeScheduleModel = new LpmodHmiActiveScheduleModel();
	ui->tvActiveSch->setModel(activeScheduleModel);

	airportActiveScheduleModel = new LpmodHmiAirportActiveScheduleModel("MRTM 1");
	ui->tvActiveSchDetails->setModel(airportActiveScheduleModel);

	connect(ui->tvActiveSch->horizontalScrollBar(), &QScrollBar::valueChanged,
	ui->tvActiveSchDetails->horizontalScrollBar(), &QScrollBar::setValue);
	connect(ui->tvActiveSchDetails->horizontalScrollBar(), &QScrollBar::valueChanged,
	ui->tvActiveSch->horizontalScrollBar(), &QScrollBar::setValue);
}

void LpwHmiSchedules::configOptimalSchedule()
{
	ui->tvOptimalSch->horizontalHeader()->hide();
	ui->tvOptimalSch->verticalHeader()->hide();
	ui->tvOptimalSch->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->tvOptimalSchDetails->horizontalHeader()->hide();
	ui->tvOptimalSchDetails->verticalHeader()->hide();
	ui->tvOptimalSchDetails->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	optimalScheduleModel = new LpmodHmiOptimalScheduleModel();
	ui->tvOptimalSch->setModel(optimalScheduleModel);

	airportOptScheduleModel = new LpmodHmiAirportOptimalScheduleModel("MRTM 1");
	ui->tvOptimalSchDetails->setModel(airportOptScheduleModel);

	connect(ui->tvOptimalSch->horizontalScrollBar(), &QScrollBar::valueChanged,
	ui->tvOptimalSchDetails->horizontalScrollBar(), &QScrollBar::setValue);
	connect(ui->tvOptimalSchDetails->horizontalScrollBar(), &QScrollBar::valueChanged,
	ui->tvOptimalSch->horizontalScrollBar(), &QScrollBar::setValue);
}

void LpwHmiSchedules::onTableActiveClicked(const QModelIndex &index)
{
    if (index.isValid())
    {
    	if(index.column() == 0)
    	{
    		airportActiveScheduleModel = new LpmodHmiAirportActiveScheduleModel(index.data().toString());
    		if(getComplexityChecked())
    			airportActiveScheduleModel->checkComplexity();
    		if(getSimOpsChecked())
    			airportActiveScheduleModel->checkSimOps();
    		if(getTotalMovChecked())
    			airportActiveScheduleModel->checkTotalMov();
    		ui->tvActiveSchDetails->setModel(airportActiveScheduleModel);
    	}
    }
}

void LpwHmiSchedules::onTableOptimalClicked(const QModelIndex &index)
{
    if (index.isValid())
    {
    	if(index.column() == 0)
    	{
    		airportOptScheduleModel = new LpmodHmiAirportOptimalScheduleModel(index.data().toString());
    		if(getComplexityChecked())
    			airportOptScheduleModel->checkComplexity();
			if(getSimOpsChecked())
				airportOptScheduleModel->checkSimOps();
			if(getTotalMovChecked())
				airportOptScheduleModel->checkTotalMov();
    		ui->tvOptimalSchDetails->setModel(airportOptScheduleModel);
    	}
    }
}

bool LpwHmiSchedules::getComplexityChecked()
{
	return ui->rbComplexity->isChecked();
}

bool LpwHmiSchedules::getSimOpsChecked()
{
	return ui->rbSimOps->isChecked();
}

bool LpwHmiSchedules::getTotalMovChecked()
{
	return ui->rbTotalMov->isChecked();
}

void LpwHmiSchedules::checkComplexity()
{
	ui->rbComplexity->setChecked(true);
	ui->rbSimOps->setChecked(false);
	ui->rbTotalMov->setChecked(false);
	airportActiveScheduleModel->checkComplexity();
	airportOptScheduleModel->checkComplexity();
}

void LpwHmiSchedules::checkSimOps()
{
	ui->rbSimOps->setChecked(true);
	ui->rbComplexity->setChecked(false);
	ui->rbTotalMov->setChecked(false);
	airportActiveScheduleModel->checkSimOps();
	airportOptScheduleModel->checkSimOps();
}

void LpwHmiSchedules::checkTotalMov()
{
	ui->rbTotalMov->setChecked(true);
	ui->rbComplexity->setChecked(false);
	ui->rbSimOps->setChecked(false);
	airportActiveScheduleModel->checkTotalMov();
	airportOptScheduleModel->checkTotalMov();
}

LpwHmiSchedules::~LpwHmiSchedules()
{
    delete ui;
}
