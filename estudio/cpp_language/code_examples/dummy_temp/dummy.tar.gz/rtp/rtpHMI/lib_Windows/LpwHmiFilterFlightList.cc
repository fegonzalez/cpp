#include "LpwHmiFilterFlightList.h"
#include "ui_rtpfilterflightlist.h"


LpwHmiFilterFlightList::LpwHmiFilterFlightList(QStringList airports, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LpwHmiFilterFlightList)
{
    ui->setupUi(this);
    setWindowTitle(tr("Select the airport: "));

    ui->lwListFilterAirport->addItem(new QListWidgetItem("ALL"));

    for(int i = 0; i < airports.size(); i++)
        ui->lwListFilterAirport->addItem(airports[i]);
}

LpwHmiFilterFlightList::~LpwHmiFilterFlightList()
{
    delete ui;
}

void LpwHmiFilterFlightList::on_pbOkFilter_clicked()
{
	confirmSelection = true;
	close();
}

void LpwHmiFilterFlightList::on_pbCancelFilter_clicked()
{
	confirmSelection = false;
	close();
}

QString LpwHmiFilterFlightList::getText(){
    QList<QListWidgetItem*> selected = ui->lwListFilterAirport->selectedItems();
    if(confirmSelection && selected.size() > 0)
        return selected[0]->text();
    else
        return "";
}
