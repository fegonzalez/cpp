#include "LpwHmiFilterFlightList.h"
#include "ui_rtpfilterflightlist.h"


LpwHmiFilterFlightList::LpwHmiFilterFlightList(QStringList airports, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LpwHmiFilterFlightList)
{
    ui->setupUi(this);
    setWindowTitle(tr("Select the airport: "));

    for(int i = 0; i < airports.size(); i++)
        ui->lwListFilterAirport->addItem(airports[i]);
}

LpwHmiFilterFlightList::~LpwHmiFilterFlightList()
{
    delete ui;
}

void LpwHmiFilterFlightList::on_bbFilterFlightList_accepted()
{
    accept();
}

void LpwHmiFilterFlightList::on_bbFilterFlightList_rejected()
{
    reject();
}

QString LpwHmiFilterFlightList::getText(){
    QList<QListWidgetItem*> selected = ui->lwListFilterAirport->selectedItems();
    if(selected.size() > 0)
        return selected[0]->text();
    else
        return "";
}
