// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 03 Sep 10:42:15 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpwHmiConfiguration.h"
#include "ui_rtpconfiguration.h"

LpwHmiConfiguration::LpwHmiConfiguration(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiConfiguration)
{
    ui->setupUi(this);

}

LpwHmiConfiguration::~LpwHmiConfiguration()
{
    delete ui;
}
