#ifndef LPWHMIHEADER_H
#define LPWHMIHEADER_H

#include <QWidget>
#include <QFile>
#include <QTime>
#include <QDate>
#include <QTimer>

namespace Ui {
class LpwHmiHeader;
}

class LpwHmiHeader : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiHeader(QWidget *parent = 0);
    ~LpwHmiHeader();

private slots:

    void setSystemDate();
    void setSystemHour();

private:
    Ui::LpwHmiHeader *ui;
    QTimer *timer;
};

#endif // LPWHMIHEADER_H
