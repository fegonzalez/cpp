#ifndef LPWHMIFLIGHTS_H
#define LPWHMIFLIGHTS_H

#include <QWidget>
#include "LpmodFlightPlanModel.h"

namespace Ui {
class LpwHmiFlights;
}

class LpwHmiFlights : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiFlights(QWidget *parent = 0);
    ~LpwHmiFlights();

    enum flightType { ADEP, ADES };

public slots:
	void onUpdateTable();

private slots:

	void on_pbFilterADEP_clicked();
    void on_pbFilterADES_clicked();

    void on_leFilterADEP_textChanged(const QString &text);
    void on_leFilterADES_textChanged(const QString &text);

    void getFilteredText(QLineEdit*, flightType);

private:
    Ui::LpwHmiFlights *ui;

    LpmodFlightPlanModel m_model;
    QSortFilterProxyModel *proxyAdep;
    QSortFilterProxyModel *proxyAdes;
    QStringList airports;
    QStringList airportsDep;
    QStringList airportsArr;


};

#endif // LPWHMIBASEDOWNSIDE_H
