#ifndef LPWHMIMAIN_H
#define LPWHMIMAIN_H

#include <QMainWindow>
#include "LpwHmiSchedules.h"
#include "LpwHmiKpisTab.h"

namespace Ui {
class LpwHmiMain;
}

class LpwHmiMain: public QMainWindow {
	Q_OBJECT

public:

	explicit LpwHmiMain(QWidget *parent = 0);
	~LpwHmiMain();


public slots:
    void openAnalysisTab();
    void openMonitoringTab();
    void openConfigurationTab();

private:
	Ui::LpwHmiMain *ui;
};

#endif // LPWHMIMAIN_H
