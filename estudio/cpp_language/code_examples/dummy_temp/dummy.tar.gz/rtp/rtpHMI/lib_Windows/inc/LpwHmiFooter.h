#ifndef LPWHMIFOOTER_H
#define LPWHMIFOOTER_H

#include <QWidget>

#include "LpwHmiKpisTab.h"

namespace Ui {
class LpwHmiFooter;
}

class LpwHmiFooter : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiFooter(QWidget *parent = 0);
    ~LpwHmiFooter();

public slots:
    void colorMonitoringSelect();
    void colorAnalysisSelect();
    void colorConfigurationSelect();

private:
    Ui::LpwHmiFooter *ui;
};

#endif // LPWHMIFOOTER_H
