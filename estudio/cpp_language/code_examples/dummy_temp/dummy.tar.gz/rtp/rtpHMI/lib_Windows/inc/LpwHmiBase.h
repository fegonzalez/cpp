#ifndef LPWHMIBASE_H
#define LPWHMIBASE_H

#include <QWidget>
#include "QFile"

namespace Ui {
class LpwHmiBase;
}

class LpwHmiBase : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiBase(QWidget *parent = 0);
    ~LpwHmiBase();

private:
    Ui::LpwHmiBase *ui;
};

#endif // LPWHMIBASE_H
