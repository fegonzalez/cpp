// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 10 Aug 12:48:57 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef C___SRC_RTP_RTPHMI_LIB_WINDOWS_LPWHMIAIRPORTINFO_H_
#define C___SRC_RTP_RTPHMI_LIB_WINDOWS_LPWHMIAIRPORTINFO_H_


#include <QWidget>
#include "LpiAdaptationAirportsInfo.h"
#include "LpiAdaptationMrtmInfo.h"
#include <QTableWidget>

namespace Ui {
class LpwHmiAirportInfo;
}

class LpwHmiAirportInfo : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiAirportInfo(QWidget *parent = 0);
    ~LpwHmiAirportInfo();

private slots:
    void cbAirportsNameTextChanged(const QString airport);
    void fillMrtmComplexity();
    void fillAirportComplexity(QString airport);
    void configTableStyle(QTableWidget *table);

private:
    Ui::LpwHmiAirportInfo *ui;
    QHash<QString, Airport> mapAirports;
    LpiAdaptationAirportsInfo parameters;
    LpiAdaptationMrtmInfo parametersMrtm;

    QFont font;
	QFont bold;

};

#endif /* C___SRC_RTP_RTPHMI_LIB_WINDOWS_LPWHMIAIRPORTINFO_H_ */
