#include "LpwHmiHeader.h"
#include "ui_rtpheader.h"
#include "LctimVirtualClock.h"
#include "LctimTimeUtils.h"
#include "QDateTimeEdit"

LpwHmiHeader::LpwHmiHeader(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiHeader)
{
    ui->setupUi(this);
    QString dateNow = QString::fromStdString(LctimTimeUtils::formatTime(
			LctimVirtualClock::Get().getTime(), "%d/%m/%Y"));
    ui->lDate->setText(dateNow);

    QString timeNow = QString::fromStdString(LctimTimeUtils::formatTime(
    		LctimVirtualClock::Get().getTime(), "%H:%M:%S"));
    ui->lTime->setText(timeNow);

    timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(setSystemHour()));
	connect(timer, SIGNAL(timeout()), this, SLOT(setSystemDate()));
	timer->start(1000);

    connect(ui->pbLogout, SIGNAL(clicked()), QApplication::instance(), SLOT(quit()));
}

void LpwHmiHeader::setSystemHour(){
	QString timeNow = QString::fromStdString(LctimTimeUtils::formatTime(
			LctimVirtualClock::Get().getTime(), "%H:%M:%S"));
	ui->lTime->setText(timeNow);
}

void LpwHmiHeader::setSystemDate(){
    QString dateNow = QString::fromStdString(LctimTimeUtils::formatTime(
			LctimVirtualClock::Get().getTime(), "%d/%m/%Y"));
    ui->lDate->setText(dateNow);
}


LpwHmiHeader::~LpwHmiHeader()
{
    delete ui;
}
