#include "LpwHmiHeader.h"
#include "ui_rtpheader.h"


LpwHmiHeader::LpwHmiHeader(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiHeader)
{
    ui->setupUi(this);
    setSystemDate();
    timer = new QTimer(this);
    timer->start(1000);
    connect(timer, SIGNAL(timeout()), this, SLOT(setSystemHour()));

    connect(ui->pbLogout, SIGNAL(clicked()), QApplication::instance(), SLOT(quit()));
}

void LpwHmiHeader::setSystemHour(){
    ui->lTime->setText(QTime::currentTime().toString("hh:mm:ss"));
}

LpwHmiHeader::~LpwHmiHeader()
{
    delete ui;
}

void LpwHmiHeader::setSystemDate(){
    QDate dtime = QDate::currentDate();
    QString date = dtime.toString("dd/MM/yyyy");
    ui->lDate->setText(date);
}
