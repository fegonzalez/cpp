#ifndef LPWHMIFILTERFLIGHTLIST_H
#define LPWHMIFILTERFLIGHTLIST_H

#include <QDialog>
#include <QListWidgetItem>
#include <QListView>
#include <QDebug>
#include <QFile>
#include <QTextStream>

namespace Ui {
class LpwHmiFilterFlightList;
}

class LpwHmiFilterFlightList : public QDialog
{
    Q_OBJECT

public:
    explicit LpwHmiFilterFlightList(QStringList airports, QWidget *parent = 0);
    ~LpwHmiFilterFlightList();
    QString getText();

private slots:
    void on_bbFilterFlightList_accepted();
    void on_bbFilterFlightList_rejected();

private:
    Ui::LpwHmiFilterFlightList *ui;
};

#endif // LPWHMIFILTERFLIGHTLIST_H
