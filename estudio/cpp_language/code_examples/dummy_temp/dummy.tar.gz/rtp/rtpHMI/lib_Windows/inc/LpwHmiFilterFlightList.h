#ifndef LPWHMIFILTERFLIGHTLIST_H
#define LPWHMIFILTERFLIGHTLIST_H

#include <QDialog>
#include <QListWidgetItem>
#include <QListView>
#include <QDebug>
#include <QFile>
#include <QTextStream>

namespace Ui {
class LpwHmiFilterFlightList;
}

class LpwHmiFilterFlightList : public QDialog
{
    Q_OBJECT

public:
    explicit LpwHmiFilterFlightList(QStringList airports, QWidget *parent = 0);
    ~LpwHmiFilterFlightList();
    QString getText();

private slots:
    void on_pbOkFilter_clicked();
    void on_pbCancelFilter_clicked();

private:
    Ui::LpwHmiFilterFlightList *ui;
    bool confirmSelection;
};

#endif // LPWHMIFILTERFLIGHTLIST_H
