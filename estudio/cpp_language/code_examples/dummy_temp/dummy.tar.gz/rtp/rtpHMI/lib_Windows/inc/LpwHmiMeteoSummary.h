#ifndef LPWHMIMETEOSUMMARY_H
#define LPWHMIMETEOSUMMARY_H

#include <QWidget>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include "LpdbMeteoNowObservable.h"
#include <LpiMeteoInfo.h> // LpiUpdateMeteoList

namespace Ui {
class LpwHmiMeteoSummary;
}

class LpwHmiMeteoSummary : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiMeteoSummary(QWidget *parent = 0);
    ~LpwHmiMeteoSummary();

public slots:
    void onUpdateMeteoNow();
    void onUpdateMeteoFore();
    void updateFieldsMeteo(LpiUpdateMeteoList, QString);

private slots:
    void on_cbAirportsList_currentTextChanged(const QString &arg1);
    void on_cbForecastSummary_currentTextChanged(const QString &arg1);

    void updateMeteoNowMessage(QString);
    void updateMeteoForeMessage(QString);
    void addAirportsComboBox();

private:
    Ui::LpwHmiMeteoSummary *ui;
    LpdbMeteoNowObservable* observable;


    //    QHash<QString, MeteorologicalInformation> mapMeteo;  // RMAN's LpiMeteoInfoHmi.h; MeteorologicalInformation

    /**@param  mapMeteo

       @brief MeteorologicalInformation for each Meteo data received, (either from one or many files.)

       @todo Use only the meteorological data when LpiMeteoInfo is updated: "calculationReason: Meteo Nowcast Reception"

	@warning (From RMAN) Not saving  LpiUpdateMeteo::calculationReason,
     *                               LpiUpdateMeteo::timeline
     *                               LpiUpdateMeteo::messageTimeandDate
     *
     *   // ¿ debería ser Hash<QString, LpiMeteoInfoList> mapMeteo;?
         // QHash<QString, LpiMeteoInfoList> mapMeteo;  // ??? FIXME
     */
    QHash<QString, LpiMeteoInfo> mapMeteoNow; // saving LpiUpdateMeteo::meteoInfo (vector<LpiMeteoInfo>)
    QHash<QString, std::vector<LpiMeteoInfo>> mapMeteoFore;
    QList<QString> listAirport; // saving LpiUpdateMeteo::airport
    QString airport;
//    QHash<QString, QString> mapAirportPeriods;
};

#endif // LPWHMIBASEUPSIDEREDUCED_H
