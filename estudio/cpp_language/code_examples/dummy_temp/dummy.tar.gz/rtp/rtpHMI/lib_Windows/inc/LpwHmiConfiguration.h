// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 03 Sep 10:42:03 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPWHMICONFIGURATION_H_
#define LPWHMICONFIGURATION_H_

#include <QWidget>

namespace Ui {
class LpwHmiConfiguration;
}

class LpwHmiConfiguration : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiConfiguration(QWidget *parent = 0);
    ~LpwHmiConfiguration();

private:
    Ui::LpwHmiConfiguration *ui;

};


#endif /* LPWHMICONFIGURATION_H_ */
