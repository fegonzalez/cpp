#include "LpwHmiTabWidget.h"
#include "ui_rtptabwidget.h"
#include <iostream>

#include "LpsigSignalsHmi.h"

LpwHmiTabWidget::LpwHmiTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiTabWidget)
{
    ui->setupUi(this);
    ui->lbCalculatingDefSch->setText("Calculating default schedule...");

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalChangeTabToMeteo()), this,
            SLOT(changeTabToMeteo()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalChangeTabToFlightList()), this,
            SLOT(changeTabToFlightList()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalChangeTabToSummary()), this,
            SLOT(changeTabToSummary()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalActiveSchedule()), this,
			SLOT(removeLabelCalculatinDefSch()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalOptimalSchedule()), this,
			SLOT(removeLabelCalculatinDefSch()));
}

void LpwHmiTabWidget::changeTabToMeteo() {
    ui->tabWidget->setCurrentIndex(tabMeteo);
}

void LpwHmiTabWidget::changeTabToFlightList() {
    ui->tabWidget->setCurrentIndex(tabFlightPlans);
}

void LpwHmiTabWidget::changeTabToSummary() {
    ui->tabWidget->setCurrentIndex(tabSummary);
}

void LpwHmiTabWidget::removeLabelCalculatinDefSch()
{
	ui->lbCalculatingDefSch->setText("");
}

LpwHmiTabWidget::~LpwHmiTabWidget()
{
    delete ui;
}

