#include "LpwHmiTabWidget.h"
#include "ui_rtptabwidget.h"
#include <iostream>

#include "LpsigSignalsHmi.h"

LpwHmiTabWidget::LpwHmiTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiTabWidget)
{
    ui->setupUi(this);

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalChangeTabToMeteo()), this,
            SLOT(changeTabToMeteo()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalChangeTabToFlightList()), this,
            SLOT(changeTabToFlightList()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalChangeTabToSummary()), this,
            SLOT(changeTabToSummary()));

}

void LpwHmiTabWidget::changeTabToMeteo() {
    ui->tabWidget->setCurrentIndex(tabMeteo);
}

void LpwHmiTabWidget::changeTabToFlightList() {
    ui->tabWidget->setCurrentIndex(tabFlightPlans);
}

void LpwHmiTabWidget::changeTabToSummary() {
    ui->tabWidget->setCurrentIndex(tabSummary);
}

LpwHmiTabWidget::~LpwHmiTabWidget()
{
    delete ui;
}

