// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 03 Sep 13:47:46 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPWHMICONFIGPARAMETERS_H_
#define LPWHMICONFIGPARAMETERS_H_


#include <QWidget>
#include "LpiAdaptationAlert_KPIs.h"

namespace Ui {
class LpwHmiConfigParameters;
}

class LpwHmiConfigParameters : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiConfigParameters(QWidget *parent = 0);
    ~LpwHmiConfigParameters();

private slots:
    void configTableAlertThresholds();
    void fillTimeParameters();

private:
    Ui::LpwHmiConfigParameters *ui;
    QFont font;

};


#endif /* C___SRC_RTP_RTPHMI_LIB_WINDOWS_INC_LPWHMICONFIGPARAMETERS_H_ */
