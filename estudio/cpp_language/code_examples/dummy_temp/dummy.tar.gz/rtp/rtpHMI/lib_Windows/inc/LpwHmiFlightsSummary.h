#ifndef LPWHMIFLIGHTSSUMARY_H
#define LPWHMIFLIGHTSSUMARY_H

#include <QWidget>
#include "LpmodFlightPlanModel.h"
#include "LpiFlightPlan.h"
#include "LpiHmiDemand.h"

namespace Ui {
class LpwHmiFlightsSummary;
}

class LpwHmiFlightsSummary : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiFlightsSummary(QWidget *parent = 0);
    ~LpwHmiFlightsSummary();

    enum flightType { ADEP, ADES };

public slots:
	void onUpdateTable();

private slots:

    void on_leFilterADEP_textChanged(const QString &text);
    void on_leFilterADES_textChanged(const QString &text);
	void on_pbFilterADEP_clicked();
    void on_pbFilterADES_clicked();

    void getFilteredText(QLineEdit*, flightType);



private:
    Ui::LpwHmiFlightsSummary *ui;

    LpmodFlightPlanModel m_model;
    QStringList airports;
    QStringList airportsDep;
    QStringList airportsArr;
    QSortFilterProxyModel *proxyAdep;
    QSortFilterProxyModel *proxyAdes;
};

#endif // LPWHMIBASEDOWNSIDEREDUCED_H
