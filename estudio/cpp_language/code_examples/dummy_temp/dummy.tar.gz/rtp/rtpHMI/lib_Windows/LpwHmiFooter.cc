#include "LpwHmiFooter.h"
#include "ui_rtpfooter.h"
#include "LpsigSignalsHmi.h"
#include <iostream>

LpwHmiFooter::LpwHmiFooter(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiFooter)
{
    ui->setupUi(this);
    ui->pbMonitoring->setStyleSheet("color: #FFFFFF; background: #027FCC; border-color: #000000; border-width: 2px");
    connect(ui->pbAnalysis, SIGNAL(clicked()), &LpsigSignalsHmi::Get(), SLOT(openAnalysis()));
    connect(ui->pbAnalysis, SIGNAL(clicked()), this, SLOT(colorAnalysisSelect()));
    connect(ui->pbMonitoring, SIGNAL(clicked()), &LpsigSignalsHmi::Get(), SLOT(openMonitoring()));
    connect(ui->pbMonitoring, SIGNAL(clicked()), this, SLOT(colorMonitoringSelect()));
    connect(ui->pbConfiguration, SIGNAL(clicked()), &LpsigSignalsHmi::Get(), SLOT(openConfiguration()));
    connect(ui->pbConfiguration, SIGNAL(clicked()), this, SLOT(colorConfigurationSelect()));
}

void LpwHmiFooter::colorAnalysisSelect()
{
    ui->pbAnalysis->setStyleSheet("color: #FFFFFF; background: #027FCC; border-color: #000000; border-width: 2px");
    ui->pbMonitoring->setStyleSheet("color: #FFFFFF;  background: #000000; border-color: #6DADD7; border-width: 2px");
    ui->pbConfiguration->setStyleSheet("color: #FFFFFF;  background: #000000; border-color: #6DADD7; border-width: 2px");
}

void LpwHmiFooter::colorMonitoringSelect()
{
    ui->pbMonitoring->setStyleSheet("color: #FFFFFF; background: #027FCC; border-color: #000000; border-width: 2px");
    ui->pbAnalysis->setStyleSheet("color: #FFFFFF;  background: #000000; border-color: #6DADD7; border-width: 2px");
    ui->pbConfiguration->setStyleSheet("color: #FFFFFF;  background: #000000; border-color: #6DADD7; border-width: 2px");
}

void LpwHmiFooter::colorConfigurationSelect()
{
    ui->pbConfiguration->setStyleSheet("color: #FFFFFF; background: #027FCC; border-color: #000000; border-width: 2px");
    ui->pbAnalysis->setStyleSheet("color: #FFFFFF;  background: #000000; border-color: #6DADD7; border-width: 2px");
    ui->pbMonitoring->setStyleSheet("color: #FFFFFF;  background: #000000; border-color: #6DADD7; border-width: 2px");
}


LpwHmiFooter::~LpwHmiFooter()
{
    delete ui;
}
