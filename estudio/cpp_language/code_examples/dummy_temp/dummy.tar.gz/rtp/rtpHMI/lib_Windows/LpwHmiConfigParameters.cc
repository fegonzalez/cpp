// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 03 Sep 13:48:31 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpwHmiConfigParameters.h"
#include "ui_rtpconfigurationparameters.h"
#include "LpdComponent.h"

LpwHmiConfigParameters::LpwHmiConfigParameters(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiConfigParameters)
{
    ui->setupUi(this);


    configTableAlertThresholds();

    fillTimeParameters();
}

void LpwHmiConfigParameters::configTableAlertThresholds()
{
    LpiAdaptationAlert_KPIs parameters;
    LpiResult result;
    LpdComponent::Get().getAdaptationAlert_KPIs(parameters, result);

    ui->twAlertThresholds->setRowCount(6);
    ui->twAlertThresholds->setColumnCount(4);

    ui->twAlertThresholds->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->twAlertThresholds->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->twAlertThresholds->horizontalHeader()->hide();
    ui->twAlertThresholds->verticalHeader()->hide();

    ui->twAlertThresholds->setItem(0, 0, new QTableWidgetItem(""));
    ui->twAlertThresholds->setItem(0, 1, new QTableWidgetItem("COMPARATIVE SIGN"));
    ui->twAlertThresholds->setItem(0, 2, new QTableWidgetItem("WARNING"));
    ui->twAlertThresholds->setItem(0, 3, new QTableWidgetItem("ALARM"));

    ui->twAlertThresholds->setItem(1, 0, new QTableWidgetItem("SIMULTANEOUS\n OPERATIONS"));
    ui->twAlertThresholds->setItem(2, 0, new QTableWidgetItem("TOTAL\n MOVEMENTS"));
    ui->twAlertThresholds->setItem(3, 0, new QTableWidgetItem("VFR"));
    ui->twAlertThresholds->setItem(4, 0, new QTableWidgetItem("AIRPORT\n COMPLEXITY"));
    ui->twAlertThresholds->setItem(5, 0, new QTableWidgetItem("MRTM\n COMPLEXITY"));

    ui->twAlertThresholds->setItem(1, 1, new QTableWidgetItem("<"));
    ui->twAlertThresholds->setItem(2, 1, new QTableWidgetItem("<"));
    ui->twAlertThresholds->setItem(3, 1, new QTableWidgetItem("<"));
    ui->twAlertThresholds->setItem(4, 1, new QTableWidgetItem("<"));
    ui->twAlertThresholds->setItem(5, 1, new QTableWidgetItem("<"));

    ui->twAlertThresholds->setItem(1, 2, new QTableWidgetItem(QString::number(parameters.getSimultaneousOpsHour().getNegativeAlert().getAlarmThreshold())));
    ui->twAlertThresholds->setItem(2, 2, new QTableWidgetItem(QString::number(parameters.getTotalMov().getNegativeAlert().getAlarmThreshold())));
    ui->twAlertThresholds->setItem(3, 2, new QTableWidgetItem(QString::number(parameters.getVfr().getNegativeAlert().getAlarmThreshold())));
    ui->twAlertThresholds->setItem(4, 2, new QTableWidgetItem(QString::number(parameters.getComplexity().getAirportsComplexity().getNegativeAlert().getAlarmThreshold())));
    ui->twAlertThresholds->setItem(5, 2, new QTableWidgetItem(QString::number(parameters.getComplexity().getModulesComplexity().getNegativeAlert().getAlarmThreshold())));

    ui->twAlertThresholds->setItem(1, 3, new QTableWidgetItem(QString::number(parameters.getSimultaneousOpsHour().getNegativeAlert().getWarningThreshold())));
    ui->twAlertThresholds->setItem(2, 3, new QTableWidgetItem(QString::number(parameters.getTotalMov().getNegativeAlert().getWarningThreshold())));
    ui->twAlertThresholds->setItem(3, 3, new QTableWidgetItem(QString::number(parameters.getVfr().getNegativeAlert().getWarningThreshold())));
    ui->twAlertThresholds->setItem(4, 3, new QTableWidgetItem(QString::number(parameters.getComplexity().getAirportsComplexity().getNegativeAlert().getWarningThreshold())));
    ui->twAlertThresholds->setItem(5, 3, new QTableWidgetItem(QString::number(parameters.getComplexity().getModulesComplexity().getNegativeAlert().getWarningThreshold())));

    font.setBold(true);
    for(int i = 0; i < ui->twAlertThresholds->rowCount(); i++)
    {
        for(int j = 0; j < ui->twAlertThresholds->columnCount(); j++)
        {
        	if (i == 0 || j == 0)
        	{
				ui->twAlertThresholds->item(i, j)->setFont(font);
				ui->twAlertThresholds->item(i, j)->setBackgroundColor("#C0C0C0");
        	}
            ui->twAlertThresholds->item(i, j)->setTextAlignment(Qt::AlignCenter);
            ui->twAlertThresholds->setEditTriggers(QAbstractItemView::NoEditTriggers);
        }
    }
}

void LpwHmiConfigParameters::fillTimeParameters()
{
    LpiAdaptationMrtmInfo parameters;
    LpiResult result;
    LpdComponent::Get().getAdaptationMrtmInfo(parameters, result);
    ui->leModuleTime->setText(QString::number(parameters.getMrtmStayTime()));

    LpiConfigurationCoreParameters parametersConfig;
    LpiResult resultConfig;
    LpdComponent::Get().getConfigurationCoreParameters(parametersConfig, resultConfig);
    ui->leTotalTimeWindow->setText(QString::number(parametersConfig.getTimeParameters().getHoursWindow()));
    ui->leFrozenPeriod->setText(QString::number(parametersConfig.getTimeParameters().getMinutesFrozen()));
    ui->leSubintervalDuration->setText(QString::number(parametersConfig.getTimeParameters().getMinutesSubinterval()));
}

LpwHmiConfigParameters::~LpwHmiConfigParameters()
{
    delete ui;
}
