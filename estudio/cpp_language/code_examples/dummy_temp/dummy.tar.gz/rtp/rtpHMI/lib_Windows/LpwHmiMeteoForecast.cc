// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Tue 07 Aug 13:01:42 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------


#include "LpwHmiMeteoForecast.h"
#include "ui_rtpmeteoforecast.h"

#include <QList>
#include "LpsigSignalsHmi.h"
#include <LctimTimeUtils.h>
#include <LcmetConstants.h>
#include <LpdbMeteoNowObservable.h>
#include <LpdbMeteoForeObservable.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>

#include <iostream>
#include <vector>
#include <iterator>

LpwHmiMeteoForecast::LpwHmiMeteoForecast(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiMeteoForecast)
{
    ui->setupUi(this);
    ui->rbMeteoNow->setChecked(true);
    disableComboBox();

    connect(ui->rbMeteoNow, SIGNAL(clicked()), this, SLOT(disableComboBox()));
    connect(ui->rbMeteoFore, SIGNAL(clicked()), this, SLOT(enableComboBox()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteo()), this,
            SLOT(onUpdateMeteoNow()));

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoFore()), this,
            SLOT(onUpdateMeteoFore()));

    connect(ui->cbAirportsListForecast, SIGNAL(currentTextChanged(QString)), this,
            SLOT(cbAirportsListTextChanged(QString)));

    connect(ui->cbForecastPeriodFore, SIGNAL(currentTextChanged(QString)), this,
               SLOT(cbForecastPeriodForeTextChanged(QString)));

    connect(ui->cbRunwayAirport, SIGNAL(currentTextChanged(QString)), this,
			   SLOT(cbRunwayAirportTextChanged(QString)));

    observable = LpdbMeteoNowObservable::GetInstance();
    ui->cbForecastPeriod->setEnabled(false);

}

LpwHmiMeteoForecast::~LpwHmiMeteoForecast()
{
    delete ui;
}

void LpwHmiMeteoForecast::disableComboBox()
{
	ui->leForecastProb->setEnabled(false);
    ui->cbForecastPeriodFore->hide();
    ui->cbForecastPeriod->show();
    if(isLoadDataNow == false)
    	updateMeteoNowMessage(airport);
}

void LpwHmiMeteoForecast::enableComboBox()
{
	ui->leForecastProb->setEnabled(true);
    ui->cbForecastPeriod->hide();
    ui->cbForecastPeriodFore->show();
    if(isLoadDataFore == false)
        	updateMeteoForeMessage(airport);
}

void LpwHmiMeteoForecast::onUpdateMeteoNow()
{
	isLoadDataNow = true;
	const LpiUpdateMeteoList &meteoList = LpdbMeteoNowObservable::GetInstance()->getInfo();
	ui->rbMeteoNow->setChecked(true);
	disableComboBox();
	updateMeteoFields(meteoList, "now");
	isLoadDataNow = false;
}

void LpwHmiMeteoForecast::onUpdateMeteoFore()
{
	isLoadDataFore = true;
	const LpiUpdateMeteoList &meteoList = LpdbMeteoForeObservable::GetInstance()->getInfo();
	ui->rbMeteoFore->setChecked(true);
	enableComboBox();
	updateMeteoFields(meteoList, "fore");
	isLoadDataFore = false;
}

void LpwHmiMeteoForecast::updateMeteoFields(LpiUpdateMeteoList meteoList, QString meteo)
{
	// May get data form many Airports
	  for (unsigned int i = 0; i < meteoList.size(); i++)
	  {
	    const LpiUpdateMeteo &current_meteo = meteoList[i];
	    std::string aport_id = current_meteo.getAirport();
	    std::vector<LpiMeteoInfo> meteo_info = current_meteo.getMeteoInfo();

	    listAirport.append(QString::fromStdString(aport_id));

	    if(meteo.compare("fore") == 0)
			mapMeteoFore.insert(QString::fromStdString(aport_id), meteo_info);
		else if (meteo.compare("now") == 0)
			mapMeteoNow.insert(QString::fromStdString(aport_id), meteo_info.at(0));
	  }
	  airport = listAirport[0];
	  listAirport.removeDuplicates();
	  listAirport.sort();
	  addAirportsComboBox();
}

void LpwHmiMeteoForecast::addAirportsComboBox()
{
    ui->cbAirportsListForecast->clear();
    for(int i = 0; i < listAirport.size(); i++)
        ui->cbAirportsListForecast->addItem(listAirport.at(i));
}

void LpwHmiMeteoForecast::updateMeteoNowMessage(QString airport)
{
	QString periodNow = QString("%1 - %2")
                    .arg(QString::fromStdString(
                             LctimTimeUtils::formatTime(mapMeteoNow[airport].getStartTimeAndDate(), "%d/%m/%Y %H:%M:%S")))
                    .arg(QString::fromStdString(
                             LctimTimeUtils::formatTime(mapMeteoNow[airport].getEndTimeAndDate(), "%d/%m/%Y %H:%M:%S")));
	ui->cbForecastPeriod->addItem(periodNow);

    boost::optional<double> foreProbability = mapMeteoNow[airport].getProbability();
    if(foreProbability.is_initialized())
        ui->leForecastProb->setText(QString::number(foreProbability.get()) + " %");


    // IOUpdateMeteoInfo::BodyInformation::

    boost::optional<lcmeteo::TYPE_WIND_SPEED> windSpeed = mapMeteoNow[airport].getWindSpeed();
    if(windSpeed.is_initialized())
        ui->leWindSpeedForecast->setText(QString::number(windSpeed.get()) + " kt");

    boost::optional<lcmeteo::TYPE_WIND_DIRECTION> windDirection = mapMeteoNow[airport].getWindDirection();
    if(windDirection.is_initialized())
        ui->leWindDirectionForecast->setText(QString::number(windDirection.get()) + " º");


    boost::optional<lcmeteo::TYPE_GUST_SPEED> gustSpeed = mapMeteoNow[airport].getGustSpeed();
    if(gustSpeed.is_initialized())
        ui->leGustSpeedForecast->setText(QString::number(gustSpeed.get()));

    boost::optional<lcmeteo::TYPE_GUST_DIRECTION> gustDirection = mapMeteoNow[airport].getGustDirection();
    if(gustDirection.is_initialized())
        ui->leGustDirectionForecast->setText(QString::number(gustDirection.get()) + " º");


    boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE> airTemp = mapMeteoNow[airport].getAirTemperature();
    if(airTemp.is_initialized())
        ui->leAirTemperatureForecast->setText(QString::number(airTemp.get()) + " ºC");

    boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE> dewPoint = mapMeteoNow[airport].getDewPointTemperature();
    if(dewPoint.is_initialized())
        ui->leDewPointForecast->setText(QString::number(dewPoint.get()) + " ºC");


    boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY> horVisibility = mapMeteoNow[airport].getHorizontalVisibility();
    if(horVisibility.is_initialized())
        ui->leHorizontalVForecast->setText(QString::number(horVisibility.get()) + " m");

    boost::optional<lcmeteo::TYPE_QNH> qnh = mapMeteoNow[airport].getQnh();
    if(qnh.is_initialized())
        ui->leQNHForecast->setText(QString::number(qnh.get()));

    boost::optional<lcmeteo::TYPE_CLOUD_BASE> cloudBase = mapMeteoNow[airport].getCloudbase();
    if(cloudBase.is_initialized())
        ui->leCloudBaseForecast->setText(QString::number(cloudBase.get()) + " ft");


    ui->leSignificantWeatherForecast->setText(QString::fromStdString(mapMeteoNow[airport].getSignificantWeather()));

    ui->leWetnessForecast->setText(QString::fromStdString(mapMeteoNow[airport].getWetness()));

    boost::optional<int> lvpAct = mapMeteoNow[airport].getLvpActivation(); // lvp_Activation == boolean
        if(lvpAct.is_initialized())
            ui->leLVPActivation->setText(QString::number(lvpAct.get()));

    boost::optional<string> reqIlsCat = mapMeteoNow[airport].getRequiredILSCategory();
        if(reqIlsCat.is_initialized())
            ui->leReqILSCat->setText(QString::fromStdString(reqIlsCat.get()));

    ui->cbRunwayAirport->clear();
	for(unsigned int i = 0; i < mapMeteoNow[airport].getRvrperRunway().getRVRPerRunway().size(); i++)
	{
		ui->cbRunwayAirport->addItem(QString::fromStdString(mapMeteoNow[airport].getRvrperRunway().getRVRPerRunway().at(i).getName()));
	}
}

void LpwHmiMeteoForecast::updateMeteoForeMessage(QString airport)
{
	std::vector<LpiMeteoInfo> meteo_infoF = mapMeteoFore[airport];
	QString period;
	ui->cbForecastPeriodFore->clear();
	for(unsigned int i = 0; i < mapMeteoFore[airport].size(); i++)
	{
		period = QString("%1 - %2")
								.arg(QString::fromStdString(
									 LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getStartTimeAndDate(), "%d/%m/%Y %H:%M:%S")))
								.arg(QString::fromStdString(
									 LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getEndTimeAndDate(), "%d/%m/%Y %H:%M:%S")));

		ui->cbForecastPeriodFore->addItem(period);
	}
}

void LpwHmiMeteoForecast::cbRunwayAirportTextChanged(QString runway)
{

	if(ui->rbMeteoNow->isChecked())
	{
		for(unsigned int i = 0; i < mapMeteoNow[airport].getRvrperRunway().size(); i++)
		{
			if(mapMeteoNow[airport].getRvrperRunway().getRVRPerRunway().at(i).getName() == runway.toStdString())
			{
				boost::optional<unsigned int> rvr = mapMeteoNow[airport].getRvrperRunway().getRVRPerRunway().at(i).getRvr();
				if(rvr.is_initialized())
					ui->leRVR->setText(QString::number(rvr.get()) + " m");

				boost::optional<lcmeteo::TYPE_CROSSWIND> crosswind = mapMeteoNow[airport].getRvrperRunway().getRVRPerRunway().at(i).getCrossWind();
				if(crosswind.is_initialized())
					ui->leCrosswind->setText(QString::number(crosswind.get()) + " kt");

				boost::optional<lcmeteo::TYPE_TAILWIND> tailwind = mapMeteoNow[airport].getRvrperRunway().getRVRPerRunway().at(i).getTailWind();
					if(tailwind.is_initialized())
						ui->leTailwind->setText(QString::number(tailwind.get()) + " kt");
			}
		}
	}
	else if(ui->rbMeteoFore->isChecked())
	{
		for(unsigned int i = 0; i < mapMeteoFore[airport].size(); i++)
		{
			for(unsigned int j = 0; j < mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().size(); j++)
			{
				if(mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().at(j).getName() == runway.toStdString())
				{
					boost::optional<unsigned int> rvr = mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().at(j).getRvr();
					if(rvr.is_initialized())
						ui->leRVR->setText(QString::number(rvr.get()) + " m");

					boost::optional<lcmeteo::TYPE_CROSSWIND> crosswind = mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().at(j).getCrossWind();
					if(crosswind.is_initialized())
						ui->leCrosswind->setText(QString::number(crosswind.get()) + " kt");

					boost::optional<lcmeteo::TYPE_TAILWIND> tailwind = mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().at(j).getTailWind();
						if(tailwind.is_initialized())
							ui->leTailwind->setText(QString::number(tailwind.get()) + " kt");
				}
			}
		}
	}

}


void LpwHmiMeteoForecast::cbAirportsListTextChanged(QString airportNew)
{
	airport = airportNew;
	updateMeteoNowMessage(airport);
	updateMeteoForeMessage(airport);
}

void LpwHmiMeteoForecast::cbForecastPeriodForeTextChanged(QString period)
{
	for(unsigned int i = 0; i < mapMeteoFore[airport].size(); i++)
		{
			if(period == QString("%1 - %2")
			        .arg(QString::fromStdString(
			             LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getStartTimeAndDate(), "%d/%m/%Y %H:%M:%S")))
			        .arg(QString::fromStdString(
			             LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getEndTimeAndDate(), "%d/%m/%Y %H:%M:%S"))))
			{
				boost::optional<double> foreProbability = mapMeteoFore[airport].at(i).getProbability();
				if(foreProbability.is_initialized())
					ui->leForecastProb->setText(QString::number(foreProbability.get()) + " %");

				// IOUpdateMeteoInfo::BodyInformation::

				boost::optional<lcmeteo::TYPE_WIND_SPEED> windSpeed = mapMeteoFore[airport].at(i).getWindSpeed();
				if(windSpeed.is_initialized())
					ui->leWindSpeedForecast->setText(QString::number(windSpeed.get()) + " kt");

				boost::optional<lcmeteo::TYPE_WIND_DIRECTION> windDirection = mapMeteoFore[airport].at(i).getWindDirection();
				if(windDirection.is_initialized())
					ui->leWindDirectionForecast->setText(QString::number(windDirection.get()) + " º");


				boost::optional<lcmeteo::TYPE_GUST_SPEED> gustSpeed = mapMeteoFore[airport].at(i).getGustSpeed();
				if(gustSpeed.is_initialized())
					ui->leGustSpeedForecast->setText(QString::number(gustSpeed.get()));

				boost::optional<lcmeteo::TYPE_GUST_DIRECTION> gustDirection = mapMeteoFore[airport].at(i).getGustDirection();
				if(gustDirection.is_initialized())
					ui->leGustDirectionForecast->setText(QString::number(gustDirection.get()) + " º");


				boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE> airTemp = mapMeteoFore[airport].at(i).getAirTemperature();
				if(airTemp.is_initialized())
					ui->leAirTemperatureForecast->setText(QString::number(airTemp.get()) + " ºC");

				boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE> dewPoint = mapMeteoFore[airport].at(i).getDewPointTemperature();
				if(dewPoint.is_initialized())
					ui->leDewPointForecast->setText(QString::number(dewPoint.get()) + " ºC");


				boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY> horVisibility = mapMeteoFore[airport].at(i).getHorizontalVisibility();
				if(horVisibility.is_initialized())
					ui->leHorizontalVForecast->setText(QString::number(horVisibility.get()) + " m");

				boost::optional<lcmeteo::TYPE_QNH> qnh = mapMeteoFore[airport].at(i).getQnh();
				if(qnh.is_initialized())
					ui->leQNHForecast->setText(QString::number(qnh.get()));

				boost::optional<lcmeteo::TYPE_CLOUD_BASE> cloudBase = mapMeteoFore[airport].at(i).getCloudbase();
				if(cloudBase.is_initialized())
					ui->leCloudBaseForecast->setText(QString::number(cloudBase.get()) + " ft");


				ui->leSignificantWeatherForecast->setText(QString::fromStdString(mapMeteoFore[airport].at(i).getSignificantWeather()));

				ui->leWetnessForecast->setText(QString::fromStdString(mapMeteoFore[airport].at(i).getWetness()));

				boost::optional<int> lvpAct = mapMeteoFore[airport].at(i).getLvpActivation(); // lvp_Activation == boolean
					if(lvpAct.is_initialized())
						ui->leLVPActivation->setText(QString::number(lvpAct.get()));

				boost::optional<string> reqIlsCat = mapMeteoFore[airport].at(i).getRequiredILSCategory();
					if(reqIlsCat.is_initialized())
						ui->leReqILSCat->setText(QString::fromStdString(reqIlsCat.get()));

				ui->cbRunwayAirport->clear();
				for(unsigned int j = 0; j < mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().size(); j++)
				{
					ui->cbRunwayAirport->addItem(QString::fromStdString(mapMeteoFore[airport].at(i).getRvrperRunway().getRVRPerRunway().at(j).getName()));
				}
			}
		}

}
