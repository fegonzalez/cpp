// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Wed 08 Aug 14:09:08 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPWHMIKPISTAB_H_
#define LPWHMIKPISTAB_H_

#include <LcgobChartsWidget.h>
#include "LpmodHmiGraphicComplexityModel.h"
#include "LpmodHmiGraphicSimOpsModel.h"
#include "LpmodHmiGraphicTotalMovModel.h"
#include "LpmodHmiGraphicVFRModel.h"

#include <QStandardItemModel>
#include <QWidget>
#include <QFile>
#include <QTextStream>
#include <QDebug>


namespace Ui {
class LpwHmiKpisTab;
}

class LpwHmiKpisTab : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiKpisTab(QWidget *parent = 0);
    ~LpwHmiKpisTab();

public slots:
    void showSimOps();
    void hideSimOps();
    void showInterval();
    void hideInterval();

private:
    Ui::LpwHmiKpisTab *ui;
    LcgobChartsWidget *chartTotalMov;
    LcgobChartsWidget *chartSimMov;
    LcgobChartsWidget *chartComplex;
    LcgobChartsWidget *chartVFR;

    LpmodHmiGraphicComplexityModel *modelComplex;
    LpmodHmiGraphicSimOpsModel *modelSimMov;
    LpmodHmiGraphicTotalMovModel *modelTotalMov;
    LpmodHmiGraphicVFRModel *modelVFR;

};




#endif /* C___SRC_RTP_RTPHMI_LIB_WINDOWS_INC_LPWHMIKPISTAB_H_ */
