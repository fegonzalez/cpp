// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 10 Aug 12:49:16 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpwHmiAirportInfo.h"
#include "ui_rtpairportinfo.h"
#include "LpdComponent.h"

#include "LpaAdaptationManager.h"
#include "LpcfgConfigurationManager.h"
#include "LpsigSignalsHmi.h"

#include <sstream>


LpwHmiAirportInfo::LpwHmiAirportInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiAirportInfo)
{
    ui->setupUi(this);

    connect(ui->cbAirportNameTab, SIGNAL(currentTextChanged(QString)), this,
               SLOT(cbAirportsNameTextChanged(QString)));

    connect(ui->cbAirportNameTab, SIGNAL(currentTextChanged(QString)), &LpsigSignalsHmi::Get(),
                   SLOT(fillMeteoThresholds(QString)));


    LpiResult result;
    LpdComponent::Get().getAdaptationAirportsInfo(parameters, result);
    LpiResult resultMrtm;
    LpdComponent::Get().getAdaptationMrtmInfo(parametersMrtm, resultMrtm);

    for(unsigned int i = 0 ; i < parameters.getAirport().size(); i++)
    {
        mapAirports.insert(QString::fromStdString(parameters.getAirport().at(i).getAirportName()),
                                                  parameters.getAirport().at(i));
    }

    for (unsigned int i = 0; i < parameters.getAirport().size(); i++)
    {
        ui->cbAirportNameTab->addItem(QString::fromStdString(parameters.getAirport().at(i).getAirportName()));
    }

    bold.setBold(true);
    fillMrtmComplexity();
}

void LpwHmiAirportInfo::fillMrtmComplexity()
{
	ui->twMrtmComp->setRowCount(5);
	ui->twMrtmComp->setColumnCount(6);
	ui->twMrtmComp->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->twMrtmComp->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->twMrtmComp->horizontalHeader()->hide();
	ui->twMrtmComp->verticalHeader()->hide();

	ui->twMrtmComp->setSpan(0, 1, 1, 6);
	ui->twMrtmComp->setSpan(0, 0, 2, 1);

	ui->twMrtmComp->setItem(0, 0, new QTableWidgetItem(""));
	ui->twMrtmComp->setItem(1, 0, new QTableWidgetItem(""));
	ui->twMrtmComp->setItem(0, 1, new QTableWidgetItem("MRTM COMPLEXITY"));

	ui->twMrtmComp->setItem(1, 1, new QTableWidgetItem("LOWER THRESHOLD"));
	ui->twMrtmComp->setItem(1, 2, new QTableWidgetItem("UPPER THRESHOLD"));
	ui->twMrtmComp->setItem(1, 3, new QTableWidgetItem("ARR-ARR"));
	ui->twMrtmComp->setItem(1, 4, new QTableWidgetItem("ARR-DEP"));
	ui->twMrtmComp->setItem(1, 5, new QTableWidgetItem("DEP-DEP"));

	ui->twMrtmComp->setItem(2, 0, new QTableWidgetItem("TOTAL MOVEMENTS"));
	ui->twMrtmComp->setItem(2, 1, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getTotalMovMrtmLowerThreshold())));
	ui->twMrtmComp->setItem(2, 2, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getTotalMovMrtmUpperThreshold())));
	ui->twMrtmComp->setItem(2, 3, new QTableWidgetItem("-"));
	ui->twMrtmComp->setItem(2, 4, new QTableWidgetItem("-"));
	ui->twMrtmComp->setItem(2, 5, new QTableWidgetItem("-"));

	ui->twMrtmComp->setItem(3, 0, new QTableWidgetItem("VFR"));
	ui->twMrtmComp->setItem(3, 1, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getVfrMrtmLowerThreshold())));
	ui->twMrtmComp->setItem(3, 2, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getVfrMrtmUpperThreshold())));
	ui->twMrtmComp->setItem(3, 3, new QTableWidgetItem("-"));
	ui->twMrtmComp->setItem(3, 4, new QTableWidgetItem("-"));
	ui->twMrtmComp->setItem(3, 5, new QTableWidgetItem("-"));

	ui->twMrtmComp->setItem(4, 0, new QTableWidgetItem("SIMULTANEOUS\n OPERATIONS"));
	ui->twMrtmComp->setItem(4, 1, new QTableWidgetItem("-"));
	ui->twMrtmComp->setItem(4, 2, new QTableWidgetItem("-"));
	ui->twMrtmComp->setItem(4, 3, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getSimultaneousOpsHour().getComplexityARRARR())));
	ui->twMrtmComp->setItem(4, 4, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getSimultaneousOpsHour().getComplexityARRDEP())));
	ui->twMrtmComp->setItem(4, 5, new QTableWidgetItem(QString::number(parametersMrtm.getWorkloadThresholds().getSimultaneousOpsHour().getComplexityDEPDEP())));

	configTableStyle(ui->twMrtmComp);
	for(int i = 0; i < 2; i++)
	{
		for(int j = 0; j < ui->twMrtmComp->columnCount(); j++)
		{
			if(ui->twMrtmComp->item(i, j) != NULL)
			{
				ui->twMrtmComp->item(i, j)->setBackgroundColor("#C0C0C0");
				ui->twMrtmComp->item(i, j)->setFont(bold);
			}
		}
	}

	for(int i = 0; i < ui->twMrtmComp->rowCount(); i++)
	{
		if(ui->twMrtmComp->item(i, 0) != NULL)
		{
			ui->twMrtmComp->item(i, 0)->setBackgroundColor("#C0C0C0");
			ui->twMrtmComp->item(i, 0)->setFont(bold);
		}
	}

}

void LpwHmiAirportInfo::cbAirportsNameTextChanged(const QString airport)
{
	std::stringstream new_max_tma("");
	new_max_tma << mapAirports[airport].getTmaMaxNominalCapacity()[E_ARR] << " "
				<< mapAirports[airport].getTmaMaxNominalCapacity()[E_DEP] << " "
				<< mapAirports[airport].getTmaMaxNominalCapacity()[E_OVA];
    ui->leTmaMaxNC->setText(QString(new_max_tma.str().c_str()));

	std::stringstream new_max_twy("");
	new_max_twy << mapAirports[airport].getTaxywaysMaxNominalCapacity()[E_ARR] << " "
				<< mapAirports[airport].getTaxywaysMaxNominalCapacity()[E_DEP] << " "
				<< mapAirports[airport].getTaxywaysMaxNominalCapacity()[E_OVA];
    ui->leTaxiMaxNC->setText(QString(new_max_twy.str().c_str()));
    //ui->leTaxiMaxNC->setText(QString::number(mapAirports[airport].getTaxywaysMaxNominalCapacity()[E_ARR]));

    fillAirportComplexity(airport);

    ui->leMaxNCArr->setText(QString::number(mapAirports[airport].getAirportMaxNominal().getArrivalsValue()));
    ui->leMaxNCDep->setText(QString::number(mapAirports[airport].getAirportMaxNominal().getDeparturesValue()));
    ui->leMaxNCOve->setText(QString::number(mapAirports[airport].getAirportMaxNominal().getOverallValue()));

    if(mapAirports[airport].getAirportType() == AirportType::EnumAirportType::AFIS)
        ui->leAirportType->setText("AFIS");
    else if(mapAirports[airport].getAirportType() == AirportType::EnumAirportType::ATS)
           ui->leAirportType->setText("ATS");

    if(mapAirports[airport].getAirportMaxILsCategory() == Max_ILS_Category::EnumMax_ILS_Category::CAT_I)
            ui->leMaxILSC->setText("CAT_I");
    else if(mapAirports[airport].getAirportMaxILsCategory() == Max_ILS_Category::EnumMax_ILS_Category::CAT_II)
                ui->leMaxILSC->setText("CAT_II");
    else if(mapAirports[airport].getAirportMaxILsCategory() == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_A)
                ui->leMaxILSC->setText("CAT_III_A");
    else if(mapAirports[airport].getAirportMaxILsCategory() == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_B)
                ui->leMaxILSC->setText("CAT_III_B");
    else if(mapAirports[airport].getAirportMaxILsCategory() == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_C)
                ui->leMaxILSC->setText("CAT_III_C");
}

void LpwHmiAirportInfo::fillAirportComplexity(QString airport)
{
	ui->twHeaderAirportComp->setRowCount(4);
	ui->twHeaderAirportComp->setColumnCount(3);
	ui->twHeaderAirportComp->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->twHeaderAirportComp->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui->twHeaderAirportComp->horizontalHeader()->hide();
	ui->twHeaderAirportComp->verticalHeader()->hide();

	ui->twHeaderAirportComp->setSpan(0, 1, 1, ui->twHeaderAirportComp->columnCount());
	ui->twHeaderAirportComp->setSpan(0, 0, 2, 1);

	ui->twHeaderAirportComp->setItem(0, 0, new QTableWidgetItem(""));
	ui->twHeaderAirportComp->setItem(0, 1, new QTableWidgetItem("AIRPORT COMPLEXITY"));
	ui->twHeaderAirportComp->setItem(0, 2, new QTableWidgetItem(""));
	ui->twHeaderAirportComp->setItem(1, 0, new QTableWidgetItem(""));
	ui->twHeaderAirportComp->setItem(1, 1, new QTableWidgetItem("LOWER THRESHOLD"));
	ui->twHeaderAirportComp->setItem(1, 2, new QTableWidgetItem("UPPER THRESHOLD"));
	ui->twHeaderAirportComp->setItem(2, 0, new QTableWidgetItem("TOTAL MOVEMENTS"));
	ui->twHeaderAirportComp->setItem(2, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getComplexityThresholds().getTotalMovAirportLowerThreshold())));
	ui->twHeaderAirportComp->setItem(2, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getComplexityThresholds().getTotalMovAirportUpperThreshold())));
	ui->twHeaderAirportComp->setItem(3, 0, new QTableWidgetItem("VFR"));
	ui->twHeaderAirportComp->setItem(3, 1, new QTableWidgetItem(QString::number(mapAirports[airport].getComplexityThresholds().getVfrAirportLowerThreshold())));
	ui->twHeaderAirportComp->setItem(3, 2, new QTableWidgetItem(QString::number(mapAirports[airport].getComplexityThresholds().getVfrAirportUpperThreshold())));

	configTableStyle(ui->twHeaderAirportComp);
	bold.setBold(true);
	for(int i = 0; i < 2; i++)
	{
		for(int j = 0; j < ui->twHeaderAirportComp->columnCount(); j++)
		{
			if(ui->twHeaderAirportComp->item(i, j) != NULL)
			{
				ui->twHeaderAirportComp->item(i, j)->setBackgroundColor("#C0C0C0");
				ui->twHeaderAirportComp->item(i, j)->setFont(bold);
			}
		}
	}

	for(int i = 0; i < ui->twHeaderAirportComp->rowCount(); i++)
	{
		if(ui->twHeaderAirportComp->item(i, 0) != NULL)
		{
			ui->twHeaderAirportComp->item(i, 0)->setBackgroundColor("#C0C0C0");
			ui->twHeaderAirportComp->item(i, 0)->setFont(bold);
		}
	}
}

void LpwHmiAirportInfo::configTableStyle(QTableWidget *table)
{
	font.setPointSize(10);
	for(int i = 0; i < table->rowCount(); i++)
	{
		for(int j = 0; j < table->columnCount(); j++)
		{
			if(table->item(i, j ) != NULL)
			{
				table->item(i, j)->setTextAlignment(Qt::AlignCenter);
				table->item(i, j)->setFont(font);
				table->setEditTriggers(QAbstractItemView::NoEditTriggers);
			}
		}
	}
}

LpwHmiAirportInfo::~LpwHmiAirportInfo()
{
    delete ui;
}
