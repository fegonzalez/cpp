// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Tue 07 Aug 13:01:29 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPWHMIMETEOFORECAST_H_
#define LPWHMIMETEOFORECAST_H_

#include <QWidget>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QString>

#include <LpiMeteoInfo.h>
#include <LpiMeteoInfoHmi.h>
#include <LpdbMeteoNowObservable.h>


namespace Ui {
class LpwHmiMeteoForecast;
}

class LpwHmiMeteoForecast : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiMeteoForecast(QWidget *parent = 0);
    ~LpwHmiMeteoForecast();

public slots:

  ///@todo LpdbMeteoForeObservable const LpiUpdateMeteoList &meteoList =
  ///      LpdbMeteoForeObservable::GetInstance()->getInfo();
  void onUpdateMeteoNow();
  void onUpdateMeteoFore();
  void updateMeteoFields(LpiUpdateMeteoList meteoList, QString meteo);

  void enableComboBox();
    void disableComboBox();

private slots:
    void cbAirportsListTextChanged(QString airport);
    void cbForecastPeriodForeTextChanged(QString period);
    void cbRunwayAirportTextChanged(QString runway);

    void updateMeteoNowMessage(QString);
    void updateMeteoForeMessage(QString);
    void addAirportsComboBox();

private:
    Ui::LpwHmiMeteoForecast *ui;
    LpdbMeteoNowObservable* observable;
    QHash<QString, LpiMeteoInfo> mapMeteoNow; ///@todo optimization THis info is also stored at LpwHmiMeteoSummary.h
    QHash<QString, std::vector<LpiMeteoInfo>> mapMeteoFore;
    QList<QString> listAirport; ///@todo optimization THis info is also stored at LpwHmiMeteoSummary.h
    bool isLoadDataNow = true;
    bool isLoadDataFore = true;
    QString airport;

  ///@todo show forecast information

};

#endif /* C___SRC_RTP_RTPHMI_LIB_WINDOWS_INC_LPWHMIMETEOFORECAST_H_ */
