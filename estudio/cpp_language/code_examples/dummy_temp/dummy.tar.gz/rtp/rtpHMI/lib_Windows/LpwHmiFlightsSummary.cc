#include "LpwHmiFlightsSummary.h"
#include "ui_rtpflightssummary.h"
#include "LpdbDemandObservable.h"
#include "LpwHmiFilterFlightList.h"

#include "LpwHmiFlightsSummary.h"
#include "LpsigSignalsHmi.h"
#include <IOConstant.h>

LpwHmiFlightsSummary::LpwHmiFlightsSummary(QWidget *parent) :
		QWidget(parent), ui(new Ui::LpwHmiFlightsSummary) {
	ui->setupUi(this);
	ui->pbMaxTabFlightPlans->setToolTip("Maximize");

	connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalDemand()), this,
			SLOT(onUpdateTable()));

	connect(ui->pbMaxTabFlightPlans, SIGNAL(clicked()), &LpsigSignalsHmi::Get(),
			SLOT(emitSignalChangeTabToFlightList()));

	ui->tableView->horizontalHeader()->setSectionResizeMode(
			QHeaderView::Stretch);

	proxyAdep = new QSortFilterProxyModel();
	proxyAdep->setFilterKeyColumn(5);
	proxyAdes = new QSortFilterProxyModel();
	proxyAdes->setFilterKeyColumn(9);

	proxyAdep->setSourceModel(&m_model);
	proxyAdes->setSourceModel(proxyAdep);
	ui->tableView->setModel(proxyAdes);
	ui->tableView->setColumnHidden(1, true);
	ui->tableView->setColumnHidden(3, true);
	ui->tableView->setColumnHidden(4, true);
	ui->tableView->setColumnHidden(6, true);
	ui->tableView->setColumnHidden(7, true);
	ui->tableView->setColumnHidden(8, true);

	ui->tableView->show();
}

LpwHmiFlightsSummary::~LpwHmiFlightsSummary() {
	delete ui;
}

void LpwHmiFlightsSummary::onUpdateTable()
{
	LpiHmiDemandList demandList =
			LpdbDemandObservable::GetInstance()->getDemand();

		for (unsigned int i = 0; i < demandList.size(); i++)
		{

			LpiFlightPlanList demand = demandList[i].getFlightPlanList();
			for (unsigned int j= 0; j < demand.size(); j++)
			{
				LpiFlightPlan fp = demand[j];

				airports.append(QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE)));
				airports.append(QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE)));

				QString module, status, callsign, aircraftType, vfrifr, depAerodrome,
				arrAerodrome, etot, itot, eldt;

				callsign = QString::fromStdString(fp.getCallsign().substr(0, IOConst::CALLSIGN_SIZE));
				depAerodrome = QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE));
				arrAerodrome = QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE));

				m_model.append( { module, status, callsign, aircraftType, vfrifr,
					depAerodrome, etot, itot, eldt, arrAerodrome });

			}

		}

		ui->tableView->sortByColumn(2, Qt::SortOrder::AscendingOrder);
		airports.removeDuplicates();
	    airports.sort();
}

void LpwHmiFlightsSummary::on_leFilterADEP_textChanged(const QString &text) {
	proxyAdep->setFilterRegExp(
			QRegExp(text, Qt::CaseInsensitive, QRegExp::FixedString));
}

void LpwHmiFlightsSummary::on_leFilterADES_textChanged(const QString &text) {
	proxyAdes->setFilterRegExp(
			QRegExp(text, Qt::CaseInsensitive, QRegExp::FixedString));
}

void LpwHmiFlightsSummary::on_pbFilterADEP_clicked() {
	getFilteredText(ui->leFilterADEP);
}

void LpwHmiFlightsSummary::on_pbFilterADES_clicked() {
	getFilteredText(ui->leFilterADES);
}

void LpwHmiFlightsSummary::getFilteredText(QLineEdit *lineEdit) {
	LpwHmiFilterFlightList lv(airports);
	lv.exec();
	lineEdit->setText(lv.getText());
}
