#include "LpwHmiFlightsSummary.h"
#include "ui_rtpflightssummary.h"
#include "LpdbDemandObservable.h"
#include "LpwHmiFilterFlightList.h"

#include "LpwHmiFlightsSummary.h"
#include "LpsigSignalsHmi.h"
#include <IOConstant.h>

LpwHmiFlightsSummary::LpwHmiFlightsSummary(QWidget *parent) :
		QWidget(parent), ui(new Ui::LpwHmiFlightsSummary)
{
	ui->setupUi(this);
	ui->pbMaxTabFlightPlans->setToolTip("Maximize");

	connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalDemand()), this,
			SLOT(onUpdateTable()));

	connect(ui->pbMaxTabFlightPlans, SIGNAL(clicked()), &LpsigSignalsHmi::Get(),
			SLOT(emitSignalChangeTabToFlightList()));

	ui->tableView->horizontalHeader()->setSectionResizeMode(
			QHeaderView::Stretch);

	proxyAdep = new QSortFilterProxyModel();
	proxyAdep->setFilterKeyColumn(3);
	proxyAdes = new QSortFilterProxyModel();
	proxyAdes->setFilterKeyColumn(4);

	proxyAdep->setSourceModel(&m_model);
	proxyAdes->setSourceModel(proxyAdep);
	ui->tableView->setModel(proxyAdes);
	ui->tableView->setColumnHidden(1, true);
	ui->tableView->setColumnHidden(6, true);
	ui->tableView->setColumnHidden(7, true);
	ui->tableView->setColumnHidden(8, true);
	ui->tableView->setColumnHidden(9, true);

	ui->tableView->show();
}

LpwHmiFlightsSummary::~LpwHmiFlightsSummary()
{
	delete ui;
}

void LpwHmiFlightsSummary::onUpdateTable()
{
	LpiHmiDemandList demandList =
			LpdbDemandObservable::GetInstance()->getDemand();

		for (unsigned int i = 0; i < demandList.size(); i++)
		{

			LpiFlightPlanList demand = demandList[i].getFlightPlanList();
			for (unsigned int j= 0; j < demand.size(); j++)
			{
				LpiFlightPlan fp = demand[j];

				airports.append(QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE)));
				airports.append(QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE)));

				airportsDep.append(QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE)));
				airportsArr.append(QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE)));

				QString module, operation, callsign, aircraftType, vfrifr, depAerodrome,
				arrAerodrome, eobt, itot, eldt;

				callsign = QString::fromStdString(fp.getCallsign().substr(0, IOConst::CALLSIGN_SIZE));
				depAerodrome = QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE));
				arrAerodrome = QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE));
				eobt = "";

				if(fp.getDepartureTimes().getEobt())
				{
					posix_time::ptime teobt = *(fp.getDepartureTimes().getEobt());
					eobt = QString::fromStdString(to_simple_string(teobt)).split(" ").at(1);
				}
				m_model.append( { module, operation, callsign, depAerodrome,
					arrAerodrome, eobt, eldt, itot, aircraftType, vfrifr});

			}

		}

		ui->tableView->sortByColumn(2, Qt::SortOrder::AscendingOrder);
		airports.removeDuplicates();
	    airports.sort();

	    airportsArr.removeDuplicates();
		airportsArr.sort();

		airportsDep.removeDuplicates();
		airportsDep.sort();
}

void LpwHmiFlightsSummary::on_leFilterADEP_textChanged(const QString &text)
{
	if(text == "ALL")
		proxyAdep->setFilterRegExp(
			QRegExp("", Qt::CaseInsensitive, QRegExp::FixedString));
	else
		proxyAdep->setFilterRegExp(
			QRegExp(text, Qt::CaseInsensitive, QRegExp::FixedString));
}

void LpwHmiFlightsSummary::on_leFilterADES_textChanged(const QString &text)
{
	if(text == "ALL")
	{
		proxyAdes->setFilterRegExp(
			QRegExp("", Qt::CaseInsensitive, QRegExp::FixedString));
	}
	else
		proxyAdes->setFilterRegExp(
			QRegExp(text, Qt::CaseInsensitive, QRegExp::FixedString));
}

void LpwHmiFlightsSummary::on_pbFilterADEP_clicked()
{
	getFilteredText(ui->leFilterADEP, ADEP);
}

void LpwHmiFlightsSummary::on_pbFilterADES_clicked()
{
	getFilteredText(ui->leFilterADES, ADES);
}

void LpwHmiFlightsSummary::getFilteredText(QLineEdit *lineEdit, flightType type)
{
	if(type == ADEP)
	{
		LpwHmiFilterFlightList lv(airportsDep);
		lv.exec();
		lineEdit->setText(lv.getText());
	}
	else
	{
		LpwHmiFilterFlightList lv(airportsArr);
		lv.exec();
		lineEdit->setText(lv.getText());
	}
}
