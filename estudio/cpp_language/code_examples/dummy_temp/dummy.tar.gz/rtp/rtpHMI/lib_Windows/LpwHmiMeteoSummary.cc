#include "ui_rtpmeteosummary.h"

#include <QList>
#include "LpsigSignalsHmi.h"
#include <LpdbMeteoNowObservable.h>
#include <LpdbMeteoForeObservable.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>

#include <LctimTimeUtils.h>
#include <LcmetConstants.h>

#include <iostream>
#include <vector>
#include <iterator>
#include "LpwHmiMeteoSummary.h"

LpwHmiMeteoSummary::LpwHmiMeteoSummary(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiMeteoSummary)
{
    ui->setupUi(this);
    ui->pbMaxTabMeteo->setToolTip("Maximize");

    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteo()), this,
            SLOT(onUpdateMeteoNow()));
    connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalMeteoFore()), this,
			SLOT(onUpdateMeteoFore()));

    connect(ui->pbMaxTabMeteo, SIGNAL(clicked()), &LpsigSignalsHmi::Get(), SLOT(emitSignalChangeTabToMeteo()));

    observable = LpdbMeteoNowObservable::GetInstance();
}

LpwHmiMeteoSummary::~LpwHmiMeteoSummary()
{
    delete ui;
}

void LpwHmiMeteoSummary::onUpdateMeteoFore()
{
	const LpiUpdateMeteoList &meteoList = LpdbMeteoForeObservable::GetInstance()->getInfo();
	ui->twTabMeteo->setCurrentIndex(1);
	updateFieldsMeteo(meteoList, "fore");
}

void LpwHmiMeteoSummary::updateFieldsMeteo(LpiUpdateMeteoList meteoList, QString meteo)
{
	// May get data form many Airports
	  for (unsigned int i = 0; i < meteoList.size(); i++)
	  {
	    const LpiUpdateMeteo &current_meteo = meteoList[i];
	    std::string aport_id = current_meteo.getAirport();
	    std::vector<LpiMeteoInfo> meteo_info = current_meteo.getMeteoInfo();
	    listAirport.append(QString::fromStdString(aport_id));
	    if(meteo.compare("fore") == 0)
	    	mapMeteoFore.insert(QString::fromStdString(aport_id), meteo_info);
    	else if (meteo.compare("now") == 0)
    		mapMeteoNow.insert(QString::fromStdString(aport_id), meteo_info.at(0));
	  }
	    airport = listAirport[0];
	    listAirport.removeDuplicates();
	    listAirport.sort();
	    addAirportsComboBox();
}

void LpwHmiMeteoSummary::onUpdateMeteoNow()
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
		<< "HMI-WINDOW: New meteo info: "
		<< " ; File: " << __FILE__
		<< " ; fn: " << __func__
		<< " ; line: " << __LINE__
		<< std::endl;
#endif
    const LpiUpdateMeteoList &meteoList = LpdbMeteoNowObservable::GetInstance()->getInfo();
    ui->twTabMeteo->setCurrentIndex(0);
	updateFieldsMeteo(meteoList, "now");
}

void LpwHmiMeteoSummary::addAirportsComboBox(){
    ui->cbAirportsList->clear();
    for(int i = 0; i < listAirport.size(); i++)
        ui->cbAirportsList->addItem(listAirport.at(i));
}

void LpwHmiMeteoSummary::updateMeteoNowMessage(QString airport)
{
	ui->leForecastPeriodReduced->setText(QString("%1 - %2")
        .arg(QString::fromStdString(
             LctimTimeUtils::formatTime(mapMeteoNow[airport].getStartTimeAndDate(), "%d/%m/%Y %H:%M:%S")))
        .arg(QString::fromStdString(
             LctimTimeUtils::formatTime(mapMeteoNow[airport].getEndTimeAndDate(), "%d/%m/%Y %H:%M:%S"))));

    boost::optional<lcmeteo::TYPE_WIND_SPEED> windSpeed = mapMeteoNow[airport].getWindSpeed();
    if(windSpeed.is_initialized())
        ui->leWindSpeedR->setText(QString::number(windSpeed.get()) + " kt");

    boost::optional<lcmeteo::TYPE_WIND_DIRECTION> windDirection = mapMeteoNow[airport].getWindDirection();
    if(windDirection.is_initialized())
        ui->leWindDirection->setText(QString::number(windDirection.get()) + " º");

    boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY> horVisibility = mapMeteoNow[airport].getHorizontalVisibility();
    if(horVisibility.is_initialized())
        ui->leHorizontalV->setText(QString::number(horVisibility.get()) + " m");

    boost::optional<lcmeteo::TYPE_CLOUD_BASE> cloudBase = mapMeteoNow[airport].getCloudbase();
    if(cloudBase.is_initialized())
        ui->leCloudBase->setText(QString::number(cloudBase.get()) + " ft");

    boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE> airTemp = mapMeteoNow[airport].getAirTemperature();
    if(airTemp.is_initialized())
        ui->leAirTemperature->setText(QString::number(airTemp.get()) + " ºC");

    boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE> dewPoint = mapMeteoNow[airport].getDewPointTemperature();
    if(dewPoint.is_initialized())
        ui->leDewPoint->setText(QString::number(dewPoint.get()) + " ºC");

    ui->leWetness->setText(QString::fromStdString(mapMeteoNow[airport].getWetness()));
}


void LpwHmiMeteoSummary::updateMeteoForeMessage(QString airport)
{

		std::vector<LpiMeteoInfo> meteo_infoF = mapMeteoFore[airport];

		QString period;
		ui->cbForecastSummary->clear();
		for(unsigned int i = 0; i < mapMeteoFore[airport].size(); i++)
		{
			period = QString("%1 - %2")
									.arg(QString::fromStdString(
										 LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getStartTimeAndDate(), "%d/%m/%Y %H:%M:%S")))
									.arg(QString::fromStdString(
										 LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getEndTimeAndDate(), "%d/%m/%Y %H:%M:%S")));

			ui->cbForecastSummary->addItem(period);
		}

}

void LpwHmiMeteoSummary::on_cbForecastSummary_currentTextChanged(const QString &arg1)
{
	for(unsigned int i = 0; i < mapMeteoFore[airport].size(); i++)
	{
		if(arg1 == QString("%1 - %2")
		        .arg(QString::fromStdString(
		             LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getStartTimeAndDate(), "%d/%m/%Y %H:%M:%S")))
		        .arg(QString::fromStdString(
		             LctimTimeUtils::formatTime(mapMeteoFore[airport].at(i).getEndTimeAndDate(), "%d/%m/%Y %H:%M:%S"))))
		{
			boost::optional<lcmeteo::TYPE_WIND_SPEED> windSpeed = mapMeteoFore[airport].at(i).getWindSpeed();
			if(windSpeed.is_initialized())
				ui->leWindSpeedRF->setText(QString::number(windSpeed.get()) + " kt");

			boost::optional<lcmeteo::TYPE_WIND_DIRECTION> windDirection = mapMeteoFore[airport].at(i).getWindDirection();
			if(windDirection.is_initialized())
				ui->leWindDirectionF->setText(QString::number(windDirection.get()) + " º");

			boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY> horVisibility = mapMeteoFore[airport].at(i).getHorizontalVisibility();
			if(horVisibility.is_initialized())
				ui->leHorizontalVF->setText(QString::number(horVisibility.get()) + " m");

			boost::optional<lcmeteo::TYPE_CLOUD_BASE> cloudBase = mapMeteoFore[airport].at(i).getCloudbase();
			if(cloudBase.is_initialized())
				ui->leCloudBaseF->setText(QString::number(cloudBase.get()) + " ft");

			boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE> airTemp = mapMeteoFore[airport].at(i).getAirTemperature();
			if(airTemp.is_initialized())
				ui->leAirTemperatureF->setText(QString::number(airTemp.get()) + " ºC");

			boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE> dewPoint = mapMeteoFore[airport].at(i).getDewPointTemperature();
			if(dewPoint.is_initialized())
				ui->leDewPointF->setText(QString::number(dewPoint.get()) + " ºC");

			ui->leWetnessF->setText(QString::fromStdString(mapMeteoFore[airport].at(i).getWetness()));
		}
	}
}


void LpwHmiMeteoSummary::on_cbAirportsList_currentTextChanged(const QString &arg1)
{
	airport = arg1;
    updateMeteoNowMessage(arg1);
    updateMeteoForeMessage(arg1);
}

