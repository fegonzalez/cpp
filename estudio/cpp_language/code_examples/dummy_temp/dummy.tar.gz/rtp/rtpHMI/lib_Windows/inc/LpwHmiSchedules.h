// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Tue 07 Aug 14:24:42 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPWHMISCHEDULES_H_
#define LPWHMISCHEDULES_H_

#include <QWidget>
#include <QFile>
#include <QTextStream>
#include <QDebug>

#include "LpmodHmiActiveScheduleModel.h"
#include "LpmodHmiOptimalScheduleModel.h"
#include "LpmodHmiAirportActiveScheduleModel.h"
#include "LpmodHmiAirportOptimalScheduleModel.h"

namespace Ui {
class LpwHmiSchedules;
}

class LpwHmiSchedules : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiSchedules(QWidget *parent = 0);
    ~LpwHmiSchedules();
    void configActiveSchedule();
    void configOptimalSchedule();

    bool getComplexityChecked();
    bool getSimOpsChecked();
    bool getTotalMovChecked();

public slots:
	void onTableActiveClicked(const QModelIndex &index);
	void onTableOptimalClicked(const QModelIndex &index);
	void checkComplexity();
	void checkSimOps();
	void checkTotalMov();


private:
    Ui::LpwHmiSchedules *ui;

    LpmodHmiActiveScheduleModel *activeScheduleModel;
    LpmodHmiOptimalScheduleModel *optimalScheduleModel;
    LpmodHmiAirportScheduleModel *airportActiveScheduleModel;
    LpmodHmiAirportScheduleModel *airportOptScheduleModel;

};

#endif /* LPWHMISCHEDULES_H_ */
