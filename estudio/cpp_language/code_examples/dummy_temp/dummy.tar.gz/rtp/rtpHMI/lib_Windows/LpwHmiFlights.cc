#include "LpwHmiFlights.h"
#include "LpwHmiFilterFlightList.h"
#include "ui_rtpflights.h"
#include "LpdbDemandObservable.h"
#include "LpsigSignalsHmi.h"
#include <IOConstant.h>

LpwHmiFlights::LpwHmiFlights(QWidget *parent) :
		QWidget(parent), ui(new Ui::LpwHmiFlights)
{
	ui->setupUi(this);

	connect(&LpsigSignalsHmi::Get(), SIGNAL(mySignalDemand()), this,
			SLOT(onUpdateTable()));

	 ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	 proxyAdep = new QSortFilterProxyModel();
	 proxyAdep->setFilterKeyColumn(5);
	 proxyAdes = new QSortFilterProxyModel();
	 proxyAdes->setFilterKeyColumn(9);

	 proxyAdep->setSourceModel(&m_model);
	 proxyAdes->setSourceModel(proxyAdep);
     ui->tableView->setModel(proxyAdes);

     ui->tableView->show();
}

LpwHmiFlights::~LpwHmiFlights()
{
	delete ui;
}

void LpwHmiFlights::onUpdateTable()
{
	LpiHmiDemandList demandList =
				LpdbDemandObservable::GetInstance()->getDemand();

	for (unsigned int i = 0; i < demandList.size(); i++)
	{
		LpiFlightPlanList demand = demandList[i].getFlightPlanList();
		for (unsigned int j= 0; j < demand.size(); j++)
		{
			LpiFlightPlan fp = demand[j];

			airports.append(QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE)));
			airports.append(QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE)));

			QString module, status, callsign, aircraftType, vfrifr, depAerodrome,
			arrAerodrome, etot, itot, eldt;

			callsign = QString::fromStdString(fp.getCallsign().substr(0, IOConst::CALLSIGN_SIZE));
			depAerodrome = QString::fromStdString(fp.getDepartureAerodrome().substr(0, IOConst::AEROD_SIZE));
			arrAerodrome = QString::fromStdString(fp.getArrivalAerodrome().substr(0, IOConst::AEROD_SIZE));
			aircraftType = QString::fromStdString(fp.getAircraftType().substr(0, IOConst::ACTYPE_SIZE));
			eldt = "";
			etot = "";
			itot = "";

			if(fp.getArrivalTimes().getEldt())
            {
                posix_time::ptime teldt = *(fp.getArrivalTimes().getEldt());
                eldt = QString::fromStdString(to_simple_string(teldt));
            }

			if(fp.getDepartureTimes().getEtot())
			{
			    posix_time::ptime tetot = *(fp.getDepartureTimes().getEtot());
			    etot = QString::fromStdString(to_simple_string(tetot));
			}

			if(fp.getDepartureTimes().getItot())
			{
                posix_time::ptime titot = *(fp.getDepartureTimes().getItot());
                itot = QString::fromStdString(to_simple_string(titot));
            }

			m_model.append( { module, status, callsign, aircraftType, vfrifr,
					depAerodrome, etot, itot, eldt, arrAerodrome });
		}
	}
	ui->tableView->sortByColumn(0, Qt::SortOrder::AscendingOrder);
    airports.removeDuplicates();
    airports.sort();

}

void LpwHmiFlights::on_leFilterADEP_textChanged(const QString &text)
{
    proxyAdep->setFilterRegExp(QRegExp(text, Qt::CaseInsensitive, QRegExp::FixedString));
}

void LpwHmiFlights::on_leFilterADES_textChanged(const QString &text)
{
    proxyAdes->setFilterRegExp(QRegExp(text, Qt::CaseInsensitive, QRegExp::FixedString));
}

void LpwHmiFlights::on_pbFilterADEP_clicked()
{
	getFilteredText(ui->leFilterADEP);
}

void LpwHmiFlights::on_pbFilterADES_clicked()
{
	getFilteredText(ui->leFilterADES);
}

void LpwHmiFlights::getFilteredText(QLineEdit *lineEdit)
{
	LpwHmiFilterFlightList lv(airports);
	lv.exec();
	lineEdit->setText(lv.getText());
}
