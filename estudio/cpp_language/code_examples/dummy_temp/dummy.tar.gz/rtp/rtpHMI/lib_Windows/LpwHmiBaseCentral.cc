#include "LpwHmiBaseCentral.h"
#include "ui_rtpbasecentral.h"

LpwHmiBaseCentral::LpwHmiBaseCentral(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LpwHmiBaseCentral)
{
    ui->setupUi(this);

}

LpwHmiBaseCentral::~LpwHmiBaseCentral()
{
    delete ui;
}
