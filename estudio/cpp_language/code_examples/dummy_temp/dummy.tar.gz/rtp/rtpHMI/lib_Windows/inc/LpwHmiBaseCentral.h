#ifndef LPWHMIBASECENTRAL_H
#define LPWHMIBASECENTRAL_H

#include <QWidget>

namespace Ui {
class LpwHmiBaseCentral;
}

class LpwHmiBaseCentral : public QWidget
{
    Q_OBJECT

public:
    explicit LpwHmiBaseCentral(QWidget *parent = 0);
    ~LpwHmiBaseCentral();


private:
    Ui::LpwHmiBaseCentral *ui;


};

#endif // LPWHMIBASECENTRAL_H
