// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 25 Jun 09:14:02 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpcfgConfigurationCoreParameters.h"
#include <LplcTypeConstants.h>

bool LpcfgConfigurationCoreParameters::isDoubleEqual(double x, int y, double roundingError)
{
   return (std::abs(x - static_cast<double>(y)) < roundingError);
}


void LpcfgConfigurationCoreParameters::convert2ConfigurationCoreParam(const CoreParameters::ParametersElement & parameters,
                                                            LpiConfigurationCoreParameters   & output)
{

    if(parameters().timeParameters().minutesSubinterval() != 10 &&
          parameters().timeParameters().minutesSubinterval() != 15 &&
          parameters().timeParameters().minutesSubinterval() != 20 &&
          parameters().timeParameters().minutesSubinterval() != 30 &&
          parameters().timeParameters().minutesSubinterval() != 60)
    {
       std::cerr << "[ERROR]: Please, check the format of the configuration file "
		 << rtp_constants::FILENAME_RTP_CORE_PARAMETERS << std::endl;                                        
       std::cerr << "[ERROR]: minutesSubinterval parameter is not correct" << std::endl;
       exit(EXIT_FAILURE);
    }


    if ((parameters().timeParameters().minutesFrozen() %
             parameters().timeParameters().minutesSubinterval() != 0) ||
             (parameters().timeParameters().minutesFrozen() >
             60 * parameters().timeParameters().hoursWindow()))
    {
       std::cerr << "[ERROR]: Please, check the format of the configuration file "
                 << rtp_constants::FILENAME_RTP_CORE_PARAMETERS << std::endl;
       std::cerr << "[ERROR]: minutesFrozen parameter is not correct" << std::endl;
       exit(EXIT_FAILURE);
    }

    if ((parameters().timeParameters().minutesFrozenForClock() %
            parameters().timeParameters().minutesSubinterval() != 0) ||
           (parameters().timeParameters().minutesFrozenForClock() < 0) ||
           (parameters().timeParameters().minutesFrozenForClock() >
            60 * parameters().timeParameters().hoursWindow()))
    {
       std::cerr << "[ERROR]: Please, check the format of the configuration file "
                 << rtp_constants::FILENAME_RTP_CORE_PARAMETERS << std::endl;
       std::cerr << "[ERROR]: minutesFrozenForClock parameter is not correct" << std::endl;
       exit(EXIT_FAILURE);
    }


    LpiTimeParameters tim;
    tim.setHoursWindow(parameters().timeParameters().hoursWindow());
    tim.setMinutesSubinterval(parameters().timeParameters().minutesSubinterval());
    tim.setMinutesFrozen(parameters().timeParameters().minutesFrozen());
    tim.setMinutesFrozenForClock(parameters().timeParameters().minutesFrozenForClock());

    output.setTimeParameters(tim);

    output.setFpExpirationTime(parameters().fpExpirationTime());

    Ponderation pond;
    pond.setWeightComplexity(parameters().transitionWeightPonderation().weightComplexity());
    pond.setWeightStability(parameters().transitionWeightPonderation().weightStability());
    pond.setWeightPreferentialAllocation(parameters().transitionWeightPonderation().weightPreferentialAllocation());
    pond.setWeightSelectMinMrtm(parameters().transitionWeightPonderation().weightSelectMinMrtm());
    pond.setWeightBalance(parameters().transitionWeightPonderation().weightBalance());
    output.setPonderationParameters(pond);

    PonderationAirports airports;
    airports.setWeightLVP(parameters().complexityWeightPonderationAirports().weightLVP());
    airports.setWeightIce(parameters().complexityWeightPonderationAirports().weightIce());
    airports.setWeightTotalMovAirport(parameters().complexityWeightPonderationAirports().weightTotalMovAirport());
    airports.setWeightVfrAirport(parameters().complexityWeightPonderationAirports().weightVfrAirport());
    output.setComplexityWeightPonderationAirports(airports);

    PonderationMrtm mrtm;
    mrtm.setWeightComplexityAirports(parameters().complexityWeightPonderationMrtm().weightComplexityAirports());
    mrtm.setWeightSimultaneousMov(parameters().complexityWeightPonderationMrtm().weightSimultaneousMov());
    mrtm.setWeightTotalMovMrtm(parameters().complexityWeightPonderationMrtm().weightTotalMovMrtm());
    mrtm.setWeightVfrMrtm(parameters().complexityWeightPonderationMrtm().weightVfrMrtm());
    output.setComplexityWeightPonderationMrtm(mrtm);

    PonderationSimMov simMov;
    simMov.setWeightMean(parameters().complexityWeightPonderationSimMov().weightMean());
    simMov.setWeightNumSimMov(parameters().complexityWeightPonderationSimMov().weightNumSimMov());
    output.setComplexityWeightPonderationSimMov(simMov);

    output.setAlternaticaAllocation(parameters().alternativeAllocationsExpirationHours());

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
			<< "\n " << output << std::endl;
#endif
}
