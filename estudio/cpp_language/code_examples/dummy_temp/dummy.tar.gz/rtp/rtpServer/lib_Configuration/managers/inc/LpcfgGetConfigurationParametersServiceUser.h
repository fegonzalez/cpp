/*
 * LpcfgGetConfigurationParametersServiceUser.h
 *
 */

#ifndef LPCFGGETCONFIGURATIONPARAMETERSSERVICEUSER_H_
#define LPCFGGETCONFIGURATIONPARAMETERSSERVICEUSER_H_

#include <LpiIServiceUsers.h>
#include <daortp_parameters_xsd.h>
#include <LpcfgConfigurationParameters.h>

class LpcfgGetConfigurationParametersServiceUser : public LpiIGetConfigurationParametersSrvUser
{
public:
   LpcfgGetConfigurationParametersServiceUser() {}

   /**
    * Inicializa la lectura del fichero XML que contiene la informacion de configuracion
    * @param name es el nombre del fichero XML
    */
   void init(const std::string & name)
   {
      this->_parameters.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug() << "Initialized File: " << name << std::endl;
#endif

      LpdComponent::Get().delegateUser(*this);
   }

   /**
    * Servicio usado para volcar la informacion leida del XML a los tipos internos
    * @param request es la peticion del servicio
    * @param reply es la respuesta del servicio
    */
   virtual void use(LpiGetConfigurationParametersReply &reply)
   {
      LpiConfigurationParameters DAORTP_arameters;
      LpcfgConfigurationParameters::convert2ConfigurationParam(this->_parameters, DAORTP_arameters);
      reply.setConfigurationParameters(DAORTP_arameters);
      reply.setResult(LpiResult::E_OK);
   }


private:
   parameters::ParametersElement _parameters;
};


#endif /* LPXFGETCONFIGURATIONPARAMETERSSERVICEUSER_H_ */
