// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 14:21:23 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------


#include "LpcfgConfigurationHmiParameters.h"


bool LpcfgConfigurationHmiParameters::isDoubleEqual(double x, int y, double roundingError)
{
   return (std::abs(x - static_cast<double>(y)) < roundingError);
}


void LpcfgConfigurationHmiParameters::convert2ConfigurationHmiParam(const HmiParameters::RtpHmiParametersElement & parameters,
                                                            LpiConfigurationHmiParameters   & output)
{

    TimeRtpHmiParameters time;
    time.setHoursRtpHmiWindow(parameters().timeRtpHmiParameters().hoursRtpHmiWindow());

    output.setTimeRtpHmiParameters(time);

    GraphicRtpMaxRepresentation graphicMax;
    graphicMax.setGraphicRtpMaxDArr(parameters().graphicRtpMaxRepresentation().graphicRtpMaxDArr());
    graphicMax.setGraphicRtpMaxDDep(parameters().graphicRtpMaxRepresentation().graphicRtpMaxDDep());

    output.setGraphicRtpMaxRepresentation(graphicMax);

    output.setMinRtpIntervalsForScrolling(parameters().minRtpIntervalsForScrolling());

    ColorsRtpHmi colors;
    GraphicRtpColors rtpColors;
    rtpColors.setColorGraphicComplexity(parameters().colorsRtpHmi().graphicRtpColors().colorGraphicComplexity());
    rtpColors.setColorGraphicSimOps(parameters().colorsRtpHmi().graphicRtpColors().colorGraphicSimOps());
    rtpColors.setColorGraphicTotalMov(parameters().colorsRtpHmi().graphicRtpColors().colorGraphicTotalMov());
    rtpColors.setColorGraphicVFR(parameters().colorsRtpHmi().graphicRtpColors().colorGraphicVFR());
    colors.setGraphicRtpColors(rtpColors);

    ModuleColors moduleColors;
    moduleColors.setColorModule1(parameters().colorsRtpHmi().moduleColors().colorModule1());
    moduleColors.setColorModule2(parameters().colorsRtpHmi().moduleColors().colorModule2());
    moduleColors.setColorModule3(parameters().colorsRtpHmi().moduleColors().colorModule3());
    moduleColors.setColorModule4(parameters().colorsRtpHmi().moduleColors().colorModule4());
    moduleColors.setColorModule5(parameters().colorsRtpHmi().moduleColors().colorModule5());
    colors.setModuleColors(moduleColors);

    AlarmColors alarmColors;
    alarmColors.setColorAlarmThreshold(parameters().colorsRtpHmi().alarmColors().colorAlarmThreshold());
    alarmColors.setColorWarningThreshold(parameters().colorsRtpHmi().alarmColors().colorWarningThreshold());
    colors.setAlarmColors(alarmColors);

    output.setColorsRtpHmi(colors);

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
			<< "\n " << output << std::endl;
#endif

}

