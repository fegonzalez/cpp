// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 14:25:20 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCFGCONFIGURATIONCOREPARAMETERS_H_
#define LPCFGCONFIGURATIONCOREPARAMETERS_H_

#include <LpiConfigurationCoreParameters.h>
#include <daortp_coreparameters_xsd.h>
#include <LclogStream.h>

class LpcfgConfigurationCoreParameters
{
   public:
      static void convert2ConfigurationCoreParam(const CoreParameters::ParametersElement &parameters,
                                             LpiConfigurationCoreParameters  &output);
   protected:
      static bool isDoubleEqual(double x, int y, double roundingError = 0.0001);
};




#endif  /*LPCFGCONFIGURATIONCOREPARAMETERS_H_ */
