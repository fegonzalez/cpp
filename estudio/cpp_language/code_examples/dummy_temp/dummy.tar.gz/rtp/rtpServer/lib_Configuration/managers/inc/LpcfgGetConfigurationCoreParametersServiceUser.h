// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 14:22:13 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCFGGETCONFIGURATIONCOREPARAMETERSSERVICEUSER_H_
#define LPCFGGETCONFIGURATIONCOREPARAMETERSSERVICEUSER_H_


#include <LpiIServiceUsers.h>
#include <daortp_coreparameters_xsd.h>
#include <LpcfgConfigurationCoreParameters.h>

class LpcfgGetConfigurationCoreParametersServiceUser : public LpiIGetConfigurationCoreParametersSrvUser
{
public:
   LpcfgGetConfigurationCoreParametersServiceUser() {}

   /**
    * Inicializa la lectura del fichero XML que contiene la informacion de configuracion
    * @param name es el nombre del fichero XML
    */
   void init(const std::string & name)
   {
      this->_coreparameters.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP_HMI).debug() << "Initialized File: " << name << std::endl;
#endif

      LpdComponent::Get().delegateUser(*this);
   }

   /**
    * Servicio usado para volcar la informacion leida del XML a los tipos internos
    * @param request es la peticion del servicio
    * @param reply es la respuesta del servicio
    */
   virtual void use(LpiGetConfigurationCoreParametersReply &reply)
   {

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP_HMI).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif
      LpiConfigurationCoreParameters coreparam;
      LpcfgConfigurationCoreParameters::convert2ConfigurationCoreParam(this->_coreparameters, coreparam);
      reply.setConfigurationCoreParameters(coreparam);
      reply.setResult(LpiResult::E_OK);
   }


private:
   CoreParameters::ParametersElement _coreparameters;
};


#endif /* LPCFGGETCONFIGURATIONCOREPARAMETERSSERVICEUSER_H_ */
