/*
 * LpcfgConfigurationManager.h
 *
 */

#ifndef LPFCONFIGURATIONMANAGER_H_
#define LPFCONFIGURATIONMANAGER_H_

#include <LplcTypeConstants.h>
#include <LpcfgGetConfigurationCoreParametersServiceUser.h>
#include <LpcfgGetConfigurationHmiParametersServiceUser.h>
#include <LpaAdaptationManager.h>
#include <boost/shared_ptr.hpp>

class LpcfgConfigurationManager
{

public:
   static LpcfgConfigurationManager & Get(void)
   {
      static LpcfgConfigurationManager manager;
      return manager;
   }

   void initialise(void)
   {
     const std::string COREFILE = 
       std::string(rtp_constants::CFGDIR_CONFIG + "/" + 
		   rtp_constants::FILENAME_RTP_CORE_PARAMETERS);


     const std::string HMIFILE = 
       std::string(rtp_constants::CFGDIR_CONFIG + "/" +
		   rtp_constants::FILENAME_RTP_HMI_PARAMETERS);

      try
      {
	_getConfigurationCoreParametersServiceUser->init(COREFILE);
      }
         catch(std::exception& ex)
      {
         std::cerr << "[ERROR]: Please, check the configuration file "
                   << COREFILE << std::endl;
         std::cerr << "[ERROR]: " << ex.what() << std::endl;
         exit(EXIT_FAILURE);
      }

      try
      {
         _getConfigurationHmiParametersServiceUser->init(HMIFILE);
      }
      catch(std::exception& ex)
      {
         std::cerr << "[ERROR]: Please, check the configuration file "
                   << HMIFILE << std::endl;
         std::cerr << "[ERROR]: " << ex.what() << std::endl;
         exit(EXIT_FAILURE);
      }

   }

private:
   LpcfgConfigurationManager ():
      _getConfigurationCoreParametersServiceUser(new LpcfgGetConfigurationCoreParametersServiceUser()),
      _getConfigurationHmiParametersServiceUser(new LpcfgGetConfigurationHmiParametersServiceUser())
   {}

   boost::shared_ptr<LpcfgGetConfigurationCoreParametersServiceUser>
                                                 _getConfigurationCoreParametersServiceUser;
   boost::shared_ptr<LpcfgGetConfigurationHmiParametersServiceUser>
                                                 _getConfigurationHmiParametersServiceUser;
};



#endif /* LPFCONFIGURATIONMANAGER_H_ */

