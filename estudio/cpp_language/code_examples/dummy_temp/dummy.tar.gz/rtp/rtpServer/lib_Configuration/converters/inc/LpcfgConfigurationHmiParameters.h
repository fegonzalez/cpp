// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 14:19:30 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCFGCONFIGURATIONHMIPARAMETERS_H_
#define LPCFGCONFIGURATIONHMIPARAMETERS_H_


#include <LpiConfigurationHmiParameters.h>
#include <daortp_hmiparameters_xsd.h>
#include <LclogStream.h>

class LpcfgConfigurationHmiParameters
{
   public:
      static void convert2ConfigurationHmiParam(const HmiParameters::RtpHmiParametersElement &parameters,
                                             LpiConfigurationHmiParameters  &output);
   protected:
      static bool isDoubleEqual(double x, int y, double roundingError = 0.0001);
};



#endif /* LPCFGCONFIGURATIONHMIPARAMETERS_H_ */
