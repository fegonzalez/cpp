/**@file LpdbAirportComplexityTimedData.h
 * 
 * complexity per interval data for a concrete airport.
 */

#ifndef LPDBAIRPORTCOMPLEXITYTIMEDDATA_H_
#define LPDBAIRPORTCOMPLEXITYTIMEDDATA_H_

#include <LcuBase.h>
#include <LplcTypeConstants.h>
#include <iosfwd>


class LpdbAirportComplexityTimedData
{

public:

  LpdbAirportComplexityTimedData() = default;
  LpdbAirportComplexityTimedData(const LpdbAirportComplexityTimedData & source) = default;
  LpdbAirportComplexityTimedData & operator= (const LpdbAirportComplexityTimedData & source) = default;
  virtual ~LpdbAirportComplexityTimedData() {};

  rtp_constants::TYPE_COMPLEXITY getComplexity() const
    { return the_complexity;}
  
  void setComplexity(const rtp_constants::TYPE_COMPLEXITY &new_val)
  {
    the_complexity = lib_base::limit(new_val,
			 rtp_constants::MIN_COMPLEXITY_VALUE,
			 rtp_constants::MAX_COMPLEXITY_VALUE);
  }

  void initComplexity()
  { the_complexity = rtp_constants::DEFAULT_COMPLEXITY_VALUE; }

 protected:

  ///param the_complexity; range: [0-1]
  rtp_constants::TYPE_COMPLEXITY the_complexity =
    rtp_constants::DEFAULT_COMPLEXITY_VALUE;
};

std::ostream& operator<<(std::ostream &os,const LpdbAirportComplexityTimedData &);


#endif /* LPDBRUNWAYSYSTEMTIMEDDATA_H_ */
