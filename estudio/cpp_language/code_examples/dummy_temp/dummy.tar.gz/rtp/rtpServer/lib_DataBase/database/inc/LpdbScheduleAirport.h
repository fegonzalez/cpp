/**@file LpdbScheduleAirport.h
 *
 * Airport information included in a schedule-module of a schedule. 
 * 
 *
 */

#ifndef LPDB_SCHEDULE_AIRPORT_H_
#define LPDB_SCHEDULE_AIRPORT_H_


#include <LpdbCommon.h>

#include <iosfwd>

class AirportSch;


/******************************************************************************/
/**@class LpdbScheduleAirport

   @brief Airports-in-LpdbScheduleModule table. Modules are created
   dynamically after every schedule is calculated, so are the embedded
   airports; therefore << set >> and/or << add >> methods are
   meaningless.

*/
/******************************************************************************/
class LpdbScheduleAirport
{
  friend std::ostream& operator<<(std::ostream &os, 
				  const LpdbScheduleAirport &data);


 public:

  explicit LpdbScheduleAirport (const AirportSch & source);
  LpdbScheduleAirport() = default;
  LpdbScheduleAirport(const LpdbScheduleAirport & source) = default;
  LpdbScheduleAirport & operator= (const LpdbScheduleAirport & source) = default;
  ~LpdbScheduleAirport() {}


  KEY_AIRPORT_ID getId()const { return the_id; }



 protected:

  /**@param the_id: identifier of a valid LpdbAirport stored in the data base.

     @warning The LpdbAirport objects are managed off this class.

   */
  KEY_AIRPORT_ID the_id;


  /**@param the_ancillary_data: rest of parameters related to a
     schedule module's airport.

     @todo To be coded when the KPI task is performed.

   */
  //  AirportModuleAncillaryData the_ancillary_data;

};


#endif /* LPDB_SCHEDULE_AIRPORT_H_ */

