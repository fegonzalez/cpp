/*
 * LpdbRunwaySystemRunway.cc
 *
 *  Created on: 17/02/2014
 *      Author: mbegega
 */

#include "LpdbRunwaySystemRunway.h"


LpdbRunwaySystemRunway::LpdbRunwaySystemRunway()
: r_id(""),
  r_use(OperationType::E_INVALID_RWY_OPERATION_TYPE),
  r_max_capacity(0),
  r_timeLine()
{
}


LpdbRunwaySystemRunway::LpdbRunwaySystemRunway(string id, OperationType::Enum use, int max_capacity)
: r_id(id),
  r_use(use),
  r_max_capacity(max_capacity),
  r_timeLine()
{
}


LpdbRunwaySystemRunway::LpdbRunwaySystemRunway(const LpdbRunwaySystemRunway & source)
: r_id(source.r_id),
  r_use(source.r_use),
  r_max_capacity(source.r_max_capacity),
  r_timeLine(source.r_timeLine)
{
}


LpdbRunwaySystemRunway & LpdbRunwaySystemRunway::operator= (const LpdbRunwaySystemRunway & source)
{
   if (this != &source)
   {
      r_id  = source.r_id;
      r_use = source.r_use;
      r_max_capacity = source.r_max_capacity;
      r_timeLine = source.r_timeLine;
   }

   return *this;
}


bool LpdbRunwaySystemRunway::has_data(const string& interval_name)
{
   return r_timeLine.hasData(interval_name);
}


LpdbRunwaySystemRunwayTimedData& LpdbRunwaySystemRunway::operator [](const string& interval_name)
{
   return r_timeLine[interval_name];
}


void LpdbRunwaySystemRunway::init(const LpiTimeParameters & parameters,
                           boost::posix_time::ptime begin_timestamp)
{
   r_timeLine.initialize(parameters.getMinutesSubinterval(),
                         parameters.getHoursWindow(),
                         parameters.getMinutesFrozen(),
                         begin_timestamp
                         );

   //Populates whole timeline with default data
   r_timeLine.fill();

}


void LpdbRunwaySystemRunway::forwardTimeline()
{
   r_timeLine.forward();

   //Creates default element in newly created interval
   r_timeLine.createElement(r_timeLine.getLastInterval());
}


TimeLine<LpdbRunwaySystemRunwayTimedData> LpdbRunwaySystemRunway::getTimeLine() const
{
   return r_timeLine;
}
