/*
 * LpdbRunway.cc
 *
 */

#include <iostream>
#include <cmath>
#include "LpdbRunway.h"
// #include "LpiIncreasingReductionFunction.h"
// #include "LpiDecreasingReductionFunction.h"
//#include "LpdbDataBase.h"


LpdbRunway::LpdbRunway(const RunwaysAirports & rwy):
  the_id(rwy.getRunwayName()),
  the_data(rwy)
{
}


//==============================================================================

// LpdbRunway::LpdbRunway() : the_id(""),
//                          r_timeLine(),
//                          r_runwayThreshold1(),
//                          r_runwayThreshold2(),
//                          r_catIls(LpiMaxILSCategory::E_NO_ILS),
//                          r_max_nominal_capacity(),
//                          r_max_capacity_scheduled(),
//                          r_crosswind_capacity_reduction_scheduled(),
//                          r_non_availability_scheduled(),
//                          r_crosswind_wet_conds_upper_threshold(),
//                          r_crosswind_dry_conds_upper_threshold()
// {
// }



//
//LpdbRunway::LpdbRunway(const LpiAdaptationRunway & rwy)
//: the_id(rwy.getNameRunway()),
//  r_catIls(rwy.getILSRunway()),
//  r_max_nominal_capacity(),
//  r_max_capacity_scheduled(),
//  r_crosswind_capacity_reduction_scheduled(),
//  r_non_availability_scheduled(),
//  r_crosswind_wet_conds_upper_threshold(),
//  r_crosswind_dry_conds_upper_threshold()
//{
//   r_runwayThreshold1.push_back(rwy.getThreshold1Latitude ());
//   r_runwayThreshold1.push_back(rwy.getThreshold1Longitude());
//   r_runwayThreshold2.push_back(rwy.getThreshold2Latitude ());
//   r_runwayThreshold2.push_back(rwy.getThreshold2Longitude());
//
//   r_max_nominal_capacity[E_ARR]= rwy.getCapacityNominal().getarrivalsValue();
//   r_max_nominal_capacity[E_DEP]= rwy.getCapacityNominal().getdeparturesValue();
//   r_max_nominal_capacity[E_OVA]= rwy.getCapacityNominal().getoverallValue();
//}


// LpdbRunway::LpdbRunway(const LpdbRunway& source)
// : the_id(source.the_id),
//   r_timeLine(source.r_timeLine),
//   r_runwayThreshold1(source.r_runwayThreshold1),
//   r_runwayThreshold2(source.r_runwayThreshold2),
//   r_catIls(source.r_catIls),
//   r_max_nominal_capacity(source.r_max_nominal_capacity),
//   r_max_capacity_scheduled(source.r_max_capacity_scheduled),
//   r_crosswind_capacity_reduction_scheduled(source.r_crosswind_capacity_reduction_scheduled),
//   r_non_availability_scheduled(source.r_non_availability_scheduled),
//   r_crosswind_wet_conds_upper_threshold(source.r_crosswind_wet_conds_upper_threshold),
//   r_crosswind_dry_conds_upper_threshold(source.r_crosswind_dry_conds_upper_threshold)
// {
// }


// LpdbRunway& LpdbRunway::operator =(const LpdbRunway& source)
// {
//    if (this != &source)
//    {
//       the_id = source.the_id;
//       r_timeLine = source.r_timeLine;
//       r_runwayThreshold1 = source.r_runwayThreshold1;
//       r_runwayThreshold2 = source.r_runwayThreshold2;
//       r_catIls = source.r_catIls;
//       r_max_nominal_capacity = source.r_max_nominal_capacity;
//       r_max_capacity_scheduled = source.r_max_capacity_scheduled;
//       r_crosswind_capacity_reduction_scheduled = source.r_crosswind_capacity_reduction_scheduled;
//       r_non_availability_scheduled = source.r_non_availability_scheduled;
//       r_crosswind_wet_conds_upper_threshold = source.r_crosswind_wet_conds_upper_threshold;
//       r_crosswind_dry_conds_upper_threshold = source.r_crosswind_dry_conds_upper_threshold;
//    }
//    return *this;
// }


// bool LpdbRunway::has_data(const string& interval_name)
// {
//    return r_timeLine.hasData(interval_name);
// }


// LpdbRunwayTimedData& LpdbRunway::operator [](const string& interval_name)
// {
//    return r_timeLine[interval_name];
// }


// void LpdbRunway::init(const LpiTimeParameters & parameters,
//                      boost::posix_time::ptime begin_timestamp)
// {
//    r_timeLine.initialize(parameters.getMinutesSubinterval(),
//                          parameters.getHoursWindow(),
//                          parameters.getMinutesFrozen(),
//                          begin_timestamp
//                          );

//    //Populates whole timeline with default data
//    r_timeLine.fill();
// }


// void LpdbRunway::forwardTimeline()
// {
//    r_timeLine.forward();

//    //Creates default element in newly created interval
//    r_timeLine.createElement(r_timeLine.getLastInterval());
// }


// std::string LpdbRunway::getRunwayId() const
// {
//    return the_id;
// }


// void LpdbRunway::setRunwayId(std::string id)
// {
//    the_id= id;
// }


// vector<LpiADOVector<int> > LpdbRunway::getCrosswindCapacityReductionScheduled() const
// {
//    return r_crosswind_capacity_reduction_scheduled;
// }


// void LpdbRunway::setCrosswindCapacityReductionScheduled(
//       vector<LpiADOVector<int> > crosswindCapacityReductionScheduled)
// {
//    r_crosswind_capacity_reduction_scheduled = crosswindCapacityReductionScheduled;
// }

// vector<LpiADOVector<double> > LpdbRunway::getManualCapacityReductionScheduled() const
// {
//    return r_manual_capacity_reduction_scheduled;
// }


// void LpdbRunway::setManualCapacityReductionScheduled(
//       vector<LpiADOVector<double> > manualCapacityReductionScheduled)
// {
//    r_manual_capacity_reduction_scheduled = manualCapacityReductionScheduled;
// }


// int LpdbRunway::getCrosswindDryCondsUpperThreshold() const
// {
//    return r_crosswind_dry_conds_upper_threshold;
// }


// void LpdbRunway::setCrosswindDryCondsUpperThreshold(int crosswindDryCondsUpperThreshold)
// {
//    r_crosswind_dry_conds_upper_threshold = crosswindDryCondsUpperThreshold;
// }


// int LpdbRunway::getCrosswindWetCondsUpperThreshold() const
// {
//    return r_crosswind_wet_conds_upper_threshold;
// }


// void LpdbRunway::setCrosswindWetCondsUpperThreshold(int crosswindWetCondsUpperThreshold)
// {
//    r_crosswind_wet_conds_upper_threshold = crosswindWetCondsUpperThreshold;
// }


// IntervalMap LpdbRunway::getMaxCapacityScheduled() const
// {
//    return r_max_capacity_scheduled;
// }


// void LpdbRunway::setMaxCapacityScheduled(IntervalMap maxCapacityScheduled)
// {
//    r_max_capacity_scheduled = maxCapacityScheduled;
// }


// LpiADOVector<int> LpdbRunway::getMaxNominalCapacity() const
// {
//    return r_max_nominal_capacity;
// }


// void LpdbRunway::setMaxNominalCapacity(LpiADOVector<int> maxNominalCapacity)
// {
//    r_max_nominal_capacity = maxNominalCapacity;
// }


// vector<bool> LpdbRunway::getNonAvailabilityScheduled() const
// {
//    return r_non_availability_scheduled;
// }


// void LpdbRunway::setNonAvailabilityScheduled(vector<bool> nonAvailabilityScheduled)
// {
//    r_non_availability_scheduled = nonAvailabilityScheduled;
// }


// vector<float> LpdbRunway::getRunwayThreshold1 () const
// {
//    return r_runwayThreshold1;
// }


// vector<float> LpdbRunway::getRunwayThreshold2 () const
// {
//    return r_runwayThreshold2;
// }


// LpiMaxILSCategory::LpiEnumCatILS LpdbRunway::getCatIls() const
// {
//    return r_catIls;
// }


// std::string LpdbRunway::getIntervalsShortFormat () const
// {
//    return r_timeLine.getIntervalsShortFormat();
// }


// std::string LpdbRunway::getIntervalsAsString () const
// {
//    return r_timeLine.getAsString();
// }


// void LpdbRunway::calculateMaximumCapacity()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string interval_name, intervals)
//    {
//       calculateMaximumCapacity(interval_name);
//    }
// }


// void LpdbRunway::calculateMaximumCapacity (string interval_name)
// {
//    int N1 = r_timeLine.getNumberOfIntervalsPerHour();

//    LpiADOVector<int> interval_capacity;
//    interval_capacity[E_ARR] = static_cast<int>(std::floor((r_max_nominal_capacity[E_ARR] / static_cast<double>(N1)) + 0.5));
//    interval_capacity[E_DEP] = static_cast<int>(std::floor((r_max_nominal_capacity[E_DEP] / static_cast<double>(N1)) + 0.5));
//    interval_capacity[E_OVA] = static_cast<int>(std::floor((r_max_nominal_capacity[E_OVA] / static_cast<double>(N1)) + 0.5));

//    r_timeLine[interval_name].setMaxCapacity(interval_capacity);
//    r_timeLine[interval_name].setMaxCapacityNominalInterval(interval_capacity);
//    r_max_capacity_scheduled[interval_name]= interval_capacity;
// }


// void LpdbRunway::calculateNoOperationCapacity()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string interval_name, intervals)
//    {
//       calculateNoOperationCapacity(interval_name);
//    }
// }


// void LpdbRunway::calculateNoOperationCapacity(string interval_name)
// {
//    LpiADOVector<int> interval_capacity(0, 0, 0);

//    if (has_data(interval_name))
//    {
//          LpdbRunwayTimedData & data = r_timeLine[interval_name];
//          bool is_non_available = data.isNonAvailability();

//          if (is_non_available)
//          {
//             r_timeLine[interval_name].setMaxCapacity(interval_capacity);
//             r_max_capacity_scheduled[interval_name]= interval_capacity;
//          }
//    }
// }


// void LpdbRunway::calculateManualReductionCapacity()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string interval_name, intervals)
//    {
//       calculateManualReductionCapacity(interval_name);
//    }
// }


// void LpdbRunway::calculateManualReductionCapacity(string interval_name)
// {
//    if (has_data(interval_name))
//    {
//          LpiADOVector<int> max_capacity = r_timeLine[interval_name].getMaxCapacity();
//          LpiADOVector<double> reduction = r_timeLine[interval_name].getManualCapacityReduction();

//          if (r_timeLine[interval_name].hasManualReduction())
//          {
//             //Apply reduction
//             LpiADOVector<int> max_cap;

//             for (int i = 0; i <= E_OVA; ++i)
//             {
//                max_cap[i] = static_cast<int>(reduction[i]);
//             }

//             r_timeLine[interval_name].setMaxCapacity(max_cap);
//             r_max_capacity_scheduled[interval_name]= max_cap;
//         }
//    }
// }


// void LpdbRunway::calculateILSCapacity()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string interval_name, intervals)
//    {
//       calculateILSCapacity(interval_name);
//    }
// }


// void LpdbRunway::calculateILSCapacity(string interval_name)
// {
//    TimeLine<LpdbMeteoTimedData> & meteo_forecast = LpdbDataBase::Get().getMeteoForecast();

//    if (has_data(interval_name) && !r_timeLine[interval_name].hasManualReduction())
//    {
//       boost::optional<string> required_category;

//       if (meteo_forecast.hasData(interval_name))
//       {
//          required_category= meteo_forecast[interval_name].getIlsCategory();
//       }

//       if (required_category)
//       {
//          LpiMaxILSCategory::LpiEnumCatILS category = getCatIls();

//          if (category < LpiMaxILSCategory::getEnumFromString(*required_category))
//          {
//             LpiADOVector<int> interval_capacity = r_timeLine[interval_name].getMaxCapacity();
//             interval_capacity[E_ARR] = 0;
//             interval_capacity[E_OVA] = 0;

//             r_timeLine[interval_name].setMaxCapacity(interval_capacity);
//             r_max_capacity_scheduled[interval_name]= interval_capacity;
//          }
//       }
//    }
// }
// 


// void LpdbRunway::applyMeteoReductions (LpiADOVector<double> crosswind_reduction,
//                                       LpiADOVector<double> tailwind_reduction,
//                                       LpiADOVector<double> visibility_reduction,
//                                       LpiAdaptationMeteothresholdList thresholds)
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string interval_name, intervals)
//    {
//       applyMeteoReductions(interval_name,
//                            crosswind_reduction,
//                            tailwind_reduction,
//                            visibility_reduction,
//                            thresholds);
//    }
// }


// void LpdbRunway::applyMeteoReductions (string interval_name,
//                                       LpiADOVector<double> crosswind_reduction,
//                                       LpiADOVector<double> tailwind_reduction,
//                                       LpiADOVector<double> visibility_reduction,
//                                       LpiAdaptationMeteothresholdList thresholds)
// {

//    if (!r_timeLine[interval_name].hasManualReduction())
//    {
//       TimeLine<LpdbMeteoTimedData> & meteorological_timeline = LpdbDataBase::Get().getMeteoForecast();

//       string runwayId = getRunwayId();

//       // if no meteorological info available, let's assume:
//       // dry conditions, no crosswind, no tailwind

//       boost::optional<string> wetness;
//       string wetness_value = "DRY";

//       boost::optional<float> crosswind;
//       double crosswind_value = 0.0;

//       boost::optional<float> tailwind;
//       double tailwind_value = 0.0;

//       boost::optional<float> visibility;
//       double visibility_value = 0.0;

//       //Calculated capacities
//       LpiADOVector<double> cw;
//       LpiADOVector<double> tw;
//       LpiADOVector<double> vb;
//       LpiADOVector<double> met;


//       if (meteorological_timeline.hasData(interval_name) && has_data(interval_name))
//       {
//          map<string, LpiRunwayMeteoInfo> runways_meteo_info = meteorological_timeline[interval_name].getRwyMeteoInfo();

//          if (runways_meteo_info.count(runwayId) > 0)
//          {
//             crosswind_value = runways_meteo_info[runwayId].getCrosswind();
//             tailwind_value  = runways_meteo_info[runwayId].getTailwind();
//          }

//          wetness = meteorological_timeline[interval_name].getWetness();

//          if (wetness)
//          {
//             wetness_value = *wetness;

//             MeteoThreshold crosswind_threshold = LpiThresholdUtils::getCrosswindThresholds (the_id,
//                                                                                             wetness_value,
//                                                                                             thresholds);

//             cw = applyReduction (crosswind_value, crosswind_reduction, crosswind_threshold);

//             r_timeLine[interval_name].setCrosswindCapacityReduction(cw);


//             MeteoThreshold tailwind_threshold = LpiThresholdUtils::getTailwindThresholds (the_id,
//                                                                                              wetness_value,
//                                                                                              thresholds);

//             tw = applyReduction (tailwind_value, tailwind_reduction, tailwind_threshold);

//             r_timeLine[interval_name].setTailwindCapacityReduction(tw);

//             visibility = meteorological_timeline[interval_name].getHorizontalVisibility();

//             if (visibility)
//             {
//                visibility_value = *visibility;

//                MeteoThreshold visibility_threshold = LpiThresholdUtils::getHorizontalVisibilityThresholds (the_id,
//                                                                                                         thresholds);

//                vb = applyDecreasingReduction (visibility_value, visibility_reduction, visibility_threshold);

//                r_timeLine[interval_name].setVisibilityCapacityReduction(vb);
//             }

//          }

//          //Calculate total meteo reduction

//          met[E_ARR] = std::max(std::max(cw[E_ARR], tw[E_ARR]), vb[E_ARR]);
//          met[E_DEP] = std::max(std::max(cw[E_DEP], tw[E_DEP]), vb[E_DEP]);
//          met[E_OVA] = std::max(std::max(cw[E_OVA], tw[E_OVA]), vb[E_OVA]);

//          r_timeLine[interval_name].setMetCapacityReduction(met);

//          LpiADOVector<int> rwy_nominal= r_timeLine[interval_name].getMaxCapacity();
//          LpiADOVector<int> max_cap;

//          double arrivals_capacity = static_cast<double>(rwy_nominal[E_ARR]) * (1.0 - met[E_ARR]);

//          //fract_part = modf(arrivals_capacity, &int_part);
//          max_cap[E_ARR]= static_cast<int>(arrivals_capacity);

//          double departures_capacity = static_cast<double>(rwy_nominal[E_DEP]) * (1.0 - met[E_DEP]);

//          //fract_part = modf(departures_capacity, &int_part);
//          max_cap[E_DEP]= static_cast<int>(departures_capacity);

//          double overall_capacity = static_cast<double>(rwy_nominal[E_OVA]) * (1.0 - met[E_OVA]);

//          //fract_part = modf(overall_capacity, &int_part);
//          max_cap[E_OVA]= static_cast<int>(overall_capacity);

//          r_timeLine[interval_name].setMaxCapacity(max_cap);
//       }
//    }

// }



// LpiADOVector<double> LpdbRunway::applyReduction (double value,
//                                                 LpiADOVector<double> reduction,
//                                                 MeteoThreshold threshold)
// {
//    LpiIncreasingReductionFunction functionA(threshold.getlowerThreshold(),
//                                             threshold.getupperThreshold(),
//                                             reduction[E_ARR]);

//    LpiIncreasingReductionFunction functionD(threshold.getlowerThreshold(),
//                                             threshold.getupperThreshold(),
//                                             reduction[E_DEP]);

//    LpiIncreasingReductionFunction functionO(threshold.getlowerThreshold(),
//                                             threshold.getupperThreshold(),
//                                             reduction[E_OVA]);


//    LpiADOVector<double> result(0.0, 0.0, 0.0);

//    result[E_ARR] = functionA(value);
//    result[E_DEP] = functionD(value);
//    result[E_OVA] = functionO(value);


//    return result;
// }



// LpiADOVector<double> LpdbRunway::applyDecreasingReduction (double value,
//                                                           LpiADOVector<double> reduction,
//                                                           MeteoThreshold threshold)
// {
//    LpiDecreasingReductionFunction functionA(threshold.getlowerThreshold(),
//                                             threshold.getupperThreshold(),
//                                             reduction[E_ARR]);

//    LpiDecreasingReductionFunction functionD(threshold.getlowerThreshold(),
//                                             threshold.getupperThreshold(),
//                                             reduction[E_DEP]);

//    LpiDecreasingReductionFunction functionO(threshold.getlowerThreshold(),
//                                             threshold.getupperThreshold(),
//                                             reduction[E_OVA]);


//    LpiADOVector<double> result(0.0, 0.0, 0.0);

//    result[E_ARR] = functionA(value);
//    result[E_DEP] = functionD(value);
//    result[E_OVA] = functionO(value);


//    return result;
// }



// void LpdbRunway::applyManualReduction (boost::posix_time::ptime startTime,
//                                       boost::posix_time::ptime endTime,
//                                       LpiADOVector<double> reduction)
// {
//    vector<string> affected_intervals = r_timeLine.getIntervalsInRange(startTime, endTime);

//    int numberOfIntervals = LpdbDataBase::Get().getGlobalParameters().getNumberOfIntervalsInHour();

//    BOOST_FOREACH(string ti, affected_intervals)
//    {
//       if(r_timeLine.hasData(ti))
//       {
//          LpiADOVector<int> maxRunwayCapacity = r_timeLine[ti].getMaxCapacity();

//          LpiADOVector<double> appliedReduction = reduction;

//          for (int j = E_ARR; j <= E_OVA; ++j)
//          {
//             if (reduction[j] >= 0.0)
//             {
//                double reduction_applied = (numberOfIntervals > 0) ? (reduction[j] / numberOfIntervals) : 0.0;

//                appliedReduction[j] = reduction_applied;
//             }
//             else
//             {
//                appliedReduction[j] = static_cast<double>(maxRunwayCapacity[j]);
//             }
//          }

//          r_timeLine[ti].setManualCapacityReduction(appliedReduction);

//          std::string tmp_a(ti);
//          boost::erase_all(tmp_a, "t");
//          unsigned int t_number= boost::lexical_cast<unsigned int>(tmp_a);

//          r_manual_capacity_reduction_scheduled[t_number]= reduction;
//       }
//    }
// }



// void LpdbRunway::applyNoOperationReduction (boost::posix_time::ptime startTime,
//                                            boost::posix_time::ptime endTime,
//                                            LpiClosureReason::LpiEnum reason,
//                                            bool nonAvailability)
// {
//    vector<string> affected_intervals = r_timeLine.getIntervalsInRange(startTime, endTime);

//    BOOST_FOREACH(string ti, affected_intervals)
//    {
//       if(r_timeLine.hasData(ti))
//       {
//          r_timeLine[ti].setNonAvailability(nonAvailability, reason);

//          std::string tmp_a(ti);
//          boost::erase_all(tmp_a, "t");
//          unsigned int t_number= boost::lexical_cast<unsigned int>(tmp_a);

//          r_non_availability_scheduled[t_number] = nonAvailability;
//       }
//    }
// }


// void LpdbRunway::resetOperationalStateInputs()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string ti, intervals)
//    {
//       if (r_timeLine.hasData(ti))
//       {
//          LpiADOVector<double> default_reduction(0.0, 0.0, 0.0);
//          r_timeLine[ti].setManualCapacityReduction(default_reduction);

//          r_timeLine[ti].setNonAvailability(false, LpiClosureReason::E_OTHER);
//       }
//    }
// }


// void LpdbRunway::resetNonAvailabilities()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string ti, intervals)
//    {
//       if (r_timeLine.hasData(ti))
//       {
//          r_timeLine[ti].setNonAvailability(false, LpiClosureReason::E_OTHER);
//       }
//    }
// }


// void LpdbRunway::resetManualReductions()
// {
//    vector<string> intervals = r_timeLine.getAllIntervalIds();

//    BOOST_FOREACH(string ti, intervals)
//    {
//       if (r_timeLine.hasData(ti))
//       {
//          LpiADOVector<double> default_reduction(0.0, 0.0, 0.0);
//          r_timeLine[ti].setManualCapacityReduction(default_reduction);
//       }
//    }
// }


// vector<string> LpdbRunway::getAllIntervalIds() const
// {
//    return r_timeLine.getAllIntervalIds();
// }


// optional<TimeInterval> LpdbRunway::getIntervalParameters(string interval)
// {
//    if (r_timeLine.exists(interval))
//    {
//       return r_timeLine.getTimeInterval(interval);
//    }
//    else
//    {
//       return boost::none;
//    }
// }


// string LpdbRunway::getMaxCapacityScheduledAsString() const
// {
//    typedef const IntervalMap::value_type data_pair;

//    std::stringstream out_stream;

//    out_stream << "[MAX_CAP_SCHED: {";

//    BOOST_FOREACH(data_pair & element, r_max_capacity_scheduled)
//    {
//       out_stream << '(' << element.second << ')';
//    }
//    out_stream << "}]";

//    return out_stream.str();
// }


// std::ostream& operator<<(std::ostream & os, const LpdbRunway & rwy)
// {
//    return os << "[ID: " << rwy.getRunwayId() << " | MX_CAP_NOM: "
//              << rwy.getMaxNominalCapacity()  << " | ILS: "
//              << rwy.getCatIls() << " | TML: " << std::endl
//              << rwy.getIntervalsAsString()
//              << rwy.getMaxCapacityScheduledAsString()
//              << ']';
// }
