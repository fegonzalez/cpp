/*
 * LpdbAlertsGenerator.h
 *
 *  Created on: 24/10/2014
 *      Author: mbegega
 */

#ifndef _LPB_ALERTS_GENERATOR_H_
#define _LPB_ALERTS_GENERATOR_H_

#include <string>

#include "LpiADO.h"
#include "LpiWarningsAlerts.h"

class Alert;
class Improvement;

class LpdbAlertsGenerator
{
   public:
//
//   static Warnings_alerts generateAlerts(int intervalsPerHour,
//                                         LpiADO warningThreshold,
//                                         LpiADO alarmThreshold,
//                                         std::string comparisonOperation,
//                                         LpiADOVector<double> kpi);
//
//   static Warnings_alerts generateAlerts(int intervalsPerHour,
//                                         LpiADO warningThreshold,
//                                         LpiADO alarmThreshold,
//                                         std::string comparisonOperation,
//                                         LpiADOVector<int> kpi);
//
//   static Warnings_alerts generateAlerts(std::string interval,
//                                         int intervalsPerHour,
//                                         LpiADO warningThreshold,
//                                         LpiADO alarmThreshold,
//                                         std::string comparisonOperation,
//                                         LpiADOVector<double> kpi);
//
//   static Warnings_alerts generateAlerts(std::string interval,
//                                         int intervalsPerHour,
//                                         LpiADO warningThreshold,
//                                         LpiADO alarmThreshold,
//                                         std::string comparisonOperation,
//                                         LpiADOVector<int> kpi);
//
//   static Warnings_alerts generateAlerts(std::string interval,
//                                         OperationType::Enum runway_usage,
//                                         LpiADOVector<double> demand_forecast,
//                                         int intervalsPerHour,
//                                         LpiADO warningThreshold,
//                                         LpiADO alarmThreshold,
//                                         std::string comparisonOperation,
//                                         LpiADOVector<int> kpi);
//
//   static Warnings_alerts generateAlerts(std::string interval,
//                                         OperationType::Enum runway_usage,
//                                         LpiADOVector<double> demand_forecast,
//                                         int intervalsPerHour,
//                                         LpiADO warningThreshold,
//                                         LpiADO alarmThreshold,
//                                         std::string comparisonOperation,
//                                         LpiADOVector<double> kpi);
//
//   static Warnings_alerts generateAlertsForComparison(int intervalsPerHour,
//                                                      LpiADO warningThreshold,
//                                                      LpiADO alarmThreshold,
//                                                      std::string comparisonOperation,
//                                                      LpiADOVector<double> kpi);
//
//   static Warnings_alerts generateAlertsForComparison(int intervalsPerHour,
//                                                      LpiADO warningThreshold,
//                                                      LpiADO alarmThreshold,
//                                                      std::string comparisonOperation,
//                                                      LpiADOVector<int> kpi);
//
//   static Warnings_alerts GenerateAlertsForComparison(int intervalsPerHour,
//                                                      const Alert & thresholds,
//                                                      const Improvement & positiveThresholds,
//                                                      LpiADOVector<double> kpi);
//
//   static Warnings_alerts GenerateAlertsForComparison(int intervalsPerHour,
//                                                      const Alert & thresholds,
//                                                      const Improvement & positiveThresholds,
//                                                      LpiADOVector<int> kpi);
//
//   private:
//
//   static Warnings_alerts::LpiEnum CheckImprovements(int intervalsPerHour,
//                                                     float slightThreshold,
//                                                     float improvementThreshold,
//                                                     std::string comparison,
//                                                     double kpi);

};

#endif /* LPBALERTSGENERATOR_H_ */
