/*
 * LpdbRunway.h
 *                         {1,2}
 *    LpdbAirport  <>-----------> LpdbRunway
 */

#ifndef LPDBRUNWAY_H_
#define LPDBRUNWAY_H_

#include <LpiAdaptationAirportsInfo.h>
#include <LpdbDataTable.h>

#include <string>
#include <vector>
#include <map>
#include <boost/optional.hpp>


/* typedef std::map<std::string, LpiADOVector<int>, compareByIntervalNumber> IntervalMap; */


class LpdbRunway
{
   public:
      LpdbRunway(const RunwaysAirports & rwy);
      virtual ~LpdbRunway() {}
      LpdbRunway() = default;
      LpdbRunway(const LpdbRunway & source) = default;
      LpdbRunway & operator= (const LpdbRunway & source) = default;
      
      std::string getId() const { return the_id; }     
      const RunwaysAirports & getData() const { return the_data; }

      /* //Check if has data associated to one given interval name */
      /* bool has_data(const string & interval_name); */

      /* //Get one element from internal timeline for modification */
      /* LpdbRunwayTimedData & operator[] (const string & interval_name); */

      /* //stablish timeline */
      /* void init(const LpiTimeParameters & parameters, */
      /*           boost::posix_time::ptime begin_timestamp); */

      /* //Forwards internal timeline in one interval */
      /* void forwardTimeline(); */

      /* //Getters and setters */

      /* std::string getRunwayId() const; */
      /* void setRunwayId(std::string id); */

      /* std::vector<LpiADOVector<int> > getCrosswindCapacityReductionScheduled() const; */
      /* void setCrosswindCapacityReductionScheduled( */
      /* std::vector<LpiADOVector<int> > crosswindCapacityReductionScheduled); */

      /* std::vector<LpiADOVector<double> > getManualCapacityReductionScheduled() const; */
      /* void setManualCapacityReductionScheduled( */
      /* std::vector<LpiADOVector<double> > manualCapacityReductionScheduled); */

      /* int getCrosswindDryCondsUpperThreshold() const; */
      /* void setCrosswindDryCondsUpperThreshold(int crosswindDryCondsUpperThreshold); */

      /* int getCrosswindWetCondsUpperThreshold() const; */
      /* void setCrosswindWetCondsUpperThreshold(int crosswindWetCondsUpperThreshold); */

      /* IntervalMap getMaxCapacityScheduled() const; */
      /* void setMaxCapacityScheduled( */
      /* IntervalMap maxCapacityScheduled); */

      /* LpiADOVector<int> getMaxNominalCapacity() const; */
      /* void setMaxNominalCapacity(LpiADOVector<int> maxNominalCapacity); */

      /* std::vector<bool> getNonAvailabilityScheduled() const; */
      /* void setNonAvailabilityScheduled(std::vector<bool> nonAvailabilityScheduled); */

      /* std::vector<float> getRunwayThreshold1 () const; */
      /* std::vector<float> getRunwayThreshold2 () const; */
      /* LpiMaxILSCategory::LpiEnumCatILS getCatIls() const; */


      /* string getIntervalsShortFormat () const; */
      /* string getIntervalsAsString () const; */

      /* //Capacity methods */
      /* void calculateMaximumCapacity (); */
      /* void calculateMaximumCapacity (string interval_name); */

      /* void calculateNoOperationCapacity(); */
      /* void calculateNoOperationCapacity(string interval_name); */

      /* void calculateManualReductionCapacity(); */
      /* void calculateManualReductionCapacity(string interval_name); */

      /* void calculateILSCapacity(); */
      /* void calculateILSCapacity(string interval_name); */
//
//      void applyMeteoReductions (LpiADOVector<double> crosswind_reduction,
//                                 LpiADOVector<double> tailwind_reduction,
//                                 LpiADOVector<double> visibility_reduction,
//                                 LpiAdaptationMeteothresholdList thresholds);
//
//      void applyMeteoReductions (string interval_name,
//                                 LpiADOVector<double> crosswind_reduction,
//                                 LpiADOVector<double> tailwind_reduction,
//                                 LpiADOVector<double> visibility_reduction,
//                                 LpiAdaptationMeteothresholdList thresholds);
//
//      void applyManualReduction (boost::posix_time::ptime startTime,
//                                 boost::posix_time::ptime endTime,
//                                 LpiADOVector<double> reduction);
//
//      void applyNoOperationReduction (boost::posix_time::ptime startTime,
//                                      boost::posix_time::ptime endTime,
//                                      LpiClosureReason::LpiEnum reason,
//                                      bool nonAvailability);

      //For logging purposes
      /* string getMaxCapacityScheduledAsString() const; */

      /* void resetOperationalStateInputs(); */
      /* void resetNonAvailabilities(); */
      /* void resetManualReductions (); */

      /* std::vector<string> getAllIntervalIds() const; */
      /* boost::optional<TimeInterval> getIntervalParameters(string interval); */


      
   protected:

      
//
//      LpiADOVector<double> applyReduction (double value,
//                                           LpiADOVector<double> reduction,
//                                           MeteoThreshold threshold);
//
//      LpiADOVector<double> applyDecreasingReduction (double value,
//                                           LpiADOVector<double> reduction,
//                                           MeteoThreshold threshold);
//

     // data area
      
      std::string the_id = {""};
      RunwaysAirports the_data;

    // TimeLine<LpdbRunwayTimedData> r_timeLine;

    
//      std::vector<float> r_runwayThreshold1;
//      std::vector<float> r_runwayThreshold2;
//
//      LpiMaxILSCategory::LpiEnumCatILS r_catIls;
//
//      LpiADOVector<int> r_max_nominal_capacity;
//
//      //std::vector<LpiADOVector<int> > r_max_capacity_scheduled;
//      IntervalMap r_max_capacity_scheduled;
//      std::vector<LpiADOVector<int> > r_crosswind_capacity_reduction_scheduled;
//      std::vector<LpiADOVector<double> > r_manual_capacity_reduction_scheduled;
//      std::vector<bool> r_non_availability_scheduled;
//
//
//      int r_crosswind_wet_conds_upper_threshold;
//      int r_crosswind_dry_conds_upper_threshold;

};


typedef LpdbDataTable<std::string, LpdbRunway> RunwayTable;

//typedef std::vector<LpdbRunway> RunwayTable;


std::ostream& operator<<(std::ostream &os, const LpdbRunway &rwy);

#endif /* LPDBRUNWAY_H_ */
