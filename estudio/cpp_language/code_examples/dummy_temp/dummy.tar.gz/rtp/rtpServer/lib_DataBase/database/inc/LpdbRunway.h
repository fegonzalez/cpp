/*
 * LpdbRunway.h
 *
* @warning LpdbRunway basada en fichero de RMAN (DAORTP_SmRunway.xml),
*          no en datos RTP (<runway> de file DAORTP_AirportsInfo.xml)​
*
* @todo Transformar para guardar la info de RTP (DAORTP_AirportsInfo.xml))
*
* Ahora usada en LpdbDataBase.h (RunwayTable)
*
 */

#ifndef LPBRUNWAY_H_
#define LPBRUNWAY_H_

#include <string>
#include <vector>
#include <map>
#include <boost/optional.hpp>

#include <LpiADOVector.h>
#include <LctimTimeLine.h>
#include "LpdbRunwayTimedData.h"

#include "LpiTimeParameters.h"
#include "LpiMaxILSCategory.h"
#include "LpiClosureReason.h"

using std::vector;
using std::map;
using boost::optional;

typedef map<string, LpiADOVector<int>, compareByIntervalNumber> IntervalMap;

class LpdbRunway
{
   public:
      LpdbRunway();
      LpdbRunway(std::string id);
//      LpdbRunway(const LpiAdaptationRunway & rwy);

      LpdbRunway(const LpdbRunway & source);

      virtual ~LpdbRunway() {}

      LpdbRunway & operator= (const LpdbRunway & source);

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbRunwayTimedData & operator[] (const string & interval_name);

      //stablish timeline
      void init(const LpiTimeParameters & parameters,
                boost::posix_time::ptime begin_timestamp);

      //Forwards internal timeline in one interval
      void forwardTimeline();

      //Getters and setters

      std::string getRunwayId() const;
      void setRunwayId(std::string id);

      vector<LpiADOVector<int> > getCrosswindCapacityReductionScheduled() const;
      void setCrosswindCapacityReductionScheduled(
      vector<LpiADOVector<int> > crosswindCapacityReductionScheduled);

      vector<LpiADOVector<double> > getManualCapacityReductionScheduled() const;
      void setManualCapacityReductionScheduled(
      vector<LpiADOVector<double> > manualCapacityReductionScheduled);

      int getCrosswindDryCondsUpperThreshold() const;
      void setCrosswindDryCondsUpperThreshold(int crosswindDryCondsUpperThreshold);

      int getCrosswindWetCondsUpperThreshold() const;
      void setCrosswindWetCondsUpperThreshold(int crosswindWetCondsUpperThreshold);

      IntervalMap getMaxCapacityScheduled() const;
      void setMaxCapacityScheduled(
      IntervalMap maxCapacityScheduled);

      LpiADOVector<int> getMaxNominalCapacity() const;
      void setMaxNominalCapacity(LpiADOVector<int> maxNominalCapacity);

      vector<bool> getNonAvailabilityScheduled() const;
      void setNonAvailabilityScheduled(vector<bool> nonAvailabilityScheduled);

      vector<float> getRunwayThreshold1 () const;
      vector<float> getRunwayThreshold2 () const;
      LpiMaxILSCategory::LpiEnumCatILS getCatIls() const;


      string getIntervalsShortFormat () const;
      string getIntervalsAsString () const;

      //Capacity methods
      void calculateMaximumCapacity ();
      void calculateMaximumCapacity (string interval_name);

      void calculateNoOperationCapacity();
      void calculateNoOperationCapacity(string interval_name);

      void calculateManualReductionCapacity();
      void calculateManualReductionCapacity(string interval_name);

      void calculateILSCapacity();
      void calculateILSCapacity(string interval_name);
/*
      void applyMeteoReductions (LpiADOVector<double> crosswind_reduction,
                                 LpiADOVector<double> tailwind_reduction,
                                 LpiADOVector<double> visibility_reduction,
                                 LpiAdaptationMeteothresholdList thresholds);

      void applyMeteoReductions (string interval_name,
                                 LpiADOVector<double> crosswind_reduction,
                                 LpiADOVector<double> tailwind_reduction,
                                 LpiADOVector<double> visibility_reduction,
                                 LpiAdaptationMeteothresholdList thresholds);

      void applyManualReduction (boost::posix_time::ptime startTime,
                                 boost::posix_time::ptime endTime,
                                 LpiADOVector<double> reduction);

      void applyNoOperationReduction (boost::posix_time::ptime startTime,
                                      boost::posix_time::ptime endTime,
                                      LpiClosureReason::LpiEnum reason,
                                      bool nonAvailability);
*/
      //For logging purposes
      string getMaxCapacityScheduledAsString() const;

      void resetOperationalStateInputs();
      void resetNonAvailabilities();
      void resetManualReductions ();

      vector<string> getAllIntervalIds() const;
      optional<TimeInterval> getIntervalParameters(string interval);

   protected:
/*
      LpiADOVector<double> applyReduction (double value,
                                           LpiADOVector<double> reduction,
                                           MeteoThreshold threshold);

      LpiADOVector<double> applyDecreasingReduction (double value,
                                           LpiADOVector<double> reduction,
                                           MeteoThreshold threshold);
*/
   protected:
      std::string   r_runwayId;
      TimeLine<LpdbRunwayTimedData> r_timeLine;

      vector<float> r_runwayThreshold1;
      vector<float> r_runwayThreshold2;

      LpiMaxILSCategory::LpiEnumCatILS r_catIls;

      //Capacities
      LpiADOVector<int> r_max_nominal_capacity;

      //vector<LpiADOVector<int> > r_max_capacity_scheduled;
      IntervalMap r_max_capacity_scheduled;
      vector<LpiADOVector<int> > r_crosswind_capacity_reduction_scheduled;
      vector<LpiADOVector<double> > r_manual_capacity_reduction_scheduled;
      vector<bool> r_non_availability_scheduled;


      int r_crosswind_wet_conds_upper_threshold;
      int r_crosswind_dry_conds_upper_threshold;

};

std::ostream& operator<<(std::ostream &os, const LpdbRunway &rwy);

#endif /* LPBRUNWAY_H_ */
