/*
 * LpdbFPAllocated.h
 *
 *  Created on: 11/12/2013
 *      Author: mbegega
 */

#ifndef LPBFPALLOCATED_H_
#define LPBFPALLOCATED_H_

#include <string>
#include <LpiOperationType.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/optional/optional.hpp>


using namespace boost;

class LpdbFPAllocated
{
   public:
      LpdbFPAllocated();
      LpdbFPAllocated(const std::string & fpKey);

      LpdbFPAllocated(const std::string & fpKey,
                     const std::string & callsign,
                     const std::string & departure,
                     const std::string & arrival,
                     const boost::optional<posix_time::ptime> & eobt);


      LpdbFPAllocated(const LpdbFPAllocated & source);

      virtual ~LpdbFPAllocated() {}

      LpdbFPAllocated & operator= (const LpdbFPAllocated & source);

      //Getters and setters
      std::string getCallsign() const;
      void setCallsign(const std::string & callsign);

      std::string getArrivalAerodrome() const;
      void setArrivalAerodrome(const std::string & arrivalAerodrome);

      std::string getDepartureAerodrome() const;
      void setDepartureAerodrome(const std::string & departureAerodrome);

      LpiOperationType::LpiEnum getOperationType() const
      { return r_operation_type; };

      void setOperationType(LpiOperationType::LpiEnum operation_type)
      { r_operation_type = operation_type; };

      //Returns an unique key/id like: "callsign dep arr"
      std::string getUniqueKey() const;


   protected:

      std::string r_fpKey;

      std::string r_callsign;
      std::string r_departure_aerodrome;
      std::string r_arrival_aerodrome;

      LpiOperationType::LpiEnum  r_operation_type;

      boost::optional<posix_time::ptime> r_eobt;

};


#endif /* LPBFPALLOCATED_H_ */
