/*
 * LpdbRSScheduled.cc
 *
 *  Created on: 12/12/2013
 *      Author: mbegega
 */

#include <boost/foreach.hpp>
#include <string>
#include <set>
#include <limits>
#include <algorithm>
#include "LpdbRwyScheduled.h"
#include "LpdbRSScheduled.h"
//#include "LpdbDataBase.h"


using std::string;
using std::set;
using std::map;


LpdbRSScheduled::LpdbRSScheduled()
: r_runwaySystemId(""),
  r_runways(),
  r_has_mixed_runways(false),
  r_absolute_airport_kpis_previous(),
  r_absolute_airport_kpis(),
  r_number_of_arrival_runways(0),
  r_number_of_departure_runways(0)
{
}


LpdbRSScheduled::LpdbRSScheduled(std::string id)
: r_runwaySystemId(id),
  r_runways(),
  r_has_mixed_runways (false),
  r_absolute_airport_kpis_previous(),
  r_absolute_airport_kpis(),
  r_number_of_arrival_runways(0),
  r_number_of_departure_runways(0)
{
}


LpdbRSScheduled::LpdbRSScheduled(const LpdbRunwaySystem & rs)
{
   r_runwaySystemId = rs.getRunwaySystemId();
   r_has_mixed_runways = rs.hasMixedRunways();

   const map<string, LpdbRunwaySystemRunway> & runways= rs.getRunways();
   typedef const map<string, LpdbRunwaySystemRunway>::value_type value_pair;

   BOOST_FOREACH(value_pair & runway, runways)
   {
      if (r_runways.count(runway.second.getId()) == 0)
      {
         r_runways[runway.second.getId()]= LpdbRwyScheduled(runway.second.getId(), runway.second.getUse());
      }
   }

   r_number_of_arrival_runways = rs.getNumberOfArrivalRunways();
   r_number_of_departure_runways = rs.getNumberOfDepartureRunways();

   r_absolute_airport_kpis_previous = LpdbAirportIntervalKPIs();
   r_absolute_airport_kpis = LpdbAirportIntervalKPIs();
}


LpdbRSScheduled::LpdbRSScheduled(const LpdbRSScheduled & source)
: r_runwaySystemId(source.r_runwaySystemId),
  r_runways(source.r_runways),
  r_has_mixed_runways(source.r_has_mixed_runways),
  r_absolute_airport_kpis_previous(source.r_absolute_airport_kpis_previous),
  r_absolute_airport_kpis(source.r_absolute_airport_kpis),
  r_number_of_arrival_runways(source.r_number_of_arrival_runways),
  r_number_of_departure_runways(source.r_number_of_departure_runways)
{
}


LpdbRSScheduled& LpdbRSScheduled::operator =(const LpdbRSScheduled& source)
{
   if (this != &source)
   {
      r_runwaySystemId= source.r_runwaySystemId;
      r_runways= source.r_runways;
      r_has_mixed_runways = source.r_has_mixed_runways;
      r_absolute_airport_kpis_previous = source.r_absolute_airport_kpis_previous;
      r_absolute_airport_kpis = source.r_absolute_airport_kpis;
      r_number_of_arrival_runways = source.r_number_of_arrival_runways;
      r_number_of_departure_runways = source.r_number_of_departure_runways;
   }

   return *this;
}


std::string LpdbRSScheduled::getRunwaySystemId() const
{
   return r_runwaySystemId;
}


void LpdbRSScheduled::setRunwaySystemId(std::string id)
{
   r_runwaySystemId= id;
}


int LpdbRSScheduled::getNumberOfRunways() const
{
   return r_runways.size();
}


std::map<std::string, LpdbRwyScheduled> LpdbRSScheduled::getRunways() const
{
   return r_runways;
}


std::map<std::string, LpdbRwyScheduled> & LpdbRSScheduled::getRunways()
{
   return r_runways;
}


void LpdbRSScheduled::addRunway(const std::string& runway_id)
{
   if (r_runways.count(runway_id) == 0)
   {
      r_runways[runway_id]= LpdbRwyScheduled(runway_id);
   }
}


void LpdbRSScheduled::deleteRunway(const std::string& runway_id)
{
   if (r_runways.count(runway_id) == 0)
   {
      r_runways.erase(runway_id);
   }
}


void LpdbRSScheduled::addRunways(const std::map<std::string, LpdbRunwaySystemRunway> & rwys)
{
   typedef const map<std::string, LpdbRunwaySystemRunway>::value_type value_pair;

   BOOST_FOREACH(value_pair & runway, rwys)
   {
      std::string id_runway = runway.first;

      if (r_runways.count(id_runway) == 0)
      {
         r_runways[id_runway]= LpdbRwyScheduled(id_runway, runway.second.getUse());
      }
   }
}


bool LpdbRSScheduled::exists (const std::string & runway_id)
{
   return (r_runways.count(runway_id) > 0);
}

LpdbRwyScheduled & LpdbRSScheduled::operator[] (const std::string & runway_id)
{
   return r_runways[runway_id];
}


bool LpdbRSScheduled::hasMixedRunways () const
{
   return r_has_mixed_runways;
}


void LpdbRSScheduled::calculateMaximumCapacities(string interval)
{
   /*LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   if (rsTable.exists(r_runwaySystemId))
   {
      LpdbRunwaySystem & rs = rsTable[r_runwaySystemId];

      map<string, LpdbRunwaySystemRunway> rs_runways = rs.getRunways();
      typedef map<string, LpdbRunwaySystemRunway>::value_type value_pair;

      BOOST_FOREACH(value_pair & data, rs_runways)
      {
         if (data.second.has_data(interval))
         {
            LpiADOVector<int> rs_rwy_max_cap = data.second[interval].getMaxCapacity();

            if (r_runways.count(data.first) > 0)
            {
               OperationType::Enum use = r_runways[data.first].getUsage();

               LpdbRwyScheduled rwy;

               switch(use)
               {
                  case OperationType::E_ARRIVALS:

                     rwy = r_runways[data.first];

                     rwy.setMaxCapacity(rs_rwy_max_cap[E_ARR]);
                     rwy.setActualCapacity(rs_rwy_max_cap[E_ARR]);

                     r_runways[data.first] = rwy;

                  break;
                  case OperationType::E_DEPARTURES:

                     rwy = r_runways[data.first];

                     rwy.setMaxCapacity(rs_rwy_max_cap[E_DEP]);
                     rwy.setActualCapacity(rs_rwy_max_cap[E_DEP]);

                     r_runways[data.first] = rwy;

                  break;

                  case OperationType::E_MIXED:

                     rwy = r_runways[data.first];

                     rwy.setMaxCapacity(rs_rwy_max_cap[E_OVA]);
                     rwy.setActualCapacity(rs_rwy_max_cap[E_OVA]);

                     r_runways[data.first] = rwy;

                  break;
                  default:
                  break;
               }
            }
         }
      }
   }*/
}


vector<string> LpdbRSScheduled::getAvailableRunways(int use_type)
{
   vector<string> result;

   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & data, r_runways)
   {
      int capacity = data.second.getActualCapacity();
      OperationType::Enum use = data.second.getUsage();

      bool same_use = false;

      switch (use_type)
      {
         case E_ARR:
            same_use = (use == OperationType::E_ARRIVALS);
         break;

         case E_DEP:
            same_use = (use == OperationType::E_DEPARTURES);
         break;
      }

      if ((capacity > 0) && same_use)
      {
         result.push_back(data.first);
      }
   }

   return result;
}


string LpdbRSScheduled::selectRunwayWithMaxAvailableCap(vector<string> runway_set)
{
   string result;
   int max_capacity = 0;

   for (unsigned int i = 0; i < runway_set.size(); i++)
   {
      string runway_id = runway_set[i];

      if (r_runways.count(runway_id) > 0)
      {
         LpdbRwyScheduled rwy = r_runways[runway_id];

         int capacity = rwy.getActualCapacity();

         if (capacity > max_capacity)
         {
            max_capacity = capacity;
            result = runway_id;
         }
      }
   }

   return result;
}



vector<string> LpdbRSScheduled::getAllRunwaysByUse  (int use_type)
{
   vector<string> result;

   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & data, r_runways)
   {
      OperationType::Enum use = data.second.getUsage();

      bool same_use = false;

      switch (use_type)
      {
         case E_ARR:
            same_use = (use == OperationType::E_ARRIVALS);
         break;

         case E_DEP:
            same_use = (use == OperationType::E_DEPARTURES);
         break;

         case E_OVA:
            same_use = (use == OperationType::E_MIXED);
         break;
      }

      if (same_use)
      {
         result.push_back(data.first);
      }
   }

   return result;
}


vector<string> LpdbRSScheduled::getAllRunwaysIds()
{
   vector<string> result;

   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & data, r_runways)
   {
      result.push_back(data.first);
   }

   return result;
}


string LpdbRSScheduled::selectPreferentialRunway(vector<string> runways,
                                                vector<string> preferential_runways,
                                                LpiOperationType::LpiEnum fp_type)
{
   string result;

   vector<string> ordered_runways = runways;
   std::sort(ordered_runways.begin(), ordered_runways.end());

   vector<string> ordered_preferential = preferential_runways;
   std::sort(ordered_preferential.begin(), ordered_preferential.end());

   vector<string> intersection;

   std::set_intersection(ordered_runways.begin(), ordered_runways.end(),
                         ordered_preferential.begin(), ordered_preferential.end(),
                         back_inserter(intersection));

   for (unsigned int i = 0; i < intersection.size(); i++)
   {
      string runway_id = intersection[i];
      if (exists(runway_id))
      {
         OperationType::Enum usage = r_runways[runway_id].getUsage();

         bool isDeparture = (usage == OperationType::E_DEPARTURES) && (fp_type == LpiOperationType::E_DEPARTURE);
         bool isArrival =   (usage == OperationType::E_ARRIVALS) && (fp_type == LpiOperationType::E_ARRIVAL);
         bool hasCapacityRemaining = r_runways[runway_id].isAvailable();

         if (((usage == OperationType::E_MIXED) || isDeparture || isArrival) && hasCapacityRemaining)
         {
            result = runway_id;
            return result;
         }
      }
   }

   return result;
}


int LpdbRSScheduled::selectNextAllowedRunway(vector<string> runways,
                                            vector<string> not_allowed,
                                            LpiOperationType::LpiEnum fp_type,
                                            int current_runway)
{
   //Protection: if all runways of fp_type are not allowed, return current
   bool areAllNotAllowed = containsAllNotAllowed(runways, not_allowed, fp_type);

   if (areAllNotAllowed)
   {
      return current_runway;
   }

   //Change destination runway of allocation
   int destination_runway = selectNextRunwayByUse(runways, fp_type, current_runway);

   vector<string>::iterator it = std::find(not_allowed.begin(),
                                           not_allowed.end(),
                                           runways[destination_runway]);

   bool isNotAllowed = (it != not_allowed.end());
   while (isNotAllowed)
   {
      destination_runway = selectNextRunwayByUse(runways, fp_type, destination_runway);

      vector<string>::iterator it = std::find(not_allowed.begin(),
                                              not_allowed.end(),
                                              runways[destination_runway]);

      isNotAllowed = (it != not_allowed.end());
   }

   //Check if not allowed, get next
   return destination_runway;
}


int LpdbRSScheduled::selectNextRunwayByUse(vector<string>runways,
                                          LpiOperationType::LpiEnum fp_type,
                                          unsigned int current_runway)
{
   bool same_use = false;

   unsigned int destination_runway = (current_runway == runways.size() - 1)
                            ? 0
                            : current_runway + 1;

   string runway_id = runways[destination_runway];
   //bool hasCapacityRemaining = true;

   if (exists(runway_id))
   {
      OperationType::Enum usage = r_runways[runway_id].getUsage();

      switch (fp_type)
      {
         case LpiOperationType::E_ARRIVAL:
            same_use = ((usage == OperationType::E_ARRIVALS) || (usage == OperationType::E_MIXED));
         break;

         case LpiOperationType::E_DEPARTURE:
            same_use = ((usage == OperationType::E_DEPARTURES) || (usage == OperationType::E_MIXED));
         break;
         case LpiOperationType::E_NONE:
            same_use = false;
         break;
      }

      //hasCapacityRemaining = r_runways[runway_id].isAvailable();
   }

   while (!same_use) //|| (same_use && !hasCapacityRemaining)
   {
      destination_runway = (destination_runway == runways.size() - 1)
                            ? 0
                            : destination_runway + 1;

      runway_id = runways[destination_runway];

      if (exists(runway_id))
      {
         OperationType::Enum usage = r_runways[runway_id].getUsage();

         switch (fp_type)
         {
            case LpiOperationType::E_ARRIVAL:
               same_use = (usage == OperationType::E_ARRIVALS) || (usage == OperationType::E_MIXED);
            break;

            case LpiOperationType::E_DEPARTURE:
               same_use = (usage == OperationType::E_DEPARTURES) || (usage == OperationType::E_MIXED);
            break;

            case LpiOperationType::E_NONE:
               same_use = false;
            break;
         }
      }
   }

   return destination_runway;
}


bool LpdbRSScheduled::containsAllNotAllowed(vector<string>runways,
                                           vector<string>not_allowed,
                                           LpiOperationType::LpiEnum fp_type)
{
   if (not_allowed.size() == 0)
   {
      return false;
   }

   vector<string> ordered_runways;

   //Extract runways of same type of fp
   for (unsigned int i = 0; i < runways.size(); i++)
   {
      string runway_id = runways[i];

      if (exists(runway_id))
      {
         OperationType::Enum usage = r_runways[runway_id].getUsage();

         bool isDeparture = (usage == OperationType::E_DEPARTURES) && (fp_type == LpiOperationType::E_DEPARTURE);
         bool isArrival = (usage == OperationType::E_ARRIVALS) && (fp_type == LpiOperationType::E_ARRIVAL);

         if ((usage == OperationType::E_MIXED) || isDeparture || isArrival)
         {
            ordered_runways.push_back(runway_id);
         }
      }
   }
   std::sort(ordered_runways.begin(), ordered_runways.end());


   vector<string> ordered_not_allowed = not_allowed;
   std::sort(ordered_not_allowed.begin(), ordered_not_allowed.end());

   vector<string> intersection;

   std::set_intersection(ordered_runways.begin(), ordered_runways.end(),
                         ordered_not_allowed.begin(), ordered_not_allowed.end(),
                         back_inserter(intersection));

   return (intersection.size() == not_allowed.size());
}


map<string, int> LpdbRSScheduled::getAvailableRunwaysAndCapacities (int use_type)
{
   map<string, int> result;

   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & data, r_runways)
   {
      OperationType::Enum use = data.second.getUsage();
      int capacity = data.second.getMaxCapacity();

      bool same_use = false;

      switch (use_type)
      {
         case E_ARR:
            same_use = (use == OperationType::E_ARRIVALS);
         break;

         case E_DEP:
            same_use = (use == OperationType::E_DEPARTURES);
         break;
      }

      if (same_use)
      {
         result[data.first] = capacity;
      }
   }

   return result;
}



string LpdbRSScheduled::getAvailAbleRunwayOfMaxCapacity (int use_type)
{
   string result;

   int maximum_capacity = 0;

   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & data, r_runways)
   {
      OperationType::Enum use = data.second.getUsage();

      bool same_use = false;

      switch (use_type)
      {
         case E_ARR:
            same_use = (use == OperationType::E_ARRIVALS);
         break;

         case E_DEP:
            same_use = (use == OperationType::E_DEPARTURES);
         break;
      }

      if (same_use)
      {
         int actual_capacity = data.second.getActualCapacity();

         if (actual_capacity > maximum_capacity)
         {
            result = data.first;
         }
      }
   }

   return result;
}




int LpdbRSScheduled::getActualCapacity (string runway)
{
   int capacity = 0;

   if (r_runways.count(runway) > 0)
   {
      capacity = r_runways[runway].getActualCapacity();
   }

   return capacity;
}


bool LpdbRSScheduled::isAvailable (string runway)
{
   bool result = false;

   if (r_runways.count(runway) > 0)
   {
      result = (r_runways[runway].getActualCapacity() > 0);
   }

   return result;
}


bool LpdbRSScheduled::isAvailable (string runway, int use)
{
   bool result = false;

   if (r_runways.count(runway) > 0)
   {
      OperationType::Enum usage = r_runways[runway].getUsage();
      bool same_usage = false;

      if (((use == E_ARR) && (usage == OperationType::E_ARRIVALS)) ||
         ((use == E_DEP) && (usage == OperationType::E_DEPARTURES)))
      {
         same_usage = true;
      }

      result = (r_runways[runway].getActualCapacity() > 0) && same_usage;
   }

   return result;
}


bool LpdbRSScheduled::isSameUse(string runway, int use)
{
   bool result = false;

   if (r_runways.count(runway) > 0)
   {
      OperationType::Enum usage = r_runways[runway].getUsage();
      bool same_usage = false;

      if (((use == E_ARR) && (usage == OperationType::E_ARRIVALS)) ||
         ((use == E_DEP) && (usage == OperationType::E_DEPARTURES)))
      {
         same_usage = true;
      }

      result = same_usage;
   }

   return result;
}


bool LpdbRSScheduled::isCompatibleUse(string runway, LpiOperationType::LpiEnum use)
{
   bool result = false;

   if (r_runways.count(runway) > 0)
   {
      OperationType::Enum usage = r_runways[runway].getUsage();
      bool same_usage = false;

      switch (use)
      {
         case LpiOperationType::E_ARRIVAL:
            same_usage = ((usage == OperationType::E_ARRIVALS) || (usage == OperationType::E_MIXED));
         break;
         case LpiOperationType::E_DEPARTURE:
            same_usage = ((usage == OperationType::E_DEPARTURES) || (usage == OperationType::E_MIXED));
         break;
         case LpiOperationType::E_NONE:
            same_usage = false;
         break;
      }

      result = same_usage;
   }

   return result;
}


LpiADOVector<int> LpdbRSScheduled::getScheduledRunwayCapacity(string runway, string interval)
{
   LpiADOVector<int> result;

   /*LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();
   if (rsTable.exists(getRunwaySystemId()))
   {
      string id = getRunwaySystemId();
      LpdbRunwaySystem & rs_db = rsTable[id];

      map<string, LpdbRunwaySystemRunway> runways_in_rs = rs_db.getRunways();

      if (runways_in_rs.count(runway) > 0)
      {
         LpdbRunwaySystemRunway & rs_rwy = runways_in_rs[runway];

         if (rs_rwy.has_data(interval))
         {
            LpiADOVector<int> max_cap = rs_rwy[interval].getMaxCapacity();
            LpiADOVector<int> max_cap_calc = rs_rwy[interval].getMaxCapacityCalculated();
            LpiADOVector<double> dep_cap_red = rs_rwy[interval].getDependencyCapacityReduction();
            LpiADOVector<double> file_cap_red = rs_rwy[interval].getFileCapacityReduction();

            result = max_cap;
         }
      }
   }
*/
   return result;
}


void LpdbRSScheduled::resetAllocation()
{
   typedef std::map<std::string, LpdbRwyScheduled>::iterator runways_iterator;

   for(runways_iterator it = r_runways.begin(); it != r_runways.end(); it++)
   {
      (*it).second.resetAllocation();
   }
}


int LpdbRSScheduled::getNumberOfArrivalRunways() const
{
   return r_number_of_arrival_runways;
}


int LpdbRSScheduled::getNumberOfDepartureRunways() const
{
   return r_number_of_departure_runways;
}

/*
//KPIs Generation v2
void LpdbRSScheduled::generateRunwayAndAirportIntervalKPIs(string interval,
                                                          map<string, LpdbFPSchedule> & scheduled_fps,
                                                          map<string, LpdbFPSchedule> & delayed_fps_last_interval,
                                                          const LpiADOVector<vector<string> > & accepted_fps,
                                                          const LpiADOVector<vector<string> > & delayed_fps,
                                                          LpiConfigurationAlertKPIs & alertThresholds,
                                                          int delayCountThreshold)
{
   //Phase II: Backup of values before new calculations
   r_absolute_airport_kpis_previous = r_absolute_airport_kpis;

   r_absolute_airport_kpis.reset();

   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & runway, r_runways)
   {
      runway.second.generateRunwayIntervalKPIs(interval,
                                               scheduled_fps,
                                               delayed_fps_last_interval,
                                               alertThresholds,
                                               delayCountThreshold);

      LpdbRunwayIntervalKPIs runwayIntervalKPIs = runway.second.getRunwayIntervalKPIs();

      r_absolute_airport_kpis.calculateAccumulatedValues(runwayIntervalKPIs);
   }

   r_absolute_airport_kpis.calculateAverages();

   r_absolute_airport_kpis.calculateAverageForecastedDelayDelayedFPs(interval,
                                                                     accepted_fps,
                                                                     delayed_fps,
                                                                     scheduled_fps,
                                                                     delayed_fps_last_interval,
                                                                     delayCountThreshold);*//*

   r_absolute_airport_kpis.generateAlerts(interval, alertThresholds);
}
*/

void LpdbRSScheduled::printRunwaysKPIs()
{
   typedef std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & runway, r_runways)
   {
      LpdbRunwayIntervalKPIs kpis = runway.second.getRunwayIntervalKPIs();

      // LclogStream::instance(LclogConfig::E_RTP).notify() << "Calculated " << runway.first << " interval kpis:" << kpis << std::endl;
   }
}


std::ostream& operator<<(std::ostream &os, const LpdbRSScheduled &info)
{
   os << "[PLANNED RS: " << info.getRunwaySystemId();

   typedef const std::map<std::string, LpdbRwyScheduled>::value_type value_pair;

   BOOST_FOREACH(value_pair & runway, info.getRunways())
   {
      os << "[RWY : " << runway.first
         << " |USG: " << runway.second.getUsage()
         << " |MAX_CAP: " << runway.second.getMaxCapacity()
         << " |ALLOC: " << runway.second.getNumberOfAllocatedFps()
         << " |DLYD: " << runway.second.getNumberOfDelayedFps()
         << "]\n";
   }

   os << ']';
   return os;
}


