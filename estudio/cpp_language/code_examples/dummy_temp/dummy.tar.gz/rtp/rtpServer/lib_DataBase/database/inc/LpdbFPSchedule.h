/*
 * LpdbFPSchedule.h
 *
 *  Created on: 08/05/2014
 *      Author: gpfernandez
 */

#ifndef LPBFPSCHEDULE_H_
#define LPBFPSCHEDULE_H_

#include <string>
#include <LpiOperationType.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/optional/optional.hpp>


using namespace boost;

class LpiScheduledFlightPlan;

class LpdbFPSchedule
{
   public:
      LpdbFPSchedule();

      LpdbFPSchedule(const std::string & key,
                    const std::string & callsign,
                    const std::string & departure,
                    const std::string & arrival,
                    const boost::optional<posix_time::ptime> & eobt);

      LpdbFPSchedule(const LpdbFPSchedule & source);

      virtual ~LpdbFPSchedule() {}

      LpdbFPSchedule & operator= (const LpdbFPSchedule & source);

      //Getters and setters
      std::string getCallsign() const;
      void setCallsign(std::string callsign);

      std::string getArrivalAerodrome() const;
      void setArrivalAerodrome(std::string arrivalAerodrome);

      std::string getDepartureAerodrome() const;
      void setDepartureAerodrome(std::string departureAerodrome);

      void setAssignedRunway(std::string runway);
      std::string getAssignedRunway() const;

      LpiOperationType::LpiEnum getOperationType() const
      { return r_operation_type; };

      void setOperationType(LpiOperationType::LpiEnum operation_type)
      { r_operation_type = operation_type; };

      const boost::optional<posix_time::ptime> & getFldt() const;
      void setFldt(posix_time::ptime fldt);

      const boost::optional<posix_time::ptime> & getFtot() const;
      void setFtot(posix_time::ptime ftot);

      const boost::optional<posix_time::ptime> & getSldt() const;
      void setSldt(posix_time::ptime sldt);

      const boost::optional<posix_time::ptime> & getStot() const;
      void setStot(posix_time::ptime stot);

      const boost::optional<posix_time::ptime> & getIldt() const;
      void setIldt(posix_time::ptime ildt);

      const boost::optional<posix_time::ptime> & getItot() const;
      void setItot(posix_time::ptime itot);

      const boost::optional<posix_time::ptime> & getEobt() const;
      void setEobt(const posix_time::ptime & eobt);

      //Returns an unique key/id like: "callsign dep arr"
      std::string getUniqueKey() const;

      boost::optional<double> getLdForecastedDelay() const;
      void setLdForecastedDelay(double ldForecastedDelay);

      boost::optional<double> getToForecastedDelay() const;
      void setToForecastedDelay(double toForecastedDelay);

      boost::optional<double>  getLdPunctualityDelay() const;
      void setLdPunctualityDelay(double ldForecastedDelay);

      boost::optional<double>  getToPunctualityDelay() const;
      void setToPunctualityDelay(double toForecastedDelay);

      boost::optional<posix_time::ptime> getAssignedTime() const;

      const bool & getTurnRoundDelayed() const;
      void setTurnRoundDelayed(const bool & delayed);

      boost::optional<posix_time::ptime> getIntentionalTime() const;

      static LpiScheduledFlightPlan convertToInterface (const LpdbFPSchedule & fp);

   protected:

      std::string r_key;

      std::string r_callsign;
      std::string r_departure_aerodrome;
      std::string r_arrival_aerodrome;

      std::string r_assigned_runway;

      LpiOperationType::LpiEnum  r_operation_type;

      boost::optional<posix_time::ptime> r_ftot;
      boost::optional<posix_time::ptime> r_fldt;

      boost::optional<posix_time::ptime> r_stot;
      boost::optional<posix_time::ptime> r_sldt;

      boost::optional<posix_time::ptime> r_itot;
      boost::optional<posix_time::ptime> r_ildt;

      boost::optional<posix_time::ptime> r_eobt;

      boost::optional<double>  r_ld_forecasted_delay;
      boost::optional<double>  r_ld_punctuality_delay;
      boost::optional<double>  r_to_forecasted_delay;
      boost::optional<double>  r_to_punctuality_delay;

      bool r_turnRoundDelayed;
};

std::ostream& operator<< (std::ostream & out,const LpdbFPSchedule & fp);


#endif /* LPBFPSCHEDULE_H_ */
