/*
 * LpdbRunwaySystemRunwayTimedData.cc
 *
 *  Created on: 17/02/2014
 *  Author: mbegega
 */

#include "LpdbRunwaySystemRunwayTimedData.h"
#include <LpiADOVector.h>

LpdbRunwaySystemRunwayTimedData::LpdbRunwaySystemRunwayTimedData()
: r_name("LpdbRunwaySystemRunwayTimedData"),
  r_max_capacity(),
  r_max_capacity_calculated(),
  r_dependency_capacity_reduction(),
  r_file_capacity_reduction(),
  r_wtc_capacity_reduction()
{
}


LpdbRunwaySystemRunwayTimedData::LpdbRunwaySystemRunwayTimedData(const LpdbRunwaySystemRunwayTimedData & source)
: r_name(source.r_name),
  r_max_capacity(source.r_max_capacity),
  r_max_capacity_calculated(source.r_max_capacity_calculated),
  r_dependency_capacity_reduction(source.r_dependency_capacity_reduction),
  r_file_capacity_reduction(source.r_file_capacity_reduction),
  r_wtc_capacity_reduction(source.r_wtc_capacity_reduction)
{
}


LpdbRunwaySystemRunwayTimedData::~LpdbRunwaySystemRunwayTimedData()
{

}


LpdbRunwaySystemRunwayTimedData & LpdbRunwaySystemRunwayTimedData::operator= (const LpdbRunwaySystemRunwayTimedData & source)
{
   if (this != &source)
   {
      r_name= source.r_name;
      r_max_capacity = source.r_max_capacity;
      r_max_capacity_calculated = source.r_max_capacity_calculated;
      r_dependency_capacity_reduction = source.r_dependency_capacity_reduction;
      r_file_capacity_reduction = source.r_file_capacity_reduction;
      r_wtc_capacity_reduction = source.r_wtc_capacity_reduction;
   }

   return *this;
}


std::string LpdbRunwaySystemRunwayTimedData::get_name () const
{
   return r_name;
}


LpiADOVector<int> LpdbRunwaySystemRunwayTimedData::getMaxCapacity() const {
   return r_max_capacity;
}


void LpdbRunwaySystemRunwayTimedData::setMaxCapacity(LpiADOVector<int> maxCapacity)
{
   r_max_capacity = maxCapacity;
}

LpiADOVector<int> LpdbRunwaySystemRunwayTimedData::getMaxCapacityCalculated() const
{
   return r_max_capacity_calculated;
}


void LpdbRunwaySystemRunwayTimedData::setMaxCapacityCalculated(LpiADOVector<int> maxCapacity)
{
   r_max_capacity_calculated = maxCapacity;
}


LpiADOVector<double> LpdbRunwaySystemRunwayTimedData::getDependencyCapacityReduction() const
{
   return r_dependency_capacity_reduction;
}


void LpdbRunwaySystemRunwayTimedData::setDependencyCapacityReduction(LpiADOVector<double> capacity)
{
   r_dependency_capacity_reduction = capacity;
}


LpiADOVector<double> LpdbRunwaySystemRunwayTimedData::getFileCapacityReduction() const
{
   return r_file_capacity_reduction;
}


void LpdbRunwaySystemRunwayTimedData::setFileCapacityReduction(LpiADOVector<double> capacity)
{
   r_file_capacity_reduction = capacity;
}

LpiADOVector<double> LpdbRunwaySystemRunwayTimedData::getWakeVortexCapacityReduction() const
{
   return r_wtc_capacity_reduction;
}

void LpdbRunwaySystemRunwayTimedData::setWakeVortexCapacityReduction(LpiADOVector<double> capacity)
{
   r_wtc_capacity_reduction = capacity;
}



std::ostream& operator<<(std::ostream &os, const LpdbRunwaySystemRunwayTimedData &info)
{
   return os << " | MAX_CAP : " << info.getMaxCapacity()
             << " | MAX_CAP_CALC : " << info.getMaxCapacityCalculated()
             << " | DEP_CAP_RED : "  << info.getDependencyCapacityReduction()
             << " | FILE_CAP_RED : " << info.getFileCapacityReduction()
             << " | WTC_CAP_RED : "  << info.getWakeVortexCapacityReduction();
}

