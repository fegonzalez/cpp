
#include "LpdbPreferences.h"
#include <LpiAdapPrefsConstants.h>

#include <algorithm>
#include <iterator>
#include <set>

//-----------------------------------------------------------------------------

LpdbPreferences::~LpdbPreferences()
{
  release();
}

void LpdbPreferences::release()
{
  r_preferencesLevelKey.clear();
}

//------------------------------------------------------------------------------

const LpdbPreferences::LpdbPreferencesStorageByLevelType & 
LpdbPreferences::getPreferences() const
{
   return r_preferencesLevelKey;
}

//------------------------------------------------------------------------------

/* Use example.- 
  std::set<std::string> allValues = findAll("A1-ID");
  for (auto& x: allValues)
    std::cout << x << "; " << std::endl;
*/
std::set<PreferenceElement> LpdbPreferences::findAll
(const PREF_LEVEL_TYPE &key) const
{
  std::set<PreferenceElement> result;
  const auto values_range = r_preferencesLevelKey.equal_range(key);
  for(auto next = values_range.first;
      next != values_range.second;
      ++next)
    {
      result.insert(next->second);
    }
  return result;
}

//------------------------------------------------------------------------------

/* Use example.- 
  std::string oneValue;
  if (findOne("A1-ID", oneValue))
  std::cout << "\n oneValue: " << oneValue << std::endl;
*/
bool LpdbPreferences::findOne(const PREF_LEVEL_TYPE &key,
			      PreferenceElement &retval) const
{
    auto search = r_preferencesLevelKey.find(key);
    if(search not_eq r_preferencesLevelKey.end())
    {
      retval = search->second;
      return true;
    }
    else
    {
      return false;
    }
}

//------------------------------------------------------------------------------

void LpdbPreferences::setPreferences(const PreferenceElementList & new_val)
{
  release();
  for (auto& x: new_val)
  {
    addPreference(std::get<0>(x),
		  std::get<1>(x),
		  std::get<2>(x));
  }
}

//------------------------------------------------------------------------------

void LpdbPreferences::addPreference(const PREF_LEVEL_TYPE &level,
                                    const PREF_AIRPORT1_TYPE &a1,
				    const PREF_AIRPORT2_TYPE &a2)
{
   r_preferencesLevelKey.insert(std::make_pair(level, 
					       std::make_tuple (level, a1, a2)));

	//iff necessary
	//r_preferencesAirportKey.insert(std::make_pair(a1, newval));
    //r_preferencesAirportKey.insert(std::make_pair(a2, newval));
}

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & os, const LpdbPreferences & info)
{
  const LpdbPreferences::LpdbPreferencesStorageByLevelType & preferences = 
    info.getPreferences();

  os << "[ preferential Allocations: ";
    
  //c++11
  for (auto& x: preferences)
    os << " (" << std::get<0>(x.second) << ','
	   << std::get<1>(x.second) << ','
	   << std::get<2>(x.second) << ')';
  os << ' ';
  os << " ] \n";

  return os;
}

//------------------------------------------------------------------------------
