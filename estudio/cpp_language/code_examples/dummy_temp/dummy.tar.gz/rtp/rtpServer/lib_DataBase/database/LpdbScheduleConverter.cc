/*
 * LpdbScheduleConverter.cc
 *
 *  Created on: 19/02/2015
 *      Author: mbegega
 */

#include "LpdbScheduleConverter.h"
//#include "LpdbDataBase.h"


LpiComparativeKpis LpdbScheduleConverter::ConvertKpis2Interface(TimeLine<LpdbSCHTimedData> & in)
{
   LpiComparativeKpis out;

   vector<string> intervals = in.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      if (in.hasData(interval))
      {
         LpiIntervalKpi intervalData;

         TimeInterval times = in.getTimeInterval(interval);

         intervalData.setStartTimeAndDate(LctimTimeUtils::formatTime(times.begin))
                     .setEndTimeAndDate  (LctimTimeUtils::formatTime(times.end));

         LpiIntervalDataKpis intervalDeltaData;
         LpiIntervalDataKpis intervalRelativeData;

         LpdbAirportIntervalComparativeKPIs::convert2Interface(in[interval].getDeltaKPIs(), intervalDeltaData);
         LpdbAirportIntervalComparativeKPIs::convert2Interface(in[interval].getRelativeKPIs(), intervalRelativeData);

         intervalData.setDeltaKpis(intervalDeltaData);
         intervalData.setRelativeKpis(intervalRelativeData);

         out.addKpiPerInterval(intervalData);
      }
   }

   return out;
}


LpiFPList LpdbScheduleConverter::ConvertFlightPlanList2Interface (LpdbSchedule & schedule)
{
   typedef std::map<string, LpdbFPSchedule>::value_type scheduledFPType;

   std::map<string, LpdbFPSchedule> scheduledFPs = schedule.getScheduleFps();
   std::map<string, LpdbFPSchedule> delayedFPsInLastInterval = schedule.getDelayedFpsInLastInterval();

   std::map<string, LpdbFPSchedule> flightPlansToProcess = scheduledFPs;
   flightPlansToProcess.insert(delayedFPsInLastInterval.begin(), delayedFPsInLastInterval.end());

   LpiFPList fpCollection;
   vector<LpiScheduledFlightPlan> fp_sequence;

   BOOST_FOREACH(scheduledFPType & element, flightPlansToProcess)
   {
      if (!element.second.getCallsign().empty())
      {
         LpiScheduledFlightPlan fp = LpdbFPSchedule::convertToInterface(element.second);
         fp_sequence.push_back(fp);
      }
   }

   fpCollection.setFpList(fp_sequence);

   return fpCollection;
}

/*
LpiSchedule LpdbScheduleConverter::Convert2Interface (LpdbSchedule & schedule,
                                                     LpdbSchedule::ScheduleType schedule_type,
                                                     const LpiConfigurationAlertKPIs & alertKPIs)
{
   LpiSchedule out;

   LpiScheduleTimeLine plannedRunwaySystems;
   std::vector<LpiTimeIntervalData> timeline;

   LpiPerformanceInfo performanceInfo;
   std::vector<LpiPerformanceIntervalData> performanceTimeLine;

   LpiCapacityInfo capacityInfo;
   std::vector<LpiCapacityIntervalData> capacityTimeLine;

   vector<string> intervals= schedule.getTimeLine().getAllIntervalIds();

   LpiADO accumulatedIntentionalDemand;
   LpiADO accumulatedInheritedDemand;
   LpiADO accumulatedTotalDemand;

   BOOST_FOREACH(string ti, intervals)
   {
      LpiTimeIntervalData scheduleIntervalInterface;
      LpiPerformanceIntervalData performanceIntervalInterface;
      LpiCapacityIntervalData capacityIntervalInterface;

      TimeInterval scheduleInterval = schedule.getTimeLine().getTimeInterval(ti);

      scheduleIntervalInterface.setName(ti);
      scheduleIntervalInterface.setBeginTime(LctimTimeUtils::formatTime(scheduleInterval.begin));
      scheduleIntervalInterface.setEndTime(LctimTimeUtils::formatTime(scheduleInterval.end));

      performanceIntervalInterface.setName(ti);
      performanceIntervalInterface.setBeginTime(LctimTimeUtils::formatTime(scheduleInterval.begin));
      performanceIntervalInterface.setEndTime(LctimTimeUtils::formatTime(scheduleInterval.end));

      capacityIntervalInterface.setName(ti);
      capacityIntervalInterface.setBeginTime(LctimTimeUtils::formatTime(scheduleInterval.begin));
      capacityIntervalInterface.setEndTime(LctimTimeUtils::formatTime(scheduleInterval.end));

      if (schedule.has_data(ti))
      {
         //Schedule planned RSs and demand interval data conversion
         LpiRS_Scheduled plannedRS = LpdbScheduleConverter::ConvertScheduledRS2Interface(schedule[ti].getRsScheduled());

         LpiScheduleDemand intervalDemand;
         intervalDemand.rIntentionalDemand = LpiADOConverter::Convert2Interface(schedule[ti].getIntentionalDemand());
         intervalDemand.rInheritedDemand   = LpiADOConverter::Convert2Interface(schedule[ti].getInheritedDemand());
         intervalDemand.rTotalDemand = LpiADOConverter::Convert2Interface(schedule[ti].getTotalDemand());

         //Update total
         accumulatedIntentionalDemand = accumulatedIntentionalDemand + intervalDemand.rIntentionalDemand;
         accumulatedInheritedDemand = accumulatedInheritedDemand + intervalDemand.rInheritedDemand;
         accumulatedTotalDemand = accumulatedTotalDemand + intervalDemand.rTotalDemand;

         scheduleIntervalInterface.setRSScheduled(plannedRS);
         scheduleIntervalInterface.setDemand(intervalDemand);

         //Runways kpis and capacities conversion
         LpdbScheduleConverter::ConvertRunwaysIntervalData2Interface(ti,
                                                                    schedule,
                                                                    alertKPIs,
                                                                    performanceIntervalInterface,
                                                                    capacityIntervalInterface);

         //Performance interval data conversion
         LpiAirportIntervalKPIs airportIntervalKPIsInterface;
         LpdbAirportIntervalKPIs scheduledAirportKpis = schedule[ti].getRsScheduled().getAirportIntervalKpis();

         //Phase I
         //Real Accepted and Shortage are calculated in Real DCB calculations (and stored in schedule interval)
         airportIntervalKPIsInterface.setrealAcceptedFps(
                                 LpiADOConverter::Convert2Interface(schedule[ti].getRealAcceptedFps()));

         airportIntervalKPIsInterface.setshortage(LpiADOConverter::Convert2Interface(schedule[ti].getShortage()));

         int intervalsPerHour = schedule.getTimeLine().getNumberOfIntervalsPerHour();
         LpdbWarningErrors alarm_warning;
         airportIntervalKPIsInterface.setshortageWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                    airportIntervalKPIsInterface.getshortage(),
                                                    alertKPIs.getAirportShortage().getAlarmThreshold(),
                                                    alertKPIs.getAirportShortage().getWarningThreshold(),
                                                    alertKPIs.getAirportShortage().getComparison()));
         //Phase II
         //LpdbAirportIntervalKPIs::convertToInterface(scheduledAirportKpis, airportIntervalKPIsInterface);

         performanceIntervalInterface.setAirportIntervalKPIs(airportIntervalKPIsInterface);

         //Capacity interval data conversion
         LpiAirportIntervalCapacityInfo airportIntervalCapacities;
         LpdbScheduleConverter::ConvertAirportIntervalCapacityInfo2Interface(ti,
                                                                            schedule,
                                                                            alertKPIs,
                                                                            airportIntervalCapacities);

         capacityIntervalInterface.setAirportIntervalCapacities(airportIntervalCapacities);

         timeline.push_back(scheduleIntervalInterface);
         performanceTimeLine.push_back(performanceIntervalInterface);
         capacityTimeLine.push_back(capacityIntervalInterface);
      }
   }

   plannedRunwaySystems.setAllScheduleIntervals(timeline);
   performanceInfo.setAllPerformanceIntervalData(performanceTimeLine);
   capacityInfo.setAllCapacityIntervalData(capacityTimeLine);

   LpiAirportTotalKPIs airportTotalKPIs = LpdbScheduleConverter::ConvertAirportTotalKPIs2Interface(schedule, alertKPIs);
   performanceInfo.setAirportTotalKPIs(airportTotalKPIs);

   //Phase II: Comparative KPIs
   performanceInfo.setComparativeKPIs(LpdbScheduleConverter::ConvertKpis2Interface(schedule.getTimeLine()));

   //Set all schedule global data
   out.setScheduleTimeLine(plannedRunwaySystems);

   out.setFPList(LpdbScheduleConverter::ConvertFlightPlanList2Interface(schedule));

   out.setPerformanceInfo(performanceInfo);

   out.setCapacityInfo(capacityInfo);

   LpiScheduleDemand totalDemand;
   totalDemand.rIntentionalDemand = accumulatedIntentionalDemand;
   totalDemand.rInheritedDemand = accumulatedInheritedDemand;
   totalDemand.rTotalDemand = accumulatedTotalDemand;

   out.setDemandData(totalDemand);

   out.setFrozenPeriod(schedule.getFrozenPeriod());

   out.setOrigin(schedule.getOrigin());

#ifdef TRACE_OUT
   //LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getScheduleInterfaceAsString(out, schedule_type) << std::endl;
#endif

   return out;
}
*/


/*
LpiRS_Scheduled LpdbScheduleConverter::ConvertScheduledRS2Interface (const LpdbRSScheduled & scheduledRS)
{
   LpiRS_Scheduled out;

   LpdbDataBase::RunwaySystemTable &rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   //Planned RS name conversion
   string plannedRSId = scheduledRS.getRunwaySystemId();

   out.setRunwaySystem(plannedRSId);

   //Planned Configuration conversion
   if(rsTable.exists(plannedRSId))
   {
      out.setConfiguration(rsTable[plannedRSId].getConfiguration());
   }

   // Runways data conversion
   std::map<std::string, LpdbRwyScheduled> plannedRunways = scheduledRS.getRunways();
   std::map<std::string, LpdbRwyScheduled>::iterator it;

   std::string arrivalRunways;
   std::string departureRunways;

   for (it= plannedRunways.begin(); it != plannedRunways.end(); it++)
   {
      switch ((it->second).getUsage())
      {
         case OperationType::E_ARRIVALS:

            if(it != plannedRunways.begin() && !arrivalRunways.empty())
            {
               arrivalRunways.append(" - ");
            }
            arrivalRunways.append((it->second).getRwyId());

         break;

         case OperationType::E_DEPARTURES:

            if(it != plannedRunways.begin() && !departureRunways.empty())
            {
               departureRunways.append(" - ");
            }
            departureRunways.append((it->second).getRwyId());

         break;

         case OperationType::E_MIXED:

            if (it != plannedRunways.begin())
            {
               if (!arrivalRunways.empty())
               {
                  arrivalRunways.append(" - ");
               }

               if (!departureRunways.empty())
               {
                  departureRunways.append(" - ");
               }
            }

            arrivalRunways.append((it->second).getRwyId());
            departureRunways.append((it->second).getRwyId());

         break;

         case OperationType::E_INVALID_RWY_OPERATION_TYPE:
         default:
         break;
      }
   }

   out.setRunwayArr(arrivalRunways);
   out.setRunwayDep(departureRunways);

   return out;
}
*/

/*
void LpdbScheduleConverter::ConvertRunwaysIntervalData2Interface(string interval,
                                                                LpdbSchedule & schedule,
                                                                const LpiConfigurationAlertKPIs & alertKPIs,
                                                                LpiPerformanceIntervalData & outPerformance,
                                                                LpiCapacityIntervalData & outCapacity)
{
   LpdbWarningErrors alarm_warning;

   //TimeLine<LpdbSCHTimedData> & scheduleTimeLine = schedule.getTimeLine();

   //int intervalsPerHour = scheduleTimeLine.getNumberOfIntervalsPerHour();

   LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
   LpdbDataBase::RunwaySystemTable & runwaySystemTable = LpdbDataBase::Get().getRunwaySystemTable();

   if(scheduleLptimTimeLine.hasData(interval))
   {
      std::map<std::string, LpdbRwyScheduled> scheduledRunways = schedule[interval].getRsScheduled().getRunways();

      typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_type;

      std::vector<LpiRunwayIntervalKPIs> kpisSequence;
      std::vector<LpiRunwayIntervalCapacityInfo> capacitiesSequence;

      BOOST_FOREACH(rwy_type & element, scheduledRunways)
      {
         std::string plannedRS = schedule[interval].getRsScheduled().getRunwaySystemId();

         if(runwayTable.exists(element.second.getRwyId()) &&
            runwaySystemTable.exists(plannedRS))
         {
            LpiRunwayIntervalCapacityInfo capacityInterface;
            LpiRunwayIntervalKPIs kpisInterface;

            capacityInterface.setrwyName(element.second.getRwyId());
            kpisInterface.setrwyName(element.second.getRwyId());

            //ISE#564
            int plannedRunwayCapacity = element.second.getMaxCapacity();

            LpiADO convertedRunwayCapacity(-1, -1, -1);

            switch (element.second.getUsage())
            {
                case OperationType::E_ARRIVALS:
                    convertedRunwayCapacity.setarrivalsValue(plannedRunwayCapacity);
                    convertedRunwayCapacity.setoverallValue(plannedRunwayCapacity);
                break;

                case OperationType::E_DEPARTURES:
                    convertedRunwayCapacity.setdeparturesValue(plannedRunwayCapacity);
                    convertedRunwayCapacity.setoverallValue(plannedRunwayCapacity);
                break;

                case OperationType::E_MIXED:
                    convertedRunwayCapacity.setarrivalsValue(plannedRunwayCapacity);
                    convertedRunwayCapacity.setdeparturesValue(plannedRunwayCapacity);
                    convertedRunwayCapacity.setoverallValue(plannedRunwayCapacity);
                break;

                case OperationType::E_INVALID_RWY_OPERATION_TYPE:
                default:
                break;
            }

            //Phase I
            capacityInterface.setrwyCapacity(convertedRunwayCapacity);
            kpisInterface.setrwyRealAcceptedFps(LpiADOConverter::Convert2Interface(element.second.getNumberOfAllocatedFps()));
            kpisInterface.setrwyShortage(LpiADOConverter::Convert2Interface(element.second.getNumberOfDelayedFps()));

            capacityInterface.setrwyCapacityWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                                           capacityInterface.getrwyCapacity(),
                                                                           alertKPIs.getRunwayCapacity().getAlarmThreshold(),
                                                                           alertKPIs.getRunwayCapacity().getWarningThreshold(),
                                                                           alertKPIs.getRunwayCapacity().getComparison()));

            kpisInterface.setrwyShortageWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                                       kpisInterface.getrwyShortage(),
                                                                       alertKPIs.getRunwayShortage().getAlarmThreshold(),
                                                                       alertKPIs.getRunwayShortage().getWarningThreshold(),
                                                                       alertKPIs.getRunwayShortage().getComparison()));

            //Phase II
            LpdbRunwayIntervalKPIs scheduledRunwayKPIs = element.second.getRunwayIntervalKPIs();

            LpdbRunwayIntervalKPIs::convertToInterface(element.second.getUsage(), scheduledRunwayKPIs, kpisInterface);

            kpisSequence.push_back(kpisInterface);
            capacitiesSequence.push_back(capacityInterface);
         }
      }
      outPerformance.setRwysKPIs(kpisSequence);
      outCapacity.setAllRwysCapacities(capacitiesSequence);
      }
}
*/

/*
LpiAirportTotalKPIs LpdbScheduleConverter::ConvertAirportTotalKPIs2Interface(LpdbSchedule &schedule,
                                                      const LpiConfigurationAlertKPIs & alertKPIs)
{
   LpiAirportTotalKPIs out;
   LpdbWarningErrors alarm_warning;

   //Airport total KPIs
   out.setTotalShortage(LpiADOConverter::Convert2Interface(schedule.getShortage()));
   out.setTotalAccepted(LpiADOConverter::Convert2Interface(schedule.getAccepted()));

   out.setmaxForecastedDelay (LpiADOConverter::Convert2Interface(schedule.getMaxForecastDelay()));
   out.setmaxForecastedDelayWA(alarm_warning.Alarm_Warning(1,
                               out.getmaxForecastedDelay(),
                               alertKPIs.getMaxForecastedDelay().getAlarmThreshold(),
                               alertKPIs.getMaxForecastedDelay().getWarningThreshold(),
                               alertKPIs.getMaxForecastedDelay().getComparison()));

   out.setaverageForecastedDelay(LpiADOConverter::Convert2Interface(schedule.getAverageForecastDelay()));

   out.setmaxPunctualityDelay(LpiADOConverter::Convert2Interface(schedule.getMaxPunctualityDelay()));
   out.setaveragePunctualityDelay(LpiADOConverter::Convert2Interface(schedule.getAveragePunctualityDelay()));

   LpiADOVector<double> avg_delay_delayed = schedule.getAbsoluteKpis().getAverageForecastedDelay_DelayedFps();
   out.setaverageForecastedDelayDelayedFPs(LpiADOConverter::Convert2Interface(avg_delay_delayed));

   Warnings_alerts avg_delay_delayed_alerts = schedule.getAbsoluteKpis().getAverageForecastedDelayDelayedFpsWA();
   out.setaverageForecastedDelayDelayedFPsWA(avg_delay_delayed_alerts);

   LpiADOVector<int> totalDemand= LpdbDataBase::Get().getDemand().getTotalDemandForecast();

   LpiADO punctualityMask(-1, -1, -1);
   LpiADO delayedFPsMask (-1, -1, -1);

   if(totalDemand[E_ARR] + totalDemand[E_DEP] == 0)
   {
      out.setpunctualFPs(delayedFPsMask);
      out.setdelayedFPs (delayedFPsMask);
   }
   else
   {
      out.setpunctualFPs(LpiADOConverter::Convert2Interface(schedule.getPunctualFP()));
      out.setdelayedFPs(LpiADOConverter::Convert2Interface(schedule.getDelayedFP()));

      LpiADOVector<double> punctualPercentage = schedule.getPunctualPorcentage();

      punctualityMask.setarrivalsValue(punctualPercentage[E_ARR]);
      punctualityMask.setdeparturesValue(punctualPercentage[E_DEP]);
      punctualityMask.setoverallValue(punctualPercentage[E_OVA]);
   }


   out.setpercentagePunctual(punctualityMask);
   out.setpercentagePunctualWA(alarm_warning.Alarm_Warning(1,
                               out.getpercentagePunctual(),
                               alertKPIs.getPunctuality().getAlarmThreshold(),
                               alertKPIs.getPunctuality().getWarningThreshold(),
                               alertKPIs.getPunctuality().getComparison()));
   return out;
}
*/

/*

///@warniong RMAN's code
void LpdbScheduleConverter::ConvertAirportIntervalCapacityInfo2Interface(string interval,
                                                                        LpdbSchedule & schedule,
                                                                        const LpiConfigurationAlertKPIs & alertKPIs,
                                                                        LpiAirportIntervalCapacityInfo & out)
{
   LpdbWarningErrors alarm_warning;

   TimeLine<LpdbSCHTimedData> & scheduleTimeLine = schedule.getTimeLine();

   int intervalsPerHour = scheduleTimeLine.getNumberOfIntervalsPerHour();

   TimeLine<LpdbTMATimedData> & tmaTimeLine = LpdbDataBase::Get().getTMA().getTimeLine();
   TimeLine<LpdbTWYTimedData> & twyTimeLine = LpdbDataBase::Get().getTWY().getTimeLine();

   if(scheduleTimeLine.hasData(interval))
   {
      //ISE#354: capacities mast be sent with reductions applied
      LpiADO tmaCapacity = LpiADOConverter::Convert2Interface(tmaTimeLine[interval].getCapacity());

      out.settmaCapacity (tmaCapacity);
      out.settmaCapacityWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                       out.gettmaCapacity(),
                                                       alertKPIs.getTMACapacity().getAlarmThreshold(),
                                                       alertKPIs.getTMACapacity().getWarningThreshold(),
                                                       alertKPIs.getTMACapacity().getComparison()));

      LpiADO twyCapacity = LpiADOConverter::Convert2Interface(twyTimeLine[interval].getCapacity());
      out.settwyCapacity(twyCapacity);
      out.settwyCapacityWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                       out.gettwyCapacity(),
                                                       alertKPIs.getTWYCapacity().getAlarmThreshold(),
                                                       alertKPIs.getTWYCapacity().getWarningThreshold(),
                                                       alertKPIs.getTWYCapacity().getComparison()));


      out.setmaxCapacity (LpiADOConverter::Convert2Interface(schedule[interval].getMaxCapacity()));
      out.setmaxCapacityWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                       out.getmaxCapacity(),
                                                       alertKPIs.getAiportCapacity().getAlarmThreshold(),
                                                       alertKPIs.getAiportCapacity().getWarningThreshold(),
                                                       alertKPIs.getAiportCapacity().getComparison()));

      out.setrsCapacity(LpiADOConverter::Convert2Interface(schedule[interval].getRwysMaxCapacity()));
      out.setrsCapacityWA(alarm_warning.Alarm_Warning(intervalsPerHour,
                                                      out.getrsCapacity(),
                                                      alertKPIs.getRSCapacity().getAlarmThreshold(),
                                                      alertKPIs.getRSCapacity().getWarningThreshold(),
                                                      alertKPIs.getRSCapacity().getComparison()));
   }

*/
