/*
 * LpdbExpirationInfo.cc
 *
 *  Created on: 15/05/2015
 *      Author: mbegega
 */

#include "LpdbExpirationInfo.h"
#include "LctimTimeUtils.h"


LpdbExpirationInfo::LpdbExpirationInfo()
: r_isExpired(false),
  r_expirationHours(0),
  r_automaticDeletion(true),
  r_expirationTime()
{
}


LpdbExpirationInfo::LpdbExpirationInfo(bool expired,
                                     float hours,
                                     bool automaticDeletion,
                                     const boost::posix_time::ptime & expirationTime)
: r_isExpired(expired),
  r_expirationHours(hours),
  r_automaticDeletion(automaticDeletion),
  r_expirationTime(expirationTime)
{
}


LpdbExpirationInfo::LpdbExpirationInfo(const LpdbExpirationInfo & source)
: r_isExpired(source.r_isExpired),
  r_expirationHours(source.r_expirationHours),
  r_automaticDeletion(source.r_automaticDeletion),
  r_expirationTime(source.r_expirationTime)
{
}


LpdbExpirationInfo::~LpdbExpirationInfo()
{
}


LpdbExpirationInfo & LpdbExpirationInfo::operator= (const LpdbExpirationInfo & source)
{
   if (this != &source)
   {
      r_isExpired = source.r_isExpired;
      r_expirationHours = source.r_expirationHours;
      r_automaticDeletion = source.r_automaticDeletion;
      r_expirationTime =source.r_expirationTime;
   }

   return *this;
}


bool LpdbExpirationInfo::isExpired() const
{
   return r_isExpired;
}


void LpdbExpirationInfo::isExpired(bool expired)
{
   r_isExpired = expired;
}


float LpdbExpirationInfo::getExpirationHours() const
{
   return r_expirationHours;
}


bool LpdbExpirationInfo::getAutomaticDeletion() const
{
   return r_automaticDeletion;
}


const boost::posix_time::ptime & LpdbExpirationInfo::getExpirationTime() const
{
   return r_expirationTime;
}


boost::posix_time::ptime LpdbExpirationInfo::getCancellationTime() const
{
   return r_expirationTime + boost::posix_time::minutes(r_expirationHours * 60);
}


void LpdbExpirationInfo::setExpirationHours(float expirationHours)
{
   r_expirationHours = expirationHours;
}


void LpdbExpirationInfo::setAutomaticDeletion(bool mustDelete)
{
   r_automaticDeletion = mustDelete;
}


void LpdbExpirationInfo::setExpirationDate(const boost::posix_time::ptime & expirationDate)
{
   unsigned int sec= expirationDate.time_of_day().seconds();

   r_expirationTime = expirationDate - seconds(sec); //HH:MM:00 (expiration date in minutes resolution, seconds discarded)

   r_isExpired = true;
}


std::ostream & operator<<(std::ostream &os, const LpdbExpirationInfo & expirationInfo)
{
   return os << "[EXPIRED :" << "false\0true" + 6 * expirationInfo.isExpired()
             << " | EXP_HOURS : " << expirationInfo.getExpirationHours()
             << " | MUST_AUT_DEL: "<< "false\0true" + 6 * expirationInfo.getAutomaticDeletion()
             << " | EXP_TIME: "<< expirationInfo.getExpirationTime()
             << " | CANCEL_TIME: "<< expirationInfo.getCancellationTime()
             << ']';
}
