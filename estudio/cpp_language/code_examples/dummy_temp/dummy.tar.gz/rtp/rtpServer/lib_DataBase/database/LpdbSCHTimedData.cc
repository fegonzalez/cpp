/*
 * LpdbSCHTimedData.cc
 *
 *  Created on: 11/12/2013
 *      Author: mbegega
 */

#include <sstream>
#include "LpdbSCHTimedData.h"
#include <LpdbDataBase.h>

LpdbSCHTimedData::LpdbSCHTimedData()
: r_name("LpdbSCHTimedData"),
  r_rs_scheduled(),
  r_default_delayed_fps(),
  r_default_delayed_fps_fps(),
  r_shortage(),
  r_real_delayed_fps(),
  r_real_delayed_fps_fps(),
  r_delayed_fps(),
  r_delayed_fps_fps(),
  r_not_allowed_delayed_fps(),
  r_not_allowed_delayed_fps_fps(),
  r_turn_round_delayed_fps(),
  r_turn_round_delayed_fps_fps(),
  r_real_demand_fps(),
  r_real_demand_fps_fps(),
  r_total_demand(),
  r_inherited_demand(),
  r_intentional_demand(),
  r_real_accepted_fps(),
  r_real_accepted_fps_fps(),
  r_max_capacity(),
  r_rwys_max_capacity(),
  r_real_dc_margin(),
  r_surplus(),
  r_max_capacity_previous(),
  r_rwys_max_capacity_previous(),
  r_shortage_previous(),
  r_deltaKPIs(),
  r_relativeKPIs()
{
}


LpdbSCHTimedData::LpdbSCHTimedData(const LpdbSCHTimedData & source)
: r_name(source.r_name),
  r_rs_scheduled(source.r_rs_scheduled),
  r_default_delayed_fps(source.r_default_delayed_fps),
  r_default_delayed_fps_fps(source.r_default_delayed_fps_fps),
  r_shortage(source.r_shortage),
  r_real_delayed_fps(source.r_real_delayed_fps),
  r_real_delayed_fps_fps(source.r_real_delayed_fps_fps),
  r_delayed_fps(source.r_delayed_fps),
  r_delayed_fps_fps(source.r_delayed_fps_fps),
  r_not_allowed_delayed_fps(source.r_not_allowed_delayed_fps),
  r_not_allowed_delayed_fps_fps(source.r_not_allowed_delayed_fps_fps),
  r_turn_round_delayed_fps(source.r_turn_round_delayed_fps),
  r_turn_round_delayed_fps_fps(source.r_turn_round_delayed_fps_fps),
  r_real_demand_fps(source.r_real_demand_fps),
  r_real_demand_fps_fps(source.r_real_demand_fps_fps),
  r_total_demand(source.r_total_demand),
  r_inherited_demand(source.r_inherited_demand),
  r_intentional_demand(source.r_intentional_demand),
  r_real_accepted_fps(source.r_real_accepted_fps),
  r_real_accepted_fps_fps(source.r_real_accepted_fps_fps),
  r_max_capacity(source.r_max_capacity),
  r_rwys_max_capacity(source.r_rwys_max_capacity),
  r_real_dc_margin(source.r_real_dc_margin),
  r_surplus(source.r_surplus),
  r_max_capacity_previous(source.r_max_capacity_previous),
  r_rwys_max_capacity_previous(source.r_rwys_max_capacity_previous),
  r_shortage_previous(source.r_shortage_previous),
  r_deltaKPIs(source.r_deltaKPIs),
  r_relativeKPIs(source.r_relativeKPIs)
{
}


LpdbSCHTimedData::~LpdbSCHTimedData()
{

}


std::string LpdbSCHTimedData::get_name ()
{
   return r_name;
}


LpdbRSScheduled LpdbSCHTimedData::getRsScheduled() const
{
   return r_rs_scheduled;
}


LpdbRSScheduled & LpdbSCHTimedData::getRsScheduled()
{
   return r_rs_scheduled;
}

void LpdbSCHTimedData::setRsScheduled(LpdbRSScheduled rsScheduled)
{
   r_rs_scheduled = rsScheduled;
}


//Default delayed

LpiADOVector<int> LpdbSCHTimedData::getDefaultDelayedFps() const
{
   return r_default_delayed_fps;
}


void LpdbSCHTimedData::setDefaultDelayedFps(const LpiADOVector<int> & defaultDelayedFps)
{
   r_default_delayed_fps = defaultDelayedFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getDefaultDelayedFpsFps() const
{
   return r_default_delayed_fps_fps;
}


void LpdbSCHTimedData::setDefaultDelayedFpsFps(const LpiADOVector<vector<string> > & defaultDelayedFpsFps)
{
   r_default_delayed_fps_fps = defaultDelayedFpsFps;
}


//Real delayed

LpiADOVector<int> LpdbSCHTimedData::getRealDelayedFps() const
{
   return r_real_delayed_fps;
}


void LpdbSCHTimedData::setRealDelayedFps(const LpiADOVector<int> & realDelayedFps)
{
   r_real_delayed_fps = realDelayedFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getRealDelayedFpsFps() const
{
   return r_real_delayed_fps_fps;
}


void LpdbSCHTimedData::setRealDelayedFpsFps(const LpiADOVector<vector<string> > & realDelayedFpsFps)
{
   r_real_delayed_fps_fps = realDelayedFpsFps;
}


//Delayed

LpiADOVector<int> LpdbSCHTimedData::getDelayedFps() const
{
   return r_delayed_fps;
}


void LpdbSCHTimedData::setDelayedFps(const LpiADOVector<int> & delayedFps)
{
   r_delayed_fps = delayedFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getDelayedFpsFps() const
{
   return r_delayed_fps_fps;
}


void LpdbSCHTimedData::setDelayedFpsFps(const LpiADOVector<vector<string> > & delayedFpsFps)
{
   r_delayed_fps_fps = delayedFpsFps;
}


//Not Allowed delayed

LpiADOVector<int> LpdbSCHTimedData::getNotAllowedDelayedFps() const
{
   return r_not_allowed_delayed_fps;
}


void LpdbSCHTimedData::setNotAllowedDelayedFps(const LpiADOVector<int> & notAllowedDelayedFps)
{
   r_not_allowed_delayed_fps = notAllowedDelayedFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getNotAllowedDelayedFpsFps() const
{
   return r_not_allowed_delayed_fps_fps;
}


void LpdbSCHTimedData::setNotAllowedDelayedFpsFps(const LpiADOVector<vector<string> > & notAllowedDelayedFpsFps)
{
   r_not_allowed_delayed_fps_fps = notAllowedDelayedFpsFps;
}


//Turn-Round delayed
LpiADOVector<int> LpdbSCHTimedData::getTurnRoundDelayedFps() const
{
   return r_turn_round_delayed_fps;
}


void LpdbSCHTimedData::setTurnRoundDelayedFps(const LpiADOVector<int> & turnRoundDelayedFps)
{
   r_turn_round_delayed_fps = turnRoundDelayedFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getTurnRoundDelayedFpsFps() const
{
   return r_turn_round_delayed_fps_fps;
}


void LpdbSCHTimedData::setTurnRoundDelayedFpsFps(const LpiADOVector<vector<string> > & turnRoundDelayedFpsFps)
{
   r_turn_round_delayed_fps_fps = turnRoundDelayedFpsFps;
}


//Shortage
LpiADOVector<int> LpdbSCHTimedData::getShortage() const
{
   return r_shortage;
}


void LpdbSCHTimedData::setShortage(const LpiADOVector<int> & shortage)
{
   //Phase II: Store backup for delta KPIs calculations
   r_shortage_previous = r_shortage;
   r_shortage = shortage;
}


//Real demand

LpiADOVector<int> LpdbSCHTimedData::getRealDemandFps() const
{
   return r_real_demand_fps;
}


void LpdbSCHTimedData::setRealDemandFps(const LpiADOVector<int> & realDemandFps)
{
   r_real_demand_fps = realDemandFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getRealDemandFpsFps() const
{
   return r_real_demand_fps_fps;
}


void LpdbSCHTimedData::setRealDemandFpsFps(const LpiADOVector<vector<string> > & realDemandFpsFps)
{
   r_real_demand_fps_fps = realDemandFpsFps;
}

//Real accepted

LpiADOVector<int> LpdbSCHTimedData::getRealAcceptedFps() const
{
   return r_real_accepted_fps;
}


void LpdbSCHTimedData::setRealAcceptedFps(const LpiADOVector<int> & realAcceptedFps)
{
   r_real_accepted_fps = realAcceptedFps;
}


LpiADOVector<vector<string> > LpdbSCHTimedData::getRealAcceptedFpsFps() const
{
   return r_real_accepted_fps_fps;
}


void LpdbSCHTimedData::setRealAcceptedFpsFps(const LpiADOVector<vector<string> > & realAcceptedFpsFps)
{
   r_real_accepted_fps_fps = realAcceptedFpsFps;
}

//Capacity

LpiADOVector<int> LpdbSCHTimedData::getMaxCapacity() const
{
   return r_max_capacity;
}


void LpdbSCHTimedData::setMaxCapacity(const LpiADOVector<int> & maxCapacity)
{
   //Phase II: Store backup for delta KPIs calculations
   r_max_capacity_previous = r_max_capacity;
   r_max_capacity = maxCapacity;
}


LpiADOVector<int> LpdbSCHTimedData::getRealDcMargin() const
{
   return r_real_dc_margin;
}


void LpdbSCHTimedData::setRealDcMargin(const LpiADOVector<int> & realDcMargin)
{
   r_real_dc_margin = realDcMargin;
}


LpiADOVector<int> LpdbSCHTimedData::getSurplus() const
{
   return r_surplus;
}


void LpdbSCHTimedData::setSurplus(const LpiADOVector<int> & surplus)
{
   r_surplus = surplus;
}


LpdbSCHTimedData & LpdbSCHTimedData::operator= (const LpdbSCHTimedData & source)
{
   if (this != &source)
   {
      r_name = source.r_name;
      r_rs_scheduled = source.r_rs_scheduled;

      r_default_delayed_fps = source.r_default_delayed_fps;
      r_default_delayed_fps_fps = source.r_default_delayed_fps_fps;
      r_shortage = source.r_shortage;
      r_real_delayed_fps = source.r_real_delayed_fps;
      r_real_delayed_fps_fps = source.r_real_delayed_fps_fps;
      r_delayed_fps = source.r_delayed_fps;
      r_delayed_fps_fps = source.r_delayed_fps_fps;
      r_not_allowed_delayed_fps = source.r_not_allowed_delayed_fps;
      r_not_allowed_delayed_fps_fps = source.r_not_allowed_delayed_fps_fps;
      r_turn_round_delayed_fps = source.r_turn_round_delayed_fps;
      r_turn_round_delayed_fps_fps = source.r_turn_round_delayed_fps_fps;

      r_real_demand_fps = source.r_real_demand_fps;
      r_real_demand_fps_fps = source.r_real_demand_fps_fps;

      r_total_demand = source.r_total_demand;
      r_inherited_demand = source.r_inherited_demand;
      r_intentional_demand = source.r_intentional_demand;

      r_real_accepted_fps = source.r_real_accepted_fps;
      r_real_accepted_fps_fps =source.r_real_accepted_fps_fps;

      r_max_capacity = source.r_max_capacity;
      r_real_dc_margin = source.r_real_dc_margin;
      r_surplus = source.r_surplus;
      r_rwys_max_capacity = source.r_rwys_max_capacity;

      //Phase II
      r_max_capacity_previous = source.r_max_capacity_previous;
      r_rwys_max_capacity_previous = source.r_rwys_max_capacity;
      r_shortage_previous = source.r_shortage_previous;

      r_deltaKPIs = source.r_deltaKPIs;
      r_relativeKPIs = source.r_relativeKPIs;
   }

   return *this;
}


LpiADOVector<int> LpdbSCHTimedData::getTotalDemand() const
{
   return r_total_demand;
}


LpiADOVector<int> LpdbSCHTimedData::getInheritedDemand() const
{
   return r_inherited_demand;
}


LpiADOVector<int> LpdbSCHTimedData::getIntentionalDemand() const
{
   return r_intentional_demand;
}


LpiADOVector<int> LpdbSCHTimedData::getRwysMaxCapacity() const
{
   return r_rwys_max_capacity;
}


void LpdbSCHTimedData::setTotalDemand(const LpiADOVector<int> & value)
{
   r_total_demand = value;
}


void LpdbSCHTimedData::setInheritedDemand(const LpiADOVector<int> & value)
{
   r_inherited_demand = value;
}


void LpdbSCHTimedData::setIntentionalDemand(const LpiADOVector<int> & value)
{
   r_intentional_demand = value;
}


void LpdbSCHTimedData::setRwysMaxCapacity(LpiADOVector<int> maxCapacity)
{
   //Phase II: Store backup for delta KPIs calculations
   r_rwys_max_capacity_previous = r_rwys_max_capacity;
   r_rwys_max_capacity = maxCapacity;
}


string LpdbSCHTimedData::getFPKeysVectorAsString (const LpiADOVector<vector<string> > & data,
                                                      bool showPriorities)
{
   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   std::stringstream out_stream;

   out_stream << "[";

   for (int i = E_ARR; i<= E_OVA; i++)
   {
      vector<string> flight_plan_ids = data[i];

      out_stream << "(";
      for (unsigned int j = 0; j < flight_plan_ids.size(); ++j)
      {
         std::string fpKey = flight_plan_ids[j];

         if (fpTable.exists(fpKey))
         {
            LpiFlightPlan fp = fpTable[fpKey];
            out_stream << fp.getCallsign();

	    ///@todo FIXME: getPriorityArrival() & getPriorityDeparture()
         // if (showPriorities)
         // {
         //    out_stream << " - P: " << fp.getPriority();
         // }
         }

         if (j != flight_plan_ids.size() - 1)
         {
            out_stream << ", ";
         }
      }
      out_stream << ")";
   }

   out_stream << "]";
   return out_stream.str();
}


void LpdbSCHTimedData::resetComparativeKPIs()
{
   r_deltaKPIs.reset();
   r_relativeKPIs.reset();
}

/*
void LpdbSCHTimedData::generateComparativeKPIs (string interval,
                                               LpiConfigurationAlertKPIs & alertThresholds,
                                               bool isClockForwarding,
                                               bool isLastInterval)
{
   if (!isClockForwarding)
   {
      generateDeltaKPIs(alertThresholds);
   }
   else
   {
      if (isLastInterval)
      {
         r_deltaKPIs.reset();
      }
   }

   generateRelativeKPIs(interval, alertThresholds);
}
*/

/*
void LpdbSCHTimedData::generateDeltaKPIs(LpiConfigurationAlertKPIs & alertThresholds)
{
   //New - previous
   r_deltaKPIs.calculateValues(r_max_capacity,
                               r_rwys_max_capacity,
                               r_shortage,
                               r_rs_scheduled.getAirportIntervalKpis(),
                               r_max_capacity_previous,
                               r_rwys_max_capacity_previous,
                               r_shortage_previous,
                               r_rs_scheduled.getAirportIntervalPreviousKpis());

   r_deltaKPIs.generateAlerts(alertThresholds, LpdbAirportIntervalComparativeKPIs::E_DELTA);
}
*/

/*
void LpdbSCHTimedData::generateRelativeKPIs(string interval, LpiConfigurationAlertKPIs & alertThresholds)
{
   //Optimal - Active
   bool existsOptimal = LpdbDataBase::Get().hasOptimalSchedule();
   if (existsOptimal)
   {
      LpdbSchedule & optimal = LpdbDataBase::Get().getOptimalSchedule();

      if (optimal.has_data(interval))
      {
         LpdbSCHTimedData & interval_data = optimal[interval];

         if (this != &interval_data)
         {
            r_relativeKPIs.calculateValues(interval_data.getMaxCapacity(),
                                           interval_data.getRwysMaxCapacity(),
                                           interval_data.getShortage(),
                                           interval_data.getRsScheduled().getAirportIntervalKpis(),
                                           r_max_capacity,
                                           r_rwys_max_capacity,
                                           r_shortage,
                                           r_rs_scheduled.getAirportIntervalKpis());

            r_relativeKPIs.generateAlerts(alertThresholds, LpdbAirportIntervalComparativeKPIs::E_RELATIVE);
         }
      }
   }
}
*/

/*
void LpdbSCHTimedData::generateRelativeKPIs(LpdbSCHTimedData & interval_data,
                                           LpiConfigurationAlertKPIs & alertThresholds)
{
   if (this != &interval_data)
   {
      r_relativeKPIs.calculateValues(r_max_capacity,
                                     r_rwys_max_capacity,
                                     r_shortage,
                                     r_rs_scheduled.getAirportIntervalKpis(),
                                     interval_data.getMaxCapacity(),
                                     interval_data.getRwysMaxCapacity(),
                                     interval_data.getShortage(),
                                     interval_data.getRsScheduled().getAirportIntervalKpis());

      r_relativeKPIs.generateAlerts(alertThresholds, LpdbAirportIntervalComparativeKPIs::E_RELATIVE);
   }
}
*/

std::string LpdbSCHTimedData::getAbsoluteKpisAsString() const
{
   std::stringstream kpisStream;

  /* kpisStream << "[MAX_CAP :" << r_max_capacity
              << " | RWY_MAX_CAP: " << r_rwys_max_capacity
              << " | SHTG: " << r_shortage
              << "\n"
              << r_rs_scheduled.getAirportIntervalKpis() << ']';*/

   return kpisStream.str();
}


std::ostream& operator<<(std::ostream &os, const LpdbSCHTimedData &info)
{
   bool showPriorities = true;
   string real_demand_fps_ids = LpdbSCHTimedData::getFPKeysVectorAsString(info.getRealDemandFpsFps(), showPriorities);

   string delayed_fps_ids = LpdbSCHTimedData::getFPKeysVectorAsString(info.getDelayedFpsFps());
   string real_delayed_fps_ids = LpdbSCHTimedData::getFPKeysVectorAsString(info.getRealDelayedFpsFps());
   string real_accepted_fps_ids = LpdbSCHTimedData::getFPKeysVectorAsString(info.getRealAcceptedFpsFps());
   string delayed_not_allowed_fps_ids = LpdbSCHTimedData::getFPKeysVectorAsString(info.getNotAllowedDelayedFpsFps());
   string delayed_turn_round_fps_ids = LpdbSCHTimedData::getFPKeysVectorAsString(info.getTurnRoundDelayedFpsFps());

   return os << "[RS: " << info.getRsScheduled()
             << " | REAL_DMND: " << info.getRealDemandFps()
             << " | DLY_NOT_ALLWD: " << info.getNotAllowedDelayedFps()
             << " | DLY_TURN_ROUND: " << info.getTurnRoundDelayedFps()
             << " | DLYD: " << info.getDelayedFps()
             << " | SURPLUS: " << info.getSurplus()
             << " | REAL_DLYD: " << info.getRealDelayedFps()
             << " | REAL_ACPT: " << info.getRealAcceptedFps()
             << " | REAL_DMND_FPs: " << real_demand_fps_ids
             << " | DLY_NOT_ALLWD_FPs: " << delayed_not_allowed_fps_ids
             << " | DLY_TURN_ROUND_FPs: " << delayed_turn_round_fps_ids
             << " | DLYD_FPs: " << delayed_fps_ids
             << " | REAL_DLYD_FPs: " << real_delayed_fps_ids
             << " | REAL_ACPT_FPs: " << real_accepted_fps_ids
             << ']';
}
