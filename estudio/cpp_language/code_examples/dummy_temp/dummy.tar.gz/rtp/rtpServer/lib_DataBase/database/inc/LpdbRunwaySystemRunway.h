/*
 * LpdbRunwaySystemRunway.h
 *
 *  Created on: 17/02/2014
 *      Author: mbegega
 */

#ifndef LPBRUNWAYSYSTEMRUNWAY_H_
#define LPBRUNWAYSYSTEMRUNWAY_H_

#include <string>
#include <map>
#include <vector>
#include <utility>

#include <LctimTimeLine.h>
#include <LpiTimeParameters.h>
#include <LpiAdaptationRunwaySystem.h>
#include "LpdbRunwaySystemRunwayTimedData.h"


using std::string;
using std::map;
using std::pair;
using std::vector;



//Emulates an NxM relationship entity
//Defines the using of a Runway in a Runway System
//Runway Exists in Runways DataTable

class LpdbRunwaySystemRunway
{
   public:

      LpdbRunwaySystemRunway();
      LpdbRunwaySystemRunway(string id, OperationType::Enum use, int max_capacity = 0);
      LpdbRunwaySystemRunway(const LpdbRunwaySystemRunway & source);

      LpdbRunwaySystemRunway & operator= (const LpdbRunwaySystemRunway & source);

      string getId() const
      { return r_id; }

      OperationType::Enum getUse() const
      { return r_use; }

      int getMaxCapacity() const
      { return r_max_capacity; }

      void setId(string id)
      { r_id = id; }

      void setUse(OperationType::Enum use)
      { r_use = use; }

      void setMaxCapacity(int capacity)
      { r_max_capacity = capacity; }

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbRunwaySystemRunwayTimedData & operator[] (const string & interval_name);

      //stablish timeline
      void init(const LpiTimeParameters & timeData,
                boost::posix_time::ptime begin_timestamp);

      void forwardTimeline();
      TimeLine<LpdbRunwaySystemRunwayTimedData> getTimeLine() const;


   private:

      string r_id;
      OperationType::Enum r_use;
      int r_max_capacity;

      TimeLine<LpdbRunwaySystemRunwayTimedData> r_timeLine;
};


#endif /* LPBRUNWAYSYSTEMRUNWAY_H_ */
