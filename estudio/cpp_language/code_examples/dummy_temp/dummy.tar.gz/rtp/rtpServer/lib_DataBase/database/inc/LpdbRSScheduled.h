/*
 * LpdbRSScheduled.h
 *
 *  Created on: 12/12/2013
 *      Author: mbegega
 */

#ifndef LPBRSSCHEDULED_H_
#define LPBRSSCHEDULED_H_

#include <string>
#include <map>

#include <boost/date_time/posix_time/posix_time.hpp>

#include <LpiOperationType.h>

#include "LpdbRunwaySystem.h"
#include "LpdbRwyScheduled.h"
#include "LpdbAirportIntervalKPIs.h"

#include <LclogStream.h>


class LpdbRSScheduled
{
   public:

      LpdbRSScheduled ();
      LpdbRSScheduled (std::string id);

      LpdbRSScheduled (const LpdbRunwaySystem & rs);
      LpdbRSScheduled (const LpdbRSScheduled & source);

      virtual ~LpdbRSScheduled() {}

      LpdbRSScheduled & operator= (const LpdbRSScheduled & source);

      //Getters and setters

      std::string getRunwaySystemId () const;
      void        setRunwaySystemId (std::string id);
      int         getNumberOfRunways () const;
      std::map<std::string, LpdbRwyScheduled> getRunways() const;
      std::map<std::string, LpdbRwyScheduled> & getRunways(); //for modification

      LpdbAirportIntervalKPIs getAirportIntervalKpis() const
      { return r_absolute_airport_kpis; }

      LpdbAirportIntervalKPIs getAirportIntervalPreviousKpis() const
      { return r_absolute_airport_kpis_previous; }

      //Internal Runways Management

      void addRunway    (const std::string & runway_id);
      void deleteRunway (const std::string & runway_id);

      void addRunways   (const std::map<std::string, LpdbRunwaySystemRunway> & rwys);

      bool exists (const std::string & runway_id);
      LpdbRwyScheduled & operator[] (const std::string & runway_id);

      bool hasMixedRunways () const;

      void calculateMaximumCapacities(string interval);

      //Methods used in FP runway allocation
      vector<string> getAvailableRunways (int use_type);
      vector<string> getAllRunwaysByUse  (int use_type);
      vector<string> getAllRunwaysIds();
      string selectPreferentialRunway(vector<string> runways,
                                      vector<string> preferential_runways,
                                      LpiOperationType::LpiEnum fp_type);

      //Gets next allowed runway of specified type in "runways" sequence
      int selectNextAllowedRunway(vector<string> runways,
                                  vector<string> not_allowed,
                                  LpiOperationType::LpiEnum fp_type,
                                  int current_runway);

      bool containsAllNotAllowed(vector<string>runways,
                                 vector<string>not_allowed,
                                 LpiOperationType::LpiEnum fp_type);

      int selectNextRunwayByUse(vector<string>runways,
                                LpiOperationType::LpiEnum fp_type,
                                unsigned int current_runway);

      map<string, int> getAvailableRunwaysAndCapacities (int use_type);

      string getAvailAbleRunwayOfMaxCapacity (int use_type);

      int  getActualCapacity (string runway);
      bool isAvailable (string runway);
      bool isAvailable (string runway, int use);
      bool isSameUse(string runway, int use);
      bool isCompatibleUse(string runway, LpiOperationType::LpiEnum use);

      LpiADOVector<int> getScheduledRunwayCapacity(string runway, string interval);

      void resetAllocation();

      string selectRunwayWithMaxAvailableCap(vector<string> runway_set);

      int getNumberOfArrivalRunways() const;
      int getNumberOfDepartureRunways() const;

      //KPIs Generation Phase 2
//      void generateRunwayAndAirportIntervalKPIs(string interval,
//                                                map<string, LpdbFPSchedule> & scheduled_fps,
//                                                map<string, LpdbFPSchedule> & delayed_fps_last_interval,
//                                                const LpiADOVector<vector<string> > & accepted_fps,
//                                                const LpiADOVector<vector<string> > & delayed_fps,
//                                                LpiConfigurationAlertKPIs & alertThresholds,
//                                                int delayCountThreshold);

      void printRunwaysKPIs();

   protected:

      std::string r_runwaySystemId;
      std::map<std::string, LpdbRwyScheduled> r_runways;

      bool r_has_mixed_runways;

      //Previous values backup for delta KPIs calculations
      LpdbAirportIntervalKPIs r_absolute_airport_kpis_previous;

      LpdbAirportIntervalKPIs r_absolute_airport_kpis;

      int r_number_of_arrival_runways;
      int r_number_of_departure_runways;
};


std::ostream& operator<<(std::ostream &os, const LpdbRSScheduled &info);

#endif /* LPBRSSCHEDULED_H_ */
