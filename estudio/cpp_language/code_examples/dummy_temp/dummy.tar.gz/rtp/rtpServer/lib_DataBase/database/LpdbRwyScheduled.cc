/*
 * LpdbRwyScheduled.cc
 *
 *  Created on: 11/12/2013
 *      Author: mbegega
 */

#include <cmath>
#include <boost/foreach.hpp>
#include "LctimTimeUtils.h"
#include "LpdbRwyScheduled.h"
//#include <LpiFlightPlan.h>
#include <LpdbDataBase.h>


LpdbRwyScheduled::LpdbRwyScheduled()
: r_absoluteKPIs(),
  r_availableFTOTs(),
  r_availableFLDTs(),
  r_availableFTOTsForLog(),
  r_availableFLDTsForLog()
{
}


LpdbRwyScheduled::LpdbRwyScheduled(string id)
:r_rwyId(id), r_max_capacity(0), r_actual_capacity(0), r_slot(0.0),
 r_absoluteKPIs(),
 r_availableFTOTs(),
 r_availableFLDTs(),
 r_availableFTOTsForLog(),
 r_availableFLDTsForLog()
{
}


LpdbRwyScheduled::LpdbRwyScheduled(string id, OperationType::Enum usage)
:r_rwyId(id), r_usage(usage),  r_max_capacity(0), r_actual_capacity(0), r_slot(0.0),
 r_absoluteKPIs(),
 r_availableFTOTs(),
 r_availableFLDTs(),
 r_availableFTOTsForLog(),
 r_availableFLDTsForLog()
{
}


LpdbRwyScheduled::LpdbRwyScheduled(const LpdbRwyScheduled & source)
:r_rwyId(source.r_rwyId),
 r_usage(source.r_usage),
 r_usage_capacity(source.r_usage_capacity),
 r_allocated_fps(source.r_allocated_fps),
 r_delayed_fps(source.r_delayed_fps),
 r_total_allocated_fps(source.r_total_allocated_fps),
 r_total_delayed_fps(source.r_total_delayed_fps),
 r_number_of_allocated_fps(source.r_number_of_allocated_fps),
 r_number_of_delayed_fps(source.r_number_of_delayed_fps),
 r_allocated_fps_fps(source.r_allocated_fps_fps),
 r_delayed_fps_fps(source.r_delayed_fps_fps),
 r_max_capacity(source.r_max_capacity),
 r_actual_capacity(source.r_actual_capacity),
 r_slot(source.r_slot),
 r_absoluteKPIs(source.r_absoluteKPIs),
 r_availableFTOTs(source.r_availableFTOTs),
 r_availableFLDTs(source.r_availableFLDTs),
 r_availableFTOTsForLog(source.r_availableFTOTsForLog),
 r_availableFLDTsForLog(source.r_availableFLDTsForLog)
{
}


LpdbRwyScheduled& LpdbRwyScheduled::operator =(const LpdbRwyScheduled& source)
{
   if (this != &source)
   {
      r_rwyId= source.r_rwyId;
      r_usage= source.r_usage,
      r_usage_capacity= source.r_usage_capacity;
      r_allocated_fps_fps= source.r_allocated_fps_fps;
      r_allocated_fps= source.r_allocated_fps;
      r_delayed_fps = source.r_delayed_fps;
      r_total_allocated_fps = source.r_total_allocated_fps;
      r_total_delayed_fps = source.r_total_delayed_fps;
      r_delayed_fps_fps = source.r_delayed_fps_fps;
      r_number_of_allocated_fps = source.r_number_of_allocated_fps;
      r_number_of_delayed_fps = source.r_number_of_delayed_fps;
      r_max_capacity = source.r_max_capacity;
      r_actual_capacity = source.r_actual_capacity;
      r_slot = source.r_slot;
      r_absoluteKPIs = source.r_absoluteKPIs;
      r_availableFTOTs = source.r_availableFTOTs;
      r_availableFLDTs = source.r_availableFLDTs;
      r_availableFTOTsForLog = source.r_availableFTOTsForLog;
      r_availableFLDTsForLog = source.r_availableFLDTsForLog;
   }
   return *this;
}


bool LpdbRwyScheduled::isAllocated  (string fp_key)
{
   return (r_allocated_fps.count(fp_key) > 0);
}


void LpdbRwyScheduled::allocateFP(LpdbFPAllocated flight_plan)
{
   r_allocated_fps[flight_plan.getUniqueKey()]= flight_plan;
}


void LpdbRwyScheduled::deAllocateFP (string fp_key)
{
   if (r_allocated_fps.count(fp_key))
   {
      r_allocated_fps.erase(fp_key);
   }
}


void LpdbRwyScheduled::allocateFPs(int fp_type, int real_accepted, vector<string> real_accepted_fp_ids)
{
   r_number_of_allocated_fps.reset();
   r_number_of_allocated_fps[fp_type] = real_accepted;
   r_number_of_allocated_fps[E_OVA] = real_accepted;

   r_allocated_fps_fps[fp_type] = real_accepted_fp_ids;
   r_allocated_fps_fps[E_OVA] = real_accepted_fp_ids;

   r_allocated_fps.clear();

   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   BOOST_FOREACH(string fpKey, real_accepted_fp_ids)
   {
      if (fpTable.exists(fpKey))
      {
         LpiFlightPlan & fp = fpTable[fpKey];

         std::string callsign  = fp.getCallsign();
         std::string departure = fp.getDepartureAerodrome();
         std::string arrival   = fp.getArrivalAerodrome();
         boost::optional<posix_time::ptime> eobt = fp.getDepartureTimes().getEobt();

         LpdbFPAllocated flight_plan(fpKey, callsign, departure, arrival, eobt);
         r_allocated_fps[fpKey] = flight_plan;
      }
   }
}


void LpdbRwyScheduled::delayFPs(int fp_type, int real_delayed, vector<string> real_delayed_fp_ids)
{
   r_number_of_delayed_fps.reset();
   r_number_of_delayed_fps[fp_type] = real_delayed;
   r_number_of_delayed_fps[E_OVA] = real_delayed;

   r_delayed_fps_fps[fp_type] = real_delayed_fp_ids;
   r_delayed_fps_fps[E_OVA] = real_delayed_fp_ids;

   r_delayed_fps.clear();

   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   BOOST_FOREACH(string fpKey, real_delayed_fp_ids)
   {
      if (fpTable.exists(fpKey))
      {
         LpiFlightPlan & fp = fpTable[fpKey];

         std::string callsign  = fp.getCallsign();
         std::string departure = fp.getDepartureAerodrome();
         std::string arrival   = fp.getArrivalAerodrome();
         boost::optional<posix_time::ptime> eobt = fp.getDepartureTimes().getEobt();

         LpdbFPDelayed flight_plan(fpKey, callsign, departure, arrival, eobt);
         r_delayed_fps[fpKey] = flight_plan;
      }
   }
}


void LpdbRwyScheduled::allocateFlightPlan(int fp_type, string fp_id)
{
   r_number_of_allocated_fps[fp_type] = r_number_of_allocated_fps[fp_type] + 1;
   r_number_of_allocated_fps[E_OVA]   = r_number_of_allocated_fps[E_OVA] + 1;

   r_allocated_fps_fps[fp_type].push_back(fp_id);
   r_allocated_fps_fps[E_OVA].push_back(fp_id);

   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   if (fpTable.exists(fp_id))
   {
      LpiFlightPlan & fp = fpTable[fp_id];

      std::string callsign  = fp.getCallsign();
      std::string departure = fp.getDepartureAerodrome();
      std::string arrival   = fp.getArrivalAerodrome();
      boost::optional<posix_time::ptime> eobt = fp.getDepartureTimes().getEobt();

      LpdbFPAllocated flight_plan(fp_id, callsign, departure, arrival, eobt);
   r_allocated_fps[fp_id] = flight_plan;
   }

   r_actual_capacity = r_actual_capacity - 1;
}


void LpdbRwyScheduled::allocateFlightPlan(LpiOperationType::LpiEnum fp_type, string fp_id)
{
   int operation = E_ARR;

   switch(fp_type)
   {
      case LpiOperationType::E_ARRIVAL:
         operation = E_ARR;
      break;
      case LpiOperationType::E_DEPARTURE:
         operation = E_DEP;
      break;
      default:
      break;
   }

   allocateFlightPlan(operation, fp_id);
}


void LpdbRwyScheduled::delayFlightPlan(int fp_type, string fp_id)
{
   //Capacity isn't affected

   r_number_of_delayed_fps[fp_type] = r_number_of_delayed_fps[fp_type] + 1;
   r_number_of_delayed_fps[E_OVA]   = r_number_of_delayed_fps[E_OVA] + 1;

   r_delayed_fps_fps[fp_type].push_back(fp_id);
   r_delayed_fps_fps[E_OVA].push_back(fp_id);

   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   if (fpTable.exists(fp_id))
   {
      LpiFlightPlan & fp = fpTable[fp_id];

      std::string callsign  = fp.getCallsign();
      std::string departure = fp.getDepartureAerodrome();
      std::string arrival   = fp.getArrivalAerodrome();
      boost::optional<posix_time::ptime> eobt = fp.getDepartureTimes().getEobt();

      LpdbFPDelayed flight_plan(fp_id, callsign, departure, arrival, eobt);
   r_delayed_fps[fp_id] = flight_plan;
   }
}


void LpdbRwyScheduled::delayFlightPlan(LpiOperationType::LpiEnum fp_type, string fp_id)
{
   int operation = E_ARR;

   switch(fp_type)
   {
      case LpiOperationType::E_ARRIVAL:
         operation = E_ARR;
      break;
      case LpiOperationType::E_DEPARTURE:
         operation = E_DEP;
      break;
      default:
      break;
   }

   delayFlightPlan(operation, fp_id);
}


void LpdbRwyScheduled::resetAllocation ()
{
   r_number_of_allocated_fps.reset();
   r_allocated_fps_fps.reset();
   r_allocated_fps.clear();

   r_number_of_delayed_fps.reset();
   r_delayed_fps_fps.reset();
   r_delayed_fps.clear();

   r_actual_capacity = r_max_capacity;
}


LpdbFPAllocated & LpdbRwyScheduled::operator[] (string fp_key)
{
   return r_allocated_fps[fp_key];
}


bool LpdbRwyScheduled::isDelayed  (string fp_key)
{
   return (r_delayed_fps.count(fp_key) > 0);
}


void LpdbRwyScheduled::delayedFP(LpdbFPDelayed flight_plan)
{
   r_delayed_fps[flight_plan.getUniqueKey()]= flight_plan;
}


void LpdbRwyScheduled::deDelayedFP (string fp_key)
{
   if (r_delayed_fps.count(fp_key))
   {
      r_delayed_fps.erase(fp_key);
   }
}

LpiADOVector<int> LpdbRwyScheduled::getTotalAcceptedFps() const
{
       
    return r_total_allocated_fps;
}

LpiADOVector<int> LpdbRwyScheduled::getTotalDelayedFps() const
{
    
    return r_total_delayed_fps;

}


map<string, LpdbFPAllocated> LpdbRwyScheduled::getAllocatedFps() const
{
   return r_allocated_fps;
}


void LpdbRwyScheduled::setAllocatedFps(map<string, LpdbFPAllocated> allocatedFps)
{
   r_allocated_fps = allocatedFps;
}


void LpdbRwyScheduled::setDelayedFps(map<string, LpdbFPDelayed> delayedFps)
{
   r_delayed_fps = delayedFps;
}

map<string, LpdbFPDelayed> LpdbRwyScheduled::getDelayedFps() const
{
   return r_delayed_fps;
}


LpiADOVector<vector<string> > LpdbRwyScheduled::getAllocatedFpsFps() const
{
   return r_allocated_fps_fps;
}


void LpdbRwyScheduled::setAllocatedFpsFps(LpiADOVector<vector<string> > allocatedFpsFps)
{
   r_allocated_fps_fps = allocatedFpsFps;
   r_total_allocated_fps[E_ARR] = r_allocated_fps_fps[E_ARR].size();
   r_total_allocated_fps[E_DEP] = r_allocated_fps_fps[E_DEP].size();
   r_total_allocated_fps[E_OVA] = r_allocated_fps_fps[E_OVA].size();
}


LpiADOVector<vector<string> > LpdbRwyScheduled::getDelayedFpsFps() const
{
   return r_delayed_fps_fps;
}


void LpdbRwyScheduled::setDelayedFpsFps(LpiADOVector<vector<string> > delayedFpsFps)
{
   r_delayed_fps_fps = delayedFpsFps;
   r_total_delayed_fps[E_ARR] = r_delayed_fps_fps[E_ARR].size();
   r_total_delayed_fps[E_DEP] = r_delayed_fps_fps[E_DEP].size();
   r_total_delayed_fps[E_OVA] = r_delayed_fps_fps[E_OVA].size();
}

string LpdbRwyScheduled::getRwyId() const
{
   return r_rwyId;
}


void LpdbRwyScheduled::setRwyId(string rwyId)
{
   r_rwyId = rwyId;
}


LpiADOVector<int> LpdbRwyScheduled::getUsageCapacity() const
{
   return r_usage_capacity;
}


void LpdbRwyScheduled::setUsageCapacity(LpiADOVector<int> usageCapacity)
{
   r_usage_capacity = usageCapacity;
}


LpiADOVector<int> LpdbRwyScheduled::getNumberOfAllocatedFps() const
{
   return r_number_of_allocated_fps;
}


void LpdbRwyScheduled::setNumberOfAllocatedFps(LpiADOVector<int> allocatedFps)
{
   r_number_of_allocated_fps = allocatedFps;
}


LpiADOVector<int> LpdbRwyScheduled::getNumberOfDelayedFps() const
{
   return r_number_of_delayed_fps;
}


void LpdbRwyScheduled::setNumberOfDelayedFps(LpiADOVector<int> delayedFps)
{
   r_number_of_delayed_fps = delayedFps;
}


OperationType::Enum LpdbRwyScheduled::getUsage() const
{
   return r_usage;
}


void LpdbRwyScheduled::setUsage (OperationType::Enum usage)
{
   r_usage = usage;
}


int  LpdbRwyScheduled::getMaxCapacity () const
{
   return r_max_capacity;
}


void LpdbRwyScheduled::setMaxCapacity (int capacity)
{
   r_max_capacity = capacity;
}


int  LpdbRwyScheduled::getActualCapacity () const
{
   return r_actual_capacity;
}


void LpdbRwyScheduled::setActualCapacity (int capacity)
{
   r_actual_capacity = capacity;
}


void LpdbRwyScheduled::setSlot(int value)
{
   r_slot = value;
}


int LpdbRwyScheduled::getSlot() const
{
   return r_slot;
}


void LpdbRwyScheduled::calculateSlot(int minutesSubinterval)
{
   if (r_max_capacity > 0)
   {
      double calculatedSlot = std::floor(static_cast<double>(minutesSubinterval) /
                                         static_cast<double>(r_max_capacity));

      r_slot = (calculatedSlot < 0.5) ? 1 : static_cast<int>(calculatedSlot);
   }
   else
   {
      r_slot = 1;
   }
}


void LpdbRwyScheduled::calculateSlot(int minutesSubinterval, LpiADOVector<int> capacity)
{
   int capacity_by_usage = -1;

   switch (r_usage)
   {
      case OperationType::E_ARRIVALS:
         capacity_by_usage = capacity[E_ARR];
      break;
      case OperationType::E_DEPARTURES:
         capacity_by_usage = capacity[E_DEP];
      break;
      case OperationType::E_MIXED:
         capacity_by_usage = capacity[E_OVA];
      break;
      case OperationType::E_INVALID_RWY_OPERATION_TYPE:
      default:
      break;
   }

   r_slot = 1;

   if (capacity_by_usage > 0)
   {
      double calculatedSlot = std::floor(static_cast<double>(minutesSubinterval) /
                                         static_cast<double>(capacity_by_usage));

      r_slot = (calculatedSlot < 0.5) ? 1 : static_cast<int>(calculatedSlot);
   }
}



bool LpdbRwyScheduled::isAvailable () const
{
   return r_actual_capacity > 0;
}

/*
void LpdbRwyScheduled::generateRunwayIntervalKPIs(string interval,
                                                 map<string, LpdbFPSchedule> & scheduled_fps,
                                                 map<string, LpdbFPSchedule> & delayed_fps_last_interval,
                                                 LpiConfigurationAlertKPIs & alertThresholds,
                                                 int delayCountThreshold)
{
   r_absoluteKPIs.reset();

   r_absoluteKPIs.generateAbsoluteKPIs(interval,
                                       r_delayed_fps_fps,
                                       r_allocated_fps_fps,
                                       scheduled_fps,
                                       delayed_fps_last_interval,
                                       delayCountThreshold);

   r_absoluteKPIs.generateAlerts(interval, r_usage, alertThresholds);
}
*/

void LpdbRwyScheduled::calculateAvailableFTOTsAndFLDTs(const boost::posix_time::ptime & intervalBeginTime,
                                                      const LpiADOVector<vector<string> > & flights)
{
   if (r_usage == OperationType::E_ARRIVALS)
   {
      int numberOfFlights = flights[E_ARR].size();

      if (numberOfFlights > 0)
      {
         r_availableFLDTs.clear();
         r_availableFLDTsForLog.clear();
      }

      for (int i = 0; i < numberOfFlights; ++i)
      {
         boost::posix_time::ptime fldt = intervalBeginTime + minutes(i * r_slot);

         r_availableFLDTs.push_back(fldt);
         r_availableFLDTsForLog.push_back(fldt);
      }
   }
   else if (r_usage == OperationType::E_DEPARTURES)
   {
      int numberOfFlights = flights[E_DEP].size();

      if (numberOfFlights > 0)
      {
         r_availableFTOTs.clear();
         r_availableFTOTsForLog.clear();
      }

      for (int i = 0; i < numberOfFlights; ++i)
      {
         boost::posix_time::ptime ftot = intervalBeginTime + minutes(i * r_slot);

         r_availableFTOTs.push_back(ftot);
         r_availableFTOTsForLog.push_back(ftot);
      }
   }
}


std::string LpdbRwyScheduled::getAvailableFTOTAndFLDTsAsString()
{
   std::stringstream ftotfldtStream;

   ftotfldtStream << "[" << r_rwyId << " - ";

   if (r_availableFTOTsForLog.size() > 0)
   {
      ftotfldtStream << " AVAILABLE FTOTs:\n";
      for (unsigned int i = 0; i < r_availableFTOTsForLog.size(); ++i)
      {
         ftotfldtStream << '\t' << i << ": " << LctimTimeUtils::formatTime(r_availableFTOTsForLog[i]) << "\n";
      }
   }

   if (r_availableFLDTsForLog.size() > 0)
   {
      ftotfldtStream << " AVAILABLE FLDTs:\n";

      for (unsigned int i = 0; i < r_availableFLDTsForLog.size(); ++i)
      {
         ftotfldtStream << '\t' << i << ": " << LctimTimeUtils::formatTime(r_availableFLDTsForLog[i]) << "\n";
      }
   }

   ftotfldtStream << "\t]";

   return ftotfldtStream.str();
}
