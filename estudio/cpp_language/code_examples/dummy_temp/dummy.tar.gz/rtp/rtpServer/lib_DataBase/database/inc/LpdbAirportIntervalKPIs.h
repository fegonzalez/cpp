/*
 * LpdbAirportIntervalKPIs.h
 *
 *  Created on: 21/10/2014
 *  Author:
 */

#ifndef LPB_AIRPORT_INTERVAL_KPIS_H
#define LPB_AIRPORT_INTERVAL_KPIS_H

#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <boost/foreach.hpp>
#include <LpiADOVector.h>

#include "LpiWarningsAlerts.h"

#include "LpdbRunwayIntervalKPIs.h"

using std::string;
using std::vector;
using std::map;

class LpdbAirportIntervalKPIs
{
   public:

      LpdbAirportIntervalKPIs();
      LpdbAirportIntervalKPIs(const LpdbAirportIntervalKPIs & source);

      virtual ~LpdbAirportIntervalKPIs() {}

      LpdbAirportIntervalKPIs & operator= (const LpdbAirportIntervalKPIs & source);

      void reset();

      //Velues
      LpiADOVector<double> getMaxForecastedDelay()     const { return r_max_forecasted_delay; }
      LpiADOVector<double> getAverageForecastedDelay_DelayedFps() const { return r_average_forecasted_delay_delayedfps; }
      LpiADOVector<double> getPunctualFlights()        const { return r_punctual_flights; }
      LpiADOVector<double> getPunctualityPercentage()  const { return r_punctuality_percentage; }
      LpiADOVector<double> getAccumulatedRunwaysDemandForecast() const { return r_accumulated_rwys_demand_forecast; }

      //Alerts
      Warnings_alerts getMaxForecastedDelayWA()  const
                                                { return r_max_forecasted_delayWA; }
      Warnings_alerts getAverageForecastedDelay_DelayedFpsWA() const
                                                {return r_average_forecasted_delay_delayedfpsWA; }
      //Warnings_alerts getPunctualFlightsWA()       const
      //                                          { return r_punctual_flightsWA; }
      Warnings_alerts getPunctualityPercentageWA() const
                                                { return r_punctuality_percentageWA; }

      /*void calculateAverageForecastedDelayDelayedFPs(string interval,
                                                     const LpiADOVector<vector<string> > & acceptedFPs,
                                                     const LpiADOVector<vector<string> > & delayedFPs,
                                                     map<string, LpdbFPSchedule> & scheduled_fps,
                                                     map<string, LpdbFPSchedule> & delayed_fps_last_interval,
                                                     int delayCountThreshold);*/

      void calculateAccumulatedValues(const LpdbRunwayIntervalKPIs & runwayIntervalKPIs);
      void calculateAverages();

      //void generateAlerts(string interval, const LpiConfigurationAlertKPIs & thresholds);

      //static void convertToInterface (const LpdbAirportIntervalKPIs & kpis, LpiAirportIntervalKPIs & out);

   protected:

      LpiADOVector<double> r_max_forecasted_delay;
      LpiADOVector<double> r_average_forecasted_delay_delayedfps;
      LpiADOVector<double> r_punctual_flights;
      LpiADOVector<double> r_punctuality_percentage;
      LpiADOVector<double> r_accumulated_rwys_demand_forecast;


      Warnings_alerts r_max_forecasted_delayWA;
      Warnings_alerts r_average_forecasted_delay_delayedfpsWA;
      Warnings_alerts r_punctuality_percentageWA;
      //Warnings_alerts r_punctual_flightsWA;
};


std::ostream & operator<<(std::ostream & os, const LpdbAirportIntervalKPIs & info);


#endif //LPB_RUNWAY_INTERVAL_KPIS_H
