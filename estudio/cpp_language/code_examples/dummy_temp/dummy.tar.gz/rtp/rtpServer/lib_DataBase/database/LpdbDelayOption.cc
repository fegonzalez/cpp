/*
 * LpdbDelayOption.cc
 *
 */


#include <iostream>
#include <sstream>

#include "LpdbDelayOption.h"


LpdbDelayOption::LpdbDelayOption()
: r_delayedFPs(),
  r_accepted_delayedFPs(),
  r_non_accepted_delayedFPs(),
  r_ratioARR(0.0),
  r_ratioDEP(0.0),
  r_weightARR(0.0),
  r_weightDEP(0.0),
  r_distance(0.0)
{
}


LpdbDelayOption::LpdbDelayOption(const LpdbDelayOption & source)
: r_delayedFPs(source.r_delayedFPs),
  r_accepted_delayedFPs(source.r_accepted_delayedFPs),
  r_non_accepted_delayedFPs(source.r_non_accepted_delayedFPs),
  r_ratioARR(source.r_ratioARR),
  r_ratioDEP(source.r_ratioDEP),
  r_weightARR(source.r_weightARR),
  r_weightDEP(source.r_weightDEP),
  r_distance(source.r_distance)
{
}


LpdbDelayOption::~LpdbDelayOption()
{

}


LpdbDelayOption & LpdbDelayOption::operator= (const LpdbDelayOption & source)
{
   if (this != &source)
   {
      r_delayedFPs = source.r_delayedFPs;
      r_accepted_delayedFPs = source.r_accepted_delayedFPs;
      r_non_accepted_delayedFPs = source.r_non_accepted_delayedFPs;
      r_ratioARR = source.r_ratioARR;
      r_ratioDEP = source.r_ratioDEP;
      r_weightARR = source.r_weightARR;
      r_weightDEP = source.r_weightDEP;
      r_distance = source.r_distance;
   }

   return *this;
}


LpiADOVector<int> LpdbDelayOption::getDelayedFPs () const
{
   return r_delayedFPs;
}


void LpdbDelayOption::setDelayedFPs (const LpiADOVector<int> delayed)
{
   r_delayedFPs = delayed;
}


LpiADOVector<int> LpdbDelayOption::getAcceptedDelayedFPs () const
{
   return r_accepted_delayedFPs;
}


void LpdbDelayOption::setAcceptedDelayedFPs (const LpiADOVector<int> accepted_delayed)
{
   r_accepted_delayedFPs = accepted_delayed;
}


LpiADOVector<int> LpdbDelayOption::getNonAcceptedDelayedFPs () const
{
   return r_non_accepted_delayedFPs;
}


void LpdbDelayOption::setNonAcceptedDelayedFPs (const LpiADOVector<int> real_delayed)
{
   r_non_accepted_delayedFPs = real_delayed;
}


std::ostream& operator<<(std::ostream &os, const LpdbDelayOption &info)
{
   return os << "[DLYD: " << info.getDelayedFPs()
             << " | ACCPT_DLYD: " << info.getAcceptedDelayedFPs()
             << " | NON_ACCPT_DLYD: " << info.getNonAcceptedDelayedFPs()
             << " | ARR_RATIO: " << info.getRatioARR()
             << " | DEP_RATIO: " << info.getRatioDEP()
             << " | ARR_WEIGHT: " << info.getWeightARR()
             << " | DEP_WEIGHT: " << info.getWeightDEP()
             << " | DIST: " << info.getDistance()
             << "]";
}
