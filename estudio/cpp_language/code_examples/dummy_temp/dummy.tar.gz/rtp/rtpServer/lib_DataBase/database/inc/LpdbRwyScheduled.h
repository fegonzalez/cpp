/*
 * LpdbRwyScheduled.h
 *
 *  Created on: 11/12/2013
 *      Author: mbegega
 *
 *  Description: Runway of planned RS in one interval schedule.
 *               Contains fp keys (callsign, departure, destination, eobt) of allocated FPs in a specific schedule
 *
 */


#ifndef LPBRWYSCHEDULED_H_
#define LPBRWYSCHEDULED_H_

#include <string>
#include <vector>
#include <map>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "LpiADOVector.h"
#include "LpdbFPAllocated.h"
#include "LpdbFPDelayed.h"
#include "LpdbFPSchedule.h"
#include "LpdbRunwayIntervalKPIs.h"
#include <LpiAdaptationRunwaySystem.h>

using namespace boost;

using std::vector;
using std::string;
using std::map;

class LpdbRwyScheduled
{
   public:

      LpdbRwyScheduled();
      LpdbRwyScheduled(string id);
      LpdbRwyScheduled(string id, OperationType::Enum use);

      LpdbRwyScheduled(const LpdbRwyScheduled & source);

      virtual ~LpdbRwyScheduled() {}

      LpdbRwyScheduled & operator= (const LpdbRwyScheduled & source);

      //fp_key = "callsign dep arr" string key
      //constructed from getUniqueKey() method of FP class
      bool isAllocated  (string fp_key);
      void allocateFP   (LpdbFPAllocated flight_plan);
      void deAllocateFP (string fp_key);
      LpdbFPAllocated & operator[] (string fp_key);

      //Allocate/Delay one flight plan by type
      void allocateFlightPlan(int fp_type, string fp_id);
      void allocateFlightPlan(LpiOperationType::LpiEnum fp_type, string fp_id);

      void delayFlightPlan   (int fp_type, string fp_id);
      void delayFlightPlan   (LpiOperationType::LpiEnum fp_type, string fp_id);

      void resetAllocation ();

      //Allocate/Delay a list of flight plans by type
      void allocateFPs(int fp_type, int real_accepted, vector<string> real_accepted_fp_ids);
      void delayFPs   (int fp_type, int real_delayed,  vector<string> real_delayed_fp_ids);

      //Getters and Setters
      map<string, LpdbFPAllocated> getAllocatedFps() const;
      void setAllocatedFps(map<string, LpdbFPAllocated> allocatedFps);


      bool isDelayed   (string fp_key);
      void delayedFP   (LpdbFPDelayed flight_plan);
      void deDelayedFP (string fp_key);

      //Getters and Setters
      map<string, LpdbFPDelayed> getDelayedFps() const;
      void setDelayedFps(map<string, LpdbFPDelayed> delayedFps);

      LpiADOVector<int> getTotalAcceptedFps() const;
      LpiADOVector<int> getTotalDelayedFps() const;


      LpiADOVector<vector<string> > getAllocatedFpsFps() const;
      void setAllocatedFpsFps(LpiADOVector<vector<string> > allocatedFpsFps);

      LpiADOVector<vector<string> > getDelayedFpsFps() const;
      void setDelayedFpsFps(LpiADOVector<vector<string> > delayedFpsFps);

      string getRwyId() const;
      void setRwyId(string rwyId);

      LpiADOVector<int> getUsageCapacity() const;
      void setUsageCapacity(LpiADOVector<int> usageCapacity);

      LpiADOVector<int> getNumberOfAllocatedFps() const;
      void setNumberOfAllocatedFps(LpiADOVector<int> allocatedFps);

      LpiADOVector<int> getNumberOfDelayedFps() const;
      void setNumberOfDelayedFps(LpiADOVector<int> delayedFps);

      OperationType::Enum getUsage() const;
      void setUsage (OperationType::Enum usage);

      int  getMaxCapacity () const;
      void setMaxCapacity (int capacity);

      int  getActualCapacity () const;
      void setActualCapacity (int capacity);

      void setSlot(int value);
      int  getSlot() const;
      void calculateSlot(int minutesSubinterval);
      void calculateSlot(int minutesSubinterval, LpiADOVector<int> capacity);

      bool isAvailable () const;

      LpdbRunwayIntervalKPIs getRunwayIntervalKPIs() const
      { return r_absoluteKPIs; }

//      void generateRunwayIntervalKPIs(string interval,
//                                      map<string, LpdbFPSchedule> & scheduled_fps,
//                                      map<string, LpdbFPSchedule> & delayed_fps_last_interval,
//                                      LpiConfigurationAlertKPIs & alertThresholds,
//                                      int delayCountThreshold);

      //FTOT and FLDTs calculations

      const std::vector<boost::posix_time::ptime> & getAvailableFTOTs() const
      { return r_availableFTOTs; }

      const std::vector<boost::posix_time::ptime> & getAvailableFLDTs() const
      { return r_availableFLDTs; }

      const std::vector<boost::posix_time::ptime> & getAvailableFTOTsForLog() const
      { return r_availableFTOTsForLog; }

      const std::vector<boost::posix_time::ptime> & getAvailableFLDTsForLog() const
      { return r_availableFLDTsForLog; }


      //Helper methods for FP data calculations
      void calculateAvailableFTOTsAndFLDTs(const boost::posix_time::ptime & intervalBeginTime,
                                           const LpiADOVector<vector<string> > & flights);

      std::string getAvailableFTOTAndFLDTsAsString();

   protected:

      std::string r_rwyId;
      OperationType::Enum r_usage;

      LpiADOVector<int>             r_usage_capacity;
      map<string, LpdbFPAllocated>   r_allocated_fps;
      map<string, LpdbFPDelayed>     r_delayed_fps;
      LpiADOVector<int>             r_total_allocated_fps;
      LpiADOVector<int>             r_total_delayed_fps;

      LpiADOVector<int> r_number_of_allocated_fps;
      LpiADOVector<int> r_number_of_delayed_fps;

      LpiADOVector<vector<string> > r_allocated_fps_fps;
      LpiADOVector<vector<string> > r_delayed_fps_fps;

      int r_max_capacity;
      int r_actual_capacity;
      int r_slot;        //Time slot for FTOT/FLDT calculation

      LpdbRunwayIntervalKPIs r_absoluteKPIs;

      std::vector<boost::posix_time::ptime> r_availableFTOTs;
      std::vector<boost::posix_time::ptime> r_availableFLDTs;

      //Only for logging purposes: a copy is stored because in FTOT/FLDT calculations original values are erased
      std::vector<boost::posix_time::ptime> r_availableFTOTsForLog;
      std::vector<boost::posix_time::ptime> r_availableFLDTsForLog;
};


#endif /* LPBRWYSCHEDULED_H_ */
