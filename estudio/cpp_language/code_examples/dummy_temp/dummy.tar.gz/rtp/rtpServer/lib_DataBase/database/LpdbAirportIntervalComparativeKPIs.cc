/*
 * LpdbRelativeKPIs.cc
 *
 *  Created on: 22/10/2014
 *      Author: mbegega
 */

#include <LpiADO.h>
//#include "LpdbDataBase.h"
#include "LpdbAirportIntervalComparativeKPIs.h"
#include "LpdbAlertsGenerator.h"

LpdbAirportIntervalComparativeKPIs::LpdbAirportIntervalComparativeKPIs()
: r_airport_capacity(),
  r_rs_capacity(),
  r_shortage(),
  r_max_forecasted_delay(),
  r_percentage_punctuality(),
  r_average_forecast_delay_delayedFps(),
  r_airport_capacityWA(),
  r_rs_capacityWA(),
  r_shortageWA(),
  r_max_forecasted_delayWA(),
  r_percentage_punctualityWA(),
  r_average_forecast_delay_delayedFpsWA()
{
}


LpdbAirportIntervalComparativeKPIs::LpdbAirportIntervalComparativeKPIs(const LpdbAirportIntervalComparativeKPIs & source)
: r_airport_capacity(source.r_airport_capacity),
  r_rs_capacity(source.r_rs_capacity),
  r_shortage(source.r_shortage),
  r_max_forecasted_delay(source.r_max_forecasted_delay),
  r_percentage_punctuality(source.r_percentage_punctuality),
  r_average_forecast_delay_delayedFps(source.r_average_forecast_delay_delayedFps),
  r_airport_capacityWA(source.r_airport_capacityWA),
  r_rs_capacityWA(source.r_rs_capacityWA),
  r_shortageWA(source.r_shortageWA),
  r_max_forecasted_delayWA(source.r_max_forecasted_delayWA),
  r_percentage_punctualityWA(source.r_percentage_punctualityWA),
  r_average_forecast_delay_delayedFpsWA(source.r_average_forecast_delay_delayedFpsWA)
{
}


void LpdbAirportIntervalComparativeKPIs::reset()
{
   r_airport_capacity.reset();
   r_rs_capacity.reset();

   r_shortage.reset();

   r_max_forecasted_delay.reset();
   r_percentage_punctuality.reset();
   r_average_forecast_delay_delayedFps.reset();

   r_airport_capacityWA.reset();
   r_rs_capacityWA.reset();
   r_shortageWA.reset();
   r_max_forecasted_delayWA.reset();
   r_percentage_punctualityWA.reset();
   r_average_forecast_delay_delayedFpsWA.reset();
}


LpdbAirportIntervalComparativeKPIs & LpdbAirportIntervalComparativeKPIs::operator= (const LpdbAirportIntervalComparativeKPIs & source)
{
   if (this != &source)
   {
      r_airport_capacity = source.r_airport_capacity;
      r_rs_capacity = source.r_rs_capacity;
      r_shortage = source.r_shortage;
      r_max_forecasted_delay = source.r_max_forecasted_delay;
      r_percentage_punctuality = source.r_percentage_punctuality;
      r_average_forecast_delay_delayedFps = source.r_average_forecast_delay_delayedFps;

      r_airport_capacityWA  = source.r_airport_capacityWA;
      r_rs_capacityWA = source.r_rs_capacityWA;
      r_shortageWA = source.r_shortageWA;
      r_max_forecasted_delayWA = source.r_max_forecasted_delayWA;
      r_percentage_punctualityWA = source.r_percentage_punctualityWA;
      r_average_forecast_delay_delayedFpsWA = source.r_average_forecast_delay_delayedFpsWA;
   }

   return *this;
}


void LpdbAirportIntervalComparativeKPIs::calculateValues(const LpiADOVector<int> & airport_capacity_left,
                                                        const LpiADOVector<int> & rs_capacity_left,
                                                        const LpiADOVector<int> & shortage_left,
                                                        const LpdbAirportIntervalKPIs & left,
                                                        const LpiADOVector<int> & airport_capacity_right,
                                                        const LpiADOVector<int> & rs_capacity_right,
                                                        const LpiADOVector<int> & shortage_right,
                                                        const LpdbAirportIntervalKPIs & right)
{
   *this = left - right;
   r_airport_capacity = airport_capacity_left - airport_capacity_right;
   r_rs_capacity = rs_capacity_left - rs_capacity_right;
   r_shortage = shortage_left - shortage_right;
}

/*
void LpdbAirportIntervalComparativeKPIs::generateAlerts(const LpiConfigurationAlertKPIs & thresholds, ComparativeType kpi_type)
{
   int intervals = LpdbDataBase::Get().getGlobalParameters().getNumberOfIntervalsInHour();
   intervals = (intervals > 0) ? intervals : 1;

   //Delta by default
   Alert airportCapacity = thresholds.getAirportCapacityDelta();
   Alert rsCapacity = thresholds.getRunwaySystemCapacityDelta();
   Alert airportShortage = thresholds.getAirportShortageDelta();
   Alert maxForecastedDelay = thresholds.getMaxForecastedDelayDelta();
   Alert percentagePunctuality = thresholds.getPunctualityPercentageDelta();
   Alert avgForecastedDelayDelayed = thresholds.getAverageForecastedDelayDelayedFpsDelta();

   Improvement airportCapacityPositive = thresholds.getAirportCapacityDeltaPositive();
   Improvement rsCapacityPositive = thresholds.getRunwaySystemCapacityDeltaPositive();
   Improvement airportShortagePositive = thresholds.getAirportShortageDeltaPositive();
   Improvement maxForecastedDelayPositive = thresholds.getMaxForecastedDelayDeltaPositive();
   Improvement percentagePunctualityPositive = thresholds.getPunctualityPercentageDeltaPositive();
   Improvement avgForecastedDelayDelayedPositive = thresholds.getAverageForecastedDelayDelayedFpsDeltaPositive();

   if (kpi_type == E_RELATIVE)
   {
      airportCapacity = thresholds.getAirportCapacityRelative();
      rsCapacity = thresholds.getRunwaySystemCapacityRelative();
      airportShortage = thresholds.getAirportShortageRelative();
      maxForecastedDelay = thresholds.getMaxForecastedDelayRelative();
      percentagePunctuality = thresholds.getPunctualityPercentageRelative();
      avgForecastedDelayDelayed = thresholds.getAverageForecastedDelayDelayedFpsRelative();

      airportCapacityPositive = thresholds.getAirportCapacityRelativePositive();
      rsCapacityPositive = thresholds.getRunwaySystemCapacityRelativePositive();
      airportShortagePositive = thresholds.getAirportShortageRelativePositive();
      maxForecastedDelayPositive = thresholds.getMaxForecastedDelayRelativePositive();
      percentagePunctualityPositive = thresholds.getPunctualityPercentageRelativePositive();
      avgForecastedDelayDelayedPositive = thresholds.getAverageForecastedDelayDelayedFpsRelativePositive();
   }

   r_airport_capacityWA = LpdbAlertsGenerator::GenerateAlertsForComparison(intervals,
                                              airportCapacity,
                                              airportCapacityPositive,
                                              r_airport_capacity);

   r_rs_capacityWA = LpdbAlertsGenerator::GenerateAlertsForComparison(intervals,
                                              rsCapacity,
                                              rsCapacityPositive,
                                              r_rs_capacity);

   r_shortageWA = LpdbAlertsGenerator::GenerateAlertsForComparison(intervals,
                                              airportShortage,
                                              airportShortagePositive,
                                              r_shortage);

   r_max_forecasted_delayWA = LpdbAlertsGenerator::GenerateAlertsForComparison(1,
                                              maxForecastedDelay,
                                              maxForecastedDelayPositive,
                                              r_max_forecasted_delay);

   r_percentage_punctualityWA = LpdbAlertsGenerator::GenerateAlertsForComparison(1,
                                              percentagePunctuality,
                                              percentagePunctualityPositive,
                                              r_percentage_punctuality);

   r_average_forecast_delay_delayedFpsWA = LpdbAlertsGenerator::GenerateAlertsForComparison(1,
                                              avgForecastedDelayDelayed,
                                              avgForecastedDelayDelayedPositive,
                                              r_average_forecast_delay_delayedFps);
}
*/

void LpdbAirportIntervalComparativeKPIs::convert2Interface(const LpdbAirportIntervalComparativeKPIs & in, LpiIntervalDataKpis & out)
{
   out.setAirportCapacity(LpiADO::convert2Interface(in.getAirportCapacity()));
   out.setRSCapacity(LpiADO::convert2Interface(in.getRSCapacity()));
   out.setShortage(LpiADO::convert2Interface(in.getShortage()));
   out.setMaxForecastedDelay(LpiADO::convert2Interface(in.getMaxForecastedDelay()));
   out.setPercentagePunctual(LpiADO::convert2Interface(in.getPercentagePunctuality()));
   out.setAverageForecastedDelay_DelayedFPs(LpiADO::convert2Interface(in.getAverageForecastedDelay_DelayedFps()));

   out.setAirportCapacityWA(in.getAirportCapacityWA());
   out.setRSCapacityWA(in.getRSCapacityWA());
   out.setShortageWA(in.getShortageWA());
   out.setMaxForecastedDelayWA(in.getMaxForecastedDelayWA());
   out.setPercentagePunctualWA(in.getPercentagePunctualityWA());
   out.setAverageForecastedDelay_DelayedFPsWA(in.getAverageForecastedDelay_DelayedFpsWA());
}


LpdbAirportIntervalComparativeKPIs operator- (const LpdbAirportIntervalKPIs & left, const LpdbAirportIntervalKPIs & right)
{
   LpdbAirportIntervalComparativeKPIs result;

   result.setMaxForecastDelay(left.getMaxForecastedDelay() - right.getMaxForecastedDelay());
   result.setAverageForecastedDelay_DelayedFps(left.getAverageForecastedDelay_DelayedFps() -
                                               right.getAverageForecastedDelay_DelayedFps());
   result.setPunctualPercentage(left.getPunctualityPercentage() - right.getPunctualityPercentage());

   return result;
}


std::ostream & operator<< (std::ostream & os, const LpdbAirportIntervalComparativeKPIs & kpis)
{
   return os << "[AIRPORT CAP: "        << kpis.getAirportCapacity() << " | (" << kpis.getAirportCapacityWA() << ')'
             << " | RS CAP: "           << kpis.getRSCapacity() << " | (" << kpis.getRSCapacity() << ')'
             << " | SHORTAGE : "        << kpis.getShortage() << " | (" << kpis.getShortage() << ')'
             << " | MAX FCST DLY : "    << kpis.getMaxForecastedDelay() << " | (" << kpis.getMaxForecastedDelay() << ')'
             << " | % PUNCT : "         << kpis.getPercentagePunctuality() << " | (" << kpis.getPercentagePunctuality() << ')'
             << " | AVG FCST DLY DELAYED: " << kpis.getAverageForecastedDelay_DelayedFps() << " | (" << kpis.getAverageForecastedDelay_DelayedFps()<< ')'
             << "]";
}
