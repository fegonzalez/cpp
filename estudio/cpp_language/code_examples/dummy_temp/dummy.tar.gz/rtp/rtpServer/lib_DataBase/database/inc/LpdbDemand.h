/*
 * LpdbDemand.h
 *
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx"
 */

#ifndef LPDBDEMAND_H_
#define LPDBDEMAND_H_

#include <string>
#include <set>
#include <vector>
#include <utility>

#include "LpiTimeParameters.h"
#include <LctimTimeLine.h>
#include "LpdbDemandTimedData.h"


using std::string;
using std::set;
using std::pair;
using std::vector;

class LpiFlightPlan;

class LpdbDemand
{

friend  std::ostream& operator<<(std::ostream &os, const LpdbDemand &info);


   public:
      LpdbDemand();

      LpdbDemand(const LpdbDemand & source);

//      void init(const LpiTimeParameters & parameters,
//                boost::posix_time::ptime begin_timestamp);

      LpdbDemand & operator= (const LpdbDemand & source);

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbDemandTimedData & operator[] (const string & interval_name);

      void forward();

      vector<LpiADOVector<unsigned int> > getDemandForecastScheduled() const;
      void setDemandForecastScheduled(
                vector<LpiADOVector<unsigned int> > demandForecastScheduled);

      LpiADOVector<unsigned int> getTotalDemandForecast () const;
      void setTotalDemandForecast(LpiADOVector<unsigned int> totalDemandForecast);
      void updateTotalDemandForecast();

      LpiADOVector<double> getTotalDemandRatio () const;

      LpiADOVector<unsigned int> getTotalDemandVFR () const;
      void setTotalDemandVFR(LpiADOVector<unsigned int> totalVFR);

      TimeLine<LpdbDemandTimedData> getTimeLine() const;
      void  setTimeLine(const TimeLine<LpdbDemandTimedData> timeLine);

      void incrementDemand (const string & interval_name, unsigned int flight_type, unsigned int value);
      void decrementDemand (const string & interval_name, unsigned int flight_type, unsigned int value);

      void incrementTotalDemand (LpiADOVector<unsigned int> value);
      void decrementTotalDemand (LpiADOVector<unsigned int> value);

      void incrementDemand (unsigned int flight_type, unsigned int value);
      void decrementDemand (unsigned int flight_type, unsigned int value);

      std::string getLastMessage() {return r_last_message;};
      void setLastMessage(std::string lastMessage){r_last_message = lastMessage;};

      posix_time::ptime getmessageTimeandDate() const {return r_messageTimeandDate;};
      void setmessageTimeandDate(posix_time::ptime _messageTimeandDate) {r_messageTimeandDate = _messageTimeandDate; };

      bool isEmpty () const;

      void deleteFromForecast(const LpiFlightPlan & fp);



   protected:
      //time last message received
      posix_time::ptime             r_messageTimeandDate;

      /**@param r_timeLine

	 Defined at [1].4.2.1,a Demanda prevista por subintervalo, as:
	 Demand_Forecast (ti) = [ Num_Ai ; Num_Di ; Num_Oi ]
	 Demand_Forecast_FPs (ti) = [ FPs_Ai ; FPs_Di ; FPs_Oi ]
	 Demand_VFR (ti) = [ Num_VFR_Oi ]
       */
      TimeLine<LpdbDemandTimedData>  r_timeLine;


      vector<LpiADOVector<unsigned int> >    r_demand_forecast_scheduled;

      /**@param r_total_demand_forecast

	 Defined at [1].4.2.1,a Demanda prevista por subintervalo, as:
	 Total_Demand_Forecast = Σ𝑖 𝐷𝑒𝑚𝑎𝑛𝑑_𝐹𝑜𝑟𝑒𝑐𝑎𝑠𝑡 (𝑡𝑖)
	 
	 thus, r_total_demand_forecast = Σ𝑖 r_timeLine.r_demand_forecast
       */
      LpiADOVector<unsigned int> r_total_demand_forecast; 


      LpiADOVector<unsigned int> r_total_vfr;

      string                        r_last_message;

      //Last demand report received? Not necessary for now
      //LpdbExpectedDemand     r_expectedDemand;
};


#endif /* LPDBDEMAND_H_ */
