/*
 * LpdbDemand.h
 *
 *  Created on: 02/01/2014
 *      Author: mbegega
 */

#ifndef LPBDEMAND_H_
#define LPBDEMAND_H_

#include <string>
#include <set>
#include <vector>
#include <utility>

#include "LpiTimeParameters.h"
#include <LctimTimeLine.h>
#include "LpdbDemandTimedData.h"


using std::string;
using std::set;
using std::pair;
using std::vector;

class LpiFlightPlan;

class LpdbDemand
{
   public:
      LpdbDemand();

      LpdbDemand(const LpdbDemand & source);

//      void init(const LpiTimeParameters & parameters,
//                boost::posix_time::ptime begin_timestamp);

      LpdbDemand & operator= (const LpdbDemand & source);

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbDemandTimedData & operator[] (const string & interval_name);

      void forward();

      vector<LpiADOVector<int> > getDemandForecastScheduled() const;
      void setDemandForecastScheduled(
                vector<LpiADOVector<int> > demandForecastScheduled);

      LpiADOVector<int> getTotalDemandForecast () const;
      void setTotalDemandForecast(LpiADOVector<int> totalDemandForecast);
      void updateTotalDemandForecast();

      LpiADOVector<double> getTotalDemandRatio () const;

      LpiADOVector<int> getTotalDemandVFR () const;
      void setTotalDemandVFR(LpiADOVector<int> totalVFR);

      TimeLine<LpdbDemandTimedData> getTimeLine() const;
      void  setTimeLine(const TimeLine<LpdbDemandTimedData> timeLine);

      void incrementDemand (const string & interval_name, int flight_type, int value);
      void decrementDemand (const string & interval_name, int flight_type, int value);

      void incrementTotalDemand (LpiADOVector<int> value);
      void decrementTotalDemand (LpiADOVector<int> value);

      void incrementDemand (int flight_type, int value);
      void decrementDemand (int flight_type, int value);

      std::string getLastMessage() {return r_last_message;};
      void setLastMessage(std::string lastMessage){r_last_message = lastMessage;};

      posix_time::ptime getmessageTimeandDate() const {return r_messageTimeandDate;};
      void setmessageTimeandDate(posix_time::ptime _messageTimeandDate) {r_messageTimeandDate = _messageTimeandDate; };

      bool isEmpty () const;

      void deleteFromForecast(const LpiFlightPlan & fp);



   protected:
      //time last message received
      posix_time::ptime             r_messageTimeandDate;
      TimeLine<LpdbDemandTimedData>  r_timeLine;
      vector<LpiADOVector<int> >    r_demand_forecast_scheduled;
      LpiADOVector<int> r_total_demand_forecast;
      LpiADOVector<int> r_total_vfr;
      string                        r_last_message;

      //Last demand report received? Not necessary for now
      //LpdbExpectedDemand     r_expectedDemand;
};


std::ostream& operator<<(std::ostream &os, const LpdbDemand &info);

#endif
