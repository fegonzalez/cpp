/*
 * LpdbGlobalParameters.cc
 *
 *  Created on: 14/01/2014
 *      Author: mbegega
 */

#include "LpdbGlobalParameters.h"

#include <LcuAtcUnits.h>

#include <LpiAdaptationMrtmInfo.h>
#include <LpiAdaptationAlert_KPIs.h>


LpdbGlobalParameters::LpdbGlobalParameters()
: r_time_parameters(),
  r_distribution(),
  r_ponderations(),
  r_use_file_capacity_reductions(true),
  //r_use_wtc_capacity_reductions(true),
  r_fp_expiration_time(60),
  //r_airport_name(),
  r_default_taxi_time(0),
  r_alternativeScheduleExpirationHours(0.0),
  r_tminTurnRound(0),
  r_closedTurnRound(0)
{
}


LpdbGlobalParameters::LpdbGlobalParameters
(const LpiTimeParameters & timeData,
 const LpiEvaluationDistribution & distribution,
 const LpiWeightPonderationParameters & ponderations,
 const bool & use_file_capacity_reductions,
 //const bool & use_wtc_capacity_reductions,
 const double & fp_expiration_time,
 //const LpiAdaptationAirportInfo & airport_info,
 const double & alternativeExpirationHours,
 int   tminTurnRound,
 int   closedTurnRound)
: 
  r_time_parameters(timeData),
  //  r_distribution(distribution),
  //  r_ponderations(ponderations),
  //  r_use_file_capacity_reductions(use_file_capacity_reductions),
  //r_use_wtc_capacity_reductions(use_wtc_capacity_reductions),
  r_fp_expiration_time(fp_expiration_time),
  //r_airport_name(airport_info.getname()),
  //r_default_taxi_time(airport_info.getdefaultTaxiTime()),
  r_alternativeScheduleExpirationHours(alternativeExpirationHours)
  // r_tminTurnRound(tminTurnRound),
  // r_closedTurnRound(closedTurnRound)
{
 setNumberOfIntervalsInHour(HOURS_TO_MINUTES /
			    timeData.getMinutesSubinterval());
}

//-----------------------------------------------------------------------------

void LpdbGlobalParameters::init 
(const LpiTimeParameters & timeData,
 //RMAN  // const LpiEvaluationDistribution & distribution,
 //RMAN  // const LpiWeightPonderationParameters & ponderations,
 //RMAN  // const bool & use_file_capacity_reductions,
 //const bool & use_wtc_capacity_reductions,
 const double & fp_expiration_time,
 //const LpiAdaptationAirportInfo & airport_info,
 const double & alternativeExpirationHours,
 //RMAN // int   tminTurnRound,
 //RMAN // int   closedTurnRound,
 const ComplexityThresholds & adapMrtComplexityThresholds,
 const LpiAdaptationAlert_KPIs & adapAlertThresholds)
{
   r_time_parameters = timeData;
//   r_distribution = distribution;
//   r_ponderations = ponderations;
//   r_use_file_capacity_reductions = use_file_capacity_reductions;
//   r_use_wtc_capacity_reductions = use_wtc_capacity_reductions;
   r_fp_expiration_time = fp_expiration_time;

//   r_airport_name = airport_info.getname();
//   r_default_taxi_time = airport_info.getdefaultTaxiTime();


   r_alternativeScheduleExpirationHours = alternativeExpirationHours;

//   r_tminTurnRound = tminTurnRound;
//   r_closedTurnRound = closedTurnRound;


   setNumberOfIntervalsInHour(HOURS_TO_MINUTES /
			      timeData.getMinutesSubinterval());

   r_adapThresholds.init
     (adapMrtComplexityThresholds.getTotalMovMrtmUpperThreshold(),
      adapMrtComplexityThresholds.getTotalMovMrtmLowerThreshold(),
      adapMrtComplexityThresholds.getVfrMrtmUpperThreshold(),
      adapMrtComplexityThresholds.getVfrMrtmLowerThreshold(),
      adapAlertThresholds.
      getSimultaneousOpsHour().getNegativeAlert(). //ABS kpiS
      getAlarmThreshold(),
      adapAlertThresholds.getSimultaneousOpsHour().getNegativeAlert().
      getWarningThreshold(),
      adapAlertThresholds.getTotalMov().getNegativeAlert().
      getAlarmThreshold(),
      adapAlertThresholds.getTotalMov().getNegativeAlert().
      getWarningThreshold(),
      adapAlertThresholds.getComplexity().getAirportsComplexity().
      getNegativeAlert().getAlarmThreshold(),
      adapAlertThresholds.getComplexity().getAirportsComplexity().
      getNegativeAlert().getWarningThreshold(),
      adapAlertThresholds.getComplexity().getModulesComplexity().
      getNegativeAlert().getAlarmThreshold(),
      adapAlertThresholds.getComplexity().getModulesComplexity().
      getNegativeAlert().getWarningThreshold(),
      adapAlertThresholds.getVfr().getNegativeAlert().
      getAlarmThreshold(),
      adapAlertThresholds.getVfr().getNegativeAlert().
      getWarningThreshold(),
      this->getNumberOfIntervalsInHour());
}


LpiTimeParameters LpdbGlobalParameters::getTimeParameters() const
{
   return r_time_parameters;
}

///RAMN code: used to calculate schedule at "void
///LpschDynamicDemandSchedulesGenerator::setCalculationParameters()"
LpiEvaluationDistribution LpdbGlobalParameters::getEvaluationDistribution() const
{
   return r_distribution;
}


LpiWeightPonderationParameters LpdbGlobalParameters::getWeightPonderations() const
{
   return r_ponderations;
}


bool LpdbGlobalParameters::getUseFileCapacityReductions () const
{
   return r_use_file_capacity_reductions;
}
//
//bool LpdbGlobalParameters::getUseWakeVortexCapacityReductions () const
//{
//   return r_use_wtc_capacity_reductions;
//}

double LpdbGlobalParameters::getFPExpirationTime () const
{
   return r_fp_expiration_time;
}

unsigned int LpdbGlobalParameters::getNumberOfIntervalsInHour () const
{
   return r_N1;
}


int LpdbGlobalParameters::getDefaultTaxiTime() const
{
   return r_default_taxi_time;
}


double LpdbGlobalParameters::getAlternativeScheduleExpirationHours() const
{
   return r_alternativeScheduleExpirationHours;
}


int LpdbGlobalParameters::getTminTurnRound() const
{
   return r_tminTurnRound;
}


int LpdbGlobalParameters::getClosedTurnRound() const
{
   return r_closedTurnRound;
}

LpdbAdapThresholdsPerInterval 
LpdbGlobalParameters::getAdapThresholdsPerInterval()const
{
   return r_adapThresholds;
}



void LpdbGlobalParameters::setNumberOfIntervalsInHour(unsigned int new_val)
{ 
  r_N1 = new_val; 
}


std::ostream& operator<<(std::ostream & os, const LpdbGlobalParameters & params)
{
   return os << "[WIN: " << params.getTimeParameters().getHoursWindow()
             << " | SUBINT: " << params.getTimeParameters().getMinutesSubinterval()
             << " | FRZ: " << params.getTimeParameters().getMinutesFrozen()
             << " | N1: " << params.getNumberOfIntervalsInHour()
             << " | TMIN TURN-ROUND: " << params.getTminTurnRound()
             << " | CLOSED TURN-ROUND: " << params.getClosedTurnRound()
             << ']' << '\n'
             << "[ USE_FILE_RED: " << params.getUseFileCapacityReductions()
             << " | FP_EXP_TIME: " << params.getFPExpirationTime()
             << ']' << '\n'
             << "[DIST: " << params.getEvaluationDistribution()
             << ']' << '\n'
             << "[ W_POND: " << params.getWeightPonderations()
             << ']' << '\n'
             << "[ THRESHOLDS: " 
		  << params.getAdapThresholdsPerInterval()
             << ']' << '\n';

}


//===========================================

void LpdbAdapThresholdsPerInterval::init
(unsigned int totalMovMrtmUpperThreshold,
 unsigned int totalMovMrtmLowerThreshold,
 unsigned int vfrMrtmUpperThreshold,
 unsigned int vfrMrtmLowerThreshold,
 unsigned int SimultaneousOpsHourAlert_Alarm,
 unsigned int SimultaneousOpsHourAlert_Warning,
 unsigned int totalMovAlert_Alarm,
 unsigned int totalMovAlert_Warning,
 unsigned int ComplexityAlert_AirportsComplexity_Alarm,
 unsigned int ComplexityAlert_AirportsComplexity_Warning,
 unsigned int ComplexityAlert_ModulesComplexity_Alarm,
 unsigned int ComplexityAlert_ModulesComplexity_Warning,
 unsigned int vfrAlert_Alarm,
 unsigned int vfrAlert_Warning,
 unsigned int N1)
{
  // i) total movements (DAORTP_AirportsInfo.xml)
  theTotalMovMrtmUpperThreshold = totalMovMrtmUpperThreshold / N1;
  theTotalMovMrtmLowerThreshold = totalMovMrtmLowerThreshold / N1;
  // ii) VFR flight (DAORTP_MrtmInfo.xml)
  theVfrMrtmUpperThreshold = vfrMrtmUpperThreshold / N1;
  theVfrMrtmLowerThreshold = vfrMrtmLowerThreshold / N1;

  //iii) Alerts: Alarm and  Warning (DAORTP_Alert_KPI.xml)
  theSimultaneousOpsHourAlert_Alarm = SimultaneousOpsHourAlert_Alarm / N1;
  theSimultaneousOpsHourAlert_Warning = SimultaneousOpsHourAlert_Warning / N1;
  theTotalMovAlert_Alarm = totalMovAlert_Alarm / N1;
  theTotalMovAlert_Warning = totalMovAlert_Warning / N1;
  theComplexityAlert_AirportsComplexity_Alarm = 
    ComplexityAlert_AirportsComplexity_Alarm / N1;
  theComplexityAlert_AirportsComplexity_Warning = 
    ComplexityAlert_AirportsComplexity_Warning / N1;
  theComplexityAlert_ModulesComplexity_Alarm = 
    ComplexityAlert_ModulesComplexity_Alarm / N1;
  theComplexityAlert_ModulesComplexity_Warning = 
    ComplexityAlert_ModulesComplexity_Warning / N1;
  theVfrAlert_Alarm = vfrAlert_Alarm / N1;
  theVfrAlert_Warning = vfrAlert_Warning / N1;
}

//------------------------------------------------------------------------------

std::ostream& operator<<(std::ostream & os, 
			 const LpdbAdapThresholdsPerInterval & params)
{
  return os 
    << "[ TotalMovMrtmUpperThreshold: " << params.theTotalMovMrtmUpperThreshold
    << " | TotalMovMrtmLowerThreshold: " << params.theTotalMovMrtmLowerThreshold
    << " | VfrMrtmUpperThreshold: " << params.theVfrMrtmUpperThreshold
    << " | VfrMrtmLowerThreshold: " << params.theVfrMrtmLowerThreshold
    << " | SimultaneousOpsHourAlert_Alarm: " 
    << params.theSimultaneousOpsHourAlert_Alarm
    << " | SimultaneousOpsHourAlert_Warning: " 
    << params.theSimultaneousOpsHourAlert_Warning
    << " | TotalMovAlert_Alarm: " << params.theTotalMovAlert_Alarm
    << " | TotalMovAlert_Warning: " << params.theTotalMovAlert_Warning
    << " | ComplexityAlert_AirportsComplexity_Alarm: " 
    << params.theComplexityAlert_AirportsComplexity_Alarm
    << " | ComplexityAlert_AirportsComplexity_Warning: " 
    << params.theComplexityAlert_AirportsComplexity_Warning
    << " | ComplexityAlert_ModulesComplexity_Alarm: " 
    << params.theComplexityAlert_ModulesComplexity_Alarm
    << " | ComplexityAlert_ModulesComplexity_Warning: " 
    << params.theComplexityAlert_ModulesComplexity_Warning
    << " | VfrAlert_Alarm: " << params.theVfrAlert_Alarm
    << " | VfrAlert_Warning: " << params.theVfrAlert_Warning
    << ']' << '\n';
}

//------------------------------------------------------------------------------
