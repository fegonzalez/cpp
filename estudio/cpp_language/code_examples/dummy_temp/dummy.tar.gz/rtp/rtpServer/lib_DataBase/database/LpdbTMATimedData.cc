/*
 * LpdbTMATimedData.cc
 *
 */

#include "LpdbTMATimedData.h"
#include <iostream>

//LpdbTMATimedData::LpdbTMATimedData(const LpdbAirport & airport)
// LpdbTMATimedData::LpdbTMATimedData()
// : r_capacity(-1.0)
// {

// }


unsigned int LpdbTMATimedData::getCapacity() const
{
  return r_capacity;
}


// void LpdbTMATimedData::setCapacity(unsigned int capacity)
// {
//   r_capacity = capacity;
// }



//------------------------------------------------------------------------------


std::ostream & operator<<(std::ostream & os, const LpdbTMATimedData & info)
{
  return os << " [ CAP: " << info.getCapacity()
	    << ']';
}
