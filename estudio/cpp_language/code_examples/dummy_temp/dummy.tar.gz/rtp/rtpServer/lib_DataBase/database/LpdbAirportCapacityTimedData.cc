/**@file LpdbAirportCapacityTimedData.cc
 */

#include "LpdbAirportCapacityTimedData.h"
#include <iostream>
#include <cassert>


//------------------------------------------------------------------------------

void LpdbAirportCapacityTimedData::calculateCapacity
     (unsigned int numberOfIntervals,
      const LpiADOVector<unsigned int> & nominalCapacity)
{
  assert(numberOfIntervals > 0);
  r_capacity[E_ARR] = nominalCapacity[E_ARR] / numberOfIntervals;
  r_capacity[E_DEP] = nominalCapacity[E_DEP] / numberOfIntervals;
  r_capacity[E_OVA] = nominalCapacity[E_OVA] / numberOfIntervals;
}

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & os, const LpdbAirportCapacityTimedData & data)
{
  return os << " [ CAP: " << data.getCapacity()
	    << ']';
}
