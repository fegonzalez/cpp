/**@file LpdbAirportCapacityTimedData.cc
 */

#include "LpdbAirportCapacityTimedData.h"


//
//void LpdbAirportCapacityTimedData::setMaxCapacity(LpiADOVector<unsigned int> maxCapacity)
//{
//   r_max_capacity = maxCapacity;
//}
//
//
//LpiADOVector<unsigned int> LpdbAirportCapacityTimedData::getNominalMaxCapacity() const
//{
//   return r_nominal_max_capacity;
//}
//
//
//void LpdbAirportCapacityTimedData::setNominalMaxCapacity(LpiADOVector<unsigned int> maxCapacity)
//{
//   r_nominal_max_capacity = maxCapacity;
//}

//
//std::ostream& operator<<(std::ostream &os, const LpdbAirportCapacityTimedData &data)
//{
//// os << "MAX_CAP : " << data.getMaxCapacity(); ///@error compilation: "no match for ‘operator<<’ ... "
//
//
//
////os << "[A: " << data.r_max_capacity[E_ARR]
////              << "|D: " << data.getMaxCapacity()[E_DEP]
////              << "|O: " << data.getMaxCapacity()[E_OVA]
////              << ']';
//
//// os << "MAX_CAP : " << data.getMaxCapacity()
////             << " | NOMINAL_MAX_CAP : " << data.getNominalMaxCapacity();
//
//	os << "error: LpdbAirportCapacityTimedData::operator<<  compilation error" ;
//
//   	  return os;
//}

