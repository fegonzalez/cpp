/*
 * LpdbDataTableBest.h
 *
 *  Created on: 16/12/2013
 *      Author: mbegega
 *
 *  Description: Template for a database table with primary key of type K
 *               and stored data type T, it can store an element marked as best
 *               for O(1) access to this element
 */

#ifndef LPDBDATATABLEBEST_H_
#define LPDBDATATABLEBEST_H_

#include <iostream>
#include "LpdbDataTable.h"

template <class K, class T>
class LpdbDataTableBest: public LpdbDataTable<K, T>
{
   public:
      LpdbDataTableBest();
      LpdbDataTableBest(const LpdbDataTableBest & source);
      virtual ~LpdbDataTableBest() {}

      LpdbDataTableBest & operator= (const LpdbDataTableBest & source);

      K    getBestElementId () const;
      T &  getBestElement();
      T    getBestElement() const;

      void setBestElement (const K & id);
      void setBestElement (const K & id, const T & element);

   protected:
      K r_best_element;
};


template<class K, class T>
inline LpdbDataTableBest<K, T>::LpdbDataTableBest()
: LpdbDataTable<K, T>(), r_best_element()
{
}


template<class K, class T>
inline LpdbDataTableBest<K, T>::LpdbDataTableBest(const LpdbDataTableBest<K, T> & source)
: LpdbDataTable<K, T>(source), r_best_element(source.r_best_element)
{
}


template<class K, class T>
inline LpdbDataTableBest<K, T>& LpdbDataTableBest<K, T>::operator =(const LpdbDataTableBest<K, T> & source)
{
   if (this != &source)
   {
      LpdbDataTable<K, T>::operator =(source);
      r_best_element= source.r_best_element;
   }

   return *this;
}


template<class K, class T>
K    LpdbDataTableBest<K, T>::getBestElementId () const
{
   return r_best_element;
}


template<class K, class T>
T & LpdbDataTableBest<K, T>::getBestElement()
{
   return this->r_data[r_best_element];
}


template<class K, class T>
T LpdbDataTableBest<K, T>::getBestElement() const
{
   return this->r_data[r_best_element];
}


template<class K, class T>
void LpdbDataTableBest<K, T>::setBestElement (const K & id, const T & element)
{
   r_best_element= id;
   this->r_data[r_best_element]= element;
}


template<class K, class T>
void LpdbDataTableBest<K, T>::setBestElement (const K & id)
{
   r_best_element= id;
}


template <class K, class T>
inline std::ostream& operator<< (std::ostream & out, const LpdbDataTableBest<K, T> & table)
{
   K best_id= table.getBestElementId();

   LpdbDataTable<K, T> t=  static_cast<LpdbDataTable<K, T> >(table);

   out << t << std::endl << " Id Best Element: " << best_id;

   return out;
}
#endif /* LPDBDATATABLEBEST_H_ */
