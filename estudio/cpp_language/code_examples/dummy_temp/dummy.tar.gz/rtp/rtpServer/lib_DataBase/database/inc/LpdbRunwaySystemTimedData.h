/*
 * LpdbRunwaySystemTimedData.h
 *
 *  Created on: 17/12/2013
 *      Author: mbegega
 */

#ifndef RUNWAYSYSTEMTIMEDDATA_H_
#define RUNWAYSYSTEMTIMEDDATA_H_

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "LpiADOVector.h"


using std::vector;
using std::string;


class LpdbRunwaySystemTimedData
{
public:

   LpdbRunwaySystemTimedData();

   LpdbRunwaySystemTimedData(const LpdbRunwaySystemTimedData & source);

   virtual ~LpdbRunwaySystemTimedData();

   LpdbRunwaySystemTimedData & operator= (const LpdbRunwaySystemTimedData & source);


   //Getters and Setters
   std::string get_name () const;

   LpiADOVector<float> getDcbSuitability() const;
   void setDcbSuitability(LpiADOVector<float> dcbSuitability);

   LpiADOVector<int> getEstimatedDcMargin() const;
   void setEstimatedDcMargin(LpiADOVector<int> estimatedDcMargin);

   LpiADOVector<int> getEstimatedDelayedFps() const;
   void setEstimatedDelayedFps(LpiADOVector<int> estimatedDelayedFps);

   LpiADOVector<int> getMaxCapacity() const;
   void setMaxCapacity(LpiADOVector<int> maxCapacity);

   LpiADOVector<int> getRwysMaxCapacity() const;
   void setRwysMaxCapacity(LpiADOVector<int> maxCapacity);

   LpiADOVector<int> getNominalMaxCapacity() const;
   void setNominalMaxCapacity(LpiADOVector<int> maxCapacity);

   LpiADOVector<int> getNotAllowedEstimatedFPs() const;
   void setNotAllowedEstimatedFPs(LpiADOVector<int> notAllowed);

protected:

   std::string r_name;

   LpiADOVector<int> r_max_capacity;
   LpiADOVector<int> r_rwys_max_capacity;
   LpiADOVector<int> r_nominal_max_capacity;
   LpiADOVector<int> r_estimated_dc_margin;

   LpiADOVector<float> r_dcb_suitability;
   LpiADOVector<int>   r_estimated_delayed_fps;
   LpiADOVector<int>   r_notAllowedEstimatedFPs;
};


std::ostream& operator<<(std::ostream &os, const LpdbRunwaySystemTimedData &info);

#endif /* RUNWAYSYSTEMTIMEDDATA_H_ */
