/**@file  LpdbAirportCapacityTimedData.h
 * 
 * capacity per interval data for a concrete airport.
 */

#ifndef LPDBAIRPORTCAPACITYTIMEDDATA_H_
#define LPDBAIRPORTCAPACITYTIMEDDATA_H_

#include <LplcTypeConstants.h>
#include <LpiADOVector.h>
#include <iosfwd>


class LpdbAirportCapacityTimedData
{

public:

  LpdbAirportCapacityTimedData() = default;
  LpdbAirportCapacityTimedData(const LpdbAirportCapacityTimedData & source) = default;
  LpdbAirportCapacityTimedData & operator= (const LpdbAirportCapacityTimedData & source) = default;
  virtual ~LpdbAirportCapacityTimedData() {};

  LpiADOVector<unsigned int> getCapacity() const { return r_capacity; }

  void setCapacity(const LpiADOVector<unsigned int> &new_val)
  { r_capacity = new_val; }

  void initCapacity(unsigned int numberOfIntervals,
			 const LpiADOVector<unsigned int> & nominalCapacity);

 protected:

  LpiADOVector<unsigned int> r_capacity =
    {rtp_constants::AIRPORT_NOMINAL_CAPACITY_DEFAULT,
     rtp_constants::AIRPORT_NOMINAL_CAPACITY_DEFAULT,
     rtp_constants::AIRPORT_NOMINAL_CAPACITY_DEFAULT};

};

std::ostream& operator<<(std::ostream &os,const LpdbAirportCapacityTimedData &);


#endif /* LPDBAIRPORTCAPACITYTIMEDDATA_H_ */
