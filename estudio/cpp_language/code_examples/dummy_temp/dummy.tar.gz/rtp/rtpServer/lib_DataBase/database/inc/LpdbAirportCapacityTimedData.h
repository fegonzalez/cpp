/**@file LpdbRunwaySystemTimedData.h
 * 
 * capacity per interval data for a concrete airport.
 */

#ifndef LPDBAIRPORTCAPACITYTIMEDDATA_H_
#define LPDBAIRPORTCAPACITYTIMEDDATA_H_


#include <LpiADOVector.h>
#include <iosfwd>

//#include <boost/date_time/posix_time/posix_time.hpp>




class LpdbAirportCapacityTimedData
{

public:

   LpdbAirportCapacityTimedData() = default;
   LpdbAirportCapacityTimedData(const LpdbAirportCapacityTimedData & source) = default;
   LpdbAirportCapacityTimedData & operator= (const LpdbAirportCapacityTimedData & source) = default;
   virtual ~LpdbAirportCapacityTimedData() {};

   //Getters and Setters
   LpiADOVector<unsigned int> getMaxCapacity() const
   { return r_max_capacity; }

   void setMaxCapacity(const LpiADOVector<unsigned int> &new_val)
   { r_max_capacity = new_val; }


//   inline LpiADOVector<unsigned int> getNominalMaxCapacity() const;
//   void setNominalMaxCapacity(LpiADOVector<unsigned int> maxCapacity);

// copiado de TMA
//
//   void calculateCapacity(unsigned int numberOfIntervals, unsigned int nominalCapacity)
//   { r_capacity = nominalCapacity / numberOfIntervals; }


protected:

   LpiADOVector<unsigned int> r_max_capacity;
   //   LpiADOVector<unsigned int> r_nominal_max_capacity;

};
//
//std::ostream& operator<<(std::ostream &os, const LpdbAirportCapacityTimedData &data);


#endif /* LPDBRUNWAYSYSTEMTIMEDDATA_H_ */
