/*
 * LpdbAirportCapacity.h
 *
 *
 * DOC Reference [1] "2018-08-03 RTP Diseño Funcional.docx", chapter
 *     4.3.1 Cálculos de capacidades
 *
 * DOC Reference [2] Adaptation file - DAORTP_AirportsInfo.xml
 *
 * DOC Reference [3] Adaptation file storage - LpiAdaptationAirportsInfo.h
 */

#ifndef LPDBAIRPORTCAPACITY_H_
#define LPDBAIRPORTCAPACITY_H_

#include <LplcTypeConstants.h>
#include <LpiADOVector.h>
#include <LctimTimeLine.h>
#include <LpiAdaptationAirportsInfo.h>
#include <LpiTimeParameters.h>
#include <LpiWakeVortexCapacityReductions.h>
#include <LpdbTMA.h>
#include <LpdbTWY.h>
#include <LpdbAirportCapacityTimedData.h>

#include <string>
#include <map>
#include <vector>
#include <utility>
#include <boost/date_time/posix_time/posix_time.hpp>



class AirportMaxNominalCapacity;


/**@class LpdbAirportCapacity
 
 @brief Capacity data associated to a concrete Airport.
 
 @warning Only the explicit constructor is expected to be used
     in the regular program logic, therefore is the only constructor that
     initialize the required attribute 'the_airport' within a valid value.
     Anyway, the default constructor, copy constructor, and operator=
     can't be deleted because LpdbAirportCapacity is implicitly
     initialized used within TimeLine objects.
 */
class LpdbAirportCapacity
{
  friend std::ostream& operator<<(std::ostream &os, 
				  const LpdbAirportCapacity &rs);
  
 public:

  explicit LpdbAirportCapacity
    (const AirportMaxNominalCapacity &airportMaxNominal,
     const LpiADOVector<unsigned int> &taxywaysMaxNominal,
     const LpiADOVector<unsigned int> &tmaMaxNominal,
     const std::string  &airport);

  virtual ~LpdbAirportCapacity() {}

  //required default operations (see warning above)
  LpdbAirportCapacity() = default;
  LpdbAirportCapacity(const LpdbAirportCapacity & source) = default;
  LpdbAirportCapacity & operator= (const LpdbAirportCapacity & source) =default;


  //Check if has data associated to one given interval name
  bool has_data(const std::string & interval_name);

  //Get one element from internal timeline for modification
  LpdbAirportCapacityTimedData & operator[] (const std::string & interval_name);

  TimeLine<LpdbAirportCapacityTimedData> getTimeLine() const;

  //TimeInterval getTimeInterval(const std::string & interval);

  LpiADOVector<unsigned int> getNominalCapacity()const
      { return the_airport_nominal_capacity; }
  LpiADOVector<unsigned int> get_taxywaysNominalCapacity()const 
    { return the_twyNominalCapacity; }
  LpiADOVector<unsigned int> get_tmaNominalCapacity()const 
    { return the_tmaNominalCapacity; }
  LpdbTMA & getTMA() { return the_tma; }
  LpdbTWY & getTWY() { return the_twy; }


  //stablish timeline
  void init(const LpiTimeParameters & timeData,
	    boost::posix_time::ptime begin_timestamp,
	    const LpiADOVector<unsigned int> tmaNominalCapacity,
	    const LpiADOVector<unsigned int> twyNominalCapacity);

  //Forwards internal timeline in one interval
  void forward();
  void forward(const std::string &interval);


  void calculateMaxCapacity(); // For all the intervals


//      LpdbAirportCapacity();
//
//      LpdbAirportCapacity(std::string id);
//      LpdbAirportCapacity(const LpiAdaptationAirportsInfo & rs);
//      LpdbAirportCapacity(const LpdbAirportCapacity & source);
//
//      virtual ~LpdbAirportCapacity() {}

//      LpdbAirportCapacity & operator= (const LpdbAirportCapacity & source);

//      //Check if has data associated to one given interval name
//      bool has_data(const std::string & interval_name);
//
//      //Get one element from internal timeline for modification
//      LpdbAirportCapacityTimedData & operator[] (const std::string & interval_name);
//
//      //stablish timeline
//      void init(const LpiTimeParameters & timeData,
//                boost::posix_time::ptime begin_timestamp);
//
//      void forwardTimeline();
//      TimeLine<LpdbAirportCapacityTimedData> getTimeLine() const;
//
//      //Getters and setters
//      std::string getRunwaySystemId() const;
//      void setRunwaySystemId(std::string id);
//
//      std::string getConfiguration () const;
//      void setConfiguration (std::string configuration);
//
//      //Internal Runways Management
//      void addRunway (const std::string & runway_id, OperationType::Enum use_type);
//      void deleteRunway (const std::string & runway_id);
//      int  getNumberOfRunways () const;
//      const std::map<std::string, LpdbAirportCapacityRunway> & getRunways() const;
//
//      LpdbAirportCapacityRunway & getRunway(std::string id_runway);
//
//     //LVP Feasibility Management
//      bool isLvpFeasibility() const;
//      void setLvpFeasibility(bool lvpFeasibility);
//
//      std::string getIntervalsShortFormat () const;
//      std::string getIntervalsAsStd::String () const;
//
//      //Estimated Delayed FPs Management
//      std::vector<LpiADOStd::Vector<int> > getEstimatedDelayedFpsScheduled() const;
//
//      void setEstimatedDelayedFpsScheduled(
//                std::vector<LpiADOStd::Vector<int> > estimatedDelayedFpsScheduled);
//
//      void resetEstimatedDelayedFPs();
//      void addEstimatedDelayedFP (const LpiADOStd::Vector<int> & delayed);
//
//      //Maximum capacity calculations
//      void calculateMaximumCapacity ();
//      void calculateMaximumCapacity (std::string interval);
//
//      bool hasMixedRunways () const;
//      std::vector<std::string> getRunwaysByUse (OperationType::Enum operation) const;
//      bool hasRunwaysOfSameUse (const LpdbAirportCapacity & anotherRS,
//                                OperationType::Enum operation) const;
//
//      LpiRunwaySystemUse::LpiEnum getUse () const;
//      void setUse (LpiRunwaySystemUse::LpiEnum use);
//
//      std::map<std::string, int> getAvailableRunwaysAndCapacities (OperationType::Enum use_type, std::string interval);
//
//      int getNumberOfArrivalRunways() const;
//      int getNumberOfDepartureRunways() const;

   private:

  void calculateMaxCapacity(const std::string &interval);
  std::string getAirportId()const { return the_airport; }


//
//      void calculateRSRunwayMaxCapacity();
//      void calculateRunwayDependencies();
//      void applyCapacityReductions();
//      void combineRunwaysCapacities();
////      void applyMeteoReductions();
//
////      void calculateTMATaxiwaysReductions();
//
//      void calculateRSRunwayMaxCapacity(std::string interval);
//      void calculateRunwayDependencies(std::string interval);
//      void applyCapacityReductions(std::string interval);
//      void combineRunwaysCapacities(std::string interval);
////      void applyMeteoReductions(std::string interval);
//
////      void calculateTMATaxiwaysReductions(std::string interval);
//
//      // Member functions to reduce the capacity by WTC
//      std::vector<LpiWakeVortexConditions> calculateConditionsToApplyReduction(
//                                      std::vector<float> calculated_percentage,
//                                  std::vector<LpiWTCReduction> reductions_list);
//      std::vector<float> calculatePercentageOfWtc(
//                          std::vector<int> counter_std::vector, int counter_total);
//      void countFlightsByWtc(std::string wtc, std::vector<int> &counter_std::vector,
//                                                          int &counter_total);


      ///@param the_airport_capacity: capacity data per interval for the airport
      ///       Stores the data specified at [1].Airport_Capacity(ti) for every
      ///       interval ti.
      ///
      ///@param the_airport_nominal_capacity: nominal capacity for the airport.  
  	  ///       Called <<Capacity_Scheduled>> at [1]
      ///       Set at construction with the value from the adap file => invariant
  	  ///       during the whole program execution.
      ///
      TimeLine<LpdbAirportCapacityTimedData> the_airport_capacity;
      LpiADOVector<unsigned int> the_airport_nominal_capacity =
     	{rtp_constants::AIRPORT_NOMINAL_CAPACITY_DEFAULT,
     	 rtp_constants::AIRPORT_NOMINAL_CAPACITY_DEFAULT,
     	 rtp_constants::AIRPORT_NOMINAL_CAPACITY_DEFAULT};


      ////////////////////////////////////////
      /// TMA & Taxy way Capacity data
      ///
      ///@brief [1].4.3.1 Capacidades de TMA y Taxyways. Se toma como punto de
      ///       partida las capacidades nominales de ambas y se dividen entre
      ///       el valor N1 para obtener el número de movimientos posibles por 
      ///       subintervalo:
      ///
      ///       TMA.Capacity (ti) = (TMA.Nominal_Capacity / N1)
      ///       TWY.Capacity (ti) = (TWY.Nominal_Capacity / N1)
      ///
      ///@param the_tmaNominalCapacity: TMA nominal capacity for the airport
      ///@warning Set at construction with the value from the adap file => invariant
      //
      ///@param the_twyNominalCapacity: taxyways nominal capacity for the airport
      ///@warning Set at construction with the value from the adap file => invariant
      ///
      ///@warning ADO not required for nominal TMA & TWY: they will be eventually
      ///         compared to Airport_Capacity see [1].4.3.1, last paragraph),
      ///         that is the minimum of (ARR,DEP,OVE).
      ///
      ///@param the_tma: TMA per interval for the airport
      ///@param the_twy: TWY per interval for the airport
      ///
      ///@warning nominal capacity = values per hour
      ///
      ////////////////////////////////////////
      LpiADOVector<unsigned int> the_twyNominalCapacity =
	{rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT,
	 rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT,
	 rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT};

      LpiADOVector<unsigned int> the_tmaNominalCapacity =
	{rtp_constants::TMA_NOMINAL_CAPACITY_DEFAULT,
	 rtp_constants::TMA_NOMINAL_CAPACITY_DEFAULT,
	 rtp_constants::TMA_NOMINAL_CAPACITY_DEFAULT};
      LpdbTMA      the_tma;
      LpdbTWY      the_twy;


      ///@param the_airport: id of the associated Airport.
      ///@warning Can't be <<const>> because it will be used to call a TimeLine
      ///         (e.g. the_airport.getMeteoForecast().getElement(interval))
      std::string the_airport = {""};
      // LpdbAirport & the_airport; // & => implicitly delete the default constructor
      // const std::string the_airport;  // const => implicitly delete the default constructor
      
      
};


#endif /* LPDBAIRPORTCAPACITY_H_ */
