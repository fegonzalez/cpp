/*
 * LpdbRunwayTimedData.h
 *
 *  Created on: 17/12/2013
 *      Author: mbegega
 */

#ifndef RUNWAYTIMEDDATA_H_
#define RUNWAYTIMEDDATA_H_

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "LpiADOVector.h"
#include "LpiClosureReason.h"

using std::vector;
using std::string;


class LpdbRunwayTimedData
{
   public:

      LpdbRunwayTimedData();

      LpdbRunwayTimedData(const LpdbRunwayTimedData & source);

      virtual ~LpdbRunwayTimedData();

      LpdbRunwayTimedData & operator= (const LpdbRunwayTimedData & source);


      //Getters and Setters
      std::string get_name () const;

      boost::optional<float> getCrosswind() const;
      void setCrosswind(boost::optional<float> crosswind);

      LpiADOVector<double> getCrosswindCapacityReduction() const;
      void setCrosswindCapacityReduction(LpiADOVector<double> crosswindCapacityReduction);

      float getCrosswindDrycondsUpperthreshold() const;
      void setCrosswindDrycondsUpperthreshold(float crosswindDrycondsUpperthreshold);

      float getCrosswindMargin() const;
      void setCrosswindMargin(float crosswindMargin);

      float getCrosswindSuitability() const;
      void setCrosswindSuitability(float crosswindSuitability);

      LpiADOVector<int> getMaxCapacity() const;
      void setMaxCapacity(LpiADOVector<int> maxCapacity);

      int getMaxCapacityArrivals() const;
      void setMaxCapacityArrivals(int maxCapacityArrivals);

      int getMaxCapacityDepartures() const;
      void setMaxCapacityDepartures(int maxCapacityDepartures);

      int getMaxCapacityOverall() const;
      void setMaxCapacityOverall(int maxCapacityOverall);

      LpiADOVector<double> getMetCapacityReduction() const;
      void setMetCapacityReduction(LpiADOVector<double> metCapacityReduction);

      LpiADOVector<double> getManualCapacityReduction() const;
      void setManualCapacityReduction(LpiADOVector<double> manualCapacityReduction);

      bool isNonAvailability() const;
      void setNonAvailability(bool nonAvailability, const LpiClosureReason::LpiEnum & reason);

      float getPctgManualCapacityReduction() const;
      void setPctgManualCapacityReduction(float pctgManualCapacityReduction);

      boost::optional<float> getTailwind() const;
      void setTailwind(boost::optional<float> tailwind);

      LpiADOVector<double> getTailwindCapacityReduction() const;
      void setTailwindCapacityReduction(LpiADOVector<double> tailwindCapacityReduction);

      LpiADOVector<double> getVisibilityCapacityReduction() const;
      void setVisibilityCapacityReduction(LpiADOVector<double> visibilityCapacityReduction);

      LpiADOVector<int> getMaxCapacityNominalInterval() const;
      void setMaxCapacityNominalInterval(LpiADOVector<int> capacity);

      bool hasManualReduction () const;

      LpiClosureReason::LpiEnum getClosureReason() const
      { return r_closureReason; }

      void setClosureReason(const LpiClosureReason::LpiEnum & reason)
      { r_closureReason = reason; }

   protected:

      std::string r_name;

      //Data
      boost::optional<float> r_crosswind;       //nullable
      boost::optional<float> r_tailwind;        //nullable

      float r_crosswind_suitability; //% by one
      float r_crosswind_margin;
      float r_crosswind_dryconds_upperthreshold;

      bool r_non_availability;
      LpiADOVector<int> r_max_capacity;
      LpiADOVector<int> r_max_capacity_nominal_interval;

      float r_pctg_manual_capacity_reduction; //% by one

      LpiADOVector<double> r_met_capacity_reduction;
      LpiADOVector<double> r_crosswind_capacity_reduction;
      LpiADOVector<double> r_tailwind_capacity_reduction;
      LpiADOVector<double> r_visibility_capacity_reduction;

      LpiADOVector<double> r_manual_capacity_reduction;

      int r_max_capacity_departures;
      int r_max_capacity_arrivals;
      int r_max_capacity_overall;

      LpiClosureReason::LpiEnum r_closureReason;
};

std::ostream& operator<<(std::ostream &os, const LpdbRunwayTimedData &info);

#endif /* RUNWAYTIMEDDATA_H_ */
