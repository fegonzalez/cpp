/**@file LpdbOptimalSchedule.cc
 *
 */


#include <LpdbOptimalSchedule.h>



std::ostream & operator<< (std::ostream & os, 
			   const LpdbOptimalSchedule & data)
{
  //generic schedule data
  os << static_cast<LpdbSchedule>(data);

  // concrete data

//   if (data.getId() != -1)
//   {
//      os << "[ID: " << data.getId() << ", NAME: " << data.getName() << "]";
//   }

  return os;
}

