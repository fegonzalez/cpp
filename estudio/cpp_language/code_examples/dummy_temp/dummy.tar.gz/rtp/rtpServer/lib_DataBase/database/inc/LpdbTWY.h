/*>
 * LpdbTWY.h
 *
 */

#ifndef LPDBTWY_H_
#define LPDBTWY_H_

#include <LplcTypeConstants.h>
#include <LpdbTWYTimedData.h>
#include <LctimTimeLine.h>
#include <LpiTimeParameters.h>

#include <string>
#include <vector>
#include <map>
#include <iosfwd>


/**@class LpdbTWY
 *
 * @brief Taxyways timeline data associated to a concrete Airport.
 *
 */
class LpdbTWY
{
	friend std::ostream & operator<<(std::ostream & os, const LpdbTWY & data);
   public:
      LpdbTWY() = default;
      LpdbTWY(const LpdbTWY & source) = default;
      LpdbTWY & operator= (const LpdbTWY & source) = default;
      virtual ~LpdbTWY() {}


      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbTWYTimedData & operator[] (const string & interval_name);

      //stablish timeline
      void init(const LpiTimeParameters & parameters,
                boost::posix_time::ptime begin_timestamp,
		const unsigned int twyNominalCapacity);

      //Forwards internal timeline in one interval
      void forward();

      //Getters and setters
      TimeLine<LpdbTWYTimedData> & getTimeLine();
      string getIntervalsShortFormat () const;
      string getIntervalsAsString () const;

      void calculateCapacity();
      void calculateCapacity(string interval);

      unsigned int getNominalTWY() const { return r_twyNominal; }


   protected:

      ///@param r_timeLine: TWY per interval for the airport
      TimeLine<LpdbTWYTimedData> r_timeLine;

      ///@param r_twyNominal: nominal TWY of the airport
      ///@warning Set at init(), value from the adap file => never changed again
      unsigned int r_twyNominal = rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT; 

};


#endif /* LPDBTWY_H_ */
