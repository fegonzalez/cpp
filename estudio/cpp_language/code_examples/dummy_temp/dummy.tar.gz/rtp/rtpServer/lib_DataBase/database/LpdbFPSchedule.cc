/*
 * LpdbFPSchedule.cc
 *
 *  Created on: 08/05/2014
 *      Author: gpfernandez
 */

#include <iostream>
#include <LpiSchedule.h>

#include <LctimTimeUtils.h>
#include "LpdbFPSchedule.h"

//#include <boost/lexical_cast.hpp>

LpdbFPSchedule::LpdbFPSchedule()
{
}

LpdbFPSchedule::LpdbFPSchedule(const std::string & key,
                             const std::string & callsign,
                             const std::string & departure,
                             const std::string & arrival,
                             const boost::optional<posix_time::ptime> & eobt)
: r_key(key),
  r_callsign(callsign),
  r_departure_aerodrome(departure),
  r_arrival_aerodrome(arrival),
  r_eobt(eobt),
  r_turnRoundDelayed(false)
{
}


LpdbFPSchedule::LpdbFPSchedule(const LpdbFPSchedule & source)
: r_key(source.r_key),
  r_callsign(source.r_callsign),
 r_departure_aerodrome(source.r_departure_aerodrome),
 r_arrival_aerodrome(source.r_arrival_aerodrome),
 r_assigned_runway(source.r_assigned_runway),
 r_operation_type(source.r_operation_type),
 r_ftot(source.r_ftot),
 r_fldt(source.r_fldt),
 r_stot(source.r_stot),
 r_sldt(source.r_sldt),
 r_itot(source.r_itot),
 r_ildt(source.r_ildt),
 r_eobt(source.r_eobt),
 r_ld_forecasted_delay(source.r_ld_forecasted_delay),
 r_ld_punctuality_delay(source.r_ld_punctuality_delay),
 r_to_forecasted_delay(source.r_to_forecasted_delay),
 r_to_punctuality_delay(source.r_to_punctuality_delay),
 r_turnRoundDelayed(source.r_turnRoundDelayed)
{
}


LpdbFPSchedule & LpdbFPSchedule::operator= (const LpdbFPSchedule & source)
{
   if (this != &source)
   {
      r_key = source.r_key;
      r_callsign = source.r_callsign;
      r_departure_aerodrome = source.r_departure_aerodrome;
      r_arrival_aerodrome = source.r_arrival_aerodrome;
      r_assigned_runway = source.r_assigned_runway;
      r_operation_type = source.r_operation_type;
      r_ftot = source.r_ftot;
      r_fldt = source.r_fldt;
      r_stot = source.r_stot;
      r_sldt = source.r_sldt;
      r_itot = source.r_itot;
      r_ildt = source.r_ildt;
      r_eobt = source.r_eobt;
      r_ld_forecasted_delay = source.r_ld_forecasted_delay;
      r_ld_punctuality_delay = source.r_ld_punctuality_delay;
      r_to_forecasted_delay = source.r_to_forecasted_delay;
      r_to_punctuality_delay = source.r_to_punctuality_delay;
      r_turnRoundDelayed = source.r_turnRoundDelayed;
   }

   return *this;
}


std::string LpdbFPSchedule::getCallsign() const
{
   return r_callsign;
}


void LpdbFPSchedule::setCallsign(std::string callsign)
{
   r_callsign = callsign;
}


std::string LpdbFPSchedule::getArrivalAerodrome() const
{
   return r_arrival_aerodrome;
}


void LpdbFPSchedule::setArrivalAerodrome(std::string arrivalAerodrome)
{
   r_arrival_aerodrome = arrivalAerodrome;
}


std::string LpdbFPSchedule::getDepartureAerodrome() const
{
   return r_departure_aerodrome;
}


void LpdbFPSchedule::setDepartureAerodrome(std::string departureAerodrome)
{
   r_departure_aerodrome = departureAerodrome;
}


void LpdbFPSchedule::setAssignedRunway(std::string runway)
{
   r_assigned_runway = runway;
}


std::string LpdbFPSchedule::getAssignedRunway() const
{
   return r_assigned_runway;
}


const boost::optional<posix_time::ptime> & LpdbFPSchedule::getFldt() const
{
   return r_fldt;
}


const boost::optional<posix_time::ptime> & LpdbFPSchedule::getSldt() const
{
   return r_sldt;
}


const boost::optional<posix_time::ptime> &LpdbFPSchedule::getIldt() const
{
   return r_ildt;
}


void LpdbFPSchedule::setFldt(posix_time::ptime fldt)
{
   r_fldt = fldt;
}


void LpdbFPSchedule::setSldt(posix_time::ptime sldt)
{
   r_sldt = sldt;
}


void LpdbFPSchedule::setIldt(posix_time::ptime ildt)
{
   r_ildt = ildt;
}


const boost::optional<posix_time::ptime> & LpdbFPSchedule::getFtot() const
{
   return r_ftot;
}


const boost::optional<posix_time::ptime> & LpdbFPSchedule::getStot() const
{
   return r_stot;
}


const boost::optional<posix_time::ptime> & LpdbFPSchedule::getItot() const
{
   return r_itot;
}


void LpdbFPSchedule::setFtot(posix_time::ptime ftot)
{
   r_ftot = ftot;
}


void LpdbFPSchedule::setStot(posix_time::ptime stot)
{
   r_stot = stot;
}


void LpdbFPSchedule::setItot(posix_time::ptime itot)
{
   r_itot = itot;
}


const boost::optional<posix_time::ptime> & LpdbFPSchedule::getEobt() const
{
   return r_eobt;
}

void LpdbFPSchedule::setEobt(const posix_time::ptime & eobt)
{
   r_eobt = eobt;
}


boost::optional<double> LpdbFPSchedule::getLdForecastedDelay() const
{
   return r_ld_forecasted_delay;
}


void LpdbFPSchedule::setLdForecastedDelay(double ld_forecasted_delay)
{
   r_ld_forecasted_delay = ld_forecasted_delay;
}


boost::optional<double> LpdbFPSchedule::getToForecastedDelay() const
{
   return r_to_forecasted_delay;
}


void LpdbFPSchedule::setToForecastedDelay(double to_forecasted_delay)
{
   r_to_forecasted_delay = to_forecasted_delay;
}


boost::optional<double> LpdbFPSchedule::getLdPunctualityDelay() const
{
   return r_ld_punctuality_delay;
}


void LpdbFPSchedule::setLdPunctualityDelay(double ld_punctuality_delay)
{
   r_ld_punctuality_delay = ld_punctuality_delay;
}


boost::optional<double> LpdbFPSchedule::getToPunctualityDelay() const
{
   return r_to_punctuality_delay;
}


void LpdbFPSchedule::setToPunctualityDelay(double to_punctuality_delay)
{
   r_to_punctuality_delay = to_punctuality_delay;
}


std::string LpdbFPSchedule::getUniqueKey() const
{
   return r_key;
}


boost::optional<posix_time::ptime> LpdbFPSchedule::getAssignedTime() const
{
   boost::optional<posix_time::ptime> result = boost::none;

   if (r_operation_type == LpiOperationType::E_ARRIVAL)
   {
      result = r_fldt;
   }
   else if (r_operation_type == LpiOperationType::E_DEPARTURE)
   {
      result = r_ftot;
   }

   return result;
}


LpiScheduledFlightPlan LpdbFPSchedule::convertToInterface (const LpdbFPSchedule & fp)
{
   LpiScheduledFlightPlan convertedFP;

   convertedFP.setcallsign(fp.getCallsign());
   convertedFP.setdepAerodrome(fp.getDepartureAerodrome());
   convertedFP.setarrAerodrome(fp.getArrivalAerodrome());

   convertedFP.setAssignedRunway(fp.getAssignedRunway());

   if(fp.getOperationType() == LpiOperationType::E_ARRIVAL)
   {
      //ArrivalTimes
      ArrivalInfo arrival;
      convertedFP.setopType("ARR");

      if(fp.getIldt())
      {
         arrival.setildt(*fp.getIldt());
      }
      if(fp.getSldt())
      {
         arrival.setsldt(*(fp.getSldt()));
      }
      if(fp.getFldt())
      {
         arrival.setfldt(*fp.getFldt());
      }
      if (fp.getEobt())
      {
         arrival.setEobt(*fp.getEobt());
      }
      if(fp.getLdForecastedDelay())
      {
         convertedFP.setforecastDelay(*fp.getLdForecastedDelay());
      }
      if(fp.getLdPunctualityDelay())
      {
         convertedFP.setpunctualityDelay(*fp.getLdPunctualityDelay());
      }

      convertedFP.setarrivalTimes(arrival);
   }

   if(fp.getOperationType() == LpiOperationType::E_DEPARTURE)
   {
      //DepartureTimes
      DepartureInfo departure;
      convertedFP.setopType("DEP");

      if(fp.getItot())
      {
         departure.setitot(*fp.getItot());
      }
      if(fp.getStot())
      {
         departure.setstot(*(fp.getStot()));
      }
      if(fp.getFtot())
      {
         departure.setftot(*fp.getFtot());
      }
      if (fp.getEobt())
      {
         departure.setEobt(*fp.getEobt());
      }
      if(fp.getToForecastedDelay())
      {
         convertedFP.setforecastDelay(*fp.getToForecastedDelay());
      }
      if(fp.getToPunctualityDelay())
      {
         convertedFP.setpunctualityDelay(static_cast<int>(*fp.getToPunctualityDelay()));
      }

      convertedFP.setdepartureTimes(departure);
   }

   convertedFP.setTurnRoundDelayed(fp.getTurnRoundDelayed());

   return convertedFP;
}


const bool & LpdbFPSchedule::getTurnRoundDelayed() const
{
   return r_turnRoundDelayed;
}


void LpdbFPSchedule::setTurnRoundDelayed(const bool & delayed)
{
   r_turnRoundDelayed = delayed;
}


boost::optional<posix_time::ptime> LpdbFPSchedule::getIntentionalTime() const
{
   boost::optional<posix_time::ptime> result = boost::none;

   switch(r_operation_type)
   {
      case LpiOperationType::E_ARRIVAL:
         result = r_ildt;
      break;

      case LpiOperationType::E_DEPARTURE:
         result = r_itot;
      break;

      case LpiOperationType::E_NONE:
      default:
      break;
   }

   return result;
}


std::ostream& operator<< (std::ostream & out, const LpdbFPSchedule & fp)
{
          out << "[KEY: "  << fp.getUniqueKey()
              << "|CSGN: " << fp.getCallsign();

              if(fp.getFtot())
                 out << "|FTOT: " << *fp.getFtot();
              if(fp.getStot())
                 out << "|STOT: " << *fp.getStot();
              if(fp.getItot())
                 out << "|ITOT: " << *fp.getItot();
              if(fp.getFldt())
                 out << "|FLDT: " << *fp.getFldt();
              if(fp.getSldt())
                 out << "|SLDT: " << *fp.getSldt();
              if(fp.getIldt())
                 out << "|ILDT: " << *fp.getIldt();
              if (fp.getEobt())
                 out << "|EOBT: " << *fp.getEobt();
              if(fp.getLdForecastedDelay())
                 out << "|LD FORECASTED DELAY: " << *fp.getLdForecastedDelay();
              if(fp.getToForecastedDelay())
                 out << "|TO FORECASTED DELAY: " << *fp.getToForecastedDelay();
              if(fp.getLdPunctualityDelay())
                 out << "|LD PUNCTUALITY DELAY: " << fp.getLdPunctualityDelay();
              if(fp.getToPunctualityDelay())
                 out << "|TO PUNCTUALITY DELAY: " << fp.getToPunctualityDelay();
 
              out << "|TURN-ROUND DLYD: " << "false\0true" + 6*fp.getTurnRoundDelayed()
                  << ']';
   return out;
}
