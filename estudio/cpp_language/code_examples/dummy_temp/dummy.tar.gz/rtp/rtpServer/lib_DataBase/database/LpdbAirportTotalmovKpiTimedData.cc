/**@file LpdbAirportTotalmovKpiTimedData.cc
 */

#include <LpdbAirportTotalmovKpiTimedData.h>
#include <iostream>

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & os, const LpdbAirportTotalmovKpiTimedData & data)
{
  return os << "TOTAL-MOVEMENTS-KPI VALUE: " << data.get();
}
