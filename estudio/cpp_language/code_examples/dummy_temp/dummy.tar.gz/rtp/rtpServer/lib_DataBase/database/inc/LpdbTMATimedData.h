/**@file LpdbTMATimedData.h:
 *
 * @brief TMA values ({ARR, DEP. OVE}) for a concrete interval.
 *
 */

#ifndef LPDBTMATIMEDDATA_H_
#define LPDBTMATIMEDDATA_H_

#include <LplcTypeConstants.h>
#include <LpiADOVector.h>
#include <iosfwd>


class LpdbTMATimedData
{
 public:
  LpdbTMATimedData() = default;
  LpdbTMATimedData(const LpdbTMATimedData& source) = default;
  LpdbTMATimedData & operator =(const LpdbTMATimedData& source) = default;
  virtual ~LpdbTMATimedData() {}

  LpiADOVector<unsigned int> getCapacity() const { return r_capacity; }

  //void setCapacity(const LpiADOVector<unsigned int> &new_val)
  //{ r_capacity = new_val; }

  void calculateCapacity(unsigned int numberOfIntervals,
			 const LpiADOVector<unsigned int> & nominalCapacity);

 protected:

  ///@param r_capacity: capacity per interval = nominal capacity / num intervals
  LpiADOVector<unsigned int> r_capacity = 
    {rtp_constants::TMA_NOMINAL_CAPACITY_DEFAULT,
     rtp_constants::TMA_NOMINAL_CAPACITY_DEFAULT,
     rtp_constants::TMA_NOMINAL_CAPACITY_DEFAULT};
 
  ///@warning RMAN's used manual capacity reductions, RTP doesn't
  // LpiADOVector<unsigned int>  r_manual_capacity_reduction; // not in RTP
  // bool r_hasManualReduction;

};

std::ostream & operator<<(std::ostream & os, const LpdbTMATimedData &);

#endif /* LPDBTMATIMEDDATA_H_ */
