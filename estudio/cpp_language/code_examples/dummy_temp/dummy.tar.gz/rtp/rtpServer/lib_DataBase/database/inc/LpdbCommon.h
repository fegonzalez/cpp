/**@file LpdbCommon.h
 *
 * Common definitions among the data base.
 *
 */

#ifndef LPDB_COMMON_H_
#define LPDB_COMMON_H_

#include <string>


typedef std::string KEY_AIRPORT_ID;
 

#endif /* LPDB_COMMON_H_ */

