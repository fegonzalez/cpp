/*
 * LpdbRunwaySystemTimedData.cc
 *
 *  Created on: 17/12/2013
 *      Author: mbegega
 */

#include "LpdbRunwaySystemTimedData.h"


LpdbRunwaySystemTimedData::LpdbRunwaySystemTimedData()
: r_name("LpdbRunwaySystemTimedData"),
  r_max_capacity(),
  r_rwys_max_capacity(),
  r_nominal_max_capacity(),
  r_estimated_dc_margin(),
  r_dcb_suitability(),
  r_estimated_delayed_fps(),
  r_notAllowedEstimatedFPs()
{
}


LpdbRunwaySystemTimedData::LpdbRunwaySystemTimedData(const LpdbRunwaySystemTimedData & source)
: r_name(source.r_name),
  r_max_capacity(source.r_max_capacity),
  r_rwys_max_capacity(source.r_rwys_max_capacity),
  r_nominal_max_capacity(source.r_nominal_max_capacity),
  r_estimated_dc_margin(source.r_estimated_dc_margin),
  r_dcb_suitability(source.r_dcb_suitability),
  r_estimated_delayed_fps(source.r_estimated_delayed_fps),
  r_notAllowedEstimatedFPs(source.r_notAllowedEstimatedFPs)
{
}


LpdbRunwaySystemTimedData::~LpdbRunwaySystemTimedData()
{

}


LpdbRunwaySystemTimedData & LpdbRunwaySystemTimedData::operator= (const LpdbRunwaySystemTimedData & source)
{
   if (this != &source)
   {
      r_name= source.r_name;
      r_max_capacity = source.r_max_capacity;
      r_rwys_max_capacity = source.r_rwys_max_capacity;
      r_nominal_max_capacity = source.r_nominal_max_capacity;
      r_estimated_dc_margin = source.r_estimated_dc_margin;
      r_dcb_suitability = source.r_dcb_suitability;
      r_estimated_delayed_fps = source.r_estimated_delayed_fps;
      r_notAllowedEstimatedFPs = source.r_notAllowedEstimatedFPs;
   }

   return *this;
}


std::string LpdbRunwaySystemTimedData::get_name () const
{
   return r_name;
}


LpiADOVector<float> LpdbRunwaySystemTimedData::getDcbSuitability() const
{
   return r_dcb_suitability;
}


void LpdbRunwaySystemTimedData::setDcbSuitability(
      LpiADOVector<float> dcbSuitability)
{
   r_dcb_suitability = dcbSuitability;
}


LpiADOVector<int> LpdbRunwaySystemTimedData::getEstimatedDcMargin() const
{
   return r_estimated_dc_margin;
}


void LpdbRunwaySystemTimedData::setEstimatedDcMargin(
      LpiADOVector<int> estimatedDcMargin)
{
   r_estimated_dc_margin = estimatedDcMargin;
}


LpiADOVector<int> LpdbRunwaySystemTimedData::getEstimatedDelayedFps() const
{
   return r_estimated_delayed_fps;
}


void LpdbRunwaySystemTimedData::setEstimatedDelayedFps(
      LpiADOVector<int> estimatedDelayedFps)
{
   r_estimated_delayed_fps = estimatedDelayedFps;
}


LpiADOVector<int> LpdbRunwaySystemTimedData::getMaxCapacity() const {
   return r_max_capacity;
}


void LpdbRunwaySystemTimedData::setMaxCapacity(LpiADOVector<int> maxCapacity)
{
   r_max_capacity = maxCapacity;
}


LpiADOVector<int> LpdbRunwaySystemTimedData::getRwysMaxCapacity() const {
   return r_rwys_max_capacity;
}


void LpdbRunwaySystemTimedData::setRwysMaxCapacity(LpiADOVector<int> maxCapacity)
{
   r_rwys_max_capacity = maxCapacity;
}


LpiADOVector<int> LpdbRunwaySystemTimedData::getNominalMaxCapacity() const
{
   return r_nominal_max_capacity;
}


void LpdbRunwaySystemTimedData::setNominalMaxCapacity(LpiADOVector<int> maxCapacity)
{
   r_nominal_max_capacity = maxCapacity;
}


LpiADOVector<int> LpdbRunwaySystemTimedData::getNotAllowedEstimatedFPs() const
{
   return r_notAllowedEstimatedFPs;
}


void LpdbRunwaySystemTimedData::setNotAllowedEstimatedFPs(LpiADOVector<int> notAllowed)
{
   r_notAllowedEstimatedFPs = notAllowed;
}


std::ostream& operator<<(std::ostream &os, const LpdbRunwaySystemTimedData &info)
{
   return os << "RS_RWYS_NOM_CAP : " << info.getRwysMaxCapacity()
             << " | MAX_CAP : " << info.getMaxCapacity()
             << " | EST_NOT_ALLWD : " << info.getNotAllowedEstimatedFPs()
             << " | MRG : "  << info.getEstimatedDcMargin()
             << " | SUIT : " << info.getDcbSuitability()
             << " | EDLY : " << info.getEstimatedDelayedFps();
}

