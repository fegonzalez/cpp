/*
 * LpdbWarningErrors.cc
 *
 *  Created on: 31/07/2013
 *      Author: gpfernandez
 */

#include "LpdbWarningErrors.h"
//#include "LpdbDataBase.h"


LpdbWarningErrors::LpdbWarningErrors()
:r_max_forecast_delayWA(),
 r_punctual_porcentageWA(),
 r_average_forecasted_delay_delayedFPsWA()
{
   Warnings_alerts defaultAlert(Warnings_alerts::E_NO_ALERT,
                                Warnings_alerts::E_NO_ALERT,
                                Warnings_alerts::E_NO_ALERT);

   r_max_forecast_delayWA        = defaultAlert;
   r_punctual_porcentageWA       = defaultAlert;
   r_average_forecasted_delay_delayedFPsWA = defaultAlert;
}


LpdbWarningErrors::LpdbWarningErrors(const LpdbWarningErrors & source)
: r_max_forecast_delayWA(source.r_max_forecast_delayWA),
  r_punctual_porcentageWA(source.r_punctual_porcentageWA),
  r_average_forecasted_delay_delayedFPsWA(source.r_average_forecasted_delay_delayedFPsWA)
{
}


LpdbWarningErrors & LpdbWarningErrors::operator= (const LpdbWarningErrors & source)
{
   if (this != &source)
   {
      r_max_forecast_delayWA = source.r_max_forecast_delayWA;
      r_punctual_porcentageWA = source.r_punctual_porcentageWA;
      r_average_forecasted_delay_delayedFPsWA = source.r_average_forecasted_delay_delayedFPsWA;
   }

   return *this;
}


Warnings_alerts LpdbWarningErrors::Alarm_Warning(int n1,
                                                LpiADOVector<double> kpi,
                                                LpiADO alarmThreshold,
                                                LpiADO warningThreshold,
                                                string comparison)
{

   return Alarm_Warning(n1,
                        LpiADO::convert2Interface(kpi),
                        alarmThreshold,
                        warningThreshold,
                        comparison);

}


Warnings_alerts LpdbWarningErrors::Alarm_Warning(int n1,
                                                LpiADO kpi,
                                                LpiADO alarmThreshold,
                                                LpiADO warningThreshold,
                                                string comparison)
{
   /*Warnings_alerts::LpiEnum sNo_Alert = Warnings_alerts::E_NO_ALERT;
   Warnings_alerts::LpiEnum sWarning = Warnings_alerts::E_WARNING;
   Warnings_alerts::LpiEnum sAlarm = Warnings_alerts::E_ALARM;
*/
   Warnings_alerts vADO;
   /*vADO.setarrivals(sNo_Alert);
   vADO.setdepartures(sNo_Alert);
   vADO.setoverall(sNo_Alert);

   bool empty_demand = LpdbDataBase::Get().getDemand().isEmpty();
   if (empty_demand)
   {
       return vADO;
   }

   if(comparison.compare("less") == 0)
   {
        if( kpi.getarrivalsValue() == -1)
        {
           vADO.setarrivals(sNo_Alert);
        }
        else if( kpi.getarrivalsValue() < alarmThreshold.getarrivalsValue()/n1)
        {
           vADO.setarrivals(sAlarm);
        }
        else if(kpi.getarrivalsValue() < warningThreshold.getarrivalsValue()/n1)
        {
            vADO.setarrivals(sWarning);
        }

        if(kpi.getdeparturesValue() ==-1)
        {
           vADO.setdepartures(sNo_Alert);
        }
        else if(kpi.getdeparturesValue() < alarmThreshold.getdeparturesValue()/n1)
        {
           vADO.setdepartures(sAlarm);
        }
        else if(kpi.getdeparturesValue() < warningThreshold.getdeparturesValue()/n1)
        {
            vADO.setdepartures(sWarning);
        }

        if(kpi.getoverallValue() == -1)
        {
           vADO.setoverall(sNo_Alert);
        }
        else if(kpi.getoverallValue() < alarmThreshold.getoverallValue()/n1)
        {
           vADO.setoverall(sAlarm);
        }
        else if(kpi.getoverallValue() < warningThreshold.getoverallValue()/n1)
        {
            vADO.setoverall(sWarning);
        }
   }
   else if (comparison.compare("more") == 0)
   {
        if(kpi.getarrivalsValue() == -1)
        {
           vADO.setarrivals(sNo_Alert);
        }
        else if(kpi.getarrivalsValue() > alarmThreshold.getarrivalsValue()/n1)
        {
           vADO.setarrivals(sAlarm);
        }
        else if(kpi.getarrivalsValue() > warningThreshold.getarrivalsValue()/n1)
        {
            vADO.setarrivals(sWarning);
        }

        if(kpi.getdeparturesValue() == -1)
        {
           vADO.setdepartures(sNo_Alert);
        }
        else if(kpi.getdeparturesValue() > alarmThreshold.getdeparturesValue()/n1)
        {
           vADO.setdepartures(sAlarm);
        }
        else if(kpi.getdeparturesValue() > warningThreshold.getdeparturesValue()/n1)
        {
            vADO.setdepartures(sWarning);
        }

        if(kpi.getoverallValue() == -1)
        {
           vADO.setoverall(sNo_Alert);
        }
        else if(kpi.getoverallValue() > alarmThreshold.getoverallValue()/n1)
        {
           vADO.setoverall(sAlarm);
        }
        else if(kpi.getoverallValue() > warningThreshold.getoverallValue()/n1)
        {
            vADO.setoverall(sWarning);
        }
   }*/
   return vADO;
}


Warnings_alerts LpdbWarningErrors::convert2Interface (const vector<string> & calculatedWarnings)
{
   Warnings_alerts response;

   response.setarrivals  (Warnings_alerts::FromString(calculatedWarnings[E_ARR]));
   response.setdepartures(Warnings_alerts::FromString(calculatedWarnings[E_DEP]));
   response.setoverall   (Warnings_alerts::FromString(calculatedWarnings[E_OVA]));

   return response;
}
