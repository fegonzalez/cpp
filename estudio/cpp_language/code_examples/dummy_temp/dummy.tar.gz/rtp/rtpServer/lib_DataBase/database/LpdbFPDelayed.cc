/*
 * LpdbFPDelayed.cc
 *
 *  Created on: 05/05/2014
 *      Author: gpfernandez
 */

#include <iostream>
#include "LpdbFPDelayed.h"

LpdbFPDelayed::LpdbFPDelayed()
{
}


LpdbFPDelayed::LpdbFPDelayed(const std::string & fpKey)
: r_fpKey(fpKey)
{
}


LpdbFPDelayed::LpdbFPDelayed(const std::string & fpKey,
                           const std::string & callsign,
                           const std::string & departure,
                           const std::string & arrival,
                           const boost::optional<posix_time::ptime> & eobt)
: r_fpKey(fpKey),
  r_callsign(callsign),
  r_departure_aerodrome(departure),
  r_arrival_aerodrome(arrival),
  r_eobt(eobt)
{
}


LpdbFPDelayed::LpdbFPDelayed(const LpdbFPDelayed & source)
: r_fpKey(source.r_fpKey),
  r_callsign(source.r_callsign),
 r_departure_aerodrome(source.r_departure_aerodrome),
 r_arrival_aerodrome(source.r_departure_aerodrome),
  r_operation_type(source.r_operation_type),
  r_eobt(source.r_eobt)
{
}


LpdbFPDelayed & LpdbFPDelayed::operator= (const LpdbFPDelayed & source)
{
   if (this != &source)
   {
      r_fpKey = source.r_fpKey;
      r_callsign = source.r_callsign;
      r_departure_aerodrome = source.r_departure_aerodrome;
      r_arrival_aerodrome = source.r_arrival_aerodrome;
      r_operation_type = source.r_operation_type;
      r_eobt = source.r_eobt;
   }

   return *this;
}


std::string LpdbFPDelayed::getCallsign() const
{
   return r_callsign;
}


void LpdbFPDelayed::setCallsign(const std::string & callsign)
{
   r_callsign = callsign;
}


std::string LpdbFPDelayed::getArrivalAerodrome() const
{
   return r_arrival_aerodrome;
}


void LpdbFPDelayed::setArrivalAerodrome(const std::string & arrivalAerodrome)
{
   r_arrival_aerodrome = arrivalAerodrome;
}


std::string LpdbFPDelayed::getDepartureAerodrome() const
{
   return r_departure_aerodrome;
}


void LpdbFPDelayed::setDepartureAerodrome(const std::string & departureAerodrome)
{
   r_departure_aerodrome = departureAerodrome;
}


std::string LpdbFPDelayed::getUniqueKey() const
{
   return r_fpKey;
}


inline std::ostream& operator<< (std::ostream & out, const LpdbFPDelayed & fp)
{
   return out << "[CSGN: " << fp.getCallsign()
              << ']';
}
