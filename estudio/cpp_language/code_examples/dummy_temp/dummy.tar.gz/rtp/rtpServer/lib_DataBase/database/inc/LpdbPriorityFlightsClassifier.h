/*
 * LpdbPriorityFlightsClassifier.h
 *
 *  Created on: 23/07/2015
 *      Author: mbegega
 */

#ifndef LPBPRIORITYFLIGHTSCLASSIFIER_H_
#define LPBPRIORITYFLIGHTSCLASSIFIER_H_

#include <vector>
#include <string>
#include <map>

using std::vector;
using std::map;
using std::string;


typedef map<int, vector<string> > PriorityMap;


class LpdbPriorityFlightsClassifier
{
   public:

      static void ClassifyFlights(vector<string> collectionToCheck,
                                  vector<string> flightsToClassify,
                                  PriorityMap & categoryDelayedWithPriority,
                                  vector<string> & categoryDelayedWithoutPriority,
                                  PriorityMap & categoryWithPriority,
                                  vector<string> & categoryWithoutPriority);

      static vector<string> MergeClassifiedByPriority(PriorityMap firstCategoryWithPriority,
                                                      vector<string> firstCategoryWithoutPriority,
                                                      PriorityMap secondCategoryWithPriority,
                                                      vector<string> secondCategoryWithoutPriority);
   private:

      LpdbPriorityFlightsClassifier();
      LpdbPriorityFlightsClassifier(const LpdbPriorityFlightsClassifier & source);
};


#endif /* LPBPRIORITYFLIGHTSCLASSIFIER_H_ */
