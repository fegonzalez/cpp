/**@file LpdbTWYTimedData.h:
 *
 * @brief TWY values ({ARR, DEP. OVE}) for a concrete interval.
 *
 */

#ifndef LPDBTWYTIMEDDATA_H_
#define LPDBTWYTIMEDDATA_H_

#include <LplcTypeConstants.h>
#include <LpiADOVector.h>
#include <iosfwd>


class LpdbTWYTimedData
{
 public:
  LpdbTWYTimedData() = default;
  LpdbTWYTimedData(const LpdbTWYTimedData& source) = default;
  LpdbTWYTimedData & operator =(const LpdbTWYTimedData& source) = default;
  virtual ~LpdbTWYTimedData() {}

  LpiADOVector<unsigned int> getCapacity() const { return r_capacity; }
  //  void setCapacity(unsigned int capacity);
  void calculateCapacity(unsigned int numberOfIntervals,
			 const LpiADOVector<unsigned int> & nominalCapacity);

 protected:

  ///@param r_capacity: capacity per interval = nominal capacity / num intervals
  LpiADOVector<unsigned int> r_capacity = 
    {rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT,
     rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT,
     rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT};

};

std::ostream & operator<<(std::ostream & os, const LpdbTWYTimedData & info);


#endif /* LPDBTWYTIMEDDATA_H_ */
