/*
 * LpdbTWYTimedData.h
 *
 */

#ifndef LPDBTWYTIMEDDATA_H_
#define LPDBTWYTIMEDDATA_H_

#include <iosfwd>


class LpdbTWYTimedData
{
 public:
  LpdbTWYTimedData() = default;
  LpdbTWYTimedData(const LpdbTWYTimedData& source) = default;
  LpdbTWYTimedData & operator =(const LpdbTWYTimedData& source) = default;
  virtual ~LpdbTWYTimedData() {}

  inline unsigned int getCapacity() const;
  //  void setCapacity(unsigned int capacity);
  void calculateCapacity(unsigned int numberOfIntervals,
			 unsigned int nominalCapacity);

 protected:

  ///@param r_capacity: capacity per interval = nominal capacity / num intervals
  unsigned int r_capacity = 0;  ///@warning  -1 in RMAN == NULL ?

};

std::ostream & operator<<(std::ostream & os, const LpdbTWYTimedData & info);


#endif /* LPDBTWYTIMEDDATA_H_ */
