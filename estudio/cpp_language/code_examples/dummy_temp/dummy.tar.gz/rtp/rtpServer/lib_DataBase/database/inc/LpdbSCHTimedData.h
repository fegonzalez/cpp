/*
 * LpdbSCHTimedData.h
 *
 *  Created on: 03/12/2013
 *      Author: mbegega
 *
 *  Description: Stores data of a schedule timeline interval
 */

#ifndef SCHTIMEDDATA_H_
#define SCHTIMEDDATA_H_

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/foreach.hpp>
#include <boost/optional.hpp>
#include <LpiADOVector.h>
#include <algorithm>
#include <LpiFlightPlan.h>
#include <LpdbAirportIntervalComparativeKPIs.h>

using std::vector;
using std::string;


class LpdbSCHTimedData
{
public:

   LpdbSCHTimedData() = default;
   LpdbSCHTimedData(const LpdbSCHTimedData & source) = default;
   LpdbSCHTimedData & operator= (const LpdbSCHTimedData & source) = default;
   virtual ~LpdbSCHTimedData();

   std::string get_name ();

   //RS scheduled in interval
//
//   LpdbRSScheduled getRsScheduled() const;
//   void setRsScheduled(LpdbRSScheduled rsScheduled);

   //Only for modification
   //LpdbRSScheduled & getRsScheduled();

   //Delayed Getters and Setters

   LpiADOVector<int> getDefaultDelayedFps() const;
   void setDefaultDelayedFps(const LpiADOVector<int> & defaultDelayedFps);

   LpiADOVector<vector<string> > getDefaultDelayedFpsFps() const;
   void setDefaultDelayedFpsFps(const LpiADOVector<vector<string> > & defaultDelayedFpsFps);

   LpiADOVector<int> getRealDelayedFps() const;
   void setRealDelayedFps(const LpiADOVector<int> & realDelayedFps);

   LpiADOVector<vector<string> > getRealDelayedFpsFps() const;
   void setRealDelayedFpsFps(const LpiADOVector<vector<string> > & realDelayedFpsFps);

   LpiADOVector<int> getDelayedFps() const;
   void setDelayedFps(const LpiADOVector<int> & delayedFps);

   LpiADOVector<int> getDeltaShortage() const;
   void setDeltaShortage(const LpiADOVector<int> & deltaShortage);

   LpiADOVector<int> getRelativeShortage() const;
   void setRelativeShortage(const LpiADOVector<int> & relativeShortage);

   LpiADOVector<vector<string> > getDelayedFpsFps() const;
   void setDelayedFpsFps(const LpiADOVector<vector<string> > & delayedFpsFps);

   LpiADOVector<int> getNotAllowedDelayedFps() const;
   void setNotAllowedDelayedFps(const LpiADOVector<int> & notAllowedDelayedFps);

   LpiADOVector<vector<string> > getNotAllowedDelayedFpsFps() const;
   void setNotAllowedDelayedFpsFps(const LpiADOVector<vector<string> > & notAllowedDelayedFpsFps);

   LpiADOVector<int> getTurnRoundDelayedFps() const;
   void setTurnRoundDelayedFps(const LpiADOVector<int> & turnRoundDelayedFps);

   LpiADOVector<vector<string> > getTurnRoundDelayedFpsFps() const;
   void setTurnRoundDelayedFpsFps(const LpiADOVector<vector<string> > & turnRoundDelayedFpsFps);

   //Shortage
   LpiADOVector<int> getShortage() const;
   void setShortage(const LpiADOVector<int> & shortage);   


   //Demand
   LpiADOVector<int> getRealDemandFps() const;
   void setRealDemandFps(const LpiADOVector<int> & realDemandFps);

   LpiADOVector<vector<string> > getRealDemandFpsFps() const;
   void setRealDemandFpsFps(const LpiADOVector<vector<string> > & realDemandFpsFps);

   //Accepted
   LpiADOVector<int> getRealAcceptedFps() const;
   void setRealAcceptedFps(const LpiADOVector<int> & realAcceptedFps);
 
   LpiADOVector<vector<string> > getRealAcceptedFpsFps() const;
   void setRealAcceptedFpsFps(const LpiADOVector<vector<string> > & realAcceptedFpsFps);

   //Capacity
   LpiADOVector<int> getMaxCapacity() const;
   void setMaxCapacity(const LpiADOVector<int> & maxCapacity);

   LpiADOVector<int> getRwysMaxCapacity() const;
   void setRwysMaxCapacity(LpiADOVector<int> maxCapacity);

   LpiADOVector<int> getRelativeMaxCapacity() const;
   void setRelativeMaxCapacity(const LpiADOVector<int> & relativeMaxCapacity);

   LpiADOVector<int> getRelativeRwysMaxCapacity() const;
   void setRelativeRwysMaxCapacity(LpiADOVector<int> RelativemaxCapacity);

   LpiADOVector<int> getRealDcMargin() const;
   void setRealDcMargin(const LpiADOVector<int> & realDcMargin);

   LpiADOVector<int> getSurplus() const;
   void setSurplus(const LpiADOVector<int> & surplus);

   static string getFPKeysVectorAsString (const LpiADOVector<vector<string> > & data, bool showPriorities = false);

   LpiADOVector<int> getTotalDemand() const;
   LpiADOVector<int> getInheritedDemand() const;
   LpiADOVector<int> getIntentionalDemand() const;
   void setTotalDemand(const LpiADOVector<int> & value);
   void setInheritedDemand(const LpiADOVector<int> & value);
   void setIntentionalDemand(const LpiADOVector<int> & value);


   //Phase II: Delta and relative KPIs and Alerts

   LpiADOVector<int> getPreviousMaxCapacity() { return r_max_capacity_previous; }
   LpiADOVector<int> getPreviousRSCapacity () { return r_rwys_max_capacity_previous; }
   LpiADOVector<int> getPreviousShortage()    { return r_shortage_previous; }

   LpdbAirportIntervalComparativeKPIs getDeltaKPIs() { return r_deltaKPIs; }
   LpdbAirportIntervalComparativeKPIs getRelativeKPIs() { return r_relativeKPIs; }

   void setDeltaKPIs(const LpdbAirportIntervalComparativeKPIs & kpis) { r_deltaKPIs = kpis; }
   void setRelativeKPIs(const LpdbAirportIntervalComparativeKPIs & kpis) { r_relativeKPIs = kpis; }

   void resetComparativeKPIs();
//   void generateComparativeKPIs (string interval, LpiConfigurationAlertKPIs & alertThresholds, bool isClockForwarding, bool isLastInterval);
//   void generateDeltaKPIs(LpiConfigurationAlertKPIs & alertThresholds);
//   void generateRelativeKPIs(string interval, LpiConfigurationAlertKPIs & alertThresholds);
//
//   void generateRelativeKPIs(LpdbSCHTimedData & interval_data, LpiConfigurationAlertKPIs & alertThresholds);

   std::string getAbsoluteKpisAsString() const;

protected:

   std::string r_name;
   //LpdbRSScheduled r_rs_scheduled;   // Runway System Scheduled in this interval

   LpiADOVector<int>             r_default_delayed_fps;
   LpiADOVector<vector<string> > r_default_delayed_fps_fps;

   LpiADOVector<int>             r_shortage;

   LpiADOVector<int>             r_real_delayed_fps;
   LpiADOVector<vector<string> > r_real_delayed_fps_fps;

   // Delayed by lack of capacity
   LpiADOVector<int>             r_delayed_fps;
   LpiADOVector<vector<string> > r_delayed_fps_fps;

   //Delayed by not permitted
   LpiADOVector<int>             r_not_allowed_delayed_fps;
   LpiADOVector<vector<string> > r_not_allowed_delayed_fps_fps;

   //Delayed by turn-round
   LpiADOVector<int>             r_turn_round_delayed_fps;
   LpiADOVector<vector<string> > r_turn_round_delayed_fps_fps;

   //Real demand, accumulated plus provided
   LpiADOVector<int>             r_real_demand_fps;
   LpiADOVector<vector<string> > r_real_demand_fps_fps;

   //Phase II
   LpiADOVector<int>             r_total_demand;
   LpiADOVector<int>             r_inherited_demand;
   LpiADOVector<int>             r_intentional_demand;

   //Real accepted flights
   LpiADOVector<int>             r_real_accepted_fps;
   LpiADOVector<vector<string> > r_real_accepted_fps_fps;

   //Capacity of scheduled RS
   LpiADOVector<int>             r_max_capacity;
   LpiADOVector<int>             r_rwys_max_capacity;

   LpiADOVector<int>             r_real_dc_margin;
   LpiADOVector<int>             r_surplus;

   //Previous backup values for delta KPIs calculation
   LpiADOVector<int>             r_max_capacity_previous;
   LpiADOVector<int>             r_rwys_max_capacity_previous;
   LpiADOVector<int>             r_shortage_previous;

   LpdbAirportIntervalComparativeKPIs r_deltaKPIs;
   LpdbAirportIntervalComparativeKPIs r_relativeKPIs;
};


std::ostream& operator<<(std::ostream &os, const LpdbSCHTimedData &info);

#endif /* SCHTIMEDDATA_H_ */
