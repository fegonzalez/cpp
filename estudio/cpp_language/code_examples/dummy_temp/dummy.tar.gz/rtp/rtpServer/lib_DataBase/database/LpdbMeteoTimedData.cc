/*
 * LpdbMeteoTimedData.cc
 *
 *  Created on: 02/01/2013
 *      Author: mbegega
 */
#include <iostream>
#include <sstream>

#include <boost/foreach.hpp>

#include "LpdbMeteoTimedData.h"

LpdbMeteoTimedData::LpdbMeteoTimedData()
: r_name(),
  r_hasNowcastReport(false)
//  r_crosswind(),
//  r_tailwind()
//r_tailwind_real(),
{
}


LpdbMeteoTimedData::LpdbMeteoTimedData(const LpdbMeteoTimedData & source)
:  r_name(source.r_name),
   r_hasNowcastReport(source.r_hasNowcastReport),
   r_horizontal_visibility(source.r_horizontal_visibility),
   r_wetness(source.r_wetness),
   r_ilsCategory(source.r_ilsCategory),
   r_lvp_activation(source.r_lvp_activation),
   r_deicing_required(source.r_deicing_required),
//   r_crosswind(source.r_crosswind),
//   r_tailwind(source.r_tailwind),
   r_wind_speed(source.r_wind_speed),
   r_wind_direction(source.r_wind_direction),
   r_rwy_meteo_info(source.r_rwy_meteo_info)
{
}


LpdbMeteoTimedData::~LpdbMeteoTimedData()
{

}


LpdbMeteoTimedData & LpdbMeteoTimedData::operator= (const LpdbMeteoTimedData & source)
{
   if (this != &source)
   {
      r_name = source.r_name;
      r_hasNowcastReport = source.r_hasNowcastReport;
//      r_crosswind = source.r_crosswind;
//      r_tailwind = source.r_tailwind;
      r_wind_speed = source.r_wind_speed;
      r_wind_direction = source.r_wind_direction;
      r_horizontal_visibility = source.r_horizontal_visibility;
      r_wetness = source.r_wetness;
      r_ilsCategory = source.r_ilsCategory;
      r_lvp_activation = source.r_lvp_activation;
      r_deicing_required = source.r_deicing_required;
      r_rwy_meteo_info = source.r_rwy_meteo_info;
   }

   return *this;
}


std::string LpdbMeteoTimedData::get_name ()
{
   return r_name;
}
const bool LpdbMeteoTimedData::getHasNowcastReport() const
{
   return r_hasNowcastReport;
}
void LpdbMeteoTimedData::setHasNowcastReport(bool hasNowcastReport)
{
   r_hasNowcastReport = hasNowcastReport;
}


//const boost::optional<double> & LpdbMeteoTimedData::getCrosswind() const
//{
//   return r_crosswind;
//}
//
//void LpdbMeteoTimedData::setCrosswind(boost::optional<double> crosswind)
//{
//   r_crosswind = crosswind;
//}
//
//const boost::optional<double> & LpdbMeteoTimedData::getTailwind() const
//{
//   return r_tailwind;
//}
//
//void LpdbMeteoTimedData::setTailwind(boost::optional<double> tailwind)
//{
//   r_tailwind = tailwind;
//}


const boost::optional<bool> & LpdbMeteoTimedData::getDeicingRequired() const
{
   return r_deicing_required;
}


void LpdbMeteoTimedData::setDeicingRequired(
      boost::optional<bool> deicingRequired)
{
   r_deicing_required = deicingRequired;
}


const boost::optional<double> & LpdbMeteoTimedData::getHorizontalVisibility() const
{
   return r_horizontal_visibility;
}


void LpdbMeteoTimedData::setHorizontalVisibility(
      boost::optional<double> horizontalVisibility)
{
   r_horizontal_visibility = horizontalVisibility;
}


const boost::optional<bool> & LpdbMeteoTimedData::getLvpActivation() const
{
   return r_lvp_activation;
}


void LpdbMeteoTimedData::setLvpActivation(boost::optional<bool> lvpActivation)
{
   r_lvp_activation = lvpActivation;
}

const boost::optional<std::string> & LpdbMeteoTimedData::getWetness() const
{
    return r_wetness;
}
void LpdbMeteoTimedData::setWetness(boost::optional<std::string> wetness)
{
   r_wetness = wetness;
}

const boost::optional<std::string> & LpdbMeteoTimedData::getIlsCategory() const
{
   return r_ilsCategory;
}
void LpdbMeteoTimedData::setIlsCategory(boost::optional<std::string> ilsCategory)
{
   r_ilsCategory = ilsCategory;
}


map<string, LpiRunwayMeteoInfo> LpdbMeteoTimedData::getRwyMeteoInfo() const
{
   return r_rwy_meteo_info;
}


void LpdbMeteoTimedData::setRwyMeteoInfo
(const map<string, LpiRunwayMeteoInfo> &rwyMeteoInfo)
{
   r_rwy_meteo_info = rwyMeteoInfo;
}


const boost::optional<unsigned int> & LpdbMeteoTimedData::getWindSpeed() const
{
   return r_wind_speed;
}


void LpdbMeteoTimedData::setWindSpeed(boost::optional<unsigned int> speed)
{
   r_wind_speed = speed;
}


const boost::optional<unsigned int> & LpdbMeteoTimedData::getWindDirection() const
{
   return r_wind_direction;
}


void LpdbMeteoTimedData::setWindDirection(boost::optional<unsigned int> direction)
{
   r_wind_direction = direction;
}


std::ostream& operator<<(std::ostream &os, const LpdbMeteoTimedData &info)
{
   std::stringstream out_stream;

   boost::optional<double> horizontal_visibility = info.getHorizontalVisibility();
   boost::optional<std::string> wetness = info.getWetness();
   boost::optional<std::string> ilsCategory = info.getIlsCategory();

   //   boost::optional<bool>  lvp_activation = info.getLvpActivation();
   //   boost::optional<bool>  deicing_required = info.getDeicingRequired();
//   boost::optional<double> crosswind = info.getCrosswind();
//   boost::optional<double> tailwind = info.getTailwind();
   bool nowCastReport = info.getHasNowcastReport();

   out_stream << '[';
   if(nowCastReport == true)
   {
      out_stream << "NOWCAST REPORT";
   }
   else
   {
      out_stream << "FORECAST REPORT";
   }

   if (horizontal_visibility)
   {
      out_stream << " | HOR_VIS : " << *horizontal_visibility;
   }
   else
   {
      out_stream << " | HOR_VIS : ---";
   }

   if (wetness)
   {
      out_stream << " | WET : " << *wetness;
   }
   else
   {
      out_stream << " | WET : ---";
   }

   if (ilsCategory.is_initialized())
   {
     out_stream << " | ILS : " << ilsCategory.get();
   }
   else
   {
      out_stream << " | ILS : ---";
   }

   if (info.getLvpActivation().is_initialized())
   {
     out_stream << " | LVP : " << info.getLvpActivation().get();
   }
   else
   {
      out_stream << " | LVP : ---";
   }

   if (info.getDeicingRequired().is_initialized())
   {
     out_stream << " | DEICNG : " << info.getDeicingRequired().get();
   }
   else
   {
      out_stream << " | DEICNG : ---";
   }

   typedef map<string, LpiRunwayMeteoInfo>::value_type runway_meteo_info;
   BOOST_FOREACH(const runway_meteo_info & element, info.getRwyMeteoInfo())
   {
      out_stream << ' ' << element.second;
   }

   out_stream << ']';

   return os << out_stream.str();
}
