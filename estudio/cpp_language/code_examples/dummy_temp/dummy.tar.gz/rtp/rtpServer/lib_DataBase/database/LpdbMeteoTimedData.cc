/*
 * LpdbMeteoTimedData.cc
 *
 *  Created on: 02/01/2013
 *      Author: mbegega
 */
#include <iostream>
#include <sstream>

#include <boost/foreach.hpp>

#include "LpdbMeteoTimedData.h"

std::string LpdbMeteoTimedData::get_name ()
{
   return r_name;
}
const bool LpdbMeteoTimedData::getHasNowcastReport() const
{
   return r_hasNowcastReport;
}
void LpdbMeteoTimedData::setHasNowcastReport(bool hasNowcastReport)
{
   r_hasNowcastReport = hasNowcastReport;
}


//const boost::optional<double> & LpdbMeteoTimedData::getCrosswind() const
//{
//   return r_crosswind;
//}
//
//void LpdbMeteoTimedData::setCrosswind(boost::optional<double> crosswind)
//{
//   r_crosswind = crosswind;
//}
//
//const boost::optional<double> & LpdbMeteoTimedData::getTailwind() const
//{
//   return r_tailwind;
//}
//
//void LpdbMeteoTimedData::setTailwind(boost::optional<double> tailwind)
//{
//   r_tailwind = tailwind;
//}


const boost::optional<double> & LpdbMeteoTimedData::getHorizontalVisibility() const
{
   return r_horizontal_visibility;
}
void LpdbMeteoTimedData::setHorizontalVisibility(boost::optional<double> horizontalVisibility)
{
   r_horizontal_visibility = horizontalVisibility;
}

const boost::optional<std::string> & LpdbMeteoTimedData::getWetness() const
{
    return r_wetness;
}
void LpdbMeteoTimedData::setWetness(boost::optional<std::string> wetness)
{
   r_wetness = wetness;
}

const boost::optional<std::string> & LpdbMeteoTimedData::getIlsCategory() const
{
   return r_ilsCategory;
}
void LpdbMeteoTimedData::setIlsCategory(boost::optional<std::string> ilsCategory)
{
   r_ilsCategory = ilsCategory;
}

const boost::optional<bool> & LpdbMeteoTimedData::getLvpActivation() const
{
   return r_lvp_activation;
}
void LpdbMeteoTimedData::setLvpActivation(boost::optional<bool> lvpActivation)
{
   r_lvp_activation = lvpActivation;
}

const boost::optional<unsigned int> & LpdbMeteoTimedData::getWindSpeed() const
{
   return r_wind_speed;
}
void LpdbMeteoTimedData::setWindSpeed(boost::optional<unsigned int> speed)
{
   r_wind_speed = speed;
}

const boost::optional<unsigned int> & LpdbMeteoTimedData::getWindDirection() const
{
   return r_wind_direction;
}
void LpdbMeteoTimedData::setWindDirection(boost::optional<unsigned int> direction)
{
   r_wind_direction = direction;
}


const boost::optional<bool> & LpdbMeteoTimedData::getDeicingRequired() const
{
   return r_deicing_required;
}
void LpdbMeteoTimedData::setDeicingRequired(
      boost::optional<bool> deicingRequired)
{
   r_deicing_required = deicingRequired;
}


// Per RWY data

map<string, LpiRunwayMeteoInfo> LpdbMeteoTimedData::getRwyMeteoInfo() const
{
   return r_rwy_meteo_info;
}

void LpdbMeteoTimedData::setRwyMeteoInfo
(const map<string, LpiRunwayMeteoInfo> &rwyMeteoInfo)
{
   r_rwy_meteo_info = rwyMeteoInfo;
}


std::ostream& operator<<(std::ostream &os, const LpdbMeteoTimedData &info)
{
   std::stringstream out_stream;

   out_stream << '[';
   if(info.getHasNowcastReport() == true)
   {
      out_stream << "NOWCAST REPORT";
   }
   else
   {
      out_stream << "FORECAST REPORT";
   }

   if (info.getHorizontalVisibility().is_initialized())
   {
     out_stream << " | HOR_VIS : " << info.getHorizontalVisibility().get();
   }
   else
   {
      out_stream << " | HOR_VIS : NULL";
   }

   if (info.getWetness().is_initialized())
   {
     out_stream << " | WET : " << info.getWetness().get();
   }
   else
   {
      out_stream << " | WET : NULL";
   }

   if (info.getIlsCategory().is_initialized())
   {
     out_stream << " | ILS : " << info.getIlsCategory().get();
   }
   else
   {
      out_stream << " | ILS : NULL";
   }

   if (info.getLvpActivation().is_initialized())
   {
     out_stream << " | LVP : " << info.getLvpActivation().get();
   }
   else
   {
      out_stream << " | LVP : ---";
   }

   if (info.getDeicingRequired().is_initialized())
   {
     out_stream << " | DEICING : " << info.getDeicingRequired().get();
   }
   else
   {
      out_stream << " | DEICING : ---";
   }

   typedef map<string, LpiRunwayMeteoInfo>::value_type runway_meteo_info;
   BOOST_FOREACH(const runway_meteo_info & element, info.getRwyMeteoInfo())
   {
      out_stream << ' ' << element.second;
   }

   out_stream << ']';

   return os << out_stream.str();
}
