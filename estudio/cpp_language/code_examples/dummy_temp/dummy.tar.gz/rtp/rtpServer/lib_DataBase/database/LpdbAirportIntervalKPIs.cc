/*
 * LpdbAirportIntervalKPIs.cc
 *
 *  Created on: 21/10/2014
 *  Author:
 */

#include <algorithm>
#include <boost/foreach.hpp>

#include <LcuDataTypeUtils.h>

//#include "LpdbDataBase.h"
#include "LpdbAirportIntervalKPIs.h"
#include "LpdbAlertsGenerator.h"


LpdbAirportIntervalKPIs::LpdbAirportIntervalKPIs()
: r_max_forecasted_delay(),
  r_average_forecasted_delay_delayedfps(),
  r_punctual_flights(),
  r_punctuality_percentage(100.0, 100.0, 100.0),
  r_accumulated_rwys_demand_forecast(),
  r_max_forecasted_delayWA(),
  r_average_forecasted_delay_delayedfpsWA(),
  r_punctuality_percentageWA()
{
}


LpdbAirportIntervalKPIs::LpdbAirportIntervalKPIs(const LpdbAirportIntervalKPIs & source)
: r_max_forecasted_delay(source.r_max_forecasted_delay),
  r_average_forecasted_delay_delayedfps(source.r_average_forecasted_delay_delayedfps),
  r_punctual_flights(source.r_punctual_flights),
  r_punctuality_percentage(source.r_punctuality_percentage),
  r_accumulated_rwys_demand_forecast(source.r_accumulated_rwys_demand_forecast),
  r_max_forecasted_delayWA(source.r_max_forecasted_delayWA),
  r_average_forecasted_delay_delayedfpsWA(source.r_average_forecasted_delay_delayedfpsWA),
  r_punctuality_percentageWA(source.r_punctuality_percentageWA)
{
}


LpdbAirportIntervalKPIs & LpdbAirportIntervalKPIs::operator= (const LpdbAirportIntervalKPIs & source)
{
   if (this != &source)
   {
      r_max_forecasted_delay = source.r_max_forecasted_delay;
      r_average_forecasted_delay_delayedfps = source.r_average_forecasted_delay_delayedfps;
      r_punctual_flights = source.r_punctual_flights;
      r_punctuality_percentage = source.r_punctuality_percentage;
      r_accumulated_rwys_demand_forecast = source.r_accumulated_rwys_demand_forecast;

      r_max_forecasted_delayWA = source.r_max_forecasted_delayWA;
      r_average_forecasted_delay_delayedfpsWA = source.r_average_forecasted_delay_delayedfpsWA;
      r_punctuality_percentageWA = source.r_punctuality_percentageWA;
   }

   return *this;
}


void LpdbAirportIntervalKPIs::reset()
{
   LpiADOVector<double> default_kpi(0.0, 0.0, 0.0);
   LpiADOVector<double> default_pctg(100.0, 100.0, 100.0);

   r_max_forecasted_delay = default_kpi;
   r_average_forecasted_delay_delayedfps = default_kpi;
   r_punctual_flights = default_kpi;
   r_punctuality_percentage = default_pctg;
   r_accumulated_rwys_demand_forecast = default_kpi;
}

/*
void LpdbAirportIntervalKPIs::calculateAverageForecastedDelayDelayedFPs(string interval,
                                                                       const LpiADOVector<vector<string> > & acceptedFPs,
                                                                       const LpiADOVector<vector<string> > & delayedFPs,
                                                                       map<string, LpdbFPSchedule> & scheduled_fps,
                                                                       map<string, LpdbFPSchedule> & delayed_fps_last_interval,
                                                                       int delayCountThreshold)
{
   LpdbDemand & demand = LpdbDataBase::Get().getDemand();

   if (demand.has_data(interval))
   {
      LpiADOVector<vector<string> > interval_demand = demand[interval].getDemandForecastFps();

      LpiADOVector<double> demand_forecast(0.0, 0.0, 0.0);
      LpiADOVector<double> total_forecasted_delay(0.0, 0.0, 0.0);
      LpiADOVector<double> number_of_delayed_flights(0.0, 0.0, 0.0);

      for (int i = E_ARR; i <= E_OVA; i++)
      {
         //Phase 3: added accepted_fps treatment
         //Calculations for accepted
         vector<string> accepted_by_type = acceptedFPs[i];
         vector<string> demand_forecast_by_type  = interval_demand[i];

         BOOST_FOREACH(string accepted_callsign, accepted_by_type)
         {
            vector<string>::iterator it = std::find(demand_forecast_by_type.begin(),
                                                    demand_forecast_by_type.end(),
                                                    accepted_callsign);

            if ((it != demand_forecast_by_type.end()) && (scheduled_fps.count(accepted_callsign) > 0))
            {
               boost::optional<double> forecasted_delay;

               LpdbFPSchedule fp_in_process = scheduled_fps[accepted_callsign];
               LpiOperationType::LpiEnum fp_type = fp_in_process.getOperationType();

               switch (fp_type)
               {
                  case LpiOperationType::E_ARRIVAL:
                     forecasted_delay  = fp_in_process.getLdForecastedDelay();
                  break;

                  case LpiOperationType::E_DEPARTURE:
                     forecasted_delay = fp_in_process.getToForecastedDelay();
                  break;

                  case LpiOperationType::E_NONE:
                  break;
               }

               if ((forecasted_delay) && (*forecasted_delay > delayCountThreshold))
               {
                  total_forecasted_delay[i] += *forecasted_delay;

                  number_of_delayed_flights[i]++;
               }

            }
         }  //foreach

         //Calculations for delayed
         vector<string> delayed_by_type = delayedFPs[i];
         vector<string> real_demand_by_type  = interval_demand[i];

         BOOST_FOREACH(string delayed_callsign, delayed_by_type)
         {
            vector<string>::iterator it = std::find(real_demand_by_type.begin(),
                                                    real_demand_by_type.end(),
                                                    delayed_callsign);

            if (it != real_demand_by_type.end())
            {
               if ((scheduled_fps.count(delayed_callsign) > 0) ||
                   (delayed_fps_last_interval.count(delayed_callsign) > 0))
               {
                  demand_forecast[i] = demand_forecast[i] + 1;

                  boost::optional<double> forecasted_delay;

                  //Get from scheduled FPs or from delayed in last interval
                  LpdbFPSchedule fp_in_process;
                  bool exists_fp_to_process = false;

                  if (scheduled_fps.count(delayed_callsign) > 0)
                  {
                     fp_in_process = scheduled_fps[delayed_callsign];
                     exists_fp_to_process = true;
                  }
                  else if (delayed_fps_last_interval.count(delayed_callsign) > 0)
                  {
                     fp_in_process = delayed_fps_last_interval[delayed_callsign];
                     exists_fp_to_process = true;
                  }

                  if (exists_fp_to_process)
                  {
                     LpiOperationType::LpiEnum fp_type = fp_in_process.getOperationType();

                     switch (fp_type)
                     {
                        case LpiOperationType::E_ARRIVAL:
                           forecasted_delay  = fp_in_process.getLdForecastedDelay();
                        break;

                        case LpiOperationType::E_DEPARTURE:
                           forecasted_delay = fp_in_process.getToForecastedDelay();
                        break;

                        case LpiOperationType::E_NONE:
                        break;
                     }

                     //Phase 3
                     if ((forecasted_delay) && (*forecasted_delay > delayCountThreshold))
                     {
                        total_forecasted_delay[i] += *forecasted_delay;
                        number_of_delayed_flights[i]++;
                     }
                  }
               }
            }
         }

         //Phase 3
         //Calculate average for ARR/DEP component
         //
         r_average_forecasted_delay_delayedfps[i] = (demand_forecast[i] != 0.0) ?
                                                    (total_forecasted_delay[i] / demand_forecast[i]) :
                                                    0.0;
         //
         r_average_forecasted_delay_delayedfps[i] = (number_of_delayed_flights[i] != 0.0) ?
                                                    (total_forecasted_delay[i] / number_of_delayed_flights[i]) :
                                                    0.0;
      }

   }
}*/



void LpdbAirportIntervalKPIs::calculateAccumulatedValues(const LpdbRunwayIntervalKPIs & runwayIntervalKPIs)
{
   LpiADOVector<double> max_forecasted_delay_rwy = runwayIntervalKPIs.getMaxForecastedDelay();

   r_max_forecasted_delay = max(r_max_forecasted_delay, max_forecasted_delay_rwy);
   //Overall component
   r_max_forecasted_delay[E_OVA] = std::max(r_max_forecasted_delay[E_ARR], r_max_forecasted_delay[E_DEP]);

   LpiADOVector<double> punctual_flights_rwy = runwayIntervalKPIs.getPunctualFlights();
   r_punctual_flights = r_punctual_flights + punctual_flights_rwy;

   LpiADOVector<double> punctuality_percentage_rwy = runwayIntervalKPIs.getPunctualityPercentage();
   r_punctuality_percentage = r_punctuality_percentage + punctuality_percentage_rwy;

   LpiADOVector<double> rwy_demand_forecast = runwayIntervalKPIs.getRunwayDemandForecast();
   r_accumulated_rwys_demand_forecast = r_accumulated_rwys_demand_forecast + rwy_demand_forecast;
}


void LpdbAirportIntervalKPIs::calculateAverages()
{
   //Note: check for 0 divisor in LpiADOVector operator/
   r_punctuality_percentage = (r_punctual_flights / r_accumulated_rwys_demand_forecast) * 100;

   for (unsigned int i = E_ARR; i <= E_OVA; ++i)
   {
      r_punctuality_percentage[i] = LcuDataTypeUtils::double_equals(r_accumulated_rwys_demand_forecast[i],0.0) ? 100.0 : r_punctuality_percentage[i];
   }
}

/*
void LpdbAirportIntervalKPIs::generateAlerts(string interval, const LpiConfigurationAlertKPIs & thresholds)
{
   int intervals = LpdbDataBase::Get().getGlobalParameters().getNumberOfIntervalsInHour();
   intervals = (intervals > 0) ? intervals : 1;

   r_max_forecasted_delayWA = LpdbAlertsGenerator::generateAlerts(1,
                                                  thresholds.getMaxForecastedDelay().getWarningThreshold(),
                                                  thresholds.getMaxForecastedDelay().getAlarmThreshold(),
                                                  thresholds.getMaxForecastedDelay().getComparison(),
                                                  r_max_forecasted_delay);
   r_average_forecasted_delay_delayedfpsWA = LpdbAlertsGenerator::generateAlerts(1,
                                                  thresholds.getAverageForecastedDelayDelayedFps().getWarningThreshold(),
                                                  thresholds.getAverageForecastedDelayDelayedFps().getAlarmThreshold(),
                                                  thresholds.getAverageForecastedDelayDelayedFps().getComparison(),
                                                  r_average_forecasted_delay_delayedfps);
   r_punctuality_percentageWA = LpdbAlertsGenerator::generateAlerts(
                                                  interval,
                                                  1,
                                                  thresholds.getPunctuality().getWarningThreshold(),
                                                  thresholds.getPunctuality().getAlarmThreshold(),
                                                  thresholds.getPunctuality().getComparison(),
                                                  r_punctuality_percentage);

}
*/

/*
void LpdbAirportIntervalKPIs::convertToInterface (const LpdbAirportIntervalKPIs & kpis, LpiAirportIntervalKPIs & out)
{
   out.setTotalRunwaysDemandForecast(LpiADO::convert2Interface(kpis.getAccumulatedRunwaysDemandForecast()));
   out.setAverageForecastedDelay_DelayedFPs(LpiADO::convert2Interface(kpis.getAverageForecastedDelay_DelayedFps()));
   out.setMaxForecastedDelay(LpiADO::convert2Interface(kpis.getMaxForecastedDelay()));
   out.setPunctuality(LpiADO::convert2Interface(kpis.getPunctualFlights()));
   out.setPercentagePunctuality(LpiADO::convert2Interface(kpis.getPunctualityPercentage()));

   out.setAverageForecastedDelay_DelayedFPsWA(kpis.getAverageForecastedDelay_DelayedFpsWA());
   out.setMaxForecastedDelayWA(kpis.getMaxForecastedDelayWA());
   out.setPercentagePunctualityWA(kpis.getPunctualityPercentageWA());
}


std::ostream & operator<<(std::ostream & os, const LpdbAirportIntervalKPIs & airportIntervalKPIs)
{
   os << "[AIRPT DELAY KPIs:\n"
      << "MAX_FCST_DLY: "  << airportIntervalKPIs.getMaxForecastedDelay()
                           << " | " << airportIntervalKPIs.getMaxForecastedDelayWA()
      << " AVG_FCST_DLY_DLYD: " << airportIntervalKPIs.getAverageForecastedDelay_DelayedFps()
      << " PUNCT_FPs: " << airportIntervalKPIs.getPunctualFlights()
                           << " | " << airportIntervalKPIs.getAverageForecastedDelay_DelayedFpsWA()
      << " %PUNCT: " << airportIntervalKPIs.getPunctualityPercentage()
                           << " | " << airportIntervalKPIs.getPunctualityPercentageWA()
      << ']';

   return os;
}*/




