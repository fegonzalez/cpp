/**@file LpdbAirportTotalmovKpiTimedData.h
 * 
 * KPI associated to the total FP movements (overall value), for each
 * interval, for a concrete airport.
 *
 */

#ifndef LPDBAIRPORTTOTALMOVKPITIMEDDATA_H_
#define LPDBAIRPORTTOTALMOVKPITIMEDDATA_H_

#include <LplcTypeConstants.h>
#include <iosfwd>


class LpdbAirportTotalmovKpiTimedData
{

public:

  LpdbAirportTotalmovKpiTimedData() = default;
  LpdbAirportTotalmovKpiTimedData(const LpdbAirportTotalmovKpiTimedData & source) = default;
  LpdbAirportTotalmovKpiTimedData & operator= (const LpdbAirportTotalmovKpiTimedData & source) = default;
  virtual ~LpdbAirportTotalmovKpiTimedData() {};
  
  double get() const { return the_kpi; }

  void set(const double &new_val) { the_kpi = new_val; }

  void init() { the_kpi = rtp_constants::DEFAULT_TOTALMOVS_KPI_VALUE; }

  
 protected:

  double the_kpi = rtp_constants::DEFAULT_TOTALMOVS_KPI_VALUE;
};

std::ostream& operator<<(std::ostream &os, const LpdbAirportTotalmovKpiTimedData &);


#endif /* LPDBAIRPORTTOTALMOVKPITIMEDDATA_H_ */
