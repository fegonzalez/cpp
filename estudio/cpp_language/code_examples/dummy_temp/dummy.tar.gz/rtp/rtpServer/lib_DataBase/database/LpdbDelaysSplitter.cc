/*
 * LpdbDelaysSplitter.cc
 *
 *  Created on: 23/06/2014
 *      Author: mbegega
 */

#include <limits>
#include <sstream>
#include "LpdbDelaysSplitter.h"
#include <LcuDataTypeUtils.h>

LpdbDelaysSplitter::LpdbDelaysSplitter()
        : r_available_options(),
          r_best_delay_option(boost::none),
          r_best_option_non_accepted(boost::none),
          r_best_option_accepted(boost::none),
          r_best_option_delayed(boost::none),
          r_best_option_delayed_arrival(boost::none)
{
}

LpdbDelaysSplitter::LpdbDelaysSplitter(LpiADOVector<int> surplus, LpiADOVector<int> margin)
        : r_available_options(),
          r_surplus(surplus),
          r_estimated_DC_margin(margin),
          r_best_delay_option(boost::none),
          r_best_option_non_accepted(boost::none),
          r_best_option_accepted(boost::none),
          r_best_option_delayed(boost::none),
          r_best_option_delayed_arrival(boost::none)
{
}

LpdbDelaysSplitter::LpdbDelaysSplitter(const LpdbDelaysSplitter & source)
        : r_available_options(source.r_available_options),
          r_surplus(source.r_surplus),
          r_estimated_DC_margin(source.r_estimated_DC_margin),
          r_best_delay_option(source.r_best_delay_option),
          r_best_option_non_accepted(source.r_best_option_non_accepted),
          r_best_option_accepted(source.r_best_option_accepted),
          r_best_option_delayed(source.r_best_option_delayed),
          r_best_option_delayed_arrival(source.r_best_option_delayed_arrival)
{
}

LpdbDelaysSplitter & LpdbDelaysSplitter::operator=(const LpdbDelaysSplitter & source)
{
    if (this != &source)
    {
        r_available_options = source.r_available_options;
        r_surplus = source.r_surplus;
        r_estimated_DC_margin = source.r_estimated_DC_margin;
        r_best_delay_option = source.r_best_delay_option;
        r_best_option_non_accepted = source.r_best_option_non_accepted;
        r_best_option_accepted = source.r_best_option_accepted;
        r_best_option_delayed = source.r_best_option_delayed;
        r_best_option_delayed_arrival = source.r_best_option_delayed_arrival;
    }

    return *this;
}

void LpdbDelaysSplitter::calculateDelayOptions()
{

    LpiADOVector<int> surplus = r_surplus;

    r_available_options.clear();

    int SOd = std::max(surplus[E_OVA] - surplus[E_ARR] - surplus[E_DEP], 0);

    if (SOd > 0)
    {
        //Option 1: Delay Arrivals only

        LpiADOVector<int> delayed_arrivals(surplus[E_ARR] + SOd, surplus[E_DEP],
                                            surplus[E_ARR] + SOd + surplus[E_DEP]);

        LpdbDelayOption optionA;
        optionA.setDelayedFPs(delayed_arrivals);

        r_available_options[LpdbDelayOptions::E_OPTION_A] = optionA;

        //Option 2: Delay Departures only

        LpiADOVector<int> delayed_departures(surplus[E_ARR], surplus[E_DEP] + SOd,
                                              surplus[E_ARR] + surplus[E_DEP] + SOd);

        LpdbDelayOption optionB;
        optionB.setDelayedFPs(delayed_departures);

        r_available_options[LpdbDelayOptions::E_OPTION_B] = optionB;

        //Option 3: SOd even, departures and arrivals delays distributed equally

        if (SOd % 2 == 0)
        {
            LpiADOVector<int> delayed_flights(surplus[E_ARR] + SOd / 2, surplus[E_DEP] + SOd / 2,
                                               surplus[E_ARR] + SOd + surplus[E_DEP]);

            LpdbDelayOption optionC;
            optionC.setDelayedFPs(delayed_flights);

            r_available_options[LpdbDelayOptions::E_OPTION_C] = optionC;
        }

        //Option 4:

        if ((SOd % 2 != 0) && (SOd != 1))
        {
            int lower_value = static_cast<int>(std::floor(SOd / 2.0));
            int upper_value = static_cast<int>(std::ceil(SOd / 2.0));

            LpiADOVector<int> delayed_flights(surplus[E_ARR] + upper_value, surplus[E_DEP] + lower_value,
                                               surplus[E_ARR] + SOd + surplus[E_DEP]);

            LpdbDelayOption optionD;
            optionD.setDelayedFPs(delayed_flights);

            r_available_options[LpdbDelayOptions::E_OPTION_D] = optionD;
        }

        //Option 5:

        if ((SOd % 2 != 0) && (SOd != 1))
        {
            int lower_value = static_cast<int>(std::floor(SOd / 2.0));
            int upper_value = static_cast<int>(std::ceil(SOd / 2.0));

            LpiADOVector<int> delayed_flights(surplus[E_ARR] + lower_value, surplus[E_DEP] + upper_value,
                                               surplus[E_ARR] + SOd + surplus[E_DEP]);

            LpdbDelayOption optionE;
            optionE.setDelayedFPs(delayed_flights);

            r_available_options[LpdbDelayOptions::E_OPTION_E] = optionE;
        }
    }
}

void LpdbDelaysSplitter::calculateAcceptedDelayed()
{
    LpiADOVector<int> estimated_DC_margin_next_ti = r_estimated_DC_margin;

    typedef map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption>::value_type delay_option;

    if (r_available_options.size() > 0)
    {
        BOOST_FOREACH(delay_option & option, r_available_options)
        {
            LpiADOVector<int> delayed = option.second.getDelayedFPs();

            LpiADOVector<int> accepted_delayed;

            for (int i = E_ARR; i <= E_OVA; i++)
            {
                if (estimated_DC_margin_next_ti[i] < 0)
                {
                    accepted_delayed[i] = std::min(delayed[i], std::abs(estimated_DC_margin_next_ti[i]));
                }
            }

            option.second.setAcceptedDelayedFPs(accepted_delayed);
            r_available_options[option.first] = option.second;
        }
    }
}

void LpdbDelaysSplitter::calculateNonAcceptedDelayed()
{
    LpiADOVector<int> estimated_DC_margin_next_ti = r_estimated_DC_margin;

    typedef map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption>::value_type delay_option;

    if (r_available_options.size() > 0)
    {
        BOOST_FOREACH(delay_option & option, r_available_options)
        {
            LpiADOVector<int> delayed = option.second.getDelayedFPs();
            LpiADOVector<int> accepted = option.second.getAcceptedDelayedFPs();

            LpiADOVector<int> non_accepted_delayed;

            for (int i = E_ARR; i <= E_OVA; i++)
            {
                if (estimated_DC_margin_next_ti[i] > 0)
                {
                    non_accepted_delayed[i] = delayed[i];
                }
                else
                {
                    non_accepted_delayed[i] = delayed[i] - accepted[i];
                }
            }

            option.second.setNonAcceptedDelayedFPs(non_accepted_delayed);
            r_available_options[option.first] = option.second;
        }
    }
}

void LpdbDelaysSplitter::selectBestOption(double ratioARR, double ratioDEP)
{
    r_best_delay_option = boost::none;
    r_best_option_non_accepted = boost::none;
    r_best_option_accepted = boost::none;

    typedef map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption>::value_type delay_option;

    if (r_available_options.size() > 0)
    {
        double best_similar = std::numeric_limits<double>::max();

        BOOST_FOREACH(delay_option & option, r_available_options)
        {
            LpiADOVector<int> accepted = option.second.getAcceptedDelayedFPs();
            LpiADOVector<int> non_accepted = option.second.getNonAcceptedDelayedFPs();
            LpiADOVector<int> delayed = option.second.getDelayedFPs();

            double sum = accepted[E_ARR] + accepted[E_DEP];

	    double calculatedRatioARR = (not LcuDataTypeUtils::double_equals(sum,0)) ?
                            (static_cast<double>(delayed[E_ARR]) / sum) :
                            0.0;

            option.second.setRatioARR(calculatedRatioARR);
            option.second.setWeightARR(ratioARR);

	    double calculatedRatioDEP = (not LcuDataTypeUtils::double_equals(sum,0)) ?
                            (static_cast<double>(accepted[E_DEP]) / sum) :
                            0.0;

            option.second.setRatioDEP(calculatedRatioDEP);
            option.second.setWeightDEP(ratioDEP);

            double similar = distance(ratioARR, ratioDEP, calculatedRatioARR, calculatedRatioDEP);

            option.second.setDistance(similar);

            if (similar < best_similar)
            {
                best_similar = similar;

                r_best_delay_option = option.first;
                r_best_option_non_accepted = non_accepted;
                r_best_option_accepted = accepted;
            }
            else if (LcuDataTypeUtils::double_equals(similar, best_similar))
            {
                if ((r_best_option_accepted) && (accepted[E_OVA] > (*r_best_option_accepted)[E_OVA]))
                {
                    best_similar = similar;

                    r_best_delay_option = option.first;
                    r_best_option_non_accepted = non_accepted;
                    r_best_option_accepted = accepted;
                }
            }
        }
    }
}

void LpdbDelaysSplitter::selectBestOptionLastInterval(double ratioARR, double ratioDEP)
{
    r_best_delay_option = boost::none;

    typedef map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption>::value_type delay_option;

    if (r_available_options.size() > 0)
    {
        double best_similar = std::numeric_limits<double>::max();

        BOOST_FOREACH(delay_option & option, r_available_options)
        {
            LpiADOVector<int> delayed = option.second.getDelayedFPs();

            double sum = static_cast<double>(delayed[E_ARR] + delayed[E_DEP]);

            double calculatedRatioARR =
                    !(LcuDataTypeUtils::double_equals(sum, 0)) ? (static_cast<double>(delayed[E_ARR]) / sum) : 0.0;

            option.second.setRatioARR(ratioARR);
            option.second.setWeightARR(calculatedRatioARR);

            double calculatedRatioDEP =
                    !(LcuDataTypeUtils::double_equals(sum, 0)) ? (static_cast<double>(delayed[E_DEP]) / sum) : 0.0;

            option.second.setRatioDEP(ratioDEP);
            option.second.setWeightARR(calculatedRatioDEP);

            double similar = distance(ratioARR, ratioDEP, calculatedRatioARR, calculatedRatioDEP);

            option.second.setDistance(similar);

            if (similar < best_similar)
            {
                best_similar = similar;
                r_best_delay_option = option.first;
            }
            else if (LcuDataTypeUtils::double_equals(similar, best_similar))
            {
                if ((r_best_option_accepted) && (delayed[E_OVA] < (*r_best_option_accepted)[E_OVA]))
                {
                    best_similar = similar;
                    r_best_delay_option = option.first;
                }
            }
        }
    }
}

LpiADOVector<int> LpdbDelaysSplitter::getRealDelayedBestOption()
{
    if (r_best_delay_option)
    {
        return r_available_options[*r_best_delay_option].getDelayedFPs();
    }

    return LpiADOVector<int>(0, 0, 0);
}

void LpdbDelaysSplitter::printOptions()
{
    if (r_available_options.size() > 0)
    {
        LclogStream::instance(LclogConfig::E_RTP).info() << "Number of options: " << r_available_options.size()
                                                         << std::endl;

        typedef map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption>::value_type delay_option;

        BOOST_FOREACH(delay_option & option, r_available_options)
        {
            LclogStream::instance(LclogConfig::E_RTP).info() << "Option : "
                                                             << LpdbDelayOptions::getEnumAsString(option.first)
                                                             << std::endl;
            LclogStream::instance(LclogConfig::E_RTP).info() << option.second << std::endl;
        }

        LclogStream::instance(LclogConfig::E_RTP).info() << "Optimization result: " << std::endl;

        if (r_best_delay_option)
        {
            LclogStream::instance(LclogConfig::E_RTP).info() << "Best option found: "
                                                             << LpdbDelayOptions::getEnumAsString(*r_best_delay_option)
                                                             << std::endl;
            LclogStream::instance(LclogConfig::E_RTP).info() << "Delayed of best option: " << getRealDelayedBestOption()
                                                             << std::endl;
        }
        else
        {
            LclogStream::instance(LclogConfig::E_RTP).info() << "Best option not found" << std::endl;
        }

        if (r_best_option_non_accepted)
        {
            LclogStream::instance(LclogConfig::E_RTP).info() << "Best option non accepted found: "
                                                             << *r_best_option_non_accepted << std::endl;
        }
        else
        {
            LclogStream::instance(LclogConfig::E_RTP).info() << "Best option non accepted not found" << std::endl;
        }
    }
}

string LpdbDelaysSplitter::getOptionsAsString()
{
    std::stringstream options_stream;

    if (r_available_options.size() > 0)
    {
        options_stream << "[OPTIONS: " << r_available_options.size() << '\n';

        typedef map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption>::value_type delay_option;

        BOOST_FOREACH(delay_option & option, r_available_options)
        {
            options_stream << "OPTION : " << LpdbDelayOptions::getEnumAsString(option.first) << '\n';
            options_stream << option.second << '\n';
        }

        if (r_best_delay_option)
        {
            options_stream << "BEST: " << LpdbDelayOptions::getEnumAsString(*r_best_delay_option) << '\n';
            options_stream << "DLYD: " << getRealDelayedBestOption() << '\n';
        }

        options_stream << ']';
    }

    return options_stream.str();
}

double LpdbDelaysSplitter::distance(double ratioARR, double ratioDEP, double weightARR, double weightDEP)
{
    return std::sqrt(std::fabs(std::pow(weightARR - ratioARR, 2.0)) + std::fabs(std::pow(weightDEP - ratioDEP, 2.0)));
}
