/*
 * LpdbRunwayIntervalKPIs.cc
 *
 *  Created on: 20/10/2014
 *  Author:
 */

#include <algorithm>
#include <boost/foreach.hpp>

#include <LpiADO.h>
//#include "LpdbDataBase.h"
#include "LpdbRunwayIntervalKPIs.h"
#include "LpdbAlertsGenerator.h"


LpdbRunwayIntervalKPIs::LpdbRunwayIntervalKPIs()
: r_max_forecasted_delay(),
  r_average_forecasted_delay(),
  r_average_forecasted_delay_delayedfps(),
  r_punctual_flights(),
  r_punctuality_percentage(100.0, 100.0, 100.0),
  r_total_forecasted_delay(),
  r_total_punctuality_delay(),
  r_not_punctual_flights(),
  r_demand_forecast(),
  r_accepted_fps_own_interval(),
  r_number_of_delayed_flights()
//  .
//  r_max_forecasted_delayWA(),
//  r_average_forecasted_delay_delayedfpsWA(),
//  r_punctuality_percentageWA()
{
}


LpdbRunwayIntervalKPIs::LpdbRunwayIntervalKPIs(const LpdbRunwayIntervalKPIs & source)
: r_max_forecasted_delay(source.r_max_forecasted_delay),
  r_average_forecasted_delay(source.r_average_forecasted_delay),
  r_average_forecasted_delay_delayedfps(source.r_average_forecasted_delay_delayedfps),
  r_punctual_flights(source.r_punctual_flights),
  r_punctuality_percentage(source.r_punctuality_percentage),
  r_total_forecasted_delay(source.r_total_forecasted_delay),
  r_total_punctuality_delay(source.r_total_punctuality_delay),
  r_not_punctual_flights(source.r_not_punctual_flights),
  r_demand_forecast(source.r_demand_forecast),
  r_accepted_fps_own_interval(source.r_accepted_fps_own_interval),
  r_number_of_delayed_flights(source.r_number_of_delayed_flights)/*,
  r_max_forecasted_delayWA(source.r_max_forecasted_delayWA),
  r_average_forecasted_delay_delayedfpsWA(source.r_average_forecasted_delay_delayedfpsWA),
  r_punctuality_percentageWA(source.r_punctuality_percentageWA)*/
{
}


LpdbRunwayIntervalKPIs & LpdbRunwayIntervalKPIs::operator= (const LpdbRunwayIntervalKPIs & source)
{
   if (this != &source)
   {
      r_max_forecasted_delay = source.r_max_forecasted_delay;
      r_average_forecasted_delay = source.r_average_forecasted_delay;
      r_average_forecasted_delay_delayedfps = source.r_average_forecasted_delay_delayedfps;
      r_punctual_flights = source.r_punctual_flights;
      r_punctuality_percentage = source.r_punctuality_percentage;
      r_total_forecasted_delay = source.r_total_forecasted_delay;
      r_total_punctuality_delay = source.r_total_punctuality_delay;
      r_not_punctual_flights = source.r_not_punctual_flights;
      r_demand_forecast = source.r_demand_forecast;
      r_accepted_fps_own_interval = source.r_accepted_fps_own_interval;
      r_number_of_delayed_flights = source.r_number_of_delayed_flights;
     /* r_max_forecasted_delayWA = source.r_max_forecasted_delayWA;
      r_average_forecasted_delay_delayedfpsWA = source.r_average_forecasted_delay_delayedfpsWA;
      r_punctuality_percentageWA = source.r_punctuality_percentageWA;*/
   }

   return *this;
}


void LpdbRunwayIntervalKPIs::reset()
{
   LpiADOVector<double> default_kpi(0.0, 0.0, 0.0);
   LpiADOVector<double> default_pctg(100.0, 100.0, 100.0);

   r_max_forecasted_delay = default_kpi;
   r_average_forecasted_delay = default_kpi;
   r_average_forecasted_delay_delayedfps = default_kpi;
   r_punctual_flights = default_kpi;
   r_punctuality_percentage = default_pctg;
   r_total_forecasted_delay = default_kpi;
   r_total_punctuality_delay = default_kpi;
   r_not_punctual_flights = default_kpi;
   r_demand_forecast = default_kpi;
   r_accepted_fps_own_interval = default_kpi;
   r_number_of_delayed_flights = default_kpi;
}

/*
void LpdbRunwayIntervalKPIs::generateAbsoluteKPIs(string interval,
                                                 const LpiADOVector<vector<string> > & real_delayed,
                                                 const LpiADOVector<vector<string> > & accepted_fp_keys,
                                                 map<string, LpdbFPSchedule> & scheduled_fps,
                                                 map<string, LpdbFPSchedule> & delayed_fps_last_interval,
                                                 int delayCountThreshold)
{
   LpdbDemand & demand = LpdbDataBase::Get().getDemand();

   if (demand.has_data(interval))
   {
      LpiADOVector<vector<string> > interval_demand = demand[interval].getDemandForecastFps();

      //Extract accepted whose ITOT/ILDT is in interval
      for (int i = E_ARR; i <= E_OVA; i++)
      {
         vector<string> accepted_by_type = accepted_fp_keys[i];
         vector<string> demand_forecast_by_type  = interval_demand[i];

         BOOST_FOREACH(string accepted_key, accepted_by_type)
         {
            vector<string>::iterator it = std::find(demand_forecast_by_type.begin(),
                                                    demand_forecast_by_type.end(),
                                                    accepted_key);

            if ((it != demand_forecast_by_type.end()) && (scheduled_fps.count(accepted_key) > 0))
            {
               r_accepted_fps_own_interval[i]++;

               //Phase 3: added forecasted delay treatment (added all forecasted_delay stmts in accepted_key section)

               boost::optional<double> forecasted_delay = 0.0;
               boost::optional<double> punctuality_delay = 0.0;

               LpdbFPSchedule fp_in_process = scheduled_fps[accepted_key];
               LpiOperationType::LpiEnum fp_type = fp_in_process.getOperationType();

               switch (fp_type)
               {
                  case LpiOperationType::E_ARRIVAL:
                     forecasted_delay  = fp_in_process.getLdForecastedDelay();
                     punctuality_delay = fp_in_process.getLdPunctualityDelay();
                  break;

                  case LpiOperationType::E_DEPARTURE:
                     forecasted_delay = fp_in_process.getToForecastedDelay();
                     punctuality_delay = fp_in_process.getToPunctualityDelay();
                  break;

                  case LpiOperationType::E_NONE:
                  break;
               }

               //Phase 3: added right part && of if condition and r_number_of_delayed_flights increment
               if ((forecasted_delay) && (*forecasted_delay > delayCountThreshold))
               {
                  r_total_forecasted_delay[i] += *forecasted_delay;
                  r_max_forecasted_delay[i] = std::max(r_max_forecasted_delay[i], *forecasted_delay);

                  r_number_of_delayed_flights[i]++;
               }

               if ((punctuality_delay) && (*punctuality_delay > 15.0))
               {
                  r_total_punctuality_delay[i] += *punctuality_delay;
                  r_not_punctual_flights[i]++;
               }
            }
         }
      }


      for (int i = E_ARR; i <= E_OVA; i++)
      {
         vector<string> real_delayed_by_type = real_delayed[i];
         vector<string> real_demand_by_type  = interval_demand[i];

         BOOST_FOREACH(string delayed_key, real_delayed_by_type)
         {
            vector<string>::iterator it = std::find(real_demand_by_type.begin(),
                                                    real_demand_by_type.end(),
                                                    delayed_key);

            if (it != real_demand_by_type.end())
            {
               if ((scheduled_fps.count(delayed_key) > 0) ||
                   (delayed_fps_last_interval.count(delayed_key) > 0))
               {
                  r_demand_forecast[i] = r_demand_forecast[i] + 1;

                  boost::optional<double> forecasted_delay;
                  boost::optional<double> punctuality_delay;

                  //Get from scheduled FPs or from delayed in last interval
                  LpdbFPSchedule fp_in_process;
                  bool exists_fp_to_process = false;

                  if (scheduled_fps.count(delayed_key) > 0)
                  {
                     fp_in_process = scheduled_fps[delayed_key];
                     exists_fp_to_process = true;
                  }
                  else if (delayed_fps_last_interval.count(delayed_key) > 0)
                  {
                     fp_in_process = delayed_fps_last_interval[delayed_key];
                     exists_fp_to_process = true;
                  }

                  if (exists_fp_to_process)
                  {
                     LpiOperationType::LpiEnum fp_type = fp_in_process.getOperationType();

                     switch (fp_type)
                     {
                        case LpiOperationType::E_ARRIVAL:
                           forecasted_delay  = fp_in_process.getLdForecastedDelay();
                           punctuality_delay = fp_in_process.getLdPunctualityDelay();
                        break;

                        case LpiOperationType::E_DEPARTURE:
                           forecasted_delay = fp_in_process.getToForecastedDelay();
                           punctuality_delay = fp_in_process.getToPunctualityDelay();
                        break;

                        case LpiOperationType::E_NONE:
                        break;
                     }


                     //Phase 3: added right part && of if condition and r_number_of_delayed_flights increment
                     if ((forecasted_delay) && (*forecasted_delay > delayCountThreshold))
                     {
                        r_total_forecasted_delay[i] += *forecasted_delay;
                        r_max_forecasted_delay[i] = std::max(r_max_forecasted_delay[i], *forecasted_delay);

                        r_number_of_delayed_flights[i]++;
                     }


                     //Phase 3: added right part && of if condition
                     if ((punctuality_delay) && (*punctuality_delay > 15.0))
                     {
                        r_total_punctuality_delay[i] += *punctuality_delay;
                        r_not_punctual_flights[i]++;
                     }
                  }  // exists_fp_to_process
               }  // scheduled_fps.count || delayed_fps_last_interval.count
             } // it != real_demand.end()

         }  //foreach

         //Phase 3

         r_average_forecasted_delay_delayedfps[i] = (r_number_of_delayed_flights[i] > 0.0) ?
                                                    (r_total_forecasted_delay[i] / r_number_of_delayed_flights[i]) :
                                                     0.0;

         r_demand_forecast[i]  = r_demand_forecast[i] + r_accepted_fps_own_interval[i]; //accepted_fps[i];
         r_punctual_flights[i] = r_demand_forecast[i] - r_not_punctual_flights[i];

         r_punctuality_percentage[i] = (r_demand_forecast[i] > 0.0) ?
                                       ((r_punctual_flights[i] / r_demand_forecast[i]) * 100.0) :
                                       100.0;
      } // for (int i = E_ARR...

      //Overall components
      r_max_forecasted_delay[E_OVA] = std::max(r_max_forecasted_delay[E_ARR], r_max_forecasted_delay[E_DEP]);
   }
}
*/
/*
void LpdbRunwayIntervalKPIs::generateAlerts(string interval,
                                           OperationType::Enum runway_usage,
                                           const LpiConfigurationAlertKPIs & thresholds)
{
   int intervals = LpdbDataBase::Get().getGlobalParameters().getNumberOfIntervalsInHour();
   intervals = (intervals > 0) ? intervals : 1;

   r_max_forecasted_delayWA = LpdbAlertsGenerator::generateAlerts(1,
                                                  thresholds.getMaxForecastedDelay().getWarningThreshold(),
                                                  thresholds.getMaxForecastedDelay().getAlarmThreshold(),
                                                  thresholds.getMaxForecastedDelay().getComparison(),
                                                  r_max_forecasted_delay);
   r_average_forecasted_delay_delayedfpsWA = LpdbAlertsGenerator::generateAlerts(1,
                                                  thresholds.getAverageForecastedDelayDelayedFps().getWarningThreshold(),
                                                  thresholds.getAverageForecastedDelayDelayedFps().getAlarmThreshold(),
                                                  thresholds.getAverageForecastedDelayDelayedFps().getComparison(),
                                                  r_average_forecasted_delay_delayedfps);
   r_punctuality_percentageWA = LpdbAlertsGenerator::generateAlerts(
                                                  interval,
                                                  runway_usage,
                                                  r_demand_forecast,
                                                  1,
                                                  thresholds.getPunctuality().getWarningThreshold(),
                                                  thresholds.getPunctuality().getAlarmThreshold(),
                                                  thresholds.getPunctuality().getComparison(),
                                                  r_punctuality_percentage);
}
*/

/*void LpdbRunwayIntervalKPIs::convertToInterface (const OperationType::Enum & runway_usage,
                                                const LpdbRunwayIntervalKPIs & kpis,
                                                LpiRunwayIntervalKPIs & out)
{
   out.setRwyMaxForecastedDelay(LpiADO::convert2Interface(kpis.getMaxForecastedDelay()));
   out.setRwyAverageForecastedDelay(LpiADO::convert2Interface(kpis.getAverageForecastedDelay()));
   out.setRwyAverageDelay_DelayedFPs(LpiADO::convert2Interface(kpis.getAverageForecastedDelay_DelayedFps()));
   out.setRwyPunctualFlights(LpiADO::convert2Interface(kpis.getPunctualFlights()));
   out.setRwyDemandForecast(LpiADO::convert2Interface(kpis.getRunwayDemandForecast()));
   out.setRwyAcceptedFpsOwnInterval(LpiADO::convert2Interface(kpis.getRunwayAcceptedOwnInterval()));
   out.setRwyNotPunctualFlights(LpiADO::convert2Interface(kpis.getRwyNotPunctualFlights()));
   out.setRwyNumberOfDelayedFlights(LpiADO::convert2Interface(kpis.getNumberOfDelayedFlights()));

   out.setRwyPercentagePunctuality(
         LpiADO::tagNoUsageComponents(runway_usage,
                                      LpiADO::convert2Interface(kpis.getPunctualityPercentage())));

   out.setRwyAverageDelay_DelayedFPsWA(kpis.getAverageForecastedDelay_DelayedFpsWA());
   out.setRwyMaxForecastedDelayWA(kpis.getMaxForecastedDelayWA());
   out.setRwyPercentagePunctualityWA(kpis.getPunctualityPercentageWA());
}


std::ostream & operator<<(std::ostream & os, const LpdbRunwayIntervalKPIs & runwayIntervalKPIs)
{
   os << "[RWY DELAY KPIs:\n"
      << "MAX_FCST_DLY: "  << runwayIntervalKPIs.getMaxForecastedDelay()
                           << " | " << runwayIntervalKPIs.getMaxForecastedDelayWA()
      << " AVG_FCST_DLY: " << runwayIntervalKPIs.getAverageForecastedDelay()
      << " AVG_FCST_DLY_DLYD: " << runwayIntervalKPIs.getAverageForecastedDelay_DelayedFps()
                           << " | " << runwayIntervalKPIs.getAverageForecastedDelay_DelayedFpsWA()
      << " PUNCT_FPs: " << runwayIntervalKPIs.getPunctualFlights()
      << " %PUNCT: " << runwayIntervalKPIs.getPunctualityPercentage()
                           << " | " << runwayIntervalKPIs.getPunctualityPercentageWA()
      << ']';

   return os;
}*/




