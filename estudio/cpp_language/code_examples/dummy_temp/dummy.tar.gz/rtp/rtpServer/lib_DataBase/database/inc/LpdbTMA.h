/*
 * LpdbTMA.h
 *
 */

#ifndef LPDBTMA_H_
#define LPDBTMA_H_

#include <LplcTypeConstants.h>
#include <LpiADOVector.h>
#include <LpdbTMATimedData.h>
#include <LctimTimeLine.h>
#include <LpiTimeParameters.h>

#include <string>
#include <vector>
#include <map>
#include <iosfwd>


/**@class LpdbTMA
 *
 * @brief TMA timeline data associated to a concrete Airport.
 *
 */
class LpdbTMA
{
	friend std::ostream & operator<<(std::ostream & os, const LpdbTMA & data);

   public:
      LpdbTMA() = default;
      LpdbTMA(const LpdbTMA & source) = default;
      LpdbTMA & operator= (const LpdbTMA & source) = default;
      virtual ~LpdbTMA() {}


      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbTMATimedData & operator[] (const string & interval_name);

      //stablish timeline
      void init(const LpiTimeParameters & parameters,
                boost::posix_time::ptime begin_timestamp,
		        const LpiADOVector<unsigned int> &tmaNominalCapacity);

      //Forwards internal timeline in one interval
      void forward();

      //Getters and setters
      TimeLine<LpdbTMATimedData> & getTimeLine();
      string getIntervalsShortFormat () const;
      string getIntervalsAsString () const;

      void calculateCapacity();
      void calculateCapacity(string interval);

      LpiADOVector<unsigned int> getNominalTMA() const { return r_tmaNominal; }


   protected:

      ///@param r_timeLine: TMA per interval for the airport
      TimeLine<LpdbTMATimedData> r_timeLine;

      ///@param r_tmaNominal: nominal TMA of the airport
      ///@warning Set at init(), value from the adap file => never changed again
      LpiADOVector<unsigned int> r_tmaNominal =
	{rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT,
	 rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT,
	 rtp_constants::TWY_NOMINAL_CAPACITY_DEFAULT};

    ///@warning RMAN's used manual capacity reductions, RTP doesn't
    ///std::vector<LpiADOVector<double> > r_manual_capacity_reduction_scheduled;

      
};


#endif /* LPDBTMA_H_ */
