/*
 * LpdbWhatIfClosure.h
 *
 *  Created on: 14/05/2015
 *      Author: mbegega
 *
 *  Data model for what if inputs
 *  It refers to a generated alternative schedule stored LpdbAlternativeSchedule
 *  in database, via a foreign key
 */

#ifndef LPBWHATIFCLOSURE_H_
#define LPBWHATIFCLOSURE_H_

#include <string>

#include "LpiWhatIfClosure.h"

class LpdbWhatIfClosure
{
   public:

      LpdbWhatIfClosure();

      LpdbWhatIfClosure(const std::map <std::string, LpiRunwayClosure> & closures,
                       const LpiWhatIfClosure::LpiWhatIfClosureType & closureType,
                       int scheduleId);

      LpdbWhatIfClosure(const LpiWhatIfClosure & closureInterface);

      LpdbWhatIfClosure(const LpdbWhatIfClosure & source);

      //Only with one closure
      LpdbWhatIfClosure(const LpiRunwayClosure & runwayClosure);

      virtual ~LpdbWhatIfClosure();

      LpdbWhatIfClosure & operator= (const LpdbWhatIfClosure & source);

      const std::map <std::string, LpiRunwayClosure> & getAllRunwayClosures() const;
      const LpiWhatIfClosure::LpiWhatIfClosureType & getClosureType() const;
      int getAlternativeScheduleId() const;

      void setAlternativeScheduleId(int id);
      void setClosureType(const LpiWhatIfClosure::LpiWhatIfClosureType & closureType);

      void addRunwayClosure(const std::string & runwayId, const LpiRunwayClosure & closure);
      void deleteRunwayClosure(const std::string & runwayId);

      bool exists(const std::string & runwayId);
      LpiRunwayClosure & operator[] (const std::string & runwayId);

      int getNumberOfElements() const;
      const LpiRunwayClosure & getFirstClosure() const;

      bool isBestPointClosureType() const;

   protected:

      std::map <std::string, LpiRunwayClosure> r_runwayClosures;

      LpiWhatIfClosure::LpiWhatIfClosureType r_closureType;

      int r_alternativeScheduleId; //Alternative schedule to which is associated
};

std::ostream & operator<<(std::ostream & os, const LpdbWhatIfClosure & closure);


#endif /* LPBWHATIFCLOSURE_H_ */
