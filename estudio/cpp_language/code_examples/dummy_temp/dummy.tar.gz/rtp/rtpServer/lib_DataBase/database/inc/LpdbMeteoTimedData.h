/*
 * LpdbMeteoTimedData.h
 *
 *  Created on: 02/01/2014
 *      Author: mbegega
 */

#ifndef METEOTIMEDDATA_H_
#define METEOTIMEDDATA_H_

#include <string>
#include <vector>
#include <map>
#include <boost/shared_ptr.hpp>
#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "LpiADOVector.h"
#include <LpiRunwayMeteoInfo.h>


using std::vector;
using std::string;
using std::map;


/**@class LpdbMeteoTimedData
 *
 * @brief Stores ONE data with meteo info required for complexity/capacity calcualtions.
 */
class LpdbMeteoTimedData
{
public:

  virtual ~LpdbMeteoTimedData() {};
  LpdbMeteoTimedData() = default;
  LpdbMeteoTimedData(const LpdbMeteoTimedData & source) = default;
  LpdbMeteoTimedData & operator= (const LpdbMeteoTimedData & source) = default;


   //Getters and Setters
   std::string get_name ();

   ///@warning cross & tail were not actually been set (see LpdBusinessLogicFacade::fillIntervalData)
//   const boost::optional<double> & getCrosswind() const;
//   void setCrosswind(boost::optional<double> crosswind);
//
//   const boost::optional<double> & getTailwind() const;
//   void setTailwind(boost::optional<double> tailwind);

   const boost::optional<bool> & getDeicingRequired() const;
   void setDeicingRequired(boost::optional<bool> deicingRequired);

   const boost::optional<double> & getHorizontalVisibility() const;
   void setHorizontalVisibility(boost::optional<double> horizontalVisibility);

   const boost::optional<std::string> & getWetness() const;
   void setWetness(boost::optional<std::string> wetness);

   const boost::optional<std::string> & getIlsCategory() const;
   void setIlsCategory(boost::optional<std::string> ilsCategory);

   const boost::optional<bool> & getLvpActivation() const;
   void setLvpActivation(boost::optional<bool> lvpActivation);

   map<string, LpiRunwayMeteoInfo> getRwyMeteoInfo() const;
   
   void setRwyMeteoInfo(const map<string, LpiRunwayMeteoInfo> &rwyMeteoInfo);

   const boost::optional<unsigned int> & getWindSpeed() const;
   void setWindSpeed(boost::optional<unsigned int> speed);

   const boost::optional<unsigned int> & getWindDirection() const;
   void setWindDirection(boost::optional<unsigned int> direction);

   const bool getHasNowcastReport()const ;
   void setHasNowcastReport(bool hasNowcastReport);

protected:

   std::string r_name;
   bool r_hasNowcastReport = false;

   // Per airport data
   boost::optional<double>   r_horizontal_visibility;
   boost::optional<std::string> r_wetness;
   boost::optional<std::string> r_ilsCategory;
   boost::optional<bool>  r_lvp_activation;

   ///@warning: r_crosswind & r_tailwind are not been used in RTP.
   ///          Values stored int r_rwy_meteo_info, within each
   ///          LpiRunwayMeteoInfo element.
   //boost::optional<double> r_crosswind; // not used in RTP: stored within each
   //boost::optional<double> r_tailwind;  // not used in RTP: stored within each

   boost::optional<unsigned int>  r_wind_speed;     // RTP: not required by HMI
   boost::optional<unsigned int>  r_wind_direction; // RTP: not required by HMI

   boost::optional<bool>  r_deicing_required; ///@todo FIXME  RTP: 'PL' value

   // Per RWY data
   map<string, LpiRunwayMeteoInfo> r_rwy_meteo_info;
};

std::ostream& operator<<(std::ostream &os, const LpdbMeteoTimedData &info);

#endif /* METEOTIMEDDATA_H_ */
