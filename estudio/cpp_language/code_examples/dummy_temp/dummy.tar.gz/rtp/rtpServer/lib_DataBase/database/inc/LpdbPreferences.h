/*
 * LpdbPreferences.h
 
   Description:
   List of Preference associations (Airport A1, Airport A2) in a given interval.
   Defined at DAORTP_AssignmentPreference.xml after
   <preferentialAllocation> <allocation> tag.

   [ Example.-
     <allocation>
       <airport1> ENRS </airport1>
       <airport2> ENMH </airport2>
       <startTime> 06:00 </startTime>  // Managed in Timeline<LpdbPreferences>
       <endTime> 14:00 </endTime>
       <preferentialLevel> 1 </preferentialLevel>
     </allocation>
   end example ]
 
   Storage: 


 */


#ifndef LPDBPREFERENCES_H_
#define LPDBPREFERENCES_H_

#include <LpiAdapPrefsConstants.h>

#include <iostream>
#include <unordered_map>
#include <string>
#include <set>


class LpdbPreferences
{
 public:

  // keyed (search) by preferentialLevel: 1, 2, ...
	typedef std::unordered_multimap<PREF_LEVEL_TYPE, PreferenceElement>
	    	LpdbPreferencesStorageByLevelType;
  
  /* Iff keyed (search) by Airport id
  	 Insert operation: two insertions ?   (A1, A2) && (A2, A1)

  typedef std::unordered_multimap<PREF_AIRPORT_TYPE, PreferenceElement>
    LpdbPreferencesStorageByAirportType;  
  */
  
  LpdbPreferences() = default;
  LpdbPreferences(const LpdbPreferences&) = default;
  LpdbPreferences& operator=(const LpdbPreferences&) = default;
  virtual ~LpdbPreferences();


  const LpdbPreferencesStorageByLevelType & getPreferences() const;
  std::set<PreferenceElement> findAll(const PREF_LEVEL_TYPE &key) const;
  bool findOne(const PREF_LEVEL_TYPE &key, PreferenceElement &retval) const;

  
  void setPreferences(const PreferenceElementList & new_val);
  void addPreference(const PREF_LEVEL_TYPE &,
		             const PREF_AIRPORT1_TYPE &,
					 const PREF_AIRPORT2_TYPE &);

 protected:

  LpdbPreferencesStorageByLevelType r_preferencesLevelKey;
  //LpdbPreferencesStorageByAirportType r_preferencesAirportKey;

  void release();
};

std::ostream & operator<<(std::ostream & os, const LpdbPreferences & info);


#endif /* LPDBPREFERENCES_H_ */
