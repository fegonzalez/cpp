/*
 * LpdbDataTable.h
 *
 *  Created on: 13/12/2013
 *      Author: mbegega
 *
 *  Description: Template for a database table with primary key of type K
 *               and stored data type T
 */


#ifndef LPDBDATATABLE_H_
#define LPDBDATATABLE_H_

#include <map>
#include <vector>
#include <iostream>
#include <boost/foreach.hpp>

using std::map;
using std::vector;
using std::endl;

//K = Primary Key type (usually int or string), T= stored type

template <class K, class T>
class LpdbDataTable
{
   public:
      LpdbDataTable();
      LpdbDataTable(const LpdbDataTable & source);
      virtual ~LpdbDataTable() {}

      LpdbDataTable & operator= (const LpdbDataTable & source);

      bool exists    (const K & id) const;
      T & operator[] (const K & id);
      T   operator[] (const K & id) const;

      void addElement    (K id, T element);
      void updateElement (K id, T element);
      void deleteElement (K id);
      void deleteElements(const vector<K> & ids);

      map<K, T> getAll   () const;
      vector<K> getAllIds() const;

      int getNumberOfElements() const;

      void clear ();

   protected:
      map<K, T> r_data;

};


template<class K, class T>
inline LpdbDataTable<K, T>::LpdbDataTable()
: r_data()
{
}


template<class K, class T>
inline LpdbDataTable<K, T>::LpdbDataTable(const LpdbDataTable<K, T> & source)
: r_data(source.r_data)
{
}


template<class K, class T>
inline LpdbDataTable<K, T>& LpdbDataTable<K, T>::operator =(const LpdbDataTable<K, T> & source)
{
   if (this != &source)
   {
      r_data= source.r_data;
   }

   return *this;
}


template<class K, class T>
inline bool LpdbDataTable<K, T>::exists(const K & id) const
{
   return r_data.find(id) != r_data.end();
}


template<class K, class T>
inline T& LpdbDataTable<K, T>::operator [](const K & id)
{
   return r_data[id];
}


template<class K, class T>
inline T LpdbDataTable<K, T>::operator [](const K & id) const
{
   return r_data[id];
}


template<class K, class T>
inline void LpdbDataTable<K, T>::addElement(K id, T element)
{
   if (r_data.count(id) == 0)
   {
      r_data[id]= element;
   }
}


template<class K, class T>
inline void LpdbDataTable<K, T>::updateElement (K id, T element)
{
   if (r_data.count(id) > 0)
   {
      r_data[id]= element;
   }
}


template<class K, class T>
inline void LpdbDataTable<K, T>::deleteElement(K id)
{
   if (r_data.count(id) > 0)
   {
      r_data.erase(id);
   }
}


template<class K, class T>
inline void LpdbDataTable<K, T>::deleteElements(const vector<K> & ids)
{
   for (unsigned int i= 0; i < ids.size(); ++i)
   {
      deleteElement(ids[i]);
   }
}


template<class K, class T>
inline map<K, T> LpdbDataTable<K, T>::getAll() const
{
   return r_data;
}


template <class K, class T>
inline int LpdbDataTable<K, T>::getNumberOfElements() const
{
   return r_data.size();
}


template <class K, class T>
vector<K> LpdbDataTable<K, T>::getAllIds() const
{
   vector<K> result;
   typename map<K, T>::const_iterator data_it;

   for(data_it = r_data.begin(); data_it != r_data.end(); ++data_it)
   {
      result.push_back(data_it->first);
   }

   return result;
}


template <class K, class T>
void LpdbDataTable<K, T>::clear ()
{
   r_data.clear();
}


template <class K, class T>
inline std::ostream& operator<< (std::ostream & out, const LpdbDataTable<K, T> & table)
{
   map<K, T> elements = table.getAll();

   typename map<K, T>::const_iterator data_it;

   for(data_it = elements.begin(); data_it != elements.end(); ++data_it)
   {
      out << data_it->second << endl;
   }
   return out;
}


#endif /* LPDBDATATABLE_H_ */
