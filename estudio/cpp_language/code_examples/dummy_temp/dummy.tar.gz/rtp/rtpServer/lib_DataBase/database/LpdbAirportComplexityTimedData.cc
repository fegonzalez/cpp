/**@file LpdbAirportComplexityTimedData.cc
 */

#include "LpdbAirportComplexityTimedData.h"
#include <iostream>

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & os, const LpdbAirportComplexityTimedData & data)
{
  return os << "CAP: " << data.getComplexity();
}
