/*
 * LpdbRunwayIntervalKPIs.h
 *
 *  Created on: 20/10/2014
 *  Author:
 */

#ifndef LPB_RUNWAY_INTERVAL_KPIS_H
#define LPB_RUNWAY_INTERVAL_KPIS_H

#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <boost/foreach.hpp>

//#include "LpiSchedule.h"
//#include "LpiConfigurationAlertKPIs.h"

#include <LpiADOVector.h>
//#include <LpdbFPSchedule.h>

using std::string;
using std::vector;
using std::map;

class LpdbRunwayIntervalKPIs
{
   public:

      LpdbRunwayIntervalKPIs();
      LpdbRunwayIntervalKPIs(const LpdbRunwayIntervalKPIs & source);

      virtual ~LpdbRunwayIntervalKPIs() {}

      LpdbRunwayIntervalKPIs & operator= (const LpdbRunwayIntervalKPIs & source);

      void reset();

      //Values
      LpiADOVector<double> getMaxForecastedDelay()     const { return r_max_forecasted_delay; }
      LpiADOVector<double> getAverageForecastedDelay() const { return r_average_forecasted_delay; }
      LpiADOVector<double> getAverageForecastedDelay_DelayedFps() const { return r_average_forecasted_delay_delayedfps; }
      LpiADOVector<double> getPunctualFlights()        const { return r_punctual_flights; }
      LpiADOVector<double> getPunctualityPercentage()  const { return r_punctuality_percentage; }
      LpiADOVector<double> getRunwayDemandForecast()   const { return r_demand_forecast; }
      LpiADOVector<double> getRunwayAcceptedOwnInterval()   const { return r_accepted_fps_own_interval; }
      LpiADOVector<double> getRwyNotPunctualFlights() const { return r_not_punctual_flights; }
      LpiADOVector<double> getNumberOfDelayedFlights() const { return r_number_of_delayed_flights; }

      //Alerts
      //Warnings_alerts getMaxForecastedDelayWA() const { return r_max_forecasted_delayWA; }

      //void generateAbsoluteKPIs(string interval,
      //                          const LpiADOVector<vector<string> > & real_delayed,
      //                          const LpiADOVector<vector<string> > & accepted_fp_keys,
      //                          map<string, LpdbFPSchedule> & scheduled_fps,
      //                          map<string, LpdbFPSchedule> & delayed_fps_last_interval,
      //                          int delayCountThreshold);

      //void generateAlerts(string interval, OperationType::Enum usage, const LpiConfigurationAlertKPIs & thresholds);

     // static void convertToInterface (const OperationType::Enum & runway_usage,
     //                                 const LpdbRunwayIntervalKPIs & kpis,
     //                                 LpiRunwayIntervalKPIs & out);

   protected:

      LpiADOVector<double>            r_max_forecasted_delay;
      LpiADOVector<double>            r_average_forecasted_delay;
      LpiADOVector<double>            r_average_forecasted_delay_delayedfps;
      LpiADOVector<double>            r_punctual_flights;
      LpiADOVector<double>            r_punctuality_percentage;

      LpiADOVector<double>            r_total_forecasted_delay;
      LpiADOVector<double>            r_total_punctuality_delay;
      LpiADOVector<double>            r_not_punctual_flights;
      LpiADOVector<double>            r_demand_forecast;
      LpiADOVector<double>            r_accepted_fps_own_interval;

      //Phase 3:
      LpiADOVector<double>            r_number_of_delayed_flights;

      //Alerts
      //Warnings_alerts                 r_max_forecasted_delayWA;
      //Warnings_alerts                 r_average_forecasted_delay_delayedfpsWA;
      //Warnings_alerts                 r_punctuality_percentageWA;
};


std::ostream & operator<<(std::ostream & os, const LpdbRunwayIntervalKPIs & info);


#endif //LPB_RUNWAY_INTERVAL_KPIS_H
