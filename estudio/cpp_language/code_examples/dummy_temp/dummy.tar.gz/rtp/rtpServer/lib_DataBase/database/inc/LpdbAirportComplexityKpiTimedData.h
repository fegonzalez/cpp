/**@file LpdbAirportComplexityKpiTimedData.h
 * 
 * Complexity-Kpi value per interval data for a concrete
 * airport. Value in the range of the ISA WORKLOAD scale [ 0-5]
 *
 */

#ifndef LPDBAIRPORTCOMPLEXITYKPITIMEDDATA_H_
#define LPDBAIRPORTCOMPLEXITYKPITIMEDDATA_H_

#include <LcuBase.h>
#include <LplcTypeConstants.h>
#include <iosfwd>


class LpdbAirportComplexityKpiTimedData
{

public:

  LpdbAirportComplexityKpiTimedData() = default;
  LpdbAirportComplexityKpiTimedData(const LpdbAirportComplexityKpiTimedData & source) = default;
  LpdbAirportComplexityKpiTimedData & operator= (const LpdbAirportComplexityKpiTimedData & source) = default;
  virtual ~LpdbAirportComplexityKpiTimedData() {};
  
  rtp_constants::TYPE_COMPLEXITY get() const { return the_kpi; }

  /**@param new_val: [rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE -
                      rtp_constants::MAX_COMPLEXITY_ISA_WORKLOAD_VALUE]
   */
  void set(const rtp_constants::TYPE_COMPLEXITY &new_val)
  {
    the_kpi = lib_base::limit(new_val,
		    rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE,
		    rtp_constants::MAX_COMPLEXITY_ISA_WORKLOAD_VALUE);
  }

  void init()
  { the_kpi = rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE; }

 protected:

  /**@param the_kpi: [0-5], thus 
     [rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE - 
      rtp_constants::MAX_COMPLEXITY_ISA_WORKLOAD_VALUE]
  */
  rtp_constants::TYPE_COMPLEXITY the_kpi =
    rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE;
};

std::ostream& operator<<(std::ostream &os,const LpdbAirportComplexityKpiTimedData &);


#endif /* LPDBAIRPORTCOMPLEXITYKPITIMEDDATA_H_ */
