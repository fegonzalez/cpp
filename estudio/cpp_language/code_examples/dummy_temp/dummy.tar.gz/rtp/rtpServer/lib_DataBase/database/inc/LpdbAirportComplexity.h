/*
 * LpdbAirportComplexity.h
 *
 *
 * DOC Reference [1] "2018-08-03 RTP Diseño Funcional.docx", chapter
 *     4.3.2 Cálculos de complejidades.
 *
 * DOC Reference [2] Adaptation file - DAORTP_AirportsInfo.xml
 *
 * DOC Reference [3] Adaptation file storage - LpiAdaptationAirportsInfo.h
 */

#ifndef LPDBAIRPORTCOMPLEXITY_H_
#define LPDBAIRPORTCOMPLEXITY_H_

#include <LplcTypeConstants.h>
//#include <LpiADOVector.h>
#include <LctimTimeLine.h>
#include <LpiTimeParameters.h>
#include <LpdbAirportComplexityTimedData.h>

#include <string>
#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>



/**@class LpdbAirportComplexity
 
 @brief Complexity data associated to a concrete Airport.
 
 @warning Only the explicit constructor is expected to be used
     in the regular program logic, therefore is the only constructor that
     initialize the required attribute 'the_airport' within a valid value.
     Anyway, the default constructor, copy constructor, and operator=
     can't be deleted because LpdbAirportComplexity is implicitly
     initialized used within TimeLine objects.
 */
class LpdbAirportComplexity
{
  friend std::ostream& operator<<(std::ostream &os, 
				  const LpdbAirportComplexity &input);
  
 public:

  typedef unsigned int TYPE_COMPLEXITY_DEMAND;
  
  explicit LpdbAirportComplexity
    (const std::string  &airport,
     //airport thresholds: per hour values! ( defined in LpdbAirport)
     unsigned int totalMovAirportUpperThreshold,
     unsigned int totalMovAirportLowerThreshold,
     unsigned int vfrAirportUpperThreshold,
     unsigned int vfrAirportLowerThreshold,
     // DAORTP_Parameters.xml <complexityWeightPonderationAirports>
     double weightLVP,
     double weightIce,
     double weightTotalMovAirport,
     double weightVfrAirport);

  
  virtual ~LpdbAirportComplexity() {}

  //required default operations (see warning above)
  LpdbAirportComplexity() = default;
  LpdbAirportComplexity(const LpdbAirportComplexity & source) = default;
  LpdbAirportComplexity & operator= (const LpdbAirportComplexity & source) = default;


  // interval (TimeLine) operations 

  // 1) complexity TimeLine

  //Check if has data associated to one given interval name
  bool has_data(const std::string & interval_name);
  //Get one element from internal timeline for modification
  LpdbAirportComplexityTimedData & operator[] (const std::string & interval_name);
  TimeLine<LpdbAirportComplexityTimedData> getTimeLine() const;
  //stablish timeline
  void init(const LpiTimeParameters & timeData,
	    boost::posix_time::ptime begin_timestamp);
  //TimeInterval getTimeInterval(const std::string & interval);
  std::vector<std::string> getAllIntervalIds() const
    { return the_airport_complexity.getAllIntervalIds(); }

  
  
  ///@todo 1) KPIs TimeLine    Mirar RMAN Kpis classes en DB

  /* bool has_data_kpi(const std::string & interval_name); */
  /* LpdbAirportComplexityKpiTimedData & operator[] */
  /*   (const std::string & interval_name); */
  /* TimeLine<LpdbAirportComplexityKpiTimedData> getTimeLine() const; */
  /* void init_kpi(const LpiTimeParameters & timeData, */
  /* 		boost::posix_time::ptime begin_timestamp); */
  /* //TimeInterval getKpiTimeInterval(const std::string & interval); */


  
  //Forwards internal timeline in one interval
  void forward();
  void forward(const std::string &interval);

  void calculateComplexity(); // For all the intervals



  ///@test functions called from the unitary test must be public
  void calculate(const std::string &interval);
  void setLvpActivation(const boost::optional<bool> &lvpActivation)
  { the_lvp_activation = lvpActivation; }
  void setDeicingRequired(const boost::optional<bool> &deicingRequired)
  { the_deicing_required = deicingRequired; }
  void setDemandForecast(const TYPE_COMPLEXITY_DEMAND &newval)
  { the_demand_forecast = newval; }
  void setDemandVfr(const TYPE_COMPLEXITY_DEMAND &newval)
  { the_demand_vfr = newval; }
  void calculateTotalComplexity();
  void calculateComplexityKPIs();

  ///@todo FIXME  case: demand data not available; expected at init, before any demand has been received.
  void setDemadForecastReceived(){ the_demand_forecast_received = true; }
  void setDemadVfrReceived(){ the_demand_vfr_received = true; }
  void resetDemadForecastReceived(){ the_demand_forecast_received = false; }
  void resetDemadVfrReceived(){ the_demand_vfr_received = false; }


  
 private:
  
  std::string getAirportId()const { return the_airport; }

  //complexity calculations
  void calculateComplexity(const std::string &interval);
  void updateInputs(const std::string &interval);
  rtp_constants::TYPE_COMPLEXITY calculate_LVP_complexity();
  rtp_constants::TYPE_COMPLEXITY calculate_ice_complexity();
  rtp_constants::TYPE_COMPLEXITY calculate_totalMovs_complexity();
  rtp_constants::TYPE_COMPLEXITY calculate_VFRflights_complexity();
  rtp_constants::TYPE_COMPLEXITY fn_demand_complexity
    (const TYPE_COMPLEXITY_DEMAND & demand_data,
     const unsigned int lowerThreshold,
     const unsigned int upperThreshold);
  
  //aux fns.
  void assertWeights();
  void resetComplexityWeights();
  void errorComplexityWeights();
  bool check_airport_exists();


  //inputs getters-setters
  double get_weightLVP() const { return the_weightLVP; }
  double get_weightIce() const { return the_weightIce; }
  double get_weightTotalMovAirport() const { return the_weightTotalMovAirport; }
  double get_weightVfrAirport() const { return the_weightVfrAirport; }
  void set_weightLVP(const double &newval) { the_weightLVP = newval; }
  void set_weightIce(const double &newval) { the_weightIce = newval; }
  void set_weightTotalMovAirport(const double &newval)
  { the_weightTotalMovAirport = newval; }
  void set_weightVfrAirport(const double &newval)
  { the_weightVfrAirport = newval; }

  unsigned int get_totalMovAirportUpperThreshold() const
  { return the_totalMovAirportUpperThreshold; }
  unsigned int get_totalMovAirportLowerThreshold() const
  { return the_totalMovAirportLowerThreshold ; }
  unsigned int get_vfrAirportUpperThreshold() const
  { return the_vfrAirportUpperThreshold; }
  unsigned int get_vfrAirportLowerThreshold() const
  { return the_vfrAirportLowerThreshold; }

  //c) Variable inputs per interval
  //c.1) meteo constraints
  const boost::optional<bool> getLvpActivation() const
  { return the_lvp_activation; }
  const boost::optional<bool> getDeicingRequired() const
  { return the_deicing_required; }


  
  //c.2) demand constraints
  ///@todo

  /**@param Demand_Forecast(ti) = [Num_Ai, Num_Di, Num_Oi] definido en 4.2.1 Demanda prevista
   */
  const TYPE_COMPLEXITY_DEMAND getDemandForecast() const
  { return the_demand_forecast; }
  const TYPE_COMPLEXITY_DEMAND getDemandVfr() const
  { return the_demand_vfr; }

  ///@todo FIXME  case: demand data not available; expected at init, before any demand has been received.
  bool getDemadForecastReceived(){ return the_demand_forecast_received; }
  bool getDemadVfrReceived(){ return the_demand_vfr_received; }


  
  ///////////////
  // data area
  ///////////////
 
  // 0.25 * 4 vars = 1.0 == 100%
  static const double DEFAULT_COMPLEX_WEIGHT;
  static const TYPE_COMPLEXITY_DEMAND  MIN_COMPLEXITY_DEMAND_VALUE;
  static const std::string BAD_COMPLEX_SUM_MSG;
  static const std::string BAD_COMPLEX_ZERODIV_MSG;

  
  // 1) INPUTS

  // a) attributes
  
  ///@param the_airport: id of the associated Airport.
  ///@warning Can't be <<const>> because it will be used to call a TimeLine
  ///         (e.g. the_airport.getMeteoForecast().getElement(interval))
  std::string the_airport = {""};

  // b) fixed inputs: adap & config
  
  // adaptation data
  //airport thresholds: per hour values! ( defined in LpdbAirport)
  unsigned int the_totalMovAirportUpperThreshold = 0;
  unsigned int the_totalMovAirportLowerThreshold = 0;
  unsigned int the_vfrAirportUpperThreshold = 0;
  unsigned int the_vfrAirportLowerThreshold = 0;
  //configuration data
  // DAORTP_Parameters.xml <complexityWeightPonderationAirports>
  double the_weightLVP = DEFAULT_COMPLEX_WEIGHT;
  double the_weightIce = DEFAULT_COMPLEX_WEIGHT;
  double the_weightTotalMovAirport = DEFAULT_COMPLEX_WEIGHT;
  double the_weightVfrAirport = DEFAULT_COMPLEX_WEIGHT;

  // c) Variable inputs per interval (updated upon calculating each interval)

  ///@todo demand constraints
  /**@param the_demand_forecast

     Demand_Forecast(ti) = [Num_Ai, Num_Di, Num_Oi] definido en 4.2.1
                                                    Demanda prevista.

     @warning Solo se usa la componente Overal
   */
  TYPE_COMPLEXITY_DEMAND the_demand_forecast = MIN_COMPLEXITY_DEMAND_VALUE;
  
  /**@param the_demand_vfr

     Demand_VFR(ti) = [Num_VFR_Oi] definido en 4.2.1 Demanda prevista

     @warning Solo se usa la componente Overal
   */
  TYPE_COMPLEXITY_DEMAND the_demand_vfr = MIN_COMPLEXITY_DEMAND_VALUE;


  ///@todo FIXME  case: demand data not available; expected at init, before any demand has been received.
  bool the_demand_forecast_received = false;
  bool the_demand_vfr_received = false;


  // meteo data
  boost::optional<bool> the_lvp_activation;
  boost::optional<bool> the_deicing_required;



  // 2) OUTPUTS
  
  /**@param the_total_airport_complexity: total value of complexity
     for the airport for the time-window.

     value = ( SUM (the_airport_complexity) ) / num_intervals;
               ti

  */
  rtp_constants::TYPE_COMPLEXITY the_total_airport_complexity =
    rtp_constants::DEFAULT_COMPLEXITY_VALUE;


  /**@param the_airport_complexity: complexity data per interval for the airport
     Stores the data specified at [1].Complexity_Airport(ti) for every
     interval ti.
  */
  TimeLine<LpdbAirportComplexityTimedData> the_airport_complexity;


  ///@todo KPIs

  
  /**@param the_total_kpi_airport_complexity: total value of complexity KPIs
     for the airport for the time-window. (escala ISA-Workload)

     value = the_total_airport_complexity * MAX_COMPLEXITY_ISA_WORKLOAD_VALUE;
  */
  // rtp_constants::TYPE_COMPLEXITY the_total_kpi_airport_complexity =
  //  rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE;

  /**@param the_airport_complexity: complexity data per interval for the airport
     Stores the data specified at [1].Complexity_Airport(ti) for every
     interval ti.
  */
  //  TimeLine<LpdbAirportComplexityKpiTimedData> the_airport_complexity_kpi;

};


#endif /* LPDBAIRPORTCOMPLEXITY_H_ */
