/*
 * LpdbGlobalParameters.h
 *
 *
 * DOC Reference: [1] "2018-08-03 RTP Diseño Funcional.docx"
 *
 *
 * @warning Starting from the RMAN DB design => RMAN tables => some of them are not valid RTP tables
 *
 * @todo remove all the unused (RMAN) tables and variables (task
 *       spared among all the RTP tasks):
 */

#ifndef LPBGLOBALPARAMETERS_H_
#define LPBGLOBALPARAMETERS_H_

#include <string>
#include "LpiTimeParameters.h"
#include "LpiEvaluationDistribution.h"
#include "LpiConfigurationConstraints.h"
#include <LpiADO.h>
#include "LpiWeightPonderationParameters.h"
#include <LpiAdaptationMrtmInfo.h>
#include <LpiAdaptationAlert_KPIs.h>


//----------------------------------------------------------------------------

/**@param thresholds & prohibitions (see [1].4.1)

 @warning units: storing adaptation values/interval instead of the original
          values/hour in the adaptation file.
*/
struct LpdbAdapThresholdsPerInterval
{
  void init 
  (unsigned int totalMovMrtmUpperThreshold,
   unsigned int totalMovMrtmLowerThreshold,
   unsigned int vfrMrtmUpperThreshold,
   unsigned int vfrMrtmLowerThreshold,
   unsigned int SimultaneousOpsHourAlert_Alarm,
   unsigned int SimultaneousOpsHourAlert_Warning,
   unsigned int totalMovAlert_Alarm,
   unsigned int totalMovAlert_Warning,
   unsigned int ComplexityAlert_AirportsComplexity_Alarm,
   unsigned int ComplexityAlert_AirportsComplexity_Warning,
   unsigned int ComplexityAlert_ModulesComplexity_Alarm,
   unsigned int ComplexityAlert_ModulesComplexity_Warning,
   unsigned int vfrAlert_Alarm,
   unsigned int vfrAlert_Warning,
   unsigned int N1);

  // [value/interval]
  unsigned int theTotalMovMrtmUpperThreshold;
  unsigned int theTotalMovMrtmLowerThreshold;
  unsigned int theVfrMrtmUpperThreshold;
  unsigned int theVfrMrtmLowerThreshold;
  //iii) Alerts: Alarm and  Warning (DAORTP_Alert_KPI.xml)
  unsigned int theSimultaneousOpsHourAlert_Alarm;
  unsigned int theSimultaneousOpsHourAlert_Warning;
  unsigned int theTotalMovAlert_Alarm;
  unsigned int theTotalMovAlert_Warning;
  unsigned int theComplexityAlert_AirportsComplexity_Alarm;
  unsigned int theComplexityAlert_AirportsComplexity_Warning;
  unsigned int theComplexityAlert_ModulesComplexity_Alarm;
  unsigned int theComplexityAlert_ModulesComplexity_Warning;
  unsigned int theVfrAlert_Alarm;
  unsigned int theVfrAlert_Warning;  
};


std::ostream& operator<<(std::ostream & os, 
			 const LpdbAdapThresholdsPerInterval & params);

//----------------------------------------------------------------------------

class LpdbGlobalParameters
{
   public:
      LpdbGlobalParameters ();
      LpdbGlobalParameters (const LpiTimeParameters & timeData,
                           const LpiEvaluationDistribution & distribution,
                           const LpiWeightPonderationParameters & ponderations,
                           const bool & use_file_capacity_reductions,
                           const bool & use_wtc_capacity_reductions,
                           const double & fp_expiration_time,
                           const double & alternativeExpirationHours,
                           int   tminTurnRound,
                           int   closedTurnRound);

      LpdbGlobalParameters (const LpdbGlobalParameters & source) = default;
      LpdbGlobalParameters & operator= (const LpdbGlobalParameters & source) = default;


      void init(const LpiTimeParameters & timeData,
    		    const bool & use_wtc_capacity_reductions,
				const double & fp_expiration_time,
				const double & alternativeExpirationHours,
				const ComplexityThresholds & adapMrtComplexityThresholds,
				const LpiAdaptationAlert_KPIs & adapAlertThresholds);



      virtual ~LpdbGlobalParameters() {}

      //Accessors
      LpiTimeParameters getTimeParameters () const;
      LpiEvaluationDistribution getEvaluationDistribution() const;
      LpiWeightPonderationParameters getWeightPonderations() const;

      bool getUseFileCapacityReductions () const;
      bool getUseWakeVortexCapacityReductions() const;
      double getFPExpirationTime () const;

      unsigned int getNumberOfIntervalsInHour () const;

      int    getDefaultTaxiTime()            const;
      double  getAlternativeScheduleExpirationHours() const;

      int    getTminTurnRound()            const;
      int    getClosedTurnRound()          const;

      LpdbAdapThresholdsPerInterval getAdapThresholdsPerInterval()const;


   protected:


      LpiTimeParameters r_time_parameters; //RTP verified!

      
      ///@warning RMAN only: DCB Suitability
      ///@todo RMAN only, remove when not called anymore
      LpiEvaluationDistribution r_distribution;  
      
LpiWeightPonderationParameters r_ponderations;///@todo RMAN only, remove when not called anymore
      
bool   r_use_file_capacity_reductions;///@todo RMAN only, remove when not called anymore


      bool   r_use_wtc_capacity_reductions; //RTP verified!


      /**@param r_fp_expiration_time [1].3.2.1
       * Tiempo de caducidad de los FP: Por defecto 60 min.
       * Si la ITOT/ILDT de un PV es anterior al Tiempo actual menos el Tiempo
       * de caducidad, se eliminará el PV de la base de datos.
       */
      double r_fp_expiration_time; //RTP verified!

      ///@param r_N1 Subintervals: Number of subintervals in an hour
      unsigned int               r_N1;

      /// airpor_info parameters: in RMAN only one airport
      //std::string       r_airport_name; ///@todo RMAN only, remove when..
      int               r_default_taxi_time; ///@todo RMAN only, remove when..


      ///@param r_alternativeScheduleExpirationHours: N/A in the first RTP version
      double             r_alternativeScheduleExpirationHours; //RTP verified!


      int               r_tminTurnRound; ///@todo RMAN only, remove when
      int               r_closedTurnRound; ///@todo RMAN only, remove when


      ///@param r_adapThresholds: thresholds & prohibitions (see [1].4.1)
      LpdbAdapThresholdsPerInterval r_adapThresholds;  //RTP verified!



      // methods
      void setNumberOfIntervalsInHour(unsigned int new_val);

};

std::ostream& operator<<(std::ostream & os, const LpdbGlobalParameters & params);


#endif /* LPBGLOBALPARAMETERS_H_ */
