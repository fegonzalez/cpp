/*
 * LpdbDemandTimedData.cc
 *
 *  Created on: 02/01/2013
 *      Author: mbegega
 */

#include "LpdbDemandTimedData.h"
#include <LpdbDataBase.h>
#include "LpiADOVector.h"

#include <LcuDataTypeUtils.h>


LpdbDemandTimedData::LpdbDemandTimedData()
: r_name("LpdbDemandTimedData"),
  r_demand_forecast(),
  r_demand_forecast_fps()
{
}


LpdbDemandTimedData::LpdbDemandTimedData(const LpdbDemandTimedData & source)
: r_name(source.r_name),
  r_demand_forecast(source.r_demand_forecast),
  r_demand_forecast_fps(source.r_demand_forecast_fps)
{
}


LpdbDemandTimedData::~LpdbDemandTimedData()
{

}


LpdbDemandTimedData & LpdbDemandTimedData::operator= (const LpdbDemandTimedData & source)
{
   if (this != &source)
   {
      r_demand_forecast = source.r_demand_forecast;
      r_demand_forecast_fps = source.r_demand_forecast_fps;
   }

   return *this;
}


std::string LpdbDemandTimedData::get_name ()
{
   return r_name;
}


LpiADOVector<int> LpdbDemandTimedData::getDemandForecast() const
{
   return r_demand_forecast;
}


void LpdbDemandTimedData::setDemandForecast(LpiADOVector<int> demandForecast)
{
   r_demand_forecast = demandForecast;
}


LpiADOVector<vector<string> > LpdbDemandTimedData::getDemandForecastFps() const
{
   return r_demand_forecast_fps;
}


void LpdbDemandTimedData::setDemandForecastFps(LpiADOVector<vector<string> > demandForecastFps)
{
   r_demand_forecast_fps = demandForecastFps;
}

LpiADOVector<int> LpdbDemandTimedData::getDemandVFR() const
{
   return r_demand_VFR;
}


void LpdbDemandTimedData::setDemandVFR(LpiADOVector<int> demandVFR)
{
   r_demand_VFR = demandVFR;
}

void LpdbDemandTimedData::incrementDemand(int demand_type, int demand_value)
{
   r_demand_forecast[demand_type]+= demand_value;
}


void LpdbDemandTimedData::decrementDemand(int demand_type, int demand_value)
{
   int value_to_substract= (r_demand_forecast[demand_type] > demand_value)
                          ? demand_value
                          : r_demand_forecast[demand_type];

   r_demand_forecast[demand_type] -= value_to_substract;
}


void LpdbDemandTimedData::storeFPInForecast(const LpiFlightPlan & fp)
{
   if (fp.getOperationType() == LpiOperationType::E_DEPARTURE)
   {
      storeOrdered(fp, r_demand_forecast_fps[E_DEP]);
      storeOrdered(fp, r_demand_forecast_fps[E_OVA]);
   }
   else if (fp.getOperationType() == LpiOperationType::E_ARRIVAL)
   {
      storeOrdered(fp, r_demand_forecast_fps[E_ARR]);
      storeOrdered(fp, r_demand_forecast_fps[E_OVA]);
   }
}


void LpdbDemandTimedData::storeOrdered (const LpiFlightPlan & fp, vector<string> & storage)
{
  // LpdbDataBase::FPTable & fp_table =LpdbDataBase::Get().getFPTable();

  //  bool position_found = false;
  //  bool exists_fp = false;
  //  string flight_plan_key;

  //  for (unsigned int i = 0 ; i < storage.size() ; i++)
  //  {
  //     flight_plan_key = storage[i];
  //     exists_fp = fp_table.exists(flight_plan_key);

  //     if (exists_fp)
  //     {
  //        LpiFlightPlan fp_database = fp_table[flight_plan_key];

  //        if (fp < fp_database)
  //        {
  //           storage.insert(storage.begin() + i, fp.getUniqueKey());
  //           position_found = true;
  //           break;
  //        }
  //     }
  //  }

  //  if ((!position_found) || storage.size() == 0)
  //  {
  //     storage.push_back(fp.getUniqueKey());
  //  }
  
}


void LpdbDemandTimedData::deleteFPFromForecast(const LpiFlightPlan & fp)
{
   int type_to_delete = 0;

   if (fp.getOperationType() == LpiOperationType::E_DEPARTURE)
   {
      type_to_delete = E_DEP;
   }
   else if (fp.getOperationType() == LpiOperationType::E_ARRIVAL)
   {
      type_to_delete = E_ARR;
   }

   for (unsigned int i = 0; i < r_demand_forecast_fps[type_to_delete].size(); i++)
   {
      if (fp.getUniqueKey() == r_demand_forecast_fps[type_to_delete][i])
      {
         r_demand_forecast_fps[type_to_delete].erase(r_demand_forecast_fps[type_to_delete].begin() + i);
         break;
      }
   }

   for (unsigned int i = 0; i < r_demand_forecast_fps[E_OVA].size(); i++)
   {
      if (fp.getUniqueKey() == r_demand_forecast_fps[E_OVA][i])
      {
         r_demand_forecast_fps[E_OVA].erase(r_demand_forecast_fps[E_OVA].begin() + i);
         break;
      }
   }
}


LpiADOVector<double> LpdbDemandTimedData::getPonderatedDemand() const
{
   LpiADOVector<double> ponderatedDemand;

   double accumulated_demand = r_demand_forecast[E_ARR] + r_demand_forecast[E_DEP];

   if (LcuDataTypeUtils::double_equals(accumulated_demand, 0))
   {
      ponderatedDemand[E_ARR] = static_cast<double>(r_demand_forecast[E_ARR]) / accumulated_demand;
      ponderatedDemand[E_DEP] = static_cast<double>(r_demand_forecast[E_DEP]) / accumulated_demand;
      ponderatedDemand[E_OVA] = static_cast<double>(r_demand_forecast[E_OVA]) / accumulated_demand;
   }
   else
   {
      ponderatedDemand[E_ARR] = 0.5;
      ponderatedDemand[E_DEP] = 0.5;
      ponderatedDemand[E_OVA] = 1.0;
   }

   return ponderatedDemand;
}


bool LpdbDemandTimedData::isEmpty() const
{
   return (r_demand_forecast[E_ARR] == 0) &&
          (r_demand_forecast[E_DEP] == 0) &&
          (r_demand_forecast[E_OVA] == 0);
}


std::ostream& operator<<(std::ostream &os, const LpdbDemandTimedData &info)
{
   std::stringstream out_stream;

   LpiADOVector<vector<string> > forecast = info.getDemandForecastFps();

   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   out_stream << "[";

   for (int i = E_ARR; i<= E_OVA; i++)
   {
      vector<string> demand_fps = forecast[i];

      out_stream << "(";
      for (unsigned int j= 0; j < demand_fps.size(); j++)
      {
         std::string fpKey = demand_fps[j];

         if (fpTable.exists(fpKey))
         {
            LpiFlightPlan fp = fpTable[fpKey];
            out_stream << fp.getCallsign();
         }

         if (j != demand_fps.size() - 1)
         {
            out_stream << ", ";
         }
      }
      out_stream << ")";

   }

   out_stream << "]";

   os << info.getDemandForecast()
      << " | RATIO: " << info.getPonderatedDemand()
      << " | FPs : " << out_stream.str();

   return os;
}
