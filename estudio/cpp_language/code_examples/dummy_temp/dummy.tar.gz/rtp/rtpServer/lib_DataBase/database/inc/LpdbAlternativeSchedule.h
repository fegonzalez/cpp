/*
 * LpdbAlternativeSchedule.h
 *
 * @warning Not part of the first iteration of the RTP project (January 2019).
 *
 * @warning See RMAN code as reference.
 *
 */

#ifndef LPBALTERNATIVESCHEDULE_H_
#define LPBALTERNATIVESCHEDULE_H_

#include <LpdbSchedule.h>



class LpdbAlternativeSchedule : public LpdbSchedule
{
  friend std::ostream & operator<<(std::ostream & os, 
				   const LpdbAlternativeSchedule & data);

 public:

  ScheduleType type() const { return ScheduleType::E_ALTERNATIVE; }


 private:
  
  void print_concrete_data (std::ostream & out) const;

};


#endif /* LPBALTERNATIVESCHEDULE_H_ */
