/*
 * LpdbAlternativeSchedule.h
 *
 *  Created on: 11/07/2014
 *      Author: mbegega
 */

#ifndef LPBALTERNATIVESCHEDULE_H_
#define LPBALTERNATIVESCHEDULE_H_

#include <string>

#include "LpdbSchedule.h"
#include "LpdbScheduleConverter.h"

#include "LpiScheduleActivationType.h"
#include "LpiActiveSchedule.h"
#include "LpiAlternativeSchedule.h"
#include "LpdbExpirationInfo.h"


using std::string;

class LpdbAlternativeSchedule : public LpdbSchedule
{
   public:

      LpdbAlternativeSchedule();
      LpdbAlternativeSchedule(int min_subinterval,
                             int hours_window,
                             int min_frozen,
                             boost::posix_time::ptime begin_timestamp);

      LpdbAlternativeSchedule(const LpdbAlternativeSchedule & source);
      LpdbAlternativeSchedule(const LpdbSchedule & source);

      virtual ~LpdbAlternativeSchedule() {}

      LpdbAlternativeSchedule & operator= (const LpdbAlternativeSchedule & source);

      void setActivationType (LpiScheduleActivationType::LpiEnum activation)
      { r_activation_type = activation; }

      LpiScheduleActivationType::LpiEnum getActivationType () const
      { return r_activation_type; }

      bool isManuallyActivated() const
      { return (r_activation_type == LpiScheduleActivationType::E_MANUAL); }

      void setId (int newId)
      { r_id = newId; }

      int getId () const
      { return r_id; }

      void setName (string name)
      { r_name = name; }

      string getName () const
      { return r_name; }

      void setExpirationInformation(const LpdbExpirationInfo & info)
      { r_expirationInfo = info; }

      const LpdbExpirationInfo & getExpirationInformation() const
      { return r_expirationInfo; }

      bool isExpired() const
      { return r_expirationInfo.isExpired(); }

      void setExpirationDate (const boost::posix_time::ptime & expirationDate)
      { r_expirationInfo.setExpirationDate(expirationDate); }

      int getRunwayClosure() const
      { return r_runwayClosure; }

      void setRunwayClosure(int closure)
      { r_runwayClosure = closure; }

      double getTotalCost() const
      { return r_totalCost; }

      void setTotalCost(double cost)
      { r_totalCost = cost; }

      bool isEqual(LpdbAlternativeSchedule & right);

//      static LpiActiveSchedule Convert2ActiveInterface (LpdbAlternativeSchedule & active_schedule,
//                                                        const LpiConfigurationAlertKPIs & alertKPIs,
//                                                        const boost::posix_time::ptime & activationTime);

//      static LpiAlternativeSchedule Convert2AlternativeInterface (LpdbAlternativeSchedule & schedule,
//                                                                  const LpiConfigurationAlertKPIs & alertKPIs);

   protected:

      int r_id;
      string r_name;

      LpiScheduleActivationType::LpiEnum r_activation_type;

      //For checking what-if automatic deletion
      LpdbExpirationInfo r_expirationInfo;

      int r_runwayClosure;
      double r_totalCost;
};


std::ostream & operator<<(std::ostream & os, const LpdbAlternativeSchedule & info);



#endif /* LPBALTERNATIVESCHEDULE_H_ */
