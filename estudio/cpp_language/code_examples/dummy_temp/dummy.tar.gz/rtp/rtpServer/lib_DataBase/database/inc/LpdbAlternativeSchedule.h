/*
 * LpdbAlternativeSchedule.h
 *
 * @warning Not part of the first iteration of the RTP project (January 2019).
 *
 * @warning See RMAN code as reference.
 *
 */

#ifndef LPBALTERNATIVESCHEDULE_H_
#define LPBALTERNATIVESCHEDULE_H_

#include <LpdbSchedule.h>



class LpdbAlternativeSchedule : public LpdbSchedule
{
};


std::ostream & operator<<(std::ostream & os, const LpdbAlternativeSchedule & info);



#endif /* LPBALTERNATIVESCHEDULE_H_ */
