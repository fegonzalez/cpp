/**@file LpdbAirportComplexityKpiTimedData.cc
 */

#include <LpdbAirportComplexityKpiTimedData.h>
#include <iostream>

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & os, const LpdbAirportComplexityKpiTimedData & data)
{
  return os << "COMPLEXITY-KPI VALUE: " << data.get();
}
