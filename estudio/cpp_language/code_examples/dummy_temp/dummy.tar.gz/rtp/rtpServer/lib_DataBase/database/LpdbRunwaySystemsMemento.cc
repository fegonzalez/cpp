/*
 * LpdbRunwaySystemsMemento.cc
 *
 *  Created on: 11/03/2015
 *      Author: mbegega
 */

#include <LctimTimeLine.h>
#include "LpdbDCBAirportTimedData.h"
//#include "LpdbDataBase.h"
#include "LpdbRunwaySystemsMemento.h"


/*LpdbRunwaySystemsMemento::LpdbRunwaySystemsMemento(const LpdbDataBase::RunwayTable & runways,
                                                 const LpdbDataBase::RunwaySystemTable & runwaySystems,
                                                 const TimeLine<LpdbDCBAirportTimedData> & dcbAirportTimeline)
: r_runwaysState(runways),
  r_runwaySystemsState(runwaySystems),
  r_DCBAirportTimeline(dcbAirportTimeline)
{
}

LpdbDataBase::RunwayTable LpdbRunwaySystemsMemento::getRunwaysState () const
{
   return r_runwaysState;
}

LpdbDataBase::RunwaySystemTable LpdbRunwaySystemsMemento::getRunwaySystemsState() const
{
   return r_runwaySystemsState;
}*/


TimeLine<LpdbDCBAirportTimedData> LpdbRunwaySystemsMemento::getDCBAirportTimelineState() const
{
   return r_DCBAirportTimeline;
}


LpdbRunwaySystemsMemento & LpdbRunwaySystemsMemento::operator= (const LpdbRunwaySystemsMemento & source)
{
   if (this != &source)
   {
      //r_runwaysState = source.r_runwaysState;
      //r_runwaySystemsState = source.r_runwaySystemsState;
      r_DCBAirportTimeline = source.r_DCBAirportTimeline;
   }

   return *this;
}


ostream & operator<< (ostream & out, const LpdbRunwaySystemsMemento & m)
{
  /* out << "[RUNWAYS STATE:\n" << m.getRunwaysState()
       << "]\n"
       << "[RS STATE:\n" << m.getRunwaySystemsState()
       << "]\n"
       << "[AIRPORT DCB:\n" << m.getDCBAirportTimelineState()
       << "]\n";*/

   return out;
}
