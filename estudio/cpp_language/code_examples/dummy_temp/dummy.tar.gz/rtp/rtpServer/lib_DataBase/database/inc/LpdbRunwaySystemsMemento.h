/*
 * LpdbRunwaySystemsMemento.h
 *
 *  Created on: 11/03/2015
 *      Author: mbegega
 *
 *  Description: Memento object used in memento design pattern
 *               to backup/restore runways and RS state
 *               Originator object is LpdbDataBase
 *               Caretaker object is LpdBusinessLogicFacade
 */

#ifndef LPBRUNWAYSYSTEMSMEMENTO_H_
#define LPBRUNWAYSYSTEMSMEMENTO_H_

#include <string>
#include <iostream>

class LpdbDataBase;
class LpdbDCBAirportTimedData;
template <class T> class TimeLine;


using std::string;
using std::ostream;

class LpdbRunwaySystemsMemento
{
   public:

	LpdbRunwaySystemsMemento(){}

     /* LpdbRunwaySystemsMemento(const LpdbDataBase::RunwayTable & runways,
                              const LpdbDataBase::RunwaySystemTable & runwaySystems,
                              const TimeLine<LpdbDCBAirportTimedData> & dcbAirportTimeline);*/

      //LpdbDataBase::RunwayTable getRunwaysState () const;
      //LpdbDataBase::RunwaySystemTable getRunwaySystemsState() const;
      TimeLine<LpdbDCBAirportTimedData> getDCBAirportTimelineState() const;

      LpdbRunwaySystemsMemento & operator= (const LpdbRunwaySystemsMemento & source);

   private:

     // LpdbDataBase::RunwayTable       r_runwaysState;
     // LpdbDataBase::RunwaySystemTable r_runwaySystemsState;
      TimeLine<LpdbDCBAirportTimedData> r_DCBAirportTimeline;
};


ostream & operator<< (ostream & out, const LpdbRunwaySystemsMemento & m);

#endif /* LPBRUNWAYSYSTEMSMEMENTO_H_ */
