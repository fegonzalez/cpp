/*
 * LpdbAbsoluteKPIs.cc
 *
 *  Created on: 22/07/2013
 *      Author: gpfernandez
 */

#include "LpdbAbsoluteKPIs.h"
//#include "LpdbDataBase.h"

LpdbAbsoluteKPIs::LpdbAbsoluteKPIs()
: r_total_real_accepted_fps(),
  r_total_real_delay_fps(),
  r_shortage(),
  r_max_forecast_delay(),
  r_average_forecast_delay(),
  r_max_punctuality_delay(),
  r_average_punctuality_delay(),
  r_punctual_fp(),
  r_delayed_fp(),
  r_punctual_porcentage(),
  r_average_forecasted_delay_delayedfps(),
  r_warningErrors(),
  r_kpis_runways()
{
}


LpdbAbsoluteKPIs::LpdbAbsoluteKPIs(const LpdbAbsoluteKPIs & source)
:r_total_real_accepted_fps(source.r_total_real_accepted_fps),
 r_total_real_delay_fps(source.r_total_real_delay_fps),
 r_shortage(source.r_shortage),
 r_max_forecast_delay(source.r_max_forecast_delay),
 r_average_forecast_delay(source.r_average_forecast_delay),
 r_max_punctuality_delay(source.r_max_punctuality_delay),
 r_average_punctuality_delay(source.r_average_punctuality_delay),
 r_punctual_fp(source.r_punctual_fp),
 r_delayed_fp(source.r_delayed_fp),
 r_punctual_porcentage(source.r_punctual_porcentage),
 r_average_forecasted_delay_delayedfps(source.r_average_forecasted_delay_delayedfps),
 r_warningErrors(source.r_warningErrors),
 r_kpis_runways(source.r_kpis_runways)
{

}

LpdbAbsoluteKPIs & LpdbAbsoluteKPIs::operator= (const LpdbAbsoluteKPIs & source)
{
   if (this != &source)
   {
      r_total_real_accepted_fps = source.r_total_real_accepted_fps;
      r_total_real_delay_fps = source.r_total_real_delay_fps;
      r_shortage = source.r_shortage;
      r_max_forecast_delay = source.r_max_forecast_delay;
      r_average_forecast_delay = source.r_average_forecast_delay;
      r_max_punctuality_delay = source.r_max_punctuality_delay;
      r_average_punctuality_delay = source.r_average_punctuality_delay;
      r_punctual_fp = source.r_punctual_fp;
      r_delayed_fp = source.r_delayed_fp;
      r_punctual_porcentage = source.r_punctual_porcentage;
      r_average_forecasted_delay_delayedfps = source.r_average_forecasted_delay_delayedfps;
      r_warningErrors = source.r_warningErrors;
      r_kpis_runways = source.r_kpis_runways;
   }

   return *this;
}



/*void LpdbAbsoluteKPIs::updateMaxAndAverageKPIs(int delayCountThreshold,
                                              const std::map<std::string, LpdbFPSchedule> & scheduledFps,
                                              const std::map<std::string, LpdbFPSchedule> & delayedFpsInLastInterval)
{
   r_max_forecast_delay[E_ARR] = 0.0;
   r_max_forecast_delay[E_DEP] = 0.0;
   r_max_forecast_delay[E_OVA] = 0.0;
   r_average_forecast_delay[E_ARR] = 0;
   r_average_forecast_delay[E_DEP] = 0;
   r_average_forecast_delay[E_OVA] = 0;
   r_max_punctuality_delay[E_ARR] = 0.0;
   r_max_punctuality_delay[E_DEP] = 0.0;
   r_max_punctuality_delay[E_OVA] = 0.0;
   r_average_punctuality_delay[E_ARR] = 0;
   r_average_punctuality_delay[E_DEP] = 0;
   r_average_punctuality_delay[E_OVA] = 0;
   r_punctual_fp[E_ARR] = 0;
   r_punctual_fp[E_DEP] = 0;
   r_punctual_fp[E_OVA] = 0;
   r_delayed_fp[E_ARR] = 0;
   r_delayed_fp[E_DEP] = 0;
   r_delayed_fp[E_OVA] = 0;
   r_punctual_porcentage[E_ARR] = 0;
   r_punctual_porcentage[E_DEP] = 0;
   r_punctual_porcentage[E_OVA] = 0;
   r_average_forecasted_delay_delayedfps.reset();

   int counter = 0;

   LpiADOVector<int> total_delayed_flights = LpiADOVector<int>(0, 0, 0);

   //Use for statistics: accepted FPs + delayed in last interval FPs

   std::map<std::string, LpdbFPSchedule> flightPlansToProcess = scheduledFps;
   flightPlansToProcess.insert(delayedFpsInLastInterval.begin(), delayedFpsInLastInterval.end());

   typedef std::map<std::string, LpdbFPSchedule>::value_type scheduleFPs;

   boost::posix_time::ptime timeLineBase = LpdbDataBase::Get().getTimeLineBase();
   //TODO: Possible improvement: add limit end of window? not necessary for now
   //There won't be scheduled flights with ITOT/ILDT greater than time window

   BOOST_FOREACH(scheduleFPs & fp, flightPlansToProcess)
   {
      //ISE#610
      boost::optional<boost::posix_time::ptime> intentionalTime = fp.second.getIntentionalTime();

      if (intentionalTime &&
          (*intentionalTime >= timeLineBase))
      {
      //End ISE#610
         counter++;

         if(fp.second.getLdForecastedDelay())
         {
             r_max_forecast_delay[E_ARR] = std::max(r_max_forecast_delay[E_ARR], *(fp.second.getLdForecastedDelay()));
             r_average_forecast_delay[E_ARR] += *(fp.second.getLdForecastedDelay());

             //Phase 3
             r_average_forecast_delay[E_OVA] += *(fp.second.getLdForecastedDelay());

             double ldForecastedDelay = *(fp.second.getLdForecastedDelay());
             if (ldForecastedDelay > static_cast<double>(delayCountThreshold))
             {
                r_average_forecasted_delay_delayedfps[E_ARR] += ldForecastedDelay;

                //Phase 3
                r_average_forecasted_delay_delayedfps[E_OVA] += ldForecastedDelay;

                total_delayed_flights[E_ARR]++;
                total_delayed_flights[E_OVA]++;
             }
         }

         if(fp.second.getToForecastedDelay())
         {
             r_max_forecast_delay[E_DEP] = std::max(r_max_forecast_delay[E_DEP], *(fp.second.getToForecastedDelay()));
             r_average_forecast_delay[E_DEP] += *(fp.second.getToForecastedDelay());

             //Phase 3
             r_average_forecast_delay[E_OVA] += *(fp.second.getToForecastedDelay());

             double toForecastedDelay = *(fp.second.getToForecastedDelay());
             if (toForecastedDelay > static_cast<double>(delayCountThreshold))
             {
                r_average_forecasted_delay_delayedfps[E_DEP] += toForecastedDelay;

                //Phase 3
                r_average_forecasted_delay_delayedfps[E_OVA] += toForecastedDelay;

                total_delayed_flights[E_DEP]++;
                total_delayed_flights[E_OVA]++;
             }
         }

         if(fp.second.getLdPunctualityDelay())
         {
            r_max_punctuality_delay[E_ARR] = std::max(r_max_punctuality_delay[E_ARR], *(fp.second.getLdPunctualityDelay()));
            r_average_punctuality_delay[E_ARR] += *(fp.second.getLdPunctualityDelay());
         }

         if(fp.second.getToPunctualityDelay())
         {
            r_max_punctuality_delay[E_DEP] = std::max(r_max_punctuality_delay[E_DEP], *(fp.second.getToPunctualityDelay()));
            r_average_punctuality_delay[E_DEP] += *(fp.second.getToPunctualityDelay());
         }

         if (fp.second.getOperationType() == LpiOperationType::E_ARRIVAL &&
             fp.second.getLdPunctualityDelay() &&
             *(fp.second.getLdPunctualityDelay()) < 15 &&
             *(fp.second.getLdPunctualityDelay()) >= 0 )
         {
             r_punctual_fp[E_ARR]++;
         }

         if(fp.second.getOperationType() == LpiOperationType::E_DEPARTURE &&
            fp.second.getToPunctualityDelay()  &&
           *(fp.second.getToPunctualityDelay()) < 15 &&
           *(fp.second.getToPunctualityDelay()) >= 0 )
         {
             r_punctual_fp[E_DEP]++;
         }
      }
   }

   r_max_forecast_delay[E_OVA] = std::max(r_max_forecast_delay[E_ARR], r_max_forecast_delay[E_DEP]);
   r_max_punctuality_delay[E_OVA] = std::max(r_max_punctuality_delay[E_ARR], r_max_punctuality_delay[E_DEP]);

   if(counter != 0)
   {
      r_average_forecast_delay[E_ARR] = r_average_forecast_delay[E_ARR] / counter;
      r_average_forecast_delay[E_DEP] = r_average_forecast_delay[E_DEP] / counter;

      //Phase 3
      r_average_forecast_delay[E_OVA] = r_average_forecast_delay[E_OVA] / counter;

      r_average_punctuality_delay[E_ARR] = r_average_punctuality_delay[E_ARR] / counter;
      r_average_punctuality_delay[E_DEP] = r_average_punctuality_delay[E_DEP] / counter;
      r_average_punctuality_delay[E_OVA] = (r_average_punctuality_delay[E_ARR] + r_average_punctuality_delay[E_DEP]) / 2.0;
   }

   r_punctual_fp[E_OVA] = r_punctual_fp[E_ARR] + r_punctual_fp[E_DEP];

   LpiADOVector<int> vCounter = LpdbDataBase::Get().getDemand().getTotalDemandForecast();

   if( vCounter[E_ARR] != 0)
   {
      r_punctual_porcentage[E_ARR] = (r_punctual_fp[E_ARR] / vCounter[E_ARR]) * 100;
   }

   if( vCounter[E_DEP] != 0)
   {
      r_punctual_porcentage[E_DEP] = (r_punctual_fp[E_DEP] / vCounter[E_DEP]) * 100;
   }

   if( vCounter[E_OVA] != 0)
   {
      r_punctual_porcentage[E_OVA] = (r_punctual_fp[E_OVA] / vCounter[E_OVA] ) * 100;
   }

   //Phase II
   r_delayed_fp = toDouble(total_delayed_flights);

   r_average_forecasted_delay_delayedfps = r_average_forecasted_delay_delayedfps / toDouble(total_delayed_flights);

   //Phase III
   //r_average_forecasted_delay_delayedfps[E_OVA] = (r_average_forecasted_delay_delayedfps[E_ARR] +
   //                                                r_average_forecasted_delay_delayedfps[E_DEP]) / 2.0;

}*/


void LpdbAbsoluteKPIs::updateShortage(const LpiADOVector<int> &shortage)
{
   r_shortage[E_ARR] += shortage[E_ARR];
   r_shortage[E_DEP] += shortage[E_DEP];
   r_shortage[E_OVA] += shortage[E_OVA];
}


void LpdbAbsoluteKPIs::deleteShortage(const LpiADOVector<int> & shortage)
{
   r_shortage[E_ARR] -= shortage[E_ARR];
   r_shortage[E_DEP] -= shortage[E_DEP];
   r_shortage[E_OVA] -= shortage[E_OVA];
}


void LpdbAbsoluteKPIs::updateTotalRealAccepted(const LpiADOVector<int> &totalRealAccepted)
{
   r_total_real_accepted_fps[E_ARR]+= totalRealAccepted[E_ARR];
   r_total_real_accepted_fps[E_DEP]+= totalRealAccepted[E_DEP];
   r_total_real_accepted_fps[E_OVA]+= totalRealAccepted[E_OVA];
}


void LpdbAbsoluteKPIs::deleteFromTotalRealAccepted(const LpiADOVector<int> & totalRealAccepted)
{
   r_total_real_accepted_fps[E_ARR]-= totalRealAccepted[E_ARR];
   r_total_real_accepted_fps[E_DEP]-= totalRealAccepted[E_DEP];
   r_total_real_accepted_fps[E_OVA]-= totalRealAccepted[E_OVA];
}


/*void LpdbAbsoluteKPIs::updateKPIsRunways(std::map<std::string, LpdbRwyScheduled> runways)
{
   typedef std::map<std::string, LpdbRwyScheduled>::value_type  runways_id;
   BOOST_FOREACH(runways_id & id, runways)
   {
       string id_runway(id.second.getRwyId());
       updateRunwaysTotalAccepted(id_runway, runways[id_runway].getNumberOfAllocatedFps());
       updateRunwaysTotalShortage(id_runway, runways[id_runway].getNumberOfDelayedFps());
   }
}*/


void LpdbAbsoluteKPIs::updateRunwaysTotalAccepted(std::string id_runway,const LpiADOVector<int> & numberOfAllocatedFps)
{

    if(r_kpis_runways.count(id_runway) > 0)
    {
       r_kpis_runways[id_runway].kpis_AllocatedTotal = r_kpis_runways[id_runway].kpis_AllocatedTotal +
                                                       numberOfAllocatedFps;
    }
    else
    {
      r_kpis_runways[id_runway].kpis_AllocatedTotal = numberOfAllocatedFps;
    }
}


void LpdbAbsoluteKPIs::updateRunwaysTotalShortage(std::string id_runway,const LpiADOVector<int> & numberOfDelayedFps)
{

    if(r_kpis_runways.count(id_runway) > 0)
    {
       r_kpis_runways[id_runway].kpis_ShortageTotal = r_kpis_runways[id_runway].kpis_ShortageTotal +
                                                      numberOfDelayedFps;
    }
    else
    {
       r_kpis_runways[id_runway].kpis_ShortageTotal = numberOfDelayedFps;
    }
}


void LpdbAbsoluteKPIs::deleteFromRunwaysTotalAccepted(std::string id_runway,const LpiADOVector<int> & numberOfAllocatedFps)
{
    if(r_kpis_runways.count(id_runway) > 0)
    {
       r_kpis_runways[id_runway].kpis_AllocatedTotal = r_kpis_runways[id_runway].kpis_AllocatedTotal -
                                                       numberOfAllocatedFps;
    }
}


void LpdbAbsoluteKPIs::deleteFromRunwaysTotalShortage(std::string id_runway,const LpiADOVector<int> & numberOfDelayedFps)
{
    if(r_kpis_runways.count(id_runway) > 0)
    {
       r_kpis_runways[id_runway].kpis_ShortageTotal = r_kpis_runways[id_runway].kpis_ShortageTotal -
                                                      numberOfDelayedFps;
    }
}


/*void LpdbAbsoluteKPIs::deleteFromRunwaysKPIs(std::map<std::string, LpdbRwyScheduled> runways)
{
   typedef std::map<std::string, LpdbRwyScheduled>::value_type  runways_id;
   BOOST_FOREACH(runways_id & id, runways)
   {
       string id_runway(id.second.getRwyId());
       deleteFromRunwaysTotalAccepted(id_runway, runways[id_runway].getNumberOfAllocatedFps());
       deleteFromRunwaysTotalShortage(id_runway, runways[id_runway].getNumberOfDelayedFps());
   }
}*/

/*
void LpdbAbsoluteKPIs::generateWarningsAlarms(const LpdbAbsoluteKPIs & absolute, LpiConfigurationAlertKPIs &alertKPIs)
{
   r_warningErrors.setMaxForecastDelayWA(r_warningErrors.Alarm_Warning(1, absolute.getMaxForecastDelay(),
         alertKPIs.getMaxForecastedDelay().getAlarmThreshold(),
         alertKPIs.getMaxForecastedDelay().getWarningThreshold(),
         alertKPIs.getMaxForecastedDelay().getComparison()));

   r_warningErrors.setPunctualPorcentageWA(r_warningErrors.Alarm_Warning(1, absolute.getPunctualPorcentage(),
         alertKPIs.getPunctuality().getAlarmThreshold(),
         alertKPIs.getPunctuality().getWarningThreshold(),
         alertKPIs.getPunctuality().getComparison()));

   //Phase II
   r_warningErrors.setAverageForecastedDelayDelayedFpsWA(r_warningErrors.Alarm_Warning(1, absolute.getAverageForecastedDelay_DelayedFps(),
         alertKPIs.getAverageForecastedDelayDelayedFps().getAlarmThreshold(),
         alertKPIs.getAverageForecastedDelayDelayedFps().getWarningThreshold(),
         alertKPIs.getAverageForecastedDelayDelayedFps().getComparison()));
}
*/

void LpdbAbsoluteKPIs::reset()
{
   r_total_real_accepted_fps.reset();
   r_shortage.reset();
//   r_kpis_runways.clear();
}


std::ostream & operator<<(std::ostream & os, const LpdbAbsoluteKPIs & absoluteKPIs)
{
   os << "ABSOLUTE KPIS: ";

   os << "\n\nTHROUGHPUT KPIs:\n " ;


   os << "\n";
   os << "\nTotal Real Accepted FPs:   ";
   os << absoluteKPIs.getTotalRealAcceptedFps();
   os << "\n";

   os << "\nTotal Shortage:            ";
   os << absoluteKPIs.getShortage() ;
   os << "\n";

   os << "[DELAYS KPIs:\n ";

   os << "\nMax. Forecasted Delay:     " << absoluteKPIs.getMaxForecastDelay();
   os << " | (" << absoluteKPIs.getMaxForecastDelayWA()[E_ARR];
   os << ", " << absoluteKPIs.getMaxForecastDelayWA()[E_DEP];
   os << ", " << absoluteKPIs.getMaxForecastDelayWA()[E_OVA]<< ")";

   os << "\nDelayed flights:           " << absoluteKPIs.getDelayedFP();

   os << "\nAverage Punctuality Delay: " << absoluteKPIs.getAveragePunctualityDelay();

   os << "\nPunctual flights:          " << absoluteKPIs.getPunctualFP();

   os << "\n%Punctuality:              " << absoluteKPIs.getPunctualPorcentage();
   os << " | (" << absoluteKPIs.getPunctualPorcentageWA()[E_ARR];
   os << ", " << absoluteKPIs.getPunctualPorcentageWA()[E_DEP];
   os << ", " << absoluteKPIs.getPunctualPorcentageWA()[E_OVA] << ")]\n";

   os << "\nAverage Punctuality Delay of Delayed FPs: " << absoluteKPIs.getAverageForecastedDelay_DelayedFps();
   os << " | (" << absoluteKPIs.getAverageForecastedDelayDelayedFpsWA()[E_ARR];
   os << ", " << absoluteKPIs.getAverageForecastedDelayDelayedFpsWA()[E_DEP];
   os << ", " << absoluteKPIs.getAverageForecastedDelayDelayedFpsWA()[E_OVA] << ")";

   os << endl;
   return os;
   }




