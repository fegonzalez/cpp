/*
 * LpdbDemand.cc
 *
 *  Created on: 02/01/2014
 *      Author: mbegega
 */


#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <LclogStream.h>
#include "LpdbDemand.h"

#include "LpiFlightPlan.h"

#include <LcuDataTypeUtils.h>

using boost::posix_time::ptime;


LpdbDemand::LpdbDemand()
: r_timeLine(),
  r_demand_forecast_scheduled(),
  r_total_demand_forecast(),
  r_total_vfr()
{
}


LpdbDemand::LpdbDemand(const LpdbDemand & source)
: r_timeLine(source.r_timeLine),
  r_demand_forecast_scheduled(source.r_demand_forecast_scheduled),
  r_total_demand_forecast(source.r_total_demand_forecast),
  r_total_vfr(source.r_total_vfr)
{
}


//void LpdbDemand::init(const LpiTimeParameters & parameters,
//                     boost::posix_time::ptime begin_timestamp)
//{
//   r_timeLine.initialize(parameters.getMinutesSubinterval(),
//                         parameters.getHoursWindow(),
//                         parameters.getMinutesFrozen(),
//                         begin_timestamp
//                         );
//
//   //Populates whole timeline with 0's data ADO Vectors
//   r_timeLine.fill();
//}


LpdbDemand & LpdbDemand::operator= (const LpdbDemand & source)
{
   if (this != &source)
   {
      r_timeLine = source.r_timeLine;
      r_demand_forecast_scheduled = source.r_demand_forecast_scheduled;
      r_total_demand_forecast = source.r_total_demand_forecast;
      r_total_vfr = source.r_total_vfr;
   }

   return *this;
}


bool LpdbDemand::has_data(const string & interval_name)
{
   return r_timeLine.hasData(interval_name);
}


LpdbDemandTimedData & LpdbDemand::operator[] (const string & interval_name)
{
   return r_timeLine[interval_name];
}


void LpdbDemand::forward()
{
   r_timeLine.forward(); ///@bug floating point exception (if minutes intervals == 0)

   //Creates default element in newly created interval
   r_timeLine.createElement(r_timeLine.getLastInterval());
}


vector<LpiADOVector<int> > LpdbDemand::getDemandForecastScheduled() const
{
   return r_demand_forecast_scheduled;
}


void LpdbDemand::setDemandForecastScheduled(
                       vector<LpiADOVector<int> > demandForecastScheduled)
{
   r_demand_forecast_scheduled = demandForecastScheduled;
}


LpiADOVector<int> LpdbDemand::getTotalDemandForecast() const
{
   return r_total_demand_forecast;
}


void LpdbDemand::setTotalDemandForecast(LpiADOVector<int> totalDemandForecast)
{
   r_total_demand_forecast = totalDemandForecast;
}


void LpdbDemand::updateTotalDemandForecast()
{
   r_total_demand_forecast[E_ARR]= 0;
   r_total_demand_forecast[E_DEP]= 0;
   r_total_demand_forecast[E_OVA]= 0;
   vector<string> intervals = getTimeLine().getAllIntervalIds();
  
   BOOST_FOREACH(string ti,intervals)
   {
       r_total_demand_forecast[E_ARR] += r_timeLine[ti].getDemandForecast()[E_ARR];
       r_total_demand_forecast[E_DEP] += r_timeLine[ti].getDemandForecast()[E_DEP];
       r_total_demand_forecast[E_OVA] += r_timeLine[ti].getDemandForecast()[E_OVA];
   }
}


LpiADOVector<double> LpdbDemand::getTotalDemandRatio () const
{
   LpiADOVector<double> total_ratio;

   double accumulated_demand = r_total_demand_forecast[E_ARR] + r_total_demand_forecast[E_DEP];

   if (!LcuDataTypeUtils::double_equals(accumulated_demand,0.0))
   {
      total_ratio[E_ARR] = static_cast<double>(r_total_demand_forecast[E_ARR]) / accumulated_demand;
      total_ratio[E_DEP] = static_cast<double>(r_total_demand_forecast[E_DEP]) / accumulated_demand;
      total_ratio[E_OVA] = static_cast<double>(r_total_demand_forecast[E_OVA]) / accumulated_demand;
   }

   return total_ratio;
}

LpiADOVector<int> LpdbDemand::getTotalDemandVFR () const
{
   return r_total_vfr;
}

void LpdbDemand::setTotalDemandVFR(LpiADOVector<int> totalVFR)
{
   r_total_vfr = totalVFR;
}


void LpdbDemand::incrementDemand (const string & interval_name, int flight_type, int value)
{
   if (r_timeLine.hasData(interval_name))
   {
      r_timeLine[interval_name].incrementDemand(flight_type, value);

      //incrementTotalDemand(value);
   }
}


void LpdbDemand::decrementDemand (const string & interval_name, int flight_type, int value)
{
   if (r_timeLine.hasData(interval_name))
   {
      r_timeLine[interval_name].decrementDemand(flight_type, value);

      //decrementTotalDemand(value);
   }
}


void LpdbDemand::incrementTotalDemand (LpiADOVector<int> value)
{
   r_total_demand_forecast = r_total_demand_forecast + value;
}


void LpdbDemand::decrementTotalDemand (LpiADOVector<int> value)
{
   r_total_demand_forecast = r_total_demand_forecast - value;
}


void LpdbDemand::incrementDemand (int flight_type, int value)
{
   r_total_demand_forecast[flight_type] += value;
}


void LpdbDemand::decrementDemand (int flight_type, int value)
{
   r_total_demand_forecast[flight_type] -= value;
}


bool LpdbDemand::isEmpty () const
{
   return (r_total_demand_forecast[E_ARR] == 0) &&
          (r_total_demand_forecast[E_DEP] == 0) &&
          (r_total_demand_forecast[E_OVA] == 0);
}


void LpdbDemand::deleteFromForecast(const LpiFlightPlan & fp)
{
   boost::optional<ptime> intentionalTime = fp.getIntentionalTime();

   if (intentionalTime)
   {
      boost::optional<std::string> interval = r_timeLine.getInterval(*intentionalTime);

      if ((interval) && (r_timeLine.hasData(*interval)))
      {
         if (fp.getOperationType() == LpiOperationType::E_DEPARTURE)
         {
            r_timeLine[*interval].decrementDemand(E_DEP, 1);
            decrementDemand(E_DEP, 1);
         }
         else if (fp.getOperationType() == LpiOperationType::E_ARRIVAL)
         {
            r_timeLine[*interval].decrementDemand(E_ARR, 1);
            decrementDemand(E_ARR, 1);
         }

         r_timeLine[*interval].decrementDemand(E_OVA, 1);
         decrementDemand(E_OVA, 1);

         r_timeLine[*interval].deleteFPFromForecast(fp);
      }
   }
}

TimeLine<LpdbDemandTimedData> LpdbDemand::getTimeLine() const
{
  return r_timeLine;
}

void LpdbDemand::setTimeLine(const TimeLine<LpdbDemandTimedData> data)
{
  r_timeLine = data;
}



std::ostream& operator<<(std::ostream &os, const LpdbDemand &info)
{
   os << info.getTimeLine();
   return os;
}
