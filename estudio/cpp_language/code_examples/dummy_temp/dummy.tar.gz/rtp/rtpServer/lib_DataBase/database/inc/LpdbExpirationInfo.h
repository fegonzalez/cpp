/*
 * LpdbExpirationInfo.h
 *
 *  Created on: 15/05/2015
 *      Author: mbegega
 *
 *  Expiration date of a What-if, and a boolean to indicate whether or not it must be
 *  deleted N hours after cancellation
 *
 */

#ifndef LPBEXPIRATIONINFO_H_
#define LPBEXPIRATIONINFO_H_

#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>


class LpdbExpirationInfo
{
   public:

      LpdbExpirationInfo();

      LpdbExpirationInfo(bool expired,
                        float hours,
                        bool automaticDeletion,
                        const boost::posix_time::ptime & expirationTime);

      LpdbExpirationInfo(const LpdbExpirationInfo & source);

      virtual ~LpdbExpirationInfo();

      LpdbExpirationInfo & operator= (const LpdbExpirationInfo & source);

      bool isExpired() const;
      void isExpired(bool expired);

      float getExpirationHours() const;
      bool  getAutomaticDeletion() const;

      const boost::posix_time::ptime & getExpirationTime() const;
      boost::posix_time::ptime getCancellationTime() const;

      void setExpirationHours(float expirationHours);
      void setAutomaticDeletion(bool mustDelete);
      void setExpirationDate(const boost::posix_time::ptime & expirationDate);

   protected:

      bool r_isExpired;
      float r_expirationHours;
      bool r_automaticDeletion;
      boost::posix_time::ptime r_expirationTime;
};

std::ostream & operator<<(std::ostream &os, const LpdbExpirationInfo & expirationInfo);

#endif /* LPBRUNWAYCLOSURE_H_ */
