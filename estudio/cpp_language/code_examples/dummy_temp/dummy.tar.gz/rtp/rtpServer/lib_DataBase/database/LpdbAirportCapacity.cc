/*
 * LpdbAirportCapacity.cc
 *
 */

#include "LpdbAirportCapacity.h"
#include <LcmetConstants.h>
#include <LpdbDataBase.h>
#include <LpiADOVector.h>
#include <LpiAdaptationAirportsInfo.h>
#include <LpdbMeteoTimedData.h>
#include <LpdbRunway.h>
#ifdef TRACE_OUT
#include <LclogStream.h>
#endif

#include <iostream>
#include <cmath>
#include <map>
#include <string>
#include <algorithm>    // std::for_each
#include <functional>   // bind
#include <cassert>


#include <boost/date_time/posix_time/posix_time.hpp>

//#include <boost/foreach.hpp>
//#include <boost/lexical_cast.hpp>
//#include <LpiADOstd::vector.h>



LpdbAirportCapacity::LpdbAirportCapacity
(const AirportMaxNominalCapacity &airportMaxNominal,
 const LpiADOVector<unsigned int> &taxywaysMaxNominal,
 const LpiADOVector<unsigned int> &tmaMaxNominal,
 const std::string &airport)
  : the_airport_nominal_capacity(airportMaxNominal.getArrivalsValue(),
                                 airportMaxNominal.getDeparturesValue(),
				 airportMaxNominal.getOverallValue()),
    the_twyNominalCapacity(taxywaysMaxNominal),
    the_tmaNominalCapacity(tmaMaxNominal),
    the_airport(airport)
{
}


bool LpdbAirportCapacity::has_data(const std::string& interval_name)
{
   return the_airport_capacity.hasData(interval_name);
}


LpdbAirportCapacityTimedData& LpdbAirportCapacity::operator []
(const std::string& interval_name)
{
   return the_airport_capacity[interval_name];
}


TimeLine<LpdbAirportCapacityTimedData> LpdbAirportCapacity::getTimeLine() const
{
   return the_airport_capacity;
}


//--------------------------------------------------------------
// INIT EVENT
void LpdbAirportCapacity::init
                          (const LpiTimeParameters & timeData,
                           boost::posix_time::ptime begin_timestamp	,
                           const LpiADOVector<unsigned int> tmaNominalCapacity,
                           const LpiADOVector<unsigned int> twyNominalCapacity)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  the_airport_capacity.initialize(timeData.getMinutesSubinterval(),
				  timeData.getHoursWindow(),
				  timeData.getMinutesFrozen(),
				  begin_timestamp);
  the_airport_capacity.fill();


  the_tma.init(timeData, begin_timestamp, get_tmaNominalCapacity());
  the_twy.init(timeData, begin_timestamp, get_taxywaysNominalCapacity());
}

//--------------------------------------------------------------
// INIT EVENT
//
// (also update meteo & update demand)
//
void LpdbAirportCapacity::calculateMaxCapacity()
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TEST: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  std::vector<std::string> intervals = the_airport_capacity.getAllIntervalIds();
  std::for_each
    (std::begin(intervals), std::end(intervals),
     std::bind(static_cast<void(LpdbAirportCapacity::*)(const std::string&)>
	       (&LpdbAirportCapacity::calculateMaxCapacity), 
	       this, 
	       std::placeholders::_1));
}

//--------------------------------------------------------------

void LpdbAirportCapacity::calculateMaxCapacity(const std::string &interval)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " ; interval: " << interval
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
  
  assert(the_airport_capacity.exists(interval)); 

  LpdbDataBase::AirportTable & airport_table =
    LpdbDataBase::Get().getAirportTable();

  assert(airport_table.exists(getAirportId()));
  if(not airport_table.exists(getAirportId()))
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << "Airport not found (" << getAirportId() << ')'
      << "Capacity calculation aborted for the airport."
      << std::endl;

    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Capacity calculation aborted at"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }
  

  // calculations begin here [1]

  ///@test R_431.1 Calcular capacidad inicial del aeropuerto.
  the_airport_capacity[interval].calculateCapacity
    (the_airport_capacity.getNumberOfElements(),
     the_airport_nominal_capacity);

  LpdbMeteoTimedData meteo_constraints = 
    airport_table[getAirportId()].getMeteoForecast().getElement(interval);
    

  ///@test R_431.2
  calculate_ILS_capacity(airport_table[getAirportId()].getMaxILS(), 
			 meteo_constraints,
			 interval);
    

  /** Per runway data (crosswind, tailwind, horizontal visibility);    
     @test R_431.3 crosswind reduction
     @test R_431.4 tailwind reduction
     @test R_431.5  Horizontal visibility
     @test R_431.6: Apply the most restrictive value (cross, tail, hv).
  */
  assert(has_data(interval));
  double capacity_reduction = 0.0;
  capacity_reduction = calculate_runways_restrictions
                       (airport_table[getAirportId()].getRunways(),
                       meteo_constraints);
  apply_capacity_reduction(capacity_reduction, interval);

 
  /**@warning R: Vortex reductions NOT REQUIRED in RTP project
     (the airports managed in the RTP aren't congested enough to
     care about WTC.
  */


  /**@test R_431.7: Corregir capacidad por restricción meteo activación LVP
    
     IF    (meteoForecastF.LVP_Activation (interval) = YES)
     THEN  
     Capacity (interval) = [0; 0; 0]
  */
  if(meteo_constraints.getLvpActivation().is_initialized())
  {
    if(meteo_constraints.getLvpActivation().get() == true)
    {
      LpiADOVector<unsigned int> airport_capacity_ti = {0, 0, 0};
      the_airport_capacity[interval].setCapacity(airport_capacity_ti);
    }
  }


  /**@test R_431.8 Corregir la capacidad aplicando la reducción de capacidad
  	  más restrictiva en cada una de las restricciones calculadas:

  	  DONE: Due to the way we have made the calculations on each step, here
  	  	    the_airport_capacity[interval].getCapacity() already has computed
  	  	    the most restrictive value.
  */
  
  ///@test R_431.9 Calcular capacidad por restricción "TMA".
  the_tma.calculateCapacity(interval);

  ///@test R_431.10 Calcular capacidad por restricción "Taxyways ".
  the_twy.calculateCapacity(interval);

  /* R_431.11 & R_431.12 <<Ni las capacidades del TMA ni las
     taxyways deberían de ser factores limitantes de la capacidad
     final>> [1], are covered by the values set in the adaptation file [2] [3]:
  */

    
  /**@test R_431.13 : Airport_Capacity (interval) = MIN 
                                                    [Airport_Capacity (interval),
                                                    TMA.Capacity (interval),
                                                    TWY.Capacity (interval)]
  */
  LpiADOVector<unsigned int> max_cap_tma = the_tma[interval].getCapacity();
  LpiADOVector<unsigned int> max_cap_twy = the_twy[interval].getCapacity();
  LpiADOVector<unsigned int> airport_capacity_ti =
    the_airport_capacity[interval].getCapacity();
  airport_capacity_ti[E_ARR] = std::min(std::min(airport_capacity_ti[E_ARR],
						 max_cap_tma[E_ARR]), 
					max_cap_twy[E_ARR]);
  airport_capacity_ti[E_DEP] = std::min(std::min(airport_capacity_ti[E_DEP],
						 max_cap_tma[E_DEP]), 
					max_cap_twy[E_DEP]);
  airport_capacity_ti[E_OVA] = std::min(std::min(airport_capacity_ti[E_OVA],
						 max_cap_tma[E_OVA]), 
					max_cap_twy[E_OVA]);
  the_airport_capacity[interval].setCapacity(airport_capacity_ti);
   
}

//--------------------------------------------------------------
// CLOCK EVENT
void LpdbAirportCapacity::forward()
{
   //Forward timelines of internal objects
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   BOOST_FOREACH (data_pair & data, runways)
//   {
//         LpdbAirportCapacityRunway & rs_rwy = getRunway(data.first);
//         rs_rwy.forwardTimeline();
//   }


   the_tma.forward();
   the_twy.forward();

   the_airport_capacity.forward();
   the_airport_capacity.createElement(the_airport_capacity.getLastInterval());
}

//--------------------------------------------------------------

void LpdbAirportCapacity::forward(const std::string &interval)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " ; interval: " << interval
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

///@todo Replicar RMAN's LrdbRunwaySystem::calculateMaximumCapacity (string interval)
  calculateMaxCapacity(interval);

}


//--------------------------------------------------------------

///@test R_431.2
// IF Max_ILS_Category (interval) < Required_ILS_Category (interval),
// THEN
// Airport_Capacity (interval) = [0; di; oi – ai]
void LpdbAirportCapacity::calculate_ILS_capacity
                          (const Max_ILS_Category & max_ils,
			   const LpdbMeteoTimedData &meteo_constraints,
			   const std::string &interval)
{
  if(meteo_constraints.getIlsCategory().is_initialized())
  {
    if(max_ils < Max_ILS_Category(meteo_constraints.getIlsCategory().get()))
    {
      LpiADOVector<unsigned int> airport_capacity_ti =
	the_airport_capacity[interval].getCapacity();
      airport_capacity_ti[E_OVA] -= airport_capacity_ti[E_ARR];
      airport_capacity_ti[E_ARR] = 0;
      the_airport_capacity[interval].setCapacity(airport_capacity_ti);
    }
  }
}

//--------------------------------------------------------------


/** Per runway data (crosswind, tailwind, horizontal visibility);    

    @test R_431.3 crosswind reduction
    @test R_431.4 tailwind reduction
    @test R_431.5  Horizontal visibility

    @warning rwy adap data is the same for all the intervals

    @warning It has been verified that (due to TimeLine creation
    logic), has_data(interval) is TRUE at initialization time, even
    before any meteo data has been received => the calculation of these
    runway-restrictions must be ignored until any meteo message has
    been received.
*/
double LpdbAirportCapacity::calculate_runways_restrictions
(RunwayTable & rwy_table,
 const LpdbMeteoTimedData &meteo_constraints)
{
  double capacity_reduction = 0.0; //max{crosswind, tailwind, H_V}
  auto meteo_rwy_data = meteo_constraints.getRwyMeteoInfo();

  if(meteo_rwy_data.empty())
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).info()
      << "No meteo data for any runways (expected at system init)"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif	
    return capacity_reduction;
  }

  //element type (it->second): LpiRunwayMeteoInfo
  for (auto meteo_iterator = std::begin(meteo_rwy_data); 
       meteo_iterator != std::end(meteo_rwy_data); 
       ++meteo_iterator)
  {
    
#ifdef TRACE_OUT    
      LclogStream::instance(LclogConfig::E_RTP).debug()
	<< "Runway-meteo-data: " << meteo_iterator->second
	<< " ; File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
#endif	


    /****************************************************************/
    /**@warning Every (adaptation) runway SHOULD also exists in the
       stored meteo information for the pair (airport, interval).
    */
      
    if( rwy_table.exists(meteo_iterator->second.getRwyId()) )
    {
      const LpdbRunway &rwy = rwy_table[meteo_iterator->second.getRwyId()];

      ///@test R_431.3 crosswind reduction    
      capacity_reduction = std::max(capacity_reduction, 
				    calculate_crosswind_reduction
				    (meteo_iterator->second.getCrosswind(),
				     meteo_constraints,
				     rwy));
      ///@test R_431.4 tailwind reduction    
      capacity_reduction = std::max(capacity_reduction, 
				    calculate_tailwind_reduction
				    (meteo_iterator->second.getTailwind(),
				     meteo_constraints,
				     rwy));

      ///@test R_431.5  Horizontal visibility      
      capacity_reduction = std::max(capacity_reduction, 
				    calculate_hv_reduction
				    (meteo_constraints,
				     rwy));
    }
    else
    {
      assert(false); // forcing assert because this error must never had happen.
#ifdef TRACE_OUT    
      LclogStream::instance(LclogConfig::E_RTP).warning()
	<< "Runway << (" << meteo_iterator->second.getRwyId() << ')'
	<< "not found in airports info adaptation file for this airport. "
	<< "Capacity reduction due to crosswind/tailwind/HV ignored"
	<< " : File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
#endif	
    }
    
  } //end-for-RWY

  return capacity_reduction;
}

//--------------------------------------------------------------

 ///@test R_431.3 crosswind reduction
double LpdbAirportCapacity::calculate_crosswind_reduction
    (const double &X, //meteo data
     const LpdbMeteoTimedData &meteo_constraints,
     const LpdbRunway &rwy)
{
  return calculate_wind_reduction(X,
				  meteo_constraints,
				  rwy.getData().getCrosswindLowerThresholdWet(),
				  rwy.getData().getCrosswindUpperThresholdWet(),
				  rwy.getData().getCrosswindLowerThresholdDry(),
				  rwy.getData().getCrosswindUpperThresholdDry(),
				  rwy.getData().getCrosswindMinReduction());
}

//--------------------------------------------------------------

 ///@test R_431.3 tailwind reduction
double LpdbAirportCapacity::calculate_tailwind_reduction
  (const double &X, //meteo data
   const LpdbMeteoTimedData &meteo_constraints,
   const LpdbRunway &rwy)
{
  return calculate_wind_reduction(X,
				  meteo_constraints,
				  rwy.getData().getTailwindLowerThresholdWet(),
				  rwy.getData().getTailwindUpperThresholdWet(),
				  rwy.getData().getTailwindLowerThresholdDry(),
				  rwy.getData().getTailwindUpperThresholdDry(),
				  rwy.getData().getTailwindMinReduction());
}

//--------------------------------------------------------------

 ///@test crosswind/tailwind reduction
double LpdbAirportCapacity::calculate_wind_reduction
  (const double &X, //meteo data
   const LpdbMeteoTimedData &meteo_constraints,
   const unsigned int LowerThresholdWet,
   const unsigned int UpperThresholdWet,
   const unsigned int LowerThresholdDry,
   const unsigned int UpperThresholdDry,
   const double &MR)
{
  double wind_reduction = 0.0;
  double LT = 0.0;
  double UT = 0.0;
  if(meteo_constraints.getWetness().get() == lcmeteo::WETNESS_WET)
  {
    LT = static_cast<double>(LowerThresholdWet);
    UT = static_cast<double>(UpperThresholdWet);
  }
  else
  {
    LT = static_cast<double>(LowerThresholdDry);
    UT = static_cast<double>(UpperThresholdDry);
  }
	      
  if(X < LT)
  {
    wind_reduction = 0.0;
  }
  else if(X > UT)
  {
    wind_reduction = 1.0;
  }
  else
  {
    wind_reduction = ( (MR-1.0)/(LT-UT) * (X-UT) ) + 1.0;
  }

  return wind_reduction;
}
    
//--------------------------------------------------------------

/**@test R_431.5  Horizontal visibility
   @warning Adap file: HV data per runway
   @warning Meteo file: HV data per airport
*/
double LpdbAirportCapacity::calculate_hv_reduction
    (const LpdbMeteoTimedData &meteo_constraints,
    const LpdbRunway &rwy)
{
  double hv_reduction = 0.0;
  if(meteo_constraints.getHorizontalVisibility().is_initialized())
  {
    const double X = meteo_constraints.getHorizontalVisibility().get();
    const double LT = static_cast<double> 
      (rwy.getData().getHorizontalVisibilityLoweThreshold());
    const double UT = static_cast<double> 
      (rwy.getData().getHorizontalVisibilityUpperThreshold());
    const double MR = rwy.getData().getHorizontalMinReduction();
	      
    if(X < LT)
      {
	hv_reduction = 1.0;
      }
    else if(X > UT)
      {
	hv_reduction = 0.0;
      }
    else
      {
	hv_reduction = ( (1.0-MR)/(LT-UT) * (X-LT) ) + 1.0;
      }
  }

  return hv_reduction;
}

//--------------------------------------------------------------

/**@test R_431.6: Apply most restrictive value(cross, tail, hv)
*/
void LpdbAirportCapacity::apply_capacity_reduction
    (const double &capacity_reduction,
     const std::string &interval)
{
  assert(capacity_reduction >= 0.0);
  assert(capacity_reduction <= 1.0);
  //capacity_reduction = fabs(capacity_reduction);

  LpiADOVector<unsigned int> airport_capacity_ti =
    the_airport_capacity[interval].getCapacity();
      
  double double_capacity_value =static_cast<double>(airport_capacity_ti[E_ARR]);
  double_capacity_value *= (1.0 - capacity_reduction);
  airport_capacity_ti[E_ARR] = static_cast <unsigned int>
                               (floor(double_capacity_value));

  double_capacity_value = static_cast<double>(airport_capacity_ti[E_DEP]);
  double_capacity_value *= (1.0 - capacity_reduction);
  airport_capacity_ti[E_DEP] = static_cast <unsigned int>
                               (floor(double_capacity_value));

  double_capacity_value = static_cast<double>(airport_capacity_ti[E_OVA]);
  double_capacity_value *= (1.0 - capacity_reduction);
  airport_capacity_ti[E_OVA] = static_cast <unsigned int>
                               (floor(double_capacity_value));
			
  the_airport_capacity[interval].setCapacity(airport_capacity_ti);
}

//--------------------------------------------------------------


std::ostream& operator<<(std::ostream &out, const LpdbAirportCapacity & rs)
{

   out << "[nominal TMA: " << rs.get_tmaNominalCapacity()
	   << "| nominal TWY: " << rs.get_taxywaysNominalCapacity()
	   << "| tma per interval: " << rs.the_tma
	   << "| taxyway per interval: " << rs.the_twy;
   out << ']' << std::endl;

   return out;
}


//--------------------------------------------------------------
