/*
 * LpdbAirportCapacity.cc
 *
 */

#include "LpdbAirportCapacity.h"
#include <LpdbDataBase.h>
#include <LpiADOVector.h>
#include <LpiAdaptationAirportsInfo.h>
#include <LpdbMeteoTimedData.h>

#include <iostream>
#include <cmath>
#include <map>
#include <string>
#include <algorithm>    // std::for_each
#include <functional>   // bind
#include <cassert>


#include <boost/date_time/posix_time/posix_time.hpp>

//#include <boost/foreach.hpp>
//#include <boost/lexical_cast.hpp>
//#include <LpiADOstd::vector.h>



LpdbAirportCapacity::LpdbAirportCapacity
(const AirportMaxNominalCapacity &airportMaxNominal,
 const LpiADOVector<unsigned int> &taxywaysMaxNominal,
 const LpiADOVector<unsigned int> &tmaMaxNominal,
 const std::string &airport)
  : the_airport_nominal_capacity(airportMaxNominal.getArrivalsValue(),
                                 airportMaxNominal.getDeparturesValue(),
				 airportMaxNominal.getOverallValue()),
    the_twyNominalCapacity(taxywaysMaxNominal),
    the_tmaNominalCapacity(tmaMaxNominal),
    the_airport(airport)
{
}


bool LpdbAirportCapacity::has_data(const std::string& interval_name)
{
   return the_airport_capacity.hasData(interval_name);
}


LpdbAirportCapacityTimedData& LpdbAirportCapacity::operator []
(const std::string& interval_name)
{
   return the_airport_capacity[interval_name];
}


TimeLine<LpdbAirportCapacityTimedData> LpdbAirportCapacity::getTimeLine() const
{
   return the_airport_capacity;
}


//--------------------------------------------------------------
// INIT EVENT
void LpdbAirportCapacity::init
                          (const LpiTimeParameters & timeData,
                           boost::posix_time::ptime begin_timestamp	,
                           const LpiADOVector<unsigned int> tmaNominalCapacity,
                           const LpiADOVector<unsigned int> twyNominalCapacity)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  the_airport_capacity.initialize(timeData.getMinutesSubinterval(),
				  timeData.getHoursWindow(),
				  timeData.getMinutesFrozen(),
				  begin_timestamp);
  the_airport_capacity.fill();


  the_tma.init(timeData, begin_timestamp, get_tmaNominalCapacity());
  the_twy.init(timeData, begin_timestamp, get_taxywaysNominalCapacity());
}

//--------------------------------------------------------------
// INIT EVENT
//
// (also update meteo & update demand)
//
void LpdbAirportCapacity::calculateMaxCapacity()
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  std::vector<std::string> intervals = the_airport_capacity.getAllIntervalIds();
  std::for_each
    (std::begin(intervals), std::end(intervals),
     std::bind(static_cast<void(LpdbAirportCapacity::*)(const std::string&)>
	       (&LpdbAirportCapacity::calculateMaxCapacity), 
	       this, 
	       std::placeholders::_1));
}

//--------------------------------------------------------------

void LpdbAirportCapacity::calculateMaxCapacity(const std::string &interval)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " ; interval: " << interval
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
  
  LpdbDataBase::AirportTable & airport_table =
    LpdbDataBase::Get().getAirportTable();
  assert(airport_table.exists(getAirportId()));
  if(not airport_table.exists(getAirportId()))
  {
    LclogStream::instance(LclogConfig::E_RTP).error()
      << "Airport not found (" << getAirportId() << ')'
      << "Capacity calculation aborted for the airport."
      << std::endl;
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Capacity calculation aborted at"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }
  
      
  assert(the_airport_capacity.exists(interval));
  if (has_data(interval))
  {
    ///@test R_431.1 Calcular capacidad inicial del aeropuerto.
    the_airport_capacity[interval].calculateCapacity
      (the_airport_capacity.getNumberOfElements(),
       the_airport_nominal_capacity);


    LpdbMeteoTimedData meteo_constraints = 
      airport_table[getAirportId()].getMeteoForecast().getElement(interval);
    

    ///@test R_431.2
    // IF Max_ILS_Category (interval) < Required_ILS_Category (interval),
    // THEN
    // Airport_Capacity (interval) = [0; di; oi – ai]
    if(meteo_constraints.getIlsCategory().is_initialized())
    {
      if(airport_table[getAirportId()].getMaxILS() <
	 Max_ILS_Category(meteo_constraints.getIlsCategory().get()))
      {
	LpiADOVector<unsigned int> airport_capacity_ti =
	  the_airport_capacity[interval].getCapacity();
	airport_capacity_ti[E_OVA] -= airport_capacity_ti[E_ARR];
	airport_capacity_ti[E_ARR] = 0;
	the_airport_capacity[interval].setCapacity(airport_capacity_ti);
      }
    }
    

    
    // Per runway data (rwy adap data is the same for all the intervals)

    //LpdbAirportCapacityTimedData capacity_reduction;
    double capacity_reduction = 0.0;

    //adap data
    const LpdbAirport::RunwayTable & rwy_Table =
                                     airport_table[getAirportId()].getRunways();
    std::for_each(std::begin(rwy_Table), std::end(rwy_Table),
		  [this, meteo_constraints, &capacity_reduction]
		  (const LpdbRunway &rwy)
    {

   
      ///@todo R_431.3  //crosswind

      //
      // Para un valor X de la Condición Meteorológica:
      //
      // Si X < Lower_Threshold
      //        capacity_reduction (%) = 0
      //
      // Si Lower_Threshold ≤ X ≤ Upper_Threshold
      //        capacity_reduction (%) = (𝑀𝑅−1) / (𝐿𝑇− 𝑈𝑇) * (𝑋 − 𝑈𝑇) + 1
      //
      // Si X > Upper_Threshold
      //        capacity_reduction (%) = 1


//        if(meteo_constraints.getHorizontalVisibility().is_initialized())
//       {
// 	//meteo data
// 	const double X = meteo_constraints.getHorizontalVisibility().get();
// 	const double LT = static_cast<double> 
// 	(rwy.getData().getHorizontalVisibilityLoweThreshold());
// 	const double UT = static_cast<double> 
// 		  (rwy.getData().getHorizontalVisibilityUpperThreshold());
//         const double MR = rwy.getData().getHorizontalMinReduction();
	      
// 	if(X < LT)
// 	{
// 	  capacity_reduction = 0.0;
// 	}
// 	else if(X > UT)
// 	{
// 	  capacity_reduction = 1.0;
// 	}
// 	else
// 	{
// // ec. para crosswind & tailwind
// 	  // capacity_reduction = ( (MR-1.0)/(LT-UT) * (X-UT) ) + 1.0;
    
// 	}

//       }//end-if-HV
   
      ///@todo R_431.4  //tailwind


	  
      ///@todo R_431.5  Horizontal visibility
      //
      // Para un valor X de la Condición Meteorológica:
      //
      // Si X < Lower_Threshold
      //        capacity_reduction (%) = 1
      //
      // Si Lower_Threshold ≤ X ≤ Upper_Threshold
      //        capacity_reduction (%) = (1-𝑀𝑅) / (𝐿𝑇−𝑈𝑇) * (𝑋 − L𝑇) + 1
      //
      // Si X > Upper_Threshold
      //        capacity_reduction (%) = 0

      if(meteo_constraints.getHorizontalVisibility().is_initialized())
      {
	//meteo data
	const double X = meteo_constraints.getHorizontalVisibility().get();
	const double LT = static_cast<double> 
                        (rwy.getData().getHorizontalVisibilityLoweThreshold());
	const double UT = static_cast<double> 
                        (rwy.getData().getHorizontalVisibilityUpperThreshold());
        const double MR = rwy.getData().getHorizontalMinReduction();
	      
	if(X < LT)
	{
	  capacity_reduction = 1.0;
	}
	else if(X > UT)
	{
	  capacity_reduction = 0.0;
	}
	else
	{
	  capacity_reduction = ( (1.0-MR)/(LT-UT) * (X-LT) ) + 1.0;
	}

      }//end-if-HV
	  
    }); //end-for_each
      


    
    /**@warning R_431.6: Vortex reductions NOT REQUIRED in RTP project
       (the airports managed in the RTP aren't congested enough to
       care about WTC.
     */


    ///@todo R_431.7: Apply the most restrictive value:
    // capacity_reduction (interval) = Max [Crosswind_Capacity_Reduction (interval);
    // 				   Tailwind_Capacity_Reduction (interval);
    // 				   HV_Capacity_Reduction (interval);
    // 				   Vortex_Capacity_Reduction (interval)]

    
    ///@test R_431.8: Corregir capacidad por restricción meteo activación LVP
    //
    // IF    (meteoForecastF.LVP_Activation (interval) = YES)
    // THEN  
    // Capacity (interval) = [0; 0; 0]
    if(meteo_constraints.getLvpActivation().is_initialized())
    {
      if(meteo_constraints.getLvpActivation().get() == true)
      {
	LpiADOVector<unsigned int> airport_capacity_ti = {0, 0, 0};
	the_airport_capacity[interval].setCapacity(airport_capacity_ti);
      }
    }

  
    // R_431.9 Calcular capacidad por restricción "TMA".
    the_tma.calculateCapacity(interval);

    //R_431.10 Calcular capacidad por restricción "Taxyways ".
    the_twy.calculateCapacity(interval);

    /* R_431.11 & R_431.12 <<Ni las capacidades del TMA ni las
       taxyways deberían de ser factores limitantes de la capacidad
       final>> [1], are coverd in the adaptation file [2] [3]:
    */

    
    ///@test R_431.13 : Airport_Capacity (interval) = MIN [Airport_Capacity (interval),
    //                               TMA.Capacity (interval), TWY.Capacity (interval)]
    LpiADOVector<unsigned int> max_cap_tma = the_tma[interval].getCapacity();
    LpiADOVector<unsigned int> max_cap_twy = the_twy[interval].getCapacity();
    LpiADOVector<unsigned int> airport_capacity_ti =
          the_airport_capacity[interval].getCapacity();
    airport_capacity_ti[E_ARR] = std::min(std::min(airport_capacity_ti[E_ARR],
						   max_cap_tma[E_ARR]), 
					           max_cap_twy[E_ARR]);
    airport_capacity_ti[E_DEP] = std::min(std::min(airport_capacity_ti[E_DEP],
						   max_cap_tma[E_DEP]), 
					           max_cap_twy[E_DEP]);
    airport_capacity_ti[E_OVA] = std::min(std::min(airport_capacity_ti[E_OVA],
						   max_cap_tma[E_OVA]), 
					           max_cap_twy[E_OVA]);
    the_airport_capacity[interval].setCapacity(airport_capacity_ti);
  }

}

//--------------------------------------------------------------
// CLOCK EVENT
void LpdbAirportCapacity::forward()
{
   //Forward timelines of internal objects
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   BOOST_FOREACH (data_pair & data, runways)
//   {
//         LpdbAirportCapacityRunway & rs_rwy = getRunway(data.first);
//         rs_rwy.forwardTimeline();
//   }


   the_tma.forward();
   the_twy.forward();

   the_airport_capacity.forward();
   the_airport_capacity.createElement(the_airport_capacity.getLastInterval());
}

//--------------------------------------------------------------

void LpdbAirportCapacity::forward(const std::string &interval)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " ; interval: " << interval
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

///@todo Replicar RMAN's LrdbRunwaySystem::calculateMaximumCapacity (string interval)
  calculateMaxCapacity(interval);

}


//--------------------------------------------------------------


std::ostream& operator<<(std::ostream &out, const LpdbAirportCapacity & rs)
{

   out << "[nominal TMA: " << rs.get_tmaNominalCapacity()
	   << "| nominal TWY: " << rs.get_taxywaysNominalCapacity()
	   << "| tma per interval: " << rs.the_tma
	   << "| taxyway per interval: " << rs.the_twy;
   out << ']' << std::endl;

   return out;
}


//--------------------------------------------------------------



//
//TimeInterval LpdbAirportCapacity::getTimeInterval(const std::string & interval)
//{
//   return the_airport_capacity.getTimeInterval(interval);
//}

//
//std::string LpdbAirportCapacity::getRunwaySystemId() const
//{
//   return r_runwaySystemId;
//}
//
//
//std::string LpdbAirportCapacity::getConfiguration () const
//{
//   return r_configuration;
//}
//
//
//void LpdbAirportCapacity::setConfiguration (std::string configuration)
//{
//   r_configuration = configuration;
//}
//
//
//void LpdbAirportCapacity::setRunwaySystemId(std::string id)
//{
//   r_runwaySystemId = id;
//}
//
//
//void LpdbAirportCapacity::addRunway(const std::string & runway_id, OperationType::Enum use_type)
//{
//   LpdbAirportCapacityRunway rwy(runway_id, use_type);
//
//   r_runways[runway_id] = rwy;
//}
//
//
//void LpdbAirportCapacity::deleteRunway(const std::string & runway_id)
//{
//   if (r_runways.count(runway_id) > 0)
//   {
//      r_runways.erase(runway_id);
//   }
//}
//
//
//int LpdbAirportCapacity::getNumberOfRunways() const
//{
//   return r_runways.size();
//}
//
//
//const std::map<std::string, LpdbAirportCapacityRunway> & LpdbAirportCapacity::getRunways() const
//{
//   return r_runways;
//}
//
//
//LpdbAirportCapacityRunway & LpdbAirportCapacity::getRunway(std::string id_runway)
//{
//   return r_runways[id_runway];
//}
//
//
//std::vector<LpiADOstd::vector<int> > LpdbAirportCapacity::getEstimatedDelayedFpsScheduled() const
//{
//   return r_estimated_delayed_fps_scheduled;
//}
//
//
//void LpdbAirportCapacity::setEstimatedDelayedFpsScheduled(
//      std::vector<LpiADOstd::vector<int> > estimatedDelayedFpsScheduled)
//{
//   r_estimated_delayed_fps_scheduled = estimatedDelayedFpsScheduled;
//}
//
//
//void LpdbAirportCapacity::resetEstimatedDelayedFPs()
//{
//   r_estimated_delayed_fps_scheduled.clear();
//}
//
//
//void LpdbAirportCapacity::addEstimatedDelayedFP (const LpiADOstd::vector<int> & delayed)
//{
//   r_estimated_delayed_fps_scheduled.push_back(delayed);
//}
//
//
//bool LpdbAirportCapacity::isLvpFeasibility() const
//{
//   return r_lvp_feasibility;
//}
//
//
//void LpdbAirportCapacity::setLvpFeasibility(bool lvpFeasibility)
//{
//   r_lvp_feasibility = lvpFeasibility;
//}
//
//
//std::string LpdbAirportCapacity::getIntervalsShortFormat () const
//{
//   return the_airport_capacity.getIntervalsShortFormat();
//}
//
//
//std::string LpdbAirportCapacity::getIntervalsAsstd::string () const
//{
//   return the_airport_capacity.getAsstd::string();
//}
//
//bool LpdbAirportCapacity::hasMixedRunways () const
//{
//   return r_has_mixed_runways;
//}
//
//
//std::vector<std::string> LpdbAirportCapacity::getRunwaysByUse (OperationType::Enum operation) const
//{
//   std::vector<std::string> runway_ids;
//
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type runway_data;
//   BOOST_FOREACH (runway_data & runway, r_runways)
//   {
//      if (runway.second.getUse() == operation)
//      {
//         runway_ids.push_back(runway.first);
//      }
//   }
//
//   return runway_ids;
//}

//
//bool LpdbAirportCapacity::hasRunwaysOfSameUse (const LpdbAirportCapacity & anotherRS,
//                                           OperationType::Enum operation) const
//{
//   std::vector<std::string> ownRunways = getRunwaysByUse(operation);
//   std::vector<std::string> anotherRSRunways = anotherRS.getRunwaysByUse(operation);
//
//   std::sort(ownRunways.begin(), ownRunways.end());
//   std::sort(anotherRSRunways.begin(), anotherRSRunways.end());
//
//   std::vector<std::string> difference;
//
//   std::set_symmetric_difference(ownRunways.begin(), ownRunways.end(),
//                                 anotherRSRunways.begin(), anotherRSRunways.end(),
//                                 back_inserter(difference));
//
//   // Another option: return std::equal(ownRunways.begin(), ownRunways.end(), anotherRSRunways.begin())
//
//   return (difference.size() == 0);
//
//}
//
//
//
////Maximum capacity calculations
//void LpdbAirportCapacity::calculateMaximumCapacity ()
//{
//   calculateRSRunwayMaxCapacity();
//   calculateRunwayDependencies();
//   applyCapacityReductions();
//   combineRunwaysCapacities();
////   calculateTMATaxiwaysReductions();
//}
//
//
//void LpdbAirportCapacity::calculateMaximumCapacity (std::string interval)
//{
//   calculateRSRunwayMaxCapacity(interval);
//
//   calculateRunwayDependencies(interval);
//
//   applyCapacityReductions(interval);
//
//   combineRunwaysCapacities(interval);
//
////   calculateTMATaxiwaysReductions(interval);
//}
//
//
//void LpdbAirportCapacity::calculateRSRunwayMaxCapacity()
//{
//   /*LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
//
//   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   BOOST_FOREACH (std::string interval, intervals)
//   {
//      LpiADOstd::vector<int> rwy_max_cap;
//
//      BOOST_FOREACH (data_pair & data, runways)
//      {
//         LpdbAirportCapacityRunway & rs_rwy = getRunway(data.first);
//
//         if (runwayTable.exists(rs_rwy.getId()) && rs_rwy.has_data(interval))
//         {
//            LpdbRunway runway = runwayTable[rs_rwy.getId()];
//
//            LpiADOstd::vector<int> max_cap = runway[interval].getMaxCapacity();
//            rs_rwy[interval].setMaxCapacity(max_cap);
//         }
//      }
//   }*/
//}
//
//
//void LpdbAirportCapacity::calculateRunwayDependencies()
//{
//   /*LpiRunwayDependencyReductions & reductions = LpdbDataBase::Get().getRunwayDependencyReductions();
//   LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
//
//   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   BOOST_FOREACH (std::string interval, intervals)
//   {
//      BOOST_FOREACH (data_pair & data, runways)
//      {
//         LpdbAirportCapacityRunway & rs_rwy = getRunway(data.first);
//         LpdbRunway & runway = runwayTable[data.first];
//
//         if (rs_rwy.has_data(interval) && runway.has_data(interval))
//         {
//            rs_rwy[interval].setMaxCapacity(runway[interval].getMaxCapacity());
//            LpiADOstd::vector<int> max_capacity = rs_rwy[interval].getMaxCapacity();
//
//
//            LpiDependencyReductionKey key(r_runwaySystemId, data.first);
//
//            if (reductions.count(key) > 0)
//            {
//               LpiADOstd::vector<int> max_cap;
//
//               LpiADOstd::vector<double> reduction = reductions[key];
//
//               rs_rwy[interval].setDependencyCapacityReduction(reduction);
//
//               //Apply reduction
//               double arrivals_capacity = static_cast<double>(max_capacity[E_ARR]) * (1.0 - reduction[E_ARR]);
//
//               max_cap[E_ARR]= static_cast<int>(arrivals_capacity);
//               //max_cap[E_ARR]= static_cast<int>(std::floor(arrivals_capacity));
//
//               double departures_capacity = static_cast<double>(max_capacity[E_DEP]) * (1.0 - reduction[E_DEP]);
//
//               max_cap[E_DEP]= static_cast<int>(departures_capacity);
//
//               //max_cap[E_DEP]= static_cast<int>(std::floor(departures_capacity));
//
//               double overall_capacity = static_cast<double>(max_capacity[E_OVA]) * (1.0 - reduction[E_OVA]);
//
//               max_cap[E_OVA]= static_cast<int>(overall_capacity);
//               //max_cap[E_OVA]= static_cast<int>(std::floor(overall_capacity));
//
//               rs_rwy[interval].setMaxCapacity(max_cap);
//            }
//         }
//      }
//   }*/
//}
//
//
//void LpdbAirportCapacity::applyCapacityReductions()
//{
//	/* RMAN CODE
//  //	//std::cout << "applyCapacityReductions" << std::endl;
//	   bool applyFileReductions = LpdbDataBase::Get().getGlobalParameters().getUseFileCapacityReductions();
//	   bool applyWakeVortexReductions = LpdbDataBase::Get().getGlobalParameters().getUseWakeVortexCapacityReductions();
//	   LpiFileCapacityReductions & reductions = LpdbDataBase::Get().getFileReductions();
//	   LpiWakeVortexCapacityReductions & wtcReductions = LpdbDataBase::Get().getWakeVortexReductions();
//	   LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
//
//	   TimeLine<LpdbMeteoTimedData> & meteo_line = LpdbDataBase::Get().getMeteoForecast();
//	   LpdbDemand & demand = LpdbDataBase::Get().getDemand();
//	   //TimeLine<LpdbDemandTimedData> & demand = LpdbDataBase::Get().getDemandForecast();
//
//	   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();
//
//	   std::vector<std::string> fp_keys = fpTable.getAllIds();
//
//	//   LpiMeteoInfo & meteo_report = LpdbDataBase::Get().getMeteoInfo();
//
//
//	   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//	   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//	   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//	   BOOST_FOREACH (std::string interval, intervals)
//	   {
//	      BOOST_FOREACH (data_pair & data, runways)
//	      {
//	         LpdbAirportCapacityRunway &rwy = getRunway(data.first);
//
//	         if (rwy.has_data(interval))
//	         {
//
//	            LpiADOstd::vector<int> max_cap = rwy[interval].getMaxCapacity();
//	            rwy[interval].setMaxCapacityCalculated(max_cap);
//
//	            //Get Runway Nominal capacity
//	            if (runwayTable.exists(rwy.getId()))
//	            {
//	               LpdbRunway runway = runwayTable[rwy.getId()];
//
//	               LclogStream::instance(LclogConfig::E_RTP).debug() << interval << " [RS: " << getRunwaySystemId() << "] [RWY : "  << data.second.getId() << "]";
//
//	               if (!runway[interval].isNonAvailability())
//	               {
//	                 //LpiADOstd::vector<int> rwy_nominal= runway[interval].getMaxCapacity();
//	                  LpiADOstd::vector<int> rwy_nominal= runway[interval].getMaxCapacityNominalInterval();
//
//
//	                  bool hasMeteoRestrictions = false;
//	                  bool hasDemandRestrictions = false;
//
//	                  LpiADOstd::vector<double> wtc_reduction;
//
//	                  //Get meteo conditions
//
//	                  if (meteo_line.hasData(interval) && applyFileReductions)
//	                  {
//	                     LpdbMeteoTimedData meteo_report = meteo_line[interval];
//
//	                     int wind_speed = 0;
//	                     int wind_direction = 0;
//	                     std::string required_ild_category = "";
//
//	                     if ((meteo_report.getWindSpeed()) && (meteo_report.getWindDirection()) && (meteo_report.getIlsCategory()))
//	                     {
//	                    	 wind_speed = *(meteo_report.getWindSpeed());
//	                    	 wind_direction = *(meteo_report.getWindDirection());
//	                    	 required_ild_category = *(meteo_report.getIlsCategory());
//	                         hasMeteoRestrictions = true;
//	                         LpiMeteoConditions cond1 (wind_speed, wind_direction, required_ild_category);
//	                     }
//	                  }
//
//	                  std::vector<LpiWakeVortexConditions> cond_std::vector_ARR;
//	                  std::vector<LpiWakeVortexConditions> cond_std::vector_DEP;
//	                  std::vector<LpiWakeVortexConditions> cond_std::vector_OVA;
//
//	                  bool exist_next=false;
//
//	                  boost::optional<std::string> next_interval;
//	                  // si hay demanda en el subintervalo actual o en el anterior o en el siguiente
//	                  std::string previous_interval = meteo_line.getPreviousIntervalId(interval);
//
//	                  next_interval = meteo_line.getNextIntervalId(interval);
//	                  if (next_interval)
//	                  {
//	                      std::string y = *next_interval;
//	                      if (!demand[y].isEmpty())
//	                      {
//	                          exist_next=true;
//	                      }
//	                  }
//
//	                  //std::cout << "applyWakeVortexReductions: " << applyWakeVortexReductions << std::endl;
//
//	                  if (((!demand[interval].isEmpty()) || (!demand[previous_interval].isEmpty()) || exist_next) && applyWakeVortexReductions)
//	                  {
//	                	  //std::cout << "Estamos dentro" << std::endl;
//	                     hasDemandRestrictions = true;
//
//	                     TimeInterval previous_time = meteo_line.getTimeInterval(previous_interval);
//	                     ptime ini_time = previous_time.begin;
//
//	                     ptime final_time;
//	                     if (next_interval)
//	                     {
//	                         std::string nxt_interval = *next_interval;
//	                         TimeInterval next_time =meteo_line.getTimeInterval(nxt_interval);
//	                         final_time = next_time.end;
//	                     }
//	                     else
//	                     {
//	                         TimeInterval curr_time = meteo_line.getTimeInterval(interval);
//	                         final_time = curr_time.end;
//	                     }
//
//	                     std::vector<int> counter_std::vector_ARR;
//	                     std::vector<int> counter_std::vector_DEP;
//	                     std::vector<int> counter_std::vector_OVA;
//
//	                     for (unsigned int k = 0; k < 4; k++)
//	                     {
//	                         counter_std::vector_ARR.push_back(0);
//	                         counter_std::vector_DEP.push_back(0);
//	                         counter_std::vector_OVA.push_back(0);
//	                     }
//
//	                     int counter_total_ARR = 0;
//	                     int counter_total_DEP = 0;
//
//	                     for(unsigned int k = 0; k < fp_keys.size(); k++)
//	                      {
//	                           LpiFlightPlan fp = fpTable[fp_keys[k]];
//	                           boost::optional<posix_time::ptime> intentional_time = fp.getIntentionalTime();
//	                           ptime intentional;
//
//	                           if (intentional_time)
//	                           {
//	                               intentional = *intentional_time;
//	                           }
//	                           if (intentional >= ini_time &&
//	                                   intentional <= final_time)
//	                           {
//	                               std::string _wtc = fp.getWtc();
//
//	                               // Se cuentan vuelos de DEPARTURE
//	                               if (fp.getOperationType() == LpiOperationType::E_DEPARTURE)
//	                               {
//	                            	   //std::cout << "DEP" << " -> " << _wtc << std::endl;
//	                                   countFlightsByWtc(_wtc, counter_std::vector_DEP, counter_total_DEP);
//	                               }
//	                               //Se cuentan vuelos de ARRIVAL
//	                               if (fp.getOperationType() == LpiOperationType::E_ARRIVAL)
//	                               {
//	                            	   //std::cout << "ARR" << " -> " << _wtc << std::endl;
//	                                   countFlightsByWtc(_wtc, counter_std::vector_ARR, counter_total_ARR);
//	                               }
//
//	      	                     //std::cout << "counter_total_DEP: " << counter_total_DEP << std::endl;
//	      	                     //std::cout << "counter_total_ARR: " << counter_total_ARR << std::endl;
//	                           }
//	                      }
//
//
//	                     std::vector<float> per_ARR;
//	                     std::vector<float> per_DEP;
//	                     std::vector<float> per_OVA;
//
//	                     for (unsigned int k = 0; k < 4; k++)
//	                     {
//	                         per_ARR.push_back(0);
//	                         per_DEP.push_back(0);
//	                         per_OVA.push_back(0);
//	                     }
//
//	                     if (counter_total_ARR > 0)
//	                     {
//	                         per_ARR = calculatePercentageOfWtc(counter_std::vector_ARR, counter_total_ARR);
//	                     }
//	                     if (counter_total_DEP > 0)
//	                     {
//	                         per_DEP = calculatePercentageOfWtc(counter_std::vector_DEP, counter_total_DEP);
//	                     }
//	                     if (counter_total_ARR > 0 || counter_total_DEP > 0)
//	                     {
//	                         for (unsigned int k = 0; k < 4; k++)
//	                         {
//	                             counter_std::vector_OVA[k] = (counter_std::vector_ARR[k] + counter_std::vector_DEP[k]);
//	                         }
//	                         per_OVA = calculatePercentageOfWtc(counter_std::vector_OVA, counter_total_ARR + counter_total_DEP);
//	                     }
//
//	                     LclogStream::instance(LclogConfig::E_RTP).debug() << "per_LIGHT: [A:" << per_ARR[0] << " |D:" << per_DEP[0] << " |O:" << per_OVA[0] << "]"
//	                                  << "per_MEDIUM: [A:" << per_ARR[1] << " |D:" << per_DEP[1] << " |O:" << per_OVA[1] << "]"
//	                                  << "per_HEAVY: [A:" << per_ARR[2] << " |D:" << per_DEP[2] << " |O:" << per_OVA[2] << "]"
//	                                  << "per_JUMBO: [A:" << per_ARR[3] << " |D:" << per_DEP[3] << " |O:" << per_OVA[3] << "]" << std::endl;
//
//	                     // Calculation of conditions std::vector for each type of FP
//	                     cond_std::vector_ARR = LpdbAirportCapacity::calculateConditionsToApplyReduction(per_ARR, wtcReductions.getReductionsARR());
//	                     cond_std::vector_DEP = LpdbAirportCapacity::calculateConditionsToApplyReduction(per_DEP, wtcReductions.getReductionsDEP());
//	                     cond_std::vector_OVA = LpdbAirportCapacity::calculateConditionsToApplyReduction(per_OVA, wtcReductions.getReductionsOVA());
//	                  }
//
//
//	                 LpiADOstd::vector<double> reduction;
//
//	                 if (hasMeteoRestrictions)
//	                 {
//	                     if ((hasDemandRestrictions) && (applyWakeVortexReductions))
//	                     {
//	                         //Get wtc capacity reductions
//	                         if (cond_std::vector_ARR.size() == 4)
//	                         {
//	                         wtc_reduction[E_ARR] = wtcReductions.getReductionARR(cond_std::vector_ARR);
//	                         }
//	                         if (cond_std::vector_DEP.size() == 4)
//	                         {
//	                         wtc_reduction[E_DEP] = wtcReductions.getReductionDEP(cond_std::vector_DEP);
//	                         }
//	                         if (cond_std::vector_OVA.size() == 4)
//	                         {
//	                         wtc_reduction[E_OVA] = wtcReductions.getReductionOVA(cond_std::vector_OVA);
//	                         }
//	                     }
//	                     //Get file reduction
//	                     LpdbMeteoTimedData meteo_report = meteo_line[interval];
//
//	                     LpiMeteoConditions cond1 (*(meteo_report.getWindSpeed()), *(meteo_report.getWindDirection()),
//	                  		   	   	   	   	   	   *(meteo_report.getIlsCategory()));
//
//	                     reduction = reductions.getReduction(cond1, getRunwaySystemId(), rwy.getId());
//	                 }
//	                 else
//	                 {
//	                     reduction[E_ARR] = 0;
//	                     reduction[E_DEP] = 0;
//	                     reduction[E_OVA] = 0;
//
//	                     if ((hasDemandRestrictions) && (applyWakeVortexReductions))
//	                     {
//	                         //Get wtc capacity reductions
//	                         if (cond_std::vector_ARR.size() == 4)
//	                         {
//	                         wtc_reduction[E_ARR] = wtcReductions.getReductionARR(cond_std::vector_ARR);
//	                         }
//	                         if (cond_std::vector_DEP.size() == 4)
//	                         {
//	                         wtc_reduction[E_DEP] = wtcReductions.getReductionDEP(cond_std::vector_DEP);
//	                         }
//	                         if (cond_std::vector_OVA.size() == 4)
//	                         {
//	                         wtc_reduction[E_OVA] = wtcReductions.getReductionOVA(cond_std::vector_OVA);
//	                         }
//	                     }
//	                  }
//
//	                 //Get dependency capacity reductions
//	                 LpiADOstd::vector<double> dependency_reduction = rwy[interval].getDependencyCapacityReduction();
//	                 //Apply reduction
//	                 double arrivals_capacity = static_cast<double>(rwy_nominal[E_ARR]) * (1.0 - reduction[E_ARR])
//	                                                                        * (1.0 - wtc_reduction[E_ARR])
//	                                                                        * (1.0 - dependency_reduction[E_ARR]);
//	                 double cal_capacity = static_cast<double>(rwy_nominal[E_ARR]) * (1.0 - reduction[E_ARR])
//	                                                                        * (1.0 - dependency_reduction[E_ARR]);
//	                 LclogStream::instance(LclogConfig::E_RTP).debug() << "Nominal ARR: " << rwy_nominal[E_ARR] << " | Calculate: " << cal_capacity << " | con WTC: " << arrivals_capacity << std::endl;
//	                 max_cap[E_ARR]= static_cast<int>(arrivals_capacity);
//
//	                 double departures_capacity = static_cast<double>(rwy_nominal[E_DEP]) * (1.0 - reduction[E_DEP])
//	                                                                           * (1.0 - wtc_reduction[E_DEP])
//	                                                                           * (1.0 - dependency_reduction[E_DEP]);
//	                 max_cap[E_DEP]= static_cast<int>(departures_capacity);
//
//	                 double overall_capacity = static_cast<double>(rwy_nominal[E_OVA]) * (1.0 - reduction[E_OVA])
//	                                                                         * (1.0 - wtc_reduction[E_OVA])
//	                                                                         * (1.0 - dependency_reduction[E_OVA]);
//	                 max_cap[E_OVA]= static_cast<int>(overall_capacity);
//
//	                 rwy[interval].setFileCapacityReduction(reduction);
//	                 rwy[interval].setWakeVortexCapacityReduction(wtc_reduction);
//	                 rwy[interval].setMaxCapacity(max_cap);
//	             }
//	               LclogStream::instance(LclogConfig::E_RTP).debug() << rwy[interval] << std::endl;
//	          }
//	       }
//	    }
//	  }
//
//*/
//}
//
//
//
//
//void LpdbAirportCapacity::combineRunwaysCapacities()
//{
//   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   BOOST_FOREACH (std::string interval, intervals)
//   {
//      LpiADOstd::vector<int> rs_max_cap;
//
//      //bool is_valid_rs = true;
//
//      BOOST_FOREACH (data_pair & data, runways)
//      {
//         LpdbAirportCapacityRunway & rwy = getRunway(data.first);
//
//         if (rwy.has_data(interval))
//         {
//            LpiADOstd::vector<int> rwy_max_cap = rwy[interval].getMaxCapacity();
///*
//            for (int i = E_ARR ; i <= E_OVA; i++)
//            {
//               if (rwy_max_cap[i] == 0)
//               {
//                  is_valid_rs = false;
//               }
//            }
//*/
//            switch (rwy.getUse())
//            {
//               case OperationType::E_ARRIVALS:
//
//                  rs_max_cap[E_ARR] += rwy_max_cap[E_ARR];
//                  rs_max_cap[E_OVA] += rwy_max_cap[E_ARR];
//               break;
//
//               case OperationType::E_DEPARTURES:
//
//                  rs_max_cap[E_DEP] += rwy_max_cap[E_DEP];
//                  rs_max_cap[E_OVA] += rwy_max_cap[E_DEP];
//               break;
//
//               case OperationType::E_MIXED:
//
//                  rs_max_cap[E_ARR] += rwy_max_cap[E_ARR];
//                  rs_max_cap[E_DEP] += rwy_max_cap[E_DEP];
//                  rs_max_cap[E_OVA] += rwy_max_cap[E_OVA];
//               break;
//
//               case OperationType::E_INVALID_RWY_OPERATION_TYPE:
//               break;
//            }
//
//         }
//      }
//
//      the_airport_capacity[interval].setMaxCapacity(rs_max_cap);
///*
//      if (is_valid_rs)
//      {
//         the_airport_capacity[interval].setMaxCapacity(rs_max_cap);
//      }
//      else
//      {
//         LpiADOstd::vector<int> reduced_capacity(0, 0, 0);
//         the_airport_capacity[interval].setMaxCapacity(reduced_capacity);
//      }
//*/
//   }
//}
//
//
///*void LpdbAirportCapacity::applyMeteoReductions()
//{
//   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//   TimeLine<LpdbMeteoTimedData> & meteo_forecast = LpdbDataBase::Get().getMeteoForecast();
//
//   BOOST_FOREACH (std::string interval, intervals)
//   {
//      if (the_airport_capacity.hasData(interval) && meteo_forecast.hasData(interval))
//      {
//         bool LVP_Activation = false;
//         boost::optional<bool> has_lvp_activation = meteo_forecast[interval].getLvpActivation();
//         if (has_lvp_activation)
//         {
//            LVP_Activation = *has_lvp_activation;
//         }
//
//         LpiADOstd::vector<int> max_cap (0,0,0);
//
//         if (LVP_Activation && !r_lvp_feasibility)
//         {
//            the_airport_capacity[interval].setMaxCapacity(max_cap);
//         }
//      }
//   }
//}
//
//
//void LpdbAirportCapacity::calculateTMATaxiwaysReductions()
//{
//   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//   LpdbTMA & tmaReductions = LpdbDataBase::Get().getTMA();
//   LpdbTWY & twyReductions = LpdbDataBase::Get().getTWY();
//
//   BOOST_FOREACH (std::string interval, intervals)
//   {
//      if (the_airport_capacity.hasData(interval))
//      {
//         LpiADOstd::vector<int> reduced_cap;
//
//         LpiADOstd::vector<int>    max_cap = the_airport_capacity[interval].getMaxCapacity();
//         the_airport_capacity[interval].setRwysMaxCapacity(max_cap);
//
//         LpiADOstd::vector<int>    max_rs_cap = the_airport_capacity[interval].getRwysMaxCapacity();
//         LpiADOstd::vector<double> max_cap_tma = tmaReductions[interval].getCapacity();
//         LpiADOstd::vector<double> max_cap_twy = twyReductions[interval].getCapacity();
//
//         for (int i = E_ARR ; i <= E_OVA ; ++i)
//         {
//            double min_value = max_rs_cap[i];
//
//            if (max_cap_tma[i] >= 0.0)
//            {
//               min_value = std::min(static_cast<double>(max_rs_cap[i]), max_cap_tma[i]);
//            }
//
//            if (max_cap_twy[i] >= 0.0)
//            {
//                min_value = std::min(min_value, max_cap_twy[i]);
//            }
//
//            reduced_cap[i] = static_cast<int>(std::floor(min_value));
//         }
//
//         the_airport_capacity[interval].setMaxCapacity(reduced_cap);
//      }
//   }
//}
//
//
//
//
//void LpdbAirportCapacity::calculateTMATaxiwaysReductions(std::string interval)
//{
//   LpdbTMA & tmaReductions = LpdbDataBase::Get().getTMA();
//   LpdbTWY & twyReductions = LpdbDataBase::Get().getTWY();
//
//   if (the_airport_capacity.hasData(interval))
//   {
//      LpiADOstd::vector<int> reduced_cap;
//
//      LpiADOstd::vector<int>    max_cap = the_airport_capacity[interval].getMaxCapacity();
//      the_airport_capacity[interval].setRwysMaxCapacity(max_cap);
//
//      LpiADOstd::vector<int>    max_rs_cap = the_airport_capacity[interval].getRwysMaxCapacity();
//      LpiADOstd::vector<double> max_cap_tma = tmaReductions[interval].getCapacity();
//      LpiADOstd::vector<double> max_cap_twy = twyReductions[interval].getCapacity();
//
//      for (int i = E_ARR ; i <= E_OVA ; i++)
//      {
//         double min_value = max_rs_cap[i];
//
//         if (max_cap_tma[i] >= 0.0)
//         {
//            min_value = std::min(static_cast<double>(max_rs_cap[i]), max_cap_tma[i]);
//         }
//
//         if (max_cap_twy[i] >= 0.0)
//         {
//            min_value = std::min(min_value, max_cap_twy[i]);
//         }
//
//         reduced_cap[i] = static_cast<int>(std::floor(min_value));
//      }
//
//      the_airport_capacity[interval].setMaxCapacity(reduced_cap);
//   }
//}
//*/
//
//
//void LpdbAirportCapacity::calculateRSRunwayMaxCapacity(std::string interval)
//{
//   /*LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
//
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   LpiADOstd::vector<int> rwy_max_cap;
//
//   BOOST_FOREACH (data_pair & data, runways)
//   {
//      LpdbAirportCapacityRunway & rs_rwy = getRunway(data.first);
//
//      if (runwayTable.exists(rs_rwy.getId()) && rs_rwy.has_data(interval))
//      {
//         LpdbRunway runway = runwayTable[rs_rwy.getId()];
//
//         LpiADOstd::vector<int> max_cap = runway[interval].getMaxCapacity();
//         rs_rwy[interval].setMaxCapacity(max_cap);
//      }
//   }*/
//}
//
//
//void LpdbAirportCapacity::calculateRunwayDependencies(std::string interval)
//{
//   /*LpiRunwayDependencyReductions & reductions = LpdbDataBase::Get().getRunwayDependencyReductions();
//   LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
//
//   std::vector<std::string> intervals = getTimeLine().getAllIntervalIds();
//
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   BOOST_FOREACH (data_pair & data, runways)
//   {
//         LpdbAirportCapacityRunway & rs_rwy = getRunway(data.first);
//         LpdbRunway & runway = runwayTable[data.first];
//
//         if (rs_rwy.has_data(interval) && runway.has_data(interval))
//         {
//            rs_rwy[interval].setMaxCapacity(runway[interval].getMaxCapacity());
//            LpiADOstd::vector<int> max_capacity = rs_rwy[interval].getMaxCapacity();
//
//            LpiDependencyReductionKey key(r_runwaySystemId, data.first);
//
//            if (reductions.count(key) > 0)
//            {
//               LpiADOstd::vector<int> max_cap;
//
//               LpiADOstd::vector<double> reduction = reductions[key];
//
//               rs_rwy[interval].setDependencyCapacityReduction(reduction);
//
//               //Apply reduction
//               double arrivals_capacity = static_cast<double>(max_capacity[E_ARR]) * (1.0 - reduction[E_ARR]);
//
//               max_cap[E_ARR]= static_cast<int>(arrivals_capacity);
//
//               double departures_capacity = static_cast<double>(max_capacity[E_DEP]) * (1.0 - reduction[E_DEP]);
//
//               max_cap[E_DEP]= static_cast<int>(departures_capacity);
//
//               double overall_capacity = static_cast<double>(max_capacity[E_OVA]) * (1.0 - reduction[E_OVA]);
//
//               max_cap[E_OVA]= static_cast<int>(overall_capacity);
//
//               rs_rwy[interval].setMaxCapacity(max_cap);
//            }
//         }
//   }*/
//}
//
//
//void LpdbAirportCapacity::applyCapacityReductions(std::string interval)
//{
//	/* RMAN CODE
//
//	   bool applyFileReductions = LpdbDataBase::Get().getGlobalParameters().getUseFileCapacityReductions();
//	   bool applyWakeVortexReductions = LpdbDataBase::Get().getGlobalParameters().getUseWakeVortexCapacityReductions();
//	   LpiFileCapacityReductions & reductions = LpdbDataBase::Get().getFileReductions();
//	   LpiWakeVortexCapacityReductions & wtcReductions = LpdbDataBase::Get().getWakeVortexReductions();
//	   LpdbDataBase::RunwayTable & runwayTable = LpdbDataBase::Get().getRunwayTable();
//
//	   TimeLine<LpdbMeteoTimedData> & meteo_line = LpdbDataBase::Get().getMeteoForecast();
//	   LpdbDemand & demand = LpdbDataBase::Get().getDemand();
//	   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();
//
//	   std::vector<std::string> fp_keys = fpTable.getAllIds();
//
//
//	      typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//	      const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//	      BOOST_FOREACH (data_pair & data, runways)
//	      {
//	          LpdbAirportCapacityRunway &rwy = getRunway(data.first);
//
//	          if (rwy.has_data(interval))
//	          {
//
//	              LpiADOstd::vector<int> max_cap = rwy[interval].getMaxCapacity();
//	              rwy[interval].setMaxCapacityCalculated(max_cap);
//
//	              //Get Runway Nominal capacity
//	              if (runwayTable.exists(rwy.getId()))
//	              {
//	                 LpdbRunway runway = runwayTable[rwy.getId()];
//
//	                 LclogStream::instance(LclogConfig::E_RTP).debug() << interval << " [RS: " << getRunwaySystemId() << "] [RWY : "  << data.second.getId() << "]" << std::endl;
//
//	                 if (!runway[interval].isNonAvailability())
//	                 {
//	                     //LpiADOstd::vector<int> rwy_nominal= runway[interval].getMaxCapacity();
//	                     LpiADOstd::vector<int> rwy_nominal= runway[interval].getMaxCapacityNominalInterval();
//
//
//	                     bool hasMeteoRestrictions = false;
//	                     bool hasDemandRestrictions = false;
//
//	                     LpiADOstd::vector<double> wtc_reduction;
//
//	                     //Get meteo conditions
//
//	                     if (meteo_line.hasData(interval) && applyFileReductions)
//	                     {
//	                        LpdbMeteoTimedData meteo_report = meteo_line[interval];
//
//	                        if ((meteo_report.getWindSpeed()) && (meteo_report.getWindDirection()) && (meteo_report.getIlsCategory()))
//	                        {
//	                            hasMeteoRestrictions = true;
//	                        }
//	                     }
//
//	                     std::vector<LpiWakeVortexConditions> cond_std::vector_ARR;
//	                     std::vector<LpiWakeVortexConditions> cond_std::vector_DEP;
//	                     std::vector<LpiWakeVortexConditions> cond_std::vector_OVA;
//
//	                     bool exist_next=false;
//
//	                     boost::optional<std::string> next_interval;
//	                     // si hay demanda en el subintervalo actual o en el anterior o en el siguiente
//	                     std::string previous_interval = meteo_line.getPreviousIntervalId(interval);
//
//	                     next_interval = meteo_line.getNextIntervalId(interval);
//	                     if (next_interval)
//	                     {
//	                         std::string y = *next_interval;
//	                         if (!demand[y].isEmpty())
//	                         {
//	                             exist_next=true;
//	                         }
//	                     }
//
//	                     if (((!demand[interval].isEmpty()) || (!demand[previous_interval].isEmpty()) || exist_next) && applyWakeVortexReductions)
//	                     {
//	                        hasDemandRestrictions = true;
//
//
//	                        ptime final_time;
//	                        if (next_interval)
//	                        {
//	                            std::string nxt_interval = *next_interval;
//	                            TimeInterval next_time =meteo_line.getTimeInterval(nxt_interval);
//	                            final_time = next_time.end;
//	                        }
//	                        else
//	                        {
//	                            TimeInterval curr_time = meteo_line.getTimeInterval(interval);
//	                            final_time = curr_time.end;
//	                        }
//
//	                        std::vector<LpiWakeVortexConditions> cond_std::vector_ARR;
//	                        std::vector<LpiWakeVortexConditions> cond_std::vector_DEP;
//	                        std::vector<LpiWakeVortexConditions> cond_std::vector_OVA;
//
//	                        bool exist_next=false;
//
//	                        boost::optional<std::string> next_interval;
//	                        // si hay demanda en el subintervalo actual o en el anterior o en el siguiente
//	                        std::string previous_interval = meteo_line.getPreviousIntervalId(interval);
//
//	                        next_interval = meteo_line.getNextIntervalId(interval);
//	                        if (next_interval)
//	                        {
//	                            std::string y = *next_interval;
//	                            if (!demand[y].isEmpty())
//	                            {
//	                                exist_next=true;
//	                            }
//	                        }
//
//	                        if (((!demand[interval].isEmpty()) || (!demand[previous_interval].isEmpty()) || exist_next) && applyWakeVortexReductions)
//	                        {
//	                           hasDemandRestrictions = true;
//
//	                           TimeInterval previous_time = meteo_line.getTimeInterval(previous_interval);
//	                           ptime ini_time = previous_time.begin;
//
//	                           ptime final_time;
//	                           if (next_interval)
//	                           {
//	                               std::string nxt_interval = *next_interval;
//	                               TimeInterval next_time =meteo_line.getTimeInterval(nxt_interval);
//	                               final_time = next_time.end;
//	                           }
//	                           else
//	                           {
//	                               TimeInterval curr_time = meteo_line.getTimeInterval(interval);
//	                               final_time = curr_time.end;
//	                           }
//
//	                           std::vector<int> counter_std::vector_ARR;
//	                           std::vector<int> counter_std::vector_DEP;
//	                           std::vector<int> counter_std::vector_OVA;
//
//	                           for (unsigned int k = 0; k < 4; k++)
//	                           {
//	                               counter_std::vector_ARR.push_back(0);
//	                               counter_std::vector_DEP.push_back(0);
//	                               counter_std::vector_OVA.push_back(0);
//	                           }
//
//	                           int counter_total_ARR = 0;
//	                           int counter_total_DEP = 0;
//
//	                           for(unsigned int k = 0; k < fp_keys.size(); k++)
//	                           {
//	                               LpiFlightPlan fp = fpTable[fp_keys[k]];
//	                               boost::optional<posix_time::ptime> intentional_time = fp.getIntentionalTime();
//	                               ptime intentional;
//
//	                               if (intentional_time)
//	                               {
//	                                   intentional = *intentional_time;
//	                               }
//	                               if (intentional >= ini_time &&
//	                                   intentional <= final_time)
//	                               {
//	                                   std::string _wtc = fp.getWtc();
//
//	                                   // Se cuentan vuelos de DEPARTURE
//	                                   if (fp.getOperationType() == LpiOperationType::E_DEPARTURE)
//	                                   {
//	                                       countFlightsByWtc(_wtc, counter_std::vector_DEP, counter_total_DEP);
//	                                   }
//	                                   //Se cuentan vuelos de ARRIVAL
//	                                   if (fp.getOperationType() == LpiOperationType::E_ARRIVAL)
//	                                   {
//	                                       countFlightsByWtc(_wtc, counter_std::vector_ARR, counter_total_ARR);
//	                                   }
//	                               }
//	                           }
//
//	                           std::vector<float> per_ARR;
//	                           std::vector<float> per_DEP;
//	                           std::vector<float> per_OVA;
//
//	                           for (unsigned int k = 0; k < 4; k++)
//	                           {
//	                               per_ARR.push_back(0);
//	                               per_DEP.push_back(0);
//	                               per_OVA.push_back(0);
//	                           }
//
//	                           if (counter_total_ARR > 0)
//	                           {
//	                               per_ARR = calculatePercentageOfWtc(counter_std::vector_ARR, counter_total_ARR);
//	                           }
//	                           if (counter_total_DEP > 0)
//	                           {
//	                               per_DEP = calculatePercentageOfWtc(counter_std::vector_DEP, counter_total_DEP);
//	                           }
//	                           if (counter_total_ARR > 0 || counter_total_DEP > 0)
//	                           {
//	                               for (unsigned int k = 0; k < 4; k++)
//	                               {
//	                                   counter_std::vector_OVA[k] = (counter_std::vector_ARR[k] + counter_std::vector_DEP[k]);
//	                               }
//	                               per_OVA = calculatePercentageOfWtc(counter_std::vector_OVA, counter_total_ARR + counter_total_DEP);
//	                           }
//
//	                           LclogStream::instance(LclogConfig::E_RTP).debug() << "per_LIGHT: [A:" << per_ARR[0] << " |D:" << per_DEP[0] << " |O:" << per_OVA[0] << "]"
//	                                       << "per_MEDIUM: [A:" << per_ARR[1] << " |D:" << per_DEP[1] << " |O:" << per_OVA[1] << "]"
//	                                        << "per_HEAVY: [A:" << per_ARR[2] << " |D:" << per_DEP[2] << " |O:" << per_OVA[2] << "]"
//	                                        << "per_JUMBO: [A:" << per_ARR[3] << " |D:" << per_DEP[3] << " |O:" << per_OVA[3] << "]" << std::endl;
//
//	                           // Calculation of conditions std::vector for each type of FP
//	                           cond_std::vector_ARR = LpdbAirportCapacity::calculateConditionsToApplyReduction(per_ARR, wtcReductions.getReductionsARR());
//	                           cond_std::vector_DEP = LpdbAirportCapacity::calculateConditionsToApplyReduction(per_DEP, wtcReductions.getReductionsDEP());
//	                           cond_std::vector_OVA = LpdbAirportCapacity::calculateConditionsToApplyReduction(per_OVA, wtcReductions.getReductionsOVA());
//	                       }
//
//
//	                       LpiADOstd::vector<double> reduction;
//
//	                       if (hasMeteoRestrictions)
//	                       {
//	                           if ((hasDemandRestrictions) && (applyWakeVortexReductions))
//	                           {
//	                               //Get wtc capacity reductions
//	                               if (cond_std::vector_ARR.size() == 4)
//	                               {
//	                                   wtc_reduction[E_ARR] = wtcReductions.getReductionARR(cond_std::vector_ARR);
//	                               }
//	                               if (cond_std::vector_DEP.size() == 4)
//	                               {
//	                                   wtc_reduction[E_DEP] = wtcReductions.getReductionDEP(cond_std::vector_DEP);
//	                               }
//	                               if (cond_std::vector_OVA.size() == 4)
//	                               {
//	                                   wtc_reduction[E_OVA] = wtcReductions.getReductionOVA(cond_std::vector_OVA);
//	                               }
//	                           }
//	                           //Get file reduction
//	                           LpdbMeteoTimedData meteo_report = meteo_line[interval];
//
//	                           LpiMeteoConditions cond1 (*(meteo_report.getWindSpeed()), *(meteo_report.getWindDirection()),
//	                        		   	   	   	   	   	   *(meteo_report.getIlsCategory()));
//
//	                           reduction = reductions.getReduction(cond1, getRunwaySystemId(), rwy.getId());
//	                       }
//	                       else
//	                       {
//	                           reduction[E_ARR] = 0;
//	                           reduction[E_DEP] = 0;
//	                           reduction[E_OVA] = 0;
//
//	                           if ((hasDemandRestrictions) && (applyWakeVortexReductions))
//	                           {
//	                               //Get wtc capacity reductions
//	                               if (cond_std::vector_ARR.size() == 4)
//	                               {
//	                                   wtc_reduction[E_ARR] = wtcReductions.getReductionARR(cond_std::vector_ARR);
//	                               }
//	                               if (cond_std::vector_DEP.size() == 4)
//	                               {
//	                                   wtc_reduction[E_DEP] = wtcReductions.getReductionDEP(cond_std::vector_DEP);
//	                               }
//	                               if (cond_std::vector_OVA.size() == 4)
//	                               {
//	                                   wtc_reduction[E_OVA] = wtcReductions.getReductionOVA(cond_std::vector_OVA);
//	                               }
//	                           }
//	                       }
//
//	                       //Get dependency capacity reductions
//	                       LpiADOstd::vector<double> dependency_reduction = rwy[interval].getDependencyCapacityReduction();
//	                       //Apply reduction
//	                       double arrivals_capacity = static_cast<double>(rwy_nominal[E_ARR]) * (1.0 - reduction[E_ARR])
//	                                                                                      * (1.0 - wtc_reduction[E_ARR])
//	                                                                              * (1.0 - dependency_reduction[E_ARR]);
//	                       max_cap[E_ARR]= static_cast<int>(arrivals_capacity);
//
//	                       double departures_capacity = static_cast<double>(rwy_nominal[E_DEP]) * (1.0 - reduction[E_DEP])
//	                                                                                        * (1.0 - wtc_reduction[E_DEP])
//	                                                                                * (1.0 - dependency_reduction[E_DEP]);
//
//	                       max_cap[E_DEP]= static_cast<int>(departures_capacity);
//
//	                       double overall_capacity = static_cast<double>(rwy_nominal[E_OVA]) * (1.0 - reduction[E_OVA])
//	                                                                                     * (1.0 - wtc_reduction[E_OVA])
//	                                                                             * (1.0 - dependency_reduction[E_OVA]);
//
//	                       max_cap[E_OVA]= static_cast<int>(overall_capacity);
//
//	                       rwy[interval].setFileCapacityReduction(reduction);
//	                       rwy[interval].setWakeVortexCapacityReduction(wtc_reduction);
//	                       rwy[interval].setMaxCapacity(max_cap);
//	                   }
//	                   LclogStream::instance(LclogConfig::E_RTP).debug() << rwy[interval] << std::endl;
//	                }
//	            }
//	        }
//	    }
//*/
//}
//
//
//
//void LpdbAirportCapacity::combineRunwaysCapacities(std::string interval)
//{
//   typedef const std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//   const std::map<std::string, LpdbAirportCapacityRunway> & runways = getRunways();
//
//   LpiADOstd::vector<int> rs_max_cap;
//
//   //bool is_valid_rs = true;
//
//   BOOST_FOREACH (data_pair & data, runways)
//   {
//      LpdbAirportCapacityRunway & rwy = getRunway(data.first);
//
//      if (rwy.has_data(interval))
//      {
//         LpiADOstd::vector<int> rwy_max_cap = rwy[interval].getMaxCapacity();
//
//         switch (rwy.getUse())
//         {
//            case OperationType::E_ARRIVALS:
//
//               rs_max_cap[E_ARR] += rwy_max_cap[E_ARR];
//               rs_max_cap[E_OVA] += rwy_max_cap[E_ARR];
//            break;
//
//            case OperationType::E_DEPARTURES:
//
//               rs_max_cap[E_DEP] += rwy_max_cap[E_DEP];
//               rs_max_cap[E_OVA] += rwy_max_cap[E_DEP];
//            break;
//
//            case OperationType::E_MIXED:
//
//               rs_max_cap[E_ARR] += rwy_max_cap[E_ARR];
//               rs_max_cap[E_DEP] += rwy_max_cap[E_DEP];
//               rs_max_cap[E_OVA] += rwy_max_cap[E_OVA];
//            break;
//
//            case OperationType::E_INVALID_RWY_OPERATION_TYPE:
//            break;
//         }
//      }
//   }
//
//   the_airport_capacity[interval].setMaxCapacity(rs_max_cap);
//}
//
//
//LpiRunwaySystemUse::LpiEnum LpdbAirportCapacity::getUse () const
//{
//   return r_use;
//}
//
//
//void LpdbAirportCapacity::setUse (LpiRunwaySystemUse::LpiEnum use)
//{
//   r_use = use;
//}
//
//
//int LpdbAirportCapacity::getNumberOfArrivalRunways() const
//{
//   return r_number_of_arrival_runways;
//}
//
//
//int LpdbAirportCapacity::getNumberOfDepartureRunways() const
//{
//   return r_number_of_departure_runways;
//}
//
//
//std::map<std::string, int> LpdbAirportCapacity::getAvailableRunwaysAndCapacities (OperationType::Enum use_type, std::string interval)
//{
//   std::map<std::string, int> result;
//
//   if (has_data(interval))
//   {
//      typedef std::map<std::string, LpdbAirportCapacityRunway>::value_type data_pair;
//
//      BOOST_FOREACH (data_pair & data, r_runways)
//      {
//         if (data.second.has_data(interval))
//         {
//            OperationType::Enum use = data.second.getUse();
//            LpiADOstd::vector<int> rwy_capacity = data.second[interval].getMaxCapacity();
//
//            int index = E_ARR;
//            switch (use)
//            {
//               case OperationType::E_ARRIVALS:
//                  index = E_ARR;
//                  break;
//
//               case OperationType::E_DEPARTURES:
//                  index = E_DEP;
//                  break;
//
//               default:
//                  break;
//            }
//            int capacity = rwy_capacity[index];
//
//            if (use == use_type)
//            {
//               result[data.first] = capacity;
//            }
//         }
//      }
//   }
//   return result;
//}
//
//


//
//
//
//std::vector<LpiWakeVortexConditions> LpdbAirportCapacity::calculateConditionsToApplyReduction(
//                                std::vector<float> calculated_percentage,
//                                std::vector<LpiWTCReduction> reductions_list)
//{
//    std::vector<LpiWakeVortexConditions> conditions_calculated;
//
//    for (unsigned int i=0; i < reductions_list.size(); i++)
//    {
//        std::vector<LpiWakeVortexConditions> conditions = reductions_list[i].getWakeVortexConditions();
//        std::vector<LpiWakeVortexConditions> aux_std::vector;
//        for (unsigned int j=0; j < conditions.size(); j++)
//        {
//            if ((conditions[j].getWtcType() == "L") && (conditions[j].getMaxValue() >= calculated_percentage[0]) && (conditions[j].getMinValue() <= calculated_percentage[0]))
//            {
//                LpiWakeVortexConditions cond_wtc(conditions[j].getMaxValue(), conditions[j].getMinValue(), conditions[j].getWtcType());
//                aux_std::vector.push_back(cond_wtc);
//            }
//            else if ((conditions[j].getWtcType() == "M") && (conditions[j].getMaxValue() >= calculated_percentage[1]) && (conditions[j].getMinValue() <= calculated_percentage[1]))
//            {
//                LpiWakeVortexConditions cond_wtc(conditions[j].getMaxValue(), conditions[j].getMinValue(), conditions[j].getWtcType());
//                aux_std::vector.push_back(cond_wtc);
//            }
//            else if ((conditions[j].getWtcType() == "H") && (conditions[j].getMaxValue() >= calculated_percentage[2]) && (conditions[j].getMinValue() <= calculated_percentage[2]))
//            {
//                LpiWakeVortexConditions cond_wtc(conditions[j].getMaxValue(), conditions[j].getMinValue(), conditions[j].getWtcType());
//                aux_std::vector.push_back(cond_wtc);
//            }
//            else if ((conditions[j].getWtcType() == "J") && (conditions[j].getMaxValue() >= calculated_percentage[3]) && (conditions[j].getMinValue() <= calculated_percentage[3]))
//            {
//                LpiWakeVortexConditions cond_wtc(conditions[j].getMaxValue(), conditions[j].getMinValue(), conditions[j].getWtcType());
//                aux_std::vector.push_back(cond_wtc);
//            }
//
//            if (aux_std::vector.size() == 4)
//            {
//                conditions_calculated = aux_std::vector;
//            }
//
//        }
//    }
//    return conditions_calculated;
//}
//
//
//std::vector<float> LpdbAirportCapacity::calculatePercentageOfWtc(
//                    std::vector<int> counter_std::vector, int counter_total)
//{
//    std::vector<float> per_std::vector;
//
//    for (unsigned int k = 0; k < counter_std::vector.size(); k++)
//    {
//        per_std::vector.push_back(0);
//    }
//
//    // Se redundea a tres decimales para que los porcentajes tengan el mismo
//    // rango que las condiciones definidas en el fichero de adaptacion
//    per_std::vector[0] = (round((counter_std::vector[0] / float(counter_total))*1000))/1000;
//    per_std::vector[1] = (round((counter_std::vector[1] / float(counter_total))*1000))/1000;
//    per_std::vector[2] = (round((counter_std::vector[2] / float(counter_total))*1000))/1000;
//    per_std::vector[3] = (round((counter_std::vector[3] / float(counter_total))*1000))/1000;
//
//    return per_std::vector;
//}
//
//void LpdbAirportCapacity::countFlightsByWtc(std::string wtc,
//                           std::vector<int> &counter_std::vector, int &counter_total)
//{
//	std::string L = "L";
//	std::string M = "M";
//	std::string H = "H";
//	std::string J = "J";
//    if (wtc.compare(L) == 0)
//    {
//        ++(counter_std::vector[0]);
//        ++counter_total;
//    }
//    else if (wtc.compare(M) == 0)
//    {
//
//        ++(counter_std::vector[1]);
//        ++counter_total;
//    }
//    else if (wtc.compare(H) == 0)
//    {
//        ++(counter_std::vector[2]);
//        ++counter_total;
//    }
//    else if (wtc.compare(J) == 0)
//    {
//        ++(counter_std::vector[3]);
//        ++counter_total;
//    }
//}
