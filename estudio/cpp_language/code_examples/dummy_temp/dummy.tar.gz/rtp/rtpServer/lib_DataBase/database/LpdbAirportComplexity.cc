/*
 * LpdbAirportComplexity.cc
 *
 */

#include <LpdbAirportComplexity.h>
#include <LcuBase.h>
#include <LcuDataTypeUtils.h>
#include <LcmetConstants.h>
#include <LpdbDataBase.h>
#include <LpdbMeteoTimedData.h>
#include <LpdbDemandTimedData.h>
#include <LpiConfigurationCoreParameters.h> //PonderationAirports


#ifdef TRACE_OUT
#include <LclogStream.h>
#endif

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <numeric>
#include <cassert>
#include <cmath>


//--------------------------------------------------------------
 
const double LpdbAirportComplexity::DEFAULT_COMPLEX_WEIGHT = 0.25;
const LpdbAirportComplexity::TYPE_COMPLEXITY_DEMAND 
    LpdbAirportComplexity::MIN_COMPLEXITY_DEMAND_VALUE = 0;
const std::string LpdbAirportComplexity::BAD_COMPLEX_SUM_MSG = 
  "The sum of the four complexity weights isn't 1; resetting to 0.25 each.";
const std::string LpdbAirportComplexity::BAD_COMPLEX_ZERODIV_MSG =
  "Bad complexity-thresholds adaptation values (UT-LT) == 0 => division by zero. Returning default complexity value (0.0).";
const std::string LpdbAirportComplexity::BAD_COMPLEX_EXP_MSG =
		"Complexity calculation, infinite exponent (X-UT/UT-LT). Returning default complexity value (0.0). ";

//--------------------------------------------------------------


LpdbAirportComplexity::LpdbAirportComplexity
    (const std::string  &airport,
     //airport thresholds: per hour values! ( defined in LpdbAirport)
     unsigned int totalMovAirportUpperThreshold,
     unsigned int totalMovAirportLowerThreshold,
     unsigned int vfrAirportUpperThreshold,
     unsigned int vfrAirportLowerThreshold,
     // DAORTP_Parameters.xml <complexityWeightPonderationAirports>
     double weightLVP,
     double weightIce,
     double weightTotalMovAirport,
     double weightVfrAirport)
      :
      the_airport(airport),      
      the_totalMovAirportUpperThreshold(totalMovAirportUpperThreshold),
      the_totalMovAirportLowerThreshold(totalMovAirportLowerThreshold),
      the_vfrAirportUpperThreshold(vfrAirportUpperThreshold),
      the_vfrAirportLowerThreshold(vfrAirportLowerThreshold),
      the_weightLVP(weightLVP),                          
      the_weightIce(weightIce),
      the_weightTotalMovAirport(weightTotalMovAirport), 
      the_weightVfrAirport(weightVfrAirport),
      the_demand_forecast(MIN_COMPLEXITY_DEMAND_VALUE),
      the_demand_vfr(MIN_COMPLEXITY_DEMAND_VALUE)
{
  assertWeights();
}


//--------------------------------------------------------------
// INIT EVENT
void LpdbAirportComplexity::init(const LpiTimeParameters & timeData,
				 boost::posix_time::ptime begin_timestamp)
{
  the_complexity.initialize(timeData.getMinutesSubinterval(),
			    timeData.getHoursWindow(),
			    timeData.getMinutesFrozen(),
			    begin_timestamp);
  the_complexity.fill();
  the_total_complexity = rtp_constants::DEFAULT_COMPLEXITY_VALUE;


  the_complexity_kpi.initialize(timeData.getMinutesSubinterval(),
				timeData.getHoursWindow(),
				timeData.getMinutesFrozen(),
				begin_timestamp);
  the_complexity_kpi.fill();
  the_total_complexity_kpi = rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE;


  KPI_TotalMov_Airport_ti.initialize(timeData.getMinutesSubinterval(),
				     timeData.getHoursWindow(),
				     timeData.getMinutesFrozen(),
				     begin_timestamp);
  KPI_TotalMov_Airport_ti.fill();
  KPI_Window_TotalMov_Airport = rtp_constants::DEFAULT_TOTALMOVS_KPI_VALUE;
}

//--------------------------------------------------------------
// INIT EVENT
//
// (also update meteo & update demand)
//
void LpdbAirportComplexity::calculateComplexity()
{
   // 0) check airport exists
  if(not check_airport_exists())
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Complexity calculation aborted at"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }

    
  // 1) Calculate complexity for each interval
  std::vector<std::string> intervals=the_complexity.getAllIntervalIds();
  std::for_each
    (std::begin(intervals), std::end(intervals),
     std::bind(static_cast<void(LpdbAirportComplexity::*)(const std::string&)>
	       (&LpdbAirportComplexity::calculateComplexity),
	       this, 
	       std::placeholders::_1));

  // 2) Calculate total complexity
  calculateTotalValues(); 

  // 3) Calculate Kpis (R_432.4 to R_432.7): already executed within 1) & 2)
}

//--------------------------------------------------------------
// CLOCK EVENT
void LpdbAirportComplexity::forward()
{
  the_complexity.forward();
  the_complexity.createElement(the_complexity.getLastInterval());
  the_complexity_kpi.forward();
  the_complexity_kpi.createElement(the_complexity_kpi.getLastInterval());
  KPI_TotalMov_Airport_ti.forward();
  KPI_TotalMov_Airport_ti.createElement(KPI_TotalMov_Airport_ti.getLastInterval());
}

//--------------------------------------------------------------

void LpdbAirportComplexity::forward(const std::string &interval)
{
  // 0) check airport exists
  if(not check_airport_exists())
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Complexity calculation aborted at"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }
  
  // 1) Calculate complexity for the new interval
  calculateComplexity(interval);

  // 2) Calculate total complexity
  calculateTotalValues();

  // 3) Calculate Kpis (R_432.4 to R_432.7): already executed within 1) & 2)
}

//==============================================================

///R_432.2 Calculate complexity for the pair (airport, interval)
///R_432.4 Calculate complexity Kpi for the pair (airport, interval)
///R_432.6 Calculate "KPI_TotalMov_Airport(ti)" for the pair.
void LpdbAirportComplexity::calculateComplexity(const std::string &interval)
{
  assert(the_complexity.exists(interval)); 

  updateInputs(interval);
  
  calculate(interval);

  calculateKPITotalmov(interval);
}

//--------------------------------------------------------------

///@test demand input
void LpdbAirportComplexity::updateInputs(const std::string &interval)
{
  LpdbDataBase::AirportTable & airport_table =
    LpdbDataBase::Get().getAirportTable();
  assert(airport_table.exists(getAirportId()));


  //meteo constraints
  LpdbMeteoTimedData meteo_constraints = 
    airport_table[getAirportId()].getMeteoForecast().getElement(interval);
  setLvpActivation(meteo_constraints.getLvpActivation());
  setDeicingRequired(meteo_constraints.getDeicingRequired());

  
  /**@warning It has been verified that (due to TimeLine creation
      logic), has_data(interval) is TRUE at initialization time, even
      before any demand or meteo data has been received => the calculation of these
      runway-restrictions must be ignored until any input message has actually
      been received.
*/
  if(airport_table[getAirportId()].getDemand().has_data(interval))
  {
	if(airport_table[getAirportId()].getDemand()[interval].isForecastEmpty())
	{
	    setDemandForecast(MIN_COMPLEXITY_DEMAND_VALUE);
	    resetDemadForecastReceived();
	}
	else
	{
	    setDemandForecast(airport_table[getAirportId()].
			      getDemand()[interval].getDemandForecast()[E_OVA]);
	    setDemadForecastReceived();
	}

	if(airport_table[getAirportId()].getDemand()[interval].isVfrEmpty())
	{
		setDemandVfr(MIN_COMPLEXITY_DEMAND_VALUE);
	    resetDemadVfrReceived();
	}
	else
	{
	    setDemandVfr(airport_table[getAirportId()].
			 getDemand()[interval].getDemandVFR()[E_OVA]);
	    setDemadVfrReceived();
	}
  }
  else
  {
    setDemandForecast(MIN_COMPLEXITY_DEMAND_VALUE);
    setDemandVfr(MIN_COMPLEXITY_DEMAND_VALUE);
    resetDemadForecastReceived();
    resetDemadVfrReceived();
  }

}

//--------------------------------------------------------------

///R_432.2 Calculate complexity for the pair (airport, interval)
///R_432.4 Calculate complexity Kpi for the pair (airport, interval)
void LpdbAirportComplexity::calculate(const std::string &interval)
{  
  the_complexity[interval].initComplexity();

  ///R_432.2
  the_complexity[interval].setComplexity
    ( (calculate_LVP_complexity() * get_weightLVP()) +
      (calculate_ice_complexity() * get_weightIce()) +
      (calculate_totalMovs_complexity() * get_weightTotalMovAirport()) +
      (calculate_VFRflights_complexity() * get_weightVfrAirport()) );

  ///R432.4
  the_complexity_kpi[interval].set(the_complexity[interval].getComplexity() * 
			      rtp_constants::MAX_COMPLEXITY_ISA_WORKLOAD_VALUE);
}

//--------------------------------------------------------------

/**R_432.2-1 Calcular complejidad por "Activación LVP"
    
   IF    (meteoForecastF.LVP_Activation (interval) = YES)
   THEN  
   Complexity_LVP(interval) = 1;
   ELSE
   Complexity_LVP(interval) = 0;
*/
rtp_constants::TYPE_COMPLEXITY LpdbAirportComplexity::calculate_LVP_complexity()
{
  if(getLvpActivation().is_initialized())
  {
    if(getLvpActivation().get() == true)
      return rtp_constants::MAX_COMPLEXITY_VALUE;
    else
      return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  else
  {
    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
}

//--------------------------------------------------------------

/** R_432.2-2 Calcular complejidad por "hielo en pista"
    
   IF    (meteoForecastF.ICE_Activation (interval) = YES)
   THEN  
   Complexity_ICE(interval) = 1;
   ELSE
   Complexity_ICE(interval) = 0;


  @warning In RTP:  weather phenomenon ice pellets (PL) => ice in the runway
*/
rtp_constants::TYPE_COMPLEXITY LpdbAirportComplexity::calculate_ice_complexity()
{
  if(getDeicingRequired().is_initialized())
  {
    if(getDeicingRequired().get() == true)
      return rtp_constants::MAX_COMPLEXITY_VALUE;
    else
      return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  else
  {
    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }  
}

//--------------------------------------------------------------

/**R_432.2-3 Calcular complejidad por "movimientos totales"
*/
rtp_constants::TYPE_COMPLEXITY
LpdbAirportComplexity::calculate_totalMovs_complexity()
{
  if(getDemadForecastReceived())
  {
    return fn_demand_complexity(getDemandForecast(),
				get_totalMovAirportLowerThreshold(),
				get_totalMovAirportUpperThreshold());
  }
  else
  {
    return rtp_constants::MIN_COMPLEXITY_VALUE; 
  }
}

//--------------------------------------------------------------

/** R_432.2-4 Calcular complejidad por "vuelos VFR"
*/
rtp_constants::TYPE_COMPLEXITY
LpdbAirportComplexity::calculate_VFRflights_complexity()
{
  if(getDemadVfrReceived())
  {
    return fn_demand_complexity(getDemandVfr(),
				get_vfrAirportLowerThreshold(),
				get_vfrAirportUpperThreshold());
  }
  else
  {
    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
}

//--------------------------------------------------------------

rtp_constants::TYPE_COMPLEXITY LpdbAirportComplexity::fn_demand_complexity
                               (const TYPE_COMPLEXITY_DEMAND & demand_data,
				const unsigned int lowerThreshold,
				const unsigned int upperThreshold)
{
  rtp_constants::TYPE_COMPLEXITY result = rtp_constants::MIN_COMPLEXITY_VALUE;

  const double X = static_cast<double>(demand_data);
  const double LT = static_cast<double>(lowerThreshold);
  const double UT = static_cast<double>(upperThreshold);
  const double DENOMINATOR = (UT-LT);

  ///@exception DENOMINATOR == 0.0
  assert(not (LcuDataTypeUtils::double_equals(DENOMINATOR, 0.0)));
  if(LcuDataTypeUtils::double_equals(DENOMINATOR, 0.0))
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << BAD_COMPLEX_ZERODIV_MSG
      << std::endl;
#endif

    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  
  
  if(X < LT)
  {
    result = rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  else if(X > UT)
  {
    result = rtp_constants::MAX_COMPLEXITY_VALUE;
  }
  else
  {
    double aux_result = (X-UT) / DENOMINATOR;

    ///@exception infinite exponent
    if(std::isinf(aux_result))
    {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).error()
	<< BAD_COMPLEX_EXP_MSG
	<< std::endl;
#endif
      
      return rtp_constants::MIN_COMPLEXITY_VALUE;
    }
    else
    {
      aux_result = std::pow(10, aux_result);
      result = static_cast<rtp_constants::TYPE_COMPLEXITY>(fabs(aux_result));
    }
  }

  assert(result >= rtp_constants::MIN_COMPLEXITY_VALUE);
  assert(result <= rtp_constants::MAX_COMPLEXITY_VALUE);
  
  result = lib_base::limit(result,
                           rtp_constants::MIN_COMPLEXITY_VALUE,
                           rtp_constants::MAX_COMPLEXITY_VALUE);

  return result;
}


//==============================================================

/**@brief Calculate total airport's complexity, total complexity KPIS,
   and total movements KPISs.

    R_432.3 Calculate total complexity = 
         [ SUM (Complexity_Airport (t_i )) ] / num_intervalos

    R_432.5 Calculate total complexity Kpi.
   
    R_432.7 Calculate KPI_Window_TotalMov_Airport.
*/
void LpdbAirportComplexity::calculateTotalValues()
{
  std::vector<std::string> intervals=the_complexity.getAllIntervalIds();
  the_total_complexity = std::accumulate
    (intervals.begin(),
     intervals.end(),
     rtp_constants::DEFAULT_COMPLEXITY_VALUE,
     [this] (rtp_constants::TYPE_COMPLEXITY init_value, 
			       std::string interval)
     {
       return init_value + 
              the_complexity.getElement(interval).getComplexity();
     });

  the_total_complexity /= the_complexity.getNumberOfElements();
  
  the_total_complexity = lib_base::limit(the_total_complexity,
			       rtp_constants::MIN_COMPLEXITY_VALUE,
			       rtp_constants::MAX_COMPLEXITY_VALUE);

  the_total_complexity_kpi = lib_base::limit
    (the_total_complexity * rtp_constants::MAX_COMPLEXITY_ISA_WORKLOAD_VALUE,
     rtp_constants::MIN_COMPLEXITY_ISA_WORKLOAD_VALUE,
     rtp_constants::MAX_COMPLEXITY_ISA_WORKLOAD_VALUE);

  calculateKPIWindowTotalmov();
}


//--------------------------------------------------------------

/// R_432.6 Calculate "KPI_TotalMov_Airport(ti)" for (airport, interval)
void LpdbAirportComplexity::calculateKPITotalmov(const std::string &interval)
{
  if(getDemadForecastReceived())
    KPI_TotalMov_Airport_ti[interval].set(getDemandForecast());
  else
    KPI_TotalMov_Airport_ti[interval].init();
}

//--------------------------------------------------------------

/// R_432.7 Calculate KPI_Window_TotalMov_Airport.
void LpdbAirportComplexity::calculateKPIWindowTotalmov()
{
  std::vector<std::string> intervals=the_complexity.getAllIntervalIds();

  KPI_Window_TotalMov_Airport = std::accumulate
    (intervals.begin(),
     intervals.end(),
     rtp_constants::DEFAULT_TOTALMOVS_KPI_VALUE,
     [this] (double init_value, std::string interval)
     {
       return init_value + KPI_TotalMov_Airport_ti.getElement(interval).get();
     });

  KPI_Window_TotalMov_Airport /= KPI_TotalMov_Airport_ti.getNumberOfElements();
}


//==============================================================
//aux. fns.

void LpdbAirportComplexity::resetComplexityWeights()
{
  set_weightLVP(DEFAULT_COMPLEX_WEIGHT);
  set_weightIce(DEFAULT_COMPLEX_WEIGHT);
  set_weightTotalMovAirport(DEFAULT_COMPLEX_WEIGHT);
  set_weightVfrAirport(DEFAULT_COMPLEX_WEIGHT);
}

void LpdbAirportComplexity::assertWeights()
{
  //development only:  To force the detection of this unexpected situation
  assert(LcuDataTypeUtils::double_equals((get_weightLVP() +
					  get_weightIce() +
					  get_weightTotalMovAirport() +
					  get_weightVfrAirport()), 1.0));

    
  if (not LcuDataTypeUtils::double_equals((get_weightLVP() +
			 get_weightIce() +
			 get_weightTotalMovAirport() +
			 get_weightVfrAirport()), 1.0))
  {
    errorComplexityWeights();
  }
}

void LpdbAirportComplexity::errorComplexityWeights()
{
  resetComplexityWeights();

#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << BAD_COMPLEX_SUM_MSG
      << std::endl;
#endif
}

//--------------------------------------------------------------
 
///@return true: if the airport exists
bool LpdbAirportComplexity::check_airport_exists()
{
  LpdbDataBase::AirportTable & airport_table =
    LpdbDataBase::Get().getAirportTable();
  assert(airport_table.exists(getAirportId()));
  if(not airport_table.exists(getAirportId()))
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << "Airport not found (" << getAirportId() << ')'
      << "Complexity calculation aborted for the airport."
      << std::endl;
#endif

    return false;
  }
  else
  {
    return true;
  }
}

//--------------------------------------------------------------

std::ostream& operator<<(std::ostream &out, const LpdbAirportComplexity & input)
{
  // complexity per interval
  out << "complexity per interval: "
      << std::endl
      << input.the_complexity;
  // total complexity
  out << "total complexity: " << input.the_total_complexity
      << std::endl;

  // complexity-KPIs
  out << "complexity-KPI per interval: "
      << std::endl
      << input.the_complexity_kpi;
  out << "total complexity-KPI: "
      << input.the_total_complexity_kpi
      << std::endl;
  
  // Total movements-KPIs
  out << "TotalMovement-KPI per interval: "
      << std::endl
      << input.KPI_TotalMov_Airport_ti;
  out << "total KPI complexity: "
      << input.KPI_Window_TotalMov_Airport
      << std::endl;

   return out;
}


//--------------------------------------------------------------
