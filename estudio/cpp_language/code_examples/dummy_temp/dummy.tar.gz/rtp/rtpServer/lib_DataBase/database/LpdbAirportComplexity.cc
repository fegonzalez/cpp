/*
 * LpdbAirportComplexity.cc
 *
 */

#include "LpdbAirportComplexity.h"
#include <LcmetConstants.h>
#include <LpdbDataBase.h>
#include <LpiConfigurationCoreParameters.h> //PonderationAirports
#include <LcuDataTypeUtils.h>

// #include <LcmetConstants.h>
#include <LpiADOVector.h>
// #include <LpiAdaptationAirportsInfo.h>
// #include <LpdbMeteoTimedData.h>
// #include <LpdbRunway.h>
#ifdef TRACE_OUT
#include <LclogStream.h>
#endif

// #include <iostream>
// #include <cmath>
// #include <map>
// #include <string>
// #include <algorithm>
 #include <numeric>
// #include <functional>   // bind
// #include <cassert>

// #include <boost/date_time/posix_time/posix_time.hpp>


//--------------------------------------------------------------
 
const double LpdbAirportComplexity::DEFAULT_COMPLEX_WEIGHT = 0.25;
const LpdbAirportComplexity::TYPE_COMPLEXITY_DEMAND 
    LpdbAirportComplexity::MIN_COMPLEXITY_DEMAND_VALUE = 0;
const std::string LpdbAirportComplexity::BAD_COMPLEX_SUM_MSG = 
  "The sum of the four complexity weights isn't 1; resetting to 0.25 each.";
const std::string LpdbAirportComplexity::BAD_COMPLEX_ZERODIV_MSG =
  "Bad complexity-thresholds adaptation values (UT-LT) == 0 => division by zero. Returning default complexity value (0.0).";


//--------------------------------------------------------------


LpdbAirportComplexity::LpdbAirportComplexity
    (const std::string  &airport,
     //airport thresholds: per hour values! ( defined in LpdbAirport)
     unsigned int totalMovAirportUpperThreshold,
     unsigned int totalMovAirportLowerThreshold,
     unsigned int vfrAirportUpperThreshold,
     unsigned int vfrAirportLowerThreshold,
     // DAORTP_Parameters.xml <complexityWeightPonderationAirports>
     double weightLVP,
     double weightIce,
     double weightTotalMovAirport,
     double weightVfrAirport)
      :
      the_airport(airport),      
      the_totalMovAirportUpperThreshold(totalMovAirportUpperThreshold),
      the_totalMovAirportLowerThreshold(totalMovAirportLowerThreshold),
      the_vfrAirportUpperThreshold(vfrAirportUpperThreshold),
      the_vfrAirportLowerThreshold(vfrAirportLowerThreshold),
      the_weightLVP(weightLVP),                          
      the_weightIce(weightIce),
      the_weightTotalMovAirport(weightTotalMovAirport), 
      the_weightVfrAirport(weightVfrAirport),
      the_demand_forecast(MIN_COMPLEXITY_DEMAND_VALUE),
      the_demand_vfr(MIN_COMPLEXITY_DEMAND_VALUE)
{
  std::clog << "Test complexity (sequence diagram)"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;


  assertWeights();
}


bool LpdbAirportComplexity::has_data(const std::string& interval_name)
{
   return the_airport_complexity.hasData(interval_name);
}


LpdbAirportComplexityTimedData& LpdbAirportComplexity::operator []
(const std::string& interval_name)
{
   return the_airport_complexity[interval_name];
}


TimeLine<LpdbAirportComplexityTimedData> LpdbAirportComplexity::getTimeLine() const
{
   return the_airport_complexity;
}


//--------------------------------------------------------------
// INIT EVENT
void LpdbAirportComplexity::init(const LpiTimeParameters & timeData,
				 boost::posix_time::ptime begin_timestamp)
{
  std::clog << "Test complexity (sequence diagram)"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;


  the_airport_complexity.initialize(timeData.getMinutesSubinterval(),
				    timeData.getHoursWindow(),
				    timeData.getMinutesFrozen(),
				    begin_timestamp);
  the_airport_complexity.fill();

  the_total_airport_complexity = rtp_constants::DEFAULT_COMPLEXITY_VALUE;
}

//--------------------------------------------------------------
// INIT EVENT
//
// (also update meteo & update demand)
//
void LpdbAirportComplexity::calculateComplexity()
{
  std::clog << "Test complexity (sequence diagram)"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;

  
  // 0) check airport exists
  if(not check_airport_exists())
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Complexity calculation aborted at"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }

    
  // 1) Calculate complexity for each interval
  std::vector<std::string> intervals=the_airport_complexity.getAllIntervalIds();
  std::for_each
    (std::begin(intervals), std::end(intervals),
     std::bind(static_cast<void(LpdbAirportComplexity::*)(const std::string&)>
	       (&LpdbAirportComplexity::calculateComplexity),
	       this, 
	       std::placeholders::_1));

  // 2) Calculate total complexity
  ///@test R_432.3 Calcular complejidad total de cada aeropuerto
  calculateTotalComplexity();

  // 3) Calculate Kpis
  ///@todo R_432.4 - R_432.4  Calcular KPIs asociados a la complejidad
  calculateComplexityKPIs();
      
}

//--------------------------------------------------------------
// CLOCK EVENT
void LpdbAirportComplexity::forward()
{
  std::clog << "Test complexity (sequence diagram)"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;


  the_airport_complexity.forward();
  the_airport_complexity.createElement(the_airport_complexity.getLastInterval());
}

//--------------------------------------------------------------

void LpdbAirportComplexity::forward(const std::string &interval)
{
  std::clog << "Test complexity (sequence diagram)"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
  
  // 0) check airport exists
  if(not check_airport_exists())
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Complexity calculation aborted at"
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }
  
  // 1) Calculate complexity for the new interval
  calculateComplexity(interval);

  // 2) Calculate total complexity
  ///@test R_432.3 Calcular complejidad total de cada aeropuerto
  calculateTotalComplexity();

  // 3) Calculate Kpis
  ///@todo R_432.4 - R_432.4  Calcular KPIs asociados a la complejidad
  calculateComplexityKPIs();
}

//==============================================================

 ///@test R_432.2 Calcular complejidad para cada par (aeropuerto,intervalo)
void LpdbAirportComplexity::calculateComplexity(const std::string &interval)
{
  std::clog << "Test complexity (sequence diagram)"
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;

  assert(the_airport_complexity.exists(interval)); 

  updateInputs(interval);
  
  calculate(interval);
}

//--------------------------------------------------------------

void LpdbAirportComplexity::updateInputs(const std::string &interval)
{
  ///@todo FIXME

  LpdbDataBase::AirportTable & airport_table =
    LpdbDataBase::Get().getAirportTable();
  assert(airport_table.exists(getAirportId()));


  //meteo constraints
  LpdbMeteoTimedData meteo_constraints = 
    airport_table[getAirportId()].getMeteoForecast().getElement(interval);
  setLvpActivation(meteo_constraints.getLvpActivation());
  setDeicingRequired(meteo_constraints.getDeicingRequired());

  
  ///@todo demand constraints
  /**@param the_demand_forecast
     
     Demand_Forecast(ti) = [Num_Ai, Num_Di, Num_Oi] definido en 4.2.1
                                                    Demanda prevista.
						    
     @warning Solo se usa la componente Overal
   */
  /**@param the_demand_vfr

     Demand_VFR(ti) = [Num_VFR_Oi] definido en 4.2.1 Demanda prevista

     @warning Solo se usa la componente Overal
   */
//  setDemandForecast(demand_constraints.getDemandForecast().Overal);
//  setDemandVfr(demand_constraints.getDemandVfr().Overal);
//
}

//--------------------------------------------------------------

///@test R_432.2 Calcular complejidad para cada par (aeropuerto,intervalo)
void LpdbAirportComplexity::calculate(const std::string &interval)
{  
  the_airport_complexity[interval].initComplexity();

  ///@test finallly R_432.2
  the_airport_complexity[interval].setComplexity
    ( (calculate_LVP_complexity() * get_weightLVP()) +
      (calculate_ice_complexity() * get_weightIce()) +
      (calculate_totalMovs_complexity() * get_weightTotalMovAirport()) +
      (calculate_VFRflights_complexity() * get_weightVfrAirport()) );
}

//--------------------------------------------------------------

/**@test R_432.2-1 Calcular complejidad por "Activación LVP"
    
   IF    (meteoForecastF.LVP_Activation (interval) = YES)
   THEN  
   Complexity_LVP(interval) = 1;
   ELSE
   Complexity_LVP(interval) = 0;
*/
rtp_constants::TYPE_COMPLEXITY LpdbAirportComplexity::calculate_LVP_complexity()
{
  if(getLvpActivation().is_initialized())
  {
    if(getLvpActivation().get() == true)
      return rtp_constants::MAX_COMPLEXITY_VALUE;
    else
      return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  else
  {
    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
}

//--------------------------------------------------------------

/**@test R_432.2-2 Calcular complejidad por "hielo en pista"
    
   IF    (meteoForecastF.ICE_Activation (interval) = YES)
   THEN  
   Complexity_ICE(interval) = 1;
   ELSE
   Complexity_ICE(interval) = 0;


  @todo FIXME  deicing =>  weather phenomenon ice pellets
*/
rtp_constants::TYPE_COMPLEXITY LpdbAirportComplexity::calculate_ice_complexity()
{
  if(getDeicingRequired().is_initialized())
  {
    if(getDeicingRequired().get() == true)
      return rtp_constants::MAX_COMPLEXITY_VALUE;
    else
      return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  else
  {
    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }  
}

//--------------------------------------------------------------

/**@test R_432.2-3 Calcular complejidad por "movimientos totales"
*/
rtp_constants::TYPE_COMPLEXITY
LpdbAirportComplexity::calculate_totalMovs_complexity()
{
  return fn_demand_complexity(getDemandForecast(),
			      get_totalMovAirportLowerThreshold(),
			      get_totalMovAirportUpperThreshold());
}

//--------------------------------------------------------------

/**@test R_432.2-4 Calcular complejidad por "vuelos VFR"
*/
rtp_constants::TYPE_COMPLEXITY
LpdbAirportComplexity::calculate_VFRflights_complexity()
{
  return fn_demand_complexity(getDemandVfr(),
			      get_vfrAirportLowerThreshold(),
			      get_vfrAirportUpperThreshold());
}

//--------------------------------------------------------------

 ///@test crosswind/tailwind reduction
rtp_constants::TYPE_COMPLEXITY LpdbAirportComplexity::fn_demand_complexity
    (const TYPE_COMPLEXITY_DEMAND & demand_data,
     const unsigned int lowerThreshold,
     const unsigned int upperThreshold)
{
  rtp_constants::TYPE_COMPLEXITY result = rtp_constants::MIN_COMPLEXITY_VALUE;

  const double X = static_cast<double>(demand_data);
  const double LT = static_cast<double>(lowerThreshold);
  const double UT = static_cast<double>(upperThreshold);
  const double DENOMINATOR = (UT-LT);


  ///@todo FIXME  case: demand data not available; expected at init, before any demand has been received.
  // idem LpdbAirportCapacity::calculate_runways_restrictions
  ///@exception No meteo data has been received: system init, forward & no meteo received
//    if(demand_data.empty())
//    {
//      return rtp_constants::MIN_COMPLEXITY_VALUE;
//    }

  ///@exception DENOMINATOR == 0.0
  assert(not (LcuDataTypeUtils::double_equals(DENOMINATOR, 0.0))); // forbid zero division
  if(LcuDataTypeUtils::double_equals(DENOMINATOR, 0.0))
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << BAD_COMPLEX_ZERODIV_MSG
      << std::endl;
#endif

    return rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  
  
  if(X < LT)
  {
    result = rtp_constants::MIN_COMPLEXITY_VALUE;
  }
  else if(X > UT)
  {
    result = rtp_constants::MAX_COMPLEXITY_VALUE;
  }
  else
  {
    result = static_cast<rtp_constants::TYPE_COMPLEXITY>
             ( fabs((X-LT)/DENOMINATOR) );
  }

  assert(result >= rtp_constants::MIN_COMPLEXITY_VALUE);
  assert(result <= rtp_constants::MAX_COMPLEXITY_VALUE);
  
  return result;
}


//==============================================================

/**@todo R_432.3 Calcular complejidad total de cada aeropuerto

	Complexity_Airport = [ SUM (Complexity_Airport (t_i )) ] / num_intervalos
*/
void LpdbAirportComplexity::calculateTotalComplexity()
{
  std::vector<std::string> intervals=the_airport_complexity.getAllIntervalIds();
  the_total_airport_complexity = std::accumulate
    (intervals.begin(),
     intervals.end(),
     rtp_constants::DEFAULT_COMPLEXITY_VALUE,
     [this] (rtp_constants::TYPE_COMPLEXITY init_value, 
			       std::string interval)
     {
       return init_value + 
              the_airport_complexity.getElement(interval).getComplexity();
     });

  the_total_airport_complexity /= the_airport_complexity.getNumberOfElements();
}

//==============================================================

///@todo R_432.4 - R_432.4  Calcular KPIs asociados a la complejidad
void LpdbAirportComplexity::calculateComplexityKPIs()
{
  ///@todo FIXME  requere TimeLine para KPI_Complexity_Airport
}


//==============================================================

void LpdbAirportComplexity::resetComplexityWeights()
{
  set_weightLVP(DEFAULT_COMPLEX_WEIGHT);
  set_weightIce(DEFAULT_COMPLEX_WEIGHT);
  set_weightTotalMovAirport(DEFAULT_COMPLEX_WEIGHT);
  set_weightVfrAirport(DEFAULT_COMPLEX_WEIGHT);
}

void LpdbAirportComplexity::assertWeights()
{
	// usar la de  #include <LcuDataTypeUtils.h>

  if (not LcuDataTypeUtils::double_equals((get_weightLVP() +
			 get_weightIce() +
			 get_weightTotalMovAirport() +
			 get_weightVfrAirport()), 1.0))
  {
    errorComplexityWeights();
  }
}

void LpdbAirportComplexity::errorComplexityWeights()
{
  resetComplexityWeights();

#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << BAD_COMPLEX_SUM_MSG
      << std::endl;
#endif

  //development only:  To force the detection of this unexpected situation
  assert(false);
}

//--------------------------------------------------------------
 
///@return true: if the airport exists
bool LpdbAirportComplexity::check_airport_exists()
{
  LpdbDataBase::AirportTable & airport_table =
    LpdbDataBase::Get().getAirportTable();
  assert(airport_table.exists(getAirportId()));
  if(not airport_table.exists(getAirportId()))
  {
#ifdef TRACE_OUT    
    LclogStream::instance(LclogConfig::E_RTP).error()
      << "Airport not found (" << getAirportId() << ')'
      << "Complexity calculation aborted for the airport."
      << std::endl;
#endif

    return false;
  }
  else
  {
    return true;
  }
}

//--------------------------------------------------------------

std::ostream& operator<<(std::ostream &out, const LpdbAirportComplexity & rs)
{
  // //nominals
  // out << "nominal_complexity: " << rs.the_airport_nominal_complexity
  //     << "nominal TMA: " << rs.get_tmaNominalComplexity()
  //     << "nominal TWY: " << rs.get_taxywaysNominalComplexity()
  //     << std::endl;

  // //per interval
  // out << "max_complexity: "
  // 	  << std::endl
  // 	  << rs.the_airport_complexity
  //     << std::endl
  //     << "| TMA: " << rs.the_tma
  //     << std::endl
  //     << "| TWY: " << rs.the_twy
  //     << std::endl;

   return out;
}


//--------------------------------------------------------------
