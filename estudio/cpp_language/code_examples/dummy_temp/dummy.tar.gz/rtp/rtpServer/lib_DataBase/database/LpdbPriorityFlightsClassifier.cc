/*
 * LpdbPriorityFlightsClassifier.cc
 *
 *  Created on: 23/07/2015
 *      Author: mbegega
 */

#include <LpdbDataBase.h>
#include "LpdbPriorityFlightsClassifier.h"


void LpdbPriorityFlightsClassifier::ClassifyFlights(vector<string> collectionToCheck,
                                                   vector<string> flightsToClassify,
                                                   PriorityMap & categoryDelayedWithPriority,
                                                   vector<string> & categoryDelayedWithoutPriority,
                                                   PriorityMap & categoryWithPriority,
                                                   vector<string> & categoryWithoutPriority)
{
   categoryDelayedWithPriority.clear();
   categoryDelayedWithoutPriority.clear();
   categoryWithPriority.clear();
   categoryWithoutPriority.clear();

///@todo FIXME new logic getPriorityArrivals() & getPriorityDepartures()

   // LpdbDataBase::FPTable & flightPlansTable = LpdbDataBase::Get().getFPTable();

   // for (unsigned int i = 0; i < flightsToClassify.size(); i++)
   // {
   //    string fpKey = flightsToClassify[i];

   //    vector<string>::iterator it = std::find(collectionToCheck.begin(),
   //                                            collectionToCheck.end(),
   //                                            fpKey);
   //     
      //
      //      bool isInCollectionToCheck = (it != collectionToCheck.end());
      //
      // if (flightPlansTable.exists(fpKey))
      // {
      //    LpiFlightPlan & fp = flightPlansTable[fpKey];
      //	 
      // int fpPriority = fp.getPriority();
      //
      // if (fpPriority > 0)
      // {
      //    if (isInCollectionToCheck)
      //    {
      //          categoryDelayedWithPriority[fpPriority].push_back(fpKey);
      //    }
      //    else
      //    {
      //          categoryWithPriority[fpPriority].push_back(fpKey);
      //    }
      // }
      // else
      // {
      //    if (isInCollectionToCheck)
      //    {
      //          categoryDelayedWithoutPriority.push_back(fpKey);
      //    }
      //    else
      //    {
      //          categoryWithoutPriority.push_back(fpKey);
      //    }
      //    }
      // }
   // }
}


vector<string> LpdbPriorityFlightsClassifier::MergeClassifiedByPriority(PriorityMap firstCategoryWithPriority,
                                                                       vector<string> firstCategoryWithoutPriority,
                                                                       PriorityMap secondCategoryWithPriority,
                                                                       vector<string> secondCategoryWithoutPriority)
{
   vector<string> result;

   for (PriorityMap::iterator itr = firstCategoryWithPriority.begin();
                                    itr != firstCategoryWithPriority.end();
                                    ++itr)
   {
      result.insert(result.end(), (*itr).second.begin(), (*itr).second.end());
   }

   for (PriorityMap::iterator itr = secondCategoryWithPriority.begin();
                                    itr != secondCategoryWithPriority.end();
                                    ++itr)
   {
      result.insert(result.end(), (*itr).second.begin(), (*itr).second.end());
   }

   result.insert(result.end(), firstCategoryWithoutPriority.begin(), firstCategoryWithoutPriority.end());

   result.insert(result.end(), secondCategoryWithoutPriority.begin(), secondCategoryWithoutPriority.end());

   return result;
}
