/*
 * LpdbDelayOption.h
 *
 */

#ifndef LPB_DELAY_OPTION_H_
#define LPB_DELAY_OPTION_H_

#include <string>
#include <vector>

#include "LpiADOVector.h"

using std::vector;
using std::string;

class LpdbDelayOption
{
public:

   LpdbDelayOption();

   LpdbDelayOption(const LpdbDelayOption & source);

   virtual ~LpdbDelayOption();

   LpdbDelayOption & operator= (const LpdbDelayOption & source);


   //Getters and Setters
   LpiADOVector<int> getDelayedFPs () const;
   void setDelayedFPs (const LpiADOVector<int> delayed);

   LpiADOVector<int> getAcceptedDelayedFPs () const;
   void setAcceptedDelayedFPs (const LpiADOVector<int> accpeted_delayed);

   LpiADOVector<int> getNonAcceptedDelayedFPs () const;
   void setNonAcceptedDelayedFPs (const LpiADOVector<int> real_delayed);

   double getRatioARR() const { return r_ratioARR; }
   double getRatioDEP() const { return r_ratioDEP; }

   void setRatioARR(double value) { r_ratioARR = value; }
   void setRatioDEP(double value) { r_ratioDEP = value; }

   double getWeightARR() const { return r_weightARR; }
   double getWeightDEP() const { return r_weightDEP; }

   void setWeightARR(double value) { r_weightARR = value; }
   void setWeightDEP(double value) { r_weightDEP = value; }

   void setDistance(double value)   { r_distance = value; }
   double getDistance() const { return r_distance; }

protected:

   LpiADOVector<int> r_delayedFPs;
   LpiADOVector<int> r_accepted_delayedFPs;
   LpiADOVector<int> r_non_accepted_delayedFPs;

   double r_ratioARR;
   double r_ratioDEP;

   double r_weightARR;
   double r_weightDEP;

   double r_distance;
};


std::ostream& operator<<(std::ostream &os, const LpdbDelayOption &info);

#endif /* LPB_DELAY_OPTION_H_ */
