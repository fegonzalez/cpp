#include <LclogStream.h>
#include <LctimVirtualClock.h>
#include <LctimTimeUtils.h>


#include "LpdbDataBase.h"
//#include <LpdbRunway.h>

#include <LpdbRunwaySystemsMemento.h>

#include <LpiConfigurationCoreParameters.h>
#include <LpiAdaptationAirportsInfo.h>

#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>


void LpdbDataBase::init
(const LpiConfigurationCoreParameters &configCoreParams,
 // const LpiAdaptationRunwayList &runwayList,
 // const LpiAdaptationRunwaySystemList &runwaySystemList,
 const LpiAdaptationMrtmInfo &mrtmInfo,
 const LpiAdaptationAirportsInfo &airportInfoList,
 const LpiPriorityTable &priorityTableDepartures,
 const LpiPriorityTable &priorityTableArr,
 const LpiAdaptationAssignmentPreference &assPref,
 const LpiAdaptationAlert_KPIs &adapAlertKpi,
 const LpiWakeVortexCapacityReductions &wtcCapacity
 )
{

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).debug()
    		<< "TODO: Server DB init (begin)"
			<< " : File: " << __FILE__
			<< " ; fn: " << __func__
			<< " ; line: " << __LINE__
			<< std::endl;
#endif


	// Subintervals info
	//
	// Global parameters initialization
	r_globalParameters.init(configCoreParams.getTimeParameters(),
			configCoreParams.getUseWakeVortexCapacityReductions(),
			configCoreParams.getFpExpirationTime(),
			configCoreParams.getAlternativeAllocationsExpirationHours(),
			mrtmInfo.getWorkloadThresholds(),
			adapAlertKpi);

	boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();
	const LpiTimeParameters timeData = configCoreParams.getTimeParameters();

	//WTC reductions
	setWakeVortexReductions(wtcCapacity);


	//No optimal schedule has been stored
	r_hasOptimalSchedule = false;

	r_hasActiveSchedule = false;

	initTimeLine(timeData, now);


	//prohibitions table & preferences table (see doc [1].4.1)
	r_adapPreferencesAndProhibitions = assPref;

	r_prohibitionsTimeline.initialize(timeData.getMinutesSubinterval(),
                                      timeData.getHoursWindow(),
                                      timeData.getMinutesFrozen(),
                                      now);
	r_prohibitionsTimeline.fill();
	generateIntervalProhibitions();

	r_preferencesTimeline.initialize(timeData.getMinutesSubinterval(),
			                         timeData.getHoursWindow(),
									 timeData.getMinutesFrozen(),
									 now);
	r_preferencesTimeline.fill();
	generateIntervalPreferences();


	initAirports(airportInfoList, timeData, now);


	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///@todo the following DB MUST be checked and fixed (following tasks in [1])
	///(task spared among all the RTP tasks)
#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).debug()
            		<< "TODO: Server DB init (non-global parameters)"
					<< " : File: " << __FILE__
					<< " ; fn: " << __func__
					<< " ; line: " << __LINE__
					<< std::endl;
#endif


	//Runway information initialization
	//addRunways(runwayList, timeData, now);   ///@todo Get runways form within airportInfoList




	//	   r_DCBAirportTimeline.initialize(timeData.getMinutesSubinterval(),
	//	                                   timeData.getHoursWindow(),
	//	                                   timeData.getMinutesFrozen(),
	//	                                   now); //RMAN only
	//	   r_DCBAirportTimeline.fill(); //RMAN only
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}

void LpdbDataBase::initTimeLine(const LpiTimeParameters & timeData,
						   const boost::posix_time::ptime & now)
{
  //Calculate base of timeline
  unsigned int min= now.time_of_day().minutes();
  unsigned int sec= now.time_of_day().seconds();
  unsigned int base_min= min % timeData.getMinutesSubinterval();

  //HH:MM:00
  ptime base_timeline= now - minutes(base_min) - seconds(sec);
  r_timelineBase = base_timeline;
}

LpdbGlobalParameters LpdbDataBase::getGlobalParameters() const
{
   return r_globalParameters;
}


void LpdbDataBase::forwardTimeline()
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "DB: forwardTimeline "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  //Forward one time interval in all database timed data: per airport (demnad, meteo), ...



  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///@todo the following DB MUST be checked and fixed (following tasks in [1])
  ///(RMAN's code

   //Update each of Runways in data table

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@todo (RMAN) DB: forwardTimeline: Runways "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
//
//   std::vector<string> runway_keys = r_runwayTable.getAllIds();
//
//   BOOST_FOREACH(const string & runway_id, runway_keys)
//   {
//      if (r_runwayTable.exists(runway_id))
//      {
//         r_runwayTable[runway_id].forwardTimeline();
//      }
//   }


   //Update each of Runway Systems in data table
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@todo (RMAN) DB: forwardTimeline: Runway Systems "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
//   std::vector<string> rs_keys = r_runwaySystemTable.getAllIds();
//
//   BOOST_FOREACH(const string & rs_id, rs_keys)
//   {
//      if (r_runwaySystemTable.exists(rs_id))
//      {
//         r_runwaySystemTable[rs_id].forwardTimeline();
//      }
//   }

   //Update each of Schedule in data table
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@todo (RMAN) DB: forwardTimeline: Schedule "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
//   std::vector<int> schedule_keys=r_schedulesTable.getAllIds();
//   BOOST_FOREACH(const int & sch_key, schedule_keys)
//   {
//      if(r_schedulesTable.exists(sch_key))
//      {
//         r_schedulesTable[sch_key].forward();
//      }
//   }
//
//   //Forward active schedule
//   if (r_hasActiveSchedule)
//   {
//      r_activeSchedule.forward();
//   }
//
//   //Forward optimal schedule
//   if (r_hasOptimalSchedule)
//   {
//      r_optimalSchedule.forward();
//   }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////


  ///RTP verified actions bellow:

   //Forward Meteo data
   forwardAirportsTable();

   
   //Update DCB Airport timeline //RMAN only
//   r_DCBAirportTimeline.forward();
//   r_DCBAirportTimeline.createElement(r_DCBAirportTimeline.getLastInterval());


   //Update Prohibitions timeline
   r_prohibitionsTimeline.forward();
   r_prohibitionsTimeline.createElement(r_prohibitionsTimeline.getLastInterval());
   //Update Preferences timeline
   r_preferencesTimeline.forward();
   r_preferencesTimeline.createElement(r_preferencesTimeline.getLastInterval());

   
   //Update timelines base for future schedules creations
   r_timelineBase = LctimVirtualClock::Get().getTime();

   generateIntervalProhibitions(r_prohibitionsTimeline.getLastInterval());
   generateIntervalPreferences(r_preferencesTimeline.getLastInterval());

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).debug() << "Forward result: Prohibitions timeline:\n" << r_prohibitionsTimeline << std::endl;
   LclogStream::instance(LclogConfig::E_RTP).debug() << "Forward result: Preferences timeline:\n" << r_preferencesTimeline << std::endl;
#endif

}


void LpdbDataBase::print (std::ostream & out) const
{
   out << "Global Parameters:" << std::endl;
   out << getGlobalParameters()  << std::endl;

   out << "Airports:"  << std::endl;
   out << r_airportsTable << std::endl;
//
//   out << "Runways:" << std::endl;
//   out << r_runwayTable << std::endl;
//
//   out << "Runway Systems:" << std::endl;
//   out << r_runwaySystemTable << std::endl;
//
//   out << "Flight Plans:" << std::endl;
//   out << r_fpsTable << std::endl;

   out << "TimeLine base time: " << std::endl;
   out << r_timelineBase << std::endl;
}

//
//std::ostream& LpdbDataBase::prinMeteoTimeline(std::ostream &out)const
//{
//	std::vector<KEY_AIRPORT_ID> airport_keys = r_airportsTable.getAllIds();
//
//	BOOST_FOREACH(const KEY_AIRPORT_ID & airport_id, airport_keys)
//	{
//		if (r_airportsTable.exists(airport_id))
//		{
//			//out << getMeteoForecast(airport_id);
//			out << r_airportsTable[airport_id].getMeteoForecast();
//		}
//	}
//
//	return out;
//}
//

///@warning RMAN's code
//
//void LpdbDataBase::addRunways(const LpiAdaptationRunwayList & runways,
//                             const LpiTimeParameters & timeData,
//                             boost::posix_time::ptime begin_timestamp)
//{
//   //DataBase will store static(read from adaptation) and
//   //dynamic data (calculated)for runways
//
//   BOOST_FOREACH(const LpiAdaptationRunway & rwy, runways)
//   {
//      LpdbRunway runway(rwy);
//      runway.init(timeData, begin_timestamp); //initiates timeline
//      r_runwayTable.addElement(runway.getRunwayId(), runway);
//   }
//}


TimeLine<LpdbDCBAirportTimedData> & LpdbDataBase::getDCBAirportTimeline()
{
   return r_DCBAirportTimeline;
}


void LpdbDataBase::setDCBAirportTimeline(TimeLine<LpdbDCBAirportTimedData> & data)
{
   r_DCBAirportTimeline = data;
}


TimeLine<LpdbProhibitions> &  LpdbDataBase::getProhibitionsTimeline()
{
   return r_prohibitionsTimeline;
}


void LpdbDataBase::setProhibitionsTimeline(TimeLine<LpdbProhibitions> & data)
{
   r_prohibitionsTimeline = data;
}


TimeLine<LpdbPreferences> &  LpdbDataBase::getPreferencesTimeline()
{
   return r_preferencesTimeline;
}


void LpdbDataBase::setPreferencesTimeline(TimeLine<LpdbPreferences> & data)
{
   r_preferencesTimeline = data;
}


void LpdbDataBase::setOptimalSchedule (const LpdbSchedule & schedule)
{
   r_hasOptimalSchedule = true;
   r_optimalSchedule = schedule;
}


bool LpdbDataBase::hasOptimalSchedule () const
{
   return r_hasOptimalSchedule;
}


LpdbSchedule & LpdbDataBase::getOptimalSchedule ()
{
   return r_optimalSchedule;
}


void LpdbDataBase::setActiveSchedule (const LpdbAlternativeSchedule & schedule)
{
   r_hasActiveSchedule = true;
   r_activeSchedule = schedule;
}


bool LpdbDataBase::hasActiveSchedule () const
{
   return r_hasActiveSchedule;
}


LpdbAlternativeSchedule & LpdbDataBase::getActiveSchedule ()
{
   return r_activeSchedule;
}


boost::posix_time::ptime LpdbDataBase::getActivationTime() const
{
   return r_activationTime;
}


void LpdbDataBase::setActivationTime(boost::posix_time::ptime timestamp)
{
   r_activationTime = timestamp;
}


////////////////////////////////////////
/** Meteo Info
 *
 *@todo FIXME: adaptar para RTP: varios aeropuertos
 */
///////////////////////////////////////


/**@param r_meteoReports: ALL forecast-periods => a FOREcast msg information

//--------------------

@fn getNumberOfMeteoReportsReceived
@fn getReceivedMeteoReports


    CALL FROM:  Use case:  forwardTimeLine

    LpdBusinessLogicFacade::forwardTimeline(void)
      => LpdBusinessLogicFacade::reviewMeteoInfo(string interval)
         => call here


//--------------------


@fn LpdbDataBase::addMeteoReport

    CALL FROM:  LpdBusinessLogicFacade::updateMeteoNowcast()

    CALL FROM:  LpdBusinessLogicFacade::updateMeteoForecast()



///@warning RMAN: uses LpiUpdateMeteo => ONE airport => addMeteoReport uses only ONE airport
void LpdBusinessLogicFacade::updateMeteoNowcast(const LpiCreateMeteoList & meteolist)


///@warning   simplemente añade forecast-period al vector SIN REEMPLAZAR anteriores reports para el mismo airport-interval !!
///       => puede contener duplicados del mismo par (airport, interval)
///          Nota.- lo más moderno estará al final del vector => se puede tener esto en cuenta para guardar lo más moderno
///                 por el par (airport, interval), y así no se toca la forma de añadir datos en addMeteoReport()


@fn LpdbDataBase::deleteMeteoReport  Use case:  forwardTimeLine : borrar los datos obsoletos

    LpdBusinessLogicFacade::forwardTimeline(void)
      => LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)
         => deleteMeteoReport

*/


unsigned int LpdbDataBase::getNumberOfMeteoReportsReceived (const KEY_AIRPORT_ID &airport)
{
   assert(r_airportsTable.exists(airport));
   return r_airportsTable[airport].getNumberOfMeteoReportsReceived();
}


std::vector<LpiMeteoInfo> LpdbDataBase::getReceivedMeteoReports (const KEY_AIRPORT_ID &airport)
{
	assert(r_airportsTable.exists(airport));
	return r_airportsTable[airport].getReceivedMeteoReports();
}


void LpdbDataBase::addMeteoReport (const KEY_AIRPORT_ID &airport, const LpiMeteoInfo &report)
{
	assert(r_airportsTable.exists(airport));
	r_airportsTable[airport].addMeteoReport(report);
}

void LpdbDataBase::deleteObsoleteMeteoReports (const KEY_AIRPORT_ID &airport)
{
	assert(r_airportsTable.exists(airport));
	r_airportsTable[airport].deleteObsoleteMeteoReports();
}

///@warning: assert index < getNumberOfMeteoReportsReceived() before call
LpiMeteoInfo LpdbDataBase::getMeteoReport (const KEY_AIRPORT_ID &airport, const unsigned int index)
{
	assert(r_airportsTable.exists(airport));
	assert(index < getNumberOfMeteoReportsReceived(airport));
	return r_airportsTable[airport].getMeteoReport(index);
}

//
//
//void LpdbDataBase::deleteMeteoReport (const KEY_AIRPORT_ID &airport, unsigned int index)
//{
//
//#ifdef TRACE_OUT
//  LclogStream::instance(LclogConfig::E_RTP).debug()
//    << "BEFORE: deleteMeteoReport: (airport, index)"
//	<< '(' << airport << ',' << index << ')'
//	<< " ; r_airportsTable.getNumberOfElements() = " << r_airportsTable[airport].getNumberOfMeteoReportsReceived()
//    << " ; File: " << __FILE__
//    << " ; fn: " << __func__
//    << " ; line: " << __LINE__
//    << std::endl;
//#endif
//
//
//	assert(r_airportsTable.exists(airport));
//	r_airportsTable[airport].deleteMeteoReport(index);
//
//
//#ifdef TRACE_OUT
//  LclogStream::instance(LclogConfig::E_RTP).debug()
//    << "AFTER: deleteMeteoReport: (airport, index)"
//	<< '(' << airport << ',' << index << ')'
//	<< " ; r_airportsTable.getNumberOfElements() = " << r_airportsTable[airport].getNumberOfMeteoReportsReceived()
//    << " ; File: " << __FILE__
//    << " ; fn: " << __func__
//    << " ; line: " << __LINE__
//    << std::endl;
//#endif
//}


/**@warning getLastReceivedMeteoReport: UNUSED in RMAN

boost::optional<LpiMeteoInfo> LpdbDataBase::getLastReceivedMeteoReport (const KEY_AIRPORT_ID &airport) const
{
  assert(r_airportsTable.exists(airport));
  return r_airportsTable[airport].getLastReceivedMeteoReport();
}
*/



/**@param r_meteoLine

Use case:  new meteo info received  (Nowcast msg. / Forecast msg.)

@test LpdBusinessLogicFacade::updateMeteoNowcastDB
@test LpdBusinessLogicFacade::updateMeteoForecastDB


//--------------------

Use case:  forwardTimeLine:  get r_meteoReports

    CALL FROM:

@test LpdBusinessLogicFacade::forwardTimeline(void)
      => rLpdbDataBase::forwardTimeline()


2) update r_meteotimeline[new_interval]

    CALL FROM:

@test LpdBusinessLogicFacade::forwardTimeline(void)
      => LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)

//--------------------

@fn LpdbDataBase::setMeteoForecast

    CALL FROM:

@test LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)
      Use case:  forwardTimeLine

//--------------------

@fn LpdbDataBase::getMeteoForecast

    CALL FROM:

@test LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval);
      Use case: forwardTimeLine

-------------

    ignore now

    CALL FROM:   (RMAN: RW & RW systems: usos para reducciones de capacidad

    LpdbDataBase::getRunwaysCapacitiesAsString()
    LpdbDataBase::getRunwaySystemsCapacitiesAsString()
    LpdbRunway::calculateILSCapacity
    LpdbRunway::applyMeteoReductions
    LpdbRunwaySystem::applyCapacityReductions()
    LpdbRunwaySystem::applyMeteoReductions()
    LpdbRunwaySystem::applyCapacityReductions(string interval)


*/

TimeLine<LpdbMeteoTimedData> &
LpdbDataBase::getMeteoForecast(const std::string &airport)
{
  // the server's consumer MUST NOT accept meteo message for unmanaged airports
  assert(r_airportsTable.exists(airport));
  
  return r_airportsTable[airport].getMeteoForecast();
}


void LpdbDataBase::setMeteoForecast(const std::string &airport,
                                    const TimeLine<LpdbMeteoTimedData> & data)
{
  // the server's consumer MUST NOT accept meteo message for unmanaged airports
  assert(r_airportsTable.exists(airport));
  r_airportsTable[airport].setMeteoForecast(data);
}

void LpdbDataBase::forwardAirportsTable()
{
  std::vector<KEY_AIRPORT_ID> airport_keys = r_airportsTable.getAllIds();

   BOOST_FOREACH(const KEY_AIRPORT_ID & airport_id, airport_keys)
   {
      if (r_airportsTable.exists(airport_id))
      {
         r_airportsTable[airport_id].forwardTimeline();
      }
   }
  
}

////////////////////////////////////////
/// end Meteo Info
///////////////////////////////////////

////////////////////////////////////////
/// Demand Info
///////////////////////////////////////

LpdbDemand & LpdbDataBase::getDemand(const std::string &airport)
{
  // the server's consumer MUST NOT accept meteo message for unmanaged airports
  assert(r_airportsTable.exists(airport));

  return r_airportsTable[airport].getDemand();
}


LpdbRunwaySystemsMemento LpdbDataBase::createRunwaySystemsMemento() const
{
	//actual RMAN code
	//return LpdbRunwaySystemsMemento(r_runwayTable, r_runwaySystemTable, r_DCBAirportTimeline);

	//temporary code for compilation
	return LpdbRunwaySystemsMemento();
}


void LpdbDataBase::setRunwaySystemsMemento (const LpdbRunwaySystemsMemento & memento)
{
   //r_runwayTable = memento.getRunwaysState();
   //r_runwaySystemTable = memento.getRunwaySystemsState();
}


void LpdbDataBase::generateIntervalProhibitions()
{
   std::vector<string> intervals = r_prohibitionsTimeline.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      generateIntervalProhibitions(interval);
   }
}


void LpdbDataBase::generateIntervalProhibitions(const std::string &interval)
{
  if (r_prohibitionsTimeline.hasData(interval))
  {
    TimeInterval ti = r_prohibitionsTimeline.getTimeInterval(interval);

    r_prohibitionsTimeline[interval].setProhibitions
      (r_adapPreferencesAndProhibitions.getNotAllowedAllocations(ti, ti.begin));
  }
}


void LpdbDataBase::generateIntervalPreferences()
{
   std::vector<string> intervals = r_preferencesTimeline.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      generateIntervalPreferences(interval);
   }
}


void LpdbDataBase::generateIntervalPreferences(const std::string &interval)
{
  if (r_preferencesTimeline.hasData(interval))
  {
    TimeInterval ti = r_preferencesTimeline.getTimeInterval(interval);

    r_preferencesTimeline[interval].setPreferences
      (r_adapPreferencesAndProhibitions.getPrefAllocations(ti, ti.begin));
  }
}

//------------------------------------------------------------------------------

void LpdbDataBase::initAirports(const LpiAdaptationAirportsInfo & airportInfoList,
								const LpiTimeParameters & timeData,
								const boost::posix_time::ptime &now)
{

  AirportVector aplist = airportInfoList.getAirport();
  AirportVector::const_iterator citr;

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << "\t Airport size = " << aplist.size() << std::endl;
#endif

  for (citr=aplist.begin(); citr!=aplist.end(); ++citr)
  {
    //adaptation data
    LpdbAirport nextAirport
      (citr->getAirportName(),
       citr->getComplexityThresholds().getTotalMovAirportUpperThreshold(),
       citr->getComplexityThresholds().getTotalMovAirportLowerThreshold(),
       citr->getComplexityThresholds().getVfrAirportUpperThreshold(),
       citr->getComplexityThresholds().getVfrAirportLowerThreshold(),
       this->getGlobalParameters().getNumberOfIntervalsInHour(),
	   citr->getTaxywaysMaxNominalCapacity(),
	   citr->getTmaMaxNominalCapacity()
      );

    r_airportsTable.addElement(nextAirport.getAirportId(), nextAirport);

    //meteo data
    TimeLine<LpdbMeteoTimedData> init_metline;
    init_metline.initialize(timeData.getMinutesSubinterval(),
			    timeData.getHoursWindow(),
			    timeData.getMinutesFrozen(),
			    now);
    init_metline.fill(); //Populates whole timeline with default timed data
    r_airportsTable[nextAirport.getAirportId()].setMeteoForecast(init_metline);

    //demand data
    TimeLine<LpdbDemandTimedData>  r_timeLine;
    r_timeLine.initialize(timeData.getMinutesSubinterval(),
				timeData.getHoursWindow(),
				timeData.getMinutesFrozen(),
				now);
   r_timeLine.fill();
   r_airportsTable[nextAirport.getAirportId()].getDemand().setTimeLine(r_timeLine);


   //capacity data
   r_airportsTable[nextAirport.getAirportId()].initCapacity(timeData, now);
  }

}

//------------------------------------------------------------------------------
/*
string LpdbDataBase::getEstimatedDCBAsString()
{
   std::stringstream out_stream;

   RunwaySystemTable & rsTable = getRunwaySystemTable();
   LpdbDemand & demandTable = getDemand();
   TimeLine<LpdbDCBAirportTimedData> & airportDCBTimeline = getDCBAirportTimeline();

   if (rsTable.getNumberOfElements() > 0)
   {
      std::vector<string> runway_system_ids = rsTable.getAllIds();
      std::vector<string> time_intervals = demandTable.getTimeLine().getAllIntervalIds();

      BOOST_FOREACH(string rs_id, runway_system_ids)
      {
        out_stream << "[ RS: " << rs_id << "\n";
        out_stream << "[ TML: " << "\n";

        BOOST_FOREACH (string interval, time_intervals)
        {
           if (rsTable.exists(rs_id) && demandTable.has_data(interval))
           {
              LpiADOVector<int> demand = demandTable[interval].getDemandForecast();

              LpdbRunwaySystem   rs = rsTable[rs_id];
              TimeInterval interval_data = demandTable.getTimeLine().getTimeInterval(interval);

              LpiADOVector<int> max_cap = rs[interval].getMaxCapacity();
              LpiADOVector<int> margin = rs[interval].getEstimatedDcMargin();
              LpiADOVector<int> estimated_dly = rs[interval].getEstimatedDelayedFps();
              LpiADOVector<int> estimatedNotAllowed = rs[interval].getNotAllowedEstimatedFPs();

              //Phase III: Get data used in new Estimated DCB calculation for algorithm improvements
              LpiADOVector<int> minDelayedFPsPreviousInterval(0, 0, 0);
              if (interval != "t0")
              {
                 string previousInterval = airportDCBTimeline.getPreviousIntervalId(interval);

                 if (airportDCBTimeline.hasData(previousInterval))
                 {
                    minDelayedFPsPreviousInterval = airportDCBTimeline[previousInterval].getMinDelayedFPs();
                 }
              }


	      LpiADOVector<int> minDelayedFPs;
              LpiADOVector<int> maxAirportCapacity;
              string priorityOperation;

              if (airportDCBTimeline.hasData(interval))
              {
                 maxAirportCapacity = airportDCBTimeline[interval].getMaxAirportCapacity();
                 minDelayedFPs = airportDCBTimeline[interval].getMinDelayedFPs();

                 int operation = airportDCBTimeline[interval].getPriorityOperation();
                 priorityOperation = (operation == E_ARR) ? "E_ARR" : "E_DEP";
              }

              out_stream << interval << "[" << LctimTimeUtils::formatTime(interval_data.begin, "%d/%m/%y %H:%M") << ",";
              out_stream << LctimTimeUtils::formatTime(interval_data.end, "%d/%m/%y %H:%M") << "]: ";
              out_stream << "DEM_FCST : " << demand
                         << " | PRIORITY_OP : " << priorityOperation
                         << " | MAX_AIRPT_CAP : " << maxAirportCapacity;
              out_stream << " | MIN_DLYD_ti-1 : " << minDelayedFPsPreviousInterval
                         << " | MIN_DLYD_ti : " << minDelayedFPs;
              out_stream << " | RS_MAX_CAP : " << max_cap
                         << " | EST_NOT_ALLWD : " << estimatedNotAllowed
                         << " | EST_DCM : " << margin;
              out_stream << " | EDLY : " << estimated_dly << "\n";
            }
        }
        out_stream << "]\n]\n";
      }
   }

   return out_stream.str();
}
*/

string LpdbDataBase::getRunwaysCapacitiesAsString()
{
	return std::string();

/**@todo RTP required ?
 *
   std::stringstream out_stream;

   RunwayTable & rwyTable = getRunwayTable();
   TimeLine<LpdbMeteoTimedData> & meteo_forecast = getMeteoForecast();


   if (rwyTable.getNumberOfElements() > 0)
   {

      std::vector<string> runway_ids = rwyTable.getAllIds();
      std::vector<string> time_intervals = meteo_forecast.getAllIntervalIds();

      BOOST_FOREACH(string rwy_id, runway_ids)
      {
         if (rwyTable.exists(rwy_id))
         {
            LpdbRunway & runway = rwyTable[rwy_id];

            out_stream << "[ RWY: " << rwy_id << "| MAX_ILS: "
                       << LpiMaxILSCategory::getEnumAsString(runway.getCatIls())<< "\n";

            out_stream << "[ TML: " << "\n";

            BOOST_FOREACH (string interval, time_intervals)
            {
               if (runway.has_data(interval) && meteo_forecast.hasData(interval))
               {
                  bool availability  =  runway[interval].isNonAvailability();
                  string avail_period = availability ? "YES" : "NO";

                  boost::optional<std::string> ilsCategory = meteo_forecast[interval].getIlsCategory();

                  LpiADOVector<double> crosswindReduction = runway[interval].getCrosswindCapacityReduction();
                  LpiADOVector<double> tailwindReduction = runway[interval].getTailwindCapacityReduction();
                  LpiADOVector<double> horizontalVisibilityReduction = runway[interval].getVisibilityCapacityReduction();
                  LpiADOVector<double> meteoReduction = runway[interval].getMetCapacityReduction();

                  LpiADOVector<int>   max_cap = runway[interval].getMaxCapacity();

                  TimeInterval interval_data = meteo_forecast.getTimeInterval(interval);

                  out_stream << interval << "[" << LctimTimeUtils::formatTime(interval_data.begin, "%d/%m/%y %H:%M") << ",";
                  out_stream << LctimTimeUtils::formatTime(interval_data.end, "%d/%m/%y %H:%M") << "]: ";
                  out_stream << "NON_AV_PER : " << avail_period;

                  if (ilsCategory)
                  {
                     out_stream << " | REQ_ILS : " << *ilsCategory;
                  }
                  out_stream << " | CW_%RED: " << crosswindReduction << " | TW_%RED : " << tailwindReduction;
                  out_stream << " | HV_%RED: " << horizontalVisibilityReduction << " | MET_%RED: " << meteoReduction;
                  out_stream << " | RWY_MAX_CAP : " << max_cap << "\n";
               }
            }
            out_stream << "]\n]\n";
         }
      }
   }

   return out_stream.str();
   */
}


string LpdbDataBase::getRunwaySystemRunwaysCapacitiesAsString()
{

   std::stringstream out_stream;

   RunwaySystemTable & rsTable = getRunwaySystemTable();
   RunwayTable & runwayTable = getRunwayTable();


   if (rsTable.getNumberOfElements() > 0)
   {

      std::vector<string> runway_system_ids = rsTable.getAllIds();

      BOOST_FOREACH(string rs_id, runway_system_ids)
      {
         if (rsTable.exists(rs_id))
         {
            LpdbRunwaySystem rs = rsTable[rs_id];

            out_stream << "[ ID: " << rs_id << " | CFG :" << rs.getConfiguration();

            typedef map<string, LpdbRunwaySystemRunway>::value_type value_pair;
            map<string, LpdbRunwaySystemRunway> runways = rs.getRunways();

            BOOST_FOREACH(value_pair & rs_rwy, runways)
            {
               out_stream << " [RWY : "  << rs_rwy.second.getId() << "| USG: " << rs_rwy.second.getUse() << ']' << '\n';
               out_stream << "[ TML: " << "\n";

               std::vector<string> time_intervals = rs_rwy.second.getTimeLine().getAllIntervalIds();

               if (runwayTable.exists(rs_rwy.first))
               {
                  LpdbRunway runway = runwayTable[rs_rwy.first];

                  BOOST_FOREACH (string interval, time_intervals)
                  {
                     if (rs_rwy.second.has_data(interval) && runway.has_data(interval))
                     {
                        TimeInterval interval_data = rs_rwy.second.getTimeLine().getTimeInterval(interval);

                        LpiADOVector<int> rwy_max_cap = runway[interval].getMaxCapacity();
                        LpiADOVector<int> max_cap = rs_rwy.second[interval].getMaxCapacity();
                        LpiADOVector<int> max_cap_calculated = rs_rwy.second[interval].getMaxCapacityCalculated();
                        LpiADOVector<double> dep_cap_reduction  = rs_rwy.second[interval].getDependencyCapacityReduction();
                        LpiADOVector<double> file_cap_reduction = rs_rwy.second[interval].getFileCapacityReduction();
                        LpiADOVector<double> wtc_capacity_reduction = rs_rwy.second[interval].getWakeVortexCapacityReduction();

                        out_stream << interval << "[" << LctimTimeUtils::formatTime(interval_data.begin, "%d/%m/%y %H:%M") << ",";
                        out_stream << LctimTimeUtils::formatTime(interval_data.end, "%d/%m/%y %H:%M") << "]: ";

                        out_stream << "RWY_MAX_CAP : " << rwy_max_cap << " | DEP_%RED : " << dep_cap_reduction;
                        out_stream << " | RS_RWY_MAX_CAP_CALC: " << max_cap_calculated << " | FILE_%RED : " << file_cap_reduction;
                        out_stream << " | RS_RWY_MAX_CAP: " << max_cap << "\n";
                        out_stream << " | WTC_%RED : " << wtc_capacity_reduction <<" | RS_RWY_MAX_CAP: " << max_cap << "\n";

                     }
                  }
               }
               out_stream << "]\n]\n";
            }

            out_stream << "]" << std::endl;
         }
      }
   }

   return out_stream.str();
}


string LpdbDataBase::getRunwaySystemsCapacitiesAsString()
{
 return std::string();

	/**@todo RTP required ?   Now RMAN's code

  std::stringstream out_stream;

   RunwaySystemTable & rsTable = getRunwaySystemTable();
   TimeLine<LpdbMeteoTimedData> & meteo_forecast = getMeteoForecast();
   LpdbTMA & tma = getTMA();
   LpdbTWY & twy = getTWY();

   if (rsTable.getNumberOfElements() > 0)
   {
      std::vector<string> runway_system_ids = rsTable.getAllIds();


      BOOST_FOREACH(string rs_id, runway_system_ids)
      {
         if (rsTable.exists(rs_id))
         {
            LpdbRunwaySystem rs = rsTable[rs_id];

            bool lvpFeasibility = rs.isLvpFeasibility();
            string lvp = lvpFeasibility ? "YES" : "NO";

            out_stream << "[ ID: " << rs_id << " | LVP_FEA :" << lvp;
            out_stream << "[ TML: " << "\n";

            std::vector<string> time_intervals = rs.getTimeLine().getAllIntervalIds();

            BOOST_FOREACH (string interval, time_intervals)
            {
               if (rs.has_data(interval))
               {
                  TimeInterval interval_data = rs.getTimeLine().getTimeInterval(interval);

                  boost::optional<bool> is_lvp;
                  string lvp_activation = "NO";

                  if (meteo_forecast.hasData(interval))
                  {
                     is_lvp = meteo_forecast[interval].getLvpActivation();

                     if (is_lvp)
                     {
                        lvp_activation = *is_lvp ? "YES" : "NO";
                     }
                  }

                  LpiADOVector<double> tma_cap;
                  LpiADOVector<double> twy_cap;

                  if (tma.has_data(interval))
                  {
                     tma_cap = tma[interval].getCapacity();
                  }

                  if (twy.has_data(interval))
                  {
                     twy_cap = twy[interval].getCapacity();
                  }

                  LpiADOVector<int> rs_runways_max_cap = rs[interval].getRwysMaxCapacity();
                  LpiADOVector<int> rs_max_cap = rs[interval].getMaxCapacity();

                  out_stream << interval << "[" << LctimTimeUtils::formatTime(interval_data.begin, "%d/%m/%y %H:%M") << ",";
                  out_stream << LctimTimeUtils::formatTime(interval_data.end, "%d/%m/%y %H:%M") << "]: ";

                  out_stream << "LVP_ACT : " << lvp_activation << " | RS_RWYS_MAX_CAP : " << rs_runways_max_cap;
                  out_stream << " | TMA_CAP: " << tma_cap << " | TWY_CAP : " << twy_cap;
                  out_stream << " | RS_MAX_CAP: " << rs_max_cap << "\n";
               }
            }

            out_stream << "]\n";
         }
      }
      out_stream << "]" << std::endl;
   }

   return out_stream.str();

*/
}


string LpdbDataBase::getRunwayAllocationsAsString()
{
   std::stringstream out_stream;

   ScheduleTable & schTable = getScheduleTable();

   FPTable & fpTable = getFPTable();

   if (schTable.getNumberOfElements() > 0)
   {
      std::vector<int> all_schedule_ids = schTable.getAllIds();

      BOOST_FOREACH (int schedule_id, all_schedule_ids)
      {
         if (schTable.exists(schedule_id))
         {
            out_stream << "SCHEDULE " << schedule_id << "\n";

            LpdbSchedule schedule = schTable[schedule_id];

            std::vector<string> time_intervals = schedule.getTimeLine().getAllIntervalIds();

            BOOST_FOREACH (string interval, time_intervals)
            {
               if (schedule.has_data(interval))
               {
                  TimeInterval interval_data = schedule.getTimeLine().getTimeInterval(interval);

                  LpdbRSScheduled rs_scheduled = schedule[interval].getRsScheduled();
                  string rs_name = rs_scheduled.getRunwaySystemId();

                  std::map<std::string, LpdbRwyScheduled> runways = rs_scheduled.getRunways();

                  typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_data;

                  BOOST_FOREACH (rwy_data & runway, runways)
                  {
                     out_stream << interval << "[" << LctimTimeUtils::formatTime(interval_data.begin, "%d/%m/%y %H:%M") << ",";
                     out_stream << LctimTimeUtils::formatTime(interval_data.end, "%d/%m/%y %H:%M") << "]: ";

                     string runway_name = runway.second.getRwyId();
                     OperationType::Enum usage = runway.second.getUsage();

                     LpiADOVector<int> allocated = runway.second.getNumberOfAllocatedFps();
                     LpiADOVector<std::vector<string> > allocated_fp_ids = runway.second.getAllocatedFpsFps();

                     LpiADOVector<int> delayed = runway.second.getNumberOfDelayedFps();
                     LpiADOVector<std::vector<string> > delayed_fp_ids = runway.second.getDelayedFpsFps();

                     out_stream << "[RS : " << rs_name << "][RWY: " << runway_name << " | USE: " << usage;
                     out_stream << " | ALLOC_FPs: " << allocated << " | DLYD_FPs:" << delayed;
                     out_stream << " | ALLOC_FP_FPs: ";

                     for (int i = E_ARR ; i <= E_OVA; ++i)
                     {
                        switch (i)
                        {
                            case E_ARR:
                               out_stream << "[A: ";
                               break;
                            case E_DEP:
                               out_stream << "|D: ";
                               break;
                            case E_OVA:
                               out_stream << "|O: ";
                               break;
                            default:
                               break;
                        }
                        BOOST_FOREACH(string fpKey, allocated_fp_ids[i])
                        {
                           if (fpTable.exists(fpKey))
                           {
                              out_stream << fpTable[fpKey].getCallsign() << ", ";
                           }
                        }
                     }
                     out_stream << "]";

                     out_stream << " | DLYD_FP_FPs: ";

                     for (int i = E_ARR ; i <= E_OVA; ++i)
                     {
                        switch (i)
                        {
                            case E_ARR:
                               out_stream << "[A: ";
                               break;
                            case E_DEP:
                               out_stream << "|D: ";
                               break;
                            case E_OVA:
                               out_stream << "|O: ";
                               break;
                            default:
                               break;
                        }
                        BOOST_FOREACH(string fpKey, delayed_fp_ids[i])
                        {
                           if (fpTable.exists(fpKey))
                           {
                              out_stream << fpTable[fpKey].getCallsign() << ", ";
                           }
                        }
                     }
                     out_stream << "]";
                     out_stream << "]\n";
                  }
               }
            }
         }
      }
   }

   return out_stream.str();
}


string LpdbDataBase::getRunwayFinalAssignationAsString()
{
   std::stringstream out_stream;

   FPTable flightPlansTable = getFPTable();

   if (flightPlansTable.getNumberOfElements() > 0)
   {
      std::vector<string> all_fp_ids = flightPlansTable.getAllIds();

      BOOST_FOREACH (string fp_id, all_fp_ids)
      {
         if (flightPlansTable.exists(fp_id))
         {
            LpiFlightPlan fp = flightPlansTable[fp_id];

            string departure_runway = fp.getDepartureRunway();
            string arrival_runway   = fp.getArrivalRunway();

            if (!departure_runway.empty() || !arrival_runway.empty())
            {
               out_stream << "[" << fp.getCallsign() << "| " << fp.getOperationType() << "]: ";

               switch (fp.getOperationType())
               {
                  case LpiOperationType::E_ARRIVAL:
                     out_stream << arrival_runway;
                  break;

                  case LpiOperationType::E_DEPARTURE:
                     out_stream << departure_runway;
                  break;

                  case LpiOperationType::E_NONE:
                  break;
               }

               out_stream << "]\n";
            }
         }
      }

   }

   return out_stream.str();
}


string LpdbDataBase::getAlternativeScheduleRwyAllocationsAsString(int scheduleId)
{
   std::stringstream out_stream;

   LpdbSchedule schedule;
   bool scheduleExists = false;

   if ((scheduleId == -1) && hasActiveSchedule())
   {
      out_stream << "[ACTIVE SCHEDULE RUNWAY ALLOCATION]\n";

      schedule = getActiveSchedule();

      scheduleExists = true;
   }
   else if (r_alternativeSchedulesTable.exists(scheduleId))
   {
      out_stream << "[ALTERNATIVE SCHEDULE (id = " << scheduleId << ") RUNWAY ALLOCATION]\n";

      schedule = r_alternativeSchedulesTable[scheduleId];

      scheduleExists = true;
   }

   if (scheduleExists)
   {
      FPTable & fpTable = getFPTable();

      std::vector<string> time_intervals = schedule.getTimeLine().getAllIntervalIds();

      BOOST_FOREACH (string interval, time_intervals)
      {
         if (schedule.has_data(interval))
         {
            TimeInterval interval_data = schedule.getTimeLine().getTimeInterval(interval);

            LpdbRSScheduled rs_scheduled = schedule[interval].getRsScheduled();
            string rs_name = rs_scheduled.getRunwaySystemId();

            std::map<std::string, LpdbRwyScheduled> runways = rs_scheduled.getRunways();

            typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_data;

            BOOST_FOREACH (rwy_data & runway, runways)
            {
               out_stream << interval << "[" << LctimTimeUtils::formatTime(interval_data.begin, "%d/%m/%y %H:%M") << ",";
               out_stream << LctimTimeUtils::formatTime(interval_data.end, "%d/%m/%y %H:%M") << "]: ";

               string runway_name = runway.second.getRwyId();
               OperationType::Enum usage = runway.second.getUsage();

               LpiADOVector<int> allocated = runway.second.getNumberOfAllocatedFps();
               LpiADOVector<std::vector<string> > allocated_fp_ids = runway.second.getAllocatedFpsFps();

               LpiADOVector<int> delayed = runway.second.getNumberOfDelayedFps();
               LpiADOVector<std::vector<string> > delayed_fp_ids = runway.second.getDelayedFpsFps();

               out_stream << "[RS : " << rs_name << "][RWY: " << runway_name << " | USE: " << usage;
               out_stream << " | ALLOC_FPs: " << allocated << " | DLYD_FPs:" << delayed;
               out_stream << " | ALLOC_FP_FPs: ";

               for (int i = E_ARR ; i <= E_OVA; ++i)
               {
                  switch (i)
                  {
                     case E_ARR:
                        out_stream << "[A: ";
                        break;
                     case E_DEP:
                        out_stream << "|D: ";
                        break;
                     case E_OVA:
                        out_stream << "|O: ";
                        break;
                     default:
                        break;
                  }
                  BOOST_FOREACH(string fpKey, allocated_fp_ids[i])
                  {
                     if (fpTable.exists(fpKey))
                     {
                        out_stream << fpTable[fpKey].getCallsign() << ", ";
                     }
                  }
               }
               out_stream << "]";

               out_stream << " | DLYD_FP_FPs: ";

               for (int i = E_ARR ; i <= E_OVA; ++i)
               {
                    switch (i)
                    {
                       case E_ARR:
                          out_stream << "[A: ";
                          break;
                       case E_DEP:
                          out_stream << "|D: ";
                          break;
                       case E_OVA:
                          out_stream << "|O: ";
                          break;
                       default:
                          break;
                    }
                    BOOST_FOREACH(string fpKey, delayed_fp_ids[i])
                    {
                       if (fpTable.exists(fpKey))
                       {
                          out_stream << fpTable[fpKey].getCallsign() << ", ";
                       }
                    }
               }
               out_stream << "]";
               out_stream << "]\n";
             }
         }
      }
   }

   return out_stream.str();
}


// Second parameter is used in cast typ_of_schedule is E_ALTERNATIVE,
// will be the index of what-if generated schedule

string LpdbDataBase::getScheduledFlightPlansAsString(LpdbSchedule::ScheduleType type_of_schedule, int schedule_index)
{
   std::stringstream sOutput;

   LpdbSchedule schedule;          //Schedule to get string with flight plans
   bool schedule_available = false;

   string header;

   switch (type_of_schedule)
   {
      case LpdbSchedule::E_OPTIMAL:
         header=  "Optimal";

         if (r_schedulesTable.exists(schedule_index))
         {
            schedule = r_schedulesTable[schedule_index];
            schedule_available = true;
         }
      break;
      case LpdbSchedule::E_ACTIVE:
         header = "Active";

         if (r_hasActiveSchedule)
         {
            schedule = static_cast<LpdbSchedule>(r_activeSchedule);
            schedule_available = true;
         }
      break;
      case LpdbSchedule::E_ALTERNATIVE:
         header = "Alternative (id = " + boost::lexical_cast<std::string>(schedule_index) + ")";

         if (r_alternativeSchedulesTable.exists(schedule_index))
         {
            schedule = static_cast<LpdbSchedule>(r_alternativeSchedulesTable[schedule_index]);
            schedule_available = true;
         }
      break;
   }

   if (schedule_available)
   {
      typedef map<string, LpdbFPSchedule>::value_type  scheduledFP;
      map<string, LpdbFPSchedule> scheduledFlightPlans = schedule.getScheduleFps();

      sOutput << header << " Scheduled FPs:\n[ " << std::endl;

      sOutput << "[Available FTOT and FLDTs:\n";
      sOutput << schedule.getAvailableFTOTAndFLDTsAsString();
      sOutput << "]\n";

      BOOST_FOREACH(scheduledFP & flightPlan, scheduledFlightPlans)
      {
          sOutput << getScheduledFPAsString(flightPlan.second);

          sOutput << "| Assigned Runway:" << flightPlan.second.getAssignedRunway();
          sOutput << "]";
      }
      sOutput << "]\n\n";

      map<string, LpdbFPSchedule> delayedLastInterval = schedule.getDelayedFpsInLastInterval();

      if (delayedLastInterval.size())
      {
         sOutput << "Delayed in last interval:\n";

         BOOST_FOREACH(scheduledFP & flightPlan, delayedLastInterval)
         {
            sOutput << getScheduledFPAsString(flightPlan.second);
         }
         sOutput << "]\n\n";
      }

     std::vector<string> all_fp_keys = r_fpsTable.getAllIds();

     sOutput << "Non Scheduled FPs:\n[" ;
     BOOST_FOREACH(string fp_key, all_fp_keys)
     {
         if (r_fpsTable.exists(fp_key))
         {
            LpiFlightPlan fp = r_fpsTable[fp_key];

            if ((scheduledFlightPlans.count(fp_key) == 0) &&
                (delayedLastInterval.count(fp_key) == 0))
            {
               if(fp.getIldt())
               {
                  sOutput << "\n[Callsign: " << fp.getCallsign() << " | ILDT:" << *fp.getIldt() << "]" ;
               }
               else if(fp.getItot())
               {
                  sOutput << "\n[Callsign: " << fp.getCallsign() << " | ITOT:" << *fp.getItot() <<  "]";
               }
            }
         }
     }
     sOutput <<"]\n" ;
   }

   return sOutput.str();
}


string LpdbDataBase::getScheduledFPAsString(const LpdbFPSchedule & flightPlan)
{
   std::stringstream sOutput;

   sOutput << "\n[Callsign: " << flightPlan.getCallsign();

   sOutput << "| Operation Type: " << flightPlan.getOperationType();

   if(flightPlan.getOperationType() == LpiOperationType::E_DEPARTURE)
   {
      if (flightPlan.getEobt())
      {
         sOutput << "| EOBT: " << *flightPlan.getEobt();
      }
      if(flightPlan.getItot())
      {
         sOutput << "| ITOT: " << *flightPlan.getItot();
      }
      if(flightPlan.getStot())
      {
         sOutput << "| STOT: " << *flightPlan.getStot();
      }
      if(flightPlan.getFtot())
      {
         sOutput << "| FTOT: " << *flightPlan.getFtot();
      }
      if(flightPlan.getToForecastedDelay())
      {
         sOutput << "| Forecast Delay:" <<  *flightPlan.getToForecastedDelay();
      }
      if(flightPlan.getToPunctualityDelay())
      {
         sOutput << "| Punctuality Delay:" << *flightPlan.getToPunctualityDelay();
      }
    }
    else if(flightPlan.getOperationType() == LpiOperationType::E_ARRIVAL)
    {
       if (flightPlan.getEobt())
       {
          sOutput << "| EOBT: " << *flightPlan.getEobt();
       }
       if(flightPlan.getIldt())
       {
          sOutput << "| ILDT: " << *flightPlan.getIldt();
       }
       if(flightPlan.getSldt())
       {
          sOutput << "| SLDT: " << *flightPlan.getSldt();
       }
       if(flightPlan.getFldt())
       {
          sOutput << "| FLDT: " << *flightPlan.getFldt();
       }
       if(flightPlan.getLdForecastedDelay())
       {
          sOutput << "| Forecast Delay:" <<  *flightPlan.getLdForecastedDelay();
       }
       if(flightPlan.getLdPunctualityDelay())
       {
          sOutput << "| Punctuality Delay:" << *flightPlan.getLdPunctualityDelay();
       }
    }

   sOutput << " | Turn-round delayed: ";
   if (flightPlan.getTurnRoundDelayed())
   {
      sOutput << "true";
   }
   else
   {
      sOutput << "false";
   }

   return sOutput.str();
}


string LpdbDataBase::getScheduleInterfaceAsString(LpiSchedule & schedule, LpdbSchedule::ScheduleType type_of_schedule)
{
   std::stringstream outRS;
   std::stringstream outConfiguration;

   switch (type_of_schedule)
   {
      case LpdbSchedule::E_OPTIMAL:
         outRS << "OPTIMAL";
         break;
      case LpdbSchedule::E_ACTIVE:
         outRS << "ACTIVE";
         break;
      case LpdbSchedule::E_ALTERNATIVE:
         outRS << "ALTERNATIVE";
         break;
   }

   outRS << " SCHEDULE INTERFACE (ORIGIN: " << schedule.getOrigin() << ")\n" << "\nPLANNED RS:\n" << "[";

   outConfiguration << "\n\nPLANNED CONFIGURATION:\n" << "[";

   std::vector<LpiTimeIntervalData> schedule_plan = schedule.getScheduleTimeLine().getAllScheduleIntervals();

   //Timed Interval Data
   std::stringstream out;
   out << "KPIs:\n\n";

   for (unsigned int i = 0; i < schedule_plan.size(); ++i)
   {
      LpiTimeIntervalData plannedScheduleInterval = schedule.getScheduleTimeLine().getScheduleInterval(i);

      string beginTime = plannedScheduleInterval.getBeginTime();
      string endTime = plannedScheduleInterval.getEndTime();

      LpiRS_Scheduled plannedRS = plannedScheduleInterval.getRSScheduled();

      outRS << "t" << i << ": [" << beginTime << ", " << endTime << "]: "
            << plannedRS.getRunwaySystem() << ((i < schedule_plan.size() - 1) ? " |" : "");

      outConfiguration << "t" << i << ": [" << beginTime << ", " << endTime << "]: "
                       << plannedRS.getConfiguration()
                       << ((i < schedule_plan.size() - 1) ? " |" : "");

      LpiScheduleDemand demandData = plannedScheduleInterval.getDemand();

      //Runway Interval
      out << "t" << i << ":[" << beginTime << ", " << endTime << "]:"
          << "INH_DMND: " << demandData.rInheritedDemand
          << "| INTENT_DMND: " << demandData.rIntentionalDemand
          << "| TOT_DMND: " << demandData.rTotalDemand << "\n"
          << "[RUNWAY KPIs:  " << "\n";

      std::vector<LpiRunwayIntervalKPIs> performanceRunways = schedule.getPerformanceInfo().getPerformanceIntervalData(i).getRwysKPIs();
      std::vector<LpiRunwayIntervalCapacityInfo> capacitiesRunways = schedule.getCapacityInfo().getCapacityIntervalData(i).getAllRwysCapacities();

      int numberOfRunways = performanceRunways.size();
      for (int j = 0; j < numberOfRunways; j++)
      {
         LpiRunwayIntervalKPIs runwayIntervalKPIsData = performanceRunways[j];
         LpiRunwayIntervalCapacityInfo runwayIntervalCapacityData = capacitiesRunways[j];

         out << "[RWY:" << runwayIntervalKPIsData.getrwyName() << '\n'
             << "\tTHROUGHPUT: "
             << "RWY_CAP: " << runwayIntervalCapacityData.getrwyCapacity() << "-" << runwayIntervalCapacityData.getrwyCapacityWA()
             << " | ACCPT_FPs: " << runwayIntervalKPIsData.getrwyRealAcceptedFps()
             << " | SHTG: " << runwayIntervalKPIsData.getrwyShortage()
                            << "-" << runwayIntervalKPIsData.getrwyShortageWA() << "\n"
             << "\tDELAY: "
             << "| DMND_FCST: " << runwayIntervalKPIsData.getRwyDemandForecast()
             << "| NUM_DLYD_FPs: " << runwayIntervalKPIsData.getRwyNumberOfDelayedFlights()
             << "| ACCPT_INTENT: " << runwayIntervalKPIsData.getRwyAcceptedFpsOwnInterval()
             << "| MAX_FCST_DLY: " << runwayIntervalKPIsData.getRwyMaxForecastedDelay()
                                   << "-" << runwayIntervalKPIsData.getRwyMaxForecastedDelayWA()
             << "| AVG_FCST_DLY: " << runwayIntervalKPIsData.getRwyAverageForecastedDelay()
             << "| AVG_FCST_DLY_DLYD: " << runwayIntervalKPIsData.getRwyAverageDelay_DelayedFPs()
                                        << "-" << runwayIntervalKPIsData.getRwyAverageDelay_DelayedFPsWA()
             << "| NOT_PUNCT: " << runwayIntervalKPIsData.getRwyNotPunctualFlights()
             << "| PUNCT: " << runwayIntervalKPIsData.getRwyPunctualFlights()
             << "| % PUNCT: " << runwayIntervalKPIsData.getRwyPercentagePunctuality()
                              << "-" << runwayIntervalKPIsData.getRwyPercentagePunctualityWA()
             << "]" << "\n";
      }

      //Aerodrome Interval
      LpiAirportIntervalKPIs airportKPIs = schedule.getPerformanceInfo().getPerformanceIntervalData(i).getAirportIntevalKPIs();
      LpiAirportIntervalCapacityInfo airportCapacities = schedule.getCapacityInfo().getCapacityIntervalData(i).getAirportCapacities();

      out << "[ AERODROME KPIs:" << "\n"
          << "\tTHROUGHPUT: "
          << "AER_CAP: "  << airportCapacities.getmaxCapacity() << "-" << airportCapacities.getmaxCapacityWA()
          << "| RS_CAP: "  << airportCapacities.getrsCapacity() << "-" << airportCapacities.getrsCapacityWA()
          << "| REAL_ACCPT: "  << airportKPIs.getrealAcceptedFps()
          << "| SHTG: "  << airportKPIs.getshortage() << "-" << airportKPIs.getshortageWA() << '\n'
          << "\tDELAY: "
          << "TOTAL_RWYS_DMND_FCST: " << airportKPIs.getTotalRunwaysDemandForecast()
          << "| MAX_FCST_DLY: " << airportKPIs.getMaxForecastedDelay() << "-" << airportKPIs.getMaxForecastedDelayWA()
          << "| AVG_FCST_DLY_DLYD: " << airportKPIs.getAverageForecastedDelay_DelayedFPs()
                                             << "-" << airportKPIs.getAverageForecastedDelay_DelayedFPsWA()
          << "| PUNCT: " << airportKPIs.getPunctuality()
          << "| % PUNCT: " << airportKPIs.getPercentagePunctuality() << "-" << airportKPIs.getPercentagePunctualityWA()
          << "\n]" << "\n\n";

      out << "]\n";
   }

   out << "\n";

   
   // Phase V: Runway Total Window KPIs  ///@warnign RMAN CODE
   // std::vector<LpiRunwayWindowKPIs> allRunwayWindowKPIs = schedule.getPerformanceInfo().getRunwayWindowKPIs();
   // std::stringstream outRunwayWindowKPIs;

   // outRunwayWindowKPIs << "[RUNWAY TOTAL KPIs:\n";
   // for (unsigned int i = 0; i < allRunwayWindowKPIs.size(); ++i)
   // {
   //    outRunwayWindowKPIs << allRunwayWindowKPIs[i] << '\n';
   // }
   // outRunwayWindowKPIs << "\n]\n";

   LpiAirportTotalKPIs totalKPIs = schedule.getPerformanceInfo().getAirportTotalKPIs();

   std::stringstream outThroughput;
   outThroughput << "[AIRPORT TOTAL THROUGHPUT KPIs:\n "
                 << "TOTAL_ACCPT:" << totalKPIs.getTotalAccepted()
                 << " | TOTAL_SHTG: " << totalKPIs.getTotalShortage()
                 << "\n]\n";

   //Total absolute: Delays
   std::stringstream outdelays;
   outdelays << "[AIRPORT TOTAL DELAY KPIs:\n ";

   outdelays << "TOTAL_DLYD: " << totalKPIs.getdelayedFPs()
             << " | MAX_FCST_DLY: " << totalKPIs.getmaxForecastedDelay()
                                    << "-" << totalKPIs.getmaxForecastedDelayWA()
             << " | AVG_FCST_DLY: " << totalKPIs.getaverageForecastedDelay()
                                    << "-" << totalKPIs.getaverageForecastedDelayWA()
             << " | MAX_PUNCT_DLY: " << totalKPIs.getmaxPunctualityDelay()
                                     << "-" << totalKPIs.getmaxPunctualityDelayWA()
             << " | AVG_PUNCT_DLY: " << totalKPIs.getaveragePunctualityDelay()
                                     << "-" << totalKPIs.getaveragePunctualityDelayWA()
             << " | PUNCT: " << totalKPIs.getpunctualFPs()
             << " | % PUNCT: " << totalKPIs.getpercentagePunctual()
                               << "-" << totalKPIs.getpercentagePunctualWA()
             << " | AVG_FCST_DLY_DLYD: " << totalKPIs.getAverageForecastedDelayDelayedFps()
                                         << "-" << totalKPIs.getAverageForecastedDelayDelayedFpsWA()
             << "\n]\n\n";

   //Delta and Relative KPIs
   LpiComparativeKpis comparativeKPIs = schedule.getPerformanceInfo().getComparativeKPIs();

   std::stringstream comparativeKPIsStream;
   comparativeKPIsStream << "[COMPARATIVE KPIs:\n";

   std::vector<LpiIntervalKpi> intervalData = comparativeKPIs.getKpisPerInterval();

   for(unsigned int i = 0; i < intervalData.size() ; ++i)
   {
      LpiIntervalKpi data = intervalData[i];
      comparativeKPIsStream << "t" << i << ":[ " << data.getStartTimeAndDate() << ", " << data.getEndTimeAndDate() << "]\n";

      //Delta KPIs
      LpiIntervalDataKpis deltaKPIs = data.getDeltaKpis();
      comparativeKPIsStream << "\t[DELTA KPIs: " << deltaKPIs << "]\n";

      //Relative KPIs
      if ((type_of_schedule == LpdbSchedule::E_ACTIVE) || (type_of_schedule == LpdbSchedule::E_ALTERNATIVE))
      {
         LpiIntervalDataKpis relativeKPIs = data.getRelativeKpis();
         comparativeKPIsStream << "\t[RELAT KPIs: " << relativeKPIs << "]\n";
      }
   }

   comparativeKPIsStream << "]\n\n";

   outRS << "]\n";
   outConfiguration<< "]\n\n";

   return (outRS.str() +
           outConfiguration.str() +
           out.str() +
	   //           outRunwayWindowKPIs.str() +
           outThroughput.str() +
           outdelays.str() +
           comparativeKPIsStream.str());
}


string LpdbDataBase::getCapacityReductionsAsString(const std::vector<string> & ids_rwys)
{
return std::string();


	/**@todo RTP required ?   Now RMAN's code

  unsigned int i=0;
   std::stringstream sOutput;

   std::vector<string> intervals= LpdbDataBase::Get().getTMA().getTimeLine().getAllIntervalIds();
   LpdbDataBase::RunwayTable &  runwayTable=LpdbDataBase::Get().getRunwayTable();

   std::vector<string> ids_runways= runwayTable.getAllIds();
   sOutput << "CapacityReductions\n " ;
   if (ids_rwys.size() > 0)
   {
      sOutput << "\nCapacityReductions RUNWAY \n";

     for(i=0; i< ids_rwys.size(); ++i)
     {
        if (runwayTable.exists(ids_rwys[i]))
        {
           LpdbRunway runway = runwayTable[ids_rwys[i]];
           sOutput  << "Runway: " ;
           sOutput  << ids_rwys[i] ;
           sOutput  << "\n";

           BOOST_FOREACH(string ti,intervals)
           {
              sOutput  << runway[ti].getManualCapacityReduction();
              sOutput  << "\n";
           }

        }

     }
   }

   i=0;
   BOOST_FOREACH(string ti, intervals)
   {
     TimeInterval time_interval = LpdbDataBase::Get().getTMA().getTimeLine().getTimeInterval(ti);
     sOutput << "\n" <<ti << ": [" << LctimTimeUtils::formatTime(time_interval.begin, "%d/%m/%y %H:%M") << ", "
                                   << LctimTimeUtils::formatTime(time_interval.end, "%d/%m/%y %H:%M") << "]: ";
     sOutput << "TMA Reductions: " ;
     sOutput << LpdbDataBase::Get().getTMA().getManualCapacityReductionScheduled()[i] << ", ";
     sOutput << "TWY Reductions: " ;
     sOutput << LpdbDataBase::Get().getTWY().getManualCapacityReductionScheduled()[i] << ", ";
     sOutput << "Non Availability Runways [" ;
     BOOST_FOREACH(std::string id, ids_runways)
     {
      int k =runwayTable[id].getNonAvailabilityScheduled().size();
      sOutput << "Runway " << id;
      sOutput << ": " ;
      if(k>0)
      {
         if(runwayTable[id].getNonAvailabilityScheduled()[i] == 0)
         {
             sOutput << "NO, ";
         }
         else
         {
             sOutput << "YES, ";
         }
         sOutput << " | ";
       }

     }
     sOutput << "]" << std::endl;


    i++;
  }
  return sOutput.str();

	 */
}


string LpdbDataBase::getRealAcceptedAndShortageAsString(int schedule_id)
{
   std::stringstream out_streamAccepted;
   std::stringstream out_streamShortage;

   ScheduleTable & schTable = getScheduleTable();

   if (schTable.exists(schedule_id))
   {
      LpdbSchedule schedule = schTable[schedule_id];
      std::vector<string> intervals = schedule.getTimeLine().getAllIntervalIds();


      out_streamAccepted << "\nReal Accepted FPs: [";
      out_streamShortage << "\nShortage: [";
      BOOST_FOREACH(string interval, intervals)
      {
         TimeInterval time_interval = schedule.getTimeLine().getTimeInterval(interval);
         out_streamAccepted <<  interval;
         out_streamAccepted << ": [";
         out_streamAccepted <<   LctimTimeUtils::formatTime(time_interval.begin, "%d/%m/%y %H:%M");
         out_streamAccepted << ", " << LctimTimeUtils::formatTime(time_interval.end, "%d/%m/%y %H:%M");
         out_streamAccepted << "]";
         out_streamAccepted << schedule.getTimeLine()[interval].getRealAcceptedFps()<< ", ";


         out_streamShortage <<  interval;
         out_streamShortage << ": [";
         out_streamShortage <<   LctimTimeUtils::formatTime(time_interval.begin, "%d/%m/%y %H:%M");
         out_streamShortage << ", " << LctimTimeUtils::formatTime(time_interval.end, "%d/%m/%y %H:%M");
         out_streamShortage << "]";
         out_streamShortage << schedule.getTimeLine()[interval].getRealDelayedFps()<< ", ";
      }
      out_streamAccepted << "]";
      out_streamAccepted << "\n";
      out_streamAccepted << "\nTotal Real Accepted FPs:   ";
      out_streamAccepted << schedule.getAccepted() ;
      out_streamAccepted << "\n";

      out_streamShortage << "]";
      out_streamShortage << "\n";
      out_streamShortage << "\nTotal Shortage:            ";
      out_streamShortage << schedule.getShortage() ;
      out_streamShortage << "\n";
   }

   return (out_streamAccepted.str() + out_streamShortage.str());
}


string LpdbDataBase::getMaxAndAverageKPIsAsString(int schedule_id)
{
   std::stringstream out_stream;

   ScheduleTable & schTable = getScheduleTable();

   if (schTable.exists(schedule_id))
   {
      LpdbSchedule schedule = schTable[schedule_id];
      out_stream << "\n";
      out_stream << "Max. Forecasted Delay:     " << schedule.getMaxForecastDelay();
      out_stream << "\n";
      out_stream << "Average Forecasted Delay:  " << schedule.getAverageForecastDelay();
      out_stream << "\n";
      out_stream << "Max. Punctuality Delay:     " << schedule.getMaxPunctualityDelay();
      out_stream << "\n";
      out_stream << "Average Punctuality Delay: " << schedule.getAveragePunctualityDelay();
      out_stream << "\n";
      out_stream << "Punctual flights:          " << schedule.getPunctualFP();
      out_stream << "\n";
      out_stream << "Delayed flights:           " << schedule.getDelayedFP();
      out_stream << "\n";
      out_stream << "%Punctuality:              " << schedule.getPunctualPorcentage();
      out_stream << "\n";
   }
   return out_stream.str();
}


string LpdbDataBase::getRealAcceptedAndShortageAsString(LpdbSchedule::ScheduleType schedule_type)
{
   std::stringstream out_streamAccepted;
   std::stringstream out_streamShortage;

   bool exists_schedule = false;
   if (schedule_type == LpdbSchedule::E_OPTIMAL)
   {
      exists_schedule = r_hasOptimalSchedule;
   }
   else if (schedule_type == LpdbSchedule::E_ACTIVE)
   {
      exists_schedule = r_hasActiveSchedule;
   }

   if (exists_schedule)
   {
      LpdbSchedule & schedule = (schedule_type == LpdbSchedule::E_OPTIMAL) ? r_optimalSchedule : r_activeSchedule;

      std::vector<string> intervals = schedule.getTimeLine().getAllIntervalIds();


      out_streamAccepted << "\nReal Accepted FPs: [";
      out_streamShortage << "\nShortage: [";
      BOOST_FOREACH(string interval, intervals)
      {
         TimeInterval time_interval = schedule.getTimeLine().getTimeInterval(interval);
         out_streamAccepted <<  interval;
         out_streamAccepted << ": [";
         out_streamAccepted <<   LctimTimeUtils::formatTime(time_interval.begin, "%d/%m/%y %H:%M");
         out_streamAccepted << ", " << LctimTimeUtils::formatTime(time_interval.end, "%d/%m/%y %H:%M");
         out_streamAccepted << "]";
         out_streamAccepted << schedule.getTimeLine()[interval].getRealAcceptedFps()<< ", ";


         out_streamShortage <<  interval;
         out_streamShortage << ": [";
         out_streamShortage <<   LctimTimeUtils::formatTime(time_interval.begin, "%d/%m/%y %H:%M");
         out_streamShortage << ", " << LctimTimeUtils::formatTime(time_interval.end, "%d/%m/%y %H:%M");
         out_streamShortage << "]";
         out_streamShortage << schedule.getTimeLine()[interval].getRealDelayedFps()<< ", ";
      }
      out_streamAccepted << "]";
      out_streamAccepted << "\n";
      out_streamAccepted << "\nTotal Real Accepted FPs:   ";
      out_streamAccepted << schedule.getAccepted() ;
      out_streamAccepted << "\n";

      out_streamShortage << "]";
      out_streamShortage << "\n";
      out_streamShortage << "\nTotal Shortage:            ";
      out_streamShortage << schedule.getShortage() ;
      out_streamShortage << "\n";
   }

   return (out_streamAccepted.str() + out_streamShortage.str());
}


string LpdbDataBase::getMaxAndAverageKPIsAsString(LpdbSchedule::ScheduleType schedule_type)
{
   std::stringstream out_stream;

   bool exists_schedule = false;
   if (schedule_type == LpdbSchedule::E_OPTIMAL)
   {
      exists_schedule = r_hasOptimalSchedule;
   }
   else if (schedule_type == LpdbSchedule::E_ACTIVE)
   {
      exists_schedule = r_hasActiveSchedule;
   }

   if (exists_schedule)
   {
      LpdbSchedule & schedule = (schedule_type == LpdbSchedule::E_OPTIMAL) ? r_optimalSchedule : r_activeSchedule;
      out_stream << "\n";
      out_stream << "Max. Forecasted Delay:     " << schedule.getMaxForecastDelay();
      out_stream << "\n";
      out_stream << "Average Forecasted Delay:  " << schedule.getAverageForecastDelay();
      out_stream << "\n";
      out_stream << "Max. Punctuality Delay:     " << schedule.getMaxPunctualityDelay();
      out_stream << "\n";
      out_stream << "Average Punctuality Delay: " << schedule.getAveragePunctualityDelay();
      out_stream << "\n";
      out_stream << "Punctual flights:          " << schedule.getPunctualFP();
      out_stream << "\n";
      out_stream << "Delayed flights:           " << schedule.getDelayedFP();
      out_stream << "\n";
      out_stream << "%Punctuality:              " << schedule.getPunctualPorcentage();
      out_stream << "\n";
   }
   return out_stream.str();
}


std::ostream& operator<<(std::ostream &out, const LpdbDataBase &db)
{
   db.print(out);
   out.flush();

   return out;
}
