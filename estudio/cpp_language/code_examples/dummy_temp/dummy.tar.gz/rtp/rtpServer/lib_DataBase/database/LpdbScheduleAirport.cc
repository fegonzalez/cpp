/**@file LpdbScheduleAirport.cc
 *
 * Airport information included in a schedule-module of a schedule.
 *
 *
 */

#include <LpdbScheduleAirport.h>
#include <LpiScheduleRTP.h>

#include <iostream>

LpdbScheduleAirport::LpdbScheduleAirport (const AirportSch & source)
:
the_id(static_cast<KEY_AIRPORT_ID>(source.getAirportID()))
{

}

std::ostream& operator<<(std::ostream &os, const LpdbScheduleAirport &data)
{
  os << data.getId();
  return os;
}



