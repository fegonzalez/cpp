/**@file LpdbScheduleAirport.cc
 *
 * Airport information included in a schedule-module of a schedule.
 *
 *
 */

#include <LpdbScheduleAirport.h>

#include <iostream>



std::ostream& operator<<(std::ostream &os, const LpdbScheduleAirport &data)
{

  return os;
}



