/*
 * LpdbScheduleConverter.h
 *
 *  Created on: 19/02/2015
 *      Author: mbegega
 *
 *  Description: Utility class with static methods to perform schedule conversion
 *               from internal database type to interface layer type
 */

#ifndef LPBINTERFACECONVERSOR_H_
#define LPBINTERFACECONVERSOR_H_

#include <string>
#include <vector>
#include <algorithm>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <LctimTimeLine.h>
#include <LpiTimeParameters.h>
#include <LpiComparativeKpis.h>

#include <LpdbSchedule.h>

#include <LclogStream.h>

using std::string;
using std::vector;


class LpdbScheduleConverter
{
   public:

      static LpiComparativeKpis ConvertKpis2Interface(TimeLine<LpdbSCHTimedData> & in);

//      static LpiSchedule Convert2Interface (LpdbSchedule &schedule,
//                                            LpdbSchedule::ScheduleType schedule_type,
//                                            const LpiConfigurationAlertKPIs & alertKPIs);

      static LpiFPList ConvertFlightPlanList2Interface (LpdbSchedule & schedule);

      static LpiRS_Scheduled ConvertScheduledRS2Interface (const LpdbRSScheduled & scheduledRS);

//      static void ConvertRunwaysIntervalData2Interface(string interval,
//                                                       LpdbSchedule & schedule,
//                                                       const LpiConfigurationAlertKPIs & alertKPIs,
//                                                       LpiPerformanceIntervalData & outPerformance,
//                                                       LpiCapacityIntervalData & outCapacity);

//      static LpiAirportTotalKPIs ConvertAirportTotalKPIs2Interface(LpdbSchedule &schedule,
//                                                                   const LpiConfigurationAlertKPIs & alertKPIs);

//      static void ConvertAirportIntervalCapacityInfo2Interface(string interval,
//                                                               LpdbSchedule & schedule,
//                                                               const LpiConfigurationAlertKPIs & alertKPIs,
//                                                               LpiAirportIntervalCapacityInfo & out);

   private:
      //Prevent inheritance for this class
      LpdbScheduleConverter();
};


#endif /* LPBINTERFACECONVERSOR_H_ */
