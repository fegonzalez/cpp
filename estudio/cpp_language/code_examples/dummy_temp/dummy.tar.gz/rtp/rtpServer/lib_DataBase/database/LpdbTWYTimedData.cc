/*
 * LpdbTWYTimedData.cc
 *
 */

#include "LpdbTWYTimedData.h"
#include <iostream>



unsigned int LpdbTWYTimedData::getCapacity() const
{
  return r_capacity;
}


// void LpdbTWYTimedData::setCapacity(unsigned int capacity)
// {
//   r_capacity = capacity;
// }
 

void LpdbTWYTimedData::calculateCapacity(unsigned int numberOfIntervals,
					 unsigned int nominalCapacity)
{
  r_capacity = nominalCapacity / numberOfIntervals;
}


//------------------------------------------------------------------------------



std::ostream & operator<<(std::ostream & os, const LpdbTWYTimedData & info)
{
  return os << " [ CAP: " << info.getCapacity()
	    << ']';
}


