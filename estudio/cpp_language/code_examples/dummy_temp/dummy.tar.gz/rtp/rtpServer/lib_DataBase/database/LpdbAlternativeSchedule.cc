/*
 * LpdbAlternativeSchedule.cc
 *
 *  Created on: 11/07/2014
 *      Author: mbegega
 */

#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpdbAlternativeSchedule.h"


LpdbAlternativeSchedule::LpdbAlternativeSchedule()
: r_id(-1),
  r_name(""),
  r_activation_type(LpiScheduleActivationType::E_AUTO),
  r_expirationInfo(),
  r_runwayClosure(-1),
  r_totalCost(0.0)
{
}


LpdbAlternativeSchedule::LpdbAlternativeSchedule(int min_subinterval,
                                               int hours_window,
                                               int min_frozen,
                                               boost::posix_time::ptime begin_timestamp)
: LpdbSchedule(min_subinterval, hours_window, min_frozen, begin_timestamp),
  r_id(-1),
  r_name(""),
  r_activation_type(LpiScheduleActivationType::E_AUTO),
  r_expirationInfo(),
  r_runwayClosure(-1),
  r_totalCost(0.0)
{
}


LpdbAlternativeSchedule::LpdbAlternativeSchedule(const LpdbAlternativeSchedule & source)
: LpdbSchedule(source),
  r_id(source.r_id),
  r_name(source.r_name),
  r_activation_type(source.r_activation_type),
  r_expirationInfo(source.r_expirationInfo),
  r_runwayClosure(source.r_runwayClosure),
  r_totalCost(source.r_totalCost)
{
}


LpdbAlternativeSchedule::LpdbAlternativeSchedule(const LpdbSchedule & source)
: LpdbSchedule(source),
  r_id(-1),
  r_name(""),
  r_activation_type(LpiScheduleActivationType::E_AUTO),
  r_expirationInfo(),
  r_totalCost(0.0)
{
}


LpdbAlternativeSchedule & LpdbAlternativeSchedule::operator= (const LpdbAlternativeSchedule & source)
{
   if (this != &source)
   {
      LpdbSchedule::operator=(source);
      r_id = source.r_id;
      r_name = source.r_name;
      r_activation_type = source.r_activation_type;
      r_expirationInfo = source.r_expirationInfo;
      r_runwayClosure = source.r_runwayClosure;
      r_totalCost = source.r_totalCost;
   }

   return *this;
}


 bool LpdbAlternativeSchedule::isEqual(LpdbAlternativeSchedule & right)
{
   string scheduledRSLeft = this->toShortString();
   string scheduledRSRight = right.toShortString();

   return (scheduledRSLeft == scheduledRSRight);
}

/*
LpiActiveSchedule LpdbAlternativeSchedule::Convert2ActiveInterface (LpdbAlternativeSchedule & active_schedule,
                                                                   const LpiConfigurationAlertKPIs & alertKPIs,
                                                                   const boost::posix_time::ptime & activationTime)
{
   LpiActiveSchedule out;

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).debug() << "[ACTIVE SCHEDULE:" << std::endl;
#endif

   out = LpdbScheduleConverter::Convert2Interface(active_schedule, LpdbSchedule::E_ACTIVE, alertKPIs);

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).debug() << "]" << std::endl;
#endif

   out.setId(active_schedule.getId());
   out.setName(active_schedule.getName());
   out.storeTimestamp(activationTime);

   return out;
}
*/

 /*
LpiAlternativeSchedule LpdbAlternativeSchedule::Convert2AlternativeInterface (LpdbAlternativeSchedule & schedule,
                                                                             const LpiConfigurationAlertKPIs & alertKPIs)
{
   LpiAlternativeSchedule out;

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).debug() << "[ALTERNATIVE SCHEDULE " << schedule.getId() << "(" << schedule.getName() << "):" << std::endl;
#endif

   out = LpdbScheduleConverter::Convert2Interface(schedule, LpdbSchedule::E_ALTERNATIVE, alertKPIs);

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).debug() << "]" << std::endl;
#endif

   out.setId(schedule.getId());
   out.setName(schedule.getName());

   return out;
}
*/

std::ostream & operator<< (std::ostream & os, const LpdbAlternativeSchedule & info)
{
   if (info.getId() != -1)
   {
      os << "[ID: " << info.getId() << ", NAME: " << info.getName() << "]";
   }

   os << static_cast<LpdbSchedule>(info);

   return os;
}

