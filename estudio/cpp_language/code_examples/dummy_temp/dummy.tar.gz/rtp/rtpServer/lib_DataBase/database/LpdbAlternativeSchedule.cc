/**@file LpdbAlternativeSchedule.cc
 *
 * @warning See RMAN code as reference.
 */


#include <LpdbAlternativeSchedule.h>

#include <iostream>


void LpdbAlternativeSchedule::print_concrete_data (std::ostream & out) const
{
//   if (info.getId() != -1)
//   {
//      os << "[ID: " << info.getId() << ", NAME: " << info.getName() << "]";
//   }
}

std::ostream & operator<< (std::ostream & os, const LpdbAlternativeSchedule & data)
{
   data.print(os);
   os.flush();
   
   return os;
}

