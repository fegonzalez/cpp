/**@file LpdbAlternativeSchedule.cc
 *
 * @warning See RMAN code as reference.
 */


#include <LpdbAlternativeSchedule.h>



std::ostream & operator<< (std::ostream & os, const LpdbAlternativeSchedule & info)
{
//   if (info.getId() != -1)
//   {
//      os << "[ID: " << info.getId() << ", NAME: " << info.getName() << "]";
//   }

   os << static_cast<LpdbSchedule>(info);

   return os;
}

