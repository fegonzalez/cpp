/**@file LpdbActiveSchedule.h
 *
 *
 */

#ifndef LPDB_ACTIVE_SCHEDULE_H_
#define LPDB_ACTIVE_SCHEDULE_H_

#include <LpdbSchedule.h>

class LpiScheduleRTP;


/******************************************************************************/
/**@class LpdbActiveSchedule

   @brief Data in the current active schedule of the RTP (if exists)
 */
/******************************************************************************/
class LpdbActiveSchedule : public LpdbSchedule
{

  friend std::ostream & operator<<(std::ostream & os, 
				   const LpdbActiveSchedule & data);

 public:

  ScheduleType type() const { return ScheduleType::E_ACTIVE; }
  std::string type_to_string() const { return "ACTIVE"; }

  explicit LpdbActiveSchedule (const LpiScheduleRTP & source);
  LpdbActiveSchedule() = delete;
  LpdbActiveSchedule(const LpdbActiveSchedule &) = delete;
  LpdbActiveSchedule & operator=(const LpdbActiveSchedule &) = delete;
  

 private:
  
  void print_concrete_data (std::ostream & out) const;


};


#endif /* LPDB_ACTIVE_SCHEDULE_H_ */
