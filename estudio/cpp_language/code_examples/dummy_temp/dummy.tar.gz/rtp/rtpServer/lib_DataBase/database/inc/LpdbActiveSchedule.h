/**@file LpdbActiveSchedule.h
 *
 *
 */

#ifndef LPDB_ACTIVE_SCHEDULE_H_
#define LPDB_ACTIVE_SCHEDULE_H_

#include <LpdbSchedule.h>


/**@class LpdbActiveSchedule

   @brief Data in the current active schedule of the RTP (if exists)
 */
class LpdbActiveSchedule : public LpdbSchedule
{

  friend std::ostream & operator<<(std::ostream & os, 
				   const LpdbActiveSchedule & data);


};


#endif /* LPDB_ACTIVE_SCHEDULE_H_ */
