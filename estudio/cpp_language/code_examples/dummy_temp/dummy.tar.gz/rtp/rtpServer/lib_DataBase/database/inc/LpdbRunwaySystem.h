/*
 * LpdbRunwaySystem.h
 *
 *  Created on: 12/12/2013
 *      Author: mbegega
 */

#ifndef LPBRUNWAYSYSTEM_H_
#define LPBRUNWAYSYSTEM_H_

#include <string>
#include <map>
#include <vector>
#include <utility>

#include <LctimTimeLine.h>
#include <LpiTimeParameters.h>
#include <LpiAdaptationRunwaySystem.h>
#include <LpiRunwaySystemUse.h>
#include <LpiWakeVortexCapacityReductions.h>

#include "LpdbRunwaySystemTimedData.h"
#include "LpdbRunwaySystemRunway.h"

using std::string;
using std::map;
using std::pair;
using std::vector;


class LpdbRunwaySystem
{
   public:
      LpdbRunwaySystem();
      LpdbRunwaySystem(string id);
      LpdbRunwaySystem(const LpiAdaptationRunwaySystem & rs);
      LpdbRunwaySystem(const LpdbRunwaySystem & source);

      virtual ~LpdbRunwaySystem() {}

      LpdbRunwaySystem & operator= (const LpdbRunwaySystem & source);

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbRunwaySystemTimedData & operator[] (const string & interval_name);

      //stablish timeline
      void init(const LpiTimeParameters & timeData,
                boost::posix_time::ptime begin_timestamp);

      void forwardTimeline();
      TimeLine<LpdbRunwaySystemTimedData> getTimeLine() const;

      TimeInterval getTimeInterval(const std::string & interval);

      //Getters and setters
      string getRunwaySystemId() const;
      void setRunwaySystemId(string id);

      string getConfiguration () const;
      void setConfiguration (string configuration);

      //Internal Runways Management
      void addRunway (const string & runway_id, OperationType::Enum use_type);
      void deleteRunway (const string & runway_id);
      int  getNumberOfRunways () const;
      const map<string, LpdbRunwaySystemRunway> & getRunways() const;

      LpdbRunwaySystemRunway & getRunway(string id_runway);

     //LVP Feasibility Management
      bool isLvpFeasibility() const;
      void setLvpFeasibility(bool lvpFeasibility);

      std::string getIntervalsShortFormat () const;
      std::string getIntervalsAsString () const;

      //Estimated Delayed FPs Management
      vector<LpiADOVector<int> > getEstimatedDelayedFpsScheduled() const;

      void setEstimatedDelayedFpsScheduled(
                vector<LpiADOVector<int> > estimatedDelayedFpsScheduled);

      void resetEstimatedDelayedFPs();
      void addEstimatedDelayedFP (const LpiADOVector<int> & delayed);

      //Maximum capacity calculations
      void calculateMaximumCapacity ();
      void calculateMaximumCapacity (string interval);

      bool hasMixedRunways () const;
      vector<string> getRunwaysByUse (OperationType::Enum operation) const;
      bool hasRunwaysOfSameUse (const LpdbRunwaySystem & anotherRS,
                                OperationType::Enum operation) const;

      LpiRunwaySystemUse::LpiEnum getUse () const;
      void setUse (LpiRunwaySystemUse::LpiEnum use);

      std::map<string, int> getAvailableRunwaysAndCapacities (OperationType::Enum use_type, string interval);

      int getNumberOfArrivalRunways() const;
      int getNumberOfDepartureRunways() const;

   protected:
      void calculateRSRunwayMaxCapacity();
      void calculateRunwayDependencies();
      void applyCapacityReductions();
      void combineRunwaysCapacities();
//      void applyMeteoReductions();

//      void calculateTMATaxiwaysReductions();

      void calculateRSRunwayMaxCapacity(string interval);
      void calculateRunwayDependencies(string interval);
      void applyCapacityReductions(string interval);
      void combineRunwaysCapacities(string interval);
//      void applyMeteoReductions(string interval);

//      void calculateTMATaxiwaysReductions(string interval);

      // Member functions to reduce the capacity by WTC
      std::vector<LpiWakeVortexConditions> calculateConditionsToApplyReduction(
                                      std::vector<float> calculated_percentage,
                                  std::vector<LpiWTCReduction> reductions_list);
      std::vector<float> calculatePercentageOfWtc(
                          std::vector<int> counter_vector, int counter_total);
      void countFlightsByWtc(std::string wtc, std::vector<int> &counter_vector,
                                                          int &counter_total);

   protected:
      string r_runwaySystemId;

      string r_configuration;

      TimeLine<LpdbRunwaySystemTimedData> r_timeLine;

      //Every runway composing runway system and their use, pair must be unique
      map<string, LpdbRunwaySystemRunway> r_runways;

      bool r_lvp_feasibility;
      vector<LpiADOVector<int> > r_estimated_delayed_fps_scheduled;

      bool r_has_mixed_runways; //true if all runways are mixed
      LpiRunwaySystemUse::LpiEnum r_use;

      int r_number_of_arrival_runways;
      int r_number_of_departure_runways;
};


std::ostream& operator<<(std::ostream &os, const LpdbRunwaySystem &rs);

#endif /* LPBRUNWAYSYSTEM_H_ */
