

#ifndef _LPB_AIRPORT_INTERVAL_COMPARATIVE_KPIS_H_
#define _LPB_AIRPORT_INTERVAL_COMPARATIVE_KPIS_H_

#include <iostream>

#include "LpiADOVector.h"
#include "LpdbAirportIntervalKPIs.h"
//#include "LpdbWarningErrors.h"

#include <LpiWarningsAlerts.h>
#include <LpiComparativeKpis.h>

class LpdbAirportIntervalComparativeKPIs
{
   public:

      enum ComparativeType { E_DELTA = 0, E_RELATIVE }; //Only for internal calculations

      LpdbAirportIntervalComparativeKPIs();
      LpdbAirportIntervalComparativeKPIs(const LpdbAirportIntervalComparativeKPIs & source);
      virtual ~LpdbAirportIntervalComparativeKPIs() {}

      void reset();

      LpdbAirportIntervalComparativeKPIs & operator= (const LpdbAirportIntervalComparativeKPIs & source);

      LpiADOVector<int> getAirportCapacity()          const { return r_airport_capacity; }
      LpiADOVector<int> getRSCapacity()               const { return r_rs_capacity; }
      LpiADOVector<int> getShortage()                 const { return r_shortage; }
      LpiADOVector<double> getMaxForecastedDelay()    const { return r_max_forecasted_delay; }
      LpiADOVector<double> getPercentagePunctuality() const { return r_percentage_punctuality; }
      LpiADOVector<double> getAverageForecastedDelay_DelayedFps() const
                                                { return r_average_forecast_delay_delayedFps; }

      Warnings_alerts getAirportCapacityWA()          const { return r_airport_capacityWA; }
      Warnings_alerts getRSCapacityWA()               const { return r_rs_capacityWA; }
      Warnings_alerts getShortageWA()                 const { return r_shortageWA; }
      Warnings_alerts getMaxForecastedDelayWA()       const { return r_max_forecasted_delayWA; }
      Warnings_alerts getPercentagePunctualityWA()    const { return r_percentage_punctualityWA; }
      Warnings_alerts getAverageForecastedDelay_DelayedFpsWA() const
                                                { return r_average_forecast_delay_delayedFpsWA; }


      //setters
      void setAirportCapacity(const LpiADOVector<int> & aux)     { r_airport_capacity = aux; }
      void setRSCapacity(const LpiADOVector<int> & aux)          { r_rs_capacity = aux; }
      void setShortage(const LpiADOVector<int> & aux)            { r_shortage = aux; }
      void setMaxForecastDelay(const LpiADOVector<double> & aux) { r_max_forecasted_delay = aux; }
      void setPunctualPercentage(const LpiADOVector<double> &aux){ r_percentage_punctuality = aux; }
      void setAverageForecastedDelay_DelayedFps(const LpiADOVector<double> & aux)
                                                      { r_average_forecast_delay_delayedFps = aux; }


      void calculateValues(const LpiADOVector<int> & airport_capacity_left,
                           const LpiADOVector<int> & rs_capacity_left,
                           const LpiADOVector<int> & shortage_left,
                           const LpdbAirportIntervalKPIs & left,
                           const LpiADOVector<int> & airport_capacity_right,
                           const LpiADOVector<int> & rs_capacity_right,
                           const LpiADOVector<int> & shortage_right,
                           const LpdbAirportIntervalKPIs & right);

      //void generateAlerts(const LpiConfigurationAlertKPIs & thresholds, ComparativeType kpi_type = E_DELTA);

      // Conversion to interface
      static void convert2Interface(const LpdbAirportIntervalComparativeKPIs & in, LpiIntervalDataKpis & out);

   protected:
      //Capacity
      LpiADOVector<int>    r_airport_capacity;
      LpiADOVector<int>    r_rs_capacity;

      // Throughput
      LpiADOVector<int>    r_shortage;

      //Delay
      LpiADOVector<double> r_max_forecasted_delay;
      LpiADOVector<double> r_percentage_punctuality;
      LpiADOVector<double> r_average_forecast_delay_delayedFps;

      //Alerts
      Warnings_alerts    r_airport_capacityWA;
      Warnings_alerts    r_rs_capacityWA;
      Warnings_alerts    r_shortageWA;
      Warnings_alerts    r_max_forecasted_delayWA;
      Warnings_alerts    r_percentage_punctualityWA;
      Warnings_alerts    r_average_forecast_delay_delayedFpsWA;
};


LpdbAirportIntervalComparativeKPIs operator- (const LpdbAirportIntervalKPIs & left,
                                             const LpdbAirportIntervalKPIs & right);

std::ostream & operator<< (std::ostream & os, const LpdbAirportIntervalComparativeKPIs & kpis);

#endif
