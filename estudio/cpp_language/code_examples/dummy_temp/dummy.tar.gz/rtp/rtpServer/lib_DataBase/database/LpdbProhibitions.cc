
#include "LpdbProhibitions.h"
#include <LpiAdapProhibConstants.h>

#include <algorithm>
#include <iterator>
#include <set>

//-----------------------------------------------------------------------------

LpdbProhibitions::~LpdbProhibitions()
{
  release();
}

void LpdbProhibitions::release()
{
  r_prohibitions.clear();
}

//------------------------------------------------------------------------------

const LpdbProhibitions::LpdbProhibitionsStorageType & 
LpdbProhibitions::getProhibitions() const
{
   return r_prohibitions;
}

//------------------------------------------------------------------------------

/* Use example.- 
  std::set<std::string> allValues = findAll("A1-ID");
  for (auto& x: allValues)
    std::cout << x << "; " << std::endl;
*/
std::set<std::string> LpdbProhibitions::findAll(const std::string &key) const
{
  std::set<std::string> result;
  const auto values_range = r_prohibitions.equal_range(key);
  for(auto next = values_range.first;
      next != values_range.second;
      ++next)
    {
      result.insert(next->second);
    }
  return result;
}

//------------------------------------------------------------------------------

/* Use example.- 
  std::string oneValue;
  if (findOne("A1-ID", oneValue))
  std::cout << "\n oneValue: " << oneValue << std::endl;
*/
bool LpdbProhibitions::findOne(const std::string &key,
			       std::string &retval) const
{
    auto search = r_prohibitions.find(key);
    if(search not_eq r_prohibitions.end())
    {
      retval = search->second;
      return true;
    }
    else
    {
      return false;
    }
}

//------------------------------------------------------------------------------

// void LpdbProhibitions::setProhibitions(const LpdbProhibitionsStorageType & prohibitions)
// {
//    r_prohibitions = new_val;
// }


void LpdbProhibitions::setProhibitions(const ProhibitionElementList & new_val)
{
  release();
  for (auto& x: new_val)
    addProhibition(x.first, x.second);
}

//------------------------------------------------------------------------------

void LpdbProhibitions::addProhibition(const std::string & airport1,
				      const std::string & airport2)
{
   r_prohibitions.insert(std::make_pair(airport1, airport2));
   r_prohibitions.insert(std::make_pair(airport2, airport1));
}

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & os, const LpdbProhibitions & info)
{
  const LpdbProhibitions::LpdbProhibitionsStorageType & prohibitions = 
    info.getProhibitions();

  os << "[ notAllowedAllocations: ";
    
  //c++11
  for (auto& x: prohibitions)
    os << " (" << x.first << ':' << x.second << ')';
  os << ' ';
  //c++98
  // LpdbProhibitions::LpdbProhStorType_ConstItr citr;
  // for (citr=prohibitions.begin(); citr!=prohibitions.end(); ++citr)
  //   {
  //     os << "("
  // 	 << (*citr).first << ';' << (*citr).second
  // 	 << ") ";
  //   }

  os << "]\n";

  return os;
}

//------------------------------------------------------------------------------
