/*
 * LpdbDelaysSplitter.h
 *
 *  Created on: 23/06/2014
 *      Author: mbegega
 */

#ifndef LPBDELAYSSPLITTER_H_
#define LPBDELAYSSPLITTER_H_

#include <iostream>
#include <map>
#include <string>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <numeric>

#include <boost/foreach.hpp>
#include <boost/optional/optional.hpp>

#include "LpiADOVector.h"
#include "LpdbDelayOption.h"
#include "LpiWeightPonderationParameters.h"

#include <LclogStream.h>

using std::ostream;
using std::map;
using std::string;

//Enumeration for internal use

class LpdbDelayOptions
{
   public:

      enum LpdbEnum {
         E_OPTION_A = 0,
         E_OPTION_B,
         E_OPTION_C,
         E_OPTION_D,
         E_OPTION_E
      };

      LpdbDelayOptions() : r_enum(E_OPTION_A) {}

      LpdbDelayOptions(const LpdbDelayOptions & source) : r_enum (source.r_enum) {}

      bool operator== (LpdbDelayOptions source) const { return r_enum == source.r_enum; }

      static std::string getEnumAsString(LpdbDelayOptions::LpdbEnum value)
      {
          std::string response;

          switch(value)
          {
             case E_OPTION_A:
                response = "OPTION A";
             break;
             case E_OPTION_B:
                response = "OPTION B";
             break;
             case E_OPTION_C:
                response = "OPTION C";
             break;
             case E_OPTION_D:
                response = "OPTION D";
             break;
             case E_OPTION_E:
                response = "OPTION E";
             break;
          }

          return response;
      }

   private:

      LpdbEnum r_enum;
};


//Enumeration for internal use

class LpdbOptionOptimizationCriteria
{
   public:

      enum LpdbEnum {
         E_TOTALS = 0,
         E_ARRIVALS,
         E_DEPARTURES
      };

      LpdbOptionOptimizationCriteria() : r_enum(E_TOTALS) {}

      LpdbOptionOptimizationCriteria(const LpdbOptionOptimizationCriteria & source) : r_enum (source.r_enum) {}

      bool operator== (LpdbOptionOptimizationCriteria source) const { return r_enum == source.r_enum; }

      static std::string getEnumAsString(LpdbOptionOptimizationCriteria::LpdbEnum value)
      {
          std::string response;

          switch(value)
          {
             case E_TOTALS:
                response = "TOTALS";
             break;
             case E_ARRIVALS:
                response = "ARRIVALS";
             break;
             case E_DEPARTURES:
                response = "DEPARTURES";
             break;
          }

          return response;
      }

   private:

      LpdbEnum r_enum;
};


class LpdbDelaysSplitter
{
   public:

      LpdbDelaysSplitter ();
      LpdbDelaysSplitter (LpiADOVector<int> surplus, LpiADOVector<int> margin);
      LpdbDelaysSplitter (const LpdbDelaysSplitter & source);

      LpdbDelaysSplitter & operator= (const LpdbDelaysSplitter & source);

      void setSurplus (LpiADOVector<int> surplus)
      { r_surplus = surplus; }

      void setEstimatedDCMargin (LpiADOVector<int> margin)
      { r_estimated_DC_margin = margin; }

      void calculateDelayOptions ();
      void calculateAcceptedDelayed ();
      void calculateNonAcceptedDelayed ();

      void selectBestOption(double ratioARR, double ratioDEP);
      void selectBestOptionLastInterval(double ratioARR, double ratioDEP);

      LpiADOVector<int> getRealDelayedBestOption ();

      void printOptions ();
      string getOptionsAsString();

   protected:

      map<LpdbDelayOptions::LpdbEnum, LpdbDelayOption> r_available_options;

      LpiADOVector<int> r_surplus;
      LpiADOVector<int> r_estimated_DC_margin;

      boost::optional<LpdbDelayOptions::LpdbEnum> r_best_delay_option;
      boost::optional<LpiADOVector<int> > r_best_option_non_accepted;
      boost::optional<LpiADOVector<int> > r_best_option_accepted;
      boost::optional<LpiADOVector<int> > r_best_option_delayed;     //only for last interval
      boost::optional<int> r_best_option_delayed_arrival;

      double distance(double ratioARR, double ratioDEP, double weightARR, double weightDEP);
};



#endif /* LPBDELAYSSPLITTER_H_ */
