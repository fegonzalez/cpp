/**@file LpdbScheduleModule.cc
 *
 * Modules included in a schedule.
 *
 *
 */

#include <LpdbScheduleModule.h>

#include <iostream>



std::ostream& operator<<(std::ostream &os, const LpdbScheduleModule &data)
{

  return os;
}



