/**@file LpdbScheduleModule.cc
 *
 * Modules included in a schedule.
 *
 *
 */

#include <LpdbScheduleModule.h>
#include <LpiScheduleRTP.h>

#include <iostream>
#include <algorithm>    // std::for_each
//#include <functional>   // bind



//===============================================================================

LpdbScheduleModule::LpdbScheduleModule (const MRTM & source)
 :the_id(source.getID())
{
  the_airports.clear();
  const AirportsList &source_list = source.getAirportsList();
  std::for_each(std::begin(source_list),
		std::end(source_list),
		[this] (const AirportSch & new_element)
		{ the_airports.push_back(LpdbScheduleAirport(new_element)); });
}

//===============================================================================

std::ostream& operator<<(std::ostream &os, const LpdbScheduleModule &data)
{
  os << data.getId() << " | ";

  os << "Airports: [ ";
  std::for_each(std::begin(data.the_airports),
		std::end(data.the_airports),
		[&os] (const LpdbScheduleAirport & airport)
		{ 
		  os << airport << " | " ;
		});
  os << " ]";

  return os;
}



