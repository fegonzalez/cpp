/*
 * LpdbMeteoTimelineConverter.cc
 *
 *  Created on: 20/03/2015
 *      Author: mbegega
 */

#include <vector>
#include <string>
#include "LpdbMeteoTimelineConverter.h"


#include <LclogStream.h>

using std::vector;
using std::string;


LpiMeteoTimeline LpdbMeteoTimelineConverter::Convert2Interface(TimeLine<LpdbMeteoTimedData> & in)
{


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


   LpiMeteoTimeline out;

   vector<string> intervals = in.getAllIntervalIds();

   vector<LpiMeteoInterval> allIntervalsData;

   BOOST_FOREACH(string interval, intervals)
   {
      if (in.hasData(interval))
      {
         LpdbMeteoTimedData meteorologicalInfo = in[interval];

         string wetness;
         if (meteorologicalInfo.getWetness().is_initialized())
         {
            boost::optional<string> data = meteorologicalInfo.getWetness();
            wetness = data.get();
         }

         string ilsCategory;
         if (meteorologicalInfo.getIlsCategory())
         {
            boost::optional<string> data = meteorologicalInfo.getIlsCategory();
            ilsCategory = *data;
         }

         LpiMeteoIntervalData meteoInfoInterface(meteorologicalInfo.getHorizontalVisibility(),
                                                 wetness,
                                                 ilsCategory,
                                                 meteorologicalInfo.getLvpActivation(),
                                                 meteorologicalInfo.getDeicingRequired(),
//                                                 meteorologicalInfo.getCrosswind(),
//                                                 meteorologicalInfo.getTailwind(),
                                                 meteorologicalInfo.getWindSpeed(),
                                                 meteorologicalInfo.getWindDirection());

         TimeInterval times = in.getTimeInterval(interval);

         LpiMeteoInterval intervalInterface = LpiMeteoInterval(interval,
                                                               LctimTimeUtils::formatTime(times.begin),
                                                               LctimTimeUtils::formatTime(times.end),
                                                               meteoInfoInterface);

         allIntervalsData.push_back(intervalInterface);
      }
   }

   out.setAllScheduleIntervals(allIntervalsData);

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
   return out;
}

