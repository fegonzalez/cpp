/*
 * LpdbMeteoTimelineConverter.h
 *
 *  Created on: 30/03/2015
 *      Author: mbegega
 *
 *  Description: Utility class with static methods to perform meteorological timeline conversion
 *               from internal database type to interface layer type
 */

#ifndef LPBMETEOTIMELINECONVERSOR_H_
#define LPBMETEOTIMELINECONVERSOR_H_

#include <LctimTimeLine.h>
#include <LpiMeteoTimeline.h>


#include <LpdbMeteoTimedData.h>


class LpdbMeteoTimelineConverter
{
   public:

      static LpiMeteoTimeline Convert2Interface(TimeLine<LpdbMeteoTimedData> & in);

   private:
      //Prevent inheritance for this class
      LpdbMeteoTimelineConverter();
};


#endif /* LPBINTERFACECONVERSOR_H_ */
