/**@file LpdbActiveSchedule.cc
 *
 */


#include <LpdbActiveSchedule.h>
#include <LclogStream.h>

#include <iostream>


//------------------------------------------------------------------------------

LpdbActiveSchedule::LpdbActiveSchedule (const LpiScheduleRTP & source)
:LpdbSchedule(source)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "Schedule logic" << " ; sch type:" << type_to_string()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
}

//------------------------------------------------------------------------------

void LpdbActiveSchedule::print_concrete_data (std::ostream & out) const
{
//   if (info.getId() != -1)
//   {
//      os << "[ID: " << info.getId() << ", NAME: " << info.getName() << "]";
//   }
}

std::ostream & operator<< (std::ostream & os, const LpdbActiveSchedule & data)
{
   data.print(os);
   os.flush();
   
   return os;
}

//------------------------------------------------------------------------------
