/**@file LpdbActiveSchedule.cc
 *
 */


#include <LpdbActiveSchedule.h>



std::ostream & operator<< (std::ostream & os, 
			   const LpdbActiveSchedule & data)
{
  //generic schedule data
  os << static_cast<LpdbSchedule>(data);

  // concrete data

//   if (data.getId() != -1)
//   {
//      os << "[ID: " << data.getId() << ", NAME: " << data.getName() << "]";
//   }

  return os;
}

