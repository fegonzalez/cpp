/**@file LpdbScheduleModule.h
 *
 * Modules included in a schedule.
 *
 *
 */

#ifndef LPDB_SCHEDULEMODULE_H_
#define LPDB_SCHEDULEMODULE_H_


#include <LpdbCommon.h>
#include <LpdbScheduleAirport.h>

#include <iosfwd>
#include <vector>
//#include <memory> // std::shared_ptr


class LpdbAirport;

class LpdbScheduleModule
{
  friend std::ostream& operator<<(std::ostream &os, 
				  const LpdbScheduleModule &data);

 public:

  //  typedef LpdbDataTable<KEY_AIRPORT_ID, std::shared_ptr<LpdbAirport> > SchAirportTable;

  //   typedef LpdbDataTable<KEY_AIRPORT_ID, LpdbScheduleAirport> SchAirportTable;

  typedef std::vector<LpdbScheduleAirport> SchAirportCollection;


  
 protected:

  /**@param the_airports: airports selected for the module. 

     @warning The LpdbAirport objects are managed off this class.

   */
  SchAirportCollection the_airports; 


  /**@param the_ancillary_data: rest of parameters related to a module.

     @todo To be coded when the KPI task is performed.

     
     HINT   See "TimeLine<LpdbSCHTimedData> r_timeLine; " at LpdbSchedule.h


   */
  //  ScheduleModuleAncillaryData the_ancillary_data;

};


#endif /* LPDB_SCHEDULEMODULE_H_ */

