/*
 * LpdbTWY.h
 *
 */

#include "LpdbTWY.h"
#include <LpiIncreasingReductionFunction.h>

#include <iostream>
#include <cmath>
#include <algorithm>    // std::for_each
#include <functional>   // bind


bool LpdbTWY::has_data(const string& interval_name)
{
   return r_timeLine.hasData(interval_name);
}


LpdbTWYTimedData& LpdbTWY::operator [](const string& interval_name)
{
   return r_timeLine[interval_name];
}


void LpdbTWY::init(const LpiTimeParameters & parameters,
		   boost::posix_time::ptime begin_timestamp,
		   const unsigned int twyNominalCapacity)
{
  r_twyNominal = twyNominalCapacity; 

  r_timeLine.initialize(parameters.getMinutesSubinterval(),
			parameters.getHoursWindow(),
			parameters.getMinutesFrozen(),
			begin_timestamp);
  r_timeLine.fill();
}


void LpdbTWY::forward()
{
   r_timeLine.forward();

   //Creates default element in newly created interval
   r_timeLine.createElement(r_timeLine.getLastInterval());
}

TimeLine<LpdbTWYTimedData> & LpdbTWY::getTimeLine()
{
   return r_timeLine;
}

std::string LpdbTWY::getIntervalsShortFormat () const
{
   return r_timeLine.getIntervalsShortFormat();
}


std::string LpdbTWY::getIntervalsAsString () const
{
   return r_timeLine.getAsString();
}


void LpdbTWY::calculateCapacity()
{
  std::vector<string> intervals = r_timeLine.getAllIntervalIds();
  std::for_each(std::begin(intervals), std::end(intervals),
		std::bind(static_cast<void(LpdbTWY::*)(std::string)>
  	  	  (&LpdbTWY::calculateCapacity), this, std::placeholders::_1));
}


void LpdbTWY::calculateCapacity(string interval)
{
   if (has_data(interval))
   {
      LpdbTWYTimedData & twy_data = r_timeLine[interval];
      twy_data.calculateCapacity(r_timeLine.getNumberOfIntervalsPerHour(), 
			       r_twyNominal);
   }
}
