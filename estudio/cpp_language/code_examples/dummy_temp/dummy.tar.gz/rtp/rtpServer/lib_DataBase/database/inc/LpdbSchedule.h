/*
 * LpdbSchedule.h
 *
 *  Created on: 11/12/2013
 *      Author: mbegega
 */

#ifndef LPBSCHEDULE_H_
#define LPBSCHEDULE_H_

#include <string>
#include <vector>
#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <LpiTimeParameters.h>
#include <LpdbSCHTimedData.h>
#include <LctimTimeLine.h>
#include <LpdbGlobalParameters.h>
#include <algorithm>
#include <LclogStream.h>
#include <LpdbFPDelayed.h>
#include <LpdbFPSchedule.h>
#include <LpiADOVector.h>
#include <LpdbDelaysSplitter.h>
#include <LpdbAbsoluteKPIs.h>

#include <LpiActivationType.h>
#include <LpiComparativeKpis.h>

using std::string;
using std::vector;
using boost::posix_time::ptime;
using boost::optional;

class LpdbSchedule
{
   public:

      enum ScheduleType { E_OPTIMAL = 0, E_ACTIVE, E_ALTERNATIVE };

      LpdbSchedule();
      LpdbSchedule(int min_subinterval,
                  int hours_window,
                  int min_frozen,
                  boost::posix_time::ptime begin_timestamp);

      LpdbSchedule(const LpdbSchedule & source);
      virtual ~LpdbSchedule() {}

      void init(const LpiTimeParameters & parameters,
                boost::posix_time::ptime begin_timestamp);

      void init(int min_subinterval,
                int hours_window,
                int min_frozen,
                boost::posix_time::ptime begin_timestamp);

      LpdbSchedule & operator= (const LpdbSchedule & source);

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpdbSCHTimedData & operator[] (const string & interval_name);

      //Forward timeline
      void forward();

      void scheduleRunwaySystem (std::string interval, const LpdbRunwaySystem & rs);
      //void allocateFP (std::string interval, LpdbFlightPlan & FP);

      void setTimeLine (const TimeLine<LpdbSCHTimedData> & source);
      TimeLine<LpdbSCHTimedData> & getTimeLine ();
      const TimeLine<LpdbSCHTimedData> & getTimeLine () const;

      //Getters and Setters
      map<string, LpdbFPSchedule> getScheduleFps() const;
      map<string, LpdbFPSchedule> & getScheduleFps();
      void setScheduleFps(map<string, LpdbFPSchedule> allocatedFps);

      map<string, LpdbFPSchedule> & getDelayedFpsInLastInterval();
      map<string, LpdbFPSchedule>   getDelayedFpsInLastInterval() const;
      void setDelayedFpsInLastInterval(map<string, LpdbFPSchedule> delayedFps);

      void setIntervalTMinusOne (const LpdbSCHTimedData & interval);
      LpdbSCHTimedData getIntervalTMinusOne () const;

//    void calculateRealDCB ();
      void calculateRealDCB (string interval, int minClosedTurnRound, double ratioARR, double ratioDEP);
      void calculateRealDCB (string interval, int minClosedTurnRound, double ratioARR, double ratioDEP,
                             string previous_interval, double previousRatioARR, double previousRatioDEP,
                             bool isNewInterval = false);

      void calculateRunwayAllocation ();
      void calculateRunwayAllocation (string interval);

      void clearStoredFPs();
      void performFPCalculations(int minTurnRoundTime);
      void performFPCalculations(string interval, int minTurnRoundTime);
      void markTurnRoundFlights();


      void calculateRunwayAssignationAndFPTimes (string interval, int minTurnRoundTime);
      void assignFPTimes(const vector<string> & fpKeys,
                         vector<ptime> & availableFTOT_FLDTs,
                         int minTurnRoundTime,
                         bool areDelayedFlights = false);

      optional<ptime> extractNextFTOT_FLDT(vector<ptime> & availableFTOT_FLDTs,
                                           const LpiFlightPlan & fp,
                                           map<string, LpdbFPSchedule> scheduledFPs,
                                           map<string, LpdbFPSchedule> delayedInLastIntervalFPs,
                                           int minTurnRoundTime);

      vector<ptime>::iterator getClosestTimeTo(const ptime & uTime,
                                               vector<ptime> & availableTimes);

      vector<ptime>::iterator getMinTakeOfTime(const string & fpARRKey,
                                               int minTurnRoundTime,
                                               vector<ptime> & availableTimes,
                                               map<string, LpdbFPSchedule> scheduledFPs,
                                               map<string, LpdbFPSchedule> delayedInLastIntervalFPs);

      void calculateFPTimesForDelayedInLastInterval(string interval, int minTurnRoundTime);

//      void recalculateComparativeKPIs(LpiConfigurationAlertKPIs & alertThresholds);
//
//      void generateKPIs(LpiConfigurationAlertKPIs & alertThresholds,
//                        int delayCountThreshold,
//                        bool isClockForwarding,
//                        bool isInitialization = false);
//
//      void generateWarningsAlarms(LpiConfigurationAlertKPIs & alertThresholds);
//      void updateKPIsIntervals(LpiConfigurationAlertKPIs & alertThresholds,
//                               int delayCountThreshold,
//                               bool isClockForwarding,
//                               bool isInitialization = false);

      void updateMaxAndAverageKPIs(int delayCountThreshold);


      void updateTotalRealAccepted(string interval);
      void updateShortage(string interval);

      void updateKPIsRunways(string interval);

      //KPIs calculations v2
//      void generateRunwayAndAirportIntervalKPIs(string interval,
//                                                LpiConfigurationAlertKPIs & alertThresholds,
//                                                int delayCountThreshold,
//                                                bool isClockForwarding,
//                                                bool isInitialization = false);

      //getters and setters
      float getWeightMean () { return r_weight_mean; }
      void setWeightMean (float weightMean) { r_weight_mean = weightMean;}

      LpiADOVector<int>     getShortage()
      {return r_absolute_KPIs.getShortage(); }

      LpiADOVector<int>     getAccepted()
      {return r_absolute_KPIs.getTotalRealAcceptedFps(); }

      LpiADOVector<double>  getMaxForecastDelay()
      {return r_absolute_KPIs.getMaxForecastDelay(); }

      LpiADOVector<double>  getAverageForecastDelay()
      {return r_absolute_KPIs.getAverageForecastDelay(); }

      LpiADOVector<double>  getMaxPunctualityDelay()
      {return r_absolute_KPIs.getMaxPunctualityDelay(); }

      LpiADOVector<double>  getAveragePunctualityDelay()
      {return r_absolute_KPIs.getAveragePunctualityDelay(); }

      LpiADOVector<double>  getPunctualFP()
      {return r_absolute_KPIs.getPunctualFP(); }

      LpiADOVector<double>  getDelayedFP()
      {return r_absolute_KPIs.getDelayedFP(); }

      LpiADOVector<double>  getPunctualPorcentage()
      {return r_absolute_KPIs.getPunctualPorcentage(); }

      LpiADOVector<double> getAverageForecastedDelay_DelayedFPs()
      { return r_absolute_KPIs.getAverageForecastedDelay_DelayedFps(); }

      Warnings_alerts  getMaxForecastDelayWA()
      {return r_absolute_KPIs.getMaxForecastDelayWA(); }

      Warnings_alerts  getPunctualPorcentageWA()
      {return r_absolute_KPIs.getPunctualPorcentageWA(); }

      const LpdbAbsoluteKPIs & getAbsoluteKpis () const
      { return r_absolute_KPIs; }

      int getFrozenPeriod() const
      { return r_frozenPeriod; }

      void setFrozenPeriods(int numberOfIntervals)
      { r_frozenPeriod = numberOfIntervals; }

      LpiActivationType::ActivationType getOrigin() const
      { return r_origin; }

      void setOrigin(LpiActivationType::ActivationType origin)
      { r_origin = origin; }

      void reviewPastScheduledFPs();
      void eraseDelayedFPsInLastInterval();

      //TimeLine<LpdbSCHTimedData> compareTo(LpdbSchedule & anotherSchedule, LpiConfigurationAlertKPIs & alertThresholds);
      bool isPlannedFP (const string & fpKey);
      boost::optional<posix_time::ptime> getAssignedTime(const string & fpKey);

      std::string getIntervalAbsoluteKpisAsString();

      std::string toShortString();

      std::string getAvailableFTOTAndFLDTsAsString();

   protected:

      void calculateRealDemand  (string interval);
      void updateTotalAndInheritedDemand(string interval);
      void calculateNotAllowed  (string interval);
      void calculateNotAllowedWithCapacity  (string interval);
      void calculateTurnRounds(string interval, int minClosedTurnRound);
      void eliminateDelayedFPs(string interval);
      void sortByPriority(string interval);

      void calculateRealDelayed (string interval, double ratioARR, double ratioDEP);
      void calculateRealDelayedSegregated (string interval);
      void calculateRealDelayedMixed(string interval, double ratioARR, double ratioDEP);
      void calculateAccepted    (string interval);

      void storeRealDelayedFPsKeys (string interval);

      //Internal methods for runway allocations
      void calculateRunwayAllocation1ARR_1DEP(string interval); //Accepted & delayed are treated the same way
      void calculateRunwayAllocationAcceptedXARR_YDEP(string interval);
      void calculateRunwayAllocationAcceptedMixed(string interval);

      void calculateRunwayAllocationDelayedXARR_YDEP(string interval);
      void calculateRunwayAllocationDelayedMixed(string interval);

      void calculateScheduledRunwayCapacities(string interval);
      bool allocateFPs (string interval, int flights_type, vector<string> fpKeys);
      void delayFPs    (string interval, int flights_type, vector<string> fpKeys);

      bool isRSPlannedOfMixedUse(string interval);

      bool isAlreadyPlanned(string interval,
                            int fpType,
                            string associatedFPKey,
                            string & associatedFPPlannedInterval);
      bool isTurnRound(string associatedFPPlannedInterval, string interval, int minClosedTurnRound);
      void markTurnRoundFlights(string interval);

//      void accumulateRunwayWindowKPIs(const map<string, LpdbRwyScheduled> & runways);

   protected:

      TimeLine<LpdbSCHTimedData>    r_timeLine;

      LpdbAbsoluteKPIs              r_absolute_KPIs;
      map<string, LpdbFPSchedule>   r_fps_scheduled;
      map<string, LpdbFPSchedule>   r_fps_delayed_last_interval;
      float                        r_weight_mean;
      LpdbDelaysSplitter            r_delays_splitter;

      LpdbSCHTimedData              r_interval_t_minus_one;
      int                          r_frozenPeriod;

      LpiActivationType::ActivationType r_origin;
};


std::ostream& operator<<(std::ostream &os, const LpdbSchedule &info);


#endif /* LPBSCHEDULE_H_ */
