/**@file LpdbSchedule.h
 *
 * Base (not interface) schedule class.
 *
 * @warning See RMAN code as reference.
 *
 */

#ifndef LPDBSCHEDULE_H_
#define LPDBSCHEDULE_H_

#include <LpdbScheduleModule.h>

/* #include <LpiTimeParameters.h> */
/* #include <LpdbSCHTimedData.h> */
/* #include <LctimTimeLine.h> */
/* #include <LpdbGlobalParameters.h> */
/* #include <algorithm> */
/* #include <LclogStream.h> */
/* #include <LpdbFPDelayed.h> */
/* #include <LpdbFPSchedule.h> */
/* #include <LpiADOVector.h> */
/* #include <LpdbDelaysSplitter.h> */
/* #include <LpdbAbsoluteKPIs.h> */
/* #include <LpiActivationType.h> */
/* #include <LpiComparativeKpis.h> */

 /* @warning class LpdbScheduleConverter: */

 /*                Description: Utility class with static methods to */
 /* 		perform schedule conversion * from internal database */
 /* 		type to interface layer type */


#include <iosfwd>
#include <vector>

/* #include <string> */

/* #include <boost/optional.hpp> */
/* #include <boost/date_time/posix_time/posix_time.hpp> */

/* using boost::posix_time::ptime; */
/* using boost::optional; */

 
class LpdbSchedule
{

  friend std::ostream& operator<<(std::ostream &os, const LpdbSchedule &data);

 public:

  enum class ScheduleType { E_OPTIMAL, E_ACTIVE, E_ALTERNATIVE, E_DEFAULT };

  
  LpdbSchedule() = default; ///@todo FIXME

      /* LpdbSchedule(unsigned int min_subinterval, */
      /*             unsigned int hours_window, */
      /*             unsigned int min_frozen, */
      /*             boost::posix_time::ptime begin_timestamp); */

  LpdbSchedule(const LpdbSchedule & source) = default;
  LpdbSchedule & operator= (const LpdbSchedule & source) = default;

  virtual ~LpdbSchedule() {}

  //  virtual ScheduleType getType()const = 0;
  
      /* ///init use case */
      /* void init(const LpiTimeParameters & parameters, */
      /*           boost::posix_time::ptime begin_timestamp); */

      /* void init(unsigned int min_subinterval, */
      /*           unsigned int hours_window, */
      /*           unsigned int min_frozen, */
      /*           boost::posix_time::ptime begin_timestamp); */


      //Forward use case
  virtual void forward(); ///@todo FIXME  ¿puede virtyual?    = 0; 


      /* //Check if has data associated to one given interval name */
      /* bool has_data(const string & interval_name); */

      /* //Get one element from internal timeline for modification */
      /* LpdbSCHTimedData & operator[] (const string & interval_name); */



      /* void scheduleRunwaySystem (std::string interval, const LpdbRunwaySystem & rs); */
      /* //void allocateFP (std::string interval, LpdbFlightPlan & FP); */

      /* void setTimeLine (const TimeLine<LpdbSCHTimedData> & source); */
      /* TimeLine<LpdbSCHTimedData> & getTimeLine (); */
      /* const TimeLine<LpdbSCHTimedData> & getTimeLine () const; */


 protected:

  std::vector<LpdbScheduleModule> the_modules;

  /* TimeLine<LpdbSCHTimedData>    r_timeLine; */

  /* LpdbAbsoluteKPIs              r_absolute_KPIs; */
  /* std::map<string, LpdbFPSchedule>   r_fps_scheduled; */
  /* std::map<string, LpdbFPSchedule>   r_fps_delayed_last_interval; */
  /* double                        r_weight_mean; */
  /* LpdbDelaysSplitter            r_delays_splitter; */

  /* LpdbSCHTimedData              r_interval_t_minus_one; */
  /* unsigned int                          r_frozenPeriod; */

  /* LpiActivationType::ActivationType r_origin; */
};




#endif /* LPDBSCHEDULE_H_ */
