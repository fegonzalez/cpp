/*
 * LpdbProhibitions.h
 
   Description:
   List of Forbidden association (Airport A1, Airport A2) a given interval.
   Defined at DAORTP_AssignmentPreference.xml after
   <notAllowedAllocation> <allocation> tag.

   [ Example.-
       <allocation>
          <airport1> ENNM </airport1>
          <airport2> ENBV </airport2>
          <startTime> 10:00 </startTime>     // Managed in the Timeline<LpdbProhibitions> object
          <endTime> 18:00 </endTime>         // Managed in the Timeline<LpdbProhibitions> object
	    </allocation>
   end example ]
 
   Storage: key = Airport A1, value = A2
            std::unordered_multimap::find() complexity:
	    - Average case: constant.
	    - Worst case: linear in container size.
            info: as an association (A1, A2) is equivalent to (A2,A1)
                  two entries will be added to the table to allow the search
		  of both elements as keys.
 
   // RMAN's note: for schedules generation algorithm improvements in Phase III
 
 */


#ifndef LPDBPROHIBITIONS_H_
#define LPDBPROHIBITIONS_H_


#include <LpiAdapProhibConstants.h>

#include <iostream>
#include <unordered_map>
#include <string>
#include <set>


class LpdbProhibitions
{
 public:

  typedef std::unordered_multimap<std::string, std::string>
    LpdbProhibitionsStorageType;  
  typedef LpdbProhibitionsStorageType::const_iterator LpdbProhStorType_ConstItr;
  typedef LpdbProhibitionsStorageType::iterator LpdbProhStorType_Itr;

  LpdbProhibitions() = default;
  LpdbProhibitions(const LpdbProhibitions&) = default;
  LpdbProhibitions& operator=(const LpdbProhibitions&) = default;
  virtual ~LpdbProhibitions();


  const LpdbProhibitionsStorageType & getProhibitions() const;
  std::set<std::string> findAll(const std::string &key) const;
  bool findOne(const std::string &key, std::string &retVal) const;

  
  //void setProhibitions(const LpdbProhibitionsStorageType & new_val);
  void setProhibitions(const ProhibitionElementList & new_val);
  void addProhibition(const std::string & airport1,
		      const std::string & airport2);


 protected:

  //set<std::string> r_prohibitions;//RMAN
  LpdbProhibitionsStorageType r_prohibitions;

  void release();
};

std::ostream & operator<<(std::ostream & os, const LpdbProhibitions & info);


#endif /* LPDBPROHIBITIONS_H_ */
