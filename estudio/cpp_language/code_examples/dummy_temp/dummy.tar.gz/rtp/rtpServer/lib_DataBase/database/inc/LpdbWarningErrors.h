/*
 * LpdbWarningErrors.h
 *
 *  Created on: 31/07/2013
 *      Author: gpfernandez
 *      Description: Total timeline Airport KPIs Warnings and Alerts
 */

#ifndef LPBWARNINGERROR_H
#define LPBWARNINGERROR_H

#include <LpiWarningsAlerts.h>
#include <LpiSchedule.h>
#include <LpiADOVector.h>

using std::vector;
using std::string;

class LpdbWarningErrors
{
   public:

      LpdbWarningErrors();
      virtual ~LpdbWarningErrors() {}

      LpdbWarningErrors(const LpdbWarningErrors & source);
      LpdbWarningErrors & operator= (const LpdbWarningErrors & source);

      Warnings_alerts Alarm_Warning(int n1,
                                    LpiADO kpi,
                                    LpiADO alarmThreshold,
                                    LpiADO warningThreshold,
                                    string comparison);

      Warnings_alerts Alarm_Warning(int n1,
                                    LpiADOVector<double> kpi,
                                    LpiADO alarmThreshold,
                                    LpiADO warningThreshold,
                                    string comparison);

      const Warnings_alerts & getMaxForecastDelayWA()   const
      { return r_max_forecast_delayWA; }

      const Warnings_alerts & getPunctualPorcentageWA() const
      { return r_punctual_porcentageWA;}

      void setMaxForecastDelayWA  (const Warnings_alerts & aux)
      { r_max_forecast_delayWA = aux; }

      void setPunctualPorcentageWA(const Warnings_alerts & aux)
      { r_punctual_porcentageWA = aux;}

      Warnings_alerts  getAverageForecastedDelayDelayedFpsWA () const
      { return r_average_forecasted_delay_delayedFPsWA; }

      void setAverageForecastedDelayDelayedFpsWA (const Warnings_alerts aux)
      { r_average_forecasted_delay_delayedFPsWA = aux; }

      static Warnings_alerts convert2Interface (const vector<string> & calculatedWarnings);

   private:

      Warnings_alerts r_max_forecast_delayWA;
      Warnings_alerts r_punctual_porcentageWA;

      //PhaseII
      Warnings_alerts r_average_forecasted_delay_delayedFPsWA;
};

#endif // LPBWARNINGERROR_H
