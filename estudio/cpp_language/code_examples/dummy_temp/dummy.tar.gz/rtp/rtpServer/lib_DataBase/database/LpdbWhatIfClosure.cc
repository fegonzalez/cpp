/*
 * LpdbWhatIfClosure.cc
 *
 *  Created on: 14/05/2015
 *      Author: mbegega
 */

#include "LpdbWhatIfClosure.h"


LpdbWhatIfClosure::LpdbWhatIfClosure()
: r_runwayClosures(),
  r_closureType(LpiWhatIfClosure::E_UNKNOWN),
  r_alternativeScheduleId(-1)
{
}


LpdbWhatIfClosure::LpdbWhatIfClosure(const std::map<std::string, LpiRunwayClosure> & closures,
                                   const LpiWhatIfClosure::LpiWhatIfClosureType & closureType,
                                   int scheduleId)
: r_runwayClosures(closures),
  r_closureType(closureType),
  r_alternativeScheduleId(scheduleId)
{
}


LpdbWhatIfClosure::LpdbWhatIfClosure(const LpiWhatIfClosure & closureInterface)
: r_closureType(closureInterface.getClosureType()),
  r_alternativeScheduleId(closureInterface.getId())
{
   const std::vector<LpiRunwayClosure> & closures = closureInterface.getClosures();

   for (int i = 0; i < closureInterface.getNumberOfRunways(); ++i)
   {
      std::string runwayId = closures[i].getRunwayId();
      r_runwayClosures[runwayId] = closures[i];
   }
}


LpdbWhatIfClosure::LpdbWhatIfClosure(const LpiRunwayClosure & runwayClosure)
: r_closureType(LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE),
  r_alternativeScheduleId(-1)
{
   r_runwayClosures.clear();

   std::string runwayId = runwayClosure.getRunwayId();
   r_runwayClosures[runwayId] = runwayClosure;
}


LpdbWhatIfClosure::LpdbWhatIfClosure(const LpdbWhatIfClosure & source)
: r_runwayClosures(source.r_runwayClosures),
  r_closureType(source.r_closureType),
  r_alternativeScheduleId(source.r_alternativeScheduleId)
{
}


LpdbWhatIfClosure::~LpdbWhatIfClosure()
{
}


LpdbWhatIfClosure & LpdbWhatIfClosure::operator= (const LpdbWhatIfClosure & source)
{
   if (this != &source)
   {
      r_runwayClosures = source.r_runwayClosures;
      r_closureType = source.r_closureType;
      r_alternativeScheduleId = source.r_alternativeScheduleId;
   }

   return *this;
}


const std::map <std::string, LpiRunwayClosure> & LpdbWhatIfClosure::getAllRunwayClosures() const
{
   return r_runwayClosures;
}


const LpiWhatIfClosure::LpiWhatIfClosureType & LpdbWhatIfClosure::getClosureType() const
{
   return r_closureType;
}


int LpdbWhatIfClosure::getAlternativeScheduleId() const
{
   return r_alternativeScheduleId;
}


void LpdbWhatIfClosure::setAlternativeScheduleId(int id)
{
   r_alternativeScheduleId = id;
}


void LpdbWhatIfClosure::setClosureType(const LpiWhatIfClosure::LpiWhatIfClosureType & closureType)
{
   r_closureType = closureType;
}


void LpdbWhatIfClosure::addRunwayClosure(const std::string & runwayId, const LpiRunwayClosure & closure)
{
   if (r_runwayClosures.count(runwayId) == 0)
   {
      r_runwayClosures[runwayId] = closure;
   }
}


void LpdbWhatIfClosure::deleteRunwayClosure(const std::string & runwayId)
{
   if (r_runwayClosures.count(runwayId) == 0)
   {
      r_runwayClosures.erase(runwayId);
   }
}


bool LpdbWhatIfClosure::exists(const std::string & runwayId)
{
   return (r_runwayClosures.count(runwayId) > 0);
}


LpiRunwayClosure & LpdbWhatIfClosure::operator[] (const std::string & runwayId)
{
   return r_runwayClosures[runwayId];
}


int LpdbWhatIfClosure::getNumberOfElements() const
{
   return r_runwayClosures.size();
}


const LpiRunwayClosure & LpdbWhatIfClosure::getFirstClosure() const
{
   return r_runwayClosures.begin()->second;
}


bool LpdbWhatIfClosure::isBestPointClosureType() const
{
   return (r_closureType == LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE) ||
          (r_closureType == LpiWhatIfClosure::E_BEST_POINT_CLOSURE_FOR_ACTIVE);
}


std::ostream & operator<<(std::ostream &os, const LpdbWhatIfClosure & closure)
{
   std::stringstream runwayClosuresForLog;

   std::map <std::string, LpiRunwayClosure>::const_iterator itr;

   const std::map <std::string, LpiRunwayClosure> & rwyClosures = closure.getAllRunwayClosures();

   for (itr = rwyClosures.begin(); itr != rwyClosures.end(); ++itr)
   {
      runwayClosuresForLog << (*itr).second << "\n";
   }

   os << "[TYPE: " << LpiWhatIfClosure::ClosureTypeToString(closure.getClosureType())
      << "| SCH_ID: " << closure.getAlternativeScheduleId()
      << "| CLOSURES:\n" << runwayClosuresForLog.str() << ']';

   return os;
}
