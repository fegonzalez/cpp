/*
 * LpdbAbsoluteKPIs.h
 *
 *  Created on: 22/07/2013
 *      Author: gpfernandez
 */

#ifndef LPBABSOLUTEKPIS_H
#define LPBABSOLUTEKPIS_H

#include <iostream>
#include <map>
#include <string>
#include <boost/foreach.hpp>
#include <LpiADOVector.h>
//#include <LpdbFPSchedule.h>
//#include <LpdbSCHTimedData.h>
#include <LpdbWarningErrors.h>
#include <LctimTimeLine.h>

class KpisRunways
{
   public:
        LpiADOVector<int> kpis_ShortageTotal;
        LpiADOVector<int> kpis_AllocatedTotal;
};


class LpdbAbsoluteKPIs
{

public:

   LpdbAbsoluteKPIs();
   LpdbAbsoluteKPIs(const LpdbAbsoluteKPIs & source);

   virtual ~LpdbAbsoluteKPIs() {}

   LpdbAbsoluteKPIs & operator= (const LpdbAbsoluteKPIs & source);

  /* void updateMaxAndAverageKPIs(int delayCountThreshold,
                                const std::map<std::string, LpdbFPSchedule> & scheduledFps,
                                const std::map<std::string, LpdbFPSchedule> & delayedFpsInLastInterval);
*/
   void updateShortage(const LpiADOVector<int> &shortage);
   void updateShortageInterval(string interval, const LpiADOVector<int> &shortage);
   void updateTotalRealAccepted(const LpiADOVector<int> &totalRealAccepted);
   void updateAcceptedInterval(string interval,const LpiADOVector<int> &totalRealAccepted);
   //void updateKPIsRunways(std::map<std::string, LpdbRwyScheduled> runways);
   void updateRunwaysTotalAccepted(std::string id_runway,const LpiADOVector<int> & numberOfAllocatedFps);
   void updateRunwaysTotalShortage(std::string id_runway,const LpiADOVector<int> & numberOfDelayedFps);

   void deleteShortage(const LpiADOVector<int> & shortage);
   void deleteFromTotalRealAccepted(const LpiADOVector<int> & totalRealAccepted);
   void deleteFromRunwaysTotalAccepted(std::string id_runway,const LpiADOVector<int> & numberOfAllocatedFps);
   void deleteFromRunwaysTotalShortage(std::string id_runway,const LpiADOVector<int> & numberOfDelayedFps);
   //void deleteFromRunwaysKPIs(std::map<std::string, LpdbRwyScheduled> runways);

   //void generateWarningsAlarms(const LpdbAbsoluteKPIs &absoluteKPIs, LpiConfigurationAlertKPIs &alertKPIs);

   //getters

   const LpiADOVector<int>     & getTotalRealAcceptedFps()    const { return r_total_real_accepted_fps; }
   const LpiADOVector<int>     & getTotalRealDelayFps()       const { return r_total_real_delay_fps;    }
   const LpiADOVector<int>     & getShortage()                const { return r_shortage;                }
   const LpiADOVector<double>  & getMaxForecastDelay()        const { return r_max_forecast_delay;      }
   const LpiADOVector<double>  & getAverageForecastDelay()    const { return r_average_forecast_delay;  }
   const LpiADOVector<double>  & getMaxPunctualityDelay()     const { return r_max_punctuality_delay;   }
   const LpiADOVector<double>  & getAveragePunctualityDelay() const { return r_average_punctuality_delay;}
   const LpiADOVector<double>  & getPunctualFP()              const { return r_punctual_fp;             }
   const LpiADOVector<double>  & getDelayedFP()               const { return r_delayed_fp;              }
   const LpiADOVector<double>  & getPunctualPorcentage()      const { return r_punctual_porcentage;     }

   LpiADOVector<double> getAverageForecastedDelay_DelayedFps () const { return r_average_forecasted_delay_delayedfps; }

   const Warnings_alerts  getMaxForecastDelayWA() const
   { return r_warningErrors.getMaxForecastDelayWA();  }

   const Warnings_alerts  getPunctualPorcentageWA() const
   { return r_warningErrors.getPunctualPorcentageWA();  }

   const Warnings_alerts  getAverageForecastedDelayDelayedFpsWA() const
   { return r_warningErrors.getAverageForecastedDelayDelayedFpsWA();  }

   const LpdbWarningErrors & getWarningAlarms()
   { return r_warningErrors; }

   //setters
   void setShortage(const LpiADOVector<int> &aux)             { r_shortage = aux; }
   void setTotalRealAcceptedFps(const LpiADOVector<int> &aux) { r_total_real_accepted_fps = aux; }
   void setTotalRealDelayFps(const LpiADOVector<int> &aux)    { r_total_real_delay_fps = aux; }

   void reset();

protected:

   LpiADOVector<int>               r_total_real_accepted_fps;
   LpiADOVector<int>               r_total_real_delay_fps;
   LpiADOVector<int>               r_shortage;
   LpiADOVector<double>            r_max_forecast_delay;
   LpiADOVector<double>            r_average_forecast_delay;
   LpiADOVector<double>            r_max_punctuality_delay;
   LpiADOVector<double>            r_average_punctuality_delay;
   LpiADOVector<double>            r_punctual_fp;
   LpiADOVector<double>            r_delayed_fp;
   LpiADOVector<double>            r_punctual_porcentage;
   LpiADOVector<double>            r_average_forecasted_delay_delayedfps;
   LpdbWarningErrors                r_warningErrors;

   map<string, KpisRunways>        r_kpis_runways;
};


std::ostream & operator<<(std::ostream & os, const LpdbAbsoluteKPIs & info);

#endif //LPBABSOLUTEKPIS_H
