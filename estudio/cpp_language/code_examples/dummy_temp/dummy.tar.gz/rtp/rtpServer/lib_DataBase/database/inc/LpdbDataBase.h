/*
 * LpdbDataTable.h
 *
 *
 *  Description: RTP Internal global database
 *
 * @warning Starting from the RMAN DB design => RMAN tables => some of them are not valid RTP tables
 *
 * @todo Add all the required tables (task spared among all the RTP tasks)
 *
 * @todo remove all the unused (RMAN) tables (task spared among all the RTP tasks)
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx"
 */


#if !defined(__LPDB_DATA_BASE_H__)
#define __LPDB_DATA_BASE_H__

#include <LctimTimeLine.h>

#include <LpdbGlobalParameters.h>
#include <LpdbCommon.h>
#include <LpdbDataTable.h>
#include <LpdbDataTableBest.h>
#include <LpdbDemand.h>

#include <LpdbProhibitions.h>
#include <LpdbPreferences.h>
#include <LpdbMeteoTimedData.h>
#include <LpdbDataTableAutoIndex.h>
#include <LpdbWhatIfClosure.h>
#include <LpdbAirport.h>
#include <LpdbSchedule.h>
#include <LpdbOptimalSchedule.h>
#include <LpdbActiveSchedule.h>
//#include <LpdbAlternativeSchedule.h>
#include <LpdbFPSchedule.h>

#include <LpiTimeParameters.h>
#include <LpiWeightPonderationParameters.h>
#include <LpiAdaptationMrtmInfo.h>

#include <LpiPriorityTable.h>
#include <LpiAdaptationAssignmentPreference.h>
#include <LpiAdaptationAlert_KPIs.h>
#include <LpiOptimizationCriteria.h>
#include <LpiFlightPlan.h>
#include <LpiMeteoInfo.h>
#include <LpiSchedule.h>

/**@warning Vortex reductions not in current RTP version (January 2019)
#include <LpiWakeVortexCapacityReductions.h>
*/

#include <iostream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <memory> // std::shared_ptr

class LpiConfigurationCoreParameters;
class LpiAdaptationAirportsInfo;
class LpiScheduleRTP;


/**@class LpdbDataBase

   @brief The data base of the RTP server.
 */

class LpdbDataBase
{
public:

   typedef LpdbDataTable<KEY_AIRPORT_ID, LpdbAirport> AirportTable;

   /**@warning Alternative schedules not in current RTP version (January 2019)

   typedef LpdbDataTableAutoIndex<LpdbAlternativeSchedule> AlternativeScheduleTable;
   typedef LpdbDataTableAutoIndex<LpdbWhatIfClosure> WhatIfClosureTable;

   AlternativeScheduleTable & getAlternativeScheduleTable()
   { return r_alternativeSchedulesTable; }

   WhatIfClosureTable & getWhatIfClosureTable()
   { return r_whatIfClosuresTable; }

   std::string getAlternativeScheduleRwyAllocationsAsString(int scheduleId);

   */

   /**@warning Vortex reductions not in current RTP version (January 2019)

    //   LpiWakeVortexCapacityReductions & getWakeVortexReductions ()
    //   { return r_WtcReductions; }


    //   void setWakeVortexReductions (const LpiWakeVortexCapacityReductions & reductions)
    //   { r_WtcReductions = reductions; }
    */


   static LpdbDataBase& Get(void)
   {
      static LpdbDataBase database;
      return database;
   }

   AirportTable & getAirportTable()
   { return r_airportsTable; }

   TimeLine<LpdbProhibitions> & getProhibitionsTimeline();
   void setProhibitionsTimeline(TimeLine<LpdbProhibitions> & data);

   TimeLine<LpdbPreferences> & getPreferencesTimeline();
   void setPreferencesTimeline(TimeLine<LpdbPreferences> & data);
   

   ////////////////////////////////////////
   /// Demand Info
   ///////////////////////////////////////
   LpdbDemand & getDemand(const std::string &airport);
   LpdbAirport::FPTable & getFPTable(const KEY_AIRPORT_ID &airport);


   ////////////////////////////////////////
   /// Meteo Info: stored within
   ///////////////////////////////////////
   LpiMeteoInfo & getMeteoInfo();
   void setMeteoInfo(const LpiMeteoInfo & _meteoInfo);

   //per airport's timeline
   TimeLine<LpdbMeteoTimedData> & getMeteoForecast(const KEY_AIRPORT_ID &airport);
   void setMeteoForecast(const KEY_AIRPORT_ID &airport,
			 const TimeLine<LpdbMeteoTimedData> & data);
   
   //Methods to manage list of received meteo reports


   ///@warning LpdbDataTable causes a linkage error if the function is "const"
   unsigned int getNumberOfMeteoReportsReceived (const KEY_AIRPORT_ID & airport); // const;
   std::vector<LpiMeteoInfo> getReceivedMeteoReports (const KEY_AIRPORT_ID &airport);// const;

   ///@warning: assert index < getNumberOfMeteoReportsReceived() before call
   LpiMeteoInfo getMeteoReport (const KEY_AIRPORT_ID &airport, const unsigned int index);
   void addMeteoReport (const KEY_AIRPORT_ID &airport, const LpiMeteoInfo &report);
   void deleteObsoleteMeteoReports (const KEY_AIRPORT_ID &airport);
   //void deleteMeteoReport (const KEY_AIRPORT_ID &airport, unsigned int index);

   
   boost::posix_time::ptime getTimeLineBase() const
   { return r_timelineBase; }


   void init(const LpiConfigurationCoreParameters &configCoreParams,
	     const LpiAdaptationMrtmInfo &mrtmInfo,
	     const LpiAdaptationAirportsInfo &airportInfoList,
	     const LpiPriorityTable &priorityTableDepartures,
	     const LpiPriorityTable &priorityTableArr,
	     const LpiAdaptationAssignmentPreference &assPref,
	     const LpiAdaptationAlert_KPIs &adapAlertKpi);
	//     const LpiWakeVortexCapacityReductions &wtcCapacity);

   void initTimeLine(const LpiTimeParameters & timeData,
		             const boost::posix_time::ptime & now);

   LpdbGlobalParameters getGlobalParameters() const {return r_globalParameters;}


   void forwardTimeline();


   // Schedule logic
   void setOptimalSchedule (const LpiScheduleRTP & schedule);
   std::shared_ptr<LpdbOptimalSchedule> getOptimalSchedule ();
   bool hasOptimalSchedule () const;
   void setActiveSchedule (const LpiScheduleRTP & schedule);
   std::shared_ptr<LpdbActiveSchedule> getActiveSchedule ();
   bool hasActiveSchedule () const;


   boost::posix_time::ptime getActivationTime() const;
   void setActivationTime(boost::posix_time::ptime timestamp);

   void setInputReceivedInLastInterval(bool value)
   { r_inputReceivedInLastInterval = value; }

   bool getInputReceivedInLastInterval()
   { return r_inputReceivedInLastInterval; }

   //Methods for specific trace/logging usage
   //They use fields from different objects

   std::string getEstimatedDCBAsString ();
   std::string getRunwaySystemRunwaysCapacitiesAsString();
   std::string getRunwaySystemsCapacitiesAsString();


   ///@todo uncomment iff required in RTP
   /* std::string getScheduledFlightPlansAsString(LpdbSchedule::ScheduleType type_of_schedule, int schedule_index = 0); */
   /* std::string getScheduledFPAsString(const LpdbFPSchedule & flightPlan); */

   /* std::string getScheduleInterfaceAsString(LpiSchedule & schedule, LpdbSchedule::ScheduleType type_of_schedule); */
   /* std::string getCapacityReductionsAsString(const std::vector<std::string> & ids_rwys); */
   /* std::string getRealAcceptedAndShortageAsString(int schedule_id); */
   /* std::string getMaxAndAverageKPIsAsString(int schedule_id); */

   /* std::string getRealAcceptedAndShortageAsString(LpdbSchedule::ScheduleType schedule_type); */
   /* std::string getMaxAndAverageKPIsAsString(LpdbSchedule::ScheduleType schedule_type); */
   /* //Trace strings for logging */
   /* std::string getKPIsPerIntervalAsString(LpdbSchedule::ScheduleType schedule_type); */


   void print (std::ostream & out) const;
   //std::ostream& prinMeteoTimeline(std::ostream &out)const; // log purpose only


private: // Private methods

   LpdbDataBase() = default;
   LpdbDataBase(const LpdbDataBase&) = delete;
   LpdbDataBase& operator=(const LpdbDataBase&) = delete;

   void generateIntervalProhibitions();
   void generateIntervalProhibitions(const std::string &interval);

   void generateIntervalPreferences();
   void generateIntervalPreferences(const std::string &interval);

   //airports: adap info, meteo, demand, ...
   void initAirports(const LpiAdaptationAirportsInfo & airportsInfo,
                     const LpiTimeParameters & timeData,
		     const boost::posix_time::ptime &now,
				const PonderationAirports & complexityWeights);
   void forwardAirportsTable();

   

private:

   /**@param r_airportsTable: storing data related to an airport:
    *
    * - meteo: r_airportsTable[i]::r_meteoLine
    * - demand: r_airportsTable[i]::r_demand
    * - capacity values
    * - complexity
    *   * complexity values
    * 	* complexity KPIs
    * 	* total movements KPIs
    * 	* VFR KPIS
    *
    *   //RTP verified!
    */
   AirportTable r_airportsTable;


   // management of prohibitions & preferences

   /**@param r_adapPreferencesAndProhibitions
    *
    * A copy of the preferences & prohibions information from the
    * adaptation file.
    *
    * Must be stored to update 'r_prohibitionsTimeline' and
    * 'r_preferencesTimeline' in forwardTimeline()
   */
   LpiAdaptationAssignmentPreference r_adapPreferencesAndProhibitions;

   /**@param r_prohibitionsTimeline
    *
    * @brief Forbidden associations (Airport A1, Airport A2) per interval.
    *
    * Design definition: (see doc [1].4.1)
    * Input data: DAORTP_AssignmentPreference.xml ( <notAllowedAllocation> tag)
    *
    * Analog to LpdbRSProhibitionsTimedData in RMAN
    *
    */
   TimeLine<LpdbProhibitions> r_prohibitionsTimeline;

   /**@param r_preferencesTimeline
    *
    * @brief Preference associations (Airport A1, Airport A2) per interval.
    *
    * Design definition: (see doc [1].4.1)
    * Input data: DAORTP_AssignmentPreference.xml ( <notAllowedAllocation> tag)
    *
    */
   TimeLine<LpdbPreferences> r_preferencesTimeline;


   LpdbGlobalParameters         r_globalParameters;

/**@warning Vortex reductions not in current RTP version (January 2019)

      current version of RTP project.
      @todo Uncomment iff WTC is added to the RTP.
    //LpiWakeVortexCapacityReductions r_WtcReductions;
*/

   // Schedule logic
   std::shared_ptr<LpdbOptimalSchedule> the_optimalSchedule = nullptr;
   bool the_hasOptimalSchedule_flag = false;
   std::shared_ptr<LpdbActiveSchedule> the_activeSchedule = nullptr;
   bool the_hasActiveSchedule_flag = false;
   /**@warning Alternative schedules not in current RTP version (January 2019)
   AlternativeScheduleTable r_alternativeSchedulesTable; ///@todo RTP: required?
   WhatIfClosureTable r_whatIfClosuresTable; ///@todo RTP: required?
   */


   boost::posix_time::ptime r_activationTime;

   //Time base for schedules creation
   boost::posix_time::ptime r_timelineBase;

   //Demand, Meteo nowcast/forecast or airport operational status received
   bool r_inputReceivedInLastInterval = false; ///@todo Remove todo iff cctually used?

};


std::ostream& operator<<(std::ostream &os, const LpdbDataBase &db);

#endif // __LPDB_DATA_BASE_H__
