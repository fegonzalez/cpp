/*
 * LpdbDataTable.h
 *
 *
 *  Description: RTP Internal global database
 *
 * @warning Starting from the RMAN DB design => RMAN tables => some of them are not valid RTP tables
 *
 * @todo Add all the required tables (task spared among all the RTP tasks)
 *
 * @todo remove all the unused (RMAN) tables (task spared among all the RTP tasks)
 *
 * @warning The following files are not part of the initial RTP design
	logic, and they will be removed from the system after assuring they are not required:

	DAORTP_SmRunwaySystem.xml  => RunwaySystemTable
	DAORTP_SmRunway.xml        => RunwayTable  //  LpdbRunway basada en fichero de RMAN, no en datos RTP (<runway> de file DAORTP_AirportsInfo.xml)​
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx"
 */


#if !defined(__LPDB_DATA_BASE_H__)
#define __LPDB_DATA_BASE_H__

#include <iostream>
#include <map>
#include <set>
#include <vector>

#include <LctimTimeLine.h>
#include <LpiFlightPlan.h>
#include "LpiMeteoInfo.h"
#include "LpdbRunway.h"
#include "LpdbRunwaySystem.h"
#include "LpdbSchedule.h"
#include "LpdbDataTable.h"
#include "LpdbDataTableBest.h"
#include "LpdbDemand.h"
#include "LpdbDCBAirportTimedData.h"
#include "LpdbProhibitions.h"
#include <LpdbPreferences.h>
#include "LpdbMeteoTimedData.h"
#include "LpiTimeParameters.h"
#include "LpiWeightPonderationParameters.h"
#include <LpiAdaptationRunway.h>
#include <LpiAdaptationRunwaySystem.h>
#include <LpiAdaptationMrtmInfo.h>
//#include <LpiAdaptationAirportsInfo.h>
#include <LpiPriorityTable.h>
#include <LpiAdaptationAssignmentPreference.h>
#include <LpiAdaptationAlert_KPIs.h>

#include <LpiWakeVortexCapacityReductions.h>

 #include <LpiOptimizationCriteria.h>

#include <LpdbAlternativeSchedule.h>
#include <LpdbDataTableAutoIndex.h>
#include <LpdbWhatIfClosure.h>
#include <LpdbAirport.h>

#include <string>
using std::string;

class LpdbRunwaySystemsMemento;
class LpiConfigurationCoreParameters;
class LpiAdaptationAirportsInfo;

class LpdbDataBase
{
public:

   typedef std::string KEY_AIRPORT_ID;
   typedef LpdbDataTable<KEY_AIRPORT_ID, LpdbAirport> AirportTable;


   typedef LpdbDataTable<string, LpiFlightPlan> FPTable;

   typedef LpdbDataTable<string, LpdbRunway> RunwayTable; //see warning at header
   // LpdbRunway basada en fichero de RMAN, no en datos RTP (<runway> de file DAORTP_AirportsInfo.xml)
   // tabla de: RunwaysAiports + airpot_name
   // XOR no guardar tabla de WWs, sino guardar Table de Airports que las contenga

   typedef LpdbDataTable<string, LpdbRunwaySystem> RunwaySystemTable; //see warning at header

   typedef LpdbDataTableBest<int, LpdbSchedule> ScheduleTable;
   typedef LpdbDataTableAutoIndex<LpdbAlternativeSchedule> AlternativeScheduleTable;
   typedef LpdbDataTableAutoIndex<LpdbWhatIfClosure> WhatIfClosureTable;

   static LpdbDataBase& Get(void)
   {
      static LpdbDataBase database;
      return database;
   }

   AirportTable & getAirportTable()
   { return r_airportsTable; }

   FPTable & getFPTable()
   { return r_fpsTable; }

   ScheduleTable & getScheduleTable()
   { return r_schedulesTable; }

   AlternativeScheduleTable & getAlternativeScheduleTable()
   { return r_alternativeSchedulesTable; }

   WhatIfClosureTable & getWhatIfClosureTable()
   { return r_whatIfClosuresTable; }

   RunwayTable & getRunwayTable()
   { return r_runwayTable; }

   RunwaySystemTable & getRunwaySystemTable()
   { return r_runwaySystemTable; }


   TimeLine<LpdbDCBAirportTimedData> & getDCBAirportTimeline();
   void setDCBAirportTimeline(TimeLine<LpdbDCBAirportTimedData> & data);

   TimeLine<LpdbProhibitions> & getProhibitionsTimeline();
   void setProhibitionsTimeline(TimeLine<LpdbProhibitions> & data);

   TimeLine<LpdbPreferences> & getPreferencesTimeline();
   void setPreferencesTimeline(TimeLine<LpdbPreferences> & data);
   
//   LpiFileCapacityReductions & getFileReductions ()
//   { return r_fileReductions; }


   LpiWakeVortexCapacityReductions & getWakeVortexReductions ()
   { return r_WtcReductions; }

//   void setFileReductions (const LpiFileCapacityReductions & reductions)
//   { r_fileReductions = reductions; }

//   LpiRunwayDependencyReductions & getRunwayDependencyReductions()
//   { return r_dependencyReductions; }


   void setWakeVortexReductions (const LpiWakeVortexCapacityReductions & reductions)
   { r_WtcReductions = reductions; }

//   void setRunwayDependencyReductions(const LpiRunwayDependencyReductions & reductions)
//   { r_dependencyReductions = reductions; }




   ////////////////////////////////////////
   /// Demand Info
   ///////////////////////////////////////
   LpdbDemand & getDemand(const std::string &airport);


   ////////////////////////////////////////
   /// Meteo Info: stored within
   ///////////////////////////////////////
   LpiMeteoInfo & getMeteoInfo();
   void setMeteoInfo(const LpiMeteoInfo & _meteoInfo);

   //per airport's timeline
   TimeLine<LpdbMeteoTimedData> & getMeteoForecast(const KEY_AIRPORT_ID &airport);
   void setMeteoForecast(const KEY_AIRPORT_ID &airport,
			 const TimeLine<LpdbMeteoTimedData> & data);
   
   //Methods to manage list of received meteo reports


   ///@warning LpdbDataTable casuse linkage error if the function is "const"
   unsigned int getNumberOfMeteoReportsReceived (const KEY_AIRPORT_ID & airport); // const;
   std::vector<LpiMeteoInfo> getReceivedMeteoReports (const KEY_AIRPORT_ID &airport);// const;

   ///@warning: assert index < getNumberOfMeteoReportsReceived() before call
   LpiMeteoInfo getMeteoReport (const KEY_AIRPORT_ID &airport, const unsigned int index);

   void addMeteoReport (const KEY_AIRPORT_ID &airport, const LpiMeteoInfo &report);
   void deleteObsoleteMeteoReports (const KEY_AIRPORT_ID &airport);
   //void deleteMeteoReport (const KEY_AIRPORT_ID &airport, unsigned int index);
   /**@warning getLastReceivedMeteoReport: UNUSED in RMAN
 boost::optional<LpiMeteoInfo> getLastReceivedMeteoReport (const KEY_AIRPORT_ID &airport) const;
   */

   
   boost::posix_time::ptime getTimeLineBase() const
   { return r_timelineBase; }


   void init(const LpiConfigurationCoreParameters &configCoreParams,
	     const LpiAdaptationMrtmInfo &mrtmInfo,
	     const LpiAdaptationAirportsInfo &airportInfoList,
	     const LpiPriorityTable &priorityTableDepartures,
	     const LpiPriorityTable &priorityTableArr,
	     const LpiAdaptationAssignmentPreference &assPref,
	     const LpiAdaptationAlert_KPIs &adapAlertKpi,
	     const LpiWakeVortexCapacityReductions &wtcCapacity
	     );
   void initTimeLine(const LpiTimeParameters & timeData,
		              const boost::posix_time::ptime & now);

   LpdbGlobalParameters getGlobalParameters() const;
   void print (std::ostream & out) const;
   //std::ostream& prinMeteoTimeline(std::ostream &out)const; // log purpose only


   void forwardTimeline();

   void setOptimalSchedule (const LpdbSchedule & schedule);
   LpdbSchedule & getOptimalSchedule ();
   bool hasOptimalSchedule () const;

   void setActiveSchedule (const LpdbAlternativeSchedule & schedule);
   LpdbAlternativeSchedule & getActiveSchedule ();
   bool hasActiveSchedule () const;

   boost::posix_time::ptime getActivationTime() const;
   void setActivationTime(boost::posix_time::ptime timestamp);

   //Backup/Restore Runways and RS tables via memento pattern
   //This class acts as an originator
   LpdbRunwaySystemsMemento createRunwaySystemsMemento() const;
   void setRunwaySystemsMemento (const LpdbRunwaySystemsMemento & memento);

   void setInputReceivedInLastInterval(bool value)
   { r_inputReceivedInLastInterval = value; }

   bool getInputReceivedInLastInterval()
   { return r_inputReceivedInLastInterval; }

   //Methods for specific trace/logging usage
   //They use fields from different objects

   string getEstimatedDCBAsString ();
   string getRunwaysCapacitiesAsString();
   string getRunwaySystemRunwaysCapacitiesAsString();
   string getRunwaySystemsCapacitiesAsString();

   string getRunwayAllocationsAsString();
   string getAlternativeScheduleRwyAllocationsAsString(int scheduleId);

   string getRunwayFinalAssignationAsString();
   string getScheduledFlightPlansAsString(LpdbSchedule::ScheduleType type_of_schedule, int schedule_index = 0);
   string getScheduledFPAsString(const LpdbFPSchedule & flightPlan);

   string getScheduleInterfaceAsString(LpiSchedule & schedule, LpdbSchedule::ScheduleType type_of_schedule);
   string getCapacityReductionsAsString(const std::vector<string> & ids_rwys);
   string getRealAcceptedAndShortageAsString(int schedule_id);
   string getMaxAndAverageKPIsAsString(int schedule_id);

   string getRealAcceptedAndShortageAsString(LpdbSchedule::ScheduleType schedule_type);
   string getMaxAndAverageKPIsAsString(LpdbSchedule::ScheduleType schedule_type);

   //Trace strings for logging
   string getKPIsPerIntervalAsString(LpdbSchedule::ScheduleType schedule_type);

private: // Private methods

   LpdbDataBase() = default;
   LpdbDataBase(const LpdbDataBase&) = delete;
   LpdbDataBase& operator=(const LpdbDataBase&) = delete;

   void addRunways(const LpiAdaptationRunwayList & runways,
                   const LpiTimeParameters & timeData,
                   boost::posix_time::ptime begin_timestamp);

   void addRunwaySystems(const LpiAdaptationRunwaySystemList & rs,
                         const LpiTimeParameters & parameters,
                         boost::posix_time::ptime begin_timestamp);

   void generateIntervalProhibitions();
   void generateIntervalProhibitions(const std::string &interval);

   void generateIntervalPreferences();
   void generateIntervalPreferences(const std::string &interval);

   //airports: adap info, meteo, demand, ...
   void initAirports(const LpiAdaptationAirportsInfo & airportInfoList,
                     const LpiTimeParameters & timeData,
					 const boost::posix_time::ptime &now);
   void forwardAirportsTable();

   

private: // Private fields


   ///@warning Starting from the RMAN DB design => RMAN tables => some of them are not valid RTP tables

   ///@todo remove all the unused tables

   FPTable                     r_fpsTable; ///@todo RTP: required?  initialise

   RunwayTable                 r_runwayTable;  // key = par{<airportName>, <runwayName>} ///@todo RTP: required?  initialise


   RunwaySystemTable           r_runwaySystemTable; /////@todo RMAN only, remove when..

   ScheduleTable               r_schedulesTable; ///@todo RTP: required?  initialise
   AlternativeScheduleTable    r_alternativeSchedulesTable; ///@todo RTP: required?  initialise
   WhatIfClosureTable          r_whatIfClosuresTable; ///@todo RTP: required?  initialise




   /**@param r_airportsTable: storing data related to an airport:
    *
    * - meteo: r_airportsTable[i]::r_meteoLine
    * - demand: r_airportsTable[i]::r_demand
    * - complexity thresholds
    *   //RTP verified!
    */
   AirportTable r_airportsTable;    //Airport info  //RTP verified!




   /**@param r_DCBAirportTimeline
    * @warning RMAN only: DCB Suitability
    * @todo RMAN only, remove when not called anymore
	*/
   TimeLine<LpdbDCBAirportTimedData> r_DCBAirportTimeline;


   // management of prohibitions & preferences

   /**@param r_adapPreferencesAndProhibitions
    *
    * A copy of the preferences & prohibions information from the
    * adaptation file.
    *
    * Must be stored to update 'r_prohibitionsTimeline' and
    * 'r_preferencesTimeline' in forwardTimeline()
   */
   LpiAdaptationAssignmentPreference r_adapPreferencesAndProhibitions;  //RTP verified!

   /**@param r_prohibitionsTimeline
    *
    * @brief Forbidden associations (Airport A1, Airport A2) per interval.
    *
    * Design definition: (see doc [1].4.1)
    * Input data: DAORTP_AssignmentPreference.xml ( <notAllowedAllocation> tag)
    *
    * Analog to LpdbRSProhibitionsTimedData in RMAN
    *
    */
   TimeLine<LpdbProhibitions> r_prohibitionsTimeline;  //RTP verified!

   /**@param r_preferencesTimeline
    *
    * @brief Preference associations (Airport A1, Airport A2) per interval.
    *
    * Design definition: (see doc [1].4.1)
    * Input data: DAORTP_AssignmentPreference.xml ( <notAllowedAllocation> tag)
    *
    */
/*
   RMAN similar:   /DAORMAN_RwySystemPreference.xml => LpiAdaptationRunwaySystemPreference =>
   BusinessLogicFacade (line 337): LpiAdaptationRunwaySystemPreferenceList preferences; =>
   => _schedules_generator->setPreferentialLevels(preferences);

   => USO:


   getPreferentialRunwaySystem()  devuelve las preferenceias
=>
LpschAbstractSchedulesGenerator::generateDefaultSchedule (){
  boost::optional<string> runway_system = LpiRSPreferenceCalendar::getPreferentialRunwaySystem(ti, r_preferential_levels);
...
}
   */
   TimeLine<LpdbPreferences> r_preferencesTimeline;  //RTP verified!




   LpdbGlobalParameters         r_globalParameters; //RTP verified!

   //Reduction rules
   //LpiFileCapacityReductions r_fileReductions; /////@todo RMAN only, remove when..

    LpiWakeVortexCapacityReductions r_WtcReductions;  //RTP verified!

    //LpiRunwayDependencyReductions r_dependencyReductions; /////@todo RMAN only, remove when..




   LpdbSchedule r_optimalSchedule; ///@todo RTP: required?  initialise
   bool r_hasOptimalSchedule;///@todo RTP: required?  initialise

   LpdbAlternativeSchedule r_activeSchedule;///@todo RTP: required?  initialise
   bool r_hasActiveSchedule;///@todo RTP: required?  initialise
   boost::posix_time::ptime r_activationTime;///@todo RTP: required?  initialise

   //Time base for schedules creation
   boost::posix_time::ptime r_timelineBase;  //RTP verified!

   //Demand, Meteo nowcast/forecast or airport operational status received
   bool r_inputReceivedInLastInterval; //RTP verified!

};


std::ostream& operator<<(std::ostream &os, const LpdbDataBase &db);

#endif // __LPDB_DATA_BASE_H__
