/**@file LpdbOptimalSchedule.h
 *
 *
 */

#ifndef LPDB_OPTIMAL_SCHEDULE_H_
#define LPDB_OPTIMAL_SCHEDULE_H_

#include <LpdbSchedule.h>

class LpiScheduleRTP;


/******************************************************************************/
/**@class LpdbOptimalSchedule

   @brief Data in the current optimal schedule of the RTP (if exists)
 */
/******************************************************************************/
class LpdbOptimalSchedule : public LpdbSchedule
{

  friend std::ostream & operator<<(std::ostream & os, 
				   const LpdbOptimalSchedule & data);

 public:

  ScheduleType type() const { return ScheduleType::E_OPTIMAL; }
  std::string type_to_string() const { return "OPTIMAL"; }

  explicit LpdbOptimalSchedule (const LpiScheduleRTP & source);
  LpdbOptimalSchedule() = delete;
  LpdbOptimalSchedule(const LpdbOptimalSchedule &) = delete;
  LpdbOptimalSchedule & operator=(const LpdbOptimalSchedule &) = delete;
  

 private:
  
  void print_concrete_data (std::ostream & out) const;


};


#endif /* LPDB_OPTIMAL_SCHEDULE_H_ */
