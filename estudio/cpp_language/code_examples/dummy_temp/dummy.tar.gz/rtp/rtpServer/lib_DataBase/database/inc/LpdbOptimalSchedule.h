/**@file LpdbOptimalSchedule.h
 *
 *
 */

#ifndef LPDB_OPTIMAL_SCHEDULE_H_
#define LPDB_OPTIMAL_SCHEDULE_H_

#include <LpdbSchedule.h>


/**@class LpdbOptimalSchedule

   @brief Data in the current optimal schedule of the RTP (if exists)
 */
class LpdbOptimalSchedule : public LpdbSchedule
{

  friend std::ostream & operator<<(std::ostream & os, 
				   const LpdbOptimalSchedule & data);


};


#endif /* LPDB_OPTIMAL_SCHEDULE_H_ */
