/*
 * LpdbSchedule.cc
 *
 *  Created on: 12/12/2013
 *      Author: mbegega
 */

#include <boost/foreach.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <algorithm>
#include <cmath>
#include <iostream>

#include <LpdbSCHTimedData.h>
#include "LpdbSchedule.h"
#include <LpdbDataBase.h>
#include "LpdbAirportIntervalComparativeKPIs.h"
#include "LpdbPriorityFlightsClassifier.h"


using std::vector;
using namespace boost::posix_time;

LpdbSchedule::LpdbSchedule() : r_frozenPeriod(0), r_origin(LpiActivationType::E_PREFERENTIAL)
{
}


LpdbSchedule::LpdbSchedule(int min_subinterval,
                         int hours_window,
                         int min_frozen,
                         boost::posix_time::ptime begin_timestamp)
:r_timeLine(min_subinterval,
            hours_window,
            min_frozen,
            begin_timestamp),
 r_frozenPeriod(0),
 r_origin(LpiActivationType::E_PREFERENTIAL)
{
}


LpdbSchedule::LpdbSchedule(const LpdbSchedule& source)
:r_timeLine(source.r_timeLine),
 r_absolute_KPIs(source.r_absolute_KPIs),
 r_fps_scheduled(source.r_fps_scheduled),
 r_fps_delayed_last_interval(source.r_fps_delayed_last_interval),
 r_weight_mean(source.r_weight_mean),
 r_delays_splitter(source.r_delays_splitter),
 r_interval_t_minus_one(source.r_interval_t_minus_one),
 r_frozenPeriod(source.r_frozenPeriod),
 r_origin(source.r_origin)
{
}


void LpdbSchedule::init(const LpiTimeParameters & parameters,
                       boost::posix_time::ptime begin_timestamp)
{
   //Creates timeline with no data associated to interval contents
   r_timeLine.initialize(parameters.getMinutesSubinterval(),
                         parameters.getHoursWindow(),
                         parameters.getMinutesFrozen(),
                         begin_timestamp
                         );

   //Populates whole timeline with 0's
   r_timeLine.fill();

   r_fps_scheduled.clear();
   r_fps_delayed_last_interval.clear();

}


void LpdbSchedule::init(int min_subinterval,
                       int hours_window,
                       int min_frozen,
                       boost::posix_time::ptime begin_timestamp)
{
   //Creates timeline with no data associated to interval contents
   r_timeLine.initialize(min_subinterval,
                         hours_window,
                         min_frozen,
                         begin_timestamp
                         );

   //Populates whole timeline with 0's
   r_timeLine.fill();

   r_fps_scheduled.clear();
   r_fps_delayed_last_interval.clear();
}


LpdbSchedule & LpdbSchedule::operator= (const LpdbSchedule & source)
{
   if (this != &source)
   {
      r_timeLine        = source.r_timeLine;
      r_absolute_KPIs   = source.r_absolute_KPIs;
      r_fps_scheduled   = source.r_fps_scheduled;
      r_fps_delayed_last_interval = source.r_fps_delayed_last_interval;
      r_weight_mean     = source.r_weight_mean;
      r_delays_splitter = source.r_delays_splitter;
      r_interval_t_minus_one = source.r_interval_t_minus_one;
      r_frozenPeriod = source.r_frozenPeriod;
      r_origin = source.r_origin;
   }

   return *this;
}


bool LpdbSchedule::has_data(const string& interval_name)
{
   return r_timeLine.hasData(interval_name);
}


LpdbSCHTimedData & LpdbSchedule::operator[] (const string & interval_name)
{
   return r_timeLine[interval_name];
}


void LpdbSchedule::forward()
{
   //Store t0 interval as t-1, for later calculations
   if (r_timeLine.exists("t0") && r_timeLine.hasData("t0"))
   {
      r_interval_t_minus_one = r_timeLine["t0"];
   }

   r_timeLine.forward();
   //Creates default element in newly created interval
   r_timeLine.createElement(r_timeLine.getLastInterval());
}


void LpdbSchedule::setTimeLine (const TimeLine<LpdbSCHTimedData> & source)
{
   r_timeLine= source;
}


TimeLine<LpdbSCHTimedData> & LpdbSchedule::getTimeLine ()
{
   return r_timeLine;
}


const TimeLine<LpdbSCHTimedData> & LpdbSchedule::getTimeLine () const
{
   return r_timeLine;
}


void LpdbSchedule::scheduleRunwaySystem (std::string interval, const LpdbRunwaySystem & rs)
{
   LpdbRSScheduled runway_system(rs);
   LpdbSCHTimedData new_data_interval;
   new_data_interval.setRsScheduled(runway_system);

   if (!r_timeLine.hasData(interval))
   {  //Create new element
      r_timeLine.addElement(interval, new_data_interval);
   }
   else
   {  //Update existing element
      //LpdbSCHTimedData & interval_data = r_timeLine[interval];
      //interval_data= new_data_interval;

      r_timeLine[interval] = new_data_interval;
   }
}


map<string, LpdbFPSchedule>  LpdbSchedule::getScheduleFps() const
{
   return r_fps_scheduled;
}


map<string, LpdbFPSchedule> & LpdbSchedule::getScheduleFps()
{
   return r_fps_scheduled;
}


void LpdbSchedule::setScheduleFps(map<string, LpdbFPSchedule> allocatedFps)
{
   r_fps_scheduled = allocatedFps;
}


map<string, LpdbFPSchedule>  LpdbSchedule::getDelayedFpsInLastInterval() const
{
   return r_fps_delayed_last_interval;
}


map<string, LpdbFPSchedule> & LpdbSchedule::getDelayedFpsInLastInterval()
{
   return r_fps_delayed_last_interval;
}


void LpdbSchedule::setDelayedFpsInLastInterval(map<string, LpdbFPSchedule> delayedFps)
{
   r_fps_delayed_last_interval = delayedFps;
}


/*
void LpdbSchedule::calculateRealDCB ()
{
   vector<string> intervals = r_timeLine.getAllIntervalIds();
   BOOST_FOREACH(string interval, intervals)
   {
      calculateRealDCB(interval);
   }
}
*/


void LpdbSchedule::setIntervalTMinusOne (const LpdbSCHTimedData & interval)
{
   r_interval_t_minus_one = interval;
}


LpdbSCHTimedData LpdbSchedule::getIntervalTMinusOne () const
{
   return r_interval_t_minus_one;
}


void LpdbSchedule::calculateRealDCB (string interval, int minClosedTurnRound, double ratioARR, double ratioDEP)
{
   calculateRealDemand (interval);

   updateTotalAndInheritedDemand(interval);

   calculateNotAllowed (interval);

#ifdef TURN_ROUND
   calculateTurnRounds(interval, minClosedTurnRound);
#endif

   eliminateDelayedFPs(interval);

   sortByPriority(interval);

   calculateRealDelayed(interval, ratioARR, ratioDEP);

   calculateAccepted(interval);
}


void LpdbSchedule::calculateRealDCB (string interval, int minClosedTurnRound, double ratioARR, double ratioDEP,
                                    string previous_interval, double previousRatioARR, double previousRatioDEP,
                                    bool isNewInterval)
{
   calculateRealDemand(interval);

   updateTotalAndInheritedDemand(interval);
   calculateNotAllowed(interval);

#ifdef TURN_ROUND
   calculateTurnRounds(interval, minClosedTurnRound);
#endif

   eliminateDelayedFPs(interval);

   sortByPriority(interval);

   if (isNewInterval)
   {
      //In case of mixed use, we must recalculate real delayed for previous interval,
      //because it must use information of newly created interval
      if (isRSPlannedOfMixedUse(previous_interval))
      {
         calculateRealDelayed(previous_interval, previousRatioARR, previousRatioDEP);
      }
   }

   calculateRealDelayed(interval, ratioARR, ratioDEP);
   calculateAccepted(interval);
}


void LpdbSchedule::calculateRunwayAllocation ()
{
   vector<string> intervals = r_timeLine.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      calculateRunwayAllocation(interval);
   }
}


void  LpdbSchedule::calculateRunwayAllocation (string interval)
{
/*
   //We access to RS' table only for reading, not modifications
   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   if (has_data(interval))
   {
      LpdbRSScheduled & rs_scheduled = r_timeLine[interval].getRsScheduled();
      rs_scheduled.resetAllocation();

      string rs_id = rs_scheduled.getRunwaySystemId();

      if (rsTable.exists(rs_id))
      {
         LpiRunwaySystemUse::LpiEnum rs_use_type = rsTable[rs_id].getUse();

         switch (rs_use_type)
         {
            case LpiRunwaySystemUse::E_ONE_SEGREGATED_EACH_USE:
               calculateRunwayAllocation1ARR_1DEP(interval);

               break;

            case LpiRunwaySystemUse::E_MULTIPLE_SEGREGATED_EACH_USE:
               calculateRunwayAllocationAcceptedXARR_YDEP(interval);
               calculateRunwayAllocationDelayedXARR_YDEP(interval);

               break;

            case LpiRunwaySystemUse::E_MIXED:
               calculateRunwayAllocationAcceptedMixed(interval);
               calculateRunwayAllocationDelayedMixed(interval);

               break;

            case LpiRunwaySystemUse::E_SEGREGATED_AND_MIXED:
               calculateRunwayAllocationAcceptedMixed(interval);
               calculateRunwayAllocationDelayedMixed(interval);

               break;

            default:
               break;
         }
      }
   }
*/
}


void LpdbSchedule::calculateRunwayAllocation1ARR_1DEP(string interval)
{
/*
   //This is a simple case, where accepted and delayed are treated the same way

   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   if (has_data(interval))
   {
      calculateScheduledRunwayCapacities(interval);

      //We will modify internal runways FP allocations

      LpdbRSScheduled & rs_scheduled = r_timeLine[interval].getRsScheduled();
      string rs_id = rs_scheduled.getRunwaySystemId();

      //Get real accepted and delayed FPs for this schedule in actual interval
      LpiADOVector<int> total_real_accepted = r_timeLine[interval].getRealAcceptedFps();
      LpiADOVector<vector<string> > total_real_accepted_fp_ids = r_timeLine[interval].getRealAcceptedFpsFps();

      LpiADOVector<int> total_real_delayed = r_timeLine[interval].getRealDelayedFps();
      LpiADOVector<vector<string> > total_real_delayed_fp_ids = r_timeLine[interval].getRealDelayedFpsFps();

      if (rsTable.exists(rs_id))
      {
         const map<string, LpdbRunwaySystemRunway> & rs_runways = rsTable[rs_id].getRunways();
         typedef const map<string, LpdbRunwaySystemRunway>::value_type rs_rwy_data;

         BOOST_FOREACH (rs_rwy_data & rs_rwy, rs_runways)
         {
            OperationType::Enum rwy_use = rs_rwy.second.getUse();

            string active_rwy_id = rs_rwy.second.getId();

            if (rs_scheduled.exists(active_rwy_id))
            {
               LpdbRwyScheduled & active_runway = rs_scheduled[active_rwy_id];

               int real_accepted = 0;
               int real_delayed = 0;

               vector<string> real_accepted_fp_ids;
               vector<string> real_delayed_fp_ids;

               real_accepted_fp_ids.clear();
               real_delayed_fp_ids.clear();

               switch (rwy_use)
               {
                  case OperationType::E_ARRIVALS:

                     real_accepted = total_real_accepted[E_ARR];
                     real_accepted_fp_ids = total_real_accepted_fp_ids[E_ARR];

                     active_runway.allocateFPs(E_ARR, real_accepted, real_accepted_fp_ids);
                     real_delayed = total_real_delayed[E_ARR];
                     real_delayed_fp_ids = total_real_delayed_fp_ids[E_ARR];

                     active_runway.delayFPs(E_ARR, real_delayed, real_delayed_fp_ids);
                  break;

                  case OperationType::E_DEPARTURES:

                     real_accepted = total_real_accepted[E_DEP];
                     real_accepted_fp_ids = total_real_accepted_fp_ids[E_DEP];

                     active_runway.allocateFPs(E_DEP, real_accepted, real_accepted_fp_ids);
                     real_delayed = total_real_delayed[E_DEP];
                     real_delayed_fp_ids = total_real_delayed_fp_ids[E_DEP];

                     active_runway.delayFPs(E_DEP, real_delayed, real_delayed_fp_ids);
                  break;

                  case OperationType::E_INVALID_RWY_OPERATION_TYPE:
                  case OperationType::E_MIXED:
                  default:
                  break;
               } //switch
            } //if
         } //foreach
      }
   }
*/
}


void LpdbSchedule::calculateRunwayAllocationAcceptedXARR_YDEP(string interval)
{
   if (has_data(interval))
   {
      //ISE#620
      calculateScheduledRunwayCapacities(interval);

      //Get real accepted and delayed FPs for this schedule in actual interval
      LpiADOVector<int> total_real_accepted = r_timeLine[interval].getRealAcceptedFps();
      LpiADOVector<vector<string> > total_real_accepted_fp_ids = r_timeLine[interval].getRealAcceptedFpsFps();

      for (int use_type = E_ARR ; use_type <= E_DEP ; use_type++)
      {
         //int total_real_accepted_by_use = total_real_accepted[use_type];
         vector<string> total_real_accepted_fp_ids_by_use = total_real_accepted_fp_ids[use_type];

         vector<string> accepted_fps;
         bool allocated = false;
         int next_element = total_real_accepted_fp_ids_by_use.size() - 1;
         int last_element = total_real_accepted_fp_ids_by_use.size() - 1;

         accepted_fps = total_real_accepted_fp_ids_by_use;

         if (accepted_fps.size() > 0)
         {
            while (!allocated && (next_element >= 0))
            {
               accepted_fps = total_real_accepted_fp_ids_by_use;

               //We only swap elements only if they aren't allocated on first try
               if (next_element != last_element)
               {
                  std::swap(accepted_fps[next_element], accepted_fps[last_element]);

                  calculateScheduledRunwayCapacities(interval);
                  LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();
                  rs.resetAllocation();
               }

               allocated = allocateFPs(interval, use_type, accepted_fps);
               next_element--;
            }
         }
      }
   }
}


void LpdbSchedule::calculateRunwayAllocationAcceptedMixed(string interval)
{
   //Phase 2
/*
   if (has_data(interval))
   {
      calculateScheduledRunwayCapacities(interval);

      LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();

      //Get real accepted FPs for this schedule in current interval
      LpiADOVector<int> accepted_flights = r_timeLine[interval].getRealAcceptedFps();
      LpiADOVector<vector<string> > accepted_flights_fp_ids = r_timeLine[interval].getRealAcceptedFpsFps();

      vector<string> flight_plan_list = accepted_flights_fp_ids[E_OVA];

      vector<string> runways = rs.getAllRunwaysIds();

      LpiOperationType::LpiEnum fp_type = LpiOperationType::E_NONE;
      int destination_runway = 0;
      string runway;

      LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

      for (unsigned int i = 0; i < flight_plan_list.size(); i++)
      {
         string key = flight_plan_list[i];

         if (fpTable.exists(key))
         {
            LpiFlightPlan & fp = fpTable[key];

         vector<string> preferential_runways = fp.getPreferentialRunwaysNames(rs.getRunwaySystemId());
         vector<string> not_allowed = fp.getNotAllowedRunways();

         bool any_runway = (preferential_runways.size() == 1) && (preferential_runways[0] == "ANY");

         if ((preferential_runways.size() > 0) && (!any_runway))
         {
            runway = rs.selectPreferentialRunway(runways, preferential_runways, fp.getOperationType());
         }

         if ((preferential_runways.size() == 0) || runway.empty())
         {
            //Select current runway use
            string runway_id = runways[destination_runway];

            if (rs.exists(runway_id))
            {
               bool isCompatible = rs.isCompatibleUse(runway_id, fp.getOperationType());

               if ((fp_type == LpiOperationType::E_NONE) || (fp.getOperationType() == fp_type) || !isCompatible)
               {
                  destination_runway = rs.selectNextAllowedRunway(runways,
                                                                  not_allowed,
                                                                  fp.getOperationType(),
                                                                  destination_runway);
                  runway = runways[destination_runway];
               }
            }
         }

         fp_type = fp.getOperationType();

         if (!runway.empty() && rs.exists(runway))
         {
            LpdbRwyScheduled & active_runway = rs[runway];

               active_runway.allocateFlightPlan(fp_type, key);
         }
      }
      }
   }
*/
}


void LpdbSchedule::calculateRunwayAllocationDelayedXARR_YDEP(string interval)
{
   if (has_data(interval))
   {
      //Get real delayed FPs for this schedule in actual interval
      LpiADOVector<int> total_real_delayed = r_timeLine[interval].getRealDelayedFps();
      LpiADOVector<vector<string> > total_real_delayed_fp_ids = r_timeLine[interval].getRealDelayedFpsFps();

      for (int use_type = E_ARR ; use_type <= E_DEP ; use_type++)
      {
         //int total_real_delayed_by_use = total_real_delayed[use_type];
         vector<string> total_real_delayed_fp_ids_by_use = total_real_delayed_fp_ids[use_type];

         delayFPs(interval, use_type, total_real_delayed_fp_ids_by_use);
      }
   }
}


void LpdbSchedule::calculateRunwayAllocationDelayedMixed(string interval)
{
   //Phase 2

  /* 
   if (has_data(interval))
   {
      LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();

      //Get real accepted FPs for this schedule in current interval
      LpiADOVector<int> delayed_flights = r_timeLine[interval].getRealDelayedFps();
      LpiADOVector<vector<string> > delayed_flights_ids = r_timeLine[interval].getRealDelayedFpsFps();

      vector<string> flight_plan_list = delayed_flights_ids[E_OVA];

      vector<string> runways = rs.getAllRunwaysIds();

      LpiOperationType::LpiEnum fp_type = LpiOperationType::E_NONE;
      int destination_runway = 0;

      LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

      for (unsigned int i = 0; i < flight_plan_list.size(); i++)
      {
         string key = flight_plan_list[i];

         if (fpTable.exists(key))
         {
            LpiFlightPlan & fp = fpTable[key];

         string runway_id = runways[destination_runway];

         bool isCompatible = rs.isCompatibleUse(runway_id, fp.getOperationType());

         if ((fp_type == LpiOperationType::E_NONE) || (fp.getOperationType() == fp_type) || !isCompatible)
         {
            //Change destination runway of allocation
            destination_runway = rs.selectNextRunwayByUse(runways,
                                                          fp.getOperationType(),
                                                          destination_runway);
         }

         fp_type = fp.getOperationType();

         string runway = runways[destination_runway];

         if (rs.exists(runway))
         {
            LpdbRwyScheduled & active_runway = rs[runway];
               active_runway.delayFlightPlan(fp_type, key);
         }
      }
   }
   }
*/
}


void LpdbSchedule::calculateScheduledRunwayCapacities(string interval)
{
   if (has_data(interval))
   {
      LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();
      rs.calculateMaximumCapacities(interval);
   }
}


bool LpdbSchedule::allocateFPs (string interval, int flights_type, vector<string> fpKeys)
{
 return false; ///@todo FIXME dummy return
/*
   calculateScheduledRunwayCapacities(interval);

   bool result = false;

   LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();

   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   for (unsigned int i = 0 ; i < fpKeys.size() ; i++)
   {
      string key = fpKeys[i];

      if (fpTable.exists(key))
      {
         LpiFlightPlan & fp = fpTable[key];

      // 1- Get previously assigned runway in optimal schedule
      // (it's stored in FlightPlan data structure)
      string assigned_runway;

      switch (flights_type)
      {
         case E_ARR:
            assigned_runway = fp.getArrivalRunway();
         break;
         case E_DEP:
            assigned_runway = fp.getDepartureRunway();
         break;
      }

      // 2- Get preferential runways: there are many for a given RS
      vector<string> preferential_runways = fp.getPreferentialRunwaysNames(rs.getRunwaySystemId());

      // 3- Get available runways
      vector<string> available_runways = rs.getAvailableRunways(flights_type);

      string preferential_available; //stores preferential runway with capacity > 0

      //If preferential == "ANY", get available runway of max capacity remaining for this use
      if ((preferential_runways.size() == 1) && (preferential_runways[0] == "ANY"))
      {
         preferential_available = rs.getAvailAbleRunwayOfMaxCapacity(flights_type);
      }
      else
      {
         for (unsigned int j = 0 ; j < preferential_runways.size() ; j++)
         {
            vector<string>::iterator it = std::find(available_runways.begin(),
                                                    available_runways.end(),
                                                    preferential_runways[j]);
            if (it !=available_runways.end())
            {
               preferential_available = preferential_runways[j];
               break;
            }
         }
      }

      //Erase not allowed runways from available
      vector<string> not_allowed = fp.getNotAllowedRunways();

      //For special rule: check if there is only available one not allowed runway with capacity = 1
      bool only_one_available_not_allowed = false;

      if (not_allowed.size() > 0)
      {
         if (available_runways.size() == 1)
         {
            vector<string>::iterator it = std::find(not_allowed.begin(),
                                                    not_allowed.end(),
                                                    available_runways[E_ARR]);
            if (it !=available_runways.end())
            {
               string rwy = available_runways[E_ARR];
               LpdbRwyScheduled & active_runway = rs[rwy];

               if (active_runway.getActualCapacity() == 1)
               {
                  only_one_available_not_allowed = true;
                  break;
               }
            }
         }
         else if (available_runways.size() > 1)
         {
            BOOST_FOREACH(string not_allowed_rwy, not_allowed)
            {
               available_runways.erase(remove(available_runways.begin(), available_runways.end(), not_allowed_rwy),
                                       available_runways.end());
            }
         }
      }

      //Rule 1: Assign previous assigned runway (available = actual capacity > 0)
      //Rule 2: Assign preferential runway
      //Rule 3: Assign one available runway
      //Exception: If only available one permitted, capacity = 1 and is last flight, return false

      //Rule 1: Assign previous assigned runway : not used in phase 2        
      // if (!assigned_runway.empty() && rs.isAvailable(assigned_runway, flights_type))
      // {
      //    LpdbRwyScheduled & active_runway = rs[assigned_runway];
      //       active_runway.allocateFlightPlan(flights_type, key);

      //    result = true;
      // }
      // else if

      if (!preferential_available.empty())       //Rule 2: Assign preferential runway
      {
         LpdbRwyScheduled & active_runway = rs[preferential_available];
            active_runway.allocateFlightPlan(flights_type, key);

         result = true;
      }
      else if (!available_runways.empty()) //Rule 3: Assign one available runway
      {
         //Exception: If only available one permitted, capacity = 1 and is last flight, return false
            if ((i == fpKeys.size() - 1) && (only_one_available_not_allowed))
         {
            result = false;
            break;
         }

         string runway = rs.selectRunwayWithMaxAvailableCap(available_runways);

         LpdbRwyScheduled & active_runway = rs[runway];
            active_runway.allocateFlightPlan(flights_type, key);

         result = true;
         }
      }
   }

   return result;
*/
}



void LpdbSchedule::delayFPs(string interval, int flights_type, vector<string> fpKeys)
{

/*
      //LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();
   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   for (unsigned int i = 0 ; i < fpKeys.size() ; i++)
   {
      LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();
      //string callsign = callsigns[i];
      string key = fpKeys[i];

      if (fpTable.exists(key))
      {
         LpiFlightPlan & fp = fpTable[key];

      // 1- Get previously assigned runway in optimal schedule
      // (it's stored in FlightPlan data structure)
      string assigned_runway;

      switch (flights_type)
      {
         case E_ARR:
            assigned_runway = fp.getArrivalRunway();
         break;
         case E_DEP:
            assigned_runway = fp.getDepartureRunway();
         break;
      }

      // 2- Get preferential runways
      vector<string> preferential_runways = fp.getPreferentialRunwaysNames(rs.getRunwaySystemId());

      // 3- Get available runways
      vector<string> all_runways = rs.getAllRunwaysByUse(flights_type);

      string preferential_in_use;

      //If preferential == "ANY", get available runway of max capacity remaining for this use
      if ((preferential_runways.size() == 1) && (preferential_runways[0] == "ANY"))
      {
         preferential_in_use = rs.getAvailAbleRunwayOfMaxCapacity(flights_type);
      }
      else
      {
         for (unsigned int j = 0 ; j < preferential_runways.size() ; j++)
         {
            vector<string>::iterator it = std::find(all_runways.begin(),
                                                 all_runways.end(),
                                                 preferential_runways[j]);
            if (it !=all_runways.end())
            {
               preferential_in_use = preferential_runways[j];
               break;
            }
         }
      }

//      if (!assigned_runway.empty() && rs.exists(assigned_runway) && rs.isSameUse(assigned_runway, flights_type))
//      {
//         LpdbRwyScheduled & runway = rs[assigned_runway];
//         runway.delayFlightPlan(flights_type, key);
//      }
//      else if

      if (!preferential_in_use.empty())
      {
         LpdbRwyScheduled & runway = rs[preferential_in_use];
            runway.delayFlightPlan(flights_type, key);
      }
      else if (!all_runways.empty())
      {
         string runway_id = all_runways[0]; //any of available runways

         LpdbRwyScheduled & runway = rs[runway_id];
            runway.delayFlightPlan(flights_type, key);
      }
    } //end - fpTable.exists(key
   }//end_for
*/
}


void LpdbSchedule::clearStoredFPs()
{
   r_fps_scheduled.clear();
   r_fps_delayed_last_interval.clear();
}


void LpdbSchedule::performFPCalculations(int minTurnRoundTime)
{
   r_fps_scheduled.clear();
   r_fps_delayed_last_interval.clear();

   vector<string> intervals = r_timeLine.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      performFPCalculations(interval, minTurnRoundTime);
   }

#ifdef TURN_ROUND
   //Turn rounds must be marked once all FPs are "scheduled/processed"
   //Because LpdbFPSchedule isn't created until it's accepted or delayed in last interval
   BOOST_FOREACH(string interval, intervals)
   {
      markTurnRoundFlights(interval);
   }
#endif

}


void LpdbSchedule::performFPCalculations(string interval, int minTurnRoundTime)
{
   if (has_data(interval))
   {
     //      TimeInterval time_interval = r_timeLine.getTimeInterval(interval);

      calculateRunwayAssignationAndFPTimes(interval, minTurnRoundTime);

      //If it's last interval, assign last time of interval window as FTOT/FLDT for real delayed FPs
      string last_interval = r_timeLine.getLastInterval();

      if ((interval == last_interval) && has_data(interval))
      {
         calculateFPTimesForDelayedInLastInterval(interval, minTurnRoundTime);
      }
   }
}


void LpdbSchedule::markTurnRoundFlights()
{
   vector<string> intervals = r_timeLine.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      markTurnRoundFlights(interval);
   }
}



void LpdbSchedule::calculateRunwayAssignationAndFPTimes (string interval, int minTurnRoundTime)
{
   if (has_data(interval))
   {
      TimeInterval time_interval = r_timeLine.getTimeInterval(interval);

      LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();

      std::map<std::string, LpdbRwyScheduled> & runways = rs.getRunways();

      typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_data_type;

      BOOST_FOREACH (rwy_data_type & runway, runways)
      {
         LpiADOVector<vector<string> > allocated_fps = runway.second.getAllocatedFpsFps();

         string runway_id = runway.first;
         OperationType::Enum runway_usage = runway.second.getUsage();

         int minutesSubinterval = r_timeLine.getMinutesSubinterval();
         runway.second.calculateSlot(minutesSubinterval);

         runway.second.calculateAvailableFTOTsAndFLDTs(time_interval.begin,
                                                       allocated_fps);
         int fp_types = -1;
         vector<boost::posix_time::ptime> availableFTOT_FLDTs;

         switch (runway_usage)
         {
            case OperationType::E_ARRIVALS:
               fp_types = E_ARR;
               availableFTOT_FLDTs = runway.second.getAvailableFLDTs();
               break;
            case OperationType::E_DEPARTURES:
               fp_types = E_DEP;
               availableFTOT_FLDTs = runway.second.getAvailableFTOTs();
               break;
            case OperationType::E_MIXED:
               fp_types = E_OVA;
               break;
            case OperationType::E_INVALID_RWY_OPERATION_TYPE:
               break;
         }

         if (allocated_fps[fp_types].size() > 0)
         {
            assignFPTimes(allocated_fps[fp_types], availableFTOT_FLDTs, minTurnRoundTime);

            BOOST_FOREACH (string fpKey, allocated_fps[fp_types])
            {
               if (r_fps_scheduled.find(fpKey) != r_fps_scheduled.end())
               {
                  r_fps_scheduled[fpKey].setAssignedRunway(runway_id);
               }
            }
         }
      }
   }
}


void LpdbSchedule::assignFPTimes(const vector<string> & fpKeys,
                                vector<boost::posix_time::ptime> & availableFTOT_FLDTs,
                                int minTurnRoundTime,
                                bool areDelayedFlights)
{
/*
   LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();

   for (unsigned int i = 0; i < fpKeys.size(); i++)
   {
      string key = fpKeys[i];

      if (fpTable.exists(key))
      {
         LpiFlightPlan stored_fp = fpTable[key];

      LpiOperationType::LpiEnum operation_type= stored_fp.getOperationType();

         //IMPORTANT: get EOBT also in arrival FP, in case it's present in its departure times, to send to AOP
         boost::optional<boost::posix_time::ptime> eobt = stored_fp.getDepartureTimes().getEobt();

         LpdbFPSchedule scheduled_fp(key,
                                    stored_fp.getCallsign(),
                                 stored_fp.getDepartureAerodrome(),
                                    stored_fp.getArrivalAerodrome(),
                                    eobt);

      scheduled_fp.setOperationType(operation_type);

      if (operation_type == LpiOperationType::E_ARRIVAL)
      {
            //FLDT
            optional<ptime> nextAssignedTime = extractNextFTOT_FLDT(availableFTOT_FLDTs,
                                                                    stored_fp,
                                                                    r_fps_scheduled,
                                                                    r_fps_delayed_last_interval,
                                                                    minTurnRoundTime);

            if (nextAssignedTime)
            {
               ptime fldt = *nextAssignedTime;

               scheduled_fp.setFldt(fldt);

               //Forecasted delay
               boost::optional<posix_time::ptime> ildt = stored_fp.getIldt();
               double forecasted_delay = 0.0;

               if (ildt && (fldt >= *ildt))
               {
                  forecasted_delay = (fldt - *ildt).total_seconds() / 60;
               }

               if (ildt)
               {
                  scheduled_fp.setIldt(*ildt);
               }
               scheduled_fp.setLdForecastedDelay(forecasted_delay);

               //Punctuality delay
               boost::optional<posix_time::ptime> sldt = stored_fp.getArrivalTimes().getSldt();
               double punctuality_delay = 0.0;

               if (sldt && (fldt >= *sldt))
               {
                  punctuality_delay = (fldt - *sldt).total_seconds() / 60;
               }

               if (sldt)
               {
                  scheduled_fp.setSldt(*sldt);
               }
               scheduled_fp.setLdPunctualityDelay(punctuality_delay);
            }
      }
      else if (operation_type == LpiOperationType::E_DEPARTURE)
      {
            //FTOT
            optional<ptime> nextAssignedTime = extractNextFTOT_FLDT(availableFTOT_FLDTs,
                                                                    stored_fp,
                                                                    r_fps_scheduled,
                                                                    r_fps_delayed_last_interval,
                                                                    minTurnRoundTime);

            if (nextAssignedTime)
            {
               ptime ftot = *nextAssignedTime;
               scheduled_fp.setFtot(ftot);

               //Forecasted delay
               boost::optional<posix_time::ptime> itot = stored_fp.getItot();
               double forecasted_delay = 0.0;

               if (itot && (ftot >= *itot))
               {
                  forecasted_delay = (ftot - *itot).total_seconds() / 60;
               }

               if (itot)
               {
                  scheduled_fp.setItot(*itot);
               }
               scheduled_fp.setToForecastedDelay(forecasted_delay);

               //Punctuality delay
               boost::optional<posix_time::ptime> stot = stored_fp.getDepartureTimes().getStot();
               double punctuality_delay = 0.0;

               if (stot && (ftot >= *stot))
               {
                  punctuality_delay = (ftot - *stot).total_seconds() / 60;
               }

               if (stot)
               {
                  scheduled_fp.setStot(*stot);
               }
               scheduled_fp.setToPunctualityDelay(punctuality_delay);
            }
      }

         if (!key.empty())
      {
         if (!areDelayedFlights)
         {
               r_fps_scheduled[key] = scheduled_fp;
         }
         else
         {
               r_fps_delayed_last_interval[key] = scheduled_fp;
         }
      }
   }
   }
*/
}


boost::optional<boost::posix_time::ptime> LpdbSchedule::extractNextFTOT_FLDT(
                                                       vector<ptime> & availableFTOT_FLDTs,
                                                       const LpiFlightPlan & fp,
                                                       map<string, LpdbFPSchedule> scheduledFPs,
                                                       map<string, LpdbFPSchedule> delayedInLastIntervalFPs,
                                                       int minTurnRoundTime)
{
   optional<ptime> result;

   if (availableFTOT_FLDTs.size() == 0)
   {
      result = boost::none;
   }
   else
   {
      //Special cases:
      //1- FP is DEP TurnRound
      //2- FP has UTOT/ULDT
      vector<ptime>::iterator itr;

      LpiOperationType::LpiEnum fpType = fp.getOperationType();
      optional<ptime> uTime;

      if (fpType == LpiOperationType::E_ARRIVAL)
      {
         uTime = fp.getArrivalTimes().getUldt();
      }
      else if (fpType == LpiOperationType::E_DEPARTURE)
      {
         uTime = fp.getDepartureTimes().getUtot();
      }

#ifdef TURN_ROUND
      if ((fpType == LpiOperationType::E_DEPARTURE) && (fp.getTurnRoundKey() != ""))
      {
         itr = getMinTakeOfTime(fp.getTurnRoundKey(),
                                minTurnRoundTime,
                                availableFTOT_FLDTs,
                                scheduledFPs,
                                delayedInLastIntervalFPs);
      }
      else if (uTime)
#endif
      if (uTime)
      {
         itr = getClosestTimeTo(*uTime, availableFTOT_FLDTs);
      }
      else
      {
         itr = availableFTOT_FLDTs.begin();
      }

      result = *itr;
      availableFTOT_FLDTs.erase(itr);
   }

   return result;
}


vector<ptime>::iterator LpdbSchedule::getClosestTimeTo(const ptime & uTime,
                                                      vector<ptime> & availableTimes)
{
   vector<ptime>::iterator result = availableTimes.end();

   time_duration td(boost::posix_time::pos_infin);

   for (vector<ptime>::iterator itr = availableTimes.begin();
        itr != availableTimes.end();
        ++itr)
   {
      time_duration ellapsed = *itr - uTime;

      if (ellapsed.is_negative()) ellapsed *= -1;

      if (ellapsed < td)
      {
         result = itr;
         td = ellapsed;
      }
   }

   return result;
}


vector<ptime>::iterator LpdbSchedule::getMinTakeOfTime(const string & fpARRKey,
                                                      int minTurnRoundTime,
                                                      vector<ptime> & availableTimes,
                                                      map<string, LpdbFPSchedule> scheduledFPs,
                                                      map<string, LpdbFPSchedule> delayedInLastIntervalFPs)
{
   vector<ptime>::iterator result = availableTimes.end() - 1;

/*
   bool ftotFound = false;

   //Calculate min FTOT
   boost::optional<ptime> fpARRFLDT = boost::none;

   if (scheduledFPs.count(fpARRKey) > 0)
   {
      fpARRFLDT = scheduledFPs[fpARRKey].getFldt();
   }
   else if (delayedInLastIntervalFPs.count(fpARRKey) > 0)
   {
      fpARRFLDT = delayedInLastIntervalFPs[fpARRKey].getFldt();
   }


   if (fpARRFLDT)
   {
      ptime minFTOT = *fpARRFLDT + minutes(minTurnRoundTime);

      for (vector<ptime>::iterator itr = availableTimes.begin();
           itr != availableTimes.end();
           ++itr)
      {
         if (*itr >= minFTOT)
         {
            result = itr;
            ftotFound = true;
            break;
         }
      }

      if (!ftotFound)
      {
         result = availableTimes.end() - 1;
      }
   }
   else
   {
      result = availableTimes.end() - 1;
   }
*/
   return result;
}


void LpdbSchedule::calculateFPTimesForDelayedInLastInterval(string interval, int minTurnRoundTime)
{
   if (has_data(interval))
   {
      TimeInterval time_interval = r_timeLine.getTimeInterval(interval);

      LpdbRSScheduled & rs = r_timeLine[interval].getRsScheduled();

      std::map<std::string, LpdbRwyScheduled> & runways = rs.getRunways();

      typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_data_type;

      //Get slot of runway where FPs are delayed in last interval
      BOOST_FOREACH (rwy_data_type & runway, runways)
      {
         LpiADOVector<vector<string> > delayed_fps = runway.second.getDelayedFpsFps();

         int minutesSubinterval = r_timeLine.getMinutesSubinterval();

         if (runway.second.getSlot() == 0)
         {
            runway.second.calculateSlot(minutesSubinterval);
         }

         runway.second.calculateAvailableFTOTsAndFLDTs(time_interval.end, delayed_fps);

         OperationType::Enum runway_usage = runway.second.getUsage();

         vector<boost::posix_time::ptime> availableFTOT_FLDTs;

         int fpType = -1;

         if (runway_usage == OperationType::E_ARRIVALS)
         {
            fpType = E_ARR;
            availableFTOT_FLDTs = runway.second.getAvailableFLDTs();
         }
         else if (runway_usage == OperationType::E_DEPARTURES)
         {
            fpType = E_DEP;
            availableFTOT_FLDTs = runway.second.getAvailableFTOTs();
         }

         bool areDelayedFlights = true;

         if (fpType != -1)
         {
            assignFPTimes(delayed_fps[fpType], availableFTOT_FLDTs, minTurnRoundTime, areDelayedFlights);
         }
      }
   }
}

/*
void LpdbSchedule::recalculateComparativeKPIs(LpiConfigurationAlertKPIs & alertThresholds)
{
   vector<string> intervals = r_timeLine.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      if (r_timeLine.hasData(interval))
      {
         r_timeLine[interval].resetComparativeKPIs();
         r_timeLine[interval].generateRelativeKPIs(interval, alertThresholds);
      }
   }
}
*/

/*
void LpdbSchedule::generateKPIs(LpiConfigurationAlertKPIs & alertThresholds,
                               int delayCountThreshold,
                               bool isClockForwarding,
                               bool isInitialization)
{
   r_absolute_KPIs.reset();

   updateKPIsIntervals(alertThresholds, delayCountThreshold, isClockForwarding, isInitialization);
   updateMaxAndAverageKPIs(delayCountThreshold);

   generateWarningsAlarms(alertThresholds);
}
*/

/*
void LpdbSchedule::updateKPIsIntervals(LpiConfigurationAlertKPIs & alertThresholds,
                                      int delayCountThreshold,
                                      bool isClockForwarding,
                                      bool isInitialization)
{
   vector<string> intervals = r_timeLine.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      //Accepted and Shortage
      updateTotalRealAccepted(interval);
      updateShortage(interval);
      updateKPIsRunways(interval);

      //Forecasted delay, Max delay and Punctuality
      generateRunwayAndAirportIntervalKPIs(interval, alertThresholds, delayCountThreshold, isClockForwarding, isInitialization);
   }
}
*/


void LpdbSchedule::updateTotalRealAccepted(string interval)
{
  //   TimeInterval time_interval = r_timeLine.getTimeInterval(interval);
   r_absolute_KPIs.updateTotalRealAccepted(r_timeLine[interval].getRealAcceptedFps());
}


void LpdbSchedule::updateShortage(string interval)
{
   if(r_timeLine.hasData(interval))
   {
       LpiADOVector<int> shortage;
       shortage[E_ARR] = r_timeLine[interval].getRealDelayedFps()[E_ARR];
       shortage[E_DEP] = r_timeLine[interval].getRealDelayedFps()[E_DEP];
       shortage[E_OVA] = r_timeLine[interval].getRealDelayedFps()[E_OVA];

       r_timeLine[interval].setShortage(shortage);
       r_absolute_KPIs.updateShortage(shortage);
   }
}


void LpdbSchedule::updateKPIsRunways(string interval)
{
//
//   if(r_timeLine.hasData(interval))
//   {
//       std::map<std::string, LpdbRwyScheduled> runways = r_timeLine[interval].getRsScheduled().getRunways();
//       r_absolute_KPIs.updateKPIsRunways(runways);
//   }
}

/*
void LpdbSchedule::generateRunwayAndAirportIntervalKPIs(string interval,
                                                       LpiConfigurationAlertKPIs & alertThresholds,
                                                       int delayCountThreshold,
                                                       bool isClockForwarding,
                                                       bool isInitialization)
{
  LpdbDemand & demand = LpdbDataBase::Get().getDemand();

   LpiADOVector<int> total_demand;
   if (demand.has_data(interval))
   {
      total_demand = demand[interval].getDemandForecast();
   }

   if(r_timeLine.hasData(interval))
   {
      LpiADOVector<int> real_demand = r_timeLine[interval].getRealDemandFps();

      LpdbRSScheduled & rs_scheduled = r_timeLine[interval].getRsScheduled();

      LpiADOVector<vector<string> > accepted_fps = r_timeLine[interval].getRealAcceptedFpsFps();
      LpiADOVector<vector<string> > delayed_fps = r_timeLine[interval].getRealDelayedFpsFps();

      rs_scheduled.generateRunwayAndAirportIntervalKPIs(interval,
                                                        getScheduleFps(),
                                                        getDelayedFpsInLastInterval(),
                                                        accepted_fps,
                                                        delayed_fps,
                                                        alertThresholds,
                                                        delayCountThreshold);

      //Phase V: Add to Runway Window KPIs
      accumulateRunwayWindowKPIs(rs_scheduled.getRunways());

      //Phase II: Comparative KPIs (Relative and Delta)
      if (!isInitialization)
      {
         string lastInterval = r_timeLine.getLastInterval();
         bool isLastInterval = (interval == lastInterval);

         r_timeLine[interval].generateComparativeKPIs(interval, alertThresholds, isClockForwarding, isLastInterval);
      }
   }
}
*/

void LpdbSchedule::updateMaxAndAverageKPIs(int delayCountThreshold)
{
   //map<string, LpdbFPSchedule>   scheduledFps = this->getScheduleFps();
   //map<string, LpdbFPSchedule>   lastIntervalDelayedFps = this->getDelayedFpsInLastInterval();
//
   //r_absolute_KPIs.updateMaxAndAverageKPIs(delayCountThreshold, scheduledFps, lastIntervalDelayedFps);
//
   //Phase V: Generate Averages and Percentages on Runway Window KPIs
   //r_absolute_KPIs.aggregateRunwayWindowKPIs();
}


void LpdbSchedule::calculateRealDemand (string interval)
{
/* 

   LpdbDemand & demand = LpdbDataBase::Get().getDemand();

   string previous_interval;
   LpiADOVector<int> real_demand;
   LpiADOVector<vector<string> > real_demand_ids;

   if (interval.compare("t0") != 0)
   {
      previous_interval = r_timeLine.getPreviousIntervalId(interval);

      real_demand = r_timeLine[previous_interval].getRealDelayedFps();
      real_demand_ids = r_timeLine[previous_interval].getRealDelayedFpsFps();
   }
   else
   {
      if (LpdbDataBase::Get().hasActiveSchedule())
      {
         LpdbSCHTimedData tMinusOneData = LpdbDataBase::Get().getActiveSchedule().getIntervalTMinusOne();

         real_demand = tMinusOneData.getRealDelayedFps();
         real_demand_ids = tMinusOneData.getRealDelayedFpsFps();


//         LclogStream::instance(LclogConfig::E_RTP).debug() << "Real Demand: Reading t-1 data:\n";
//         LclogStream::instance(LclogConfig::E_RTP).debug() << "Delayed= " << real_demand << ", Ids: [";
//
//         for (unsigned int i = E_ARR; i <= E_OVA; ++i)
//         {
//            LclogStream::instance(LclogConfig::E_RTP).debug() << "(";
//            //std::copy(real_demand_ids[i].begin(), real_demand_ids[i].end(), std::ostream_iterator<std::string>(std::cout, " "));
//            std::copy(real_demand_ids[i].begin(), real_demand_ids[i].end(), std::ostream_iterator<std::string>(LclogStream::instance(LclogConfig::E_RTP).debug(), " "));
//            LclogStream::instance(LclogConfig::E_RTP).debug() << ")";
//            LclogStream::instance(LclogConfig::E_RTP).debug() << "]" << std::endl;
//         }

      }
   }
   //Else LpiADOVectors will be populated with default values (0,0,0) and (,,)

   //Update delayed number of flights
   LpiADOVector<int> demand_forecast = demand[interval].getDemandForecast();

   real_demand = demand_forecast + real_demand;
   r_timeLine[interval].setRealDemandFps(real_demand);

   //Update delayed Flight IDs
   LpiADOVector<vector<string> > demand_forecast_ids = demand[interval].getDemandForecastFps();

   for (int i = E_ARR; i <= E_OVA; i++)
   {
      //Insert real delayed of previous interval at begin
      for (std::vector<string>::reverse_iterator rit = real_demand_ids[i].rbegin(); rit!= real_demand_ids[i].rend(); ++rit)
      {
         string flightPlanKey = *rit;

         vector<string>::iterator it = std::find(demand_forecast_ids[i].begin(), demand_forecast_ids[i].end(), flightPlanKey);

         if (it == demand_forecast_ids[i].end())
         {
            demand_forecast_ids[i].insert(demand_forecast_ids[i].begin(), flightPlanKey);
         }
      }
   }

   r_timeLine[interval].setRealDemandFpsFps(demand_forecast_ids);
*/
}


void LpdbSchedule::updateTotalAndInheritedDemand(string interval)
{
/*
   LpiADOVector<int> realDemand = r_timeLine[interval].getRealDemandFps();

   LpdbDemand & demandForecast = LpdbDataBase::Get().getDemand();

   r_timeLine[interval].setTotalDemand(realDemand);

   if (demandForecast.has_data(interval))
   {
      LpiADOVector<int> forecast = demandForecast[interval].getDemandForecast();

      r_timeLine[interval].setInheritedDemand(realDemand - forecast);
      r_timeLine[interval].setIntentionalDemand(forecast);
   }
*/
}


void LpdbSchedule::calculateNotAllowed (string interval)
{
/*

 LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   OperationType::Enum usages[3] = {OperationType::E_ARRIVALS, OperationType::E_DEPARTURES, OperationType::E_MIXED };

   if (has_data(interval))
   {
      string rs_scheduled = r_timeLine[interval].getRsScheduled().getRunwaySystemId();
      LpiADOVector<vector<string> > flight_plans = r_timeLine[interval].getRealDemandFpsFps();

      LpiADOVector<int> not_allowed;
      LpiADOVector<vector<string> > not_allowed_fp_ids;

      LpdbDataBase::FPTable & flightPlansTable = LpdbDataBase::Get().getFPTable();

      for (int i = E_ARR; i <= E_DEP; i++)
      {
         BOOST_FOREACH(string fpKey, flight_plans[i])
         {
            if (flightPlansTable.exists(fpKey))
            {
               LpiFlightPlan & fp = flightPlansTable[fpKey];

            vector<string> fp_not_allowed_runways = fp.getNotAllowedRunways();

            if (rsTable.exists(rs_scheduled) && (fp_not_allowed_runways.size() > 0))
            {
               LpdbRunwaySystem rs = rsTable[rs_scheduled];
               vector<string> runways_by_use = rs.getRunwaysByUse(usages[i]);

               //With set_difference, we calculate runways of RS that are not included in
               //not allowed with set_difference in two ordered collections
               //if all of RS' runways are contained in not allowed, difference will be 0
               vector<string> difference;

               std::sort(fp_not_allowed_runways.begin(), fp_not_allowed_runways.end());
               std::sort(runways_by_use.begin(), runways_by_use.end());

               std::set_difference(runways_by_use.begin(), runways_by_use.end(),
                                   fp_not_allowed_runways.begin(), fp_not_allowed_runways.end(),
                                   back_inserter(difference));

               if (difference.size() == 0)
               {
                  not_allowed[i] = not_allowed[i] + 1;
                     not_allowed_fp_ids[i].push_back(fpKey);

                  not_allowed[E_OVA] = not_allowed[E_OVA] + 1;
                     not_allowed_fp_ids[E_OVA].push_back(fpKey);
                  }
               }
            }
         }
      }

      r_timeLine[interval].setNotAllowedDelayedFps(not_allowed);
      r_timeLine[interval].setNotAllowedDelayedFpsFps(not_allowed_fp_ids);
   }
*/
}


void LpdbSchedule::calculateNotAllowedWithCapacity (string interval)
{
/*

LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   OperationType::Enum usages[3] = {OperationType::E_ARRIVALS, OperationType::E_DEPARTURES, OperationType::E_MIXED };

   if (has_data(interval))
   {
      string rs_scheduled = r_timeLine[interval].getRsScheduled().getRunwaySystemId();
      LpiADOVector<vector<string> > flight_plans = r_timeLine[interval].getRealDemandFpsFps();

      LpiADOVector<int> not_allowed;
      LpiADOVector<vector<string> > not_allowed_fp_ids;

      //      typedef map<string, int>::value_type available_data_type;

      LpdbDataBase::FPTable & flightPlansTable = LpdbDataBase::Get().getFPTable();

      for (int i = E_ARR; i <= E_DEP; i++)
      {
         if (rsTable.exists(rs_scheduled))
         {
            //map<string, int> available_runways = r_timeLine[interval].getRsScheduled().getAvailableRunwaysAndCapacities (usages[i]);
            LpdbRunwaySystem rs = rsTable[rs_scheduled];

            if (rs.has_data(interval))
            {
               map<string, int> available_runways = rs.getAvailableRunwaysAndCapacities(usages[i], interval);

               BOOST_FOREACH(string fpKey, flight_plans[i])
               {
                  if (flightPlansTable.exists(fpKey))
                  {
                     LpiFlightPlan & fp = flightPlansTable[fpKey];

                  vector<string> fp_not_allowed_runways = fp.getNotAllowedRunways();

                  if (fp_not_allowed_runways.size() > 0)
                  {

                     LpdbRunwaySystem rs = rsTable[rs_scheduled];
                     vector<string> runways_by_use = rs.getRunwaysByUse(usages[i]);

                     //With set_difference, we calculate runways of RS thar are not included in
                     //not allowed with set_difference in two ordered collections
                     //if all of RS' runways are contained in not allowed, difference will be 0
                     vector<string> difference;

                     std::sort(fp_not_allowed_runways.begin(), fp_not_allowed_runways.end());
                     std::sort(runways_by_use.begin(), runways_by_use.end());

                     std::set_difference(runways_by_use.begin(), runways_by_use.end(),
                                         fp_not_allowed_runways.begin(), fp_not_allowed_runways.end(),
                                         back_inserter(difference));

                     if (difference.size() == 0)
                     {
                        not_allowed[i] = not_allowed[i] + 1;
                           not_allowed_fp_ids[i].push_back(fpKey);

                        not_allowed[E_OVA] = not_allowed[E_OVA] + 1;
                           not_allowed_fp_ids[E_OVA].push_back(fpKey);
                     }
                     else if (difference.size() > 0)
                     {
                        //Check capacity in one of allowed runways, and decrement it in case of "accept"
                        //Get first available with capacity > 0
                        bool runway_available = false;
                        string runway_available_id;

                        for (unsigned int j = 0; j < difference.size(); j++)
                        {
                           string runway_id = difference[j];

                           if ((available_runways.count(runway_id) > 0) && (available_runways[runway_id] > 0))
                           {
                              runway_available = true;
                              runway_available_id = runway_id;

                              break;
                           }
                              else
                              {
                           }
                        }

                        if (runway_available)
                        {
                           available_runways[runway_available_id] = available_runways[runway_available_id] - 1;
                        }
                        else
                        {
                           not_allowed[i] = not_allowed[i] + 1;
                              not_allowed_fp_ids[i].push_back(fpKey);

                           not_allowed[E_OVA] = not_allowed[E_OVA] + 1;
                              not_allowed_fp_ids[E_OVA].push_back(fpKey);
                        }
                     }
                  }
                     else
                     {
                     //Check capacity in one of allowed runways, and decrement it in case of "accept"
                     //Get first available with capacity > 0
                     bool runway_available = false;
                     string runway_available_id;

                     typedef map<string, int>::value_type runway_data;

                     BOOST_FOREACH(runway_data & rwy, available_runways)
                    {
                        string runway_id = rwy.first;
                      if ((available_runways.count(runway_id) > 0) && (available_runways[runway_id] > 0))
                      {
                          runway_available = true;
                          runway_available_id = runway_id;

                          break;
                      }
                    }

                     if (runway_available)
                     {
                       available_runways[runway_available_id] = available_runways[runway_available_id] - 1;
                          }
                     }
                  }
            }
          }
         }
      }

      r_timeLine[interval].setNotAllowedDelayedFps(not_allowed);
      r_timeLine[interval].setNotAllowedDelayedFpsFps(not_allowed_fp_ids);
   }
*/
}


void LpdbSchedule::calculateTurnRounds(string interval, int minClosedTurnRound)
{
/* 

   LpdbDataBase::FPTable fpTable = LpdbDataBase::Get().getFPTable();

   LpiADOVector<int> turnRoundDelayed;
   LpiADOVector<vector<string> > turnRoundDelayedIds;

   if (has_data(interval))
   {
      LpiADOVector<vector<string> > flightPlanIds = r_timeLine[interval].getRealDemandFpsFps();

      //Check DEP flights with associated ARR turn-round flight
      //associatedFPKey = key of ARR flight, fpKey = key of later DEP flight
      for (unsigned int i = 0; i < flightPlanIds[E_DEP].size(); ++i)
      {
         string fpKey = flightPlanIds[E_DEP][i];

         if (fpTable.exists(fpKey))
         {
            LpiFlightPlan & fp = fpTable[fpKey];

         string associatedFPKey = fp.getTurnRoundKey();
         if (associatedFPKey != "")
         {
               LclogStream::instance(LclogConfig::E_RTP).debug() << "TURN-ROUND: " << fpKey << " has associated key = " << associatedFPKey << std::endl;
         }

         if ((associatedFPKey != "") && fpTable.exists(associatedFPKey))
         {
            LpiFlightPlan & associatedFp = fpTable[associatedFPKey];

               LclogStream::instance(LclogConfig::E_RTP).debug() << "TURN-ROUND: " << fpKey << " associated FP = " << associatedFp << std::endl;

            string associatedFPPlannedInterval;
               if (!isAlreadyPlanned(interval, E_ARR, associatedFp.getUniqueKey(), associatedFPPlannedInterval))
            {
                  LclogStream::instance(LclogConfig::E_RTP).debug() << "TURN-ROUND: " << associatedFp.getUniqueKey() << " NOT already planned, delay " << std::endl;

               ++turnRoundDelayed[E_DEP];
                  turnRoundDelayedIds[E_DEP].push_back(fpKey); //Add DEP flight
            }
            else
            {
                  LclogStream::instance(LclogConfig::E_RTP).debug() << "TURN-ROUND: " << associatedFp.getUniqueKey() << " already planned checking closed TR " << std::endl;

               if (!isTurnRound(associatedFPPlannedInterval, interval, minClosedTurnRound))
               {
                     LclogStream::instance(LclogConfig::E_RTP).debug() << "TURN-ROUND: " << associatedFp.getUniqueKey() << " isn't TR, delay " << std::endl;

                  ++turnRoundDelayed[E_DEP];
                     turnRoundDelayedIds[E_DEP].push_back(fpKey); //Add DEP flight
                  }
               }
            }
         }
      }

      r_timeLine[interval].setTurnRoundDelayedFps(turnRoundDelayed);
      r_timeLine[interval].setTurnRoundDelayedFpsFps(turnRoundDelayedIds);
   }
*/
}


void LpdbSchedule::eliminateDelayedFPs(string interval)
{
   if (has_data(interval))
   {
      //Eliminate from real demand all not-permitted_delayed

      LpiADOVector<int> real_demand = r_timeLine[interval].getRealDemandFps();
      LpiADOVector<int> not_allowed = r_timeLine[interval].getNotAllowedDelayedFps();

      LpiADOVector<int> difference = real_demand - not_allowed;
      LpiADOVector<int> zero_demand(0, 0, 0);
      LpiADOVector<int> result = max(difference, zero_demand);

      LpiADOVector<vector<string> > real_demand_fp_ids = r_timeLine[interval].getRealDemandFpsFps();
      LpiADOVector<vector<string> > not_allowed_fp_ids = r_timeLine[interval].getNotAllowedDelayedFpsFps();

      for (int i = E_ARR; i <= E_OVA; i++)
      {
         BOOST_FOREACH(string fpKey, not_allowed_fp_ids[i])
         {
            //Erase-remove idiom
            real_demand_fp_ids[i].erase(remove(real_demand_fp_ids[i].begin(),
                                               real_demand_fp_ids[i].end(),
                                               fpKey),
                                        real_demand_fp_ids[i].end());
         }
      }

#ifdef TURN_ROUND
      //Eliminate turn-round delayed FPs from real demand not already erased from not-allowed FPs

      LpiADOVector<int> turn_round = r_timeLine[interval].getTurnRoundDelayedFps();
      LpiADOVector<vector<string> > turn_round_fp_ids = r_timeLine[interval].getTurnRoundDelayedFpsFps();

      vector<string> not_allowed_fp_ids_DEP = not_allowed_fp_ids[E_DEP];
      vector<string> turn_round_fp_ids_DEP = turn_round_fp_ids[E_DEP];

      BOOST_FOREACH(string fpKey, turn_round_fp_ids_DEP)
      {
         vector<string>::iterator itr = std::find(not_allowed_fp_ids_DEP.begin(),
                                                  not_allowed_fp_ids_DEP.end(),
                                                  fpKey);
         if (itr == not_allowed_fp_ids_DEP.end())
         {
            result[E_DEP] = (result[E_DEP] >= 0) ? --result[E_DEP] : 0;

            //Erase-remove idiom
            real_demand_fp_ids[E_DEP].erase(remove(real_demand_fp_ids[E_DEP].begin(),
                                                   real_demand_fp_ids[E_DEP].end(),
                                                   fpKey),
                                            real_demand_fp_ids[E_DEP].end());
         }
      }
#endif

      r_timeLine[interval].setRealDemandFps(result);
      r_timeLine[interval].setRealDemandFpsFps(real_demand_fp_ids);
   }
}


void LpdbSchedule::sortByPriority(string interval)
{
   string previousInterval;
   LpiADOVector<vector<string> > realDelayedIdsPrevious;

   if (interval.compare("t0") != 0)
   {
      previousInterval = r_timeLine.getPreviousIntervalId(interval);

      if (has_data(previousInterval))
      {
         realDelayedIdsPrevious = r_timeLine[previousInterval].getRealDelayedFpsFps();
      }
   }

   if (has_data(interval))
   {
      LpiADOVector<vector<string> > realDemandIds = r_timeLine[interval].getRealDemandFpsFps();

      LpiADOVector<vector<string> > orderedRealDemand;

      //Classify flights y 4 separate categories (maps)
      //Once classified, merge in one vector ordered by category (which map belongs to)

      for (unsigned int i = E_ARR; i <= E_OVA; ++i)
      {
         PriorityMap delayedWithPriority;
         PriorityMap notDelayedWithPriority;
         vector<string> delayedWithoutPriority;
         vector<string> notDelayedWithoutPriority;

         LpdbPriorityFlightsClassifier::ClassifyFlights(realDelayedIdsPrevious[i],
                                                       realDemandIds[i],
                                                       delayedWithPriority,
                                                       delayedWithoutPriority,
                                                       notDelayedWithPriority,
                                                       notDelayedWithoutPriority);

         vector<string> orderedFlights = LpdbPriorityFlightsClassifier::MergeClassifiedByPriority(delayedWithPriority,
                                                                                                 delayedWithoutPriority,
                                                                                                 notDelayedWithPriority,
                                                                                                 notDelayedWithoutPriority);

         orderedRealDemand[i] = orderedFlights;
      }

      r_timeLine[interval].setRealDemandFpsFps(orderedRealDemand);
   }

}



void LpdbSchedule::calculateRealDelayed (string interval, double ratioARR, double ratioDEP)
{
/*

   LpiADOVector<int> real_demand  = r_timeLine[interval].getRealDemandFps();

   LpiADOVector<int> max_capacity;

   //Get maximum capacity of RS scheduled in interval
  LpdbDataBase::RunwaySystemTable & rs_table = LpdbDataBase::Get().getRunwaySystemTable();

   if (has_data(interval))
   {
      string rs_id = r_timeLine[interval].getRsScheduled().getRunwaySystemId();

      if (rs_table.exists(rs_id))
      {
         LpdbRunwaySystem rs = rs_table[rs_id];
         if (rs.has_data(interval))
         {
            max_capacity = rs[interval].getMaxCapacity();

            LpiADOVector<int> rs_rwy_max_capacity = rs[interval].getRwysMaxCapacity();
            r_timeLine[interval].setMaxCapacity(max_capacity);
            r_timeLine[interval].setRwysMaxCapacity(rs_rwy_max_capacity);
         }

         LpiADOVector<int> real_DC_margin = real_demand - max_capacity;

         r_timeLine[interval].setRealDcMargin(real_DC_margin);

         LpiADOVector<int> surplus;

         for (int i = E_ARR; i <= E_OVA; i++)
         {
            int real_dc_margin_component = real_DC_margin[i];
            surplus[i] = std::max(real_dc_margin_component, 0);
         }

         r_timeLine[interval].setSurplus(surplus);

         LpiRunwaySystemUse::LpiEnum rs_use_type = rs.getUse();

         if ((rs_use_type == LpiRunwaySystemUse::E_MIXED) ||
             (rs_use_type == LpiRunwaySystemUse::E_SEGREGATED_AND_MIXED))
         {
            calculateRealDelayedMixed(interval, ratioARR, ratioDEP);
         }
         else
         {
            calculateRealDelayedSegregated(interval);
         }
      }
   }
*/
}


void LpdbSchedule::calculateRealDelayedSegregated (string interval)
{
   LpiADOVector<int> surplus = r_timeLine[interval].getSurplus();

   LpiADOVector<int> delayed = surplus;

   //In segregated runways, consider overall as arrivals + departures
   delayed[E_OVA] = delayed[E_DEP] + delayed[E_ARR];

   //Calculate keys of delayed in interval
   LpiADOVector<vector<string> > real_demand = r_timeLine[interval].getRealDemandFpsFps();

   LpiADOVector<vector<string> > delayed_fps;
   for (int i = E_ARR; i <= E_DEP ; i++)
   {
      int number_of_delayed_fps = delayed[i];
      vector<string> demand = real_demand[i];

      for (int j = 0; j < number_of_delayed_fps; j++)
      {
         int index = demand.size() - 1 - j;

         delayed_fps[i].insert(delayed_fps[i].begin(), demand[index]);
      }
   }

   //Overall must be in this case departures plus arrivals
   for (int i = E_ARR; i <= E_DEP ; i++)
   {
      vector<string> delayed_callsigns = delayed_fps[i];

      std::copy(delayed_fps[i].begin(), delayed_fps[i].end(), std::back_inserter(delayed_fps[E_OVA]));
   }

   r_timeLine[interval].setDelayedFps(delayed);
   r_timeLine[interval].setDelayedFpsFps(delayed_fps);

   storeRealDelayedFPsKeys(interval);

}


void LpdbSchedule::calculateRealDelayedMixed(string interval, double ratioARR, double ratioDEP)
{
/* 

  LpiADOVector<int> surplus = r_timeLine[interval].getSurplus();

   int SOd = std::max(surplus[E_OVA] - surplus[E_ARR] - surplus[E_DEP] , 0);

#ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).debug() << interval << ": Real Delayed Mixed case."
                  << "Surplus: " << surplus << " SOd= " << SOd << std::endl;
#endif

   if (SOd > 0)
   {
      string last_interval = r_timeLine.getLastInterval();

      //      LpiWeightPonderationParameters ponderations = LpdbDataBase::Get().getGlobalParameters().getWeightPonderations();

      if (interval != last_interval)
      {
         boost::optional<string> next_interval = r_timeLine.getNextIntervalId(interval);

         if (next_interval)
         {
            if (has_data(interval))
            {
               string rs_id = r_timeLine[interval].getRsScheduled().getRunwaySystemId();

               LpdbDataBase::RunwaySystemTable & rs_table = LpdbDataBase::Get().getRunwaySystemTable();

               if (rs_table.exists(rs_id))
               {
                  LpdbRunwaySystem rs = rs_table[rs_id];

                  if (rs.has_data(interval))
                  {
                     LpiADOVector<int> margin = rs[*next_interval].getEstimatedDcMargin();

                     r_delays_splitter.setSurplus(surplus);
                     r_delays_splitter.setEstimatedDCMargin(margin);

                     r_delays_splitter.calculateDelayOptions();

                     r_delays_splitter.calculateAcceptedDelayed();
                     r_delays_splitter.calculateNonAcceptedDelayed();
                     r_delays_splitter.selectBestOption(ratioARR, ratioDEP);

#ifdef TRACE_OUT
                     LclogStream::instance(LclogConfig::E_RTP).debug() << r_delays_splitter.getOptionsAsString() << std::endl;
#endif
                  }
               }
            }
         }
      }
      else
      {
         r_delays_splitter.setSurplus(surplus);

         r_delays_splitter.calculateDelayOptions();
         r_delays_splitter.calculateAcceptedDelayed();
         r_delays_splitter.calculateNonAcceptedDelayed();
         r_delays_splitter.selectBestOptionLastInterval(ratioARR, ratioDEP);
      }

      LpiADOVector<int> delayed = r_delays_splitter.getRealDelayedBestOption();

      //Calculate callsigns of delayed in interval
      LpiADOVector<vector<string> > real_demand = r_timeLine[interval].getRealDemandFpsFps();

      LpiADOVector<vector<string> > delayed_fps;

      for (int i = E_ARR; i <= E_DEP; i++)
      {
         int number_of_delayed_fps = delayed[i];
         vector<string> demand = real_demand[i];

         for (int j = 0; j < number_of_delayed_fps; j++)
         {
            int index = demand.size() - 1 - j;

            delayed_fps[i].insert(delayed_fps[i].begin(), demand[index]);
         }
      }

      //Overall must be in this case departures plus arrivals
      for (int i = E_ARR; i <= E_DEP ; i++)
      {
         vector<string> delayed_callsigns = delayed_fps[i];

         std::copy(delayed_fps[i].begin(), delayed_fps[i].end(), std::back_inserter(delayed_fps[E_OVA]));
      }

      r_timeLine[interval].setDelayedFps(delayed);
      r_timeLine[interval].setDelayedFpsFps(delayed_fps);

      storeRealDelayedFPsKeys(interval);
   }
   else
   {
      //In case there isn't distributed surplus, it's the same case as segregated runways
      calculateRealDelayedSegregated(interval);
   }
*/
}


void LpdbSchedule::storeRealDelayedFPsKeys (string interval)
{
   //Calculate number of real delayed FPs
    LpiADOVector<int> delayed = r_timeLine[interval].getDelayedFps();
    LpiADOVector<vector<string> > delayed_fps = r_timeLine[interval].getDelayedFpsFps();

    LpiADOVector<int> not_allowed = r_timeLine[interval].getNotAllowedDelayedFps();
    LpiADOVector<vector<string> > not_allowed_fps = r_timeLine[interval].getNotAllowedDelayedFpsFps();

#ifdef TURN_ROUND
    LpiADOVector<int> turn_round = r_timeLine[interval].getTurnRoundDelayedFps();
    LpiADOVector<vector<string> > turn_round_fps = r_timeLine[interval].getTurnRoundDelayedFpsFps();
#endif

    //Once number of delayed flights is obtained (N), get last N from real demand and assign
    //to real delayed
    //Real delayed are: delayed by not allowed + delayed by turn round + last N delayed

    //1-Not-allowed treatment
    LpiADOVector<vector<string> > real_delayed_fps = not_allowed_fps;

    LpiADOVector<int> delayed_turn_round_to_include;


    for (unsigned int i = E_ARR; i <= E_OVA ; i++)
    {

#ifdef TURN_ROUND
       //2-Turn-round treatment
       vector<string> delayed_turn_round_to_include_ids;
       vector<string> turnRoundIds = turn_round_fps[i];

       for (unsigned int j = 0; j < turnRoundIds.size(); ++j)
       {
          vector<string>::iterator itr = std::find(not_allowed_fps[i].begin(), not_allowed_fps[i].end(), turnRoundIds[j]);

          if (itr == not_allowed_fps[i].end())
          {
             delayed_turn_round_to_include[i]++;
             delayed_turn_round_to_include_ids.push_back(turnRoundIds[j]);
          }
       }

       if (delayed_turn_round_to_include_ids.size() > 0)
       {
          std::copy(delayed_turn_round_to_include_ids.begin(),
                    delayed_turn_round_to_include_ids.end(),
                    std::back_inserter(real_delayed_fps[i]));
       }
#endif

       //3-Delayed treatment
       vector<string> delayed_keys = delayed_fps[i];

       std::copy(delayed_keys.begin(), delayed_keys.end(), std::back_inserter(real_delayed_fps[i]));
    }

    LpiADOVector<int> real_delayed = not_allowed + delayed_turn_round_to_include + delayed;

    r_timeLine[interval].setRealDelayedFps(real_delayed);
    r_timeLine[interval].setRealDelayedFpsFps(real_delayed_fps);
}


void LpdbSchedule::calculateAccepted (string interval)
{
   LpiADOVector<vector<string> > real_demand_fps = r_timeLine[interval].getRealDemandFpsFps();

   LpiADOVector<vector<string> > not_allowed_fps = r_timeLine[interval].getNotAllowedDelayedFpsFps();

   LpiADOVector<vector<string> > turn_round_fps  = r_timeLine[interval].getTurnRoundDelayedFpsFps();

   LpiADOVector<vector<string> > real_delayed_fps= r_timeLine[interval].getRealDelayedFpsFps();

   LpiADOVector<int> accepted;
   LpiADOVector<vector<string> > accepted_fps;

   for (int i = E_ARR; i <= E_OVA; i++)
   {
      //1-Real demand
      vector<string> realDemandIds = real_demand_fps[i];
      if (realDemandIds.size() > 0)
      {
         std::copy(realDemandIds.begin(),
                   realDemandIds.end(),
                   std::back_inserter(accepted_fps[i]));
      }

      //2-Not-allowed
      vector<string> notAllowedIds = not_allowed_fps[i];
      if (notAllowedIds.size() > 0)
      {
         std::copy(notAllowedIds.begin(),
                   notAllowedIds.end(),
                   std::back_inserter(accepted_fps[i]));
      }

#ifdef TURN_ROUND
      //3-Turn-round treatment
      vector<string> turnRoundIds = turn_round_fps[i];

      for (unsigned int j = 0; j < turnRoundIds.size(); ++j)
      {
         vector<string>::iterator itr = std::find(not_allowed_fps[i].begin(), not_allowed_fps[i].end(), turnRoundIds[j]);

         if (itr == not_allowed_fps[i].end())
         {
            accepted_fps[i].push_back(turnRoundIds[j]);
         }
      }
#endif

      BOOST_FOREACH(string fpKey, real_delayed_fps[i])
      {
         //Erase-remove idiom
         accepted_fps[i].erase(remove(accepted_fps[i].begin(), accepted_fps[i].end(), fpKey), accepted_fps[i].end());
      }

      accepted[i] = accepted_fps[i].size();
   }

   r_timeLine[interval].setRealAcceptedFps(accepted);
   r_timeLine[interval].setRealAcceptedFpsFps(accepted_fps);
}

//void LpdbSchedule::generateWarningsAlarms(LpiConfigurationAlertKPIs & alertKPIs)
//{
//   r_absolute_KPIs.generateWarningsAlarms(r_absolute_KPIs, alertKPIs);
//}


bool LpdbSchedule::isRSPlannedOfMixedUse(string interval)
{
 return false; ///@todo FIXME dummy return value

/*
   bool isMixedUse = false;

   if (has_data(interval))
   {
      LpdbRSScheduled & rs_scheduled = r_timeLine[interval].getRsScheduled();

      string rs_id = rs_scheduled.getRunwaySystemId();

    LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

      if (rsTable.exists(rs_id))
      {
         LpiRunwaySystemUse::LpiEnum rs_use_type = rsTable[rs_id].getUse();

         if ((rs_use_type == LpiRunwaySystemUse::E_MIXED) ||
             (rs_use_type == LpiRunwaySystemUse::E_SEGREGATED_AND_MIXED))
         {
            isMixedUse = true;
         }
      }
   }

   return isMixedUse;
*/
}


void LpdbSchedule::reviewPastScheduledFPs()
{
   LpdbRSScheduled & pastScheduledRS = r_interval_t_minus_one.getRsScheduled();

   //Get all allocated fps in all runways, erase them from r_fps_scheduled
   std::map<std::string, LpdbRwyScheduled> runways = pastScheduledRS.getRunways();

   typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_data_type;

   BOOST_FOREACH (rwy_data_type & runway, runways)
   {
      LpiADOVector<vector<string> > allocated_fps = runway.second.getAllocatedFpsFps();

      vector<string> keysToReview = allocated_fps[E_OVA];

      //Review all FPs
      for (unsigned int i = 0; i < keysToReview.size(); i++)
      {
         r_fps_scheduled.erase(r_fps_scheduled.find(keysToReview[i]));
      }
   }
}


void LpdbSchedule::eraseDelayedFPsInLastInterval()
{
   r_fps_delayed_last_interval.clear();
}

/*
TimeLine<LpdbSCHTimedData> LpdbSchedule::compareTo(LpdbSchedule & anotherSchedule, LpiConfigurationAlertKPIs & alertThresholds)
{
   //We don't want to modify object's timeline, since it's only a one time comparison
   TimeLine<LpdbSCHTimedData> result = r_timeLine;

   vector<string> intervals = result.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      if(result.hasData(interval) && anotherSchedule.has_data(interval))
      {
         result[interval].generateRelativeKPIs(anotherSchedule[interval], alertThresholds);
      }
   }

   return result;
}
*/


bool LpdbSchedule::isPlannedFP(const string & fpKey)
{
   if ((r_fps_scheduled.find(fpKey) == r_fps_scheduled.end()) &&
       (r_fps_delayed_last_interval.find(fpKey) == r_fps_delayed_last_interval.end()))
   {
      return false;
   }
   else
   {
      return true;
   }
}


boost::optional<posix_time::ptime> LpdbSchedule::getAssignedTime(const string & fpKey)
{
   boost::optional<posix_time::ptime> assignedTime = boost::none;

   if (r_fps_scheduled.find(fpKey) != r_fps_scheduled.end())
   {
      assignedTime = r_fps_scheduled[fpKey].getAssignedTime();
   }
   else if (r_fps_delayed_last_interval.find(fpKey) != r_fps_delayed_last_interval.end())
   {
      assignedTime = r_fps_delayed_last_interval[fpKey].getAssignedTime();
   }

   return assignedTime;
}


std::string LpdbSchedule::getIntervalAbsoluteKpisAsString()
{
   std::stringstream kpisStream;

   vector<std::string> intervals = r_timeLine.getAllIntervalIds();
   BOOST_FOREACH (std::string interval_id, intervals)
   {
      if (r_timeLine.hasData(interval_id))
      {
         TimeInterval time_interval = r_timeLine.getTimeInterval(interval_id);
         kpisStream << interval_id << ": [" << LctimTimeUtils::formatTime(time_interval.begin) << ", "
                                            << LctimTimeUtils::formatTime(time_interval.end) << "]: ";

         kpisStream << r_timeLine[interval_id].getAbsoluteKpisAsString() << '\n';
      }
   }

   return kpisStream.str();
}


std::string LpdbSchedule::toShortString()
{
   std::stringstream scheduleStream;

   vector<std::string> intervals = r_timeLine.getAllIntervalIds();
   BOOST_FOREACH (std::string interval_id, intervals)
   {
      if (r_timeLine.hasData(interval_id))
      {
         std::string rsId = r_timeLine[interval_id].getRsScheduled().getRunwaySystemId();
         scheduleStream << '[' << interval_id << '-' << rsId << ']';
      }
   }

   return scheduleStream.str();
}


bool LpdbSchedule::isAlreadyPlanned(string currentInterval,
                                   int fpType,
                                   string associatedFPKey,
                                   string & associatedFPPlannedInterval)
{
   bool isPlanned = false;

   vector<string> intervals = r_timeLine.getAllIntervalIds();

   unsigned int currentIntervalNumber = r_timeLine.extractIntervalNumber(currentInterval);

   for (unsigned int i = 0; i <= currentIntervalNumber; ++i)
   {
      string interval = intervals[i];

      LpiADOVector<vector<string> > realAcceptedInInterval = r_timeLine[interval].getRealAcceptedFpsFps();

      vector<string>::iterator accepted = std::find(realAcceptedInInterval[fpType].begin(),
                                                    realAcceptedInInterval[fpType].end(),
                                                    associatedFPKey);

      if (accepted != realAcceptedInInterval[fpType].end())
      {
         isPlanned = true;
         associatedFPPlannedInterval = interval;
         break;
      }
   }

   return isPlanned;
}


bool LpdbSchedule::isTurnRound(string associatedFPPlannedInterval, string interval, int minClosedTurnRound)
{

//   if ((associatedFPPlannedInterval == "") || (interval == ""))
//   {
//      return false;
//   }
//   else
// {
      TimeInterval tMaxArrInterval = r_timeLine.getTimeInterval(associatedFPPlannedInterval);
      TimeInterval tMaxDepInterval = r_timeLine.getTimeInterval(interval);

      int minutesEllapsed = (tMaxDepInterval.end - tMaxArrInterval.end).total_seconds() / 60;

      if (minutesEllapsed < minClosedTurnRound)
      {
         return false;
      }
      else
      {
         return true;
      }
   //}
}


void LpdbSchedule::markTurnRoundFlights(string interval)
{
   if (has_data(interval))
   {
      LpiADOVector<vector<string> > turn_round_delayed = r_timeLine[interval].getTurnRoundDelayedFpsFps();

      BOOST_FOREACH(const string & key, turn_round_delayed[E_DEP])
      {
         if (r_fps_scheduled.find(key) != r_fps_scheduled.end())
         {
            LpdbFPSchedule & delayedFP = r_fps_scheduled[key];
            delayedFP.setTurnRoundDelayed(true);
         }
         else if (r_fps_delayed_last_interval.find(key) != r_fps_delayed_last_interval.end())
         {
            LpdbFPSchedule & delayedFP = r_fps_delayed_last_interval[key];
            delayedFP.setTurnRoundDelayed(true);
         }
      }
   }
}


std::string LpdbSchedule::getAvailableFTOTAndFLDTsAsString()
{
   std::stringstream output;

   vector<string> intervals = r_timeLine.getAllIntervalIds();

   BOOST_FOREACH(string interval, intervals)
   {
      if (has_data(interval))
      {
         TimeInterval timeInterval = r_timeLine.getTimeInterval(interval);

         LpdbRSScheduled rs = r_timeLine[interval].getRsScheduled();

         std::map<std::string, LpdbRwyScheduled> runways = rs.getRunways();

         typedef std::map<std::string, LpdbRwyScheduled>::value_type rwy_data_type;

         BOOST_FOREACH (rwy_data_type & runway, runways)
         {
            string runway_id = runway.first;

            output << interval << " [" << LctimTimeUtils::formatTime(timeInterval.begin)
                   << '-' << LctimTimeUtils::formatTime(timeInterval.end) << "]:\n\t"
                   << runway.second.getAvailableFTOTAndFLDTsAsString() << "\n";
         }
      }
   }

   return output.str();
}

/*
void LpdbSchedule::accumulateRunwayWindowKPIs(const map<string, LpdbRwyScheduled> & runways)
{
   typedef map<string, LpdbRwyScheduled>::const_iterator runway_iterator;

   for (runway_iterator it = runways.begin(); it != runways.end() ; ++it)
   {
      string runwayName = (*it).first;
      OperationType::Enum runwayUsage= (*it).second.getUsage();

      LpdbRunwayIntervalKPIs intervalKPIs = (*it).second.getRunwayIntervalKPIs();

      r_absolute_KPIs.accumulateRunwayWindowKPIs(runwayName, runwayUsage, intervalKPIs);
   }
}
*/


std::ostream& operator<<(std::ostream &os, const LpdbSchedule &info)
{
   if (LpdbDataBase::Get().hasActiveSchedule())
   {
      LpdbDataBase::FPTable fpTable = LpdbDataBase::Get().getFPTable();

      LpdbSCHTimedData tMinusOneData = LpdbDataBase::Get().getActiveSchedule().getIntervalTMinusOne();

      LpiADOVector<int> real_demand = tMinusOneData.getRealDelayedFps();
      LpiADOVector<vector<string> >real_demand_ids = tMinusOneData.getRealDelayedFpsFps();

      os << "REAL_DEMAND: t-1 data:" << "DLY[t-1] = " << real_demand << ", DLY_IDS[t-1]= [";

      for (unsigned int i = E_ARR; i <= E_OVA; ++i)
      {
         os << "(";
         vector<string> fpKeys = real_demand_ids[i];

         for (unsigned j = 0; j < fpKeys.size(); ++j)
         {
            string key = fpKeys[j];

            if (fpTable.exists(key))
            {
               LpiFlightPlan & fp = fpTable[key];

               os << fp.getCallsign();

               if (j != fpKeys.size() - 1)
               {
                  os << ", ";
               }
            }
         }
         os << ")";
      }

      os << "]" << "\n";
   }

   os << info.getTimeLine();

   return os;
}
