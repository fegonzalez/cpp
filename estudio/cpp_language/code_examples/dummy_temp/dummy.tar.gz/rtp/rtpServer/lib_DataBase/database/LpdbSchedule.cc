/**@file LpdbSchedule.cc
 *
 @warning class LpdbScheduleConverter:

                Description: Utility class with static methods to
		perform schedule conversion * from internal database
		type to interface layer type
 */


#include <LpdbSchedule.h>

// #include <LpdbDataBase.h>
// #include <LpdbSCHTimedData.h>
// #include <LpdbAirportIntervalComparativeKPIs.h>
// #include <LpdbPriorityFlightsClassifier.h>

// #include <boost/foreach.hpp>
// #include <boost/algorithm/string.hpp>
// #include <boost/optional/optional.hpp>
// #include <boost/date_time/posix_time/posix_time.hpp>

// #include <algorithm>
// #include <cmath>
#include <iostream>

// using namespace boost::posix_time;

// LpdbSchedule::LpdbSchedule() : r_frozenPeriod(0), r_origin(LpiActivationType::E_PREFERENTIAL)
// {
// }


// LpdbSchedule::LpdbSchedule(int min_subinterval,
//                          int hours_window,
//                          int min_frozen,
//                          boost::posix_time::ptime begin_timestamp)
// :r_timeLine(min_subinterval,
//             hours_window,
//             min_frozen,
//             begin_timestamp),
//  r_frozenPeriod(0),
//  r_origin(LpiActivationType::E_PREFERENTIAL)
// {
// }



// void LpdbSchedule::init(const LpiTimeParameters & parameters,
//                        boost::posix_time::ptime begin_timestamp)
// {
//    //Creates timeline with no data associated to interval contents
//    r_timeLine.initialize(parameters.getMinutesSubinterval(),
//                          parameters.getHoursWindow(),
//                          parameters.getMinutesFrozen(),
//                          begin_timestamp
//                          );

//    //Populates whole timeline with 0's
//    r_timeLine.fill();

//    r_fps_scheduled.clear();
//    r_fps_delayed_last_interval.clear();

// }


// void LpdbSchedule::init(int min_subinterval,
//                        int hours_window,
//                        int min_frozen,
//                        boost::posix_time::ptime begin_timestamp)
// {
//    //Creates timeline with no data associated to interval contents
//    r_timeLine.initialize(min_subinterval,
//                          hours_window,
//                          min_frozen,
//                          begin_timestamp
//                          );

//    //Populates whole timeline with 0's
//    r_timeLine.fill();

//    r_fps_scheduled.clear();
//    r_fps_delayed_last_interval.clear();
// }



// bool LpdbSchedule::has_data(const string& interval_name)
// {
//    return r_timeLine.hasData(interval_name);
// }


// LpdbSCHTimedData & LpdbSchedule::operator[] (const string & interval_name)
// {
//    return r_timeLine[interval_name];
// }


///@todo FIXME
void LpdbSchedule::forward()
{
   // //Store t0 interval as t-1, for later calculations
   // if (r_timeLine.exists("t0") && r_timeLine.hasData("t0"))
   // {
   //    r_interval_t_minus_one = r_timeLine["t0"];
   // }

   // r_timeLine.forward();
   // //Creates default element in newly created interval
   // r_timeLine.createElement(r_timeLine.getLastInterval());
}


// void LpdbSchedule::setTimeLine (const TimeLine<LpdbSCHTimedData> & source)
// {
//    r_timeLine= source;
// }


// TimeLine<LpdbSCHTimedData> & LpdbSchedule::getTimeLine ()
// {
//    return r_timeLine;
// }


// const TimeLine<LpdbSCHTimedData> & LpdbSchedule::getTimeLine () const
// {
//    return r_timeLine;
// }

//          }
//       }
//    }
// }



std::ostream& operator<<(std::ostream &os, const LpdbSchedule &data)
{

  return os;
}
