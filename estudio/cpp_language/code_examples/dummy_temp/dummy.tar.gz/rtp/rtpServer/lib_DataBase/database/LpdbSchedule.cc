/**@file LpdbSchedule.cc
 *
 @warning class LpdbScheduleConverter:

                Description: Utility class with static methods to
		perform schedule conversion * from internal database
		type to interface layer type
 */


#include <LpdbSchedule.h>
#include <LpiScheduleRTP.h>
#include <LclogStream.h>
// #include <LpdbDataBase.h>
// #include <LpdbSCHTimedData.h>

#include <iostream>
#include <algorithm>    // std::for_each
//#include <functional>   // bind
// #include <cmath>

#include <boost/date_time/posix_time/posix_time.hpp>
// using namespace boost::posix_time;


//==============================================================================

LpdbSchedule::LpdbSchedule (const LpiScheduleRTP & source)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "Schedule logic"
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


  the_modules.clear();
  const MRTMList &source_list = source.getMrtmsList();
  std::for_each(std::begin(source_list),
		std::end(source_list),
		[this] (const MRTM & new_element)
		{ the_modules.push_back(LpdbScheduleModule(new_element)); });
}

//==============================================================================

/**@fn void LpdbSchedule::forward()
   @todo FIXME
*/
void LpdbSchedule::forward()
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).info()
    << "@todo Schedule logic; forward TODO."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


   // //Store t0 interval as t-1, for later calculations
   // if (r_timeLine.exists("t0") && r_timeLine.hasData("t0"))
   // {
   //    r_interval_t_minus_one = r_timeLine["t0"];
   // }

   // r_timeLine.forward();
   // //Creates default element in newly created interval
   // r_timeLine.createElement(r_timeLine.getLastInterval());
}


// LpdbSchedule::LpdbSchedule() : r_frozenPeriod(0), r_origin(LpiActivationType::E_PREFERENTIAL)
// {
// }


// LpdbSchedule::LpdbSchedule(int min_subinterval,
//                          int hours_window,
//                          int min_frozen,
//                          boost::posix_time::ptime begin_timestamp)
// :r_timeLine(min_subinterval,
//             hours_window,
//             min_frozen,
//             begin_timestamp),
//  r_frozenPeriod(0),
//  r_origin(LpiActivationType::E_PREFERENTIAL)
// {
// }



// void LpdbSchedule::init(const LpiTimeParameters & parameters,
//                        boost::posix_time::ptime begin_timestamp)
// {
//    //Creates timeline with no data associated to interval contents
//    r_timeLine.initialize(parameters.getMinutesSubinterval(),
//                          parameters.getHoursWindow(),
//                          parameters.getMinutesFrozen(),
//                          begin_timestamp
//                          );

//    //Populates whole timeline with 0's
//    r_timeLine.fill();

//    r_fps_scheduled.clear();
//    r_fps_delayed_last_interval.clear();

// }


// void LpdbSchedule::init(int min_subinterval,
//                        int hours_window,
//                        int min_frozen,
//                        boost::posix_time::ptime begin_timestamp)
// {
//    //Creates timeline with no data associated to interval contents
//    r_timeLine.initialize(min_subinterval,
//                          hours_window,
//                          min_frozen,
//                          begin_timestamp
//                          );

//    //Populates whole timeline with 0's
//    r_timeLine.fill();

//    r_fps_scheduled.clear();
//    r_fps_delayed_last_interval.clear();
// }



// bool LpdbSchedule::has_data(const string& interval_name)
// {
//    return r_timeLine.hasData(interval_name);
// }


// LpdbSCHTimedData & LpdbSchedule::operator[] (const string & interval_name)
// {
//    return r_timeLine[interval_name];
// }



// void LpdbSchedule::setTimeLine (const TimeLine<LpdbSCHTimedData> & source)
// {
//    r_timeLine= source;
// }


// TimeLine<LpdbSCHTimedData> & LpdbSchedule::getTimeLine ()
// {
//    return r_timeLine;
// }


// const TimeLine<LpdbSCHTimedData> & LpdbSchedule::getTimeLine () const
// {
//    return r_timeLine;
// }

//          }
//       }
//    }
// }


//==============================================================================

void LpdbSchedule::print (std::ostream & out) const
{
  print_generic_data(out);
  print_concrete_data(out);
}

///@todo Complete with all attributes
void LpdbSchedule::print_generic_data (std::ostream & out) const
{
  out << '(' << type_to_string()  << '-' << "schedule" << ')';

  out << " Modules: ";
  std::for_each(std::begin(the_modules),
		std::end(the_modules),
		[this, &out] (const LpdbScheduleModule & module)
		{ 
		  out << module << " ; " ;
		});

   // out << "TimeLine base time: " << std::endl;
   // out << r_timelineBase << std::endl;
}

