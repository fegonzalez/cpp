/*
 * LpdbDCBAirportTimedData.h
 *
 *  Created on: 09/05/2015
 *      Author: mbegega
 *
 *  Description:
 *      Data used in Estimated DCB for schedules generation algorithm improvements in Phase III
 */


#ifndef LPBDCBAIRPORTTIMEDDATA_H_
#define LPBDCBAIRPORTTIMEDDATA_H_

#include <iostream>
#include "LpiADOVector.h"

class LpdbDCBAirportTimedData
{
   public:
      LpdbDCBAirportTimedData();
      LpdbDCBAirportTimedData(const LpdbDCBAirportTimedData & source);

      virtual ~LpdbDCBAirportTimedData();
      LpdbDCBAirportTimedData & operator =(const LpdbDCBAirportTimedData & source);


      LpiADOVector<int> getMaxAirportCapacity() const;
      void setMaxAirportCapacity(LpiADOVector<int> capacity);

      LpiADOVector<int> getMinDelayedFPs() const;
      void setMinDelayedFPs(LpiADOVector<int> minimumDelayedFPs);

      int getPriorityOperation() const;
      void setPriorityOperation(int operation);

   protected:

       LpiADOVector<int> r_maxAirportCapacity;
       LpiADOVector<int> r_minDelayedFPs;
       int r_priorityOperation;
};

std::ostream & operator<<(std::ostream & os, const LpdbDCBAirportTimedData & info);


#endif /* LPBDCBAIRPORTTIMEDDATA_H_ */
