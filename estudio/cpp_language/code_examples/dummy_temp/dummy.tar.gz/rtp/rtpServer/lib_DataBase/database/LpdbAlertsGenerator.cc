/*
 * LpdbAlertsGenerator.cc
 *
 *  Created on: 24/10/2014
 *      Author: mbegega
 */

#include "LpdbAlertsGenerator.h"

//#include "LpdbDataBase.h"
//
//Warnings_alerts LpdbAlertsGenerator::generateAlerts(int intervalsPerHour,
//                                                   LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                   string comparisonOperation,
//                                                   LpiADOVector<double> kpi)
//{
//   Warnings_alerts result(Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT);
//
//  /* bool empty_demand = LpdbDataBase::Get().getDemand().isEmpty();
//
//   if (empty_demand)
//   {
//      return result;
//   }
//
//   for (int i = E_ARR; i <= E_OVA; i++)
//   {
//      if (kpi[i] >= 0)
//      {
//         if (comparisonOperation == "less")
//         {
//            if ((kpi[i] < (alarmThreshold[i] / intervalsPerHour)) && (kpi[i] > 0.0))
//            {
//               result[i] = Warnings_alerts::E_ALARM;
//            }
//            else if ((kpi[i] < (warningThreshold[i] / intervalsPerHour)) && (kpi[i] > 0.0))
//            {
//               result[i] = Warnings_alerts::E_WARNING;
//            }
//         }
//         else if (comparisonOperation == "more")
//         {
//            if (kpi[i] > (alarmThreshold[i] / intervalsPerHour))
//            {
//               result[i] = Warnings_alerts::E_ALARM;
//            }
//            else if (kpi[i] > (warningThreshold[i] / intervalsPerHour))
//            {
//               result[i] = Warnings_alerts::E_WARNING;
//            }
//         }
//      }
//   }
//
//   return result;
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlerts(int intervalsPerHour,
//                                                  LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                  string comparisonOperation,
//                                                  LpiADOVector<int> kpi)
//{
//   return generateAlerts(intervalsPerHour,
//                         warningThreshold,
//                         alarmThreshold,
//                         comparisonOperation,
//                         toDouble(kpi));
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlerts(std::string interval,
//                                                   int intervalsPerHour,
//                                                   LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                   string comparisonOperation,
//                                                   LpiADOVector<double> kpi)
//{
//
//   Warnings_alerts result(Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT);
//
//  /* LpdbDemand & demand = LpdbDataBase::Get().getDemand();
//
//   bool empty_demand = demand.isEmpty();
//
//   bool empty_demand_interval = false;
//   LpiADOVector<int> demand_interval;
//   if (demand.has_data(interval))
//   {
//      empty_demand_interval = demand[interval].isEmpty();
//      demand_interval = demand[interval].getDemandForecast();
//   }
//
//   if (empty_demand || empty_demand_interval)
//   {
//      return result;
//   }
//
//   for (int i = E_ARR; i <= E_OVA; i++)
//   {
//      if (demand_interval[i] > 0.0)
//      {
//         if (kpi[i] >= 0)
//         {
//            if (comparisonOperation == "less")
//            {
//               if ((kpi[i] < (alarmThreshold[i] / intervalsPerHour)) && (kpi[i] >= 0.0))
//               {
//                  result[i] = Warnings_alerts::E_ALARM;
//               }
//               else if ((kpi[i] < (warningThreshold[i] / intervalsPerHour)) && (kpi[i] >= 0.0))
//               {
//                  result[i] = Warnings_alerts::E_WARNING;
//               }
//            }
//            else if (comparisonOperation == "more")
//            {
//               if (kpi[i] > (alarmThreshold[i] / intervalsPerHour))
//               {
//                  result[i] = Warnings_alerts::E_ALARM;
//               }
//               else if (kpi[i] > (warningThreshold[i] / intervalsPerHour))
//               {
//                  result[i] = Warnings_alerts::E_WARNING;
//               }
//            }
//         }
//      }
//   }
//*/
//   return result;
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlerts(std::string interval,
//                                                   int intervalsPerHour,
//                                                   LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                   string comparisonOperation,
//                                                   LpiADOVector<int> kpi)
//{
//   return generateAlerts(interval,
//                         intervalsPerHour,
//                         warningThreshold,
//                         alarmThreshold,
//                         comparisonOperation,
//                         toDouble(kpi));
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlerts(std::string interval,
//                                                   OperationType::Enum runway_usage,
//                                                   LpiADOVector<double> demand_forecast,
//                                                   int intervalsPerHour,
//                                                   LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                   string comparisonOperation,
//                                                   LpiADOVector<double> kpi)
//{
//
//   Warnings_alerts result(Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT);
//
//  /* LpdbDemand & demand = LpdbDataBase::Get().getDemand();
//
//   bool empty_demand = demand.isEmpty();
//
//   bool empty_demand_interval = false;
//   LpiADOVector<int> demand_interval;
//   if (demand.has_data(interval))
//   {
//      empty_demand_interval = demand[interval].isEmpty();
//      demand_interval = demand[interval].getDemandForecast();
//   }
//
//   if (empty_demand || empty_demand_interval)
//   {
//      return result;
//   }
//
//   int runway_no_usage = -1;
//   switch (runway_usage)
//   {
//      case OperationType::E_ARRIVALS:
//         runway_no_usage = E_DEP;
//      break;
//      case OperationType::E_DEPARTURES:
//         runway_no_usage = E_ARR;
//      break;
//      case OperationType::E_MIXED:
//      case OperationType::E_INVALID_RWY_OPERATION_TYPE:
//      break;
//   }
//
//
//   for (int i = E_ARR; i <= E_OVA; i++)
//   {
//      if ((i != runway_no_usage) && (demand_forecast[i] > 0.0))
//      {
//         if (kpi[i] >= 0)
//         {
//            if (comparisonOperation == "less")
//            {
//               if (kpi[i] < (alarmThreshold[i] / intervalsPerHour))
//               {
//                  result[i] = Warnings_alerts::E_ALARM;
//               }
//               else if (kpi[i] < (warningThreshold[i] / intervalsPerHour))
//               {
//                  result[i] = Warnings_alerts::E_WARNING;
//               }
//            }
//            else if (comparisonOperation == "more")
//            {
//               if (kpi[i] > (alarmThreshold[i] / intervalsPerHour))
//               {
//                  result[i] = Warnings_alerts::E_ALARM;
//               }
//               else if (kpi[i] > (warningThreshold[i] / intervalsPerHour))
//               {
//                  result[i] = Warnings_alerts::E_WARNING;
//               }
//            }
//         }
//      }
//   }*/
//
//   return result;
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlerts(std::string interval,
//                                                   OperationType::Enum runway_usage,
//                                                   LpiADOVector<double> demand_forecast,
//                                                   int intervalsPerHour,
//                                                   LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                   string comparisonOperation,
//                                                   LpiADOVector<int> kpi)
//{
//   return generateAlerts(interval,
//                         runway_usage,
//                         demand_forecast,
//                         intervalsPerHour,
//                         warningThreshold,
//                         alarmThreshold,
//                         comparisonOperation,
//                         toDouble(kpi));
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlertsForComparison(int intervalsPerHour,
//                                                                LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                                string comparisonOperation,
//                                                                LpiADOVector<double> kpi)
//{
//
//   Warnings_alerts result(Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT);
//
// /*  bool empty_demand = LpdbDataBase::Get().getDemand().isEmpty();
//
//   if (empty_demand)
//   {
//      return result;
//   }
//
//   for (int i = E_ARR; i <= E_OVA; i++)
//   {
//         if (comparisonOperation == "less")
//         {
//            if (kpi[i] < (alarmThreshold[i] / intervalsPerHour))
//            {
//               result[i] = Warnings_alerts::E_ALARM;
//            }
//            else if (kpi[i] < (warningThreshold[i] / intervalsPerHour))
//            {
//               result[i] = Warnings_alerts::E_WARNING;
//            }
//         }
//         else if (comparisonOperation == "more")
//         {
//            if (kpi[i] > (alarmThreshold[i] / intervalsPerHour))
//            {
//               result[i] = Warnings_alerts::E_ALARM;
//            }
//            else if (kpi[i] > (warningThreshold[i] / intervalsPerHour))
//            {
//               result[i] = Warnings_alerts::E_WARNING;
//            }
//         }
//   }
//*/
//   return result;
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::generateAlertsForComparison(int intervalsPerHour,
//                                                                LpiADO warningThreshold, LpiADO alarmThreshold,
//                                                                string comparisonOperation,
//                                                                LpiADOVector<int> kpi)
//{
//   return generateAlertsForComparison(intervalsPerHour,
//                                      warningThreshold,
//                                      alarmThreshold,
//                                      comparisonOperation,
//                                      toDouble(kpi));
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::GenerateAlertsForComparison(int intervalsPerHour,
//                                                                const Alert & thresholds,
//                                                                const Improvement & positiveThresholds,
//                                                                LpiADOVector<double> kpi)
//{
//   Warnings_alerts result(Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT,
//                          Warnings_alerts::E_NO_ALERT);
///*
//   bool empty_demand = LpdbDataBase::Get().getDemand().isEmpty();
//
//   if (empty_demand)
//   {
//      return result;
//   }
//
//   LpiADO warningThreshold = thresholds.getWarningThreshold();
//   LpiADO alarmThreshold   = thresholds.getAlarmThreshold();
//   std::string comparisonAlarm = thresholds.getComparison();
//
//   LpiADO slightThreshold = positiveThresholds.getSlightImprovementThreshold();
//   LpiADO improvementThreshold = positiveThresholds.getImprovementThreshold();
//   std::string comparisonImprovement = positiveThresholds.getComparison();
//
//   for (int i = E_ARR; i <= E_OVA; i++)
//   {
//      if (comparisonAlarm == "less")
//      {
//         if (kpi[i] < (alarmThreshold[i] / intervalsPerHour))
//         {
//            result[i] = Warnings_alerts::E_ALARM;
//         }
//         else if (kpi[i] < (warningThreshold[i] / intervalsPerHour))
//         {
//            result[i] = Warnings_alerts::E_WARNING;
//         }
//         else
//         {
//            result[i] = CheckImprovements(intervalsPerHour,
//                                          slightThreshold[i],
//                                          improvementThreshold[i],
//                                          comparisonImprovement,
//                                          kpi[i]);
//         }
//      }
//      else if (comparisonAlarm == "more")
//      {
//         if (kpi[i] > (alarmThreshold[i] / intervalsPerHour))
//         {
//            result[i] = Warnings_alerts::E_ALARM;
//         }
//         else if (kpi[i] > (warningThreshold[i] / intervalsPerHour))
//         {
//            result[i] = Warnings_alerts::E_WARNING;
//         }
//         else
//         {
//            result[i] = CheckImprovements(intervalsPerHour,
//                                          slightThreshold[i],
//                                          improvementThreshold[i],
//                                          comparisonImprovement,
//                                          kpi[i]);
//         }
//      }
//   }
//*/
//   return result;
//}
//
//
//Warnings_alerts LpdbAlertsGenerator::GenerateAlertsForComparison(int intervalsPerHour,
//                                                                const Alert & thresholds,
//                                                                const Improvement & positiveThresholds,
//                                                                LpiADOVector<int> kpi)
//{
//   return GenerateAlertsForComparison(intervalsPerHour,
//                                      thresholds,
//                                      positiveThresholds,
//                                      toDouble(kpi));
//}
//
//
//Warnings_alerts::LpiEnum LpdbAlertsGenerator::CheckImprovements(int intervalsPerHour,
//                                                               float slightThreshold,
//                                                               float improvementThreshold,
//                                                               std::string comparison,
//                                                               double kpi)
//{
//   Warnings_alerts::LpiEnum result = Warnings_alerts::E_NO_ALERT;
//
//
//   if (comparison == "less")
//   {
//         if (kpi < (improvementThreshold / intervalsPerHour))
//         {
//            result = Warnings_alerts::E_IMPROVEMENT;
//         }
//         else if (kpi < (slightThreshold / intervalsPerHour))
//         {
//            result = Warnings_alerts::E_SLIGHT_IMPROVEMENT;
//         }
//   }
//   else if (comparison == "more")
//   {
//         if (kpi > (improvementThreshold / intervalsPerHour))
//         {
//            result = Warnings_alerts::E_IMPROVEMENT;
//         }
//         else if (kpi > (slightThreshold / intervalsPerHour))
//         {
//            result = Warnings_alerts::E_SLIGHT_IMPROVEMENT;
//         }
//   }
//
//   return result;
//}
//
