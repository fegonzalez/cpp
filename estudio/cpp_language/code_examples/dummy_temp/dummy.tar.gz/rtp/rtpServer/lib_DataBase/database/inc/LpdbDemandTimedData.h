/*
 * LpdbDemandTimedData.h
 *
 *  Created on: 02/01/2014
 *      Author: mbegega
 */

#ifndef DEMANDTIMEDDATA_H_
#define DEMANDTIMEDDATA_H_

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <LpiADOVector.h>
#include "LpiFlightPlan.h"

using std::vector;
using std::string;


class LpdbDemandTimedData
{
	friend 	std::ostream& operator<<(std::ostream &os, const LpdbDemandTimedData &info);

public:

   LpdbDemandTimedData();

   LpdbDemandTimedData(const LpdbDemandTimedData & source);

   virtual ~LpdbDemandTimedData();

   LpdbDemandTimedData & operator= (const LpdbDemandTimedData & source);

   std::string get_name ();

   LpiADOVector<unsigned int> getDemandForecast() const;
   void setDemandForecast(LpiADOVector<unsigned int> demandForecast);

   LpiADOVector<unsigned int> getDemandVFR() const;
   void setDemandVFR(LpiADOVector<unsigned int> demandVFR);

   LpiADOVector<vector<string> > getDemandForecastFps() const;
   void setDemandForecastFps(LpiADOVector<vector<string> > demandForecastFps);

   void incrementDemand(unsigned int demand_type, unsigned int demand_value);
   void decrementDemand(unsigned int demand_type, unsigned int demand_value);


   //Store FP in forecast ordered by Intentional time
   void storeFPInForecast(const LpiFlightPlan & fp);

   void deleteFPFromForecast(const LpiFlightPlan & fp);

   LpiADOVector<double> getPonderatedDemand() const;

   bool isForecastEmpty () const;
   bool isVfrEmpty() const;

protected:

   std::string r_name;

   LpiADOVector<unsigned int>             r_demand_forecast;

   LpiADOVector<vector<string> > r_demand_forecast_fps; ///@todo FIXME No Se está actualizando al recibir demanda; solo hay una llamaa a deleteFPFromForecast

   LpiADOVector<unsigned int>			  r_demand_VFR; ///@todo FIXME No se está actualizando al recibir input demanda


   ///@todo FIXME  LpdbDataBase::Get().getFPTable();  ¿Qué hay aquí?


   void storeOrdered (const LpiFlightPlan & fp, vector<string> & store);
};



#endif /* DEMANDTIMEDDATA_H_ */
