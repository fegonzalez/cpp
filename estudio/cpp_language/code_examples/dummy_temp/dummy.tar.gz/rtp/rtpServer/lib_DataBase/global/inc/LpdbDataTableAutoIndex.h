/*
 * LpdbDataTableAutoIndex.h
 *
 *  Created on: 11/07/2014
 *      Author: mbegega
 *
 *  Description: Template for a database table with autonumeric index
 *               and stored data type T
 */

#ifndef LPDBDATA_TABLE_AUTOINDEX_H_
#define LPDBDATA_TABLE_AUTOINDEX_H_

#include <iostream>
#include <set>
#include "LpdbDataTable.h"

using std::set;

template <class T>
class LpdbDataTableAutoIndex: public LpdbDataTable<int, T>
{
   public:
      LpdbDataTableAutoIndex();
      LpdbDataTableAutoIndex(int initialIndex);
      LpdbDataTableAutoIndex(const LpdbDataTableAutoIndex & source);
      virtual ~LpdbDataTableAutoIndex() {}

      LpdbDataTableAutoIndex & operator= (const LpdbDataTableAutoIndex & source);

      int addElement (T element);
      void deleteElement (int index);

      void clear();

      int getNextAutoId() const;

   protected:

      int r_next_auto_id;
      set<int> r_free_ids;
};


template <class T>
inline LpdbDataTableAutoIndex<T>::LpdbDataTableAutoIndex()
: LpdbDataTable<int, T>(),
  r_next_auto_id(0),
  r_free_ids()
{
}


template <class T>
inline LpdbDataTableAutoIndex<T>::LpdbDataTableAutoIndex(int initialIndex)
: LpdbDataTable<int, T>(),
  r_next_auto_id(initialIndex),
  r_free_ids()
{
}


template<class T>
inline LpdbDataTableAutoIndex<T>::LpdbDataTableAutoIndex(const LpdbDataTableAutoIndex<T> & source)
: LpdbDataTable<int, T>(source),
  r_next_auto_id(source.r_next_auto_id),
  r_free_ids(source.r_free_ids)
{
}


template<class T>
int LpdbDataTableAutoIndex<T>::addElement(T element)
{
   int id = r_next_auto_id;

   if (r_free_ids.size() > 0)
   {
      id = *r_free_ids.begin();
      r_free_ids.erase(r_free_ids.begin());
   }
   else
   {
      r_next_auto_id++;
   }

   LpdbDataTable<int,T>::addElement(id, element);

   return id;
}


template<class T>
void LpdbDataTableAutoIndex<T>::deleteElement(int index)
{
   r_free_ids.insert(index);

   LpdbDataTable<int, T>::deleteElement(index);
}


template<class T>
inline LpdbDataTableAutoIndex<T>& LpdbDataTableAutoIndex<T>::operator = (const LpdbDataTableAutoIndex<T> & source)
{
   if (this != &source)
   {
      LpdbDataTable<int, T>::operator =(source);
      r_next_auto_id = source.r_next_auto_id;
      r_free_ids = source.r_free_ids;
   }

   return *this;
}


template<class T>
void LpdbDataTableAutoIndex<T>::clear()
{
   LpdbDataTable<int, T>::clear();
   r_free_ids.clear();
   r_next_auto_id = 0;
}


template<class T>
int LpdbDataTableAutoIndex<T>::getNextAutoId() const
{
   if (r_free_ids.size() > 0)
   {
      return *r_free_ids.begin();
   }
   else
   {
      return r_next_auto_id;
   }
}


template <class T>
inline std::ostream & operator<< (std::ostream & out, const LpdbDataTableAutoIndex<T> & table)
{
   out << static_cast<const LpdbDataTable<int, T> &>(table);
   out << "[NEXT: " << table.getNextAutoId() << "]";

   return out;
}

#endif /* LPDBDATA_TABLE_AUTOINDEX_H_ */
