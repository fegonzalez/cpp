/*
 * LpdbTMA.h
 *
 */

#include "LpdbTMA.h"
#include <LpiIncreasingReductionFunction.h>

#ifdef TRACE_OUT
#include <LclogStream.h>
#endif

#include <iostream>
#include <cmath>
#include <algorithm>    // std::for_each
#include <functional>   // bind
#include <cassert>


bool LpdbTMA::has_data(const string& interval_name)
{
   return r_timeLine.hasData(interval_name);
}


LpdbTMATimedData& LpdbTMA::operator [](const string& interval_name)
{
   return r_timeLine[interval_name];
}


void LpdbTMA::init(const LpiTimeParameters & parameters,
		   boost::posix_time::ptime begin_timestamp,
		   const unsigned int tmaNominalCapacity)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  r_tmaNominal = tmaNominalCapacity; // from adap file => // const during all the execution

  r_timeLine.initialize(parameters.getMinutesSubinterval(),
			parameters.getHoursWindow(),
			parameters.getMinutesFrozen(),
			begin_timestamp);
   r_timeLine.fill();
}


void LpdbTMA::forward()
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

   r_timeLine.forward();

   //Creates default element in newly created interval
   r_timeLine.createElement(r_timeLine.getLastInterval());
}

TimeLine<LpdbTMATimedData> & LpdbTMA::getTimeLine()
{
   return r_timeLine;
}

std::string LpdbTMA::getIntervalsShortFormat () const
{
   return r_timeLine.getIntervalsShortFormat();
}


std::string LpdbTMA::getIntervalsAsString () const
{
   return r_timeLine.getAsString();
}


//------------------------------------------------------------------------------

void LpdbTMA::calculateCapacity()
{
  std::vector<string> intervals = r_timeLine.getAllIntervalIds();


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
	<< " ; num intervals = " << intervals.size()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  std::for_each(std::begin(intervals), std::end(intervals),
		std::bind(static_cast<void(LpdbTMA::*)(std::string)>
  	  	  (&LpdbTMA::calculateCapacity), this, std::placeholders::_1));
}


void LpdbTMA::calculateCapacity(std::string interval)
{
  assert(r_timeLine.exists(interval));
  if (has_data(interval))
  {
	assert(r_timeLine.getNumberOfIntervalsPerHour() > 0);
    LpdbTMATimedData & tma_data = r_timeLine[interval];
    tma_data.calculateCapacity(r_timeLine.getNumberOfIntervalsPerHour(), 
			       r_tmaNominal); // const during all the execution
  }
}

//------------------------------------------------------------------------------

 std::ostream & operator<<(std::ostream & os, const LpdbTMA & data)
 {
   return os << "nominal_tma: " << data.getNominalTMA()
 	    << " | timeline: " << data.r_timeLine
 	    << ']';
 }

 //------------------------------------------------------------------------------

