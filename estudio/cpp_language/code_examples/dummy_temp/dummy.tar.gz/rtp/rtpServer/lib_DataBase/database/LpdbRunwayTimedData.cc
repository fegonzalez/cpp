/*
 * LpdbRunwayTimedData.cc
 *
 *  Created on: 17/12/2013
 *      Author: mbegega
 */

#include "LpdbRunwayTimedData.h"


LpdbRunwayTimedData::LpdbRunwayTimedData()
: r_name(),
  r_crosswind(),
  r_tailwind(),
  r_crosswind_suitability(),
  r_crosswind_margin(),
  r_crosswind_dryconds_upperthreshold(),
  r_non_availability(false),
  r_max_capacity(),
  r_max_capacity_nominal_interval(),
  r_pctg_manual_capacity_reduction(),
  r_met_capacity_reduction(),
  r_crosswind_capacity_reduction(),
  r_tailwind_capacity_reduction(),
  r_visibility_capacity_reduction(),
  r_manual_capacity_reduction(),
  r_max_capacity_departures(),
  r_max_capacity_arrivals(),
  r_max_capacity_overall(),
  r_closureReason(LpiClosureReason::E_NONE)
{
}


LpdbRunwayTimedData::LpdbRunwayTimedData(const LpdbRunwayTimedData & source)
:  r_name(source.r_name),
   r_crosswind(source.r_crosswind),
   r_tailwind(source.r_tailwind),
   r_crosswind_suitability(source.r_crosswind_suitability),
   r_crosswind_margin(source.r_crosswind_margin),
   r_crosswind_dryconds_upperthreshold(source.r_crosswind_dryconds_upperthreshold),
   r_non_availability(source.r_non_availability),
   r_max_capacity(source.r_max_capacity),
   r_max_capacity_nominal_interval(source.r_max_capacity_nominal_interval),
   r_pctg_manual_capacity_reduction(source.r_pctg_manual_capacity_reduction),
   r_met_capacity_reduction(source.r_met_capacity_reduction),
   r_crosswind_capacity_reduction(source.r_crosswind_capacity_reduction),
   r_tailwind_capacity_reduction(source.r_tailwind_capacity_reduction),
   r_visibility_capacity_reduction(source.r_visibility_capacity_reduction),
   r_manual_capacity_reduction(source.r_manual_capacity_reduction),
   r_max_capacity_departures(source.r_max_capacity_departures),
   r_max_capacity_arrivals(source.r_max_capacity_arrivals),
   r_max_capacity_overall(source.r_max_capacity_overall),
   r_closureReason(source.r_closureReason)
{
}


LpdbRunwayTimedData::~LpdbRunwayTimedData()
{

}


LpdbRunwayTimedData & LpdbRunwayTimedData::operator= (const LpdbRunwayTimedData & source)
{
   if (this != &source)
   {
      r_name = source.r_name;
      r_crosswind = source.r_crosswind;
      r_tailwind = source.r_tailwind;
      r_crosswind_suitability = source.r_crosswind_suitability;
      r_crosswind_margin = source.r_crosswind_margin;
      r_crosswind_dryconds_upperthreshold = source.r_crosswind_dryconds_upperthreshold;
      r_non_availability = source.r_non_availability;
      r_max_capacity = source.r_max_capacity;
      r_pctg_manual_capacity_reduction = source.r_pctg_manual_capacity_reduction;
      r_met_capacity_reduction = source.r_met_capacity_reduction;
      r_crosswind_capacity_reduction = source.r_crosswind_capacity_reduction;
      r_tailwind_capacity_reduction = source.r_tailwind_capacity_reduction;
      r_visibility_capacity_reduction = source.r_visibility_capacity_reduction;
      r_manual_capacity_reduction = source.r_manual_capacity_reduction;
      r_max_capacity_departures = source.r_max_capacity_departures;
      r_max_capacity_arrivals = source.r_max_capacity_arrivals;
      r_max_capacity_overall = source.r_max_capacity_overall;
      r_max_capacity_nominal_interval = source.r_max_capacity_nominal_interval;
      r_closureReason = source.r_closureReason;
   }

   return *this;
}


std::string LpdbRunwayTimedData::get_name () const
{
   return r_name;
}


boost::optional<float> LpdbRunwayTimedData::getCrosswind() const
{
   return r_crosswind;
}


void LpdbRunwayTimedData::setCrosswind(boost::optional<float> crosswind)
{
   r_crosswind = crosswind;
}


LpiADOVector<double> LpdbRunwayTimedData::getCrosswindCapacityReduction() const
{
   return r_crosswind_capacity_reduction;
}


void LpdbRunwayTimedData::setCrosswindCapacityReduction(
      LpiADOVector<double> crosswindCapacityReduction)
{
   r_crosswind_capacity_reduction = crosswindCapacityReduction;
}


float LpdbRunwayTimedData::getCrosswindDrycondsUpperthreshold() const
{
   return r_crosswind_dryconds_upperthreshold;
}


void LpdbRunwayTimedData::setCrosswindDrycondsUpperthreshold(
      float crosswindDrycondsUpperthreshold)
{
   r_crosswind_dryconds_upperthreshold = crosswindDrycondsUpperthreshold;
}


float LpdbRunwayTimedData::getCrosswindMargin() const
{
   return r_crosswind_margin;
}


void LpdbRunwayTimedData::setCrosswindMargin(float crosswindMargin)
{
   r_crosswind_margin = crosswindMargin;
}


float LpdbRunwayTimedData::getCrosswindSuitability() const
{
   return r_crosswind_suitability;
}


void LpdbRunwayTimedData::setCrosswindSuitability(float crosswindSuitability)
{
   r_crosswind_suitability = crosswindSuitability;
}


LpiADOVector<int> LpdbRunwayTimedData::getMaxCapacity() const
{
   return r_max_capacity;
}


void LpdbRunwayTimedData::setMaxCapacity(LpiADOVector<int> maxCapacity)
{
   r_max_capacity = maxCapacity;
}


int LpdbRunwayTimedData::getMaxCapacityArrivals() const
{
   return r_max_capacity_arrivals;
}


void LpdbRunwayTimedData::setMaxCapacityArrivals(int maxCapacityArrivals)
{
   r_max_capacity_arrivals = maxCapacityArrivals;
}


int LpdbRunwayTimedData::getMaxCapacityDepartures() const
{
   return r_max_capacity_departures;
}


void LpdbRunwayTimedData::setMaxCapacityDepartures(int maxCapacityDepartures)
{
   r_max_capacity_departures = maxCapacityDepartures;
}


int LpdbRunwayTimedData::getMaxCapacityOverall() const
{
   return r_max_capacity_overall;
}


void LpdbRunwayTimedData::setMaxCapacityOverall(int maxCapacityOverall)
{
   r_max_capacity_overall = maxCapacityOverall;
}


LpiADOVector<double> LpdbRunwayTimedData::getMetCapacityReduction() const
{
   return r_met_capacity_reduction;
}


void LpdbRunwayTimedData::setMetCapacityReduction(LpiADOVector<double> metCapacityReduction)
{
   r_met_capacity_reduction = metCapacityReduction;
}

LpiADOVector<double> LpdbRunwayTimedData::getManualCapacityReduction() const
{
   return r_manual_capacity_reduction;
}


void LpdbRunwayTimedData::setManualCapacityReduction(LpiADOVector<double> manualCapacityReduction)
{
   r_manual_capacity_reduction = manualCapacityReduction;
}

bool LpdbRunwayTimedData::isNonAvailability() const
{
   return r_non_availability;
}


void LpdbRunwayTimedData::setNonAvailability(bool nonAvailability, const LpiClosureReason::LpiEnum & reason)
{
   r_non_availability = nonAvailability;
   r_closureReason = reason;
}


float LpdbRunwayTimedData::getPctgManualCapacityReduction() const
{
   return r_pctg_manual_capacity_reduction;
}


void LpdbRunwayTimedData::setPctgManualCapacityReduction(
      float pctgManualCapacityReduction)
{
   r_pctg_manual_capacity_reduction = pctgManualCapacityReduction;
}


boost::optional<float> LpdbRunwayTimedData::getTailwind() const
{
   return r_tailwind;
}


void LpdbRunwayTimedData::setTailwind(boost::optional<float> tailwind)
{
   r_tailwind = tailwind;
}


LpiADOVector<double> LpdbRunwayTimedData::getTailwindCapacityReduction() const
{
   return r_tailwind_capacity_reduction;
}


void LpdbRunwayTimedData::setTailwindCapacityReduction(
      LpiADOVector<double> tailwindCapacityReduction)
{
   r_tailwind_capacity_reduction = tailwindCapacityReduction;
}


LpiADOVector<double> LpdbRunwayTimedData::getVisibilityCapacityReduction() const
{
   return r_visibility_capacity_reduction;
}


void LpdbRunwayTimedData::setVisibilityCapacityReduction(
      LpiADOVector<double> visibilityCapacityReduction)
{
   r_visibility_capacity_reduction = visibilityCapacityReduction;
}


LpiADOVector<int> LpdbRunwayTimedData::getMaxCapacityNominalInterval() const
{
   return r_max_capacity_nominal_interval;
}


void LpdbRunwayTimedData::setMaxCapacityNominalInterval(LpiADOVector<int> capacity)
{
   r_max_capacity_nominal_interval = capacity;
}


bool LpdbRunwayTimedData::hasManualReduction () const
{
   return ((r_manual_capacity_reduction[E_ARR] > 0.0) ||
           (r_manual_capacity_reduction[E_DEP] > 0.0) ||
           (r_manual_capacity_reduction[E_OVA] > 0.0));
}


std::ostream& operator<<(std::ostream &os, const LpdbRunwayTimedData &info)
{
   return os << " | MAX_CAP : " << info.getMaxCapacity()
             << " | MANUAL REDUCTIONS: "<< info.getManualCapacityReduction()
             << " | NON_AVAIL: " << "false\0true" + (6 * info.isNonAvailability())
             << " | REASON: " << info.getClosureReason();
}
