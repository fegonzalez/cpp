
#ifndef LPCOPTIMALCRITERIAEVTPUBLISHER_H_
#define LPCOPTIMALCRITERIAEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOWhatIFEventsiBContract.h>
#include <IOWhatIFEvents.h>
#include <IOTim.h>


class LpcOptimalCriteriaEvtPublisher : public LpiIOptimalCriteriaEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiOptimalCriteriaEvt &data);

private:

   iBG::IOWhatIFEvents::AlternativeResponseEventPublisher *_publisher;
};



#endif /* LPCOPTIMALCRITERIAEVTPUBLISHER_H_ */
