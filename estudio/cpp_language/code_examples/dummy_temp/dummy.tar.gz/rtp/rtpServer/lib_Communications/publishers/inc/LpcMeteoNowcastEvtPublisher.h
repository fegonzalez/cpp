
#ifndef LPCMETEONOWCASTEVTPUBLISHER_H_
#define LPCMETEONOWCASTEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOTim.h>

#include <IOMeteoInfoEventsiBContract.h>
#include <IOMeteoInfoEvents.h>

class LpcMeteoNowcastEvtPublisher : public LpiIMeteoNowcastEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiMeteoNowcastEvt &data);

private:

   iBG::IOMeteoInfoEvents::UpdateMeteoNowcastEventListPublisher *_publisher;
};



#endif /* LPCMETEOINFOEVTPUBLISHER_H_ */
