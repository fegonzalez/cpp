
#include "LpcSchedulesComparisonEvtConsumer.h"
#include <IOComparisonSchedules.h>
#include <LpiSchedulesComparisonEvt.h>
#include "LpcSchedulesComparison.h"
#include <LpdComponent.h>

#include <string>


void LpcSchedulesComparisonEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOComparisonSchedulesEvents::ComparisonSchedulesEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventSubscriber &subscriber =
             iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventCreateSubscriber(sid, sprofile);

   subscriber.addListener(this);
}


void LpcSchedulesComparisonEvtConsumer::on_data_available(
                iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventSubscriber & sub)
{
   iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventSubscriber::DataList dl;

   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventSubscriber::DataList::iterator dit
                                                                                  = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {

      if(iit->isValid())
      {
         //Obtain data
         IOComparisonSchedules::ComparisonSchedules comparisonData;
         memset(&comparisonData, 0, sizeof(IOComparisonSchedules::ComparisonSchedules));
         comparisonData = dit->comparisonSchedules;

         //Internal type conversion
         LpiSchedulesComparison schedulesComparison;
         LpcSchedulesComparison::convertIO2Lpi(comparisonData, schedulesComparison);

         //Event
         LpiSchedulesComparisonEvt event;
         event.setSchedulesComparison(schedulesComparison);

         LpdComponent::Get().consume(event);
      }
   }
}

