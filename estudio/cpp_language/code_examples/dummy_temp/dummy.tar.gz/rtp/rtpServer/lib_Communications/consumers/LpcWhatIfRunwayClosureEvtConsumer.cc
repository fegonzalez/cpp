/*
 * LpcWhatIfRunwayClosureEvtConsumer.h
 *
 *  Created on: 19/05/2015
 */

#include <string>

#include "LpcWhatIfRunwayClosureEvtConsumer.h"
#include <IOWhatIF.h>
#include <LpiWhatIfRunwayClosureEvt.h>
#include "LpcWhatIfClosure.h"
#include <LpdComponent.h>


void LpcWhatIfRunwayClosureEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOWhatIFEvents::RunwayClosuresEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOWhatIFEvents::RunwayClosuresEventSubscriber &subscriber =
             iBG::IOWhatIFEvents::RunwayClosuresEventCreateSubscriber(sid, sprofile);

   subscriber.addListener(this);
}


void LpcWhatIfRunwayClosureEvtConsumer::on_data_available(
                        iBG::IOWhatIFEvents::RunwayClosuresEventSubscriber & sub)
{
   iBG::IOWhatIFEvents::RunwayClosuresEventSubscriber::DataList dl;

   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOWhatIFEvents::RunwayClosuresEventSubscriber::DataList::iterator dit
                                                               = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {

      if(iit->isValid())
      {
         //Obtain data
         IOWhatIF::RunwayClosures runwayClosures;
         memset(&runwayClosures, 0, sizeof(IOWhatIF::RunwayClosures));
         runwayClosures = dit->runwayClosures;

         //Internal type conversion
         LpiWhatIfClosure closuresInterface;
         LpcWhatIfClosure::ConvertIO2Lpi(runwayClosures, closuresInterface);

         //Event
         LpiWhatIfRunwayClosureEvt event;
         event.setClosures(closuresInterface);

         LpdComponent::Get().consume(event);
      }
   }
}

