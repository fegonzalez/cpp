/*
 * LpcOptimalSchedule.h
 *
 *  Created on: 17/02/2014
 *  Author: gpfernandez
 */

#ifndef LPCOPTIMALSCHEDULE_H_
#define LPCOPTIMALSCHEDULE_H_

#include <vector>

#include <IOTim.h>
#include <IOSchedule.h>

#include <LpiKPIs.h>
#include <LpiCapacityInfo.h>
#include <LpiSchedule.h>


class LpcOptimalSchedule
{
   public:

      static void convert2OptimalSchedule(const LpiSchedule & in,
                                          IOSchedule::Schedule & out);

      static void convert2ScheduledFPs(const LpiFPList & in,
                                       IOSchedule::ScheduledFlightPlans & out);

      static void convert2TimeIntervalData(const LpiTimeIntervalData & in,
                                           IOSchedule::TimeIntervalData & out);

      static void convert2AirportIntervalKPIs(const LpiAirportIntervalKPIs & in,
                                              IOKPIs::AirportIntervalKPIs & out);

      static void convert2AirportIntervalCapacityInfo(const LpiAirportIntervalCapacityInfo & in,
                                                      IOCapacity::AirportIntervalCapacityInfo & out);

      static void convert2RunwaysIntervalData(const LpiPerformanceIntervalData & inPerformance,
                                              IOKPIs::RunwaysKPIs & outKpis,
                                              const LpiCapacityIntervalData & inCapacity,
                                              IOCapacity::RunwaysIntervalCapacities & outCapacities);

      static void convert2AirportTotalKPIs(const LpiAirportTotalKPIs & in,
                                           IOKPIs::AirportTotalKPIs & out);

   private:

};


#endif /* LPCOPTIMALSCHEDULE_H_ */
