#include <vector>
#include <string>
#include <LctimTimeUtils.h>
#include <LctimVirtualClock.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/algorithm/string/trim.hpp>

#include <LpdbDataBase.h>
#include "LpcClosureReason.h"
#include <LcuStringArrayConvUtils.h>
#include "LpcWhatIfClosure.h"

using std::vector;
using std::string;


void LpcWhatIfClosure::ConvertIO2Lpi(const IOCapacityReductions::RunwayNonPeriods & in,
                                     std::vector<LpiRunwayClosure> & out)
{
   boost::posix_time::ptime startup = LctimVirtualClock::Get().getStartupTime();
   boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();
   int minutesSubInterval = LpdbDataBase::Get().getGlobalParameters().getTimeParameters().getMinutesSubinterval();

   unsigned int min= startup.time_of_day().minutes();
   unsigned int sec= startup.time_of_day().seconds();
   unsigned int base_min= min % minutesSubInterval;

   //To Detect day change in start time
   boost::posix_time::ptime timeLineInit = startup - minutes(base_min) - seconds(sec);

   for (int i = 0; i < in.length(); i++)
   {
      IOCapacityReductions::RunwayNonPeriod rwyClosureIO = in.get_at(i);

      std::string idRunway(rwyClosureIO.runway, IOConst::RWY_SIZE);
      boost::algorithm::trim(idRunway);

      string startTime(rwyClosureIO.startTime, IOConst::TIME_SIZE);
      boost::algorithm::trim(startTime);

      boost::posix_time::ptime startDate;
      LctimTimeUtils::getFromTodayHour(startTime, startup, startDate);

      //Detect day change
      if (startDate < timeLineInit)
      {
         LctimTimeUtils::getFromTomorrowHour(startTime, startup, startDate);
      }

      string endTime(rwyClosureIO.endTime, IOConst::TIME_SIZE);
      boost::algorithm::trim(endTime);

      boost::posix_time::ptime endDate;
      LctimTimeUtils::getFromTodayHour(endTime, now, endDate);

      if (endDate < startDate)
      {
         LctimTimeUtils::getFromTomorrowHour(endTime, now, endDate);
      }

      LpiClosureReason::LpiEnum reason;
      LpcClosureReason::convertIO2LpiClosureReason(rwyClosureIO.reason, reason);

      LpiRunwayClosure rwyClosureInterface(idRunway, startDate, endDate, reason);

      out.push_back(rwyClosureInterface);
   }
}


void LpcWhatIfClosure::ConvertIO2Lpi(const IOWhatIF::RunwayClosures & in,
                                     LpiWhatIfClosure & out)
{
   out.setId(static_cast<int>(in.id));

   string whatIfName(in.name, IOConst::WHAT_IF_NAME_SIZE);
   boost::algorithm::trim(whatIfName);

   out.setName(whatIfName);

   out.setAvoidAutoDelete(static_cast<bool>(in.avoidAutomaticDeletion));

   switch(in.runwayClosuresType)
   {
      case IOWhatIF::E_ACTIVE_SCHEDULE:
         out.setWhatIfClosureType(LpiWhatIfClosure::E_APPLY_ON_ACTIVE);
      break;
      case IOWhatIF::E_NEW_SOLUTION:
         out.setWhatIfClosureType(LpiWhatIfClosure::E_NEW_OPTIMAL);
      break;
      case IOWhatIF::E_BEST_POINT_CLOSURE:
         out.setWhatIfClosureType(LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE);
      break;
      case IOWhatIF::E_BEST_POINT_CLOSURE_FOR_ACTIVE:
         out.setWhatIfClosureType(LpiWhatIfClosure::E_BEST_POINT_CLOSURE_FOR_ACTIVE);
      break;
      default:
         out.setWhatIfClosureType(LpiWhatIfClosure::E_UNKNOWN);
      break;
   }

   if ((in.runwayClosuresType == IOWhatIF::E_BEST_POINT_CLOSURE) ||
       (in.runwayClosuresType == IOWhatIF::E_BEST_POINT_CLOSURE_FOR_ACTIVE))
   {
      LpiBestPointClosure bestPointClosure;
      LpcWhatIfClosure::ConvertIO2Lpi(in.bestPointClosure, bestPointClosure);
      out.setBestPointClosure(bestPointClosure);
   }
   else
   {
      std::vector<LpiRunwayClosure> runwayClosures;
      LpcWhatIfClosure::ConvertIO2Lpi(in.nonAvailabilityRUNW, runwayClosures);
      out.setRunwayClosures(runwayClosures);
   }
}


void LpcWhatIfClosure::ConvertIO2Lpi(const IOWhatIF::BestPointClosure & in,
                                     LpiBestPointClosure & out)
{
   boost::posix_time::ptime startup = LctimVirtualClock::Get().getStartupTime();
   boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();
   int minutesSubInterval = LpdbDataBase::Get().getGlobalParameters().getTimeParameters().getMinutesSubinterval();

   unsigned int min= startup.time_of_day().minutes();
   unsigned int sec= startup.time_of_day().seconds();
   unsigned int base_min= min % minutesSubInterval;

   //To Detect day change in start time
   boost::posix_time::ptime timeLineInit = startup - minutes(base_min) - seconds(sec);

   std::string idRunway(in.runway, IOConst::RWY_SIZE);
   boost::algorithm::trim(idRunway);

   string startTime(in.startTime, IOConst::TIME_SIZE);
   boost::algorithm::trim(startTime);

   boost::posix_time::ptime startDate;
   LctimTimeUtils::getFromTodayHour(startTime, startup, startDate);

   //Detect day change
   if (startDate < timeLineInit)
   {
      LctimTimeUtils::getFromTomorrowHour(startTime, startup, startDate);
   }

   string endTime(in.endTime, IOConst::TIME_SIZE);
   boost::algorithm::trim(endTime);

   boost::posix_time::ptime endDate;
   LctimTimeUtils::getFromTodayHour(endTime, now, endDate);

   if (endDate < startDate)
   {
      LctimTimeUtils::getFromTomorrowHour(endTime, now, endDate);
   }

   LpiClosureReason::LpiEnum reason;
   LpcClosureReason::convertIO2LpiClosureReason(in.reason, reason);

   LpiRunwayClosure rwyClosureInterface(idRunway, startDate, endDate, reason);
   out.setClosure(rwyClosureInterface);

   out.setDuration(static_cast<unsigned int>(in.period));

   out.setMinutesSubInterval(minutesSubInterval);
}


void LpcWhatIfClosure::ConvertLpi2IO(const LpiRunwayClosure & in,
                                     IOCapacityReductions::RunwayNonPeriod & out)
{
   std::string startTime = LctimTimeUtils::formatTime(in.getStartTime());
   LcuStringArrayConvUtils::String2Array<IOConst::DATE_SIZE>(startTime, out.startTime);

   std::string endTime = LctimTimeUtils::formatTime(in.getEndTime());
   LcuStringArrayConvUtils::String2Array<IOConst::DATE_SIZE>(endTime, out.endTime);

   LcuStringArrayConvUtils::String2Array<IOConst::RWY_SIZE>(in.getRunwayId(), out.runway);

   LpcClosureReason::convertLpi2IOClosureReason(in.getReason(), out.reason);
}
