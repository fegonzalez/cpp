/*
 * LpcManualEditionEvtConsumer.h
 *
 *  Created on: 16/09/2014
 */

#include <string>

#include "LpcManualEditionEvtConsumer.h"
#include <IOWhatIF.h>
#include <LpiManualEditionEvt.h>
#include "LpcManualEdition.h"
#include <LpdComponent.h>


void LpcManualEditionEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOWhatIFEvents::ManualEditionEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOWhatIFEvents::ManualEditionEventSubscriber &subscriber =
             iBG::IOWhatIFEvents::ManualEditionEventCreateSubscriber(sid, sprofile);

   subscriber.addListener(this);
}


void LpcManualEditionEvtConsumer::on_data_available(
                        iBG::IOWhatIFEvents::ManualEditionEventSubscriber & sub)
{
   iBG::IOWhatIFEvents::ManualEditionEventSubscriber::DataList dl;

   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOWhatIFEvents::ManualEditionEventSubscriber::DataList::iterator dit
                                                               = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {

      if(iit->isValid())
      {
         //Obtain data
         IOWhatIF::ManualEdition manualSchedule;
         memset(&manualSchedule, 0, sizeof(IOWhatIF::ManualEdition));
         manualSchedule = dit->manualEditionData;

         //Internal type conversion
         LpiAlternativeSchedule lpiManualSchedule;
         LpcManualEdition::convertIO2Lpi(manualSchedule, lpiManualSchedule);

         //Event
         LpiManualEditionEvt event;
         event.setManualSchedule(lpiManualSchedule);

         LpdComponent::Get().consume(event);
      }
   }
}

