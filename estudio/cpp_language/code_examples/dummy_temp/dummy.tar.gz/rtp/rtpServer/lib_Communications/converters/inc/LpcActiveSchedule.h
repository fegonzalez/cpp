/*
 * LpcActiveSchedule.h
 *
 *  Created on: 16/07/2014
 *      Author: gpfernandez
 */

#ifndef LPCACTIVESCHEDULE_H_
#define LPCACTIVESCHEDULE_H_

#include <IOScheduleActivation.h>
#include <LpiActiveSchedule.h>

class LpcActiveSchedule
{
   public:
      static void convertLpi2IOActiveSchedule (const LpiActiveSchedule &in,
                                               IOScheduleActivation::UpdateScheduleActivation &out);

      static void generateTimestamp (IOTim::OptionalTimeU & out);
};


#endif /* LPCACTIVESCHEDULE_H_ */
