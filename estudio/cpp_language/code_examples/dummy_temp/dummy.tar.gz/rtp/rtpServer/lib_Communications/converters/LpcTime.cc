/*
 * LpcTime.cc
 *
 */

#include "LpcTime.h"
#include <LcuStringArrayConvUtils.h>

#include <ctime>


void LpcTime::convertTimesSIdl2Time (const IOTim::TimeS &inTimeS, LpiTime &out)
{
   out = inTimeS;
}

void LpcTime::convertOptTimeIdl2Time (const IOTim::OptionalTimeU &inOptionalTimeU, LpiTime &out)
{
   if (inOptionalTimeU._d == true)
   {
       out = inOptionalTimeU._u.value;
   }
   else
   {
       out = 0;
   }
}


/*void LxcTime::convert2FullDateAndDaySIdl (const LxiTime &in,
                                          IOTim::FullDateAndDayS &out)
{
    time_t tim = in;
    tm *time_tm = gmtime (&tim);

    out.day.day = time_tm->tm_mday;
    out.day.month = time_tm->tm_mon;
    out.day.year = time_tm->tm_year;

    out.hour.hh = time_tm->tm_hour;
    out.hour.mm = time_tm->tm_min;

}*/

void LpcTime::convertTime2TimesSIdl (const LpiTime &inTimeS, IOTim::TimeS &out)
{
    out = inTimeS;
}

void LpcTime::convertTime2OptTimeIdl (const LpiTime &inOptionalTimeU,
                                      IOTim::OptionalTimeU &out)
{
    if (inOptionalTimeU != 0)
    {
        out._u.value = inOptionalTimeU;
        out._d = true;
    }
    else
    {
        out._d = false;
    }
}
