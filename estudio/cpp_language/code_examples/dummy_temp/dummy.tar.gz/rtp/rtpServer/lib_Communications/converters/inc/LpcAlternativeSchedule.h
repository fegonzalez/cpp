/*
 * LpcAlternativeSchedule.h
 *
 * Created on: 18/09/2014
 * Author:
 *
 */

#ifndef __LPC_ALTERNATIVE_SCHEDULE_H__
#define __LPC_ALTERNATIVE_SCHEDULE_H__

#include <IOWhatIF.h>
#include <LpiAlternativeSchedule.h>

class LpcAlternativeSchedule
{
   public:
      static void convertLpi2IOlternativeSchedule (const LpiAlternativeSchedule &in,
                                                   IOWhatIF::AlternativeSchedule &out);

};


#endif /* __LPC_ALTERNATIVE_SCHEDULE_H__ */
