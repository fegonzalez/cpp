
#include <LpcOptimalScheduleEvtPublisher.h>

#include <LcuStringArrayConvUtils.h>

#include <LpiSchedule.h>

#include <LpcOptimalSchedule.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <boost/lexical_cast.hpp>

#include <iostream>

#include <IOMeteoInfo.h>


void LpcOptimalScheduleEvtPublisher::init(void)
{
    iB::PublisherId pid("IOOptimalScheduleEvents::OptimalScheduleEvent");

    iB::PublicationProfile pprofile;
    
    _publisher = &iBG::IOOptimalScheduleEvents::CreateOptimalScheduleEventCreatePublisher(
                                                                                    pid,
                                                                                    pprofile);
    LpdComponent::Get().delegatePublisher(*this);
}


void LpcOptimalScheduleEvtPublisher::publish(const LpiOptimalScheduleEvt &data)
{
   IOOptimalScheduleEvents::CreateOptimalScheduleEvent ddsSeqEvt;
   memset(&ddsSeqEvt, 0, sizeof(IOOptimalScheduleEvents::CreateOptimalScheduleEvent));
   IOOptimalScheduleEvents::CreateOptimalScheduleEventTypeSupport::initialize_data(&ddsSeqEvt);

   IOSchedule::Schedule out;
   memset(&out, 0, sizeof(IOSchedule::Schedule));

   LpcOptimalSchedule::convert2OptimalSchedule(data.getSchedule(), out);

   ddsSeqEvt.optimalScheduled = out;
   _publisher->push(ddsSeqEvt);

   IOOptimalScheduleEvents::CreateOptimalScheduleEventTypeSupport::finalize_data(&ddsSeqEvt);

   LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED OPTIMAL SCHEDULE]" << std::endl;
}




