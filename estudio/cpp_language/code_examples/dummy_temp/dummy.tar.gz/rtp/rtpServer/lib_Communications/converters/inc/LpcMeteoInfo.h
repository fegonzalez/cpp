/*
 * LpcMeteoInfo.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez
 */

#ifndef LPC_METEO_INFO_H_
#define LPC_METEO_INFO_H_

#include <IOMeteoInfo.h>
#include <IOUpdateMeteoInfo.h>
#include <LpiMeteoInfo.h>


class LpcMeteoInfo
{
 public:

  // Server consumer: IDL's IOMeteoInfo::Meteo msg. => memory "DB" LpiCreateMeteo
  static void convert2Meteo(const IOMeteoInfo::Meteo &in, LpiCreateMeteo &out);

  // Server publisher: memory "DB" => IDL's IOUpdateMeteoInfo::Meteo msg
  static void convert2Meteo(const LpiUpdateMeteo &in, IOUpdateMeteoInfo::Meteo &output);

  // HMI consumer: IDL's IOUpdateMeteoInfo::Meteo msg. => memory "DB"
  static void convert2Meteo(const IOUpdateMeteoInfo::Meteo &in, LpiUpdateMeteo &out);

 private:

};


#endif /* LPC_METEO_INFO_H_ */
