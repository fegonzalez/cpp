
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/optional/optional.hpp>
#include <boost/foreach.hpp>

#include <IOConstant.h>
#include <LpiOptimizationCriteria.h>

#include "LpcOptimizationCriteria.h"
#include "LpdbDataBase.h"

#include <LctimVirtualClock.h>

using std::string;
using std::vector;


void LpcOptimizationCriteria::convertIO2Lpi(const IOWhatIF::OptimizationCriteria &in,
                                            LpiOptimizationCriteria &out)
{
   out.setId(static_cast<int>(in.id));

   string name(in.name, IOConst::WHAT_IF_NAME_SIZE);
   boost::algorithm::trim(name);
   out.setName(name);

   out.setDcbWeight(static_cast<double>(in.weightDCB));
   out.setSuitabilityWeight(static_cast<double>(in.weightStability));
   out.setRsPreferenceWeight(static_cast<double>(in.weightRB));

   out.setAvoidAutomaticDeletion(static_cast<bool>(in.avoidAutomaticDeletion));

   //Construct timeline with interval ponderations

   out.init(LpdbDataBase::Get().getGlobalParameters().getTimeParameters(),
            LpdbDataBase::Get().getTimeLineBase());

   for (int i = 0; i < in.prioritySequence.length(); i++)
   {
      IOWhatIF::ArrDepPriority element = in.prioritySequence.get_at(i);

      float arrivals_priority = static_cast<float>(element.arrPriority);
      float departures_priority = static_cast<float>(element.depPriority);

      LpiOptimizationCriteriaTimedData::CriteriaType ponderation_type = LpiOptimizationCriteriaTimedData::E_MANUAL;

      string startTime(element.startTime, IOConst::TIME_SIZE);
      boost::algorithm::trim_right(startTime);

      string endTime(element.endTime, IOConst::TIME_SIZE);
      boost::algorithm::trim_right(endTime);

      TimeLine<LpiOptimizationCriteriaTimedData> timeline = out.getTimeLine();

      boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();

      boost::posix_time::ptime start_time;
      LctimTimeUtils::getFromTodayHour(startTime, now, start_time);

      boost::optional<string> interval_id = timeline.getInterval(start_time);
      if (!interval_id)
      {
         LctimTimeUtils::getFromTomorrowHour(startTime, now, start_time);
      }

      boost::posix_time::ptime end_time;
      LctimTimeUtils::getFromTodayHour(endTime, now, end_time);

      interval_id = timeline.getInterval(end_time);
      if (!interval_id)
      {
         LctimTimeUtils::getFromTomorrowHour(endTime, now, end_time);
      }

      vector<string> affected_intervals = timeline.getIntervalsInRange(start_time, end_time);


      BOOST_FOREACH(string interval, affected_intervals)
      {
         if (out.has_data(interval))
         {
            out[interval] = LpiOptimizationCriteriaTimedData(arrivals_priority,
                                                             departures_priority,
                                                             ponderation_type);
         }
      }
   }
}
