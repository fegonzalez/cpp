/*
 * LxcTime.h
 *
 */

#ifndef LPCTIME_H_
#define LPCTIME_H_

#include <LpiTime.h>
#include <IOTim.h>

class LpcTime
{
public:
   static void convertTimesSIdl2Time (const IOTim::TimeS &inTimeS, LpiTime &out);

   static void convertOptTimeIdl2Time (const IOTim::OptionalTimeU &inOptionalTimeU,
                                       LpiTime &out);

   /*static void convert2FullDateAndDaySIdl (const LxiTime &in,
                                           IOTim::FullDateAndDayS &out);*/

   static void convertTime2TimesSIdl (const LpiTime &inTimeS, IOTim::TimeS &out);

   static void convertTime2OptTimeIdl (const LpiTime &inOptionalTimeU,
                                       IOTim::OptionalTimeU &out);

};

#endif /* LPCTIME_H_ */
