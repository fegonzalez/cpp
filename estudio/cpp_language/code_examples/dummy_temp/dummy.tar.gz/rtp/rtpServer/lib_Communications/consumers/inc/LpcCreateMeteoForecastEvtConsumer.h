/*
 * LpcCreateMeteoForecastEvtConsumer.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez
 */

#ifndef LPCCREATEMETEOFORECASTEVTCONSUMER_H_
#define LPCCREATEMETEOFORECASTEVTCONSUMER_H_

#include <IOMeteoInfoEventsiBContract.h>
#include <LpiMeteoInfo.h>


class LpcCreateMeteoForecastEvtConsumer: public iBG::IOMeteoInfoEvents::CreateMeteoForecastEventListSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IOMeteoInfoEvents::CreateMeteoForecastEventListSubscriber &sub);

private:
   LpiCreateMeteo handle_one_meteo_data(const IOMeteoInfo::Meteo &next_meteo_data);

};



#endif /* LPCCREATEMETEOINFOEVTCONSUMER_H_ */
