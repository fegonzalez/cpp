/*
 * LpcDefaultScheduleEvtPublisher.cc
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#include <LpcDefaultScheduleEvtPublisher.h>
#include <LcuStringArrayConvUtils.h>

#include <LpcScheduleRTP.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <boost/lexical_cast.hpp>

#include <iostream>


void LpcDefaultScheduleEvtPublisher::init(void)
{
    iB::PublisherId pid("IOScheduleRTPEvents::ScheduleActivation");

    iB::PublicationProfile pprofile;

    _publisher = &iBG::IOScheduleRTPEvents::ScheduleActivationCreatePublisher(pid, pprofile);
    LpdComponent::Get().delegatePublisher(*this);
}

void LpcDefaultScheduleEvtPublisher::publish(const LpiDefaultScheduleEvt &evt)
{
	LclogStream::instance(LclogConfig::E_RTP).notify()
	    << "[----- RTP-DefaultSchedule-PUBLISHER:: PUBLISHING DEFAULT SCHEDULE INFORMATION TO HMI]" << std::endl;


	IOScheduleRTPEvents::ScheduleActivation data;
	IOScheduleRTPEvents::ScheduleActivationTypeSupport::initialize_data(&data);

	IOScheduleRTP::Schedule out_data;
	LpcScheduleRTP::convert2DefaultSchedule(evt.getDefaultSchedule(), out_data);
	data.schedule = out_data;


	DDS_ReturnCode_t rc = _publisher->push(data);
	if(rc != DDS_RETCODE_OK)
	{
	  const std::string ERR_PUSH_MSG = {"imasblue could not add the IOScheduleRTPEvents::ScheduleActivation to the send queue."};
	  std::cerr << "\n" << ERR_PUSH_MSG
		<< " : File: " << __FILE__    << " ; fn: " << __func__
		<< " ; line: " << __LINE__;
	  LclogStream::instance(LclogConfig::E_RTP).error()
	<< ERR_PUSH_MSG
	<< " : File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
	}

	::IOScheduleRTPEvents::ScheduleActivationTypeSupport::finalize_data(&data);

	LclogStream::instance(LclogConfig::E_RTP).notify()
	      << "[PUBLISHING DEFAULT_SCHEDULE INFO TO HMI ----]" << std::endl;
}
