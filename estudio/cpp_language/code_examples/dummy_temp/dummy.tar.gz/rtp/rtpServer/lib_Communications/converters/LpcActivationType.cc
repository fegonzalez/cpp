// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):     icima
 Created:   10/4/2015 11:56:10 2015
 Release:   $Revision$
 Modified:  $Date$
 Path:      $Source$
 */
//---------------------------------------------------------------------------
#include "LpcActivationType.h"


IOCommonTypes::ActivationType LpcActivationType::LpiToIOType(LpiActivationType::ActivationType value)
{
    switch(value)
    {
        case LpiActivationType::E_PREFERENTIAL:
            return IOCommonTypes::E_PREFERENTIAL;
        case LpiActivationType::E_OPTIMAL:
            return IOCommonTypes::E_OPTIMAL;
        case LpiActivationType::E_WHAT_IF_1:
            return IOCommonTypes::E_WHAT_IF_1;
        case LpiActivationType::E_WHAT_IF_2:
            return IOCommonTypes::E_WHAT_IF_2;
        case LpiActivationType::E_WHAT_IF_3_ACTIVE:
            return IOCommonTypes::E_WHAT_IF_3_ACTIVE;
        case LpiActivationType::E_WHAT_IF_3_NEW_SOLUTION:
            return IOCommonTypes::E_WHAT_IF_3_NEW_SOLUTION;
        case LpiActivationType::E_WHAT_IF_3_BEST_POINT:
            return IOCommonTypes::E_WHAT_IF_3_BEST_POINT;
        case LpiActivationType::E_WHAT_IF_3_BEST_POINT_FOR_ACTIVE:
            return IOCommonTypes::E_WHAT_IF_3_BEST_POINT_FOR_ACTIVE;
        default:
            return IOCommonTypes::E_PREFERENTIAL;

    }
}

void LpcActivationType::convertIOToLpiActivationType(const IOCommonTypes::ActivationType &in,
                                                 LpiActivationType::ActivationType& out)
{
    switch(in)
    {
        case IOCommonTypes::E_PREFERENTIAL:
            out =  LpiActivationType::E_PREFERENTIAL;
            break;
        case IOCommonTypes::E_OPTIMAL:
            out =  LpiActivationType::E_OPTIMAL;
            break;
        case IOCommonTypes::E_WHAT_IF_1:
            out =  LpiActivationType::E_WHAT_IF_1;
            break;
        case IOCommonTypes::E_WHAT_IF_2:
            out =  LpiActivationType::E_WHAT_IF_2;
            break;
        case IOCommonTypes::E_WHAT_IF_3_ACTIVE:
            out =  LpiActivationType::E_WHAT_IF_3_ACTIVE;
            break;
        case IOCommonTypes::E_WHAT_IF_3_NEW_SOLUTION:
            out =  LpiActivationType::E_WHAT_IF_3_NEW_SOLUTION;
            break;
        case IOCommonTypes::E_WHAT_IF_3_BEST_POINT:
            out = LpiActivationType::E_WHAT_IF_3_BEST_POINT;
            break;
        case IOCommonTypes::E_WHAT_IF_3_BEST_POINT_FOR_ACTIVE:
            out = LpiActivationType::E_WHAT_IF_3_BEST_POINT_FOR_ACTIVE;
            break;
        default:
            out =  LpiActivationType::E_PREFERENTIAL;
            break;
    }
}
