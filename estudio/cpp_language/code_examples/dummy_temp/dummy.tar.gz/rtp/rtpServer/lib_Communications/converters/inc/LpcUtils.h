
#ifndef LPCUTILS_H_
#define LPCUTILS_H_

//#include <string>
#include <LclogStream.h>
#include <string.h>


class LpcUtils
{
public:
   //template conversion from char arrays without null ending to string
   template< int N >
   static void Array2String(const char (&array)[N], std::string &str);

   template< int N >
   static void String2Array(const std::string &str, char (&array)[N]);
};

template< int N >
void LpcUtils::Array2String(const char (&array)[N], std::string &str)
{
   str.assign(array, 0, N);
}

template< int N >
void LpcUtils::String2Array(const std::string &str, char (&array)[N])
{
   memset(array, ' ', N);

   if(str.size() <= N)
   {
      memcpy(array, str.c_str(), str.size());
   }
   else
   {
     /*rlog_ptr->error() << "LpcUtils::String2Array\n"
		       << "ERROR: Bad string size: [" << str << "] != " << N
		       << "characters\n"
		       << "Truncating to -> " << str.substr(0, N) <<std::endl;*/

      memcpy(array, str.c_str(), N);
   }
}



#endif /* LPCUTILS_H_ */
