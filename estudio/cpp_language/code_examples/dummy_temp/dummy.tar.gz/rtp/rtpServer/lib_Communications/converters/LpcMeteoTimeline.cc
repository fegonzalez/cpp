/*
 * LpcMeteoTimeline.cc
 *
 *  Created on: 19/03/2015
 *      Author: mbegega
 */

#include "LpcMeteoTimeline.h"

#include <LpcUtils.h>
#include <LpcCommon.h>
#include <LpiMeteoTimeline.h>
#include <IOUpdateMeteoInfo.h>
#include <IOMeteoTimeline.h>
#include <LpiMaxILSCategory.h>

#include <boost/optional.hpp>


#include <LclogStream.h>


void LpcMeteoTimeline::convert2IO(const LpiMeteoTimeline & in, IOMeteoTimeline::MeteoTimeLine & out)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

   unsigned int numberOfIntervals = in.size(); //in.getAllScheduleIntervals().size();

   out.ensure_length(numberOfIntervals, numberOfIntervals);

   for (unsigned int i = 0; i < numberOfIntervals; ++i)
   {
      IOMeteoTimeline::MeteoInfo meteoInfoIO;
      IOMeteoTimeline::MeteoTimeIntervalData meteoIntervalIO;

      LpiMeteoInterval meteoIntervalInterface = in[i];
      LpiMeteoIntervalData meteoInfoInterface = meteoIntervalInterface.getData();

      LpcCommon::optionalDouble2IO(meteoInfoInterface.getHorizontalVisibility(), meteoInfoIO.horizontalVisibility);
      LpcUtils::String2Array(meteoInfoInterface.getWetness(), meteoInfoIO.wetness);

      string ilsCategory= LpiMaxILSCategory::getEnumAsStringToHmi(meteoInfoInterface.getILSCategory());

      LpcUtils::String2Array(ilsCategory, meteoInfoIO.ilsCategory);
      LpcCommon::optionalBool2IO(meteoInfoInterface.getLVPActivation(), meteoInfoIO.lvpActivation);
      LpcCommon::optionalBool2IO(meteoInfoInterface.getDeicingRequired(), meteoInfoIO.deicingRequired);
      LpcCommon::optionalDouble2IO(meteoInfoInterface.getCrosswind(), meteoInfoIO.crosswind);
      LpcCommon::optionalDouble2IO(meteoInfoInterface.getTailwind(), meteoInfoIO.tailwind);


      ///@warning IDL types error: "int" & "float";  required "unsigned int" & "double"

      //LpcCommon::OptionalInt2IOInteger(meteoInfoInterface.getWindSpeed(), meteoInfoIO.windSpeed);
      LpcCommon::OptionalUnsignedInt2IOInteger(meteoInfoInterface.getWindSpeed(), meteoInfoIO.windSpeed);

      //LpcCommon::optionalInt2IO(meteoInfoInterface.getWindDirection(), meteoInfoIO.windDirection);
      LpcCommon::OptionalUnsignedInt2IOInteger(meteoInfoInterface.getWindDirection(), meteoInfoIO.windDirection);

      LpcUtils::String2Array(meteoIntervalInterface.getName(), meteoIntervalIO.intervalName);
      LpcUtils::String2Array(meteoIntervalInterface.getBeginTime(), meteoIntervalIO.startTimeAndDate);
      LpcUtils::String2Array(meteoIntervalInterface.getEndTime(), meteoIntervalIO.endTimeAndDate);

      meteoIntervalIO.meteoInfo = meteoInfoIO;

      out.set_at(i, meteoIntervalIO);
   }

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
}

//-----------------------------------------------------------------------------

void LpcMeteoTimeline::convert(const IOMeteoTimeline::MeteoTimeLine & in,
			       LpiMeteoTimeline & out)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

    for (int i = 0; i < in.length(); ++i) // LpiMeteoInterval
    {
      std::string intervalName;
      LpcUtils::Array2String(in.get_at(i).intervalName, intervalName);
      std::string startTimeAndDate;
      LpcUtils::Array2String(in.get_at(i).startTimeAndDate,startTimeAndDate);
      std::string endTimeAndDate;
      LpcUtils::Array2String(in.get_at(i).endTimeAndDate,endTimeAndDate);


      // LpiMeteoInterval::LpiMeteoIntervalData 

      boost::optional<double> horizontalVisibility;
      LpcCommon::IOOptionalDouble2OptionalDouble(in.get_at(i).meteoInfo.horizontalVisibility, horizontalVisibility);
      
      std::string wetness;
      LpcUtils::Array2String(in.get_at(i).meteoInfo.wetness,wetness);
      
      std::string ilsCategory;
      LpcUtils::Array2String(in.get_at(i).meteoInfo.ilsCategory,ilsCategory);

      boost::optional<bool> lvpActivation;
      LpcCommon::IOOptionalBool2OptionalBool(in.get_at(i).meteoInfo.lvpActivation, lvpActivation);

      boost::optional<bool> deicingRequired;
      LpcCommon::IOOptionalBool2OptionalBool(in.get_at(i).meteoInfo.deicingRequired, deicingRequired);

      boost::optional<double> crosswind;
      LpcCommon::IOOptionalDouble2OptionalDouble(in.get_at(i).meteoInfo.crosswind, crosswind);

      boost::optional<double> tailwind;
      LpcCommon::IOOptionalDouble2OptionalDouble(in.get_at(i).meteoInfo.tailwind, tailwind);
      
      boost::optional<unsigned int> windSpeed;
      LpcCommon::IOOptionalInt2OptionalUnsignedInt(in.get_at(i).meteoInfo.windSpeed, windSpeed);
      
      boost::optional<unsigned int> windDirection;
      LpcCommon::IOOptionalInt2OptionalUnsignedInt(in.get_at(i).meteoInfo.windDirection, windDirection);


      LpiMeteoIntervalData meteoIntervalData(horizontalVisibility,
				wetness,
				ilsCategory,
				lvpActivation,
				deicingRequired,
				crosswind,
				tailwind,
				windSpeed,
				windDirection);

      LpiMeteoInterval meteoInterval(intervalName,
				     startTimeAndDate,
				     endTimeAndDate,
				     meteoIntervalData);


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
	<< " ;  i = " << i << " "
	<< " ; out.size = " << out.size() << " "
	<< " ; in.length() = " << in.length() << " "
    << std::endl;
#endif

      //out[i] = meteoInterval; //error: out.size() is zero here
      out.push_back(meteoInterval);

    }  

}

//-----------------------------------------------------------------------------

