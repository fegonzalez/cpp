/*
 * LpcCommunicationsManager.h
 *
 */

#ifndef LPCCOMMUNICATIONSMANAGER_H_
#define LPCCOMMUNICATIONSMANAGER_H_

#include <LpcCreateDemandEvtConsumer.h>
#include <LpcCreateMeteoForecastEvtConsumer.h>
#include <LpcCreateMeteoNowcastEvtConsumer.h>
#include <LpcDemandEvtPublisher.h>
#include <LpcMeteoForecastEvtPublisher.h>
#include <LpcMeteoNowcastEvtPublisher.h>
#include <LclogStream.h>
#include <boost/thread.hpp>
#include "LpcActiveScheduleRTPEvtPublisher.h"
#include "LpcOptimalScheduleRTPEvtPublisher.h"

class LpcCommunicationsManager
{
public:

   static LpcCommunicationsManager & Get(void);
   void initialise(void);
   void waitForEvents (void);

private:

   LpcCommunicationsManager ();

   boost::shared_ptr<LpcCreateDemandEvtConsumer>           _createDemandEvtConsumer;
   boost::shared_ptr<LpcCreateMeteoForecastEvtConsumer>    _createMeteoForecastEvtConsumer;
   boost::shared_ptr<LpcCreateMeteoNowcastEvtConsumer>     _createMeteoNowcastEvtConsumer;
   boost::shared_ptr<LpcDemandEvtPublisher>                _demandEvtPublisher;
   boost::shared_ptr<LpcMeteoForecastEvtPublisher>         _meteoForecastEvtPublisher;
   boost::shared_ptr<LpcMeteoNowcastEvtPublisher>          _meteoNowcastEvtPublisher;

   boost::shared_ptr<LpcActiveScheduleRTPEvtPublisher> 	   _activeScheduleRTPEvtPublisher;
   boost::shared_ptr<LpcOptimalScheduleRTPEvtPublisher>    _optimalScheduleRTPEvtPublisher;

   //boost::shared_ptr<LpschDefaultSchedule>  _defaultSchedule;
//   boost::shared_ptr<LpcScheduleActivationEvtConsumer>     _scheduleActivationEvtConsumer;
//   boost::shared_ptr<LpcOptimalScheduleEvtPublisher>       _optimalScheduleEvtPublisher;
//   boost::shared_ptr<LpcOptimalCriteriaEvtPublisher>       _optimalCriteriaEvtPublisher;
//   boost::shared_ptr<LpcOptimizationCriteriaEvtConsumer>   _optimizationCriteriaEvtConsumer;
//   boost::shared_ptr<LpcCapacityReductionsEvtConsumer>     _capacityReductionsEvtConsumer;
//   boost::shared_ptr<LpcActiveScheduleEvtPublisher>        _activeScheduleEvtPublisher;
//   boost::shared_ptr<LpcManualEditionEvtConsumer>          _manualEditionEvtConsumer;
//   boost::shared_ptr<LpcScheduleDeleteEvtConsumer>         _scheduleDeleteEvtConsumer;
//   boost::shared_ptr<LpcAlternativeScheduleEvtPublisher>   _alternativeSchedulePublisher;
//   boost::shared_ptr<LpcSchedulesComparisonEvtConsumer>    _schedulesComparisonEvtConsumer;
//   boost::shared_ptr<LpcSchedulesComparisonResponseEvtPublisher> _schedulesComparisonResponseEvtPublisher;
//   boost::shared_ptr<LpcWhatIfRunwayClosureEvtConsumer>    _whatIfRunwayClosureEvtConsumer;
//   boost::shared_ptr<LpcAutomaticDeletionEvtPublisher>     _automaticDeletionEvtPublisher;
};

#endif /* LPCCOMMUNICATIONSMANAGER_H_ */
