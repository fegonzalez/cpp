/*
 * LpcDefaultScheduleEvtPublisher.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPCACTIVESCHEDULEEVTPUBLISHER_H_
#define LPCACTIVESCHEDULEEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOTim.h>

#include <IOScheduleRTPEventsiBContract.h>
#include <IOScheduleRTPEvents.h>

class LpcActiveScheduleRTPEvtPublisher : public LpiIActiveScheduleRTPEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiActiveScheduleRTPEvt &data);

private:

   iBG::IOScheduleRTPEvents::ScheduleActivationPublisher *_publisher;
};


#endif /* LPCDEFAULTSCHEDULEEVTPUBLISHER_H_ */
