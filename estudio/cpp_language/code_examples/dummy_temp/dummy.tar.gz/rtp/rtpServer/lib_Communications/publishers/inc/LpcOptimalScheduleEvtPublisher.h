
#ifndef LPCOPTIMALSCHEDULEEVTPUBLISHER_H_
#define LPCOPTIMALSCHEDULEEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOOptimalScheduleEventsiBContract.h>
#include <IOOptimalScheduleEvents.h>
#include <IOTim.h>

#include <IOMeteoInfoEventsiBContract.h>
#include <IOMeteoInfoEvents.h>

class LpcOptimalScheduleEvtPublisher : public LpiIOptimalScheduleEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiOptimalScheduleEvt &data);

private:

   iBG::IOOptimalScheduleEvents::CreateOptimalScheduleEventPublisher *_publisher;
  //iBG::IOMeteoInfoEvents::CreateMeteoInfoEventPublisher *_publisher;

   /*
   std::string sequenceResume2String(const IOSeqEvents::UpdateSequenceEvent &);

   std::string timeS2StringHH_MM_SS(const IOTim::TimeS &);
   */
};



#endif /* LPCOPTIMALSCHEDULEEVTPUBLISHER_H_ */
