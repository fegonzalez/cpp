
#include <string>
#include <boost/algorithm/string/trim.hpp>


#include <IOConstant.h>
#include <LpiSchedulesComparison.h>
#include "LpcSchedulesComparison.h"
#include <LcuStringArrayConvUtils.h>
#include "LpcKpis.h"

using std::string;

void LpcSchedulesComparison::convertIO2Lpi(const IOComparisonSchedules::ComparisonSchedules &in,
                                           LpiSchedulesComparison & out)
{
   out.setLeftOperandId(static_cast<int>(in.r_sch_id_1));

   string leftOperandName(in.r_name_1, IOConst::WHAT_IF_NAME_SIZE);
   boost::algorithm::trim(leftOperandName);
   out.setLeftOperandName(leftOperandName);

   out.setRightOperandId(static_cast<int>(in.r_sch_id_2));

   string rightOperandName(in.r_name_2, IOConst::WHAT_IF_NAME_SIZE);
   boost::algorithm::trim(rightOperandName);
   out.setRightOperandName(rightOperandName);
}


void LpcSchedulesComparison::convertLpi2IO(const LpiSchedulesComparisonResponse & in,
                                           IOComparisonSchedules::ComparisonSchedulesCalculate & out)
{
   out.r_sch_id_1 = in.getLeftOperandId();
   LcuStringArrayConvUtils::String2Array<IOConst::WHAT_IF_NAME_SIZE>(in.getLeftOperandName(), out.r_name_1);

   out.r_sch_id_2 = in.getRightOperandId();
   LcuStringArrayConvUtils::String2Array<IOConst::WHAT_IF_NAME_SIZE>(in.getRightOperandName(), out.r_name_2);

   LpcComparativeKpis::convertLpi2IOComparativeKpis (in.getKpis(), out.r_comparasionKpis);
}
