/*
 * LpcScheduleActivation.cc
 *
 *  Created on: 14/07/2014
 *      Author: gpfernandez
 */

#include <LpiScheduleActivation.h>
#include "LpcScheduleActivation.h"

void LpcScheduleActivation::convertIO2Lpi(const IOScheduleActivation::ScheduleActivation &in,
                                            LpiScheduleActivation &out)
{
   out.setScheduleId(in.sch_id);
}
