
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/algorithm/string/trim.hpp>

#include <IOConstant.h>
#include <LpiSchedule.h>

#include "LpcManualEdition.h"

using std::string;
using std::vector;


void LpcManualEdition::convertIO2Lpi(const IOWhatIF::ManualEdition &in,
                                     LpiAlternativeSchedule & out)
{
   out.setId(static_cast<int>(in.id));

   string name(in.name, IOConst::WHAT_IF_NAME_SIZE);
   boost::algorithm::trim(name);
   out.setName(name);
   out.setAvoidAutomaticDeletion(static_cast<bool>(in.avoidAutomaticDeletion));

   vector<LpiTimeIntervalData> schedule;

   for (int i = 0; i < in.scheduled.length(); i++)
   {
      IOSchedule::TimeIntervalData element = in.scheduled.get_at(i);

      string interval_name      (element.intervalName, IOConst::INTERVAL_NAME);
      string start_time         (element.startTimeAndDate, IOConst::TIME_SIZE);
      string end_time           (element.endTimeAndDate, IOConst::TIME_SIZE);

      string planned_rs         (element.plannedRS.rsName, IOConst::RUNWAY_SYSTEM_SIZE);
      string arrival_runways    (element.plannedRS.runwaysArr, IOConst::RUNWAYS_SIZE);
      string departure_runways  (element.plannedRS.runwaysDep, IOConst::RUNWAYS_SIZE);
      string configuration      (element.plannedRS.configuration, IOConst::CONFIG_SIZE);

      //Remove whitespaces
      boost::algorithm::trim(interval_name);
      boost::algorithm::trim(start_time);
      boost::algorithm::trim(end_time);
      boost::algorithm::trim(planned_rs);
      boost::algorithm::trim(arrival_runways);
      boost::algorithm::trim(departure_runways);
      boost::algorithm::trim(configuration);

      LpiTimeIntervalData interval_data(interval_name, start_time, end_time);
      LpiRS_Scheduled plannedRS(planned_rs, arrival_runways, departure_runways, configuration);
      interval_data.setRSScheduled(plannedRS);

      schedule.push_back(interval_data);
   }

   LpiScheduleTimeLine scheduled_intervals;
   scheduled_intervals.setAllScheduleIntervals(schedule);

   out.setScheduleTimeLine(scheduled_intervals);
}
