/*
 * LpcCreateDemandEvtConsumer.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez
 */

#ifndef LPCREATEDEMANDEVTCONSUMER_H_
#define LPCREATEDEMANDEVTCONSUMER_H_

#include <IODemandEventsiBContract.h>
#include <LclogStream.h>


class LpcCreateDemandEvtConsumer: public iBG::IODemandEvents::CreateDemandEventListSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IODemandEvents::CreateDemandEventListSubscriber &sub);

};



#endif /* LPCREATEDEMANDEVTCONSUMER_H_ */
