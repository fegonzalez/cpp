/*
 * LpcActiveSchedule.cc
 *   Created on: 15/07/2014
 *   Author: gpfernandez
 */

#include "LpiActiveSchedule.h"
#include <LcuStringArrayConvUtils.h>
#include "LpcKpis.h"
#include "LpcActiveSchedule.h"
#include "LpcOptimalSchedule.h"
#include <LctimVirtualClock.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>


void LpcActiveSchedule::convertLpi2IOActiveSchedule(const LpiActiveSchedule &in,
                                                    IOScheduleActivation::UpdateScheduleActivation &out)
{
   LpcOptimalSchedule::convert2OptimalSchedule(static_cast<const LpiSchedule &>(in), out.schedule);

   LcuStringArrayConvUtils::String2Array(in.getActivationTime() , out.schedule.timeAndDate);

   LpcActiveSchedule::generateTimestamp(out.timestamp);
}


void LpcActiveSchedule::generateTimestamp (IOTim::OptionalTimeU & out)
{
   boost::posix_time::ptime epoch(boost::gregorian::date(1970,1,1));
   boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();
                                  //boost::posix_time::second_clock::local_time();

   unsigned long secondsSinceEpoch = (now - epoch).total_seconds();

   out._d = true;
   out._u.value = secondsSinceEpoch;
}
