/*
 * LpcAlternativeSchedule.cc
 *   Created on: 18/09/2014
 *   Author:
*/

#include <boost/algorithm/string/trim.hpp>

#include <IOConstant.h>
#include <LcuStringArrayConvUtils.h>

#include "LpcAlternativeSchedule.h"
#include "LpcOptimalSchedule.h"

void LpcAlternativeSchedule::convertLpi2IOlternativeSchedule (const LpiAlternativeSchedule &in,
                                                              IOWhatIF::AlternativeSchedule &out)
{
   out.id = in.getId();

   LcuStringArrayConvUtils::String2Array<IOConst::WHAT_IF_NAME_SIZE>(in.getName(), out.name);

   LpcOptimalSchedule::convert2OptimalSchedule(static_cast<const LpiSchedule &>(in), out.schedule);
}
