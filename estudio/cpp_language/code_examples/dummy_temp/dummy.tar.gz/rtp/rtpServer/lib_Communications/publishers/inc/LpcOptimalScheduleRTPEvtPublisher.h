/*
 * LpcDefaultScheduleEvtPublisher.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPCOPTIMALSCHEDULEEVTPUBLISHER_H_
#define LPCOPTIMALSCHEDULEEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOTim.h>

#include <IOScheduleRTPEventsiBContract.h>
#include <IOScheduleRTPEvents.h>

class LpcOptimalScheduleRTPEvtPublisher : public LpiIOptimalScheduleRTPEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiOptimalScheduleRTPEvt &data);

private:

   iBG::IOScheduleRTPEvents::OptimalScheduleActivationPublisher *_publisher;
};


#endif /* LPCDEFAULTSCHEDULEEVTPUBLISHER_H_ */
