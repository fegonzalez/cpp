
#ifndef _LPC_SCHEDULES_COMPARISON_RESPONSE_EVTPUBLISHER_H_
#define _LPC_SCHEDULES_COMPARISON_RESPONSE_EVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOComparisonSchedulesEventsiBContract.h>

#include <IOTim.h>


class LpcSchedulesComparisonResponseEvtPublisher : public LpiISchedulesComparisonResponseEvtPublisher
{
   public:

      void init(void);
      virtual void publish(const LpiSchedulesComparisonResponseEvt &data);

   private:

      iBG::IOComparisonSchedulesEvents::ComparisonSchedulesCalculateEventPublisher *_publisher;
};



#endif /* _LPC_SCHEDULES_COMPARISON_RESPONSE_EVTPUBLISHER_H_ */
