
#ifndef LPC2OSTREAM_H_
#define LPC2OSTREAM_H_

#include <iostream>
#include <IOTim.h>


std::ostream & operator<<(std::ostream &,
                          const IOTim::TimeS &);

std::ostream & operator<<(std::ostream &,
                          const IOTim::OptionalTimeU &);







#endif /* LPC2OSTREAM_H_ */
