#include <LpcMeteoForecastEvtPublisher.h>
#include <LcuStringArrayConvUtils.h>

//#include <LpiSchedule.h>

#include <IOUpdateMeteoInfo.h>
#include <IOMeteoInfoEvents.h>
#include <LpcMeteoInfo.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <boost/lexical_cast.hpp>

#include <iostream>


void LpcMeteoForecastEvtPublisher::init(void)
{
    iB::PublisherId pid("IOMeteoInfoEvents::UpdateMeteoForecastEventList");

    iB::PublicationProfile pprofile;
    
    _publisher = &iBG::IOMeteoInfoEvents::UpdateMeteoForecastEventListCreatePublisher(pid, pprofile);
    LpdComponent::Get().delegatePublisher(*this);
}

//------------------------------------------------------------------------------

void LpcMeteoForecastEvtPublisher::publish(const LpiMeteoForecastEvt &evt)
{
  LclogStream::instance(LclogConfig::E_RTP).notify() 
    << "[----- RTP-MeteoForecast-PUBLISHER:: PUBLISHING METEO FORECAST INFORMATION TO HMI]"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;

  ///@warning Data was previously received & stored by the consumer at
  //      " LpcCreateMeteoForecastEvtConsumer::on_data_available()
  //        {  event.setMeteoForecast(meteoForeList); } "
  //      Later it was updated (wetness, ...)
  //      and finally here, it is recovered and sent to the HMI

  // reading the stored data received by the consumer (from the Meteo
  // dummy/connector)
  LpiCreateMeteoList listMeteo = evt.getMeteoForecast(); 

  ::IOMeteoInfoEvents::UpdateMeteoForecastEventList data;
  ::IOMeteoInfoEvents::UpdateMeteoForecastEventListTypeSupport::initialize_data(&data);
  ///@warning ensure_length required: otherwise data.meteoUpdates.length() = 0
  /// and (MeteoSeq_get_reference:!assert index out of bounds) error later
  data.meteoUpdates.ensure_length(listMeteo.size(), listMeteo.size());  

    // for each meteo info in the list of meteo infos:
    // convert from (LpiMeteoInfoList LpiCreateMeteo) to the IDL format
    // (IOUpdateMeteoInfo::Meteo at UpdateMeteoInfo.idl
    for (unsigned int i = 0; i < listMeteo.size(); i++)
    {
      IOUpdateMeteoInfo::Meteo out_data;
      LpcMeteoInfo::convert2Meteo(listMeteo[i], out_data);
      data.meteoUpdates.set_at(i, out_data);
    }


    DDS_ReturnCode_t rc = _publisher->push(data); 
    if(rc != DDS_RETCODE_OK)
    {
      const std::string ERR_PUSH_MSG = {"imasblue could not add the IOMeteoInfoEvents::UpdateMeteoForecastEventList to the send queue."};
      std::cerr << "\n" << ERR_PUSH_MSG
		<< " : File: " << __FILE__    << " ; fn: " << __func__
		<< " ; line: " << __LINE__;
      LclogStream::instance(LclogConfig::E_RTP).error()
	<< ERR_PUSH_MSG
	<< " : File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
    }

    ::IOMeteoInfoEvents::UpdateMeteoForecastEventListTypeSupport::finalize_data(&data);  
}




