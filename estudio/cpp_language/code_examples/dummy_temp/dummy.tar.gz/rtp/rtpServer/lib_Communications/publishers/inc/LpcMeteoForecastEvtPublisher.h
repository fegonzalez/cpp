
#ifndef LPCMETEOFORECASTEVTPUBLISHER_H_
#define LPCMETEOFORECASTEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOTim.h>

#include <IOMeteoInfoEventsiBContract.h>
#include <IOMeteoInfoEvents.h>

class LpcMeteoForecastEvtPublisher : public LpiIMeteoForecastEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiMeteoForecastEvt &evt);

private:

   iBG::IOMeteoInfoEvents::UpdateMeteoForecastEventListPublisher *_publisher;
};



#endif /* LPCMETEOINFOEVTPUBLISHER_H_ */
