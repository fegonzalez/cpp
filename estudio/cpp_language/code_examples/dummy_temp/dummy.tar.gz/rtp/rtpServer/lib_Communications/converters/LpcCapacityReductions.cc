
#include "LpcClosureReason.h"
#include "LpcCapacityReductions.h"
#include <LcuStringArrayConvUtils.h>
#include "LpcADO.h"
#include <LctimTimeUtils.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <LpdComponent.h>
#include <math.h>
#include <LctimVirtualClock.h>


void LpcCapacityReductions::convertIOCapacity2LpiCapacity(const IOCapacityReductions::CapacityReductions &in, LpiCapacityReductions &out)
{
   posix_time::ptime startTimeAndDate;
   posix_time::ptime endTimeAndDate;
   RunwaysNonPeriodsList nonAvailabilityRUNWY;
  
   CapacityReductionsRWYS capacityReductionsRUNW;
   LpiADO    vADO;
    
   capacityReductionsRUNW.clear();
   nonAvailabilityRUNWY.clear();

   boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();

    for(int i=0; i< in.capacityReductionsRUNW.length(); i++)
    {
       //capacityReductionsRUNW
      CapacityReductionsRW capacityRunway;
      std::string startTime;
      startTime.assign(in.capacityReductionsRUNW.get_at(i).startTime,0,5);
      LctimTimeUtils::getFromTodayHour(startTime, now, startTimeAndDate);
      capacityRunway.setstartTimeAndDate(startTimeAndDate);

      std::string endTime;
      endTime.assign(in.capacityReductionsRUNW.get_at(i).endTime,0,5);
      LctimTimeUtils::getFromTodayHour(endTime, now, endTimeAndDate);

      if (endTimeAndDate < startTimeAndDate)
      {
         LctimTimeUtils::getFromTomorrowHour(endTime, now, endTimeAndDate);
      }

      capacityRunway.setendTimeAndDate(endTimeAndDate);

      vADO = LpcAdo::IOADO2LpiADO(in.capacityReductionsRUNW.get_at(i).vectorADO);
      capacityRunway.setvectorADO(vADO);
      std::string id_runway(in.capacityReductionsRUNW.get_at(i).runway,3);
      capacityRunway.setrunway(id_runway);
      capacityReductionsRUNW.push_back(capacityRunway);
    }

    for(int i = 0; i < in.nonAvailabilityRUNW.length(); i++)
    {
       //nonAvailabilityRUNW
      RunwaysNonPeriods nonAvailability;
      std::string startTime;
      startTime.assign(in.nonAvailabilityRUNW.get_at(i).startTime, 0 , 5);
      LctimTimeUtils::getFromTodayHour(startTime, now, startTimeAndDate);
      nonAvailability.setstartTimeAndDate(startTimeAndDate);

      std::string endTime;
      endTime.assign(in.nonAvailabilityRUNW.get_at(i).endTime,0,5);
      LctimTimeUtils::getFromTodayHour(endTime, now, endTimeAndDate);

      if (endTimeAndDate < startTimeAndDate)
      {
         LctimTimeUtils::getFromTomorrowHour(endTime, now, endTimeAndDate);
      }

      nonAvailability.setendTimeAndDate(endTimeAndDate);
      std::string idrunway(in.nonAvailabilityRUNW.get_at(i).runway, 3);
      boost::algorithm::trim(idrunway);
      nonAvailability.setrunway(idrunway);

      LpiClosureReason::LpiEnum reason;
      LpcClosureReason::convertIO2LpiClosureReason(in.nonAvailabilityRUNW.get_at(i).reason, reason);
      nonAvailability.setReason(reason);

      nonAvailabilityRUNWY.push_back(nonAvailability);
     }
    
     out.setcapacityReductionsRUNWY(capacityReductionsRUNW);
     out.setnonAvailabilityRUNWY(nonAvailabilityRUNWY);

}
