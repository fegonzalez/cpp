/*
 * LpcDefaultScheduleEvtPublisher.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPCDEFAULTSCHEDULEEVTPUBLISHER_H_
#define LPCDEFAULTSCHEDULEEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOTim.h>

#include <IOScheduleRTPEventsiBContract.h>
#include <IOScheduleRTPEvents.h>

class LpcDefaultScheduleEvtPublisher : public LpiIDefaultScheduleEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiDefaultScheduleEvt &data);

private:

   iBG::IOScheduleRTPEvents::ScheduleActivationPublisher *_publisher;
};


#endif /* LPCDEFAULTSCHEDULEEVTPUBLISHER_H_ */
