/*
 * LpcCommunicationsManager.cc
 *
 */


#include "LpcCommunicationsManager.h"

void wait()
{
    while (1)
     {
        boost::this_thread::sleep(boost::posix_time::milliseconds(500));
     }
}

LpcCommunicationsManager& LpcCommunicationsManager::Get(void)
{
    static LpcCommunicationsManager manager;
    return manager;
}

void LpcCommunicationsManager::initialise(void)
{
      _createDemandEvtConsumer->init();
      _createMeteoForecastEvtConsumer->init();
      _createMeteoNowcastEvtConsumer->init();
      _demandEvtPublisher->init();
      _meteoForecastEvtPublisher->init();
      _meteoNowcastEvtPublisher->init();

//      _scheduleActivationEvtConsumer->init();
//      _optimalScheduleEvtPublisher->init();
//      _optimalCriteriaEvtPublisher->init();
//      _optimizationCriteriaEvtConsumer->init();
//      _capacityReductionsEvtConsumer->init();
//      _activeScheduleEvtPublisher->init();
//      _manualEditionEvtConsumer->init();
//      _scheduleDeleteEvtConsumer->init();
//      _alternativeSchedulePublisher->init();
//      _schedulesComparisonEvtConsumer->init();
//      _schedulesComparisonResponseEvtPublisher->init();
//      _whatIfRunwayClosureEvtConsumer->init();
//      _automaticDeletionEvtPublisher->init();
}

LpcCommunicationsManager::LpcCommunicationsManager ():
      _createDemandEvtConsumer(new LpcCreateDemandEvtConsumer()),
      _createMeteoForecastEvtConsumer(new LpcCreateMeteoForecastEvtConsumer()),
      _createMeteoNowcastEvtConsumer(new LpcCreateMeteoNowcastEvtConsumer()),
      _demandEvtPublisher(new LpcDemandEvtPublisher()),
      _meteoForecastEvtPublisher(new LpcMeteoForecastEvtPublisher()),
      _meteoNowcastEvtPublisher(new LpcMeteoNowcastEvtPublisher())
//      _scheduleActivationEvtConsumer(new LpcScheduleActivationEvtConsumer()),
//      _optimalScheduleEvtPublisher(new LpcOptimalScheduleEvtPublisher()),
//      _optimalCriteriaEvtPublisher(new LpcOptimalCriteriaEvtPublisher()),
//      _optimizationCriteriaEvtConsumer(new LpcOptimizationCriteriaEvtConsumer()),
//      _capacityReductionsEvtConsumer(new LpcCapacityReductionsEvtConsumer()),
//      _activeScheduleEvtPublisher(new LpcActiveScheduleEvtPublisher()),
//      _manualEditionEvtConsumer(new LpcManualEditionEvtConsumer()),
//      _scheduleDeleteEvtConsumer(new LpcScheduleDeleteEvtConsumer()),
//      _alternativeSchedulePublisher(new LpcAlternativeScheduleEvtPublisher()),
//      _schedulesComparisonEvtConsumer(new LpcSchedulesComparisonEvtConsumer()),
//      _schedulesComparisonResponseEvtPublisher(new LpcSchedulesComparisonResponseEvtPublisher()),
//      _whatIfRunwayClosureEvtConsumer(new LpcWhatIfRunwayClosureEvtConsumer()),
//      _automaticDeletionEvtPublisher(new LpcAutomaticDeletionEvtPublisher())
{

}

void LpcCommunicationsManager::waitForEvents()
{
    boost::thread _waitThread(&wait);
    std::cout << "RTP Server Ready: Waiting for Events..." << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).notify() << "RTP Server Ready: Waiting for Events..." << std::endl;
    _waitThread.join();
}


