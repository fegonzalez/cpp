
#ifndef LPCDEMANDEVTPUBLISHER_H_
#define LPCDEMANDEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOTim.h>

#include <IODemandEventsiBContract.h>
#include <IODemandEvents.h>


class LpcDemandEvtPublisher : public LpiIDemandEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiUpdateDemandEvt &data);

private:

   iBG::IODemandEvents::UpdateDemandEventListPublisher *_publisher;
};



#endif /* LPCDEMANDEVTPUBLISHER_H_ */
