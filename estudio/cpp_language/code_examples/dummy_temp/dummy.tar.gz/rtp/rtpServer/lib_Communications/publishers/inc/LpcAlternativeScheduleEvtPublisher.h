#ifndef __LPC_ALTERNATIVE_SCHEDULE_EVT_PUBLISHER_H_
#define __LPC_ALTERNATIVE_SCHEDULE_EVT_PUBLISHER_H_

#include <IOTim.h>
#include <IOWhatIFEventsiBContract.h>
#include <IOWhatIFEvents.h>

#include <LpiIEventPublishers.h>

class LpcAlternativeScheduleEvtPublisher : public LpiIAlternativeScheduleEvtPublisher
{
   public:
      void init(void);

      virtual void publish(const LpiAlternativeScheduleEvt &data);

   private:

      iBG::IOWhatIFEvents::AlternativeResponseEventPublisher *_publisher;
};


#endif /* __LPC_ALTERNATIVE_SCHEDULE_EVT_PUBLISHER_H_ */
