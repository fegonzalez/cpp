/*
 * LpcCapacityReductionsEvtConsumer.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez
 */

#ifndef LPCAPACITYREDUCTIONSEVTCONSUMER_H_
#define LPCAPACITYREDUCTIONSEVTCONSUMER_H_

#include <IOCapacityReductionsEventsiBContract.h>
#include <LclogStream.h>


class LpcCapacityReductionsEvtConsumer: public iBG::IOCapacityReductionsEvents::CapacityReductionsEventSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IOCapacityReductionsEvents::CapacityReductionsEventSubscriber &sub);
};



#endif /* LPCAPACITYREDUCTIONSEVTCONSUMER_H_ */
