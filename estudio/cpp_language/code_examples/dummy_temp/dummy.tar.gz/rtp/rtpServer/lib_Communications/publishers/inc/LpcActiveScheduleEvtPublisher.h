
#ifndef LPCACTIVESCHEDULEEVTPUBLISHER_H_
#define LPCACTIVESCHEDULEEVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOScheduleActivationEventsiBContract.h>
#include <IOScheduleActivationEvents.h>
#include <IOTim.h>

#include <IOMeteoInfoEventsiBContract.h>
#include <IOMeteoInfoEvents.h>

class LpcActiveScheduleEvtPublisher : public LpiIActiveScheduleEvtPublisher
{
public:
   void init(void);

   // Publicador del evento hacia el exterior
   virtual void publish(const LpiActiveScheduleEvt &data);

private:

   iBG::IOScheduleActivationEvents::UpdateScheduleActivationEventPublisher *_publisher;

};



#endif /* LPCACTIVESCHEDULEEVTPUBLISHER_H_ */
