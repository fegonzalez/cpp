/*
 * LpcScheduleDeleteEvtConsumer.h
 *
 *  Created on: 16/09/2014
 */


#include "LpcScheduleDeleteEvtConsumer.h"
#include <IOWhatIF.h>
#include <LpiScheduleDeleteEvt.h>
#include "LpcScheduleDelete.h"
#include <LpdComponent.h>


void LpcScheduleDeleteEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOScheduleDeleteEvents::ScheduleDeleteEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOScheduleDeleteEvents::ScheduleDeleteEventSubscriber &subscriber =
             iBG::IOScheduleDeleteEvents::ScheduleDeleteEventCreateSubscriber(sid, sprofile);

   subscriber.addListener(this);
}


void LpcScheduleDeleteEvtConsumer::on_data_available(
                        iBG::IOScheduleDeleteEvents::ScheduleDeleteEventSubscriber & sub)
{
   iBG::IOScheduleDeleteEvents::ScheduleDeleteEventSubscriber::DataList dl;

   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOScheduleDeleteEvents::ScheduleDeleteEventSubscriber::DataList::iterator dit
                                                               = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {
      if(iit->isValid())
      {
         //Obtain data
         IOScheduleDelete::ScheduleDelete scheduleToDelete;
         memset(&scheduleToDelete, 0, sizeof(IOScheduleDelete::ScheduleDelete));
         scheduleToDelete = dit->scheduleDelete;

         //Internal type conversion
         int scheduleToDeleteId;
         LpcScheduleDelete::ConvertIO2Lpi(scheduleToDelete, scheduleToDeleteId);

         //Event
         LpiScheduleDeleteEvt event;
         event.setManualSchedule(scheduleToDeleteId);

         LpdComponent::Get().consume(event);
      }
   }
}

