/*
 *  LpcActiveScheduleEvtPublisher.cc
 *
 *  Created on: 14/07/2014
 *
 *  Author: gpfernandez
 */

#include <LpcActiveScheduleEvtPublisher.h>
#include <LcuStringArrayConvUtils.h>

#include <LpiActiveSchedule.h>
#include <IOScheduleActivationEvents.h>
#include <IOScheduleActivation.h>
#include <LpcActiveSchedule.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <boost/lexical_cast.hpp>

#include <iostream>


void LpcActiveScheduleEvtPublisher::init(void)
{
    iB::PublisherId pid("IOScheduleActivationEvents::UpdateScheduleActivationEvent");

    iB::PublicationProfile pprofile;

    _publisher = &iBG::IOScheduleActivationEvents::UpdateScheduleActivationEventCreatePublisher(pid, pprofile);
    LpdComponent::Get().delegatePublisher(*this);
}


void LpcActiveScheduleEvtPublisher::publish(const LpiActiveScheduleEvt &data)
{
   IOScheduleActivationEvents::UpdateScheduleActivationEvent activeScheduleEvt;

   IOScheduleActivationEvents::UpdateScheduleActivationEventTypeSupport::initialize_data(&activeScheduleEvt);

   IOScheduleActivation::UpdateScheduleActivation out;
   LpcActiveSchedule::convertLpi2IOActiveSchedule(data.getActiveSchedule(), out);

   activeScheduleEvt.updateScheduleActivation = out;
   _publisher->push(activeScheduleEvt);

   IOScheduleActivationEvents::UpdateScheduleActivationEventTypeSupport::finalize_data(&activeScheduleEvt);

   LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED SCHEDULE ACTIVATION]" << std::endl;

}

