
#include "LpcOptimizationCriteriaEvtConsumer.h"
#include <IOWhatIF.h>
#include <LpiOptimizationCriteriaEvt.h>
#include "LpcOptimizationCriteria.h"
#include <LpdComponent.h>


#include <string>
#include <LpdbDataBase.h>


void LpcOptimizationCriteriaEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOWhatIFEvents::OptimizationCriteriaEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOWhatIFEvents::OptimizationCriteriaEventSubscriber &subscriber =
             iBG::IOWhatIFEvents::OptimizationCriteriaEventCreateSubscriber(sid, sprofile);

   subscriber.addListener(this);
}


void LpcOptimizationCriteriaEvtConsumer::on_data_available(
                        iBG::IOWhatIFEvents::OptimizationCriteriaEventSubscriber &sub)
{
   iBG::IOWhatIFEvents::OptimizationCriteriaEventSubscriber::DataList dl;

   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOWhatIFEvents::OptimizationCriteriaEventSubscriber::DataList::iterator dit
                                                                  = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {

      if(iit->isValid())
      {
         //Obtain data
         IOWhatIF::OptimizationCriteria optimizationCriteria;
         memset(&optimizationCriteria, 0, sizeof(IOWhatIF::OptimizationCriteria));
         optimizationCriteria = dit->optimizationCriteriaData;

         //Internal type conversion
         LpiOptimizationCriteria lpiOptimizationCriteria;
         LpcOptimizationCriteria::convertIO2Lpi(optimizationCriteria, lpiOptimizationCriteria);

         //Event
         LpiOptimizationCriteriaEvt event;
         event.setOptimizationCriteria (lpiOptimizationCriteria);

         LpdComponent::Get().consume(event);
      }
   }
}

