/*
 * LpcCapacityReductions.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez 
 */

#ifndef LPCCAPACITY_REDUCTIONS_H_
#define LPCCAPACITY_REDUCTIONS_H_

#include <IOCapacityReductions.h>
#include <LpiCapacityReductions.h>
#include <IOTim.h>
#include <string>
#include <LpdComponent.h>


class LpcCapacityReductions
{
   public:

      static void convertIOCapacity2LpiCapacity(const IOCapacityReductions::CapacityReductions & in,
                                                LpiCapacityReductions & out);

   private:

};


#endif /* LPCCAPACITY_REDUCTIONS_H_ */
