// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):     icima
 Created:   10/4/2015 11:56:09 2015
 Release:   $Revision$
 Modified:  $Date$
 Path:      $Source$
 */
//---------------------------------------------------------------------------
#ifndef LPCACTIVATIONTYPE_H_
#define LPCACTIVATIONTYPE_H_

#include <IOCommonTypes.h>
#include "LpiActivationType.h"

class LpcActivationType
{
    public:
        static IOCommonTypes::ActivationType LpiToIOType(LpiActivationType::ActivationType value);

        static void convertIOToLpiActivationType(const IOCommonTypes::ActivationType &in,
                                                 LpiActivationType::ActivationType& out);
};

#endif /* LPCACTIVATIONTYPE_H_ */
