
#ifndef _LPC_AUTOMATIC_DELETION_EVTPUBLISHER_H_
#define _LPC_AUTOMATIC_DELETION_EVTPUBLISHER_H_

#include <LpiIEventPublishers.h>
#include <IOScheduleDeleteEventsiBContract.h>

#include <IOTim.h>


class LpcAutomaticDeletionEvtPublisher : public LpiIAutomaticDeletionEvtPublisher
{
   public:

      void init(void);
      virtual void publish(const LpiAutomaticDeletionEvt &data);

   private:

      iBG::IOScheduleDeleteEvents::ScheduleAutomaticDeleteEventPublisher *_publisher;
};



#endif /* _LPC_AUTOMATIC_DELETION_EVTPUBLISHER_H_ */
