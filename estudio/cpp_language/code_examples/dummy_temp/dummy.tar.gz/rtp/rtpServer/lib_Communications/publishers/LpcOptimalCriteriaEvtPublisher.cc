
#include <LpcOptimalCriteriaEvtPublisher.h>

#include <LcuStringArrayConvUtils.h>

#include <LpiSchedule.h>

#include <LpcOptimalSchedule.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <boost/lexical_cast.hpp>

#include <iostream>

#include <IOMeteoInfo.h>


void LpcOptimalCriteriaEvtPublisher::init(void)
{
    iB::PublisherId pid("IOWhatIFEvents::AlternativeResponseEvent");

    iB::PublicationProfile pprofile;
    
    _publisher = &iBG::IOWhatIFEvents::AlternativeResponseEventCreatePublisher(pid, pprofile);

    LpdComponent::Get().delegatePublisher(*this);
}

void LpcOptimalCriteriaEvtPublisher::publish(const LpiOptimalCriteriaEvt &data)
{
   IOWhatIFEvents::AlternativeResponseEvent ddsSeqEvt;
   memset(&ddsSeqEvt, 0, sizeof(IOWhatIFEvents::AlternativeResponseEvent));
   IOWhatIFEvents::AlternativeResponseEventTypeSupport::initialize_data(&ddsSeqEvt);

   IOSchedule::Schedule out;
   memset(&out, 0, sizeof(IOSchedule::Schedule));

   LpcOptimalSchedule::convert2OptimalSchedule(data.getSchedule(), out);
   ddsSeqEvt.alternativeSchedule.schedule = out;

   _publisher->push(ddsSeqEvt);

   IOWhatIFEvents::AlternativeResponseEventTypeSupport::finalize_data(&ddsSeqEvt);

   LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED OPTIMIZATION CRITERIA]" << std::endl;
}

