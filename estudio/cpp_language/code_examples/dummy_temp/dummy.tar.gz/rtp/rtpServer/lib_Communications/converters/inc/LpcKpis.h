/*
 * LpcKpis.h
 *
 * Created on: 24/09/2014
 * Author:
 *
 */

#ifndef __LPC_KPIS_H__
#define __LPC_KPIS_H__

#include <IOKPIs.h>
#include <LpiComparativeKpis.h>

class LpcComparativeKpis
{
   public:
      static void convertLpi2IOComparativeKpis (const LpiComparativeKpis & in,
                                                IOKPIs::ComparativeKpis  & out);

};


#endif /* __LPC_KPIS_H__ */
