/*
 * LpcSchedulesComparisonEvtConsumer.h
 *
 *  Created on: 07/01/2015
 *      Author: mbegega
 */

#ifndef LPC_SCHEDULES_COMPARISON_EVTCONSUMER_H_
#define LPC_SCHEDULES_COMPARISON_EVTCONSUMER_H_

#include <IOComparisonSchedulesEventsiBContract.h>
#include <LclogStream.h>


class LpcSchedulesComparisonEvtConsumer: public iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventSubscriberListener
{
   public:

      void init(void);
      void on_data_available(iBG::IOComparisonSchedulesEvents::ComparisonSchedulesEventSubscriber & sub);
};



#endif /* LPC_SCHEDULES_COMPARISON_EVTCONSUMER_H_ */
