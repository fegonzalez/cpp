/*
 * LpcDemand.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez 
 */

#ifndef LPCDEMAND_H_
#define LPCDEMAND_H_

#include <IODemandRTP.h>
#include <IOUpdateDemand.h>
#include <IOUpdateDemandRTP.h>

#include <LpiDemand.h>
#include <LpiFlightPlan.h>
#include <LpiUpdateDemandEvt.h>

#include <IOTim.h>
#include <string>


class LpcDemand
{
public:

   static void convert2FP(const IODemandRTP::FlightPlanS &in,
		   LpiFlightPlan &out, std::string &aerodrome); //CONSUMER: IODemand -> LpiFligthPlan

   static void convert2IOUpdateDemand(const LpiDemand &in,
		   IOUpdateDemandRTP::Demand &out);

private:
   static void Convert2IODepartureTimes(const LpiDepartureTimes & in, IODemandRTP::DepartureInfo & out);
   static void Convert2IOArrivalTimes(const LpiArrivalTimes & in, IODemandRTP::ArrivalInfo & out);
};


#endif /* LPCDEMAND_H_ */
