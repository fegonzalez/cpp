/*
 * LpcOptimizationCriteriaEvtConsumer.h
 *
 *  Created on: 06/03/2014
 *      Author: gpfernandez
 */

#ifndef LPOPTIMIZATIONCRITERIAEVTCONSUMER_H_
#define LPOPTIMIZATIONCRITERIAEVTCONSUMER_H_

#include <IOWhatIFEventsiBContract.h>
#include <LclogStream.h>


class LpcOptimizationCriteriaEvtConsumer: public iBG::IOWhatIFEvents::OptimizationCriteriaEventSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IOWhatIFEvents::OptimizationCriteriaEventSubscriber &sub);
};



#endif /* LPOPTIMIZATIONCRITERIAEVTCONSUMER_H_ */
