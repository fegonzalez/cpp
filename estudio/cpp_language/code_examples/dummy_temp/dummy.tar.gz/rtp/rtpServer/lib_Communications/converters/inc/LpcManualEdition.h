#ifndef __LPC_MANUAL_EDITION_H__
#define __LPC_MANUAL_EDITION_H__

#include <IOWhatIF.h>
#include <LpiAlternativeSchedule.h>

class LpcManualEdition
{
   public:
      static void convertIO2Lpi(const IOWhatIF::ManualEdition &in,
                                LpiAlternativeSchedule & out);
};


#endif /* __LPC_MANUAL_EDITION_H__ */
