/*
 * LpcScheduleRTP.cc
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */
#include <LpcScheduleRTP.h>



void LpcScheduleRTP::convert2DefaultSchedule(const std::vector<std::vector<std::string>> &in, IOScheduleRTP::Schedule &out)
{
	out.scheduleAirports.ensure_length(in.size(), in.size());
	for(unsigned int i = 0; i < in.size(); i++)
	{
		IOScheduleRTP::MRTM mrtm;
		mrtm.mrtmAirports.ensure_length(in.at(i).size(), in.at(i).size());
		for(unsigned int j = 0; j < in.at(i).size(); j++)
		{

			IOScheduleRTP::Airport airport;
			memset(&airport, 0, sizeof(IOScheduleRTP::Airport));
			LcuStringArrayConvUtils::String2Array(in.at(i).at(j), airport.airportID);
			mrtm.mrtmAirports.set_at(j, airport);
		}

		out.scheduleAirports.set_at(i, mrtm);
	}
}
