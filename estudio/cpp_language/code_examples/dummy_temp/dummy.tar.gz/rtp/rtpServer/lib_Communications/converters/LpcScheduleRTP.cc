/*
 * LpcScheduleRTP.cc
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */
#include <LpcScheduleRTP.h>
#include <LclogStream.h>

void LpcScheduleRTP::convert2Schedule(const LpiScheduleRTP &in, IOScheduleRTP::Schedule &out)
{
	out.scheduleAirports.ensure_length(in.getMrtmsList().size(), in.getMrtmsList().size());
	for(unsigned int i = 0; i < in.getMrtmsList().size(); i++)
	{
		IOScheduleRTP::MRTM mrtm;
		mrtm.mrtmAirports.ensure_length(in.getMrtmsList().at(i).getAirportsList().size(), in.getMrtmsList().at(i).getAirportsList().size());
		for(unsigned int j = 0; j < in.getMrtmsList().at(i).getAirportsList().size(); j++)
		{

			IOScheduleRTP::Airport airport;
			memset(&airport, 0, sizeof(IOScheduleRTP::Airport));
			LcuStringArrayConvUtils::String2Array(in.getMrtmsList().at(i).getAirportsList().at(j).getAirportID(), airport.airportID);
			mrtm.mrtmAirports.set_at(j, airport);

		}

		out.scheduleAirports.set_at(i, mrtm);
	}
}
