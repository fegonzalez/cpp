/*
 * LpcScheduleRTP.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPCSCHEDULERTP_H_
#define LPCSCHEDULERTP_H_

#include <IOScheduleRTP.h>
#include <string>
#include <vector>
#include <iostream>
#include "LcuStringArrayConvUtils.h"
#include "LpiScheduleRTP.h"

class LpcScheduleRTP
{
 public:

  static void convert2Schedule(const LpiScheduleRTP &in, IOScheduleRTP::Schedule &out);


 private:

};


#endif /* LPCSCHEDULERTP_H_ */
