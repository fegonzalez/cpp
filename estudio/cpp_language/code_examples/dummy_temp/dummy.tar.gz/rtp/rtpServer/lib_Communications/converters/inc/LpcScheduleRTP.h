/*
 * LpcScheduleRTP.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPCSCHEDULERTP_H_
#define LPCSCHEDULERTP_H_

#include <IOScheduleRTP.h>
#include <string>
#include <vector>
#include <iostream>
#include "LcuStringArrayConvUtils.h"

class LpcScheduleRTP
{
 public:

  static void convert2DefaultSchedule(const std::vector<std::vector<std::string>> &in, IOScheduleRTP::Schedule &out);


 private:

};


#endif /* LPCSCHEDULERTP_H_ */
