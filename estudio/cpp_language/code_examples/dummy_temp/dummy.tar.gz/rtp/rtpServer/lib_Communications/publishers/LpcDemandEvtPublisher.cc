#include <LpcDemandEvtPublisher.h>
#include <LcuStringArrayConvUtils.h>

#include <LpiSchedule.h>
#include <IODemand.h>
#include <LpcDemand.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <boost/lexical_cast.hpp>

#include <iostream>

void LpcDemandEvtPublisher::init(void)
{
    iB::PublisherId pid("IODemandEvents::UpdateDemandEventList");

    iB::PublicationProfile pprofile;

    _publisher = &iBG::IODemandEvents::UpdateDemandEventListCreatePublisher(pid, pprofile);
    LpdComponent::Get().delegatePublisher(*this);
}

void LpcDemandEvtPublisher::publish(const LpiUpdateDemandEvt &evt)
{
    LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED DEMAND TO HMI ----]" << std::endl;

    IODemandEvents::UpdateDemandEventList data;
    IODemandEvents::UpdateDemandEventListTypeSupport::initialize_data(&data);
    data.demands.ensure_length(evt.getDemand().size(), evt.getDemand().size());

    for (unsigned int i = 0; i < evt.getDemand().size(); i++)
    {
        IOUpdateDemandRTP::Demand demand;

        LpcDemand::convert2IOUpdateDemand(evt.getDemand()[i], demand);
        data.demands.set_at(i, demand);
    }

    _publisher->push(data);
    ::IODemandEvents::UpdateDemandEventListTypeSupport::finalize_data(&data);

    LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED DEMAND]" << std::endl;
}

