/*
 * LpcManualEditionEvtConsumer.h
 *
 *  Created on: 16/09/2014
 */

#ifndef __LPC_MANUAL_EDITION_EVT_CONSUMER_H__
#define __LPC_MANUAL_EDITION_EVT_CONSUMER_H__

#include <IOWhatIFEventsiBContract.h>
#include <LclogStream.h>


class LpcManualEditionEvtConsumer: public iBG::IOWhatIFEvents::ManualEditionEventSubscriberListener
{
   public:
      void init(void);
      void on_data_available(iBG::IOWhatIFEvents::ManualEditionEventSubscriber & sub);
};


#endif /* __LPC_MANUAL_EDITION_EVT_CONSUMER_H__ */
