
#include "LpcCalculationReason.h"
#include "LpcDemand.h"
#include <LcuStringArrayConvUtils.h>
#include <IOConstant.h>
#include <LctimTimeUtils.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/algorithm/string/trim.hpp>

void Array2String(const IOConst::Callsign &callsign, std::string &out)
{
    LcuStringArrayConvUtils::Array2String(callsign, out);
}


void OptionalTime2Posix_time(const IOTim::OptionalTimeU & optionaltime,
                             boost::optional<posix_time::ptime> & pos_time)
{
   if(optionaltime._d == true)
   {
      pos_time = posix_time::from_time_t(optionaltime._u.value);
   }
   else
   {
      pos_time = boost::none;
   }
}


void Posix_time2OptionalTime(const boost::optional<posix_time::ptime> & pos_time,
                             IOTim::OptionalTimeU & optionaltime)
{
    if(pos_time)
    {
      posix_time::ptime epoch(boost::gregorian::date(1970,1,1));
        
      optionaltime._d = true;
      optionaltime._u.value = ((*pos_time)- epoch).total_seconds();
    }
    else
    {
       optionaltime._d = false;
    }

}


void LpcDemand::convert2FP(const IODemandRTP::FlightPlanS & in, LpiFlightPlan & out, std::string & aerodrome)
{
   std::string callsign;
   LcuStringArrayConvUtils::Array2String(in.fpKey.callsign, callsign);

   boost::algorithm::trim(callsign);
   out.setCallsign(callsign);

   std::string depAerodrome;
   LcuStringArrayConvUtils::Array2String(in.fpKey.depAerodrome, depAerodrome);

   boost::algorithm::trim(depAerodrome);
   out.setDepartureAerodrome(depAerodrome);

   std::string arrAerodrome;
   LcuStringArrayConvUtils::Array2String(in.fpKey.arrAerodrome, arrAerodrome);

   boost::algorithm::trim(arrAerodrome);
   out.setArrivalAerodrome(arrAerodrome);

   std::string star;
   LcuStringArrayConvUtils::Array2String(in.star, star);

   std::string vfr;
   LcuStringArrayConvUtils::Array2String(in.vfr, vfr);

   boost::algorithm::trim(vfr);
   out.setVFR(vfr);

   std::string sid;
   LcuStringArrayConvUtils::Array2String(in.sid, sid);


   if(depAerodrome.compare(aerodrome) == 0)
   {
     out.setOperationType(LpiOperationType::E_DEPARTURE);
     boost::algorithm::trim(sid);
     out.setSID(sid);
   }
   else if(arrAerodrome.compare(aerodrome) == 0)
   {
     out.setOperationType(LpiOperationType::E_ARRIVAL);
     boost::algorithm::trim(star);
     out.setSTAR(star);
   }
   else
   {
     out.setOperationType(LpiOperationType::E_NONE);
   }

   std::string aircraftType;
   LcuStringArrayConvUtils::Array2String(in.acType, aircraftType);
   if (aircraftType != "")
   {
      boost::algorithm::trim(aircraftType);
   }

   out.setAircraftType(aircraftType);

   std::string registration;
   LcuStringArrayConvUtils::Array2String(in.registration, registration);
   if (registration != "")
   {
      boost::algorithm::trim(registration);
   }

   out.setRegistration(registration);

   std::string wtc;
   LcuStringArrayConvUtils::Array2String(in.wtc, wtc);
   if (wtc != "")
   {
      boost::algorithm::trim(wtc);
   }

   out.setWtc(wtc);
 

   //Times Departure
   LpiDepartureTimes depTimes;
   
   boost::optional<posix_time::ptime> eobt_time;
   boost::optional<posix_time::ptime> sobt_time;
   boost::optional<posix_time::ptime> tobt_time;
   boost::optional<posix_time::ptime> etot_time;
   boost::optional<posix_time::ptime> ttot_time;
   boost::optional<posix_time::ptime> stot_time;
   boost::optional<posix_time::ptime> atot_time;
   boost::optional<posix_time::ptime> ctot_time;
   boost::optional<posix_time::ptime> utot_time;

   OptionalTime2Posix_time(in.depInfo.eobt, eobt_time);
   if (eobt_time)
      depTimes.setEobt(*eobt_time);

   OptionalTime2Posix_time(in.depInfo.sobt, sobt_time);
   if (sobt_time)
      depTimes.setSobt(*sobt_time);

   OptionalTime2Posix_time(in.depInfo.tobt, tobt_time);
   if (tobt_time)
      depTimes.setTobt(*tobt_time);

   OptionalTime2Posix_time(in.depInfo.etot, etot_time);
   if (etot_time)
      depTimes.setEtot(*etot_time);

   OptionalTime2Posix_time(in.depInfo.ttot, ttot_time);
   if (ttot_time)
      depTimes.setTtot(*ttot_time);

   OptionalTime2Posix_time(in.depInfo.stot, stot_time);
   if (stot_time)
      depTimes.setStot(*stot_time);

   OptionalTime2Posix_time(in.depInfo.atot, atot_time);
   if (atot_time)
      depTimes.setAtot(*atot_time);

   OptionalTime2Posix_time(in.depInfo.ctot, ctot_time);
   if (ctot_time)
      depTimes.setCtot(*ctot_time);

   OptionalTime2Posix_time(in.depInfo.utot, utot_time);
   if (utot_time)
      depTimes.setUtot(*utot_time);

   out.setDepartureTimes(depTimes);

   //Arrival Departure
   LpiArrivalTimes arrTimes;
   boost::optional<posix_time::ptime> eldt_time;
   boost::optional<posix_time::ptime> tldt_time;
   boost::optional<posix_time::ptime> aldt_time;
   boost::optional<posix_time::ptime> ildt_time;
   boost::optional<posix_time::ptime> sibt_time;
   boost::optional<posix_time::ptime> sldt_time;
   boost::optional<posix_time::ptime> uldt_time;

   OptionalTime2Posix_time(in.arrInfo.eldt, eldt_time);
   if (eldt_time)
      arrTimes.setEldt(*eldt_time);

   OptionalTime2Posix_time(in.arrInfo.tldt, tldt_time);
   if (tldt_time)
      arrTimes.setTldt(*tldt_time);

   OptionalTime2Posix_time(in.arrInfo.aldt, aldt_time);
   if (aldt_time)
      arrTimes.setAldt(*aldt_time);

   OptionalTime2Posix_time(in.arrInfo.sibt, sibt_time);
   if (sibt_time)
      arrTimes.setSibt(*sibt_time);

   OptionalTime2Posix_time(in.arrInfo.sldt, sldt_time);
   if (sldt_time)
      arrTimes.setSldt(*sldt_time);

   OptionalTime2Posix_time(in.arrInfo.uldt, uldt_time);
   if (uldt_time)
      arrTimes.setUldt(*uldt_time);

   out.setArrivalTimes(arrTimes);
}

void LpcDemand::convert2IOUpdateDemand(const LpiDemand &demand, IOUpdateDemandRTP::Demand &out)
{
   unsigned int i, j;

   LpcCalculationReason::convertLpi2IOCalculationReason(demand.getCalculationReason(), out.calculationReason);

   LcuStringArrayConvUtils::String2Array(LctimTimeUtils::formatTime(demand.getmessageTimeandDate(), "%H%M/%d%m%y"), out.timeAndDate);

   out.demandForecast.ensure_length(demand.getDemand().getDemand().size(), demand.getDemand().getDemand().size());
   for( i= 0; i < demand.getDemand().getDemand().size()  ; i++)
   {
      IOUpdateDemandRTP::Demand_Forecast IOdemand;

      memset(&IOdemand, 0, sizeof(IOUpdateDemandRTP::Demand_Forecast));
      IOdemand.demand_forecast.arrivals        = 
            demand.getDemand().getDemand()[i].getdemandForecastScheduled().getarrivalsValue();
      IOdemand.demand_forecast.departures      = 
            demand.getDemand().getDemand()[i].getdemandForecastScheduled().getdeparturesValue();
      IOdemand.demand_forecast.overall         = 
            demand.getDemand().getDemand()[i].getdemandForecastScheduled().getoverallValue();

      LcuStringArrayConvUtils::String2Array(demand.getDemand().getDemand()[i].getIntervalName(),IOdemand.intervalName);
      LcuStringArrayConvUtils::String2Array(demand.getDemand().getDemand()[i].getStarTime(),IOdemand.starTimeAndDate);
      LcuStringArrayConvUtils::String2Array(demand.getDemand().getDemand()[i].getEndTime(),IOdemand.endTimeAndDate);
      
      IOdemand.ratio.arrivals = demand.getDemand().getDemand()[i].getDemandRatio().getarrivalsValue();
      IOdemand.ratio.departures = demand.getDemand().getDemand()[i].getDemandRatio().getdeparturesValue();
      IOdemand.ratio.overall = demand.getDemand().getDemand()[i].getDemandRatio().getoverallValue();

      IOdemand.vfr.arrivals = demand.getDemand().getDemand()[i].getDemandVFR().getarrivalsValue();
      IOdemand.vfr.departures = demand.getDemand().getDemand()[i].getDemandVFR().getdeparturesValue();
      IOdemand.vfr.overall = demand.getDemand().getDemand()[i].getDemandVFR().getoverallValue();

      IOdemand.fp.arrivals.ensure_length(demand.getFps()[i].arrivals.size(), demand.getFps()[i].arrivals.size());

      std::string opType;
      opType = "ARR";
      for(j = 0; j< demand.getFps()[i].arrivals.size(); j++)
      {
         IOUpdateDemandRTP::Fps fps;
         memset(&fps, 0, sizeof(IOUpdateDemandRTP::Fps));

         LcuStringArrayConvUtils::String2Array (demand.getFps()[i].arrivals[j].getdemandForecastFpsScheduled(),fps.fp);

         Posix_time2OptionalTime(demand.getFps()[i].arrivals[j].getItotIldt(), fps.itot_ildt);
         Posix_time2OptionalTime(demand.getFps()[i].arrivals[j].getCtotSibt(), fps.ctot_sibt);
         Posix_time2OptionalTime(demand.getFps()[i].arrivals[j].getEtotEldt(), fps.etot_eldt);
         Posix_time2OptionalTime(demand.getFps()[i].arrivals[j].getStotSldt(), fps.stot_sldt);
         Posix_time2OptionalTime(demand.getFps()[i].arrivals[j].getTtotTldt(), fps.ttot_tldt);
         Posix_time2OptionalTime(demand.getFps()[i].arrivals[j].getUtotUldt(), fps.utot_uldt);

         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].arrivals[j].getAircraftType(), fps.acType);

         LcuStringArrayConvUtils::String2Array(opType, fps.opType);
         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].arrivals[j].getSIDSTAR(), fps.proced);

         IOdemand.fp.arrivals.set_at(j, fps); 
      }  
      
      IOdemand.fp.departure.ensure_length(demand.getFps()[i].departure.size(), demand.getFps()[i].departure.size());
      opType = "DEP";
      for(j = 0; j< demand.getFps()[i].departure.size() ; j++)
      {
         IOUpdateDemandRTP::Fps fps;
         memset(&fps, 0, sizeof(IOUpdateDemandRTP::Fps));

         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].departure[j].getdemandForecastFpsScheduled(),fps.fp);

         Posix_time2OptionalTime(demand.getFps()[i].departure[j].getItotIldt(), fps.itot_ildt);
         Posix_time2OptionalTime(demand.getFps()[i].departure[j].getCtotSibt(), fps.ctot_sibt);
         Posix_time2OptionalTime(demand.getFps()[i].departure[j].getEtotEldt(), fps.etot_eldt);
         Posix_time2OptionalTime(demand.getFps()[i].departure[j].getStotSldt(), fps.stot_sldt);
         Posix_time2OptionalTime(demand.getFps()[i].departure[j].getTtotTldt(), fps.ttot_tldt);
         Posix_time2OptionalTime(demand.getFps()[i].departure[j].getUtotUldt(), fps.utot_uldt);

         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].departure[j].getAircraftType(),fps.acType);

         LcuStringArrayConvUtils::String2Array(opType, fps.opType);
         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].departure[j].getSIDSTAR(), fps.proced);

         IOdemand.fp.departure.set_at(j, fps);
      }

      IOdemand.fp.overall.ensure_length(demand.getFps()[i].overall.size(), demand.getFps()[i].overall.size());
      opType = "NON";
      for ( j= 0; j<demand.getFps()[i].overall.size(); j++)
      {
         IOUpdateDemandRTP::Fps fps;
         memset(&fps, 0, sizeof(IOUpdateDemandRTP::Fps));

         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].overall[j].getdemandForecastFpsScheduled(),fps.fp);

         Posix_time2OptionalTime(demand.getFps()[i].overall[j].getItotIldt(), fps.itot_ildt);
         Posix_time2OptionalTime(demand.getFps()[i].overall[j].getCtotSibt(), fps.ctot_sibt);
         Posix_time2OptionalTime(demand.getFps()[i].overall[j].getEtotEldt(), fps.etot_eldt);
         Posix_time2OptionalTime(demand.getFps()[i].overall[j].getStotSldt(), fps.stot_sldt);
         Posix_time2OptionalTime(demand.getFps()[i].overall[j].getTtotTldt(), fps.ttot_tldt);
         Posix_time2OptionalTime(demand.getFps()[i].overall[j].getUtotUldt(), fps.utot_uldt);

         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].overall[j].getAircraftType(), fps.acType);

         LcuStringArrayConvUtils::String2Array(opType, fps.opType);
         LcuStringArrayConvUtils::String2Array(demand.getFps()[i].overall[j].getSIDSTAR(), fps.proced);
         IOdemand.fp.overall.set_at(j, fps);
      }
      out.demandForecast.set_at(i, IOdemand);
   }

   out.total_demand_forecast.arrivals   = demand.getDemand().gettotalDemandForecast().getarrivalsValue();
   out.total_demand_forecast.departures = demand.getDemand().gettotalDemandForecast().getdeparturesValue();
   out.total_demand_forecast.overall    = demand.getDemand().gettotalDemandForecast().getoverallValue();

   out.total_ratio.arrivals = demand.getDemand().getTotalDemandRatio().getarrivalsValue();
   out.total_ratio.departures = demand.getDemand().getTotalDemandRatio().getdeparturesValue();
   out.total_ratio.overall = demand.getDemand().getTotalDemandRatio().getoverallValue();

   out.total_vfr.arrivals = demand.getDemand().getTotalDemandVFR().getarrivalsValue();
   out.total_vfr.departures = demand.getDemand().getTotalDemandVFR().getdeparturesValue();
   out.total_vfr.overall = demand.getDemand().getTotalDemandVFR().getoverallValue();


   LcuStringArrayConvUtils::String2Array<IOConst::AEROD_SIZE>(demand.getNameAirport(), out.airport);
   LcuStringArrayConvUtils::String2Array(LctimTimeUtils::formatTime(demand.getDemandStartTimeAndDate(), "%H%M/%d%m%y"), out.demandStartTimeAndDate);
   LcuStringArrayConvUtils::String2Array(LctimTimeUtils::formatTime(demand.getDemandEndTimeAndDate(), "%H%M/%d%m%y"), out.demandEndTimeAndDate);

   LpiFlightPlanList fplist = demand.getFlightPlanList();
   out.fligthPlanList.ensure_length(demand.getFlightPlanList().size(), demand.getFlightPlanList().size());
   for(unsigned int x = 0; x < fplist.size(); x++)
   {
	   const LpiFlightPlan fp = fplist.at(x);
	   IODemandRTP::FlightPlanS flightPlanIO;
	   LpcDemand::Convert2IODepartureTimes(fp.getDepartureTimes(),flightPlanIO.depInfo);
	   LpcDemand::Convert2IOArrivalTimes(fp.getArrivalTimes(),flightPlanIO.arrInfo);
	   LcuStringArrayConvUtils::String2Array<IOConst::CALLSIGN_SIZE>(fp.getCallsign(), flightPlanIO.fpKey.callsign);
	   LcuStringArrayConvUtils::String2Array<IOConst::AEROD_SIZE>(fp.getDepartureAerodrome(), flightPlanIO.fpKey.depAerodrome);
	   LcuStringArrayConvUtils::String2Array<IOConst::AEROD_SIZE>(fp.getArrivalAerodrome(), flightPlanIO.fpKey.arrAerodrome);
	   LcuStringArrayConvUtils::String2Array<IOConst::ACTYPE_SIZE>(fp.getAircraftType(), flightPlanIO.acType);
	   LcuStringArrayConvUtils::String2Array<12>(fp.getRegistration(), flightPlanIO.registration);
	   LcuStringArrayConvUtils::String2Array<IOConst::WTC_SIZE>(fp.getWtc(), flightPlanIO.wtc);
	   LcuStringArrayConvUtils::String2Array<IOConst::PROCED_SIZE>(fp.getSID(), flightPlanIO.sid);
	   LcuStringArrayConvUtils::String2Array<IOConst::PROCED_SIZE>(fp.getSTAR(), flightPlanIO.star);
	   out.fligthPlanList.set_at(x, flightPlanIO);
   }
}


void LpcDemand::Convert2IODepartureTimes(const LpiDepartureTimes & in, IODemandRTP::DepartureInfo & out)
{
   //eobt
   Posix_time2OptionalTime(in.getEobt(), out.eobt);

   //sobt
   Posix_time2OptionalTime(in.getSobt(), out.sobt);

   //tobt
   Posix_time2OptionalTime(in.getTobt(), out.tobt);

   //etot
   Posix_time2OptionalTime(in.getEtot(), out.etot);

   //ttot
   Posix_time2OptionalTime(in.getTtot(), out.ttot);

   //stot
   Posix_time2OptionalTime(in.getStot(), out.stot);

   //atot
   Posix_time2OptionalTime(in.getAtot(), out.atot);

   //ctot
   Posix_time2OptionalTime(in.getCtot(), out.ctot);

   //utot
   Posix_time2OptionalTime(in.getUtot(), out.utot);
}


void LpcDemand::Convert2IOArrivalTimes(const LpiArrivalTimes & in, IODemandRTP::ArrivalInfo & out)
{
   //eldt
   Posix_time2OptionalTime(in.getEldt(), out.eldt);

   //tldt
   Posix_time2OptionalTime(in.getTldt(), out.tldt);

   //aldt
   Posix_time2OptionalTime(in.getAldt(), out.aldt);

   //sldt
   Posix_time2OptionalTime(in.getSldt(), out.sldt);

   //sibt
   Posix_time2OptionalTime(in.getSibt(), out.sibt);

   //uldt
   Posix_time2OptionalTime(in.getUldt(), out.uldt);
}

