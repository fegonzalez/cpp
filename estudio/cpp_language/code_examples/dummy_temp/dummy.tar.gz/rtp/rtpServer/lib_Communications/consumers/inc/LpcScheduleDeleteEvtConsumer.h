/*
 * LpcScheduleDeleteEvtConsumer.h
 *
 *  Created on: 16/09/2014
 */

#ifndef __LPC_SCHEDULE_DELETE_EVT_CONSUMER_H__
#define __LPC_SCHEDULE_DELETE_EVT_CONSUMER_H__

#include <IOScheduleDeleteEventsiBContract.h>
#include <LclogStream.h>


class LpcScheduleDeleteEvtConsumer: public iBG::IOScheduleDeleteEvents::ScheduleDeleteEventSubscriberListener
{
   public:
      void init(void);
      void on_data_available(iBG::IOScheduleDeleteEvents::ScheduleDeleteEventSubscriber & sub);
};


#endif /* __LPC_SCHEDULE_DELETE_EVT_CONSUMER_H__ */
