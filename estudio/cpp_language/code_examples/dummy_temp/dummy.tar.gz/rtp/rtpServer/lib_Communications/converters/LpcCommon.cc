/*
 * LpcCommon.cc
 *
 *  Created on: 19/03/2015
 *      Author: mbegega
 */

#include "LpcCommon.h"


// from boost::optional to IOCommonTypes::Optional

void LpcCommon::optionalBool2IO(const boost::optional<bool> & in, IOCommonTypes::OptionalBool & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
   }
}


void LpcCommon::optionalFloat2IO(const boost::optional<float> & in,IOCommonTypes::OptionalFloat & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
   }
}


void LpcCommon::optionalInt2IO(const boost::optional<int> & in, IOCommonTypes::OptionalInt & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
   }
}


void LpcCommon::optionalDouble2IO(const boost::optional<double> & in,IOCommonTypes::OptionalDouble & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
   }
}


void LpcCommon::optionalDouble2IO(const boost::optional<double> & in,IOCommonTypes::OptionalFloat & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
   }
}


void LpcCommon::OptionalUnsignedInt2IO(const boost::optional<unsigned int> & in, IOCommonTypes::OptionalUnsignedInt & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;
      out._u.value = *in;
   }
}

void LpcCommon::OptionalUnsignedInt2IOInteger(const boost::optional<unsigned int> & in,
		                           IOCommonTypes::OptionalInt & out)
{
   out._d = false;

   if (in)
   {
      out._d = true;

      //out._u.value = *in;
      int aux_int_val = static_cast<int> (*in);
      out._u.value = aux_int_val;
   }
}

//-----------------------------------------------------------------------------

// from IOCommonTypes::Optional to boost::optional 


void LpcCommon::IOOptionalBool2OptionalBool(const IOCommonTypes::OptionalBool & optional,
					    boost::optional<bool> & optionalBool)
{
   if(optional._d == true)
   {
       optionalBool = optional._u.value;
   }
   else
   {
       optionalBool = boost::none;
   }
}

void LpcCommon::IOOptionalUnsignedInt2OptionalUnsignedInt(const IOCommonTypes::OptionalUnsignedInt & optional,
							  boost::optional<unsigned int> & optionalUnsignedInt)
{
   if(optional._d == true)
   {
       optionalUnsignedInt = optional._u.value;
   }
   else
   {
       optionalUnsignedInt = boost::none;
   }
}

void LpcCommon::IOOptionalDouble2OptionalDouble(const IOCommonTypes::OptionalDouble & optional,
						boost::optional<double> & optionalDouble)
{
   if(optional._d == true)
   {
       optionalDouble = optional._u.value;
   }
   else
   {
       optionalDouble = boost::none;
   }
}





void LpcCommon::IOOptionalInt2OptionalUnsignedInt(const IOCommonTypes::OptionalInt & optional,
						  boost::optional<unsigned int> & optionalUnsignedInt)
{
   if(optional._d == true)
   {
       int aux_int_val =  optional._u.value;
       optionalUnsignedInt = static_cast<unsigned int> (aux_int_val); 
   }
   else
   {
       optionalUnsignedInt = boost::none;
   }
}

void LpcCommon::IOOptionalDouble2OptionalDouble(const IOCommonTypes::OptionalFloat & optional,
					       boost::optional<double> & optionalDouble)
{
   if(optional._d == true)
   {
       optionalDouble = optional._u.value;
   }
   else
   {
       optionalDouble = boost::none;
   }
}

//-----------------------------------------------------------------------------
