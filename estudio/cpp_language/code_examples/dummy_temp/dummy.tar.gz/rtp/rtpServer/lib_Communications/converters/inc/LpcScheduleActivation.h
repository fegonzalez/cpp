/*
 * LpcScheduleActivation.h
 *
 *  Created on: 17/07/2014
 *      Author: gpfernandez
 */

#ifndef LPCSCHEDULEACTIVATION_H_
#define LPCSCHEDULEACTIVATION_H_

#include <IOScheduleActivation.h>
#include <LpiScheduleActivation.h>

class LpcScheduleActivation
{
public:
   static void convertIO2Lpi(const IOScheduleActivation::ScheduleActivation &in,
                                  LpiScheduleActivation &out);

private:

};


#endif /* LPCSCHEDULEACTIVATION_H_ */
