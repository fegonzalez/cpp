#include "LpcCreateDemandEvtConsumer.h"
#include <IODemand.h>
#include <LpiFlightPlan.h>
#include "LpcDemand.h"
#include <LpdComponent.h>
#include <LcuStringArrayConvUtils.h>
#include <LctimTimeUtils.h>
#include <string>
#include <LpdbDataBase.h>
#include <LpdFunctions.h>


void LpcCreateDemandEvtConsumer::init(void) {
	iB::SubscriberId sid("IODemandEvents::CreateDemandEventList");
	iB::SubscriptionProfile sprofile;

	iBG::IODemandEvents::CreateDemandEventListSubscriber &subscriber =
			iBG::IODemandEvents::CreateDemandEventListCreateSubscriber(sid,
					sprofile);
	subscriber.addListener(this);
}

void LpcCreateDemandEvtConsumer::on_data_available(
		iBG::IODemandEvents::CreateDemandEventListSubscriber &sub) {
    LclogStream::instance(LclogConfig::E_RTP).notify() << "[ DEMAND PV ]" << std::endl;

	iBG::IODemandEvents::CreateDemandEventListSubscriber::DataList dl;
	iB::DIList il;
	sub.getData(dl, il);

	iBG::IODemandEvents::CreateDemandEventListSubscriber::DataList::iterator dit =
			dl.begin();
	iB::DIList::iterator iit = il.begin();
	int pos = 0;

	for (; (dit != dl.end()) && (iit != il.end()); ++dit, ++iit, pos++) {
		if (iit->isValid()) {
			 bool aux_NewData = false;
			LclogStream::instance(LclogConfig::E_RTP).notify() << "[RECEIVED DEMAND EVENT]" << std::endl;

			IODemandEvents::DemandList ioDemandList;
			ioDemandList = dit->flightPlans;

			//Event

			LpiCreateDemandList demandList;

			for (int x = 0; x < ioDemandList.length(); x++) {
				//Obtain data
				IODemandRTP::Demand iodemand;
				iodemand = ioDemandList.get_at(x);

				IODemandRTP::FlightPlanList iofplist = iodemand.fligthPlanList;

				//Get parameters for internal conversion
//				int default_taxi_time =
//						LpdbDataBase::Get().getGlobalParameters().getDefaultTaxiTime();

				//Event
				LpiCreateDemandEvt event;
				LpiCreateDemand demand;

				std::string aerodrome;
				LcuStringArrayConvUtils::Array2String < IOConst::AEROD_SIZE> (iodemand.airport, aerodrome);

				posix_time::ptime startTimeAndDate, endTimeAndDate;
				startTimeAndDate = LctimTimeUtils::getFromString(
						iodemand.demandStartTimeAndDate);
				endTimeAndDate = LctimTimeUtils::getFromString(
						iodemand.demandEndTimeAndDate);

				/*LpbDataBase::RunwaySystemTable & rs_table =
				 LpbDataBase::Get().getRunwaySystemTable();
				 vector<string> rs_keys = rs_table.getAllIds();

				 //Calculate not allowed runways
				 LpiAdaptationNotAllowedList not_allowed;
				 LpiResult resultNotAllowed;
				 LpdComponent::Get().getAdaptationNotAllowed(not_allowed,
				 resultNotAllowed);

				 //Calculate preferential runways
				 LpiPreferentialAllocation preferential;
				 LpiResult resultPreferentialAllocation;
				 LpdComponent::Get().getAdaptationPreferentialAllocation(
				 preferential, resultPreferentialAllocation);*/

				LpiFlightPlanList flightPlanList;
				for (int i = 0; i < iofplist.length(); i++) {
					//Internal type conversion
					LpiFlightPlan fp;
					LpcDemand::convert2FP(iofplist.get_at(i), fp, aerodrome);

					//Calculate intentional time
					fp.calculateIntentionalTimes();

					boost::optional<posix_time::ptime> intentional_time =
							fp.getIntentionalTime();
					if (intentional_time) {
						flightPlanList.push_back(fp);
					} else {
#ifdef TRACE_OUT
						if (fp.getOperationType() == LpiOperationType::E_NONE)
						{
							LclogStream::instance(LclogConfig::E_RTP).debug() << "FP [" << fp.getCallsign() << "] discarded (doesn't concern our airport)" << std::endl;
						}
						else
						{
							LclogStream::instance(LclogConfig::E_RTP).debug() << "FP [" << fp.getCallsign() << "] discarded (no intentional time)" << std::endl;
						}
#endif
					}
				}


				demand.setNameAirport(aerodrome);
				demand.setDemandStartTimeAndDate(startTimeAndDate);
				demand.setDemandEndTimeAndDate(endTimeAndDate);
				demand.setFlightPlanList(flightPlanList);

				LclogStream::instance(LclogConfig::E_RTP).notify() << demand << std::endl;



					if(managedAirport(aerodrome))
					{
						aux_NewData = true;
						demandList.push_back(demand);
					}
					else
					{
						LclogStream::instance(LclogConfig::E_RTP).warning()
							  << "Bad Demand Info received. Airport not found "
							  << '(' << aerodrome << ')'
							  << " . Demand data ignored."
							  << " ; file: " << __FILE__
							  << " ; FN: " << __func__
							  << " ; LINE:  " << __LINE__
							  << std::endl;
					  }

			}

			if(aux_NewData)
			{
			LpiCreateDemandEvt event;
				event.setCreateDemand(demandList);

				LclogStream::instance(LclogConfig::E_RTP).notify() << "[ END OF CONSUMER RTP -- ]" << std::endl;
				LpdComponent::Get().consume(event);
			}
		}
	}
}


