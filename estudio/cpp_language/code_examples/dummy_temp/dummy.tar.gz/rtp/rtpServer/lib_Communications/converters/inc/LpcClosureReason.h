#ifndef __LPC_CLOSURE_REASON_H__
#define __LPC_CLOSURE_REASON_H__

#include <IOCommonTypes.h>
#include <LpiClosureReason.h>

class LpcClosureReason
{
   public:
      static void convertLpi2IOClosureReason(const LpiClosureReason::LpiEnum &in,
                                             IOCommonTypes::ClosureReason & out);

      static void convertIO2LpiClosureReason(const IOCommonTypes::ClosureReason & in,
                                             LpiClosureReason::LpiEnum & out);
};


#endif /* __LPC_CLOSURE_REASON_H__ */
