/*
 * LpcOptimizationCriteria.h
 *
 *  Created on: 08/01/2014
 *      Author: gpfernandez 
 */

#ifndef LPCOPTIMIZATIONCRITERIA_H_
#define LPCOPTIMIZATIONCRITERIA_H_

#include <IOWhatIF.h>
#include <LpiOptimizationCriteria.h>

class LpcOptimizationCriteria
{
   public:
      static void convertIO2Lpi(const IOWhatIF::OptimizationCriteria &in,
                                LpiOptimizationCriteria & out);

   private:

};


#endif /* LPCOPTIMIZATIONCRITERIA_H_ */
