/*
 * LpcWhatIfClosure.h
 *
 *  Created on: 18/05/2015
 *      Author: mbegega
 */


#ifndef LPCWHATIFCLOSURE_H_
#define LPCWHATIFCLOSURE_H_

#include <IOCapacityReductions.h>
#include <IOWhatIF.h>

#include <LpiWhatIfClosure.h>

class LpcWhatIfClosure
{
   public:

      static void ConvertIO2Lpi(const IOCapacityReductions::RunwayNonPeriods & in,
                                std::vector<LpiRunwayClosure> & out);

      static void ConvertIO2Lpi(const IOWhatIF::RunwayClosures & in,
                                LpiWhatIfClosure & out);

      static void ConvertIO2Lpi(const IOWhatIF::BestPointClosure & in,
                                LpiBestPointClosure & out);

      static void ConvertLpi2IO(const LpiRunwayClosure & in,
                                IOCapacityReductions::RunwayNonPeriod & out);
};


#endif /* LPCWHATIFCLOSURE_H_ */
