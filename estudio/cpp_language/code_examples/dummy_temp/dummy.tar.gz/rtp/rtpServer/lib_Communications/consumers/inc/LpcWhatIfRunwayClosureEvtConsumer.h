/*
 * LpcWhatIfRunwayClosureEvtConsumer.h
 *
 *  Created on: 19/05/2015
 */


#ifndef __LPC_WHATIF_RUNWAYCLOSURE_EVT_CONSUMER_H__
#define __LPC_WHATIF_RUNWAYCLOSURE_EVT_CONSUMER_H__

#include <IOWhatIFEventsiBContract.h>
#include <LclogStream.h>


class LpcWhatIfRunwayClosureEvtConsumer: public iBG::IOWhatIFEvents::RunwayClosuresEventSubscriberListener
{
   public:

      void init(void);
      void on_data_available(iBG::IOWhatIFEvents::RunwayClosuresEventSubscriber & sub);
};


#endif /* __LPC_WHATIF_RUNWAYCLOSURE_EVT_CONSUMER_H__ */
