/*
 * LpcCreateMeteoNowcastEvtConsumer.h
 *
 *  Created on: 10/06/2014
 *      Author: gpfernandez
 */

#ifndef LPCCREATEMETEONOWCASTEVTCONSUMER_H_
#define LPCCREATEMETEONOWCASTEVTCONSUMER_H_

#include <IOMeteoInfoEventsiBContract.h>
#include <LpiMeteoInfo.h> // LpiCreateMeteo


class LpcCreateMeteoNowcastEvtConsumer: 
  public iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListSubscriber &sub);

private:
   LpiCreateMeteo handle_one_meteo_data(const IOMeteoInfo::Meteo &next_meteo_data);

};



#endif /* LPCCREATEMETEONOWCASTEVTCONSUMER_H_ */
