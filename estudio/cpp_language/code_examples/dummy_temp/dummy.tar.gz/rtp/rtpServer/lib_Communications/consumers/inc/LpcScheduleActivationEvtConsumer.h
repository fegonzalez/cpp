/*
 * LpcScheduleActivationEvtConsumer.h
 *
 *  Created on: 14/07/2014
 *      Author: gpfernandez
 */

#ifndef LPSCHEDULEACTIVATIONEVTCONSUMER_H_
#define LPSCHEDULEACTIVATIONEVTCONSUMER_H_

#include <IOScheduleActivationEventsiBContract.h>
#include <LclogStream.h>


class LpcScheduleActivationEvtConsumer: public iBG::IOScheduleActivationEvents::ScheduleActivationEventSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IOScheduleActivationEvents::ScheduleActivationEventSubscriber &sub);;

};
#endif /* LPSCHEDULEACTIVATIONEVTCONSUMER_H_ */
