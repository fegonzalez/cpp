/*
 * LpcScheduleActivationEvtConsumer.h
 *
 *  Created on: 14/07/2014
 *      Author: gpfernandez
 */

#ifndef LPSCHEDULEACTIVATIONEVTCONSUMER_H_
#define LPSCHEDULEACTIVATIONEVTCONSUMER_H_

#include <IOScheduleRTPEventsiBContract.h>
#include <LclogStream.h>


class LpcScheduleActivationEvtConsumer: public iBG::IOScheduleRTPEvents::ActivateScheduleFromHmiSubscriberListener
{
public:
   void init(void);

   void on_data_available(iBG::IOScheduleRTPEvents::ActivateScheduleFromHmiSubscriber &sub);;

};
#endif /* LPSCHEDULEACTIVATIONEVTCONSUMER_H_ */
