/*
 * LpcOptimalSchedule.cc
 *
 *  Created on: 01/02/2014
 *      Author: gpfernandez
 */


#include <string>

#include "LpcOptimalSchedule.h"
#include <LcuStringArrayConvUtils.h>
#include "LpcADO.h"
#include "LpcKpis.h"

#include <LctimTimeUtils.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>

#include <LctimVirtualClock.h>
#include "LpcCalculationReason.h"
#include "LpcActivationType.h"


void Posix_time2OptionalTime(const boost::posix_time::ptime & pos_time,
                             IOTim::OptionalTimeU & optionaltime)
{
   posix_time::ptime epoch(boost::gregorian::date(1970,1,1));

   if (pos_time.is_not_a_date_time())
   {
      optionaltime._d = false;
   }
   else
   {
      optionaltime._d = true;
      optionaltime._u.value = ((pos_time)- epoch).total_seconds();
   }
}


void LpcOptimalSchedule::convert2OptimalSchedule(const LpiSchedule & in,
                                                 IOSchedule::Schedule & out)
{
   posix_time::ptime timeAndDate = LctimVirtualClock::Get().getTime();

   LcuStringArrayConvUtils::String2Array(LctimTimeUtils::formatTime(timeAndDate, "%H%M/%d%m%y"), out.timeAndDate);

   LpcCalculationReason::convertLpi2IOCalculationReason(in.getCalculationReason(), out.calculationReason);

   out.activationType = LpcActivationType::LpiToIOType(in.getOrigin());

   out.frozenPeriod = in.getFrozenPeriod();

   unsigned int numberOfIntervals = in.getScheduleTimeLine().getAllScheduleIntervals().size();

   //Fill all timelines with one loop
   IOSchedule::ScheduleTimeLine timeLineIO;
   IOKPIs::PerformanceInfo performanceInfoIO;
   IOCapacity::CapacityInfo capacityInfoIO;
   IOSchedule::Demand demandIO;

   timeLineIO.ensure_length(numberOfIntervals, numberOfIntervals);
   performanceInfoIO.performanceTimeLine.ensure_length(numberOfIntervals, numberOfIntervals);
   capacityInfoIO.ensure_length(numberOfIntervals, numberOfIntervals);

   for (unsigned int i = 0; i < numberOfIntervals; i++)
   {
      IOSchedule::TimeIntervalData intervalDataIO;
      IOKPIs::PerformanceIntervalData performanceIntervalDataIO;
      IOCapacity::CapacityIntervalData capacityIntervalDataIO;

      LpiTimeIntervalData timeIntervalInterface = in.getScheduleTimeLine().getScheduleInterval(i);

      string name = timeIntervalInterface.getName();
      string intervalBegin = timeIntervalInterface.getBeginTime();
      string intervalEnd = timeIntervalInterface.getEndTime();

      LpiPerformanceIntervalData performanceIntervalInterface = in.getPerformanceInfo().getPerformanceIntervalData(i);
      LpiCapacityIntervalData capacityIntervalInterface = in.getCapacityInfo().getCapacityIntervalData(i);

      LcuStringArrayConvUtils::String2Array(name, intervalDataIO.intervalName);
      LcuStringArrayConvUtils::String2Array(intervalBegin, intervalDataIO.startTimeAndDate);
      LcuStringArrayConvUtils::String2Array(intervalEnd, intervalDataIO.endTimeAndDate);

      LpcOptimalSchedule::convert2TimeIntervalData(timeIntervalInterface, intervalDataIO);

      LpcOptimalSchedule::convert2RunwaysIntervalData(performanceIntervalInterface,
                                                      performanceIntervalDataIO.runwayKPIs,
                                                      capacityIntervalInterface,
                                                      capacityIntervalDataIO.runwaysCapacities);


      LcuStringArrayConvUtils::String2Array(name, performanceIntervalDataIO.intervalName);
      LcuStringArrayConvUtils::String2Array(intervalBegin, performanceIntervalDataIO.startTimeAndDate);
      LcuStringArrayConvUtils::String2Array(intervalEnd, performanceIntervalDataIO.endTimeAndDate);

      LpcOptimalSchedule::convert2AirportIntervalKPIs(performanceIntervalInterface.getAirportIntevalKPIs(),
                                                      performanceIntervalDataIO.airportKPIs);

      LcuStringArrayConvUtils::String2Array(name, capacityIntervalDataIO.intervalName);
      LcuStringArrayConvUtils::String2Array(intervalBegin, capacityIntervalDataIO.startTimeAndDate);
      LcuStringArrayConvUtils::String2Array(intervalEnd, capacityIntervalDataIO.endTimeAndDate);

      LpcOptimalSchedule::convert2AirportIntervalCapacityInfo(capacityIntervalInterface.getAirportCapacities(),
                                                              capacityIntervalDataIO.airportCapacities);

      timeLineIO.set_at(i, intervalDataIO);
      performanceInfoIO.performanceTimeLine.set_at(i, performanceIntervalDataIO);
      capacityInfoIO.set_at(i, capacityIntervalDataIO);
   }

   //AirportTotalKPIs
   LpcOptimalSchedule::convert2AirportTotalKPIs(in.getPerformanceInfo().getAirportTotalKPIs(),
                                                performanceInfoIO.airportKPIs);

   //ComparativeKPIs
   LpcComparativeKpis::convertLpi2IOComparativeKpis(in.getPerformanceInfo().getComparativeKPIs(),
                                                    performanceInfoIO.comparationKPIs);

   out.timeline = timeLineIO;
   
   out.performanceInfo = performanceInfoIO;
   out.capacityInfo = capacityInfoIO;

   //Total schedule demand
   LpiScheduleDemand totalDemand = in.getDemandData();

   demandIO.intentionalDemand = LpcAdo::Lpi2IO(totalDemand.rIntentionalDemand);
   demandIO.inheritedDemand   = LpcAdo::Lpi2IO(totalDemand.rInheritedDemand);
   demandIO.totalDemand       = LpcAdo::Lpi2IO(totalDemand.rTotalDemand);

   out.totalDemand = demandIO;

   //Fill Scheduled Flight Plans
   std::vector<LpiScheduledFlightPlan> fps = in.getFPList().getFpList();

   LpcOptimalSchedule::convert2ScheduledFPs(in.getFPList(), out.flightPlans);

 }


void LpcOptimalSchedule::convert2ScheduledFPs(const LpiFPList & in,
                                              IOSchedule::ScheduledFlightPlans & out)
{
   IOSchedule::ScheduledFlightPlans flightPlanList;

   unsigned int numberOfFlights = in.getFpList().size();

   flightPlanList.ensure_length(numberOfFlights, numberOfFlights);

   for (unsigned int i = 0; i < numberOfFlights; i++)
   {
      IOSchedule::FlightPlan fp;

      memset(&fp, 0, sizeof(IOSchedule::FlightPlan));

      LpiScheduledFlightPlan flightPlan = in.getFpList(i);

      LcuStringArrayConvUtils::String2Array(flightPlan.getcallsign(), fp.callsign);
      LcuStringArrayConvUtils::String2Array(flightPlan.getdepAerodrome(), fp.depAerodrome);
      LcuStringArrayConvUtils::String2Array(flightPlan.getarrAerodrome(), fp.arrAerodrome);
      LcuStringArrayConvUtils::String2Array(flightPlan.getopType(), fp.opType);

      if(flightPlan.getopType().compare("DEP") == 0)
      {
         DepartureInfo departureTimes = flightPlan.getdepartureTimes();

         Posix_time2OptionalTime(departureTimes.getitot(), fp.departureTimes.itot);
         Posix_time2OptionalTime(departureTimes.getstot(), fp.departureTimes.stot);
         Posix_time2OptionalTime(departureTimes.getftot(), fp.departureTimes.ftot);

         if (departureTimes.getEobt())
         {
            Posix_time2OptionalTime(*(departureTimes.getEobt()), fp.departureTimes.eobt);
         }
      }
      else if(flightPlan.getopType().compare("ARR") == 0)
      {
         ArrivalInfo arrivalTimes = flightPlan.getarrivalTimes();

         Posix_time2OptionalTime(arrivalTimes.getildt(), fp.arrivalTimes.ildt);
         Posix_time2OptionalTime(arrivalTimes.getsldt(), fp.arrivalTimes.sldt);
         Posix_time2OptionalTime(arrivalTimes.getfldt(), fp.arrivalTimes.fldt);

         if (arrivalTimes.getEobt())
         {
            Posix_time2OptionalTime(*(arrivalTimes.getEobt()), fp.arrivalTimes.eobt);
         }
      }

      fp.forecastDelay    = flightPlan.getforecastDelay();
      fp.punctualityDelay = flightPlan.getpunctualityDelay();

      LcuStringArrayConvUtils::String2Array<IOConst::RWY_SIZE>(flightPlan.getAssignedRunway(), fp.assignedRunway);

      if (flightPlan.getTurnRoundDelayed())
      {
         fp.closedTurnRound = true;
      }
      else
      {
         fp.closedTurnRound = false;
      }

      flightPlanList.set_at(i, fp);
    }

   out = flightPlanList;
}


void LpcOptimalSchedule::convert2TimeIntervalData(const LpiTimeIntervalData & in,
                                                  IOSchedule::TimeIntervalData & out)
{
   LpiRS_Scheduled rs = in.getRSScheduled();

   LcuStringArrayConvUtils::String2Array(rs.getRunwaySystem(), out.plannedRS.rsName);
   LcuStringArrayConvUtils::String2Array(rs.getRunwayArr(), out.plannedRS.runwaysArr);
   LcuStringArrayConvUtils::String2Array(rs.getRunwayDep(), out.plannedRS.runwaysDep);
   LcuStringArrayConvUtils::String2Array(rs.getConfiguration(), out.plannedRS.configuration);

   LpiScheduleDemand demand = in.getDemand();

   out.demand.intentionalDemand = LpcAdo::Lpi2IO(demand.rIntentionalDemand);
   out.demand.inheritedDemand   = LpcAdo::Lpi2IO(demand.rInheritedDemand);
   out.demand.totalDemand       = LpcAdo::Lpi2IO(demand.rTotalDemand);
}


void LpcOptimalSchedule::convert2AirportIntervalKPIs(const LpiAirportIntervalKPIs & in,
                                                     IOKPIs::AirportIntervalKPIs & out)
{
   out.realAcceptedFPs = LpcAdo::Lpi2IO(in.getrealAcceptedFps());

   out.shortage        = LpcAdo::Lpi2IO(in.getshortage());
   out.shortageWA      = LpcAdo::Lpi2IO(in.getshortageWA());

   out.averageDelayFPs = LpcAdo::Lpi2IO(in.getAverageForecastedDelay_DelayedFPs());
   out.maxDelay        = LpcAdo::Lpi2IO(in.getMaxForecastedDelay());
   out.punctuality     = LpcAdo::Lpi2IO(in.getPercentagePunctuality());

   out.averageDelayFPsWA = LpcAdo::Lpi2IO(in.getAverageForecastedDelay_DelayedFPsWA());
   out.maxDelayWA        = LpcAdo::Lpi2IO(in.getMaxForecastedDelayWA());
   out.punctualityWA     = LpcAdo::Lpi2IO(in.getPercentagePunctualityWA());
}


void LpcOptimalSchedule::convert2AirportIntervalCapacityInfo(const LpiAirportIntervalCapacityInfo & in,
                                                             IOCapacity::AirportIntervalCapacityInfo & out)
{
   out.maxCapacity     = LpcAdo::Lpi2IO(in.getmaxCapacity());
   out.maxCapacityWA   = LpcAdo::Lpi2IO(in.getmaxCapacityWA());
   out.twyCapacity     = LpcAdo::Lpi2IO(in.gettwyCapacity());
   out.twyCapacityWA   = LpcAdo::Lpi2IO(in.gettwyCapacityWA());
   out.rsCapacity      = LpcAdo::Lpi2IO(in.getrsCapacity());
   out.rsCapacityWA    = LpcAdo::Lpi2IO(in.getrsCapacityWA());
}


void LpcOptimalSchedule::convert2RunwaysIntervalData(const LpiPerformanceIntervalData & inPerformance,
                                                     IOKPIs::RunwaysKPIs & outKpis,
                                                     const LpiCapacityIntervalData & inCapacity,
                                                     IOCapacity::RunwaysIntervalCapacities & outCapacities)
{
   unsigned int numberOfRunways = inPerformance.getRwysKPIs().size();

   outKpis.ensure_length(numberOfRunways, numberOfRunways);
   outCapacities.ensure_length(numberOfRunways, numberOfRunways);

   for (unsigned int i = 0; i < numberOfRunways; i++)
   {
      IOKPIs::RunwayIntervalKPIs runwayKPIsIO;
      IOCapacity::RunwayIntervalCapacityInfo runwayCapacityIO;

      LpiRunwayIntervalKPIs runwayKPIsInterfaceData = inPerformance.getRwysKPIs(i);
      LpiRunwayIntervalCapacityInfo runwayCapacityInterfaceData = inCapacity.getRwysCapacities(i);

      LcuStringArrayConvUtils::String2Array(runwayKPIsInterfaceData.getrwyName(), runwayKPIsIO.rwyName);
      LcuStringArrayConvUtils::String2Array(runwayKPIsInterfaceData.getrwyName(), runwayCapacityIO.rwyName);

      runwayKPIsIO.rwyRealAcceptedFps  = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getrwyRealAcceptedFps());
      runwayKPIsIO.rwyShortage         = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getrwyShortage());
      runwayKPIsIO.rwyShortageWA       = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getrwyShortageWA());

      runwayKPIsIO.rwyAverageDelayFPs = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getRwyAverageDelay_DelayedFPs());
      runwayKPIsIO.rwyMaxDelay        = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getRwyMaxForecastedDelay());
      runwayKPIsIO.rwyPunctuality     = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getRwyPercentagePunctuality());

      runwayKPIsIO.rwyAverageDelayFPsWA = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getRwyAverageDelay_DelayedFPsWA());
      runwayKPIsIO.rwyMaxDelayWA        = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getRwyMaxForecastedDelayWA());
      runwayKPIsIO.rwyPunctualityWA     = LpcAdo::Lpi2IO(runwayKPIsInterfaceData.getRwyPercentagePunctualityWA());

      runwayCapacityIO.rwyCapacity      = LpcAdo::Lpi2IO(runwayCapacityInterfaceData.getrwyCapacity());
      runwayCapacityIO.rwyCapacityWA    = LpcAdo::Lpi2IO(runwayCapacityInterfaceData.getrwyCapacityWA());

      outKpis.set_at(i, runwayKPIsIO);
      outCapacities.set_at(i, runwayCapacityIO);
   }
}


void LpcOptimalSchedule::convert2AirportTotalKPIs(const LpiAirportTotalKPIs & in,
                                                  IOKPIs::AirportTotalKPIs & out)
{
   out.totalAccepted                = LpcAdo::Lpi2IO(in.getTotalAccepted());
   out.totalShortage                = LpcAdo::Lpi2IO(in.getTotalShortage());
   out.maxForecastedDelay           = LpcAdo::Lpi2IO(in.getmaxForecastedDelay());
   out.maxForecastedDelayWA         = LpcAdo::Lpi2IO(in.getmaxForecastedDelayWA());
   out.averageForecastedDelay       = LpcAdo::Lpi2IO(in.getaverageForecastedDelay());
   out.averageForecastedDelayWA     = LpcAdo::Lpi2IO(in.getaverageForecastedDelayWA());
   out.maxPunctualityDelay          = LpcAdo::Lpi2IO(in.getmaxPunctualityDelay());
   out.maxPunctualityDelayWA        = LpcAdo::Lpi2IO(in.getmaxPunctualityDelayWA());
   out.maxAveragePunctualityDelay   = LpcAdo::Lpi2IO(in.getaveragePunctualityDelay());
   out.maxAveragePunctualityDelayWA = LpcAdo::Lpi2IO(in.getaveragePunctualityDelayWA());
   out.punctualFPs                  = LpcAdo::Lpi2IO(in.getpunctualFPs());
   out.delayedFPs                   = LpcAdo::Lpi2IO(in.getdelayedFPs());
   out.percentagePunctual           = LpcAdo::Lpi2IO(in.getpercentagePunctual());
   out.percentagePunctualWA         = LpcAdo::Lpi2IO(in.getpercentagePunctualWA());

   out.averageForecastedDelayDelayedFPs = LpcAdo::Lpi2IO(in.getAverageForecastedDelayDelayedFps());
   out.averageForecastedDelayDelayedFPsWA = LpcAdo::Lpi2IO(in.getAverageForecastedDelayDelayedFpsWA());
}
