/*
 * LpcMeteoTimeline.h
 *
 *  Created on: 19/03/2015
 *      Author: mbegega
 */

#ifndef LPCMETEOTIMELINE_H_
#define LPCMETEOTIMELINE_H_

#include <IOMeteoTimeline.h>
#include <LpiMeteoTimeline.h>


class LpcMeteoTimeline
{
   public:

     static void convert2IO(const LpiMeteoTimeline & in,
			    IOMeteoTimeline::MeteoTimeLine & out);
     
     static void convert(const IOMeteoTimeline::MeteoTimeLine & in,
			 LpiMeteoTimeline & out);
     
   private:

};


#endif /* LPCMETEOTIMELINE_H_ */
