#include "LpcCreateMeteoNowcastEvtConsumer.h"
#include <LpiMeteoNowcastEvt.h>
#include <IOMeteoInfo.h>
#include <IOMeteoInfoEvents.h>
#include <LpiMeteoInfo.h>
#include <LpcMeteoInfo.h>
#include <LpdComponent.h>
#include <LpdFunctions.h>
#include <LcuStringArrayConvUtils.h>
#include <LclogStream.h>


#ifdef TRACE_OUT
#include <iostream>  //debug cout & clog
#include <cstdlib>   //debug __FILE__
#endif

void LpcCreateMeteoNowcastEvtConsumer::init(void)
{
  LclogStream::instance(LclogConfig::E_RTP).notify()
    << "[ RTP-MeteoNowcast-CONSUMER: vtConsumer init]"
    << "\t file: " << __FILE__
    << " ; FN: " << __func__
    << " ; LINE:  " << __LINE__
    << std::endl;

    iB::SubscriberId sid("IOMeteoInfoEvents::CreateMeteoNowcastEventList");
    iB::SubscriptionProfile sprofile;

    iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListSubscriber &subscriber =
      iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListCreateSubscriber
      (sid, sprofile);
    subscriber.addListener(this);
}

//------------------------------------------------------------------------------

void LpcCreateMeteoNowcastEvtConsumer::on_data_available
(iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListSubscriber &sub)
{
  LclogStream::instance(LclogConfig::E_RTP).notify()
    << "[RECEIVED METEO_NOWCAST EVENT]"
    << "\t file: " << __FILE__
    << " ; FN: " << __func__
    << " ; LINE:  " << __LINE__
    << std::endl;

  iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListSubscriber::DataList dl;
  iB::DIList il;
  sub.getData(dl, il);

  iBG::IOMeteoInfoEvents::CreateMeteoNowcastEventListSubscriber::
    DataList::iterator dit = dl.begin();
  iB::DIList::iterator iit = il.begin();
  int pos = 0;

  for (; 
       (dit != dl.end()) && (iit != il.end()); 
       ++dit, ++iit, pos++)
  {
    if (iit->isValid())
    {
      IOMeteoInfoEvents::MeteoList ioMeteoList = dit->meteos;
      LpiCreateMeteoList meteoNowList; // list of meteo reports (one per airport)
	    
      bool aux_NewData = false;

      for (int x = 0; x < ioMeteoList.length(); x++) 
      {
    	  IOMeteoInfo::Meteo next_meteo_data = ioMeteoList.get_at(x);
    	  std::string string_airport;
    	  LcuStringArrayConvUtils::Array2String
		  	  (next_meteo_data.messageIdentification.airport, string_airport);
    	  if(managedAirport(string_airport))
    	  {
    		aux_NewData = true;
    	    meteoNowList.push_back(handle_one_meteo_data(next_meteo_data));
    	  }
    	  else
    	  {
    		LclogStream::instance(LclogConfig::E_RTP).warning()
    		      << "Bad Meteo Info received. Airport not found "
    		      << '(' << string_airport << ')'
    			  << " . Meteo data ignored."
    		      << " ; file: " << __FILE__
    		      << " ; FN: " << __func__
    		      << " ; LINE:  " << __LINE__
    		      << std::endl;
    	  }
      }

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug()
      //std::cerr << "\nDEBUG: [RECEIVED METEO_NOWCAST EVENT] list Meteos:"
	<< "[RECEIVED METEO_NOWCAST EVENT] list Meteos:"
	<< " : File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< " ; data: \n"
	<< meteoNowList
	<< std::endl;
#endif

      ///@warning The data is stored within the 'LpiMeteoNowcastEvt'
      ///         object. this is the rtp server's "DB"
      ///         Then the data is updated (wetness,... calculations),
      ///         and eventually, the publisher ( LpcMeteoNowcastEvtPublisher::
      ///         publish(const LpiMeteoNowcastEvt &evt) )
      ///	      will read the data and send it to the HMI.

      if(aux_NewData)
      {
        LpiMeteoNowcastEvt event;
        event.setMeteoNowcast(meteoNowList);
        LpdComponent::Get().consume(event);
      }

    }//end-if(iit->isValid())
  }

}

//------------------------------------------------------------------------------

LpiCreateMeteo  LpcCreateMeteoNowcastEvtConsumer::handle_one_meteo_data 
(const IOMeteoInfo::Meteo &next_meteo_data)
{
  LpiCreateMeteo new_meteo;

  LpcMeteoInfo::convert2Meteo(next_meteo_data, new_meteo);
  new_meteo.setMessageTimeandDate(LctimTimeUtils::getFromString
			    (next_meteo_data.messageIdentification.
			     timeAndDate));
  new_meteo.setCalculationReason(LpiCalculationReason::E_NEW_METEO_NOWCAST);

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "------new meto data------"
    << new_meteo
    << " ; file: " << __FILE__
    << " ; FN: " << __func__
    << " ; LINE:  " << __LINE__
    << std::endl;


//  std::cerr << "\n\n RRRRRRRRRRRRRRRRRRRRRRRRR  new_meteo:"
//    << "------new meto data------"
//    << new_meteo
//    << " ; file: " << __FILE__
//    << " ; FN: " << __func__
//    << " ; LINE:  " << __LINE__
//    << std::endl;
#endif
  return new_meteo;
}
