/*
 * LpcKpis.cc
 *   Created on: 24/09/2014
 *   Author:
*/

#include <boost/algorithm/string/trim.hpp>

#include <IOConstant.h>

#include "LpiADO.h"
#include "LpiWarningsAlerts.h"

#include <LcuStringArrayConvUtils.h>
#include "LpcADO.h"
#include "LpcKpis.h"


void LpcComparativeKpis::convertLpi2IOComparativeKpis (const LpiComparativeKpis & in,
                                                       IOKPIs::ComparativeKpis  & out)
{
   vector<LpiIntervalKpi> timeLine = in.getKpisPerInterval();

   out.kpisTimeLine.ensure_length(timeLine.size(), timeLine.size());

   for (unsigned int i = 0; i < timeLine.size(); i++)
   {
      IOKPIs::IntervalKpi intervalData;

      LcuStringArrayConvUtils::String2Array<IOConst::DATE_SIZE>(timeLine[i].getStartTimeAndDate(), intervalData.startTimeAndDate);
      LcuStringArrayConvUtils::String2Array<IOConst::DATE_SIZE>(timeLine[i].getEndTimeAndDate(), intervalData.endTimeAndDate);

      LpiIntervalDataKpis deltas = timeLine[i].getDeltaKpis();

      // Delta Kpis
      intervalData.deltaKpis.shortage = LpcAdo::Lpi2IO(deltas.getShortage());
      intervalData.deltaKpis.airportCapacity = LpcAdo::Lpi2IO(deltas.getAirportCapacity());
      intervalData.deltaKpis.rsCapacity = LpcAdo::Lpi2IO(deltas.getRSCapacity());
      intervalData.deltaKpis.maxForecastedDelay = LpcAdo::Lpi2IO(deltas.getMaxForecastedDelay());
      intervalData.deltaKpis.percentagePunctual = LpcAdo::Lpi2IO(deltas.getPercentagePunctual());
      intervalData.deltaKpis.averageForecastedDelay_DelayedFPs = LpcAdo::Lpi2IO(deltas.getAverageForecastedDelay_DelayedFPs());

      //Delta Kpis warnings
      intervalData.deltaKpis.shortageWA = LpcAdo::Lpi2IO(deltas.getShortageWA());
      intervalData.deltaKpis.airportCapacityWA = LpcAdo::Lpi2IO(deltas.getAirportCapacityWA());
      intervalData.deltaKpis.rsCapacityWA = LpcAdo::Lpi2IO(deltas.getRSCapacityWA());
      intervalData.deltaKpis.maxForecastedDelayWA = LpcAdo::Lpi2IO(deltas.getMaxForecastedDelayWA());
      intervalData.deltaKpis.percentagePunctualWA = LpcAdo::Lpi2IO(deltas.getPercentagePunctualWA());
      intervalData.deltaKpis.averageForecastedDelay_DelayedFPsWA = LpcAdo::Lpi2IO(deltas.getAverageForecastedDelay_DelayedFPsWA());

      LpiIntervalDataKpis relatives = timeLine[i].getRelativeKpis();

      // Relative Kpis
      intervalData.relativeKpis.shortage = LpcAdo::Lpi2IO(relatives.getShortage());
      intervalData.relativeKpis.airportCapacity = LpcAdo::Lpi2IO(relatives.getAirportCapacity());
      intervalData.relativeKpis.rsCapacity = LpcAdo::Lpi2IO(relatives.getRSCapacity());
      intervalData.relativeKpis.maxForecastedDelay = LpcAdo::Lpi2IO(relatives.getMaxForecastedDelay());
      intervalData.relativeKpis.percentagePunctual = LpcAdo::Lpi2IO(relatives.getPercentagePunctual());
      intervalData.relativeKpis.averageForecastedDelay_DelayedFPs = LpcAdo::Lpi2IO(relatives.getAverageForecastedDelay_DelayedFPs());

      // Relative Kpis warnings
      intervalData.relativeKpis.shortageWA = LpcAdo::Lpi2IO(relatives.getShortageWA());
      intervalData.relativeKpis.airportCapacityWA = LpcAdo::Lpi2IO(relatives.getAirportCapacityWA());
      intervalData.relativeKpis.rsCapacityWA = LpcAdo::Lpi2IO(relatives.getRSCapacityWA());
      intervalData.relativeKpis.maxForecastedDelayWA = LpcAdo::Lpi2IO(relatives.getMaxForecastedDelayWA());
      intervalData.relativeKpis.percentagePunctualWA = LpcAdo::Lpi2IO(relatives.getPercentagePunctualWA());
      intervalData.relativeKpis.averageForecastedDelay_DelayedFPsWA = LpcAdo::Lpi2IO(relatives.getAverageForecastedDelay_DelayedFPsWA());


      out.kpisTimeLine.set_at(i, intervalData);
   }

}
