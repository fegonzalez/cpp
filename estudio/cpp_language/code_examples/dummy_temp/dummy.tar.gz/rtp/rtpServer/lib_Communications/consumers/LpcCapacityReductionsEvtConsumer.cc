
#include "LpcCapacityReductionsEvtConsumer.h"
#include <IOCapacityReductions.h>
#include <LpiFlightPlan.h>
#include "LpcCapacityReductions.h"
#include <LpdComponent.h>
#include <string>
#include <LpdbDataBase.h>


void LpcCapacityReductionsEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOCapacityReductionsEvents::CapacityReductionsEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOCapacityReductionsEvents::CapacityReductionsEventSubscriber &subscriber =
             iBG::IOCapacityReductionsEvents::CapacityReductionsEventCreateSubscriber(sid,
                                                                     sprofile);
   subscriber.addListener(this);
}


void LpcCapacityReductionsEvtConsumer::on_data_available(
                        iBG::IOCapacityReductionsEvents::CapacityReductionsEventSubscriber &sub)
{
   iBG::IOCapacityReductionsEvents::CapacityReductionsEventSubscriber::DataList dl;
   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOCapacityReductionsEvents::CapacityReductionsEventSubscriber::DataList::iterator dit
                                                                  = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {
      if(iit->isValid())
      {
         //Obtain data
         IOCapacityReductions::CapacityReductions dds;
         memset(&dds, 0, sizeof( IOCapacityReductions::CapacityReductions));
         dds = dit->capacityReductions;

         //Internal type conversion
         LpiCapacityReductions capacity;
         //Event
         LpiCapacityReductionsEvt event;

         LpcCapacityReductions::convertIOCapacity2LpiCapacity(dds, capacity);

         event.setCapacityReductions(capacity);

         LpdComponent::Get().consume(event);
      }
   }
}



