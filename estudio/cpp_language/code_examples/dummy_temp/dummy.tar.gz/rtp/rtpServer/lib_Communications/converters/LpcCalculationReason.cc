
#include "LpcCalculationReason.h"
#include <IOCommonTypes.h>
#include <LpiCalculationReason.h>

void LpcCalculationReason::convertLpi2IOCalculationReason(const LpiCalculationReason::LpiEnum &in,
                                                          IOCommonTypes::CalculationReason & out)
{
   switch (in)
   {
      case LpiCalculationReason::E_INIT:
         out = IOCommonTypes::E_INIT;
      break;
      case LpiCalculationReason::E_NEW_METEO_NOWCAST:
         out = IOCommonTypes::E_NEW_METEO_NOWCAST;
      break;
      case LpiCalculationReason::E_NEW_METEO_FORECAST:
         out = IOCommonTypes::E_NEW_METEO_FORECAST;
      break;
      case LpiCalculationReason::E_NEW_DEMAND:
         out = IOCommonTypes::E_NEW_DEMAND;
      break;
      case LpiCalculationReason::E_CLOCK:
         out = IOCommonTypes::E_CLOCK;
      break;
      case LpiCalculationReason::E_MANUAL_ACTIVATION:
         out = IOCommonTypes::E_MANUAL_ACTIVATION;
      break;
      case LpiCalculationReason::E_AIRPORT_OPERATIONAL_STATUS_CHANGE:
         out = IOCommonTypes::E_AIRPORT_OPERATIONAL_STATUS_CHANGE;
      break;
      case LpiCalculationReason::E_WHAT_IF_NEW_CRITERIA:
         out = IOCommonTypes::E_WHAT_IF_NEW_CRITERIA;
      break;
      case LpiCalculationReason::E_WHAT_IF_NEW_CRITERIA_UPDATE:
         out = IOCommonTypes::E_WHAT_IF_NEW_CRITERIA_UPDATE;
      break;
      case LpiCalculationReason::E_WHAT_IF_MANUAL_EDITION:
         out = IOCommonTypes::E_WHAT_IF_MANUAL_EDITION;
      break;
      case LpiCalculationReason::E_WHAT_IF_MANUAL_EDITION_UPDATE:
         out = IOCommonTypes::E_WHAT_IF_MANUAL_EDITION_UPDATE;
      break;
      case LpiCalculationReason::E_WHAT_IF_DELETION:
         out = IOCommonTypes::E_WHAT_IF_DELETION;
      break;
      case LpiCalculationReason::E_WHAT_IF_APPLY_ON_ACTIVE:
         out = IOCommonTypes::E_WHAT_IF_APPLY_ON_ACTIVE;
      break;
      case LpiCalculationReason::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE:
         out = IOCommonTypes::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE;
      break;
      case LpiCalculationReason::E_WHAT_IF_NEW_OPTIMAL:
         out = IOCommonTypes::E_WHAT_IF_NEW_OPTIMAL;
      break;
      case LpiCalculationReason::E_WHAT_IF_NEW_OPTIMAL_UPDATE:
         out = IOCommonTypes::E_WHAT_IF_NEW_OPTIMAL_UPDATE;
      break;
      case LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE:
         out = IOCommonTypes::E_WHAT_IF_BEST_POINT;
      break;
      case LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_UPDATE:
         out = IOCommonTypes::E_WHAT_IF_BEST_POINT_UPDATE;
      break;
      case LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE:
         out = IOCommonTypes::E_WHAT_IF_BEST_POINT_FOR_ACTIVE;
      break;
      case LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE_UPDATE:
         out = IOCommonTypes::E_WHAT_IF_BEST_POINT_FOR_ACTIVE_UPDATE;
      break;
      default:
      break;
   }
}

//------------------------------------------------------------------------------


void LpcCalculationReason::convertIO2LpiCalculationReason
(const IOCommonTypes::CalculationReason &in,
 LpiCalculationReason::LpiEnum & out)
{
    switch (in)
    {
    case IOCommonTypes::E_INIT:
        out = LpiCalculationReason::LpiEnum::E_INIT;
        break;
    case IOCommonTypes::E_NEW_METEO_NOWCAST:
        out = LpiCalculationReason::LpiEnum::E_NEW_METEO_NOWCAST;
        break;
    case IOCommonTypes::E_NEW_METEO_FORECAST:
        out = LpiCalculationReason::LpiEnum::E_NEW_METEO_FORECAST;
        break;
    case IOCommonTypes::E_NEW_DEMAND:
        out = LpiCalculationReason::LpiEnum::E_NEW_DEMAND;
        break;
    case IOCommonTypes::E_CLOCK:
        out = LpiCalculationReason::LpiEnum::E_CLOCK;
        break;
    case IOCommonTypes::E_MANUAL_ACTIVATION:
        out = LpiCalculationReason::LpiEnum::E_MANUAL_ACTIVATION;
        break;
    case IOCommonTypes::E_AIRPORT_OPERATIONAL_STATUS_CHANGE:
        out = LpiCalculationReason::LpiEnum::E_AIRPORT_OPERATIONAL_STATUS_CHANGE;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_CRITERIA:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_CRITERIA;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_CRITERIA_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_CRITERIA_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_MANUAL_EDITION:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_MANUAL_EDITION;
        break;
    case IOCommonTypes::E_WHAT_IF_MANUAL_EDITION_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_MANUAL_EDITION_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_DELETION:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_DELETION;
        break;
    case IOCommonTypes::E_WHAT_IF_APPLY_ON_ACTIVE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_APPLY_ON_ACTIVE;
        break;
    case IOCommonTypes::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_OPTIMAL:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_OPTIMAL;
        break;
    case IOCommonTypes::E_WHAT_IF_NEW_OPTIMAL_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_NEW_OPTIMAL_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE_UPDATE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT_FOR_ACTIVE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE;
        break;
    case IOCommonTypes::E_WHAT_IF_BEST_POINT_FOR_ACTIVE_UPDATE:
        out = LpiCalculationReason::LpiEnum::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE_UPDATE;
        break;
    default:
        break;
    }
}

