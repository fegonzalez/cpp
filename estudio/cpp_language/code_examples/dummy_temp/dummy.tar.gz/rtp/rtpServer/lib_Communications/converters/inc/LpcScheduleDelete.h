#ifndef __LPC_SCHEDULE_DELETE_H__
#define __LPC_SCHEDULE_DELETE_H__

#include <vector>
#include <IOScheduleDelete.h>

class LpcScheduleDelete
{
   public:
      static void ConvertIO2Lpi(const IOScheduleDelete::ScheduleDelete &in,
                                int & out);

      static void ConvertLpi2IO(const std::vector<int> & in,
                                IOScheduleDelete::ScheduleAutomaticDelete & out);
};


#endif /* __LPC_SCHEDULE_DELETE_H__ */
