
#include "LpcMeteoInfo.h"
#include <LcuStringArrayConvUtils.h>
#include <LctimTimeUtils.h>
#include <LcuUnitConversionUtils.h>
#include <LcmetFunction.h>
#include <LcmetConstants.h>
#include <LcmetWindVector.h>
#include <LpdComponent.h>
#include <LpiMeteoTimeline.h>
#include <LpiAdaptationAirportsInfo.h>
#include <LpcCalculationReason.h>
#include <LpcUtils.h>
#include <IOMeteoInfo.h>
#include <IOUpdateMeteoInfo.h>
#include <LpiMeteoInfo.h>
#include <LpcMeteoTimeline.h>


#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>


#include <string>
#include <cmath> // M_PI
#ifndef M_PI
#define M_PI (3.14159265358979323846264338327950288)
#endif
#ifdef TRACE_OUT
#include <iostream>
#endif
#include <cassert>

//==============================================================================

namespace{
  
  /**@fn setLVPActivation

     [1].4.2.2 - Procedimientos de baja visibilidad.

     @return YES/NO exists low visibility conditions for the airport 'airportId'.
     
     @warning If the airport has more than one runway, it is enought that one of them
              requires the activation.
  */
  bool setLVPActivation_Airport
    (const lcmeteo::TYPE_CLOUD_BASE &cloud_base, 
     const lcmeteo::TYPE_HORIZONTAL_VISIVILITY & horizontal_visibility,
     const IOMeteoInfo::RVRperRunwayList &rvr, 
     const std::string &airportId,
     const LpiAdaptationAirportsInfo &airportInfoList);


  /**@fn void setCatILS_Airport

     @brief Calculate the ILS category for the airport 'airportId'

     [1].4.2.2 - Categoría ILS

     @return the calculated ILS category value if exists; 
     @return  Max_ILS_Category::NO_ILS otherwise;
   */
  std::string setCatILS_Airport
    (const lcmeteo::TYPE_CLOUD_BASE &cloud_base, 
     const lcmeteo::TYPE_HORIZONTAL_VISIVILITY & horizontal_visibility,
     const IOMeteoInfo::RVRperRunwayList &rvr,
     const std::string &airportId,
     const LpiAdaptationAirportsInfo &airportInfoList);

    std::string setCatILS
    (const lcmeteo::TYPE_CLOUD_BASE &cloud_base, 
     const lcmeteo::TYPE_HORIZONTAL_VISIVILITY & horizontal_visibility,
     const IOMeteoInfo::RVRperRunwayList &rvr,
     const Airport &currentAirport);

//------------------------------------------------------------------------------

  bool setLVPActivation_Airport
    (const lcmeteo::TYPE_CLOUD_BASE &cloud_base, 
     const lcmeteo::TYPE_HORIZONTAL_VISIVILITY & horizontal_visibility,
     const IOMeteoInfo::RVRperRunwayList &rvr, 
     const std::string &airportId,
     const LpiAdaptationAirportsInfo &airportInfoList)
  {
    lcmeteo::TYPE_CLOUD_BASE LVP_ConditionCloudBase =
      lcmeteo::CLOUD_BASE_MIN;
    lcmeteo::TYPE_HORIZONTAL_VISIVILITY LVP_CondHorizVisibility =
      lcmeteo::HORIZONTAL_VISIVILITY_MIN;
    lcmeteo::TYPE_RVR LVP_ConditionRVR = lcmeteo::RVR_VALUE_MIN;

    //get Adaptation's info for the airport 'airportId'
    Airport currentAirport = airportInfoList[airportId];
    assert(airportId.compare(currentAirport.getAirportName()) == 0);
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << "\t Airport found: <" << currentAirport.getAirportName() << '>'
      << std::endl;
#endif

    // get conditions: cloudbase, HorizontalVisibility, and RVR.
    //
    ///@todo (NICE_TO_HAVE) optimization: map[lcmeteo::LVP_CONDITION_CLOUDBASE]
    for(unsigned int i = 0; 
	i< currentAirport.getLvpActivationConditions().size(); 
	++i) 
    {
      if(currentAirport.getLvpActivationConditions()[i].getConditionName() ==
	 lcmeteo::LVP_CONDITION_CLOUDBASE)
      {
	LVP_ConditionCloudBase = currentAirport.getLvpActivationConditions()[i].
	  getConditionValue();
      }
      else if(currentAirport.getLvpActivationConditions()[i].getConditionName() ==
		 lcmeteo::LVP_CONDITION_HORIZONTAL_VISIBILITY)
      {
	LVP_CondHorizVisibility =
	  currentAirport.getLvpActivationConditions()[i].getConditionValue();
      }
      else if(currentAirport.getLvpActivationConditions()[i].getConditionName() ==
	      lcmeteo::LVP_CONDITION_RVR)
      {
	LVP_ConditionRVR = currentAirport.getLvpActivationConditions()[i].
	  getConditionValue();
      }
    }//end-for-get conditions

    // solve
    std::vector<lcmeteo::TYPE_RVR> rvr_values;
    for( int j = 0; j< rvr.length(); ++j )
    {
      rvr_values.push_back(rvr.get_at(j).rvr);
    }

    return lcmeteo::setLVPActivation(cloud_base,
				     LVP_ConditionCloudBase,
				     horizontal_visibility,
				     LVP_CondHorizVisibility,
				     rvr_values,
				     LVP_ConditionRVR);
}

  //----------------------------------------------------------------------------

  std::string setCatILS_Airport
    (const lcmeteo::TYPE_CLOUD_BASE &cloud_base, 
     const lcmeteo::TYPE_HORIZONTAL_VISIVILITY & horizontal_visibility,
     const IOMeteoInfo::RVRperRunwayList &rvr,
     const std::string &airportId,
     const LpiAdaptationAirportsInfo &airportInfoList)    
{
    //get Adaptation's info for the airport 'airportId'
    Airport currentAirport = airportInfoList[airportId];
    assert(airportId.compare(currentAirport.getAirportName()) == 0);
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << "\t Airport found: <" << currentAirport.getAirportName() << '>'
      << std::endl;
#endif

    return setCatILS(cloud_base,
		       horizontal_visibility,
		       rvr,
		       currentAirport);
}


  //----------------------------------------------------------------------------

  std::string setCatILS
    (const lcmeteo::TYPE_CLOUD_BASE &cloud_base, 
     const lcmeteo::TYPE_HORIZONTAL_VISIVILITY & horizontal_visibility,
     const IOMeteoInfo::RVRperRunwayList &rvr,
     const Airport &currentAirport)
 {
    std::string retval = {""};
    bool retvalFound = false; //return  Max_ILS_Category::NO_ILS if no ILS info found
    CatILsList configurationCatILS = currentAirport.getCatILs();
    
    
   // Getting the ILS category for Cloud_base

   Max_ILS_Category::EnumMax_ILS_Category catCloud =
     Max_ILS_Category::NO_ILS;
   
   // if ANY value exists and it is in-bounds, then assign value and stop
   for (unsigned int i = 0;
	i < configurationCatILS.size();
	++i)
   {
     // boost<optional> usage
     // value.is_initialized() == true => boost<optional> value exists
     // value.get() => getting the value
     if(configurationCatILS[i].getCloudBase().is_initialized())
     {
       if( (configurationCatILS[i].getCloudBase().get().getLowerBound() <=
	   cloud_base) and
	   (cloud_base <
	    configurationCatILS[i].getCloudBase().get().getUpperBound()) )
       {
	 catCloud = configurationCatILS[i].getIdCatILs();
	 retvalFound = true;
	 break;
       }
     }
   }

   
   // Getting the ILS category for RVR
   
   lcmeteo::TYPE_RVR minrvr = rvr.get_at(0).rvr;
    for(int i = 0; i < rvr.length(); i++)
    {
      if (minrvr > rvr.get_at(i).rvr)
      {
	minrvr = rvr.get_at(i).rvr;
      }
    }

   Max_ILS_Category::EnumMax_ILS_Category catRVR =
     Max_ILS_Category::NO_ILS;
   
   // if ANY value exists and it is in-bounds, then assign value and stop
   for (unsigned int i = 0; i < configurationCatILS.size(); ++i)
   {
     if( (configurationCatILS[i].getRvrType().getLowerBound() <= minrvr) and
	 (minrvr < configurationCatILS[i].getRvrType().getUpperBound()) )
     {
       catRVR = configurationCatILS[i].getIdCatILs();
       retvalFound = true;
       break;
     }
   }

   
    // Getting the ILS category for HorizontalVisibility

   Max_ILS_Category::EnumMax_ILS_Category catHV =
     Max_ILS_Category::NO_ILS;
   // if ANY value exists and it is in-bounds, then assign value and stop
   for (unsigned int i = 0;
	i < configurationCatILS.size();
	++i)
   {
     if(configurationCatILS[i].getHorizontalVisibility().is_initialized())
     {
       if( (configurationCatILS[i].getHorizontalVisibility().get().
	    getLowerBound() <= horizontal_visibility) and 
	   (horizontal_visibility <
	    configurationCatILS[i].getHorizontalVisibility().get().
	    getUpperBound()) )
       {
	 catHV = configurationCatILS[i].getIdCatILs();
	 retvalFound = true;
	 break;
       }	 
     }
   }


   // Select the most restrictive (CAT_III_C .. CAT_I), of the
   // three elements (cloud_base, horizontal visibility, RVR):

   if(catHV == Max_ILS_Category::CAT_III_C ||
      catRVR == Max_ILS_Category::CAT_III_C ||
      catCloud == Max_ILS_Category::CAT_III_C)
   {

     ///@warning Max_ILS_Category::EnumMax_ILS_Category EQUIVALENT_TO
     /// LpiMaxILSCategory::LpiEnumCatILS
     retval.append(LpiMaxILSCategory::getEnumAsString
		   (LpiMaxILSCategory::E_CAT_III_C));
   }
   else if(catHV == Max_ILS_Category::CAT_III_B ||
	   catRVR == Max_ILS_Category::CAT_III_B ||
	   catCloud == Max_ILS_Category::CAT_III_B)
   {
     retval.append(LpiMaxILSCategory::getEnumAsString
		   (LpiMaxILSCategory::E_CAT_III_B));
   }
   else if(catHV == Max_ILS_Category::CAT_III_A ||
      catRVR == Max_ILS_Category::CAT_III_A ||
      catCloud == Max_ILS_Category::CAT_III_A)
   {
     retval.append(LpiMaxILSCategory::getEnumAsString
		   (LpiMaxILSCategory::E_CAT_III_A));
   }
   else if(catHV == Max_ILS_Category::CAT_II ||
	   catRVR == Max_ILS_Category::CAT_II ||
	   catCloud == Max_ILS_Category::CAT_II)
   {
     retval.append(LpiMaxILSCategory::getEnumAsString
		   (LpiMaxILSCategory::E_CAT_II));

   }
   else if(catHV == Max_ILS_Category::CAT_I ||
	   catRVR == Max_ILS_Category::CAT_I ||
	   catCloud == Max_ILS_Category::CAT_I)
   {
     retval.append(LpiMaxILSCategory::getEnumAsString
		   (LpiMaxILSCategory::E_CAT_I));
   }
   else
   {
     retval.append(LpiMaxILSCategory::getEnumAsString
		   (LpiMaxILSCategory::E_NO_ILS));
   }

   
   // finally: return found ILS category or  Max_ILS_Category::NO_ILS
   
   if(retvalFound == true)
   {
     return retval;
   }
   else
   {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).warning()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << "\t NO valid ILS category calculated from the received meteo data."
      << std::endl;
#endif

    return (LpiMaxILSCategory::getEnumAsString(LpiMaxILSCategory::E_NO_ILS));
    //return lcmeteo::INVALID_ILS; // runtime_error: unhandled
                                   // Max_ILS_Category value
   }

} //end-setCatILS


//==============================================================================


} // end-of-namespace{

//==============================================================================
 

/**@fn void LpcMeteoInfo::convert2Meteo

                        meteo data
   External system   ----------------->  RTP


   input: idl's (IOMeteoInfo::Meteo) msg. (one airport);

   output: saving to RTP Server's internal meteo info. storage (LpiCreateMeteo);
           where LpiCreateMeteo equivalent to idl's IOUpdate MeteoInfo::Meteo

   @error if the airport (in.messageIdentification.airport) doesn't
          exists in the system (not in DAORTP_AirportsInfo.xml)
*/
void LpcMeteoInfo::convert2Meteo(const IOMeteoInfo::Meteo &in,
				 LpiCreateMeteo &output)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

  std::string aerodrome;
  LcuStringArrayConvUtils::Array2String
    (in.messageIdentification.airport, aerodrome);

  LpiAdaptationAirportsInfo airportInfoList;
  LpiResult result;
  LpdComponent::Get().getAdaptationAirportsInfo(airportInfoList, result);
  assert(result.getResult() == LpiResult::LpiEnum::E_OK);


  ////////////////////////////////////////////////////
  //check that airport is managed by the RTP: already checked in the consumer
  assert(airportInfoList.exists(aerodrome));
  ////////////////////////////////////////////////////
  
  // msgIDentification
  //
  // output.msgTimeAndDate
  posix_time::ptime msgTimeAndDate;
  msgTimeAndDate = LctimTimeUtils::getFromString
    (in.messageIdentification.timeAndDate);
  output.setMessageTimeandDate(msgTimeAndDate);
  //
  // output.airport
  output.setAirport(aerodrome);

  
  /**@warning calculationReason & timeline are not present in the input msg.
     @warning They are copied to the HMI by the publisher at
     LpcMeteoInfo::convert2Meteo.
  */

  // output.meteoInfo
  for(int i=0; i< in.bodyInformation.length(); i++)
  {
    LpiMeteoInfo bodyOut;

    // from IOMeteoInfo::BodyInformation::periodInformation
    posix_time::ptime starTimeAndDate;
    starTimeAndDate = LctimTimeUtils::getFromString
      (in.bodyInformation.get_at(i).periodInformation.startTimeAndDate);
    bodyOut.setStartTimeAndDate(starTimeAndDate);

    posix_time::ptime endTimeAndDate;
    endTimeAndDate = LctimTimeUtils::getFromString
      (in.bodyInformation.get_at(i).periodInformation.endTimeAndDate);
    bodyOut.setEndTimeAndDate(endTimeAndDate);

    bodyOut.setProbability(in.bodyInformation.get_at(i).periodInformation.
			   probability);

    // from MeteoInfo::BodyInformation::MeteorologicalInformation
    //
    // to output.meteoInfo ("IOUpdateMeteoInfo")
    // ::BodyInformation::MeteorologicalInformation"
      
    // windDirection
    if(lcmeteo::WIND_DIRECTION_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.windDirection  &&
       in.bodyInformation.get_at(i).meteorologicalInformation.
       meteorological.windDirection <= lcmeteo::WIND_DIRECTION_MAX)
      {
	bodyOut.setWindDirection(in.bodyInformation.get_at(i).
				 meteorologicalInformation.meteorological.
				 windDirection);
      }
    // windSpeed
    if(lcmeteo::WIND_SPEED_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.windSpeed &&
       in.bodyInformation.get_at(i).meteorologicalInformation.
       meteorological.windSpeed <= lcmeteo::WIND_SPEED_MAX)
      {
	bodyOut.setWindSpeed(in.bodyInformation.get_at(i).
			     meteorologicalInformation.meteorological.
			     windSpeed);
      }

    // gustSpeed
    if(lcmeteo::GUST_SPEED_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.gustSpeed &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       gustSpeed <= lcmeteo::GUST_SPEED_MAX)
    {
      bodyOut.setGustSpeed(in.bodyInformation.get_at(i).
			   meteorologicalInformation.meteorological.gustSpeed);
    }
    // gustDirection
    if(lcmeteo::GUST_DIRECTION_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.gustDirection &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       gustDirection <= lcmeteo::GUST_DIRECTION_MAX)
    {
      bodyOut.setGustDirection(in.bodyInformation.get_at(i).
			       meteorologicalInformation.meteorological.
			       gustDirection);
    }

    // airTemperature
    if(lcmeteo::AIR_TEMPERATURE_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.airTemperature &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       airTemperature <= lcmeteo::AIR_TEMPERATURE_MAX)
    {
      bodyOut.setAirTemperature(in.bodyInformation.get_at(i).
				meteorologicalInformation.meteorological.
				airTemperature);
    }

    // dewPointTemperature
    if(lcmeteo::DEW_POINT_TEMPERATURE_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.dewPointTemperature &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       dewPointTemperature <= lcmeteo::DEW_POINT_TEMPERATURE_MAX)
    {
      bodyOut.setDewPointTemperature(in.bodyInformation.get_at(i).
				     meteorologicalInformation.meteorological.
				     dewPointTemperature);
    }

    // horizontalVisibility
    if(lcmeteo::HORIZONTAL_VISIVILITY_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.horizontalVisibility &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       horizontalVisibility <= lcmeteo::HORIZONTAL_VISIVILITY_MAX)
      {
	bodyOut.setHorizontalVisibility(in.bodyInformation.get_at(i).
					meteorologicalInformation.
					meteorological.horizontalVisibility);
      }
    
    // QHh
    if(lcmeteo::QNH_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.qnh &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       qnh <= lcmeteo::QNH_MAX)
    {
      bodyOut.setQnh(in.bodyInformation.get_at(i).meteorologicalInformation.
		     meteorological.qnh);
    }

    //cloudBase
    if(lcmeteo::CLOUD_BASE_MIN <= in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.cloudBase &&
       in.bodyInformation.get_at(i).meteorologicalInformation.meteorological.
       cloudBase <= lcmeteo::CLOUD_BASE_MAX)
    {
      bodyOut.setCloudbase(in.bodyInformation.get_at(i).
			   meteorologicalInformation.meteorological.cloudBase);
    }

    //significantWeather + wetness + deicing
    std::string significantWeather;    
    LcuStringArrayConvUtils::Array2String
      (in.bodyInformation.get_at(i).
       meteorologicalInformation.meteorological.significantWeather,
       significantWeather);
    bodyOut.setSignificantWeather(significantWeather);
    if(significantWeather.size() > lcmeteo::SIGNIFICANT_WEATHER_MIN_LEN)
    {
      std::string significantWeatherQualifier;
      significantWeatherQualifier.assign
	(significantWeather,
	 lcmeteo::SIGNIFICANT_WEATHER_QUALIFIER_BEGIN,
	 lcmeteo::SIGNIFICANT_WEATHER_QUALIFIER_BEGIN +
	 lcmeteo::SIGNIFICANT_WEATHER_QUALIFIER_LEN);
      bodyOut.setSignificantWeatherQualifier(significantWeatherQualifier);

      std::string signficantWeatherPhenomenon;
      signficantWeatherPhenomenon.assign
	(significantWeather,
	 lcmeteo::SIGNIFICANT_WEATHER_PHENOMENON_BEGIN,
	 lcmeteo::SIGNIFICANT_WEATHER_PHENOMENON_BEGIN +
	 lcmeteo::SIGNIFICANT_WEATHER_PHENOMENON_LEN);
      bodyOut.setSignificantWeatherPhenomenon(signficantWeatherPhenomenon);

      
      // from MeteoInfo::BodyInformation::MeteorologicalInformation
      //
      // calculate output.meteoInfo::wetness ("IOUpdateMeteoInfo")
      //"IOUpdateMeteoInfo::BodyInformation::MeteorologicalInformation::wetness"
      bodyOut.setWetness(lcmeteo::setWetness(signficantWeatherPhenomenon));
      //

      /**@param deicing
         @warning In the RTP project, deicing refers only to the presence of the PL value,
      	  	  	   (see 4.2.2 Información meteorológica, apartado "Asociación a subintervalos")

      	 //using generic setDeicing logic (e.g. used in RMAN)
         bodyOut.setDeicing(lcmeteo::setDeicing
			 (in.bodyInformation.get_at(i).meteorologicalInformation.
			  meteorological.airTemperature,
			  signficantWeatherPhenomenon));
       */
      bodyOut.setDeicing( signficantWeatherPhenomenon.compare(lcmeteo::SIGNIF_WEATHER_PHENOM_ICE_PELLETS) == 0 );
    }

    // from MeteoInfo::BodyInformation::MeteorologicalInformation
    //
    // calculate "IOUpdateMeteoInfo::BodyInformation::
    //            MeteorologicalInformation::lvp_Activation"
    bodyOut.setLvpActivation
      (setLVPActivation_Airport
       (in.bodyInformation.get_at(i).meteorologicalInformation.
	meteorological.cloudBase,
	in.bodyInformation.get_at(i).meteorologicalInformation.
	meteorological.horizontalVisibility,
	in.bodyInformation.get_at(i).meteorologicalInformation.rvrPerRunway,
	aerodrome,
	airportInfoList));


    // from IOMeteoInfo::BodyInformation::MeteorologicalInformation::
    // calculate "IOUpdateMeteoInfo::BodyInformation::
    //            MeteorologicalInformation::required_ILS_Category"
    std::string categoryILS = setCatILS_Airport
      (in.bodyInformation.get_at(i).meteorologicalInformation.
       meteorological.cloudBase,
       in.bodyInformation.get_at(i).meteorologicalInformation.
       meteorological.horizontalVisibility,
       in.bodyInformation.get_at(i).meteorologicalInformation.rvrPerRunway,
       aerodrome,
       airportInfoList);
    bodyOut.setRequiredILSCategory(categoryILS);


    // windVector [1].4.2.2
    lcmeteo::WindVector<lcmeteo::TYPE_WIND_SPEED>
      wind(in.bodyInformation.get_at(i).
	   meteorologicalInformation.meteorological.windSpeed,
	   lcmeteo::flipWindDirection(in.bodyInformation.get_at(i).
				      meteorologicalInformation.
				      meteorological.windDirection));
    bodyOut.setWindVector(wind.theSpeed, wind.theDirection);


    Airport currentAirport = airportInfoList[aerodrome];
    assert(aerodrome.compare(currentAirport.getAirportName()) == 0);
    RunwaysAirportsList runways = currentAirport.getRunways();
    RVRPerRunwayList rvrRunwaysList;

    // for each Runway (in the adaptation file) of airport received (in the msg.)
    for(unsigned int j = 0; j < runways.size(); j++)
    {

     // a) calculate crosswind & tailwind:  // [deg] [1].4.2.2. - Viento

      double lat1 = 0.0;
      if(runways[j].getRunwayThreshold1Latitude().is_initialized())
      {
	lat1 = runways[j].getRunwayThreshold1Latitude().get();
      }
      double lon1 = 0.0;
      if(runways[j].getRunwayThreshold1Longitude().is_initialized())
      {
	lon1 = runways[j].getRunwayThreshold1Longitude().get();
      }
      double lat2 = 0.0;
      if(runways[j].getRunwayThreshold2Latitude().is_initialized())
      {
	lat2 = runways[j].getRunwayThreshold2Latitude().get();
      }
      double lon2 = 0.0;
      if(runways[j].getRunwayThreshold2Longitude().is_initialized())
      {
	lon2 = runways[j].getRunwayThreshold2Longitude().get();
      }
      double beta = lcmeteo::beta(lat1, lon1, lat2, lon2); // [rad]
      double tailwind = lcmeteo::tailWind(wind.theSpeed,
    		  	                          LcuUnitConversionUtils::degrees2Radians(wind.theDirection),
	                                      beta);
      double crosswind = lcmeteo::crossWind(wind.theSpeed,
    		                                LcuUnitConversionUtils::degrees2Radians(wind.theDirection),
											beta);


    	  std::string currentRvr_Name
		  (in.bodyInformation.get_at(i).meteorologicalInformation.rvrPerRunway.get_at(j).name,
				  IOConst::RWY_SIZE);  // RWY_SIZE at IOConstant.idl
    	  trim(currentRvr_Name);

    	  std::string rname = runways[j].getRunwayName();
    	  trim(rname);
    	  // exactly the same name
          if(currentRvr_Name.compare(0, runways[j].getRunwayName().size(), rname) == 0)
          {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << "\t NEw RVR added: <" << currentRvr_Name<< '>'
      << std::endl;
#endif
             currentRvr_Name.clear();
             RVRPerRunway newRwToSave;
             newRwToSave.setName(runways[j].getRunwayName());
             newRwToSave.setTailWind(tailwind);
          	 //tailwind_RMAN = floorf( ((tailwind*100) + 0.5) / 100); // WHY ?
          	 newRwToSave.setCrossWind(crosswind);
          	 //crosswind_RMAN = floorf( ((crosswind*100) + 0.5) / 100); //WHY
             newRwToSave.setRvr((in.bodyInformation.get_at(i).meteorologicalInformation.rvrPerRunway.get_at(j).rvr));
             rvrRunwaysList.setRVRPerRunway(newRwToSave);
          }

    }
    bodyOut.setRvrperRunway(rvrRunwaysList);
    //finally store the BodyInformation element
    output.addMeteoInfoElement(bodyOut);

   }

 }


//------------------------------------------------------------------------------


/**@fn void LpcMeteoInfo::convert2Meteo

                 meteo data
   RTP Server ----------------->  (RTP) HMI    : executed by the server to write (send) the data


   input: internal storage (LpiCreateMeteo/LpiUpdateMeteo) of Meteo info. (one airport);

   output: idl's IOUpdateMeteoInfo::Meteo msg. (one airport);

*/
void LpcMeteoInfo::convert2Meteo(const LpiUpdateMeteo &in, IOUpdateMeteoInfo::Meteo &output)
{

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

  // output.MessageIndentificacion
  LcuStringArrayConvUtils::String2Array
    (LctimTimeUtils::formatTime
     (in.getMessageTimeandDate(), "%H%M/%d%m%y"),
     output.messageIdentification.timeAndDate);
  LcuStringArrayConvUtils::String2Array
    (in.getAirport(),
     output.messageIdentification.airport);


  /**@warning output.calculationReason wasn't filled in the input msg => empty here =>
     it is set prior to be sent to the HMI at
     void LpdBusinessLogicFacade::updateMeteoNowcast()
          that calls  void LpdBusinessLogicFacade::updateMeteoNowcastHmi()
   */
   LpcCalculationReason::convertLpi2IOCalculationReason
     (in.getCalculationReason(), output.calculationReason);


  /**@warning output.timeline wasn't filled in the input msg => empty here =>
  	  it is set prior to be sent to the HMI at
     void LpdBusinessLogicFacade::updateMeteoNowcast()
          that calls  void LpdBusinessLogicFacade::updateMeteoNowcastHmi()
   */
   LpiMeteoTimeline timeline = in.getTimeline();
   LpcMeteoTimeline::convert2IO(timeline, output.timeline);



  // output.bodyInformation
  output.bodyInformation.ensure_length(in.getMeteoInfo().size(),
				       in.getMeteoInfo().size());
  for(unsigned int k=0; k<in.getMeteoInfo().size(); k++)
  {
    IOUpdateMeteoInfo::BodyInformation bodyOut;

    //BodyInformation::PeriodInformation
    LcuStringArrayConvUtils::String2Array
      (LctimTimeUtils::formatTime
       (in.getMeteoInfo()[k].getStartTimeAndDate(),
	"%H%M/%d%m%y"),
       bodyOut.periodInformation.startTimeAndDate);

    LcuStringArrayConvUtils::String2Array
      (LctimTimeUtils::formatTime
       (in.getMeteoInfo()[k].getEndTimeAndDate(),
	"%H%M/%d%m%y"),
       bodyOut.periodInformation.endTimeAndDate);

    bodyOut.periodInformation.probability=in.getMeteoInfo()[k].getProbability();


    //BodyInformation::MeteorologicalInformation::Meteorological
    if(in.getMeteoInfo()[k].getWindDirection())
    {
      bodyOut.meteorologicalInformation.meterological.windDirection =
	*in.getMeteoInfo()[k].getWindDirection();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.windDirection =
	lcmeteo::WIND_DIRECTION_MIN;
    }

    if(in.getMeteoInfo()[k].getWindSpeed())
    {
      bodyOut.meteorologicalInformation.meterological.windSpeed =
	*in.getMeteoInfo()[k].getWindSpeed();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.windSpeed =
	lcmeteo::WIND_SPEED_MIN;
    }

    if(in.getMeteoInfo()[k].getGustDirection())
    {
      bodyOut.meteorologicalInformation.meterological.gustDirection =
	*in.getMeteoInfo()[k].getGustDirection();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.gustDirection =
	lcmeteo::GUST_DIRECTION_MIN;
    }

    if(in.getMeteoInfo()[k].getGustSpeed())
    {
      bodyOut.meteorologicalInformation.meterological.gustSpeed =
	*in.getMeteoInfo()[k].getGustSpeed();
    }
    else
    {
	bodyOut.meteorologicalInformation.meterological.gustSpeed =
	  lcmeteo::GUST_SPEED_MIN;
    }

    if(in.getMeteoInfo()[k].getAirTemperature())
    {
      bodyOut.meteorologicalInformation.meterological.airTemperature =
	*in.getMeteoInfo()[k].getAirTemperature();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.airTemperature
	= lcmeteo::AIR_TEMPERATURE_MIN;
    }

    if(in.getMeteoInfo()[k].getDewPointTemperature())
    {
      bodyOut.meteorologicalInformation.meterological.dewPointTemperature =
	*in.getMeteoInfo()[k].getDewPointTemperature();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.dewPointTemperature =
	lcmeteo::DEW_POINT_TEMPERATURE_MIN;
    }

    if(in.getMeteoInfo()[k].getHorizontalVisibility())
    {
      bodyOut.meteorologicalInformation.meterological.horizontalVisibility =
	*in.getMeteoInfo()[k].getHorizontalVisibility();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.horizontalVisibility =
	lcmeteo::HORIZONTAL_VISIVILITY_MIN;
    }

    if(in.getMeteoInfo()[k].getQnh())
    {
      bodyOut.meteorologicalInformation.meterological.qnh =
	*in.getMeteoInfo()[k].getQnh();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.qnh =
	lcmeteo::QNH_MIN;
    }

    if(in.getMeteoInfo()[k].getCloudbase())
    {
      bodyOut.meteorologicalInformation.meterological.cloudBase =
	*in.getMeteoInfo()[k].getCloudbase();
    }
    else
    {
      bodyOut.meteorologicalInformation.meterological.cloudBase =
	lcmeteo::CLOUD_BASE_MIN;
    }

    LcuStringArrayConvUtils::String2Array
      (in.getMeteoInfo()[k].getSignificantWeather(),
       bodyOut.meteorologicalInformation.meterological.
       significantWeather);


    // BodyInformation::MeteorologicalInformation::Wetness
    LcuStringArrayConvUtils::String2Array
      (in.getMeteoInfo()[k].getWetness(),
       bodyOut.meteorologicalInformation.wetness);

    // BodyInformation::MeteorologicalInformation::lvp_Activation
    bodyOut.meteorologicalInformation.lvp_Activation = 
      in.getMeteoInfo()[k].getLvpActivation();

    // BodyInformation::MeteorologicalInformation::ILSCategory
    std::string ILSCategory;
    if(in.getMeteoInfo()[k].getRequiredILSCategory())
    { 
      ILSCategory = (*in.getMeteoInfo()[k].getRequiredILSCategory());
    }
    else
    {
      ILSCategory = lcmeteo::INVALID_METEO_DATA;
    }
    LcuStringArrayConvUtils::String2Array
      (ILSCategory, 
       bodyOut.meteorologicalInformation.required_ILS_Category);


    /**@param BodyInformation::MeteorologicalInformation::de_icing_required
       @warning In the RTP project, deicing refers only to the presence of the PL value,
    	  	  	   (see 4.2.2 Información meteorológica, apartado "Asociación a subintervalos")

     */
    bodyOut.meteorologicalInformation.de_icing_required = 
      in.getMeteoInfo()[k].getDeicing();


    //BodyInformation::MeteorologicalInformation::RVRperRunwayList  //rvrperRunway

    bodyOut.meteorologicalInformation.rvrperRunway.ensure_length         
      (in.getMeteoInfo()[k].getRvrperRunway().getRVRPerRunway().size(),
       in.getMeteoInfo()[k].getRvrperRunway().getRVRPerRunway().size());

    for(unsigned int i = 0; 
	i< in.getMeteoInfo()[k].getRvrperRunway().getRVRPerRunway().size(); 
	++i)
    {
     IOUpdateMeteoInfo::RVRperRunway rvrperRunway;
      LcuStringArrayConvUtils::String2Array(in.getMeteoInfo()[k].getRvrperRunway().
	 getRVRPerRunway(i).getName(), rvrperRunway.RVRperRunway.name);

      if(in.getMeteoInfo()[k].getRvrperRunway().getRVRPerRunway(i).getRvr())
      {
	rvrperRunway.RVRperRunway.rvr = *in.getMeteoInfo()[k].getRvrperRunway().
	  getRVRPerRunway(i).getRvr();
      }
      else
      {
	rvrperRunway.RVRperRunway.rvr = lcmeteo::RVR_VALUE_MIN;
      }
      rvrperRunway.crosswind = in.getMeteoInfo()[k]. getRvrperRunway().getRVRPerRunway(i).getCrossWind();
      rvrperRunway.tailwind = in.getMeteoInfo()[k].getRvrperRunway().getRVRPerRunway(i).getTailWind();

      bodyOut.meteorologicalInformation.rvrperRunway.set_at(i, rvrperRunway);
    }//end-for rvrperRunway


#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
    << "DEBUG: RVW-length: bodyOut.meteorologicalInformation.rvrperRunway.size() = "
	<< bodyOut.meteorologicalInformation.rvrperRunway.length()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif


    output.bodyInformation.set_at(k,bodyOut);
  }//end-for-output.bodyInformation

}


//------------------------------------------------------------------------------

/**@fn void LpcMeteoInfo::convert2Meteo

                 meteo data
   RTP Server ----------------->  (RTP) HMI    : executed by the HMI to read the data.


   input: idl's IOUpdateMeteoInfo::Meteo msg. (one airport);

   output: internal storage (LpiUpdateMeteo) of Meteo info. (one airport);

*/
void LpcMeteoInfo::convert2Meteo(const IOUpdateMeteoInfo::Meteo &in, LpiUpdateMeteo &output)
{

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif


    // output.timeline
    LpiMeteoTimeline newTimeLine;
    LpcMeteoTimeline::convert(in.timeline, newTimeLine);
    output.setTimeline(newTimeLine);


#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif
   // output.calculationReason
   LpiCalculationReason::LpiEnum auxOutCalculationReason =
     LpiCalculationReason::E_INIT;
   LpcCalculationReason::convertIO2LpiCalculationReason
     (in.calculationReason, auxOutCalculationReason);
   output.setCalculationReason(auxOutCalculationReason);

   
   ///@warning ignore msg. on clock advance event
   if (output.getCalculationReason() == LpiCalculationReason::E_CLOCK)
   {

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).notify()
      << " Updating Meteo to HMI: case clock event => "
      << " MeteoTimeline updated. Meteorological data NOT updated." 
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

     return;
   }

   
   // NOT LpiCalculationReason::E_CLOCK => updating Meteorological data

   //-------------------------------------------------------------------------------
   //MESSAGE IDENTIFICATION
   // output.msgTimeAndDate
   output.setMessageTimeandDate(LctimTimeUtils::getFromString(in.messageIdentification.timeAndDate));
   // output.airport
   std::string aerodrome;
   LcuStringArrayConvUtils::Array2String(in.messageIdentification.airport, aerodrome);
   output.setAirport(aerodrome);


#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif
  //---------------------------------------------------------------------------------
  //BODY INFORMATION

  // sequence<BodyInformation> BodyInformationList => std::vector<LpiMeteoInfo>
  for (int j = 0; j < in.bodyInformation.length(); j++)
  {
    
    // BodyInformation  => LpiMeteoInfo
    LpiMeteoInfo new_meteoInfo;
    
    // a) BodyInformation::IOMeteoInfo::PeriodInformation
    posix_time::ptime startTimeAndDate = LctimTimeUtils::getFromString
      (in.bodyInformation.get_at(j).periodInformation.startTimeAndDate);
    new_meteoInfo.setStartTimeAndDate(startTimeAndDate);

    posix_time::ptime endTimeAndDate = LctimTimeUtils::getFromString
      (in.bodyInformation.get_at(j).periodInformation.endTimeAndDate);
    new_meteoInfo.setEndTimeAndDate(endTimeAndDate);

    new_meteoInfo.setProbability(in.bodyInformation.get_at(j).periodInformation.probability);

    
    // b) BodyInformation::MeteorologicalInformation
    //BodyInformation::MeteorologicalInformation::IOMeteoInfo::Meteorological
    new_meteoInfo.setWindDirection
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.windDirection);
    new_meteoInfo.setWindSpeed
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.windSpeed);
    new_meteoInfo.setGustSpeed
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.gustSpeed);
    new_meteoInfo.setGustDirection
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.gustDirection);
    new_meteoInfo.setAirTemperature
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.airTemperature);
    new_meteoInfo.setDewPointTemperature
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.dewPointTemperature);
    new_meteoInfo.setHorizontalVisibility
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.horizontalVisibility);
    new_meteoInfo.setQnh
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.qnh);
    new_meteoInfo.setCloudbase
      (in.bodyInformation.get_at(j).meteorologicalInformation.meterological.cloudBase);
    std::string significantWeather;
    LpcUtils::Array2String(in.bodyInformation.get_at(j).meteorologicalInformation.meterological.significantWeather,
			   significantWeather);
    new_meteoInfo.setSignificantWeather(significantWeather);

    //BodyInformation::MeteorologicalInformation::
    //wetness
    std::string wetness;
    LpcUtils::Array2String(in.bodyInformation.get_at(j).meteorologicalInformation.wetness,
			   wetness);
    new_meteoInfo.setWetness(wetness);
    //lvp_Activation
    new_meteoInfo.setLvpActivation(in.bodyInformation.get_at(j).meteorologicalInformation.lvp_Activation);
    //required_ILS_Category
    std::string required_ILS_Category;
    LpcUtils::Array2String(in.bodyInformation.get_at(j).meteorologicalInformation.required_ILS_Category,
			   required_ILS_Category);
    new_meteoInfo.setRequiredILSCategory(boost::algorithm::trim_right_copy(required_ILS_Category));

    /**@param deicing
       @warning In the RTP project, deicing refers only to the presence of the PL value,
    	  	  	   (see 4.2.2 Información meteorológica, apartado "Asociación a subintervalos")
     */
    new_meteoInfo.setDeicing(in.bodyInformation.get_at(j).meteorologicalInformation.de_icing_required);

    // RVRperRunwayList rvrperRunway
    RVRPerRunwayList rvr_per_runway_list;  // RVRperRunway rvrrunways;
    for (int i_elem = 0;
	 i_elem < in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.length();
	 ++i_elem)
    {
      // struct RVRperRunway
      RVRPerRunway new_ioupdate_rvrperrunway;

      // IOMeteoInfo::RVRperRunway RVRperRunway;
      std::string name;
      LpcUtils::Array2String(in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(i_elem).
			     RVRperRunway.name, name);
      new_ioupdate_rvrperrunway.setName(name);		
      new_ioupdate_rvrperrunway.setRvr
	(in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(i_elem).RVRperRunway.rvr);
      // IOMeteoInfo::RVRperRunway::crosswind
      new_ioupdate_rvrperrunway.setCrossWind
	(in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(i_elem).crosswind);
      // IOMeteoInfo::RVRperRunway::tailwind
      new_ioupdate_rvrperrunway.setTailWind
	(in.bodyInformation.get_at(j).meteorologicalInformation.rvrperRunway.get_at(i_elem).tailwind);
      
      rvr_per_runway_list.setRVRPerRunway(new_ioupdate_rvrperrunway);
    }//end-for-RVRperRunwayList
    new_meteoInfo.setRvrperRunway(rvr_per_runway_list);

    output.addMeteoInfoElement(new_meteoInfo);

  }//end-for-BodyInformationList

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

}//end-convert2Meteo


