#ifndef __LPC_CALCULATION_REASON_H__
#define __LPC_CALCULATION_REASON_H__

#include <IOCommonTypes.h>
#include <LpiCalculationReason.h>

class LpcCalculationReason
{
 public:

  static void convertLpi2IOCalculationReason
    (const LpiCalculationReason::LpiEnum &in,
     IOCommonTypes::CalculationReason & out);

  static void convertIO2LpiCalculationReason
    (const IOCommonTypes::CalculationReason &in,
     LpiCalculationReason::LpiEnum & out);
};


#endif /* __LPC_CALCULATION_REASON_H__ */
