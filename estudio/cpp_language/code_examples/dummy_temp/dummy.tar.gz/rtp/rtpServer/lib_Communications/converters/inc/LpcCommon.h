/*
 * LpcCommon.h
 *
 *  Created on: 19/03/2015
 *      Author: mbegega
 */

#ifndef LPCCOMMON_H_
#define LPCCOMMON_H_

#include <IOCommonTypes.h>
#include <boost/optional.hpp>


class LpcCommon
{
   public:

     static void optionalBool2IO(const boost::optional<bool> & in, IOCommonTypes::OptionalBool & out);
     static void optionalFloat2IO(const boost::optional<float> & in,IOCommonTypes::OptionalFloat & out);
     static void optionalInt2IO(const boost::optional<int> & in, IOCommonTypes::OptionalInt & out);


     static void optionalDouble2IO(const boost::optional<double> & in,IOCommonTypes::OptionalDouble & out);

     static void optionalDouble2IO(const boost::optional<double> & in,IOCommonTypes::OptionalFloat & out);


     static void OptionalUnsignedInt2IO(const boost::optional<unsigned int> & in,
					IOCommonTypes::OptionalUnsignedInt & out);

     static void OptionalUnsignedInt2IOInteger(const boost::optional<unsigned int> & in,
    		                                   IOCommonTypes::OptionalInt & out);



     // IOCommonTypes::Optional to boost::optional
     static void IOOptionalBool2OptionalBool(const IOCommonTypes::OptionalBool & optional,
					     boost::optional<bool> & optionalBool);
 
     static void IOOptionalUnsignedInt2OptionalUnsignedInt(const IOCommonTypes::OptionalUnsignedInt & optional,
							   boost::optional<unsigned int> & optionalUnsignedInt);
 
     static void IOOptionalDouble2OptionalDouble(const IOCommonTypes::OptionalDouble & optional,
						 boost::optional<double> & optionalDouble);
 
     static void IOOptionalInt2OptionalUnsignedInt(const IOCommonTypes::OptionalInt & optional,
						   boost::optional<unsigned int> & optionalUnsignedInt);
 
     static void IOOptionalDouble2OptionalDouble(const IOCommonTypes::OptionalFloat & optional,
						boost::optional<double> & optionalDouble);

  
   private:

};


#endif /* LPCCOMMON_H_ */
