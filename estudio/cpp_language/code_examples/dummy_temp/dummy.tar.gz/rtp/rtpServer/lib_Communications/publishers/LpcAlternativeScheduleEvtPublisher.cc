/*
 * LpcActiveScheduleEvtPublisher.cc
 *  Created on: 17/09/2014
 *  Author:
 */

#include <iostream>
#include <boost/lexical_cast.hpp>

#include <IOScheduleActivationEvents.h>
#include <IOScheduleActivation.h>

#include <LpiAlternativeSchedule.h>

#include <LpcWhatIfClosure.h>
#include <LpcAlternativeSchedule.h>
#include <LpcAlternativeScheduleEvtPublisher.h>

#include <LpdComponent.h>


void LpcAlternativeScheduleEvtPublisher::init(void)
{
   iB::PublisherId pid("IOWhatIFEvents::AlternativeResponseEvent");
   iB::PublicationProfile pprofile;

   _publisher = &iBG::IOWhatIFEvents::AlternativeResponseEventCreatePublisher(pid, pprofile);

   LpdComponent::Get().delegatePublisher(*this);
}


void LpcAlternativeScheduleEvtPublisher::publish(const LpiAlternativeScheduleEvt & data)
{
   IOWhatIFEvents::AlternativeResponseEvent alternativeScheduleEvt;
   IOWhatIFEvents::AlternativeResponseEventTypeSupport::initialize_data(&alternativeScheduleEvt);

   IOWhatIF::AlternativeSchedule out;
   LpcAlternativeSchedule::convertLpi2IOlternativeSchedule(data.getAlternativeSchedule(), out);
   alternativeScheduleEvt.alternativeSchedule = out;

   vector<LpiRunwayClosure> closures = data.getClosures();

   alternativeScheduleEvt.appliedClosures.ensure_length(closures.size(), closures.size());

   for (unsigned int i = 0; i < closures.size(); ++i)
   {
      IOCapacityReductions::RunwayNonPeriod runwayClosureIO;
      LpcWhatIfClosure::ConvertLpi2IO(closures[i], runwayClosureIO);

      alternativeScheduleEvt.appliedClosures.set_at(i, runwayClosureIO);
   }

   _publisher->push(alternativeScheduleEvt);

   IOWhatIFEvents::AlternativeResponseEventTypeSupport::finalize_data(&alternativeScheduleEvt);

   LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED ALTERNATIVE SCHEDULE]" << std::endl;
}

