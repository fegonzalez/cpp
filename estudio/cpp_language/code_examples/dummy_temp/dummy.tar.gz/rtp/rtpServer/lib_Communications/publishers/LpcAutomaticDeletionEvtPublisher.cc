
#include <LpcAutomaticDeletionEvtPublisher.h>

#include <LpcScheduleDelete.h>
#include <LpdComponent.h>
#include <LclogStream.h>

#include <iostream>


void LpcAutomaticDeletionEvtPublisher::init(void)
{
   iB::PublisherId pid("IOScheduleDeleteEvents::ScheduleAutomaticDeleteEvent");

   iB::PublicationProfile pprofile;

   _publisher = &iBG::IOScheduleDeleteEvents::ScheduleAutomaticDeleteEventCreatePublisher(pid, pprofile);

   LpdComponent::Get().delegatePublisher(*this);
}


void LpcAutomaticDeletionEvtPublisher::publish(const LpiAutomaticDeletionEvt &data)
{
   IOScheduleDeleteEvents::ScheduleAutomaticDeleteEvent ddsSeqEvt;
   memset(&ddsSeqEvt, 0, sizeof(IOScheduleDeleteEvents::ScheduleAutomaticDeleteEvent));
   IOScheduleDeleteEvents::ScheduleAutomaticDeleteEventTypeSupport::initialize_data(&ddsSeqEvt);

   IOScheduleDelete::ScheduleAutomaticDelete out;
   memset(&out, 0, sizeof(IOScheduleDelete::ScheduleAutomaticDelete));

   LpcScheduleDelete::ConvertLpi2IO(data.getDeletedScheduleIds(), out);

   ddsSeqEvt.scheduleAutomaticDelete = out;

   _publisher->push(ddsSeqEvt);

   IOScheduleDeleteEvents::ScheduleAutomaticDeleteEventTypeSupport::finalize_data(&ddsSeqEvt);

   LclogStream::instance(LclogConfig::E_RTP).notify() << "[PUBLISHED DELETED SCHEDULES LIST]" << std::endl;
}

