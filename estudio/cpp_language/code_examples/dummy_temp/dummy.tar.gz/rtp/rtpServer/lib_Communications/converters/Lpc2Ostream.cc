
#include "Lpc2Ostream.h"
#include <LcuStringArrayConvUtils.h>


std::ostream & operator<<(std::ostream & out,
                          const IOTim::TimeS & timeS)
{
   return out << "[SEC:" << (long)timeS << "]";
}


std::ostream & operator<<(std::ostream & out,
                          const IOTim::OptionalTimeU & oTime)
{
   return out << "[OFD:" << oTime._d
              << "|OFU:[VAL:" << (long)oTime._u.value
              << "|FLD:" << oTime._u.field
              << "]]";
}

