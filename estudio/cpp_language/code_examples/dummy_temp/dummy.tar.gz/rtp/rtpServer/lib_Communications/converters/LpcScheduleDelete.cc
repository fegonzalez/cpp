

#include "LpcScheduleDelete.h"


void LpcScheduleDelete::ConvertIO2Lpi(const IOScheduleDelete::ScheduleDelete &in,
                                      int & out)
{
   out = static_cast<int>(in.sch_id);
}


void LpcScheduleDelete::ConvertLpi2IO(const std::vector<int> & in,
                                      IOScheduleDelete::ScheduleAutomaticDelete & out)
{
   unsigned int numberOfDeletedSchedules = in.size();

   out.schIdList.ensure_length(numberOfDeletedSchedules, numberOfDeletedSchedules);

   for (unsigned int i = 0; i < numberOfDeletedSchedules; ++i)
   {
      out.schIdList.set_at(i, in[i]);
   }
}
