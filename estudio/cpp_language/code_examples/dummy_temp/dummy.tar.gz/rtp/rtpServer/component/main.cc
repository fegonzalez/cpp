#include <boost/asio.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <LplcTypeConstants.h>

#include <LpdComponent.h>
#include <LpdbDataBase.h>
#include <LpiUsers.h>
#include <LpcCommunicationsManager.h>
#include <LpaAdaptationManager.h>
#include <LpcfgConfigurationManager.h>

#include <LcuAtcUnits.h>
#include <LcuDataTypeUtils.h>
#include <LclogStream.h>
#include <LctimVirtualClock.h>
#include <LctimNotificationTimer.h>


int main(int argc, char * argv[])
{
    std::string processName(argv[0]);

    for (int ii = 1; ii < argc; ii++)
    {
        processName = processName + " " + argv[ii];
    }

    LclogStream::instance(LclogConfig::E_RTP).info() << processName << " initialized" << std::endl;


    // a) Set the system (real or simulated) time: LctimVirtualClock::getTime()

    LctimVirtualClock::ExecutionMode mode = LctimVirtualClock::E_REAL;

    boost::posix_time::ptime startTime;

    if (argc > 1)
    {
        std::string simulationDate(argv[1]);

        startTime = LctimTimeUtils::getFromString(simulationDate);

        if (startTime.is_not_a_date_time())
        {
            LclogStream::instance(LclogConfig::E_RTP).error() << argv[1]
                      << " is not a valid date/time format. Usage: " << argv[0]
                      << " dd/mm/YYYY HH:MM" << std::endl;
            exit(EXIT_FAILURE);
        }

        mode = LctimVirtualClock::E_SIMULATED;
    }
    else
    {
        startTime = boost::posix_time::second_clock::local_time();
    }

    boost::posix_time::ptime realStartTime = second_clock::local_time();

    LctimVirtualClock::Get().setParameters(mode, realStartTime, startTime);
    LclogStream::instance(LclogConfig::E_RTP).info() << "RTP Execution-Mode (0-real/1-simulated): "
    		<< LctimVirtualClock::Get().GetExecutionModeAsString(LctimVirtualClock::Get().getExecutionMode()) << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).info() << "RTP Execution-time: "
    		<< LctimVirtualClock::Get().getTime() << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).info() << "RTP real-time: "
    	    		<< LctimVirtualClock::Get().getRealTime() << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).info() << "RTP getStartupTime: "
    	    		<< LctimVirtualClock::Get().getStartupTime() << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).info() << "RTP Server Starting..." << std::endl;
    std::cout << "RTP Server Starting..." << std::endl;



    LpdComponent::Get().create();

    // b) init config. manager
    LpcfgConfigurationManager::Get().initialise();

    // c) init adap. manager
    LpaAdaptationManager::Get().initialise();

    // d) init LpdComponent (rtp Server main component)
    LpdComponent::Get().initialise();

    // e) init comms. manager: init comms. between config. manager, adap. manager, rtpServer
    LpcCommunicationsManager::Get().initialise();


    // f) run execute scheduling: calculate the initial optimal schedule ... and set it as the active schedule.
    LpdComponent::Get().complete();
    ;

    // g) Create and start the (periodic) timer object
    const unsigned int min_subinterval = LpdbDataBase::Get().getGlobalParameters().getTimeParameters().getMinutesSubinterval();

    LclogStream::instance(LclogConfig::E_RTP).info()
            << "Minutes subinterval= "
            << LpdbDataBase::Get().getGlobalParameters().getTimeParameters().getMinutesSubinterval()
            << std::endl;


    unsigned int period = min_subinterval;
    boost::posix_time::ptime now = LctimVirtualClock::Get().getTime();

    //First event will be in:
    int min = now.time_of_day().minutes();
    int sec = now.time_of_day().seconds();
    int first_event = min_subinterval - (min % min_subinterval);
    LclogStream::instance(LclogConfig::E_RTP).info() << "First event will be in " << first_event << " minutes ";
    LclogStream::instance(LclogConfig::E_RTP).info() << "less " << sec << " seconds" << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).info() << "Period for next events will be " << period << " minutes" << std::endl;

    //Timer creation
    //Component main_component;
    boost::asio::io_service io;

    LctimNotificationTimer periodic_timer(io,
    									  LpdComponent::Get(),
										  first_event * MINUTES_TO_SECONDS - sec,
										  period * MINUTES_TO_SECONDS);
    periodic_timer.start();

    // h) Server loop: Wait for iMas Blue reception events
    LpcCommunicationsManager::Get().waitForEvents();

    periodic_timer.stop();

    std::cout << "\n\n RTP Server finished... \n " << std::endl;
    LclogStream::instance(LclogConfig::E_RTP).info() << "\n\n RTP Server finished... \n " << std::endl;

    return 0;
}
