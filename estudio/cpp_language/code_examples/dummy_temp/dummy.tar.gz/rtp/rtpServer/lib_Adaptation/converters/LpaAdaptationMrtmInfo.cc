/*
 * LpaAdaptationMrtmInfo.cc
 *
 */

#include "LpaAdaptationMrtmInfo.h"


void LpaAdaptationMrtmInfo::convert2AdaptationMrtmInfo(const SmMrtmInfo::MrtmElement &mrtmElement,
														LpiAdaptationMrtmInfo  &output)
{

	output.setMrtmAvailable(mrtmElement().mrtmAvailable());
	output.setMrtmAfisAirports(mrtmElement().mrtmAfisAirports());
	output.setMrtmAtsAirports(mrtmElement().mrtmAtsAirports());
	output.setMaxTotalMov(mrtmElement().maxTotalMov());
	output.setMaxSimultaneousOpsHour(mrtmElement().maxSimultaneousOpsHour());
	output.setSimultaneousOpsTime(mrtmElement().simultaneousOpsTime());
	output.setMrtmStayTime(mrtmElement().mrtmStayTime());

	ComplexityThresholds wt;
	wt.setTotalMovMrtmUpperThreshold(mrtmElement().complexityThresholds().totalMovMrtmUpperThreshold());
	wt.setTotalMovMrtmLowerThreshold(mrtmElement().complexityThresholds().totalMovMrtmLowerThreshold());

	SimultaneousOpsHour sim;
	sim.setComplexityDEPDEP(mrtmElement().complexityThresholds().simultaneousOpsHour().complexityDEPDEP());
	sim.setComplexityARRDEP(mrtmElement().complexityThresholds().simultaneousOpsHour().complexityARRDEP());
	sim.setComplexityARRARR(mrtmElement().complexityThresholds().simultaneousOpsHour().complexityARRARR());
	wt.setSimultaneousOpsHour(sim);

	wt.setVfrMrtmUpperThreshold(mrtmElement().complexityThresholds().vfrMrtmUpperThreshold());
	wt.setVfrMrtmLowerThreshold(mrtmElement().complexityThresholds().vfrMrtmLowerThreshold());

	output.setWorkloadThresholds(wt);


#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
			<< "\n " << output << std::endl;
#endif

}
