/*
 * LpaAdaptationAirportsInfo.cc
 *
 */

#include "LpaAdaptationAirportsInfo.h"

#include <boost/algorithm/string/trim.hpp>


void LpaAdaptationAirportsInfo::convert2AdaptationAirportsInfo(const FpAirportsInfo::AirportsElement  &airportInfoElement,
                                         LpiAdaptationAirportsInfo  &output)
{

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

    LpiAdaptationAirportsInfo airports;
    AirportVector vAirport;
    Airport airport;

    for(unsigned int i = 0; i < airportInfoElement().airport().size(); i++)
    {
       std::string trim_airport_name = airportInfoElement().airport().at(i).airportName();
       boost::algorithm::trim(trim_airport_name);
       airport.setAirportName(trim_airport_name);

       if(airportInfoElement().airport().at(i).airportType().toString() == "AFIS")
           airport.setAirportType(AirportType::AFIS);
       else if(airportInfoElement().airport().at(i).airportType().toString() == "ATS")
           airport.setAirportType(AirportType::ATS);

       AirportMaxNominalCapacity maxNominal = airport.getAirportMaxNominal();
       maxNominal.setArrivalsValue(airportInfoElement().airport().at(i).airportMaxNominalCapacity().arrivalsValue());
       maxNominal.setDeparturesValue(airportInfoElement().airport().at(i).airportMaxNominalCapacity().departuresValue());
       maxNominal.setOverallValue(airportInfoElement().airport().at(i).airportMaxNominalCapacity().overallValue());
       airport.setAirportMaxNominal(maxNominal);

       airport.setTaxywaysMaxNominalCapacity(airportInfoElement().airport().at(i).taxywaysMaxNominalCapacity());
       airport.setTmaMaxNominalCapacity(airportInfoElement().airport().at(i).tmaMaxNominalCapacity());

       if(airportInfoElement().airport().at(i).airportMaxILsCategory().toString() == "NO_ILS")
           airport.setAirportMaxILsCategory(RunwayMaxIlsCategory::NO_ILS);
       else if(airportInfoElement().airport().at(i).airportMaxILsCategory().toString() == "CAT_I")
           airport.setAirportMaxILsCategory(RunwayMaxIlsCategory::CAT_I);
       else if(airportInfoElement().airport().at(i).airportMaxILsCategory().toString() == "CAT_II")
           airport.setAirportMaxILsCategory(RunwayMaxIlsCategory::CAT_II);
       else if(airportInfoElement().airport().at(i).airportMaxILsCategory().toString() == "CAT_III_A")
           airport.setAirportMaxILsCategory(RunwayMaxIlsCategory::CAT_III_A);
       else if(airportInfoElement().airport().at(i).airportMaxILsCategory().toString() == "CAT_III_B")
           airport.setAirportMaxILsCategory(RunwayMaxIlsCategory::CAT_III_B);
       else if(airportInfoElement().airport().at(i).airportMaxILsCategory().toString() == "CAT_III_C")
           airport.setAirportMaxILsCategory(RunwayMaxIlsCategory::CAT_III_C);


       RunwaysAirportsList rAirportsList;
       RunwaysAiports runwayAirports;
       boost::optional<double> f = 0.0;
       for(unsigned int j = 0; j < airportInfoElement().airport().at(i).runways().runway().size(); j++){
           runwayAirports.setRunwayName(airportInfoElement().airport().at(i).runways().runway().at(j).runwayName());
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Latitude() > 0)
               runwayAirports.setRunwayThreshold1Latitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Latitude());
           else
               runwayAirports.setRunwayThreshold1Latitude(f);
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Longitude() > 0)
               runwayAirports.setRunwayThreshold1Longitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Longitude());
           else
               runwayAirports.setRunwayThreshold1Longitude(f);
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Latitude() > 0)
               runwayAirports.setRunwayThreshold2Latitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Latitude());
           else
               runwayAirports.setRunwayThreshold2Latitude(f);
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Longitude() > 0)
               runwayAirports.setRunwayThreshold2Longitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Longitude());
           else
               runwayAirports.setRunwayThreshold2Longitude(f);
           runwayAirports.setCrosswindUpperThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindUpperThresholdDry());
           runwayAirports.setCrosswindLowerThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindLowerThresholdDry());
           runwayAirports.setCrosswindUpperThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindUpperThresholdWet());
           runwayAirports.setCrosswindLowerThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindLowerThresholdWet());
           runwayAirports.setCrosswindMinReduction(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindMinReduction());
           runwayAirports.setTailwindUpperThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindUpperThresholdDry());
           runwayAirports.setTailwindLowerThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindLowerThresholdDry());
           runwayAirports.setTailwindUpperThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindUpperThresholdWet());
           runwayAirports.setTailwindLowerThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindLowerThresholdWet());
           runwayAirports.setTailwindMinReduction(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindMinReduction());
           runwayAirports.setHorizontalVisibilityUpperThreshold(airportInfoElement().airport().at(i).runways().runway().at(j).horizontalVisibilityUpperThreshold());
           runwayAirports.setHorizontalVisibilityLoweThreshold(airportInfoElement().airport().at(i).runways().runway().at(j).horizontalVisibilityLowerThreshold());
           runwayAirports.setHorizontalMinReduction(airportInfoElement().airport().at(i).runways().runway().at(j).horizontalMinReduction());
           rAirportsList.push_back(runwayAirports);
       }
       airport.setRunway(rAirportsList);


       LvpActivacionConditonsList activationsList;
       ActivationConditions activations;

       for (unsigned int j=0; j< airportInfoElement().airport().at(i).lvpActivationConditions().condition().size(); j++)
       {
           activations.setConditionName(airportInfoElement().airport().at(i).lvpActivationConditions().condition(j).conditionName());
           activations.setTotalConditionValue(airportInfoElement().airport().at(i).lvpActivationConditions().condition(j).conditionValue());
           activationsList.push_back(activations);
       }
       airport.setLvpActivationConditions(activationsList);


       CatILsList catilsList;
       CatILs catils;
       for(unsigned int j = 0; j < airportInfoElement().airport().at(i).catILs().catIL().size(); j++)
       {

           if(airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString() == "NO_ILS")
               catils.setIdCatILs(RunwayMaxIlsCategory::NO_ILS);
           else if(airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString() == "CAT_I")
               catils.setIdCatILs(RunwayMaxIlsCategory::CAT_I);
           else if(airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString() == "CAT_II")
               catils.setIdCatILs(RunwayMaxIlsCategory::CAT_II);
           else if(airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString() == "CAT_III_A")
               catils.setIdCatILs(RunwayMaxIlsCategory::CAT_III_A);
           else if(airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString() == "CAT_III_B")
               catils.setIdCatILs(RunwayMaxIlsCategory::CAT_III_B);
           else if(airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString() == "CAT_III_C")
               catils.setIdCatILs(RunwayMaxIlsCategory::CAT_III_C);

           //assert(catils.getCloudBase().is_initialized()); //falla siempre
           Bound base;
           //if(catils.getCloudBase().is_initialized()) // redundant, updated just after
           //{ base = catils.getCloudBase().get(); }
           //assert(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().is_initialized()); //falla
           if(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().is_initialized())
           {
             base.setUpperBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().get().upperBound());
             base.setLowerBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().get().lowerBound());
           }
//           else
//           {
//        	   LclogStream::instance(LclogConfig::E_RTP).error()
//    	    	       << " : File: " << __FILE__
//    	    	       << " ; fn: " << __func__
//    	    	       << " ; line: " << __LINE__
//    				   << " ; "
//        			   << "airportInfoElement's cloudBase not initialized. Set to 0."
//					   << std::endl;
//           }
           catils.setCloudBase(base);

           Bound visibility;
           //assert(airportInfoElement().airport().at(i).catILs().catIL().at(j).horizontalVisibility().is_initialized());
           if(airportInfoElement().airport().at(i).catILs().catIL().at(j).
        		   horizontalVisibility().is_initialized())
           {
             visibility.setUpperBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).horizontalVisibility().get().upperBound());
             visibility.setLowerBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).horizontalVisibility().get().lowerBound());
           }
//           else
//           {
//        	   LclogStream::instance(LclogConfig::E_RTP).error()
//    	       << " : File: " << __FILE__
//    	       << " ; fn: " << __func__
//    	       << " ; line: " << __LINE__
//			   << " ; "
//			   << "airportInfoElement's horizontalVisibility not initialized. Set to 0."
//					   << std::endl;
//           }
           catils.setHorizontalVisibility(visibility);

           Bound rvr = catils.getRvrType();
           rvr.setUpperBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).rvr().upperBound());
           rvr.setLowerBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).rvr().lowerBound());
           catils.setRvrType(rvr);
           catilsList.push_back(catils);
       }

       airport.setCatILs(catilsList);

       ComplexityAirportsThresholds comp = airport.getComplexityThresholds();
       comp.setTotalMovAirportUpperThreshold(airportInfoElement().airport().at(i).complexityThresholds().totalMovAirportUpperThreshold());
       comp.setTotalMovAirportLowerThreshold(airportInfoElement().airport().at(i).complexityThresholds().totalMovAirportLowerThreshold());
       comp.setVfrAirportUpperThreshold(airportInfoElement().airport().at(i).complexityThresholds().vfrAirportUpperThreshold());
       comp.setVfrAirportLowerThreshold(airportInfoElement().airport().at(i).complexityThresholds().vfrAirportLowerThreshold());
       airport.setComplexityThresholds(comp);

       vAirport.push_back(airport);
    }

    output.setAirport(vAirport);

//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug()
//		    << " : File: " << __FILE__
//		    << " ; fn: " << __func__
//		    << " ; line: " << __LINE__
//			<< "\n " << output << std::endl;
//#endif

}
