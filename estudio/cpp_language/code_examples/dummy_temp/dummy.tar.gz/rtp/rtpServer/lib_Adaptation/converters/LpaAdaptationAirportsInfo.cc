/*
 * LpaAdaptationAirportsInfo.cc
 *
 */

#include "LpaAdaptationAirportsInfo.h"

#include <boost/algorithm/string/trim.hpp>


void LpaAdaptationAirportsInfo::convert2AdaptationAirportsInfo
     (const FpAirportsInfo::AirportsElement  &airportInfoElement,
      LpiAdaptationAirportsInfo  &output)
{

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

    LpiAdaptationAirportsInfo airports;
    AirportVector vAirport;
    Airport airport;

    for(unsigned int i = 0; i < airportInfoElement().airport().size(); i++)
    {
       std::string aux_trim_name = airportInfoElement().airport().at(i).airportName();
       boost::algorithm::trim(aux_trim_name);
       airport.setAirportName(aux_trim_name);

       aux_trim_name = airportInfoElement().airport().at(i).airportType().toString();
       boost::algorithm::trim(aux_trim_name);
       if( aux_trim_name == "AFIS")
           airport.setAirportType(AirportType::AFIS);
       else if(aux_trim_name == "ATS")
           airport.setAirportType(AirportType::ATS);

       AirportMaxNominalCapacity maxNominal = airport.getAirportMaxNominal();
       maxNominal.setArrivalsValue(airportInfoElement().airport().at(i).airportMaxNominalCapacity().arrivalsValue());
       maxNominal.setDeparturesValue(airportInfoElement().airport().at(i).airportMaxNominalCapacity().departuresValue());
       maxNominal.setOverallValue(airportInfoElement().airport().at(i).airportMaxNominalCapacity().overallValue());
       airport.setAirportMaxNominal(maxNominal);
	   LpiADOVector<unsigned int> new_twy_value;
       new_twy_value[E_ARR] = airportInfoElement().airport().at(i).taxywaysMaxNominalCapacity().arrivalsValue();
       new_twy_value[E_DEP] = airportInfoElement().airport().at(i).taxywaysMaxNominalCapacity().departuresValue();
       new_twy_value[E_OVA] = airportInfoElement().airport().at(i).taxywaysMaxNominalCapacity().overallValue();
       airport.setTaxywaysMaxNominalCapacity(new_twy_value);
	   LpiADOVector<unsigned int> new_tma_value;
       new_tma_value[E_ARR] = airportInfoElement().airport().at(i).tmaMaxNominalCapacity().arrivalsValue();
       new_tma_value[E_DEP] = airportInfoElement().airport().at(i).tmaMaxNominalCapacity().departuresValue();
       new_tma_value[E_OVA] = airportInfoElement().airport().at(i).tmaMaxNominalCapacity().overallValue();
       airport.setTmaMaxNominalCapacity(new_tma_value);

       aux_trim_name = airportInfoElement().airport().at(i).airportMaxILsCategory().toString();
       boost::algorithm::trim(aux_trim_name);
       if(aux_trim_name == "NO_ILS")
           airport.setAirportMaxILsCategory(Max_ILS_Category::NO_ILS);
       else if(aux_trim_name == "CAT_I")
           airport.setAirportMaxILsCategory(Max_ILS_Category::CAT_I);
       else if(aux_trim_name == "CAT_II")
           airport.setAirportMaxILsCategory(Max_ILS_Category::CAT_II);
       else if(aux_trim_name == "CAT_III_A")
           airport.setAirportMaxILsCategory(Max_ILS_Category::CAT_III_A);
       else if(aux_trim_name == "CAT_III_B")
           airport.setAirportMaxILsCategory(Max_ILS_Category::CAT_III_B);
       else if(aux_trim_name == "CAT_III_C")
           airport.setAirportMaxILsCategory(Max_ILS_Category::CAT_III_C);


       RunwaysAirportsList rAirportsList;
       RunwaysAirports runwayAirports;
       const boost::optional<double> DEFAULT_LALON_THRESHOLD = 0.0;
       for(unsigned int j = 0; j < airportInfoElement().airport().at(i).runways().runway().size(); j++)
       {
           aux_trim_name = airportInfoElement().airport().at(i).runways().runway().at(j).runwayName();
           boost::algorithm::trim(aux_trim_name);
           runwayAirports.setRunwayName(aux_trim_name);

           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Latitude() > 0)
               runwayAirports.setRunwayThreshold1Latitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Latitude());
           else
               runwayAirports.setRunwayThreshold1Latitude(DEFAULT_LALON_THRESHOLD);
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Longitude() > 0)
               runwayAirports.setRunwayThreshold1Longitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold1Longitude());
           else
               runwayAirports.setRunwayThreshold1Longitude(DEFAULT_LALON_THRESHOLD);
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Latitude() > 0)
               runwayAirports.setRunwayThreshold2Latitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Latitude());
           else
               runwayAirports.setRunwayThreshold2Latitude(DEFAULT_LALON_THRESHOLD);
           if(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Longitude() > 0)
               runwayAirports.setRunwayThreshold2Longitude(airportInfoElement().airport().at(i).runways().runway().at(j).runwayThreshold2Longitude());
           else
               runwayAirports.setRunwayThreshold2Longitude(DEFAULT_LALON_THRESHOLD);
	   
           runwayAirports.setCrosswindUpperThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindUpperThresholdDry());
           runwayAirports.setCrosswindLowerThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindLowerThresholdDry());
           runwayAirports.setCrosswindUpperThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindUpperThresholdWet());
           runwayAirports.setCrosswindLowerThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindLowerThresholdWet());
           runwayAirports.setCrosswindMinReduction(airportInfoElement().airport().at(i).runways().runway().at(j).crosswindMinReduction());
	   
           runwayAirports.setTailwindUpperThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindUpperThresholdDry());
           runwayAirports.setTailwindLowerThresholdDry(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindLowerThresholdDry());
           runwayAirports.setTailwindUpperThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindUpperThresholdWet());
           runwayAirports.setTailwindLowerThresholdWet(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindLowerThresholdWet());
           runwayAirports.setTailwindMinReduction(airportInfoElement().airport().at(i).runways().runway().at(j).tailwindMinReduction());

	   runwayAirports.setHorizontalVisibilityUpperThreshold(airportInfoElement().airport().at(i).runways().runway().at(j).horizontalVisibilityUpperThreshold())
           runwayAirports.setHorizontalVisibilityLoweThreshold(airportInfoElement().airport().at(i).runways().runway().at(j).horizontalVisibilityLowerThreshold());
           runwayAirports.setHorizontalMinReduction(airportInfoElement().airport().at(i).runways().runway().at(j).horizontalMinReduction());

	   rAirportsList.push_back(runwayAirports);
       }
       airport.setRunway(rAirportsList);


       LvpActivacionConditonsList activationsList;
       ActivationConditions activations;

       for (unsigned int j=0; j< airportInfoElement().airport().at(i).lvpActivationConditions().condition().size(); j++)
       {
         aux_trim_name = airportInfoElement().airport().at(i).lvpActivationConditions().condition(j).conditionName();
         boost::algorithm::trim(aux_trim_name);
         activations.setConditionName(aux_trim_name);
         activations.setTotalConditionValue(airportInfoElement().airport().at(i).lvpActivationConditions().condition(j).conditionValue());
         activationsList.push_back(activations);
       }
       airport.setLvpActivationConditions(activationsList);


       CatILsList catilsList;
       CatILs catils;
       for(unsigned int j = 0; j < airportInfoElement().airport().at(i).catILs().catIL().size(); j++)
       {
    	   aux_trim_name = airportInfoElement().airport().at(i).catILs().catIL().at(j).idCatILs().toString();
    	   boost::algorithm::trim(aux_trim_name);
           if(aux_trim_name == "NO_ILS")
               catils.setIdCatILs(Max_ILS_Category::NO_ILS);
           else if(aux_trim_name == "CAT_I")
               catils.setIdCatILs(Max_ILS_Category::CAT_I);
           else if(aux_trim_name == "CAT_II")
               catils.setIdCatILs(Max_ILS_Category::CAT_II);
           else if(aux_trim_name == "CAT_III_A")
               catils.setIdCatILs(Max_ILS_Category::CAT_III_A);
           else if(aux_trim_name == "CAT_III_B")
               catils.setIdCatILs(Max_ILS_Category::CAT_III_B);
           else if(aux_trim_name == "CAT_III_C")
               catils.setIdCatILs(Max_ILS_Category::CAT_III_C);

           //assert(catils.getCloudBase().is_initialized()); //falla siempre
           Bound base;
           //assert(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().is_initialized()); //falla
           if(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().is_initialized())
           {
             base.setUpperBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().get().upperBound());
             base.setLowerBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).cloudBase().get().lowerBound());
           }
           catils.setCloudBase(base);

           Bound visibility;
           //assert(airportInfoElement().airport().at(i).catILs().catIL().at(j).horizontalVisibility().is_initialized());
           if(airportInfoElement().airport().at(i).catILs().catIL().at(j).
        		   horizontalVisibility().is_initialized())
           {
             visibility.setUpperBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).horizontalVisibility().get().upperBound());
             visibility.setLowerBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).horizontalVisibility().get().lowerBound());
           }
           catils.setHorizontalVisibility(visibility);

           Bound rvr = catils.getRvrType();
           rvr.setUpperBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).rvr().upperBound());
           rvr.setLowerBound(airportInfoElement().airport().at(i).catILs().catIL().at(j).rvr().lowerBound());
           catils.setRvrType(rvr);
           catilsList.push_back(catils);
       }

       airport.setCatILs(catilsList);

       ComplexityAirportsThresholds comp = airport.getComplexityThresholds();
       comp.setTotalMovAirportUpperThreshold(airportInfoElement().airport().at(i).complexityThresholds().totalMovAirportUpperThreshold());
       comp.setTotalMovAirportLowerThreshold(airportInfoElement().airport().at(i).complexityThresholds().totalMovAirportLowerThreshold());
       comp.setVfrAirportUpperThreshold(airportInfoElement().airport().at(i).complexityThresholds().vfrAirportUpperThreshold());
       comp.setVfrAirportLowerThreshold(airportInfoElement().airport().at(i).complexityThresholds().vfrAirportLowerThreshold());
       airport.setComplexityThresholds(comp);

       vAirport.push_back(airport);
    }

    output.setAirport(vAirport);

//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug()
//		    << " : File: " << __FILE__
//		    << " ; fn: " << __func__
//		    << " ; line: " << __LINE__
//			<< "\n " << output << std::endl;
//#endif

}
