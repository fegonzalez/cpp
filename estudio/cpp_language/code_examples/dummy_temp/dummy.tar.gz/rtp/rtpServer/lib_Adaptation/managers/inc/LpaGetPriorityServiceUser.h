/*
 * LpaGetPriorityServiceUser.h
 *
 */

#ifndef __LPA_PRIORITY_SERVICEUSER_H__
#define __LPA_PRIORITY_SERVICEUSER_H__

#include <LpiIServiceUsers.h>
#include <daortp_fppriority_xsd.h>
#include <LpaPriorityTable.h>

#include <LclogStream.h>

class LpaGetPriorityServiceUser : public LpiIGetPriorityTableSrvUser
{
   public:

      LpaGetPriorityServiceUser() {}

      void init (const std::string & name)
      {
         r_priority.open(name);

#ifdef TRACE_OUT
         LclogStream::instance(LclogConfig::E_RTP).debug() <<"Initialized File: " << name<< std::endl;
#endif

         LpdComponent::Get().delegateUser(*this);
      }

      virtual void use (LpiGetPriorityReply & reply)
      {

#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

         LpiPriorityTable tableDepartures;
         LpiPriorityTable tableArrivals;

         LpaPriorityTable::Convert2PriorityTableDepartures(r_priority, tableDepartures);
         reply.setPriorityTableDepartures(tableDepartures);

         LpaPriorityTable::Convert2PriorityTableArrivals(r_priority, tableArrivals);
         reply.setPriorityTableArrivals(tableArrivals);

         reply.setResult(LpiResult::E_OK);
      }

   private:

      FpPriority::PriorityElement r_priority;
};


#endif /* __LPA_PRIORITY_SERVICEUSER_H__ */
