/*
 * LpaAdaptationAirportsInfo.h
 *
 */

#ifndef LPAADAPTATIONAIRPORTSINFO_H_
#define LPAADAPTATIONAIRPORTSINFO_H_

#include "daortp_fpairportsinfo_xsd.h"
#include <LpiAdaptationAirportsInfo.h>
#include <LclogStream.h>

class LpaAdaptationAirportsInfo
{
public:

   
    static void convert2AdaptationAirportsInfo(const FpAirportsInfo::AirportsElement  &airportInfoElement,
                                         LpiAdaptationAirportsInfo  &output);
   
};


#endif /* LPAADAPTATIONAIRPORTSINFO_H_ */
