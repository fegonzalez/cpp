// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 10:21:34 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpaAdaptationAlert_KPIs.h"

void LpaAdaptationAlert_KPIs::convert2AdaptationKpiParam(const AlertKpi::AbsoluteKPIsElement &alert_KPIs,
                                              LpiAdaptationAlert_KPIs &output)
{
    AbsoluteKPIs sim;
    NegativeAlert nSim;
    nSim.setAlarmThreshold(alert_KPIs().simultaneousOpsHourAlert().negativeAlert().alarmThreshold());
    nSim.setWarningThreshold(alert_KPIs().simultaneousOpsHourAlert().negativeAlert().warningThreshold());
    sim.setNegativeAlert(nSim);
    output.setSimultaneousOpsHour(sim);

    AbsoluteKPIs move;
    NegativeAlert nMove;
    nMove.setAlarmThreshold(alert_KPIs().totalMovAlert().negativeAlert().alarmThreshold());
    nMove.setWarningThreshold(alert_KPIs().totalMovAlert().negativeAlert().warningThreshold());
    move.setNegativeAlert(nMove);
    output.setTotalMov(move);

    Complexity comp;
    AbsoluteKPIs aCompAirports;
    NegativeAlert nCompAirports;
    AbsoluteKPIs aCompModules;
    NegativeAlert nCompModules;

    nCompAirports.setAlarmThreshold(alert_KPIs().complexityAlert().airportsComplexity().negativeAlert().alarmThreshold());
    nCompAirports.setWarningThreshold(alert_KPIs().complexityAlert().airportsComplexity().negativeAlert().warningThreshold());
    aCompAirports.setNegativeAlert(nCompAirports);
    comp.setAirportsComplexity(aCompAirports);

    nCompModules.setAlarmThreshold(alert_KPIs().complexityAlert().modulesComplexity().negativeAlert().alarmThreshold());
    nCompModules.setWarningThreshold(alert_KPIs().complexityAlert().modulesComplexity().negativeAlert().warningThreshold());
    aCompModules.setNegativeAlert(nCompModules);
    comp.setModulesComplexity(aCompModules);
    output.setComplexity(comp);

    AbsoluteKPIs vfr;
   	NegativeAlert nVfr;
   	nVfr.setAlarmThreshold(alert_KPIs().vfrAlert().negativeAlert().alarmThreshold());
   	nVfr.setWarningThreshold(alert_KPIs().vfrAlert().negativeAlert().warningThreshold());
   	vfr.setNegativeAlert(nVfr);
   	output.setVfr(vfr);


#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
			<< "\n " << output << std::endl;
#endif
}

