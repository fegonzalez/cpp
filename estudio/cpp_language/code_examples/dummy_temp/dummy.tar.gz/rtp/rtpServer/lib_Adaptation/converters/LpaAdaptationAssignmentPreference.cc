// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 21 Jun 11:22:09 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#include "LpaAdaptationAssignmentPreference.h"

void LpaAdaptationAssignmentPreference::convert2AdaptationAssignmentPreference(
        const FpAssignmentPreference::AssigmentPreferenceElement &assElement,
                                                       LpiAdaptationAssignmentPreference &output)
{
    LpiAllocationList lNotAllowed;
    LpiAllocationVector lvNotAllowed;
    LpiAllocationListLevel lPreferential;
    LpiAllocationVectorLevel lvPreferential;
    LpiAllocation lAllocation;
    LpiAllocationLevel lAllocationLevel;

    for(unsigned int i = 0; i < assElement().notAllowedAllocation().allocation().size(); i++){
        lAllocation.setAirport1(assElement().notAllowedAllocation().allocation(i).airport1());
        lAllocation.setAirport2(assElement().notAllowedAllocation().allocation(i).airport2());
        lAllocation.setStartTime(assElement().notAllowedAllocation().allocation(i).startTime());
        lAllocation.setEndTime(assElement().notAllowedAllocation().allocation(i).endTime());

        lvNotAllowed.push_back(lAllocation);
    }

    lNotAllowed.setAllocation(lvNotAllowed);
    output.setNotAllowedAllocation(lNotAllowed);

    for(unsigned int i = 0; i < assElement().preferentialAllocation().allocation().size(); i++){
        lAllocationLevel.setAirport1(assElement().preferentialAllocation().allocation(i).airport1());
        lAllocationLevel.setAirport2(assElement().preferentialAllocation().allocation(i).airport2());
        lAllocationLevel.setStartTime(assElement().preferentialAllocation().allocation(i).startTime());
        lAllocationLevel.setEndTime(assElement().preferentialAllocation().allocation(i).endTime());
        lAllocationLevel.setPreferentialLevel(assElement().preferentialAllocation().allocation(i).preferentialLevel());

        lvPreferential.push_back(lAllocationLevel);
    }

    lPreferential.setAllocation(lvPreferential);
    output.setPreferentialAllocation(lPreferential);


#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
//			<< "\n " << output
			<< std::endl;
#endif
}
