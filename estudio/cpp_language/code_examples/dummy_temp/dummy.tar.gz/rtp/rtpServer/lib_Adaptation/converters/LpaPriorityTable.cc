/*
 * LpaPriorityTable.cc
 *
 */

#include "LpaPriorityTable.h"
#include <LpiPriorityTable.h>


void LpaPriorityTable::Convert2Charateristic (const FpPriority::FPCharacteristicName::Enum & input,
                                              LpiFPCharacteristic::LpiEnum & output)
{
   switch (input)
   {
      case FpPriority::FPCharacteristicName::EOBT:
         output = LpiFPCharacteristic::E_EOBT;
         break;
      case FpPriority::FPCharacteristicName::SOBT:
         output = LpiFPCharacteristic::E_SOBT;
         break;
      case FpPriority::FPCharacteristicName::TOBT:
         output = LpiFPCharacteristic::E_TOBT;
         break;
      case FpPriority::FPCharacteristicName::ETOT:
         output = LpiFPCharacteristic::E_ETOT;
         break;
      case FpPriority::FPCharacteristicName::TTOT:
         output = LpiFPCharacteristic::E_TTOT;
         break;
      case FpPriority::FPCharacteristicName::STOT:
         output = LpiFPCharacteristic::E_STOT;
         break;
      case FpPriority::FPCharacteristicName::CTOT:
         output = LpiFPCharacteristic::E_CTOT;
         break;
      case FpPriority::FPCharacteristicName::UTOT:
         output = LpiFPCharacteristic::E_UTOT;
         break;
      case FpPriority::FPCharacteristicName::ELDT:
         output = LpiFPCharacteristic::E_ELDT;
         break;
      case FpPriority::FPCharacteristicName::TLDT:
         output = LpiFPCharacteristic::E_TLDT;
         break;
      case FpPriority::FPCharacteristicName::SLDT:
         output = LpiFPCharacteristic::E_SLDT;
         break;
      case FpPriority::FPCharacteristicName::ULDT:
         output = LpiFPCharacteristic::E_ULDT;
         break;
      case FpPriority::FPCharacteristicName::SIBT:
         output = LpiFPCharacteristic::E_SIBT;
         break;
      default:
         output = LpiFPCharacteristic::E_UNKNOWN;
      break;
   }

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
			<< "\n " << output << std::endl;
#endif
}


void LpaPriorityTable::Convert2PriorityTableDepartures (const FpPriority::PriorityElement & input,
                                              LpiPriorityTable  & output)
{
   for(unsigned int i = 0; i < input().departures().fpCharacteristic().size(); ++i)
   {
       FpPriority::FPCharacteristic priorityElement = input().departures().fpCharacteristic(i);

      //Use an internal enumeration type
      LpiFPCharacteristic::LpiEnum characteristic;
      //LpaPriorityTable::Convert2Charateristic(priorityElement.characteristic(), characteristic);
      int priorityLevel = static_cast<int>(priorityElement.priorityLevel());

      output.addCharacteristicDepartures(priorityLevel, characteristic);
   }


//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug()
//		    << " : File: " << __FILE__
//		    << " ; fn: " << __func__
//		    << " ; line: " << __LINE__
//			<< "\n " << output << std::endl;
//#endif

}


void LpaPriorityTable::Convert2PriorityTableArrivals (const FpPriority::PriorityElement & input,
                                              LpiPriorityTable  & output)
{
   for(unsigned int i = 0; i < input().arrivals().fpCharacteristic().size(); ++i)
   {
          FpPriority::FPCharacteristic priorityElement = input().arrivals().fpCharacteristic(i);

         //Use an internal enumeration type
         LpiFPCharacteristic::LpiEnum characteristic;
         //LpaPriorityTable::Convert2Charateristic(priorityElement.characteristic(), characteristic);
         int priorityLevel = static_cast<int>(priorityElement.priorityLevel());

         output.addCharacteristicArrivals(priorityLevel, characteristic);
   }
//#ifdef TRACE_OUT
// LclogStream::instance(LclogConfig::E_RTP).debug()
//		    << " : File: " << __FILE__
//		    << " ; fn: " << __func__
//		    << " ; line: " << __LINE__
//			<< "\n " << output << std::endl;
//#endif
}

