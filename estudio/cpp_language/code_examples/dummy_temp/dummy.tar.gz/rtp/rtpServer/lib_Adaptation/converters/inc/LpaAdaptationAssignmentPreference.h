// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 21 Jun 11:22:09 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPAADAPTATIONASSIGNMENTPREFERENCE_H_
#define LPAADAPTATIONASSIGNMENTPREFERENCE_H_

#include <daortp_fpassignmentpreference_xsd.h>
#include "LpiAdaptationAssignmentPreference.h"
#include <LclogStream.h>

class LpaAdaptationAssignmentPreference
{
public:

    static void convert2AdaptationAssignmentPreference(
            const FpAssignmentPreference::AssigmentPreferenceElement &assElement,
                                                       LpiAdaptationAssignmentPreference &output);
};

#endif /* LPAADAPTATIONASSIGNMENTPREFERENCE_H_ */
