/*
 * LpaWakeVortexCapacityReductions.h
 *
 *  Created on: 22 ago. 2017
 *      Author: cgudin
 */

#ifndef C___LPAWAKEVORTEXCAPACITYREDUCTIONS_H_
#define C___LPAWAKEVORTEXCAPACITYREDUCTIONS_H_

#include <daortp_wakevortexcapacityreductions_xsd.h>
#include <LpiWakeVortexCapacityReductions.h>
#include <string>
#include <iostream>


class LpaWakeVortexCapacityReductions
{
public:


    static void convert2WTCapacityReductionsInfo(
                            const WakevortexCapacityReductions::WTC_capacityReductionICAO_BlockElement  &in,
                            LpiWakeVortexCapacityReductions  &output);

};


#endif /* C___LPAWAKEVORTEXCAPACITYREDUCTIONS_H_ */
