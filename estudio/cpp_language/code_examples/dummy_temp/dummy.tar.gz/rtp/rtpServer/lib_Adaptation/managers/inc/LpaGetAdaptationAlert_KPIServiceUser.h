// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 09:44:53 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCFGGETADAPTATIONALERT_KPISERVICEUSER_H_
#define LPCFGGETADAPTATIONALERT_KPISERVICEUSER_H_

#include <LpiIServiceUsers.h>
#include <daortp_alertkpi_xsd.h>
#include "LpaAdaptationAlert_KPIs.h"

class LpaGetAdaptationAlert_KPIServiceUser : public LpiIGetAdaptationAlert_KPIsSrvUser
{
public:
   LpaGetAdaptationAlert_KPIServiceUser() {}

   /**
    * Inicializa la lectura del fichero XML que contiene la informacion de configuracion
    * @param name es el nombre del fichero XML
    */
   void init(const std::string &name)
   {
      this->_alert_KPI.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug() <<"Initialized File: "<<name<<std::endl;
#endif

      LpdComponent::Get().delegateUser(*this);
   }

   /**
    * Servicio usado para volcar la informacion leida del XML a los tipos internos
    * @param request es la peticion del servicio
    * @param reply es la respuesta del servicio
    */
   virtual void use(LpiGetAdaptationAlert_KPIsReply &reply)
   {
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif
      LpiAdaptationAlert_KPIs AlertKpi;
      LpaAdaptationAlert_KPIs::convert2AdaptationKpiParam(this->_alert_KPI, AlertKpi);
      reply.setAdaptationAlert_KPIs(AlertKpi);
      reply.setResult(LpiResult::E_OK);
   }


private:
   AlertKpi::AbsoluteKPIsElement _alert_KPI;
};



#endif /* LPCFGGETCONFIGURATIONALERT_KPISERVICEUSER_H_ */
