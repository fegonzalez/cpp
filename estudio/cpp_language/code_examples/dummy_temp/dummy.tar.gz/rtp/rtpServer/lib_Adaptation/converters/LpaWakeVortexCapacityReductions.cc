/*
 * LpaWakeVortexCapacityReductions.cc
 *
 *  Created on: 22 ago. 2017
 *      Author: cgudin
 */

#include "LpaWakeVortexCapacityReductions.h"
#include <LpiADOVector.h>

/**
 * Convierte la informacion leida del XML al tipo interno
 * @param output es el dato donde el metodo DEVUELVE la informacion
 * una vez convertida al tipo interno
 */


void LpaWakeVortexCapacityReductions::convert2WTCapacityReductionsInfo(
                            const WakevortexCapacityReductions::WTC_capacityReductionICAO_BlockElement &in,
                            LpiWakeVortexCapacityReductions &output)
{


    std::vector<LpiWakeVortexConditions> wtc_conditions_vector_DEP;
    std::vector<LpiWakeVortexConditions> wtc_conditions_vector_OVA;

    for (unsigned int i = 0; i < in().wakeVortexCapacityReductionICAO().size(); i++)
    {

        for (unsigned int ii = 0; ii < in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR().size(); ii++)
        {

            // Get conditions
            std::vector<LpiWakeVortexConditions> wtc_conditions_vector_ARR;

            LpiWakeVortexConditions wtc_conditions_ARR_L(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_L().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_L().minValue(),
            "L");
            wtc_conditions_vector_ARR.push_back(wtc_conditions_ARR_L);

            LpiWakeVortexConditions wtc_conditions_ARR_M(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_M().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_M().minValue(),
            "M");
            wtc_conditions_vector_ARR.push_back(wtc_conditions_ARR_M);

            LpiWakeVortexConditions wtc_conditions_ARR_H(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_H().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_H().minValue(),
            "H");
            wtc_conditions_vector_ARR.push_back(wtc_conditions_ARR_H);

            LpiWakeVortexConditions wtc_conditions_ARR_J(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_J().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).percentage_ARR().percentage_WTC_J().minValue(),
            "J");
            wtc_conditions_vector_ARR.push_back(wtc_conditions_ARR_J);

            //Get reductions
            float reduction_ARR(in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR(ii).reductionValue_ARR());

            output.addWTCReductionARR(wtc_conditions_vector_ARR,
                                   reduction_ARR);
        }

        for (unsigned int ii = 0; ii < in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().size(); ii++)
        {

            // Get conditions
            std::vector<LpiWakeVortexConditions> wtc_conditions_vector_DEP;

            LpiWakeVortexConditions wtc_conditions_DEP_L(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_L().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_L().minValue(),
            "L");
            wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_L);

            LpiWakeVortexConditions wtc_conditions_DEP_M(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_M().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_M().minValue(),
            "M");
            wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_M);

            LpiWakeVortexConditions wtc_conditions_DEP_H(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_H().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_H().minValue(),
            "H");
            wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_H);

            LpiWakeVortexConditions wtc_conditions_DEP_J(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_J().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).percentage_DEP().percentage_WTC_J().minValue(),
            "J");
            wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_J);

            //Get reductions
            float reduction_DEP(in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP(ii).reductionValue_DEP());

            output.addWTCReductionDEP(wtc_conditions_vector_DEP,
                                   reduction_DEP);
        }

        for (unsigned int ii = 0; ii < in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().size(); ii++)
        {

            // Get conditions
            std::vector<LpiWakeVortexConditions> wtc_conditions_vector_OVE;

            LpiWakeVortexConditions wtc_conditions_OVE_L(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_L().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_L().minValue(),
            "L");
            wtc_conditions_vector_OVE.push_back(wtc_conditions_OVE_L);

            LpiWakeVortexConditions wtc_conditions_OVE_M(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_M().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_M().minValue(),
            "M");
            wtc_conditions_vector_OVE.push_back(wtc_conditions_OVE_M);

            LpiWakeVortexConditions wtc_conditions_OVE_H(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_H().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_H().minValue(),
            "H");
            wtc_conditions_vector_OVE.push_back(wtc_conditions_OVE_H);

            LpiWakeVortexConditions wtc_conditions_OVE_J(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_J().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).percentage_OVE().percentage_WTC_J().minValue(),
            "J");
            wtc_conditions_vector_OVE.push_back(wtc_conditions_OVE_J);

            //Get reductions
            float reduction_OVE(in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE(ii).reductionValue_OVE());

            output.addWTCReductionOVA(wtc_conditions_vector_OVE,
                                   reduction_OVE);
        }
    }
}
/*

         LpiWakeVortexConditions wtc_conditions_DEP_L(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_L().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_L().minValue(),
            "L");
         wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_L);

         LpiWakeVortexConditions wtc_conditions_DEP_M(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_M().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_M().minValue(),
            "M");
         wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_M);

         LpiWakeVortexConditions wtc_conditions_DEP_H(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_H().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_H().minValue(),
            "H");
         wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_H);

         LpiWakeVortexConditions wtc_conditions_DEP_J(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_J().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().percentage_DEP().percentage_WTC_J().maxValue(),
            "J");
         wtc_conditions_vector_DEP.push_back(wtc_conditions_DEP_J);


         LpiWakeVortexConditions wtc_conditions_OVE_L(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_L().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_L().minValue(),
            "L");
         wtc_conditions_vector_OVA.push_back(wtc_conditions_OVE_L);

         LpiWakeVortexConditions wtc_conditions_OVE_M(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_M().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_M().minValue(),
            "M");
         wtc_conditions_vector_OVA.push_back(wtc_conditions_OVE_M);

         LpiWakeVortexConditions wtc_conditions_OVE_H(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_H().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_H().minValue(),
            "H");
         wtc_conditions_vector_OVA.push_back(wtc_conditions_OVE_H);

         LpiWakeVortexConditions wtc_conditions_OVE_J(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_J().maxValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().percentage_OVE().percentage_WTC_J().maxValue(),
            "J");
         wtc_conditions_vector_OVA.push_back(wtc_conditions_OVE_J);


         LpiADOVector<float> reduction(
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_ARR().arrivalReductionValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_DEP().departureReductionValue(),
            in().wakeVortexCapacityReductionICAO(i).capacityReduction_OVE().overallReductionValue());

         output.addWTCReduction(wtc_conditions_vector_ARR,
                                wtc_conditions_vector_DEP,
                                wtc_conditions_vector_OVA,
                                reduction);
     }
}
*/

