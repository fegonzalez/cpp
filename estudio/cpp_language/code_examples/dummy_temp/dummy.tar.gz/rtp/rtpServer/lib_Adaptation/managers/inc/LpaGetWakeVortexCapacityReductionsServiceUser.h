/*
 * LpaGetWakeVortexCapacityReductionsServiceUser.h
 *
 *  Created on: 22 ago. 2017
 *      Author: cgudin
 */

#ifndef C__LPAGETWAKEVORTEXCAPACITYREDUCTIONSSERVICEUSER_H_
#define C__LPAGETWAKEVORTEXCAPACITYREDUCTIONSSERVICEUSER_H_

#include <LpiIServiceUsers.h>
#include <daortp_wakevortexcapacityreductions_xsd.h>
#include <LpaWakeVortexCapacityReductions.h>
#include <LclogStream.h>

class LpaGetWakeVortexCapacityReductionsServiceUser : public LpiIGetWakeVortexCapacityReductionsSrvUser
{
public:
   LpaGetWakeVortexCapacityReductionsServiceUser() {}

   /**
    * Inicializa la lectura del fichero XML que contiene la informacion de configuracion
    * @param name es el nombre del fichero XML
    */
   void init(const std::string &name)
   {
      this->_WTC_capacity.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug() << "Initialized File: " << name << std::endl;
#endif

      LpdComponent::Get().delegateUser(*this);
   }

   /**
    * Servicio usado para volcar la informacion leida del XML a los tipos internos
    * @param request es la peticion del servicio
    * @param reply es la respuesta del servicio
    */
   virtual void use(LpiGetWakeVortexCapacityReductionsReply &reply)
   {
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif
      LpiWakeVortexCapacityReductions capacity;
      LpaWakeVortexCapacityReductions::convert2WTCapacityReductionsInfo(this->_WTC_capacity, capacity);
      reply.setWakeVortexCapacityReductions(capacity);
      reply.setResult(LpiResult::E_OK);
   }


private:
   WakevortexCapacityReductions::WTC_capacityReductionICAO_BlockElement _WTC_capacity;
};


#endif /* C__LPAGETWAKEVORTEXCAPACITYREDUCTIONSSERVICEUSER_H_ */
