/*
 * LpaPriorityTable.h
 *
 */

#ifndef __LPA_PRIORITY_TABLE_H__
#define __LPA_PRIORITY_TABLE_H__

#include "daortp_fppriority_xsd.h"
#include <LpiPriorityTable.h>
#include <LclogStream.h>

class LpaPriorityTable
{
   public:

       static void Convert2Charateristic (const FpPriority::FPCharacteristicName::Enum & input,
                                          LpiFPCharacteristic::LpiEnum & output);

       static void Convert2PriorityTableDepartures (const FpPriority::PriorityElement & input,
                                          LpiPriorityTable  & output);

       static void Convert2PriorityTableArrivals (const FpPriority::PriorityElement & input,
                                          LpiPriorityTable  & output);
};


#endif /* __LPA_PRIORITY_TABLE_H__ */
