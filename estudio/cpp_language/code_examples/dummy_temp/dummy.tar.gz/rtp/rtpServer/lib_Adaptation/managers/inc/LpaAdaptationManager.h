/*
 * LpaAdaptationManager.h
 *
 */

#ifndef LPAADAPTATIONMANAGER_H_
#define LPAADAPTATIONMANAGER_H_

#include <boost/shared_ptr.hpp>
#include <boost/property_tree/exceptions.hpp>

#include <iostream>

#include <LplcTypeConstants.h>
#include <LpaGetAdaptationMrtmInfoServiceUser.h>
#include <LpaGetAdaptationAirportsInfoServiceUser.h>
#include <LpaGetAdaptationAssignmentPreferenceServiceUser.h>
#include <LpaGetPriorityServiceUser.h>
#include <LpaGetAdaptationAlert_KPIServiceUser.h>


#include <dirent.h>

#include <LpaGetWakeVortexCapacityReductionsServiceUser.h>

class LpaAdaptationManager
{
public:
   static LpaAdaptationManager & Get(void)
   {
      static LpaAdaptationManager manager;
      return manager;
   }

   void initialise(void)
   {

     try {
       _getMrtmInfoServiceUser->init
	 (std::string(rtp_constants::CFGDIR_ADAP + "/" + 
		      rtp_constants::FILENAME_DAORTP_MRTM_INFO));
     } catch (std::exception& ex) {
       std::cerr << "[ERROR]: Please, check the adaptation file "
		 << rtp_constants::FILENAME_DAORTP_MRTM_INFO << std::endl;
       std::cerr << "[ERROR]: " << ex.what() << std::endl;
       exit(EXIT_FAILURE);
     }


     try {
       _getAssignmentPreferenceServiceUser->init
	 (std::string(rtp_constants::CFGDIR_ADAP + "/" + 
		      rtp_constants::FILENAME_DAORTP_ASSIGNMENT_PREFERENCE));
        } catch (std::exception& ex) {
            std::cerr << "[ERROR]: Please, check the adaptation file "
		      << rtp_constants::FILENAME_DAORTP_ASSIGNMENT_PREFERENCE 
		      << std::endl;
            std::cerr << "[ERROR]: " << ex.what() << std::endl;
            exit(EXIT_FAILURE);
        }

        try {
            _getAirportsInfoServiceUser->init
	      (std::string(rtp_constants::CFGDIR_ADAP + "/" + 
			   rtp_constants::FILENAME_DAORTP_AIRPORTS_INFO));

        } catch (std::exception& ex) {
            std::cerr << "[ERROR]: Please, check the adaptation file "
		      << rtp_constants::FILENAME_DAORTP_AIRPORTS_INFO 
		      << std::endl;
            std::cerr << "[ERROR]: " << ex.what() << std::endl;
            exit(EXIT_FAILURE);
        }

        try
        {
           _getPriorityServiceUser->init
	      (std::string(rtp_constants::CFGDIR_ADAP + "/" + 
			   rtp_constants::FILENAME_DAORTP_FP_PRIORITY));
        }
        catch(std::exception& ex)
        {
           std::cerr << "[ERROR]: Please, check the adaptation file "
                 << rtp_constants::FILENAME_DAORTP_FP_PRIORITY << std::endl;
           std::cerr << "[ERROR]: " << ex.what() << std::endl;
           exit(EXIT_FAILURE);
        }

        try
        {
           _getAlert_KPIsServiceUser->init
	      (std::string(rtp_constants::CFGDIR_ADAP + "/" + 
			   rtp_constants::FILENAME_DAORTP_ALERT_KPI));
        }
        catch(std::exception& ex)
        {
           std::cerr << "[ERROR]: Please, check the configuration file "
                   << rtp_constants::FILENAME_DAORTP_ALERT_KPI << std::endl;
           std::cerr << "[ERROR]: " << ex.what() << std::endl;
           exit(EXIT_FAILURE);
        }

        try
        {
           _getWakeVortexCapacityReductionsServiceUser->init(
                   std::string(rtp_constants::CFGDIR_ADAP + "/" +
                       rtp_constants::FILENAME_DAORTP_WAKEVORTEX_CPACITY));
        }
        catch(std::exception& ex)
        {
            std::cerr << "[ERROR]: Please, check the adaptation file "
                  << "DAORTP_WakevortexCapacityReductions.xml" << std::endl;
            std::cerr << "[ERROR]: " << ex.what() << std::endl;
            exit(EXIT_FAILURE);
        }

   }

private:
   LpaAdaptationManager ():
   _getMrtmInfoServiceUser(new LpaGetAdaptationMrtmInfoServiceUser()),
   _getAssignmentPreferenceServiceUser(new LpaGetAdaptationAssignmentPreferenceServiceUser()),
   _getAirportsInfoServiceUser(new LpaGetAdaptationAirportsInfoServiceUser()),
   _getPriorityServiceUser(new LpaGetPriorityServiceUser()),
   _getAlert_KPIsServiceUser(new LpaGetAdaptationAlert_KPIServiceUser()),
   _getWakeVortexCapacityReductionsServiceUser
   	   (new LpaGetWakeVortexCapacityReductionsServiceUser())

   {}


   boost::shared_ptr<LpaGetAdaptationMrtmInfoServiceUser>
                                         _getMrtmInfoServiceUser;
   boost::shared_ptr<LpaGetAdaptationAirportsInfoServiceUser>
                                         _getAirportsInfoServiceUser;
   boost::shared_ptr<LpaGetAdaptationAssignmentPreferenceServiceUser>
                                         _getAssignmentPreferenceServiceUser;
   boost::shared_ptr<LpaGetPriorityServiceUser>
                                         _getPriorityServiceUser;
   boost::shared_ptr<LpaGetAdaptationAlert_KPIServiceUser>
                                          _getAlert_KPIsServiceUser;

   boost::shared_ptr<LpaGetWakeVortexCapacityReductionsServiceUser>
                                    _getWakeVortexCapacityReductionsServiceUser;

};


#endif /* LPAADAPTATIONMANAGER_H_ */
