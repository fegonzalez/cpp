/*
 * LpaGetAdaptationMrtmInfoServiceUser.h
 *
 */

#ifndef LPAGETAdaptationMrtmInfoSERVICEUSER_H_
#define LPAGETAdaptationMrtmInfoSERVICEUSER_H_

#include <LpiIServiceUsers.h>
#include <daortp_smmrtminfo_xsd.h>
#include <LpaAdaptationMrtmInfo.h>
#include <LclogStream.h>

class LpaGetAdaptationMrtmInfoServiceUser : public LpiIGetAdaptationMrtmInfoSrvUser
{
public:
	LpaGetAdaptationMrtmInfoServiceUser() {}

   /**
    * Inicializa la lectura del fichero XML que contiene la informacion de configuracion
    * @param name es el nombre del fichero XML
    */
   void init(const std::string &name)
   {
      this->_mrtmInfo.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug() <<"Initialized File: "<<name<<std::endl;
#endif


      LpdComponent::Get().delegateUser(*this);
   }

   /**
    * Servicio usado para volcar la informacion leida del XML a los tipos internos
    * @param request es la peticion del servicio
    * @param reply es la respuesta del servicio
    */
   virtual void use(LpiGetAdaptationMrtmInfoReply &reply)
   {
#ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug()
       << " : File: " << __FILE__
       << " ; fn: " << __func__
       << " ; line: " << __LINE__
       << std::endl;
#endif

	   LpiAdaptationMrtmInfo mrtm;
	   LpaAdaptationMrtmInfo::convert2AdaptationMrtmInfo(this->_mrtmInfo, mrtm);
	   reply.setAdaptationMrtmInfo(mrtm);
	   reply.setResult(LpiResult::E_OK);
   }


private:
   SmMrtmInfo::MrtmElement _mrtmInfo;
};


#endif /* LPAGETAdaptationMrtmInfoSERVICEUSER_H_ */
