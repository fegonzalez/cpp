// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 10:21:10 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPCFGCONFIGURATIONALERT_KPIS_H_
#define LPCFGCONFIGURATIONALERT_KPIS_H_

#include <LpiAdaptationAlert_KPIs.h>
#include <daortp_alertkpi_xsd.h>
#include <LclogStream.h>

class LpaAdaptationAlert_KPIs
{
public:
    static void convert2AdaptationKpiParam(const AlertKpi::AbsoluteKPIsElement &alert_KPIs,
                                              LpiAdaptationAlert_KPIs &output);
};

#endif /* LPCFGCONFIGURATIONALERT_KPIS_H_ */
