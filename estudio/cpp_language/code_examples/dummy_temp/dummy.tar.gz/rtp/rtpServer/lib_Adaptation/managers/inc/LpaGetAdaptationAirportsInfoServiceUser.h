/*
 * LpaGetAdaptationAirportsInfoServiceUser.h
 *
 */

#ifndef LPAGETAdaptationAirportsInfoSERVICEUSER_H_
#define LPXAGETAdaptationAirportsInfoSERVICEUSER_H_

#include <LpiIServiceUsers.h>
#include <LpaAdaptationAirportsInfo.h>

class LpaGetAdaptationAirportsInfoServiceUser : public LpiIGetAdaptationAirportsInfoSrvUser
{
public:
   LpaGetAdaptationAirportsInfoServiceUser() {}

   /**
    * Inicializa la lectura del fichero XML que contiene la informacion de configuracion
    * @param name es el nombre del fichero XML
    */
   void init(const std::string &name)
   {
      this->_airportsInfo.open(name);

#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug() <<"Initialized File: "<<name<<std::endl;
#endif

      LpdComponent::Get().delegateUser(*this);
   }

   /**
    * Servicio usado para volcar la informacion leida del XML a los tipos internos
    * @param request es la peticion del servicio
    * @param reply es la respuesta del servicio
    */
   virtual void use(LpiGetAdaptationAirportsInfoReply &reply)
   {
//#ifdef TRACE_OUT
//     LclogStream::instance(LclogConfig::E_RTP).debug()
//       << " : File: " << __FILE__
//       << " ; fn: " << __func__
//       << " ; line: " << __LINE__
//       << std::endl;
//#endif
       LpiAdaptationAirportsInfo rtp_airportInfo;
       LpaAdaptationAirportsInfo::convert2AdaptationAirportsInfo(this->_airportsInfo, rtp_airportInfo);

	   reply.setAdaptationAirportsInfo(rtp_airportInfo);
	   reply.setResult(LpiResult::E_OK);
   }


private:
   FpAirportsInfo::AirportsElement _airportsInfo;
};


#endif /* LPAGETAdaptationAirportsInfoSERVICEUSER_H_ */
