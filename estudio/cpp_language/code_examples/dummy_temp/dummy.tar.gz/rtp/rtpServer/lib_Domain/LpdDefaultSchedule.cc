/*
 * LpdDefaultSchedule.cc
 *
 *  Created on: Oct 29, 2018
 *      Author: srperez
 */

#include "LpdDefaultSchedule.h"
#include <boost/algorithm/string/trim.hpp>

LpdDefaultSchedule::LpdDefaultSchedule()
{
	//generateDefaultSchedule();
}

void LpdDefaultSchedule::generateDefaultSchedule ()
{
   //clearPonderationCriteria();

//   std::vector<std::string> default_schedule;


   std::vector<std::string> listATS = { "ENNA", "ENBO", "ENRO", "ENHD" };
   std::vector<std::string> optimalATS = scheduleDefault(listATS, 6);

//   std::cout << "\n";
   std::vector<std::string> listAFIS = { "ENRS", "ENMH", "ENHK", "ENRM", "ENSH", "ENML", "ENSG", "ENSS", "ENNM", "ENBV", "ENBL" };
   std::vector<std::string> optimalAFIS = scheduleDefault(listAFIS, 6 - optimalATS.size());

   default_schedule = optimalATS;
   for(unsigned int i = 0; i < optimalAFIS.size(); i++)
	   default_schedule.push_back(optimalAFIS.at(i));

	for(unsigned int i = 0; i < default_schedule.size(); i++)
	   std::cout << "Módulo " << i + 1 << ": " << default_schedule.at(i) << std::endl;

//   r_default_schedule = default_schedule;
//   std::cout << defaultSchedule.size() << std::endl;
}

std::vector<std::string> LpdDefaultSchedule::getDefaultSchedule()
{
	return default_schedule;
}

void LpdDefaultSchedule::setAdaptationPreference(LpiAdaptationAssignmentPreference pref)
{
	preference = pref;
}

int LpdDefaultSchedule::calculateCost(std::string a1, std::string a2)
{
	int costAux = 0;

	for(unsigned int i = 0; i < preference.getPreferentialAllocation().getAllocation().size(); i++)
	{
		std::string pref1 = preference.getPreferentialAllocation().getAllocation().at(i).getAirport1();
		std::string pref2 = preference.getPreferentialAllocation().getAllocation().at(i).getAirport2();
		boost::algorithm::trim(pref1);
		boost::algorithm::trim(pref2);

		if((pref1 == a1 && pref2 == a2) || (pref1 == a2 && pref2 == a1))
		{
			if(preference.getPreferentialAllocation().getAllocation().at(i).getStartTime() == " 06:00 "
					&& preference.getPreferentialAllocation().getAllocation().at(i).getEndTime() == " 14:00 ")
				costAux += preference.getPreferentialAllocation().getAllocation().at(i).getPreferentialLevel();
			else
				costAux += 100;
		}
		else
				costAux += 100;
	}

	for(unsigned int i = 0; i < preference.getNotAllowedAllocation().getAllocation().size(); i++)
	{
		std::string proh1 = preference.getNotAllowedAllocation().getAllocation().at(i).getAirport1();
		std::string proh2 = preference.getNotAllowedAllocation().getAllocation().at(i).getAirport2();
		boost::algorithm::trim(proh1);
		boost::algorithm::trim(proh2);

		if((proh1 == a1 && proh2 == a2) || (proh1 == a2 && proh2 == a1))
		{
			if(preference.getPreferentialAllocation().getAllocation().at(i).getStartTime() == " 06:00 "
					&& preference.getPreferentialAllocation().getAllocation().at(i).getEndTime() == " 14:00 ")
				costAux += 10000;
		}
	}

	return costAux;
}

std::vector<std::string> LpdDefaultSchedule::scheduleDefault(std::vector<std::string> listAirports, unsigned int numMrtm)
{
	 std::vector<std::string> v = listAirports;
	  unsigned size = v.size();

	  std::vector<std::vector<std::string>> listMrtmAirp;

	      try {
	      	LpmodPartition::iterator it(size);

	        while (true) {

	      	  std::vector<std::string> listAirp;
	      	  std::auto_ptr<std::vector<std::vector<std::string> > > part;

	      		  part = it[v];

	      	  for(unsigned int i = 0; i < part.get()->size(); i++)
	      	  {
	      		  std::stringstream a("");
	      		  a << part.get()->at(i);
	      		  listAirp.push_back(a.str());

	      	  }
	      	  listMrtmAirp.push_back(listAirp);

	      	  ++it;
	        }
	      } catch (std::overflow_error&) {}

	    std::vector<std::vector<std::string>> listMrtmAirpF;
	    for(unsigned int x = 0; x < listMrtmAirp.size(); x++)
	    {
	  	  if(listMrtmAirp.at(x).size() <= numMrtm) // numero de módulos
	  	  {
	  		  bool cumple = true;
	  		  for(unsigned int y = 0; y < listMrtmAirp.at(x).size(); y++)
	  		  {
	  			  //si cada modulo tiene != de 2 aeropuertos elimina la combinación
	  			  if(splitString(listMrtmAirp.at(x).at(y), " ").size() != 2)
	  				  if(splitString(listMrtmAirp.at(x).at(y), " ").size() != 3)
	  				  cumple = false;
	  		  }
	  		  if(cumple == true)
	  			  listMrtmAirpF.push_back(listMrtmAirp.at(x));
	  	  }
	    }

//	    for(unsigned int x = 0; x < listMrtmAirpF.size(); x++)
//	      {
//	    	  std::cout << "Combinacion: " << x + 1 << std::endl;
//	    	  for(unsigned int y = 0; y < listMrtmAirpF.at(x).size(); y++)
//	    	  {
//	    		  std::cout << "Modulo: " << y + 1 << std::endl;
//	    		  std::cout << listMrtmAirpF.at(x).at(y) << std::endl;
//	    	  }
//	    	  std::cout << "\n";
//	      }

	    int cost = 1000000;
	    std::vector<std::string> fin;
	    for(unsigned int a = 0; a < listMrtmAirpF.size(); a ++)
	    {
	  	  int costAux = 0;
	  	  for(unsigned int b = 0; b < listMrtmAirpF.at(a).size(); b++)
	  	  {
	  //		  if(QString::fromStdString(listMrtmAirpF.at(a).at(b)).split(" ").size() == 1)
	  //			  costAux += 100; ¿?¿?

	  		  if(splitString(listMrtmAirpF.at(a).at(b), " ").size() == 2)
	  		  {
	  			  std::string a1 = splitString(listMrtmAirpF.at(a).at(b), " ").at(0);
	  			  std::string a2 = splitString(listMrtmAirpF.at(a).at(b), " ").at(1);

	  			  costAux += calculateCost(a1, a2);
	  		  }

	  		  else if(splitString(listMrtmAirpF.at(a).at(b), " ").size() == 3)
	  		  {
	  			  std::string a1 = splitString(listMrtmAirpF.at(a).at(b), " ").at(0);
	  			  std::string a2 = splitString(listMrtmAirpF.at(a).at(b), " ").at(1);
	  			  std::string a3 = splitString(listMrtmAirpF.at(a).at(b), " ").at(2);

	  			  costAux += calculateCost(a1, a2);
	  			  costAux += calculateCost(a1, a3);
	  			  costAux += calculateCost(a2, a3);
	  		  }
	  //std::cout << costAux << std::endl;
	  	  }
	  	  if(costAux > 0 && costAux < cost)
	  	  {
	  		  cost = costAux;
	  //		  std::cout << "COST:    " << cost << std::endl;
	  		  fin = listMrtmAirpF.at(a);
	  	  }
	  //	  std::cout << "\n";
	    }

//	  std::cout << "Combinación óptima: " << std::endl;
//	  for(unsigned int q = 0; q < fin.size(); q++)
//	  {
//		  std::cout << "Módulo: " << q + 1 << std::endl;
//		  std::cout << fin.at(q) << std::endl;
//	  }
	  return fin;
}

std::vector<std::string> LpdDefaultSchedule::splitString( const std::string& strStringToSplit,
                                               const std::string& strDelimiter,
                                               const bool keepEmpty ) {
    std::vector<std::string> vResult;
    if ( strDelimiter.empty() ) {
        vResult.push_back( strStringToSplit );
        return vResult;
    }

    std::string::const_iterator itSubStrStart = strStringToSplit.begin(), itSubStrEnd;
    while ( true ) {
        itSubStrEnd = search( itSubStrStart, strStringToSplit.end(), strDelimiter.begin(), strDelimiter.end() );
        std::string strTemp( itSubStrStart, itSubStrEnd );
        if ( keepEmpty || !strTemp.empty() ) {
            vResult.push_back( strTemp );
        }

        if ( itSubStrEnd == strStringToSplit.end() ) {
            break;
        }

        itSubStrStart = itSubStrEnd + strDelimiter.size();
    }

    return vResult;
}
