/*
 * LpdMeteoLogic.cc
 *
 * Section of  LpdBusinessLogicFacade.cc related to meteorological calculations
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx"
 *
 */

#include "LpdBusinessLogicFacade.h"
#include <LpdComponent.h>
#include <LplcTypeConstants.h>
#include <LpdbDataBase.h>
#include <LpdbMeteoTimedData.h>
#include <LpdbMeteoTimelineConverter.h>
//#include <LpiRunwayMeteoInfo.h>
#include <LpiMeteoForecastEvt.h>
#include <LpiMeteoNowcastEvt.h>
#include <LclogStream.h>

#include <iostream>
//#include <ctime>
#include <string>
#include <vector>
#include <iterator>
//#include <cassert>
#include <algorithm>    // std::for_each

#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>


//-----------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)

   @brief For all the managed airports, check meteo info on clock
   event (add stored info to new interval)

   - Update meteo info in the DB after a CLOCK event (for all airports);
   - Send meteo info for the new interval to the HMI (for all airports)

   (called from void LpdBusinessLogicFacade::forwardTimeline(void))
*/
void LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "Business Logic: forward meteo information in database. Last interval: "
    << new_interval
    << ", for ALL the airports ..."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  std::vector<std::string> airport_keys =
    LpdbDataBase::Get().getAirportTable().getAllIds();
  BOOST_FOREACH(const std::string & airport_id, airport_keys)
  {
    reviewMeteoInfo(airport_id, new_interval);
  }
}

//-----------------------------------------------------------------------------

///@brief reviewMeteoInfo for the pair (airport, interval)
void LpdBusinessLogicFacade::reviewMeteoInfo(std::string airport_id,
					     std::string new_interval)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).info()
    << "Business Logic: forward meteo information in database. "
    << " for airport =  <" << airport_id << '>'
    << " , and for last interval =  <" << new_interval << '>'
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

  if(LpdbDataBase::Get().getNumberOfMeteoReportsReceived(airport_id) <= 0 )
  {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "No meteo reports found for airport <" << airport_id << '>'
      << " ; File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif

    return;
  }


  // I. Update DB: for each airport, for all the received reports on the airport

  // I.a) remove obsolete reports

  LpdbDataBase::Get().deleteObsoleteMeteoReports(airport_id);


  // I.b) update data for the new (forwarded) interval

  /**@warning not optimal: repeating the operation for every meteo
     block => each time removing the former value. Eventually we use
     the most recent report (that is stored at the end of the vector
     'meteo_blocks'), that have affected intervals.

     @todo (nice to have) optimization of this logic.
  */
  for (unsigned int i = 0;
       i < LpdbDataBase::Get().getNumberOfMeteoReportsReceived(airport_id);
       ++i)
  {
    LpiMeteoInfo meteo = LpdbDataBase::Get().getMeteoReport(airport_id, i);
    posix_time::ptime begin_time = meteo.getStartTimeAndDate();
    posix_time::ptime end_time = meteo.getEndTimeAndDate();

    TimeLine<LpdbMeteoTimedData> & meteoForecast =
      LpdbDataBase::Get().getMeteoForecast(airport_id);

    std::vector<std::string> affected_intervals = meteoForecast.getIntervalsInRange
                                                      (begin_time, end_time);

    //Check if new interval (the current last) is affected by any stored report
    std::vector<std::string>::iterator it = std::find(affected_intervals.begin(),
					    affected_intervals.end(),
					    new_interval);
    if (it != affected_intervals.end())
    {
#ifdef TRACE_OUT
      LclogStream::instance(LclogConfig::E_RTP).debug()
	<< "Forward meteo: afected interval: " << new_interval
	<< " ; File: " << __FILE__
	<< " ; fn: " << __func__
	<< " ; line: " << __LINE__
	<< std::endl;
#endif

      if (meteoForecast.hasData(new_interval))
      {
	fillIntervalData(meteoForecast[new_interval], meteo);
	LpdbDataBase::Get().setMeteoForecast(airport_id, meteoForecast);
      }
    }
    
  }//end-for

  
  // II. Send meteo forecast update to HMI: one timeline per airport
  LpiUpdateMeteo airport_meteo_report;
  airport_meteo_report.setCalculationReason(LpiCalculationReason::E_CLOCK);
  airport_meteo_report.setAirport(airport_id);
  boost::optional<boost::posix_time::ptime> initialTime =
    LpdbDataBase::Get().getMeteoForecast(airport_id).getInitialTime();
  if (initialTime.is_initialized())
  {
    airport_meteo_report.setMessageTimeandDate(initialTime.get());
  }
  else
  {
    airport_meteo_report.setMessageTimeandDate(ptime());
  }
  
  airport_meteo_report.setMeteoInfo
    (LpdbDataBase::Get().getReceivedMeteoReports(airport_id));
  airport_meteo_report.setTimeline
    (LpdbMeteoTimelineConverter::Convert2Interface
     (LpdbDataBase::Get().getMeteoForecast(airport_id)));
  
  LpiUpdateMeteoList meteo_report_list;
  meteo_report_list.push_back(airport_meteo_report);

  LpiMeteoForecastEvt meteoEvt;
  meteoEvt.setMeteoForecast(meteo_report_list);
  LpdComponent::Get().publish(meteoEvt);
}

//------------------------------------------------------------------------------

/**@brief update DB with the new meteo NOWcast data received for N airports
   Event E_NEW_METEO_NOWCAST
   (Called from LpdComponent::updateMeteoNowcast)
*/
void LpdBusinessLogicFacade::updateMeteoNowcast(const LpiCreateMeteoList & meteolist)
{

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "TEST: RTP-MeteoNowcast-CONSUMER: New meteo info: "
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif


  // section I: update DB with the new meteo data
  updateMeteoNowcastDB(meteolist);


///@test db_meteo_nowcast: Here the stored (airport, interval) data in the DB.
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TEST: Meteo DB (nowcast) updated: "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
  for(unsigned int meteo_data_i = 0;
      meteo_data_i < meteolist.size();
      ++meteo_data_i)
  {
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "Airport: <" << meteolist[meteo_data_i].getAirport() << ">\n"
      << LpdbDataBase::Get().getMeteoForecast(meteolist[meteo_data_i].
					      getAirport());   
  }
#endif

    
  // section II (depends on the timeline stored in the DB): send the
  // meteo data to the HMI
  updateMeteoNowcastHmi(meteolist);


  ///@todo section III: update the optimal schedule using the new meteo data

  /// void LpdBusinessLogicFacade::updateMeteoNowcastSchedule(const LpiCreateMeteoList & meteolist)

  /** @todo Upon RTP's CORE construction review the following code. (it is the RMAN's code)


 setExpirationDateForWhatIfs(LctimVirtualClock::Get().getTime());

   #ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).info() << "OPTIMAL SCHEDULE CALCULATION" <<std::endl;
   LclogStream::instance(LclogConfig::E_RTP).info() << "Calculation cause: Meteo Nowcast input received" <<std::endl;
   #endif

   std::string our_airport = LpdbDataBase::Get().getGlobalParameters().getAerodromeName();

   if (meteolist.getairport() != our_airport)
   {
   #ifdef TRACE_OUT
   LclogStream::instance(LclogConfig::E_RTP).info() << "Business Logic: meteorological information doesn't concern our airport..." << std::endl;
   LclogStream::instance(LclogConfig::E_RTP).info() << "Meteo airport:" << meteolist.getairport() << std::endl;
   LclogStream::instance(LclogConfig::E_RTP).info() << "Our airport:" << our_airport << std::endl;
   #endif
   return;
   }


     calculateMaxCapacities();
     calculateEstimatedDCB();

     #ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).debug() << "Estimated DCB calculations: " << std::endl;
     LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getEstimatedDCBAsString() << std::endl;

     LclogStream::instance(LclogConfig::E_RTP).debug() << "Invocation to schedules generation..." << std::endl;
     #endif

     generateSchedulesForAllIntervals();

     calculateRealDCBAndRunwayAllocation();

     #ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).info() << "FPS Schedule calculations..." <<std::endl;
     #endif

     performFPInScheduleCalculations();

     #ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).info() << "Calculate KPIs..." << std::endl;
     #endif

     bool isClockForwarding = false;
     calculateSchedulesKPIs(isClockForwarding);

     #ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).info() << "Calculate Optimal Schedule..." << std::endl;
     #endif

     generateOptimalSchedule();

     performActiveScheduleCalculations(isClockForwarding);

     publishOptimalAndActiveSchedules(LpiCalculationReason::E_NEW_METEO_NOWCAST);

     #ifdef TRACE_OUT
     LclogStream::instance(LclogConfig::E_RTP).info() << "[RUNWAY FINAL ASSIGNATION]: " << std::endl;
     #endif

     calculateRunwayFinalAssignation();

     LpdbDataBase::Get().setInputReceivedInLastInterval(true); */


}

//------------------------------------------------------------------------------

///@brief update DB with the new meteo NOWcast data received for N airports
void LpdBusinessLogicFacade::updateMeteoNowcastDB(const LpiCreateMeteoList & meteolist)
{
  for(unsigned int data_i = 0; data_i < meteolist.size(); ++data_i)
  {
    updateMeteoNowcastDB(meteolist[data_i]);
  }
}

//------------------------------------------------------------------------------

///@brief update DB with the new meteo NOWcast data received for 1 airport
void LpdBusinessLogicFacade::updateMeteoNowcastDB(const LpiCreateMeteo & meteoData)
{
  // a) Store every meteo report received for further use after CLOCK event
  for (unsigned int i = 0; i < meteoData.getMeteoInfo().size(); i++)
  {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).info() 
      << "Adding received Meteorological Nowcast block to DB." << std::endl;
#endif
    
    LpdbDataBase::Get().addMeteoReport(meteoData.getAirport(),
				       meteoData.getMeteoInfo()[i]);
  }


  // b) Storing received meteo data among intervals (IOMeteoTimeline:.idl)

  /**@warning not optimal: repeating the operation for every meteo
     block => each time removing the former value. Eventually we use
     the most recent report (that is stored at the end of the vector
     'meteo_blocks'), that have affected intervals.

     @todo (nice to have) optimization of this logic.
  */
  std::vector<LpiMeteoInfo> meteo_blocks = meteoData.getMeteoInfo();
  for(unsigned int i = 0; i < meteo_blocks.size(); ++i)
  {
    LpiMeteoInfo meteo = meteo_blocks[i];

    TimeLine<LpdbMeteoTimedData>  & meteoForecast =
      LpdbDataBase::Get().getMeteoForecast(meteoData.getAirport());

    std::vector<std::string> affected_intervals = meteoForecast.getIntervalsInRange
      (meteo.getStartTimeAndDate(), meteo.getEndTimeAndDate());

    //for each interval affected by the meteo-bodyInformation
    BOOST_FOREACH(std::string ti, affected_intervals)
    {
      if (meteoForecast.hasData(ti))
      {
    	  fillIntervalData(meteoForecast[ti], meteo);
	  meteoForecast[ti].setHasNowcastReport(true);
      }
    }
    LpdbDataBase::Get().setMeteoForecast(meteoData.getAirport(), meteoForecast);
  }

  LpdbDataBase::Get().setInputReceivedInLastInterval(true);
} 
  
//-----------------------------------------------------------------------------

///@brief Send Meteo (nowcast) data to the HMI for N airports
void LpdBusinessLogicFacade::updateMeteoNowcastHmi
(const LpiCreateMeteoList & meteolist)
{
  LpiCreateMeteoList meteoReport = meteolist;  // to update setTimeline

  /**@warning If we don't explicitly set calculationReason & timeline fields,
     then iMASBlue error "...deserialize..", and the data never gets
     to the HMI consumer.

     The timeline values are updated after every meteo msg. is received:
     void LpdBusinessLogicFacade::updateMeteoNowcastDB(const LpiCreateMeteo & meteoData)
     void LpdBusinessLogicFacade::updateMeteoForecastDB(const LpiCreateMeteo & meteoData)
  */
  std::for_each(std::begin(meteoReport), std::end(meteoReport),
		[](LpiCreateMeteo &val)
  {
    val.setCalculationReason(LpiCalculationReason::E_NEW_METEO_NOWCAST);
    val.setTimeline(LpdbMeteoTimelineConverter::Convert2Interface
		    (LpdbDataBase::Get().getMeteoForecast(val.getAirport())));
  });

  //////////////////////////
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "RTP-MeteoNowcast-CONSUMER: New meteo info to HMI: "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << "\n LpiCreateMeteoList & meteoReport: size = "
    << meteoReport.size()
    << " ; list: ";

  std::for_each(std::begin(meteoReport),
		std::end(meteoReport),
		[](const LpiCreateMeteo &val)
		{
		  LclogStream::instance(LclogConfig::E_RTP).debug()
		    << val << std::endl;
		});
#endif
  //////////////////////////


  // Send MeteoNowcast to HMI
  LpiMeteoNowcastEvt meteoEvt;
  meteoEvt.setMeteoNowcast(meteoReport);
  LpdComponent::Get().publish(meteoEvt);

}

//------------------------------------------------------------------------------

/**@brief update DB with the new meteo FOREcast data received for N airports
   Event E_NEW_METEO_FORECAST
   (Called from LpdComponent::updateMeteoForecast)
*/
void LpdBusinessLogicFacade::updateMeteoForecast(const LpiCreateMeteoList &meteolist)
{

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "TEST: RTP-MeteoForecast-CONSUMER: New meteo info: "
      << " : File: " << __FILE__
      << " ; fn: " << __func__
      << " ; line: " << __LINE__
      << std::endl;
#endif


  // section I: update DB with the new meteo data
  updateMeteoForecastDB(meteolist);
    

  ///@test db_meteo_forecast: Here the stored (airport, interval) data in the DB
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TEST: Meteo DB (forecast) updated: "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
  for(unsigned int meteo_data_i = 0;
      meteo_data_i < meteolist.size();
      ++meteo_data_i)
  {
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << LpdbDataBase::Get().getMeteoForecast(meteolist[meteo_data_i].
					      getAirport());
  }
#endif


    // section II (depends on the timeline stored in the DB): send the
    // meteo data to the HMI
    updateMeteoForecastHmi(meteolist);


    ///@todo section III: update the optimal schedule using the new meteo data
    /// void LpdBusinessLogicFacade::updateMeteoForecastSchedule(const LpiCreateMeteoList & meteolist)


//    setExpirationDateForWhatIfs(LctimVirtualClock::Get().getTime());
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).info() << "OPTIMAL SCHEDULE CALCULATION" <<std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Calculation cause: Meteo Forecast input received" <<std::endl;
//#endif


    //
    //    //Process meteo information only if concerns to our airport
    //    std::string our_airport = LpdbDataBase::Get().getGlobalParameters().getAerodromeName();
    //    if (meteolist.getairport() != our_airport)
    //    {
    //#ifdef TRACE_OUT
    //        LclogStream::instance(LclogConfig::E_RTP).info() << "Business Logic: meteorological information doesn't concern our airport..." << std::endl;
    //#endif
    //
    //        return;
    //    }

//
//    calculateMaxCapacities();
//    calculateEstimatedDCB();
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Estimated DCB calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getEstimatedDCBAsString() << std::endl;
//
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Invocation to schedules generation..." << std::endl;
//#endif
//
//    generateSchedulesForAllIntervals();
//
//    calculateRealDCBAndRunwayAllocation();
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).info() << "FPS Schedule calculations..." <<std::endl;
//#endif
//
//    performFPInScheduleCalculations();
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Calculate KPIs..." << std::endl;
//#endif
//
//    bool isClockForwarding = false;
//    calculateSchedulesKPIs(isClockForwarding);
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Calculate Optimal Schedule..." << std::endl;
//#endif
//
//    generateOptimalSchedule();
//
//    performActiveScheduleCalculations(isClockForwarding);
//
//    publishOptimalAndActiveSchedules(LpiCalculationReason::E_NEW_METEO_FORECAST);
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).info() << "[RUNWAY FINAL ASSIGNATION]: " << std::endl;
//#endif
//
//    calculateRunwayFinalAssignation();
//
//    LpdbDataBase::Get().setInputReceivedInLastInterval(true);
}

//-----------------------------------------------------------------------------

///@brief update DB with the new meteo FOREcast data received
void LpdBusinessLogicFacade::updateMeteoForecastDB(const LpiCreateMeteoList & meteolist)
{
  for(unsigned int data_i = 0; data_i < meteolist.size(); ++data_i)
  {
    updateMeteoForecastDB(meteolist[data_i]);
  }
}

//-----------------------------------------------------------------------------

///@brief update DB with the new meteo FOREcast data received for 1 airport 
void LpdBusinessLogicFacade::updateMeteoForecastDB(const LpiCreateMeteo & meteoData)
{

// #ifdef TRACE_OUT
//   LclogStream::instance(LclogConfig::E_RTP).debug()
//     << "Business Logic: updating (forecast) meteo information in database "
//     << " for airport <" << meteoData.getAirport() << '>'
//     << " : File: " << __FILE__
//     << " ; fn: " << __func__
//     << " ; line: " << __LINE__
//     << std::endl;
// #endif

  // a) Store every meteo report received for further use after CLOCK event
  for (unsigned int i = 0; i < meteoData.getMeteoInfo().size(); i++)
  {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).info()
      << "Adding received Meteorological Forecast block to DB." << std::endl;
#endif
    
    LpdbDataBase::Get().addMeteoReport(meteoData.getAirport(),
				       meteoData.getMeteoInfo()[i]);
  }


  // b) Storing received meteo data among intervals (IOMeteoTimeline:.idl)
  
  /**@warning not optimal: repeating the operation for every meteo
     block => each time removing the former value. Eventually we use
     the most recent report (that is stored at the end of the vector
     'meteo_blocks'), that have affected intervals.

     @todo (nice to have) optimization of this logic.
  */
  std::vector<LpiMeteoInfo> meteo_blocks = meteoData.getMeteoInfo();
  for (unsigned int i = 0; i < meteo_blocks.size(); ++i)
  {
    LpiMeteoInfo meteo = meteo_blocks[i];

    TimeLine<LpdbMeteoTimedData> & meteoForecast =
      LpdbDataBase::Get().getMeteoForecast(meteoData.getAirport());
	
    std::vector<std::string> affected_intervals = meteoForecast.getIntervalsInRange
      (meteo.getStartTimeAndDate(), meteo.getEndTimeAndDate());

    //for each interval affected by the meteo-bodyInformation	
    BOOST_FOREACH(std::string ti, affected_intervals)
    {
      if (meteoForecast.hasData(ti)
	  ///@warning requirement: nowcast has preference over forecast
	  and (meteoForecast[ti].getHasNowcastReport() == false))
      {	
    	  fillIntervalData(meteoForecast[ti], meteo);
      }
      else
      {
#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info()
	  << "Meteorological Forecast Report has been discarded for interval:"
	  << ti << ", because it already has a Nowcast Report"
	  << std::endl;
#endif
      }	    
    }
    LpdbDataBase::Get().setMeteoForecast(meteoData.getAirport(), meteoForecast);
  }

  LpdbDataBase::Get().setInputReceivedInLastInterval(true);
}

//------------------------------------------------------------------------------

///@brief Send Meteo (forecast) data to the HMI for N airports
void LpdBusinessLogicFacade::updateMeteoForecastHmi
(const LpiCreateMeteoList & meteolist)
{
  LpiCreateMeteoList meteoReport = meteolist; // to update setTimeline

  /**@warning If we don't explicitly set calculationReason & timeline fields,
     then iMASBlue error "...deserialize..", and the data never gets
     to the HMI consumer.

     The timeline values are updated after every meteo msg. is received:
     void LpdBusinessLogicFacade::updateMeteoNowcastDB(const LpiCreateMeteo & meteoData)
     void LpdBusinessLogicFacade::updateMeteoForecastDB(const LpiCreateMeteo & meteoData)
  */
    std::for_each(std::begin(meteoReport), std::end(meteoReport),
		  [](LpiCreateMeteo &val)
    {
      val.setCalculationReason(LpiCalculationReason::E_NEW_METEO_FORECAST);     
      val.setTimeline(LpdbMeteoTimelineConverter::Convert2Interface
		      (LpdbDataBase::Get().getMeteoForecast(val.getAirport())));
    });

  //////////////////////////
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "RTP-MeteoForecast-CONSUMER: New meteo info to HMI: "
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << "\n LpiCreateMeteoList & meteoReport: size = "
    << meteoReport.size()
    << " ; list: ";

  std::for_each(std::begin(meteoReport),
		std::end(meteoReport),
		[](const LpiCreateMeteo &val)
		{
		  LclogStream::instance(LclogConfig::E_RTP).debug()
		    << val << std::endl;
		});
#endif
  //////////////////////////
    

  LpiMeteoForecastEvt meteoEvt;
  meteoEvt.setMeteoForecast(meteoReport);
  LpdComponent::Get().publish(meteoEvt);
}

//------------------------------------------------------------------------------

/**@warning IOMeteoTimeline::MeteoInfo::crosswind not used in RTP,
   (stored per each RW instead)
   @warning IOMeteoTimeline::MeteoInfo::tailwind not used in RTP,
   (stored per each RW instead)
*/
void LpdBusinessLogicFacade::fillIntervalData
                             (LpdbMeteoTimedData & outputIntervalData,
			      const LpiMeteoInfo & input)
{
  outputIntervalData.setHorizontalVisibility(input.getHorizontalVisibility());
  outputIntervalData.setWetness(input.getWetness());
  outputIntervalData.setLvpActivation(input.getLvpActivation());
  outputIntervalData.setIlsCategory(input.getRequiredILSCategory());

  ///@todo FIXME: phenomenon / PE
  outputIntervalData.setDeicingRequired(input.getDeicing());

  ///@warning unused in RTP's HMI
  outputIntervalData.setWindSpeed(input.getWindSpeed());
  outputIntervalData.setWindDirection(input.getWindDirection());

  ///@warning moved down, after Populate crosswind and tailwind of each rw
  // LpdbDataBase::Get().setMeteoForecast(meteoData.getAirport(),meteoForecast);

  //Populate crosswind and tailwind of each runway
  std::map<std::string, LpiRunwayMeteoInfo> runways_meteo_info;
  std::vector<RVRPerRunway> runways_data = input.getRvrperRunway().getRVRPerRunway();

  for (unsigned int j = 0; j < runways_data.size(); ++j)
  {
    std::string rwy_name = runways_data[j].getName();
    LpiRunwayMeteoInfo information(rwy_name,
				   runways_data[j].getCrossWind(),
				   runways_data[j].getTailWind());
    runways_meteo_info[rwy_name] = information;
  }
  outputIntervalData.setRwyMeteoInfo(runways_meteo_info);
}

//------------------------------------------------------------------------------
