/*
 * LpdComplexityLogic.cc
 *
 * Section of  LpdBusinessLogicFacade.cc related to complexity calculations
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.3.2
 * Cálculos de complejidad"
 *
 */

#include "LpdBusinessLogicFacade.h"
#include <LplcTypeConstants.h>
#include <LclogStream.h>

#include <iostream>
//#include <ctime>
#include <string>
#include <vector>
#include <iterator>
#include <cassert>
#include <algorithm>    // std::for_each


//--------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::calculateComplexity()

   @brief For each airport, for every interval, calculate airport
           complexity for the pair (airport, interval)

   Caller event:

   - INIT at LpdBusinessLogicFacade::complete(void)
          After init the DB complexity data structures (timelines void values)

   - E_NEW_METEO_NOWCAST at LpdBusinessLogicFacade::updateMeteoNowcast()
          After update the DB with the meteo report received =>
          => timelines populated with actual data.

   - E_NEW_METEO_FORECAST at LpdBusinessLogicFacade::updateMeteoForecast()
          After update the DB with the meteo report received =>
          => timelines populated with actual data.

   - E_NEW_DEMAND at LpdBusinessLogicFacade::updateDemand()
          After update the DB with the demand report received =>
          => timelines populated with actual data.

*/
void LpdBusinessLogicFacade::calculateComplexity(void)
{

  auto calculate = [this](const std::string airport_id)
  {
    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
    assert(airport_table.exists(airport_id));
    if(airport_table.exists(airport_id))
    {
      airport_table[airport_id].calculateComplexity();
    }
    else
    {
      LclogStream::instance(LclogConfig::E_RTP).error()
      << "Bad airport id: " << airport_id
      << ", airport complexity not calculated."
      << std::endl;
    }

  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);
}

//------------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::forwardComplexity(std::string interval)

   @brief for each airport, calculate airport complexity on
   interval 'interval'.

   - E_CLOCK at LpdBusinessLogicFacade::forwardTimeline(void)

*/
void LpdBusinessLogicFacade::forwardComplexity(std::string interval)
{

  auto calculate = [this, interval](const std::string airport_id)
  {
    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
    assert(airport_table.exists(airport_id));
    if(airport_table.exists(airport_id))
    {
      airport_table[airport_id].forwardComplexity(interval);
    }
    else
    {
      LclogStream::instance(LclogConfig::E_RTP).error()
      << "Bad airport id: " << airport_id
      << ", airport complexity not calculated for interval:" << interval
      << std::endl;
    }
  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::testLog_calculateComplexity()
{

#ifdef TRACE_OUT
  
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@test result <<calculate max_complexity (airport, interval)>>"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;

  // Test code to show only one airport (mim. log file messages)
  // test data (calculate_complexity_Test) prepared for ENRS
  LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
  const std::string airport_id = {"ENRS"};
  if(airport_table.exists(airport_id))
  {
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "# Airport: <" << airport_id << ">"
      << std::endl
      << "# Airport complexity:"
      << std::endl
      << airport_table[airport_id].getComplexity()
      << std::endl;
  }


// Test code to show all airports (works ok: verified)
//
//  auto log_msg = [this](const std::string airport_id)
//  {
//    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
//    assert(airport_table.exists(airport_id));
//    if(airport_table.exists(airport_id))
//    {
//      LclogStream::instance(LclogConfig::E_RTP).debug()
//  	<< "# Airport: <" << airport_id << ">"
//	<< std::endl
//  	<< "# Airport complexity:"
//	<< std::endl
//	<< airport_table[airport_id].getComplexity()
//	<< std::endl;
//    }
//    else
//    {
//      LclogStream::instance(LclogConfig::E_RTP).debug()
//      << "Bad airport id: " << airport_id
//      << ", airport complexity not calculated."
//      << std::endl;
//    }
//  };//end-lambda
//    std::vector<std::string> airport_keys =
//      LpdbDataBase::Get().getAirportTable().getAllIds();
//    std::for_each(std::begin(airport_keys), std::end(airport_keys), log_msg);


#endif
}

//------------------------------------------------------------------------------

