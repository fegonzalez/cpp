
#include "LpdComponent.h"
#include <LpdbDataBase.h>
#include <LclogStream.h>
#include <LctimVirtualClock.h> //common/timer/common/inc/LctimVirtualClock.h
#include <iostream>
#include <sstream>
#include <ctime>

void LpdComponent::updateSystemTime(const LpiTime &time) {
	LclogStream::instance(LclogConfig::E_RTP).notify() << "UPDATE SYSTEM TIME " << "[TIME:" << time << ']'
			<< std::endl;
//   this->_rules.updateSystemTime(time);
}

void LpdComponent::updateDemand(const LpiCreateDemandList &demand) {
	r_mutex.lock();

	this->_businessLogic.setExpirationDateForWhatIfs(
			LctimVirtualClock::Get().getTime());

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "[DEMAND RECEIVED]" << std::endl;
	LclogStream::instance(LclogConfig::E_RTP).info() << "OPTIMAL SCHEDULE CALCULATION" <<std::endl;
	LclogStream::instance(LclogConfig::E_RTP).info() << "Calculation cause: Demand input received" <<std::endl;
#endif

	for(unsigned int a = 0; a < demand.size(); a++)
	{
		this->_businessLogic.updateDemandTimeAndDate(
				demand.at(a).getmessageTimeandDate(), demand.at(a).getNameAirport());

		LpiFlightPlanList fp = demand.at(a).getFlightPlanList();

		vector<string> receivedFPKeys;
		for (unsigned int i = 0; i < fp.size(); i++) {
			receivedFPKeys.push_back(fp[i].getUniqueKey());
	#ifdef TURN_ROUND
			this->_businessLogic.calculateTurnRound(fp[i]);
	#endif
			this->_businessLogic.calculatePriority(fp[i]);
			this->_businessLogic.updateDemand(fp[i]);
		}
		this->_businessLogic.calculateRSMaxCapacities();
		this->_businessLogic.deleteNotReceivedFPs(receivedFPKeys);

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "FPs DataBase:" << std::endl;
	LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getFPTable() << std::endl;

	LclogStream::instance(LclogConfig::E_RTP).info() << "Demand Forecast:" << std::endl;
//	LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getDemand() << std::endl;
#endif
	this->_businessLogic.updateHMIDemand(LpiCalculationReason::E_NEW_DEMAND, demand.at(a));

	this->_businessLogic.calculateEstimatedDCB();

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).debug() << "Estimated DCB calculations: " << std::endl;
//	LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getEstimatedDCBAsString() << std::endl;

	LclogStream::instance(LclogConfig::E_RTP).debug() << "Invocation to schedules generation..." << std::endl;
#endif

	this->_businessLogic.generateSchedulesForAllIntervals();

	this->_businessLogic.calculateRealDCBAndRunwayAllocation();

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "Scheduled FPs..." << std::endl;
#endif

	this->_businessLogic.performFPInScheduleCalculations();

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "Calculate Schedules KPIs.."<< std::endl;
#endif

	bool isClockForwarding = false;
	this->_businessLogic.calculateSchedulesKPIs(isClockForwarding);

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).debug() << "[OPTIMAL SCHEDULE CALCULATIONS]:" << std::endl;
#endif

	this->_businessLogic.generateOptimalSchedule();

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "[ACTIVE SCHEDULE CALCULATIONS]: "<< std::endl;
#endif

	this->_businessLogic.performActiveScheduleCalculations(isClockForwarding);

	this->_businessLogic.publishOptimalAndActiveSchedules(
			LpiCalculationReason::E_NEW_DEMAND);

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "[RUNWAY FINAL ASSIGNATION]: " << std::endl;
#endif

	this->_businessLogic.calculateRunwayFinalAssignation();

	LpdbDataBase::Get().setInputReceivedInLastInterval(true);


	}
	this->_businessLogic.publishUpdateDemandToHmi();
	r_mutex.unlock();


}

void LpdComponent::updateMeteoForecast(const LpiCreateMeteoList &meteolist) {
	r_mutex.lock();

	LclogStream::instance(LclogConfig::E_RTP).notify() << "[RECEIVED METEO FORECAST INFORMATION]" << std::endl;

	this->_businessLogic.updateMeteoForecast(meteolist);

	r_mutex.unlock();
}

void LpdComponent::updateMeteoNowcast(const LpiCreateMeteoList & meteolist) {
	r_mutex.lock();

	LclogStream::instance(LclogConfig::E_RTP).notify() << "[RECEIVED METEO NOWCAST INFORMATION]" << std::endl;

	this->_businessLogic.updateMeteoNowcast(meteolist);

	r_mutex.unlock();
}

void LpdComponent::updateScheduleActivation(
		const LpiScheduleActivation &scheduleActivation) {
	r_mutex.lock();

	LclogStream::instance(LclogConfig::E_RTP).notify() << "[RECEIVED SCHEDULE ACTIVATION]" << std::endl;

	this->_businessLogic.updateScheduleActivation(scheduleActivation);

	r_mutex.unlock();
}

void LpdComponent::updateCapacityReductions(
		const LpiCapacityReductions &capacity) {
	r_mutex.lock();

	this->_businessLogic.setExpirationDateForWhatIfs(
			LctimVirtualClock::Get().getTime());

	LclogStream::instance(LclogConfig::E_RTP).notify() << "[AERODROME OPERATIONAL STATUS CHANGE]" << std::endl;
#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "OPTIMAL SCHEDULE CALCULATION" <<std::endl;
	LclogStream::instance(LclogConfig::E_RTP).info() << "Calculation cause: Aerodrome Operational Status received" <<std::endl;
#endif

	this->_businessLogic.updateCapacityReductions(capacity);

	this->_businessLogic.calculateMaxCapacities();
	this->_businessLogic.calculateEstimatedDCB();

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).debug() << "Estimated DCB calculations: " << std::endl;
//	LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getEstimatedDCBAsString() << std::endl;

	LclogStream::instance(LclogConfig::E_RTP).debug() << "Invocation to schedules generation..." << std::endl;
#endif

	this->_businessLogic.generateSchedulesForAllIntervals();

	this->_businessLogic.calculateRealDCBAndRunwayAllocation();

	this->_businessLogic.performFPInScheduleCalculations();

	bool isClockForwarding = false;
	this->_businessLogic.calculateSchedulesKPIs(isClockForwarding);

	this->_businessLogic.generateOptimalSchedule();

	this->_businessLogic.performActiveScheduleCalculations(isClockForwarding);

	this->_businessLogic.publishOptimalAndActiveSchedules(
			LpiCalculationReason::E_AIRPORT_OPERATIONAL_STATUS_CHANGE);

#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "[RUNWAY FINAL ASSIGNATION]: " << std::endl;
#endif

	this->_businessLogic.calculateRunwayFinalAssignation();

	LpdbDataBase::Get().setInputReceivedInLastInterval(true);

	r_mutex.unlock();
}

void LpdComponent::updateOptimizationCriteria(
		const LpiOptimizationCriteria &criteria) {
	r_mutex.lock();

	LclogStream::instance(LclogConfig::E_RTP).notify() << "[UPDATE OPTIMIZATION CRITERIA]" << std::endl;
#ifdef TRACE_OUT
	LclogStream::instance(LclogConfig::E_RTP).info() << "OPTIMAL SCHEDULE CALCULATION" <<std::endl;
	LclogStream::instance(LclogConfig::E_RTP).info() << "Calculation cause: Optimization criteria change" <<std::endl;
#endif

	this->_businessLogic.updateOptimizationCriteria(criteria);

	r_mutex.unlock();
}

void LpdComponent::generateManualSchedule(
		const LpiAlternativeSchedule & manualSchedule) {
	this->_businessLogic.generateManualSchedule(manualSchedule);
}

void LpdComponent::deleteSchedule(int scheduleId) {
	this->_businessLogic.deleteSchedule(scheduleId);
}

void LpdComponent::compareSchedules(
		const LpiSchedulesComparison & schedulesToCompare) {
	this->_businessLogic.compareSchedules(schedulesToCompare);
}

void LpdComponent::generateWhatIfRunwayClosures(
		const LpiWhatIfClosure & closures) {
	r_mutex.lock();

	LpiWhatIfClosure::LpiWhatIfClosureType closureType =
			closures.getClosureType();

	switch (closureType) {
	case LpiWhatIfClosure::E_UNKNOWN:
		break;
	case LpiWhatIfClosure::E_APPLY_ON_ACTIVE:
		this->_businessLogic.generateWhatIfClosuresforActive(closures);
		break;
	case LpiWhatIfClosure::E_NEW_OPTIMAL:
		this->_businessLogic.generateWhatIfClosuresforOptimal(closures);
		break;
	default:
		break;
	}
	r_mutex.unlock();
}

/**
 * Component creation
 */
void LpdComponent::create(void) {

}

/**
 * Component init
 */
void LpdComponent::initialise(void) {
	this->_businessLogic.initialise();
}

/**
 * End of component processing
 */
void LpdComponent::complete(void) {
	r_mutex.lock();

	this->_businessLogic.complete();

	r_mutex.unlock();
}

void LpdComponent::notify(void) {

	r_mutex.lock();

try
{
	LclogStream::instance(LclogConfig::E_RTP).notify() << "[RECEIVED RTP CLOCK EVENT]" << std::endl;
	this->_businessLogic.forwardTimeline(); // throw InvalidSubintervalException
}
catch (InvalidSubintervalException& ex)
{
  std::stringstream err_msg;
  err_msg << "[ERROR]: interval value equal to zero.";
  err_msg << "\t[ERROR]: "<< ex.what();
  LclogStream::instance(LclogConfig::E_RTP).error() << err_msg.str() << std::endl;
  std::cerr << err_msg.str() << std::endl;
  exit(EXIT_FAILURE);
}

	r_mutex.unlock();
}

/**
 * Only for testing purpose
 */
void LpdComponent::test(void) {

}

