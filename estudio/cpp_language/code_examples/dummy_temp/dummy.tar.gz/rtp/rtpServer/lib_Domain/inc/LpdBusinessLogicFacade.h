#if !defined(__LPD_BUSINESS_LOGIC_FACADE_H__)
#define __LPD_BUSINESS_LOGIC_FACADE_H__


#include <LpschSchedulesManager.h>

#include <LpiInterfaces.h>
#include <LpdbRunwaySystem.h>
#include <LpdbAlternativeSchedule.h>
#include <LpdbWarningErrors.h>
#include <LpdbDataBase.h>
#include <LpiSchedule.h>
#include <LpiScheduleActivation.h>
#include <LpiActiveSchedule.h>
#include <LpiFlightPlan.h>
#include <LpiDemand.h>


class LpdbMeteoTimedData;
class LpiMeteoInfo;

/**@class LpdBusinessLogicFacade

   @bried: RTP server main logic.

   DOC Reference [1] "2018-08-03 RTP Diseño Funcional.docx",

 */
class LpdBusinessLogicFacade : public LpiILifeCycle,
                               public LpiIGetAdaptationAirportsInfo,
                               public LpiIForwardTimeline,
                               public LpiIGetSystemTime,
                               public LpiICalculateMaxCapacities,
                               public LpiIScheduleActivation,
                               public LpiIPerformActiveScheduleCalculations,
                               public LpiIPerformFPInScheduleCalculations,
                               public LpiIGenerateSchedules,
                               public LpiIGenerateManualSchedule,
                               public LpiIScheduleDeletion,
                               public LpiISchedulesComparison,
                               public LpiISchedulesPublish,
                               public LpiIKeyPerformanceIndicatorsCalculations,
                               public LpiIUpdateDemand,
//                               public LpiIWhatIfRunwayClosures,  ///@warning alternative schedules are not part of this (Jan2019) RTP version.
                               public LpiIGetPriorityTable
{
public:

   LpdBusinessLogicFacade();
   ~LpdBusinessLogicFacade();

   // Eventos consumidos
   virtual void updateDemandTimeAndDate(const posix_time::ptime   &timeAndDate, std::string airport);
   virtual void updateDemand(const LpiCreateDemandList &demand);
   virtual void updateDemand(const LpiFlightPlan &data);
   virtual void updateMeteoForecast (const LpiCreateMeteoList &meteolist);   // (implementation at LpdMeteoLogic)
   virtual void updateMeteoNowcast(const LpiCreateMeteoList & meteolist);   // (implementation at LpdMeteoLogic)
   virtual void updateScheduleActivation(const LpiScheduleActivation &scheduleActivation);

   /**
    * @warning Activated by the HMI after a manual update  (not in actual RTP phase)
    *          Handled by the server in LpcCapacityReductionsEvtConsumer.
    */
   virtual void updateCapacityReductions (const LpiCapacityReductions &reductions);

   virtual void updateOptimizationCriteria (const LpiOptimizationCriteria &criteria);


   // Published events (implemented in BaseComponent)

   virtual void getSystemTime (LpiTime & tick, LpiResult & result) ;


   virtual void getConfigurationCoreParameters (
                                        LpiConfigurationCoreParameters & parameters,
                                        LpiResult & result);

   virtual void getConfigurationHmiParameters (
                                        LpiConfigurationHmiParameters & parameters,
                                        LpiResult & result);


   virtual void getAdaptationMrtmInfo(LpiAdaptationMrtmInfo &mrtm_info,
		   	   	   	   	   	   	   	   LpiResult & result);

   virtual void getAdaptationAssignmentPreference(LpiAdaptationAssignmentPreference &ass_pref,
                                       LpiResult & result);

   virtual void getAdaptationAirportsInfo(
                                     LpiAdaptationAirportsInfo &airportsInfo,
                                     LpiResult & result);

   virtual void getAdaptationAlert_KPIs(LpiAdaptationAlert_KPIs &configurationAlert_KPIs,
                                           LpiResult &result);

   virtual void getPriorityTableDepartures(LpiPriorityTable & priorities, LpiResult & result);
   virtual void getPriorityTableArrivals(LpiPriorityTable & priorities, LpiResult & result);

//   virtual void getWakeVortexCapacityReductions(
//                                   LpiWakeVortexCapacityReductions & capacity,
//                                   LpiResult & result);

   virtual void create(void);
   virtual void initialise(void);
   virtual void complete(void);

   virtual void forwardTimeline(void);

   LpiTime& currentTime(void) {return this->the_currentTime;}


   //Capacity Calculations
   void calculateMaxCapacities(void);


   //Complexity Calculations
    void calculateComplexity(void);

    //virtual void calculatePriorityOperation(string interval);
   //virtual void calculateMinDelayedFPs(const string &);


   virtual void updateHMIDemand(const LpiCalculationReason::LpiEnum & reason, LpiCreateDemand demandL);
   virtual void updateHMIDemand(const LpiCalculationReason::LpiEnum & reason, std::string airport);
   virtual void publishUpdateDemandToHmi();

   //virtual void calculateEstimatedDelayedFPs(void);

   //Schedules Generation via Pathfinding algorithm

   //Generate schedules via 1 invocation to pathfinding algorithm
   virtual void generateSchedulesForAllIntervals(void);
   //Generate existent optimal schedule with a newly generated node for the new interval
   virtual void generateSchedulesForLastInterval(string new_interval);

   //Generate existent optimal schedule with only frozen part and newly created intervals
   virtual void generateSchedulesForClock(int minutesFrozenForClock);

 
   //KPIs calculations
   virtual void calculateSchedulesKPIs(bool isClockForwarding, bool isInitialization = false);

   //Optimal Schedule
   virtual void generateOptimalSchedule();

   //Flight Plan Runway Allocations
   virtual void calculateRunwayAllocation(void);
   virtual void calculateRunwayAllocation(std::string interval);

   //Runway Final Assignation
   virtual void calculateRunwayFinalAssignation(void);
   virtual void calculateRunwayFinalAssignation(std::string interval);

   //Schedule activation
   virtual void activateSchedule(int, LpiScheduleActivationType::LpiEnum activation_type =
                                      LpiScheduleActivationType::E_AUTO);


   //FTOT, FLDT, forecast delay and punctuality delay
   virtual void performFPInScheduleCalculations();

   virtual void performActiveScheduleCalculations(bool isClockForwarding, bool isInitialization = false);

   virtual void generateManualSchedule (const LpiAlternativeSchedule & manualSchedule);
   virtual void deleteSchedule(int scheduleId);
   virtual void compareSchedules(const LpiSchedulesComparison & schedulesToCompare);

   virtual void publishOptimalAndActiveSchedules(const LpiCalculationReason::LpiEnum & reason);
   virtual void publishOptimalSchedule(const LpiCalculationReason::LpiEnum & reason);
   virtual void publishActiveSchedule(const LpiCalculationReason::LpiEnum & reason);

   void deleteNotReceivedFPs(vector<string> & receivedFPKeys);
   void calculatePriority(LpiFlightPlan & fp);

   /**@warning Functions inherited from LpiIWhatIfRunwayClosures:

   	  ///@warning alternative schedules are not part of this (Jan2019) RTP version.

//   virtual void generateWhatIfClosuresforActive(const LpiWhatIfClosure & closures);
//   virtual void generateWhatIfClosuresforOptimal(const LpiWhatIfClosure & closures);
//   virtual void setExpirationDateForWhatIfs(boost::posix_time::ptime expirationDate,
//                                            int idWhatIfToExclude = -1);
    */


private:

   void showAdapAndConfigInfo();

   //Calculations for one rs in one determined interval, invoked from interface methods
   void calculateEstimatedNotAllowed(std::string interval, LpdbRunwaySystem & rs);

   //Updates arrivals, departures, and overall demand numbers
   void calculateTimedDemand ();                         //calculates whole timeline demand
   void calculateTimedDemand (std::string interval, std::string airport);     //calculates demand only in one interval
   void calculateTimedDemand (const LpiFlightPlan & fp, boost::optional<ptime>); //updates demand with one fp data

   void testLog_updateDemand()const; ///@test Demand information in the DB.

   //Check FPs for cancelation by age
   void reviewObsoleteFlightPlans (int minutes_threshold);
   void reviewObsoleteFlightPlansByAssignedTime (int minutes_threshold);
   void reviewTurnRound(string fpKey);

   //Capacity Calculations
   void forwardMaxCapacities(std::string interval);
   void testLog_calculateMaxCapacities()const; // LclogStream test result

   //complexity Calculations
   void forwardComplexity(std::string interval);
   void testLog_calculateComplexity()const;

   //Monitoring functionality methods
   void activateOptimalSchedule();

   //void calculateWhatIfMode1(const LpiOptimizationCriteria & criteria);

   //void generateMrtmTransitionCosts(LpiAdaptationMrtmTransitionCostTable & transitions);


   //aux methods for algorithm generation
   string getLastFrozenNodeOfActiveSchedule(const vector<string> & frozen) const;
   string getLastFrozenNodeOfOptimalSchedule(const vector<string> & frozen) const;

   LpiADOVector<int> getEstimatedDelayed(string initialNode, string interval);


   //Auxiliary methods for What-if 3
//   void performCalculationsInSchedule(LpdbAlternativeSchedule & schedule);
//   void applyRunwayClosures(const LpiWhatIfClosure & closures, bool mustResetState = true);
//   void applyRunwayClosures(const LpdbWhatIfClosure & closures, bool mustResetState = true);
//   void applyRunwayClosures(const LpiRunwayClosure & closure);
//   void activateRunwayClosures(int alternativeId);
//   int updateWhatIfDataBase(const LpiWhatIfClosure & closures,
//                            LpdbAlternativeSchedule & result,
//                            LpiCalculationReason::LpiEnum & reason);
//   void sendAlternativeSchedule(int alternativeId,
//                                LpiCalculationReason::LpiEnum reason);
//   void reviewObsoleteWhatIfs();
//   vector<LpiRunwayClosure> getCurrentClosures();



   void reviewClockForwardingForActivation(const LpiActivationType::ActivationType & origin);

   
   // meteo logic (implementation at LpdMeteoLogic)

   // CLOCK event
   /**@fn void LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)

      @brief Fall all the managed airports, check meteo info on clock
      event (add stored info to new interval)

      - Update meteo info in the DB after a CLOCK event (for all airports);
      - Send meteo info for the new interval to the HMI (for all airports)
   */
   void reviewMeteoInfo(std::string new_interval);
   ///@brief reviewMeteoInfo for the pair (airport, interval)
   void reviewMeteoInfo(std::string airport_id, std::string new_interval);

   // Event E_NEW_METEO_NOWCAST   
   ///@brief update DB with the new meteo NOWcast data received
   void updateMeteoNowcastDB(const LpiCreateMeteoList & meteolist);
   void updateMeteoNowcastDB(const LpiCreateMeteo & meteoData);
   ///@brief Send Meteo (nowcast) data to the HMI
   void updateMeteoNowcastHmi(const LpiCreateMeteoList & meteolist);

   // Event E_NEW_METEO_FORECAST
   void updateMeteoForecastDB(const LpiCreateMeteoList & meteolist);
   void updateMeteoForecastDB(const LpiCreateMeteo & meteoData);
   void updateMeteoForecastHmi(const LpiCreateMeteoList & meteolist);

   void fillIntervalData(LpdbMeteoTimedData & outputIntervalData,
			 const LpiMeteoInfo & input);


   //schedule calculations

   /// Creating the default schedule after system setup
   void initDefaultSchedule(const LpiAdaptationAssignmentPreference &ass_pref,
                            const LpiAdaptationAirportsInfo &airInfo);

   /// Sending active and optimal schedule to the HMI after system setup
   void sendDefaultSchedule() const;

   ///@todo Use case <<Save active & optimal schedules in DB after system setup>> [1].4.4.1
   void testLog_dbDefaultSchedule()const;
   



   //------------------------------------
   // data area
   //------------------------------------

   LpiTime     the_currentTime;
   LpiUpdateDemandList demandUpdateList;


   /**@param the_schedule_manager

      @todo RTP: Usar este en tarea [1].4.4.3 Algoritmo de búsqueda de
      asignaciones
   */
   LpschSchedulesManager the_schedule_manager;

};



#endif // __LPD_BUSINESS_LOGIC_FACADE_H__
