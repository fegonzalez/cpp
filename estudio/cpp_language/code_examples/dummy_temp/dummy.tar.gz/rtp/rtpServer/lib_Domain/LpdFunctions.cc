
#include "LpdFunctions.h"
#include <LpaAdaptationAirportsInfo.h>
#include <LpdComponent.h>
#include <LpiResult.h>
#include <boost/algorithm/string/trim.hpp>

#include <string>


  //---------------------------------------------------------------

  bool managedAirport(std::string airport)
  {
	  std::string aerodrome = airport;
	  boost::algorithm::trim(aerodrome);

	  LpiAdaptationAirportsInfo airportInfoList;
	  LpiResult result;
	  LpdComponent::Get().getAdaptationAirportsInfo(airportInfoList, result);
	  assert(result.getResult() == LpiResult::LpiEnum::E_OK);

	  return (airportInfoList.exists(aerodrome));
  }

  //---------------------------------------------------------------
