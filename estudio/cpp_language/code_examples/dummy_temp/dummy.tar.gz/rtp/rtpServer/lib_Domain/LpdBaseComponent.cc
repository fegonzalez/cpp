
#include "LpdBaseComponent.h"
#include <LclogStream.h>

#include <iostream>

LpdBaseComponent::LpdBaseComponent() :
   _pGetSystemTimeSrvDelegateUser(
		   boost::make_shared<LpiGetSystemTimeSrvDelegateUser>()),
   _pGetConfigurationCoreParametersSrvDelegateUser(
              boost::make_shared<LpiGetConfigurationCoreParametersSrvDelegateUser>()),
   _pGetConfigurationHmiParametersSrvDelegateUser(
             boost::make_shared<LpiGetConfigurationHmiParametersSrvDelegateUser>()),
   _pGetAdaptationAlert_KPIsSrvDelegateUser(
           boost::make_shared<LpiGetAdaptationAlert_KPIsSrvDelegateUser>()),
   _pGetAdaptationMrtmInfoSrvDelegateUser(
           boost::make_shared<LpiGetAdaptationMrtmInfoSrvDelegateUser>()),
   _pGetAdaptationAssignmentPreferenceSrvDelegateUser(
           boost::make_shared<LpiGetAdaptationAssignmentPreferenceSrvDelegateUser>()),

//_pGetAdaptationRunwaySrvDelegateUser(
//		   boost::make_shared<LpiGetAdaptationRunwaySrvDelegateUser>()),

//   _pGetAdaptationRunwaySystemSrvDelegateUser(
//		   boost::make_shared<LpiGetAdaptationRunwaySystemSrvDelegateUser>()),

   _pGetAdaptationAirportsInfoSrvDelegateUser(
           boost::make_shared<LpiGetAdaptationAirportsInfoSrvDelegateUser>()),
   _pGetPriorityTableSrvDelegateUser(
		   boost::make_shared<LpiGetPriorityTableSrvDelegateUser>()),

   _pGetWakeVortexCapacityReductionsSrvDelegateUser(
           boost::make_shared<LpiGetWakeVortexCapacityReductionsSrvDelegateUser>()),

   _pOptimalScheduleEvtDelegatePublisher(
		   boost::make_shared<LpiOptimalScheduleEvtDelegatePublisher>()),
   _pOptimalCriteriaEvtDelegatePublisher(
		   boost::make_shared<LpiOptimalCriteriaEvtDelegatePublisher>()),
   _pDemanEvtDelegatePublisher(
		   boost::make_shared<LpiDemandEvtDelegatePublisher>()),
   _pActiveScheduleEvtDelegatePublisher(
		   boost::make_shared<LpiActiveScheduleEvtDelegatePublisher>()),
   _pMeteoForecastEvtDelegatePublisher(
		   boost::make_shared<LpiMeteoForecastEvtDelegatePublisher>()),
   _pMeteoNowcastEvtDelegatePublisher(
		   boost::make_shared<LpiMeteoNowcastEvtDelegatePublisher>()),
   _pAlternativeScheduleEvtDelegatePublisher(
		   boost::make_shared<LpiAlternativeScheduleEvtDelegatePublisher>()),
   _pSchedulesComparisonResponseEvtDelegatePublisher(
		   boost::make_shared<LpiSchedulesComparisonResponseEvtDelegatePublisher>()),
   _pAutomaticDeletionEvtDelegatePublisher(
		   boost::make_shared<LpiAutomaticDeletionEvtDelegatePublisher>())
{}

LpdBaseComponent::~LpdBaseComponent()
{}

void LpdBaseComponent::getConfigurationCoreParameters(
                           LpiConfigurationCoreParameters &configurationCoreParameters,
                           LpiResult                  &result)
{
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug()
		    << " : File: " << __FILE__
		    << " ; fn: " << __func__
		    << " ; line: " << __LINE__
			<< std::endl;
#endif
   LpiGetConfigurationCoreParametersReply     reply;
   use(reply);
   result.setResult(reply.getResult());
   configurationCoreParameters = reply.getConfigurationCoreParameters();
}

void LpdBaseComponent::getConfigurationHmiParameters(
                           LpiConfigurationHmiParameters &configurationHmiParameters,
                           LpiResult                  &result)
{
   LpiGetConfigurationHmiParametersReply     reply;
   use(reply);
   result.setResult(reply.getResult());
   configurationHmiParameters = reply.getConfigurationHmiParameters();
}

/**
 * Gets configuration information via service
 * @param configurationAlertKPIs parameter is filled by method with config info
 * @param result indicates if the service invocation has successfully completed or not
*/
void LpdBaseComponent::getAdaptationAlert_KPIs(
                           LpiAdaptationAlert_KPIs & configurationAlert_KPIs,
                           LpiResult                 & result)
{
   LpiGetAdaptationAlert_KPIsReply     reply;
   use(reply);
   result.setResult(reply.getResult());
   configurationAlert_KPIs = reply.getAdaptationAlert_KPIs();
}

/**
 * Gets system time via service
 * @param tick parameter is filled by method with time info
 * @param result indicates if the service invocation has successfully completed or not
*/
void LpdBaseComponent::getSystemTime(LpiTime &tick, LpiResult &result)
{
   LpiGetSystemTimeRequest   request;
   LpiGetSystemTimeReply     reply;
   use(request, reply);
   tick = reply.getTime();
   result.setResult(reply.getResult());
}

/**
 * Gets adaptation information via service
 * @param adaptationRunway parameter is filled by method with adap info
 * @param result indicates if the service invocation has successfully completed or not
*/
void LpdBaseComponent::getAdaptationMrtmInfo(LpiAdaptationMrtmInfo &mrtmInfo,
											LpiResult   &result)
{
	LpiGetAdaptationMrtmInfoReply	reply;
	use(reply);
	result.setResult(reply.getResult());
	mrtmInfo = reply.getAdaptationMrtmInfo();
}

/**
 * Gets adaptation information via service
 * @param adaptationRunway parameter is filled by method with adap info
 * @param result indicates if the service invocation has successfully completed or not
*/
void LpdBaseComponent::getAdaptationAssignmentPreference(LpiAdaptationAssignmentPreference &assPref,
                                            LpiResult   &result)
{
    LpiGetAdaptationAssignmentPreferenceReply   reply;
    use(reply);
    result.setResult(reply.getResult());
    assPref = reply.getAdaptationAssignmentPreference();
}



/**
 * Gets adaptation information via service
 * @param adaptationRunway parameter is filled by method with adap info
 * @param result indicates if the service invocation has successfully completed or not
*/
//void LpdBaseComponent::getAdaptationRunway(
//                           LpiAdaptationRunwayList & adaptationRunway,
//                           LpiResult               & result)
//{
//#ifdef TRACE_OUT
//   LclogStream::instance(LclogConfig::E_RTP).debug()
//		<<"@test CORE DUMPED HERE?. After calling meteoNowcast connector (at   use(reply)   bellow) ?? (it happens in July 2018)"
//	    << " : file: " << __FILE__
//	    << " ; fn: " << __func__
//	    << " ; line:  " << __LINE__
//	    << std::endl;
//#endif
//
//   LpiGetAdaptationRunwayReply     reply;
//   use(reply); ///@bug core-dumped al cargar info de RW systems
//   result.setResult(reply.getResult());
//   adaptationRunway = reply.getAdaptationRunway();
//}

/**
 * Gets adaptation information via service
 * @param adaptationRunwaySystem parameter is filled by method with adap info
 * @param result indicates if the service invocation has successfully completed or not
*/
//void LpdBaseComponent::getAdaptationRunwaySystem(
//                           LpiAdaptationRunwaySystemList & adaptationRunwaySystem,
//                           LpiResult                     & result)
//{
//   LpiGetAdaptationRunwaySystemReply     reply;
//   use(reply);
//   result.setResult(reply.getResult());
//   adaptationRunwaySystem = reply.getAdaptationRunwaySystem();
//}

/**
 * Gets adaptation information via service
 * @param adaptationAirportInfo parameter is filled by method with adaptation info
 * @param result indicates if the service invocation has successfully completed or not
*/
void LpdBaseComponent::getAdaptationAirportsInfo(
                           LpiAdaptationAirportsInfo   & adaptationAirportsInfo,
                           LpiResult                  & result)
{
   LpiGetAdaptationAirportsInfoReply     reply;
   use(reply);
   result.setResult(reply.getResult());
   adaptationAirportsInfo = reply.getAdaptationAirportsInfo();
}

void LpdBaseComponent::getPriorityTableDepartures(LpiPriorityTable & priorities, LpiResult & result)
{
   LpiGetPriorityReply reply;
   use(reply);
   result.setResult(reply.getResult());
   priorities = reply.getPriorityTableDepartures();
}

void LpdBaseComponent::getPriorityTableArrivals(LpiPriorityTable & priorities, LpiResult & result)
{
   LpiGetPriorityReply reply;
   use(reply);
   result.setResult(reply.getResult());
   priorities = reply.getPriorityTableArrivals();
}

void LpdBaseComponent::getWakeVortexCapacityReductions(LpiWakeVortexCapacityReductions &capacity,
                                                       LpiResult &result)
{
   LpiGetWakeVortexCapacityReductionsReply reply;
   use(reply);
   result.setResult(reply.getResult());
   capacity = reply.getWakeVortexCapacityReductions();
}

/**
 * Update time event processing
 * @param event is the event to process
 */
void LpdBaseComponent::consume(const LpiUpdateSystemTimeEvt  &event)
{
   updateSystemTime(event.getSystemTime());
}

/**
 * Demand event processing
 * @param event is the event to process, contains flight plans data
 */
void LpdBaseComponent::consume(const LpiCreateDemandEvt  &event)
{
   updateDemand(event.getCreateDemand());
}

/**
 * Meteo forecast event processing
 * @param event is the event to process, contains future meteo prediction
 */
void LpdBaseComponent::consume(const LpiMeteoForecastEvt  &event)
{
   updateMeteoForecast(event.getMeteoForecast());
}

/**
 * Meteo nowcast report event processing
 * @param event is the event to process, contains current meteorological data
 */
void LpdBaseComponent::consume(const LpiMeteoNowcastEvt  &event)
{
   updateMeteoNowcast(event.getMeteoNowcast());
}

void LpdBaseComponent::consume(const LpiScheduleActivationEvt  &event)
{
   updateScheduleActivation(event.getScheduleActivation());
}

/**
 * What-if 1 event processing
 * @param event is the event to process, contains new optimization criteria
 */
void LpdBaseComponent::consume(const LpiOptimizationCriteriaEvt  &event)
{
   updateOptimizationCriteria(event.getOptimizationCriteria());
}

/**
 * Airport operational state change event processing
 * @param event is the event to process, contains reductions timelines
 *
 * @warning Activated by the HMI after a manual update  (not in actual RTP phase)
 */
void LpdBaseComponent::consume(const LpiCapacityReductionsEvt  &event)
{
   updateCapacityReductions(event.getCapacityReductions());
}

/**
 * What-if 2 event processing
 * @param event is the event to process, contains a manually generated schedule
 */
void LpdBaseComponent::consume(const LpiManualEditionEvt  &event)
{
   generateManualSchedule(event.getManualSchedule());
}

/**
 * Alternative schedule deletion event processing
 * @param event is the event to process, contains a schedule id
 */
void LpdBaseComponent::consume(const LpiScheduleDeleteEvt  &event)
{
   deleteSchedule(event.getScheduleId());
}

/**
 * Schedules comparison Event consumption callback
 * @param managed event, contains 2 schedule identifiers and names
 */
void LpdBaseComponent::consume(const LpiSchedulesComparisonEvt  &event)
{
   compareSchedules(event.getSchedulesComparison());
}


void LpdBaseComponent::consume(const LpiWhatIfRunwayClosureEvt & event)
{
   generateWhatIfRunwayClosures(event.getClosures());
}

/**
 * Service used to get system time
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(const LpiGetSystemTimeRequest  &request,
                           LpiGetSystemTimeReply          &reply)
{
   this->_pGetSystemTimeSrvDelegateUser->use(request, reply);
}

/**
 * Service used to get configuration info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetConfigurationCoreParametersReply & reply)
{
   this->_pGetConfigurationCoreParametersSrvDelegateUser->use(reply);
}

/**
 * Service used to get configuration info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetConfigurationHmiParametersReply & reply)
{
   this->_pGetConfigurationHmiParametersSrvDelegateUser->use(reply);
}

/**
 * Service used to get configuration info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetAdaptationAlert_KPIsReply          &reply)
{
   this->_pGetAdaptationAlert_KPIsSrvDelegateUser->use(reply);
}

/**
 * Service delegation to get adaptation info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetAdaptationMrtmInfoSrvUser &user) //RTP
{

	this->_pGetAdaptationMrtmInfoSrvDelegateUser->delegateUser(user);
}

/**
 * Service delegation to get adaptation info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetAdaptationAssignmentPreferenceSrvUser &user) //RTP
{

    this->_pGetAdaptationAssignmentPreferenceSrvDelegateUser->delegateUser(user);
}


/**
 * Service used to get adaptation info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetAdaptationMrtmInfoReply          &reply)
{
   this->_pGetAdaptationMrtmInfoSrvDelegateUser->use(reply);
}

/**
 * Service used to get adaptation info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetAdaptationAssignmentPreferenceReply          &reply)
{
   this->_pGetAdaptationAssignmentPreferenceSrvDelegateUser->use(reply);
}


/**
 * Service used to get adaptation info
 * @param request is the service request
 * @param reply is the service response
 */
//void LpdBaseComponent::use(LpiGetAdaptationRunwayReply          &reply)
//{
//   this->_pGetAdaptationRunwaySrvDelegateUser->use(reply);
//}

/**
 * Service used to get adaptation info
 * @param request is the service request
 * @param reply is the service response
 */
//void LpdBaseComponent::use(LpiGetAdaptationRunwaySystemReply          &reply)
//{
//   this->_pGetAdaptationRunwaySystemSrvDelegateUser->use(reply);
//}

/**
 * Service used to get adaptation info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetWakeVortexCapacityReductionsReply          &reply)
{
   this->_pGetWakeVortexCapacityReductionsSrvDelegateUser->use(reply);

}

/**
 * Service used to get adaptation info
 * @param request is the service request
 * @param reply is the service response
 */
void LpdBaseComponent::use(LpiGetAdaptationAirportsInfoReply          &reply)
{
    this->_pGetAdaptationAirportsInfoSrvDelegateUser->use(reply);
}

void LpdBaseComponent::use(LpiGetPriorityReply & reply)
{
   this->_pGetPriorityTableSrvDelegateUser->use(reply);
}

/**
 * Service delegation to get system time
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetSystemTimeSrvUser &user)
{
   this->_pGetSystemTimeSrvDelegateUser->delegateUser(user);
}

/**
 * Service delegation to get configuration info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetConfigurationCoreParametersSrvUser &user)
{
   this->_pGetConfigurationCoreParametersSrvDelegateUser->delegateUser(user);
}

/**
 * Service delegation to get configuration info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetConfigurationHmiParametersSrvUser &user)
{
   this->_pGetConfigurationHmiParametersSrvDelegateUser->delegateUser(user);
}

/**
 * Service delegation to get configuration info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetAdaptationAlert_KPIsSrvUser &user)
{
    this->_pGetAdaptationAlert_KPIsSrvDelegateUser->delegateUser(user);
}

/**
 * Service delegation to get adaptation info
 * @param user is the user who is delegated
 */
//void LpdBaseComponent::delegateUser(LpiIGetAdaptationRunwaySrvUser &user)
//{
//   this->_pGetAdaptationRunwaySrvDelegateUser->delegateUser(user);
//}

/**
 * Service delegation to get adaptation info
 * @param user is the user who is delegated
 */
//void LpdBaseComponent::delegateUser(LpiIGetAdaptationRunwaySystemSrvUser &user)
//{
//   this->_pGetAdaptationRunwaySystemSrvDelegateUser->delegateUser(user);
//}

/**
 * Service delegation to get adaptation info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetAdaptationAirportsInfoSrvUser &user)
{
   this->_pGetAdaptationAirportsInfoSrvDelegateUser->delegateUser(user);
}


/**
 * Service delegation to get adaptation info
 * @param user is the user who is delegated
 */
void LpdBaseComponent::delegateUser(LpiIGetWakeVortexCapacityReductionsSrvUser &user)
{
   this->_pGetWakeVortexCapacityReductionsSrvDelegateUser->delegateUser(user);
}

void LpdBaseComponent::delegateUser(LpiIGetPriorityTableSrvUser &user)
{
   this->_pGetPriorityTableSrvDelegateUser->delegateUser(user);
}

/**
 * Publication via delegation
 * @param publisher is the event to be published
 */
void LpdBaseComponent::delegatePublisher(LpiIOptimalScheduleEvtPublisher &publisher)
{
   this->_pOptimalScheduleEvtDelegatePublisher->delegatePublisher(publisher);
}


void LpdBaseComponent::delegatePublisher(LpiIOptimalCriteriaEvtPublisher &publisher)
{
   this->_pOptimalCriteriaEvtDelegatePublisher->delegatePublisher(publisher);
}

/**
 * Publication via delegation
 * @param publisher is the event to be published
 */
void LpdBaseComponent::delegatePublisher(LpiIMeteoForecastEvtPublisher &publisher)
{
   this->_pMeteoForecastEvtDelegatePublisher->delegatePublisher(publisher);
}


/**
 * Publication via delegation
 * @param publisher is the event to be published
 */
void LpdBaseComponent::delegatePublisher(LpiIMeteoNowcastEvtPublisher &publisher)
{
   this->_pMeteoNowcastEvtDelegatePublisher->delegatePublisher(publisher);
}

/**
 * Publication via delegation
 * @param publisher is the event to be published
 */
void LpdBaseComponent::delegatePublisher(LpiIDemandEvtPublisher &publisher)
{
   this->_pDemanEvtDelegatePublisher->delegatePublisher(publisher);
}

void LpdBaseComponent::delegatePublisher(LpiIActiveScheduleEvtPublisher &publisher)
{
   this->_pActiveScheduleEvtDelegatePublisher->delegatePublisher(publisher);
}

/**
 * Publication via delegation
 * @param publisher is the event to be published
 */
void LpdBaseComponent::delegatePublisher(LpiIAlternativeScheduleEvtPublisher &publisher)
{
   this->_pAlternativeScheduleEvtDelegatePublisher->delegatePublisher(publisher);
}

void LpdBaseComponent::delegatePublisher(LpiISchedulesComparisonResponseEvtPublisher &publisher)
{
   this->_pSchedulesComparisonResponseEvtDelegatePublisher->delegatePublisher(publisher);
}

void LpdBaseComponent::delegatePublisher(LpiIAutomaticDeletionEvtPublisher &publisher)
{
   this->_pAutomaticDeletionEvtDelegatePublisher->delegatePublisher(publisher);
}

/**
 * Meteo Nowcast publication event
 * @param data is the schedule to publish
 */
void LpdBaseComponent::publish(const LpiMeteoNowcastEvt &data)
{
   this->_pMeteoNowcastEvtDelegatePublisher->publish(data);
}

/**
 * Meteo Forecast publication event
 * @param data is the schedule to publish
 */
void LpdBaseComponent::publish(const LpiMeteoForecastEvt &data)
{
   this->_pMeteoForecastEvtDelegatePublisher->publish(data);
}


void LpdBaseComponent::publish(const LpiUpdateDemandEvt &data)
{
   this->_pDemanEvtDelegatePublisher->publish(data);
}

void LpdBaseComponent::publish(const LpiActiveScheduleEvt &data)
{
   this->_pActiveScheduleEvtDelegatePublisher->publish(data);
}

/**
 * Optimal Schedule publication event
 * @param data is the schedule to publish
 */
void LpdBaseComponent::publish(const LpiOptimalScheduleEvt &data)
{
   this->_pOptimalScheduleEvtDelegatePublisher->publish(data);
}

/**
 * Alternative Schedule publication event
 * @param data is the schedule to publish
 */
void LpdBaseComponent::publish(const LpiOptimalCriteriaEvt &data)
{
   this->_pOptimalCriteriaEvtDelegatePublisher->publish(data);
}

/**
 * Alternative Schedule publication event
 * @param data is the schedule to publish
 */
void LpdBaseComponent::publish(const LpiAlternativeScheduleEvt &data)
{
   this->_pAlternativeScheduleEvtDelegatePublisher->publish(data);
} 

void LpdBaseComponent::publish(const LpiSchedulesComparisonResponseEvt &data)
{
   this->_pSchedulesComparisonResponseEvtDelegatePublisher->publish(data);
}

void LpdBaseComponent::publish(const LpiAutomaticDeletionEvt & data)
{
   this->_pAutomaticDeletionEvtDelegatePublisher->publish(data);
}

