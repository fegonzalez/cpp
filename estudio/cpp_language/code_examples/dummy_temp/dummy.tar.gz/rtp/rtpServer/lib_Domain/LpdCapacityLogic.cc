/*
 * LpdCapacityLogic.cc
 *
 * Section of  LpdBusinessLogicFacade.cc related to capacity calculations
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.3.1
 * Cálculos de capacidades"
 *
 */
#include <LplcTypeConstants.h>

#include "LpdBusinessLogicFacade.h"

#include <LclogStream.h>

#include <iostream>
#include <ctime>
#include <string>
#include <vector>
#include <iterator>
#include <cassert>
#include <algorithm>    // std::for_each


//--------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::calculateMaxCapacities()

   @brief For each airport, for every interval, calculate airport
          maximum capacities for the pair (airport, interval)

   Caller event:

   - INIT at LpdBusinessLogicFacade::complete(void)
          After init the DB capacity data structures (timelines void values)

   - E_NEW_METEO_NOWCAST at LpdBusinessLogicFacade::updateMeteoNowcast()
          After update the DB with the meteo report received =>
          => timelines populated with actual data.

   - E_NEW_METEO_FORECAST at LpdBusinessLogicFacade::updateMeteoForecast()
          After update the DB with the meteo report received =>
          => timelines populated with actual data.

   @todo - E_CLOCK at ...



*/
void LpdBusinessLogicFacade::calculateMaxCapacities(void)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


  auto calculate = [this](const std::string airport_id)
  {
    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
    assert(airport_table.exists(airport_id));
    if(airport_table.exists(airport_id))
    {
      airport_table[airport_id].calculateMaxCapacity();
    }
    else
    {
      LclogStream::instance(LclogConfig::E_RTP).error()
      << "Bad airport id: " << airport_id
      << ", airport capacities not calculated."
      << std::endl;
    }

  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
}

//------------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::calculateMaxCapacities(std::string interval)

   @brief for each airport, calculate airport maximum capacities on
   interval 'interval'.

   - Event: CLOCK => LpdBusinessLogicFacade::forwardTimeline(void):
     forward capacities

*/
void LpdBusinessLogicFacade::forwardMaxCapacities(std::string interval)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " ; interval:" << interval
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


  auto calculate = [this, interval](const std::string airport_id)
  {
    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
    assert(airport_table.exists(airport_id));
    if(airport_table.exists(airport_id))
    {
      airport_table[airport_id].forwardCapacity(interval);
    }
    else
    {
      LclogStream::instance(LclogConfig::E_RTP).error()
      << "Bad airport id: " << airport_id
      << ", airport capacities not calculated for interval:" << interval
      << std::endl;
    }
  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
}

//------------------------------------------------------------------------------

