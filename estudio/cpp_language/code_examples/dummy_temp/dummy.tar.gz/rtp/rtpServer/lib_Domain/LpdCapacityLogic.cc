/*
 * LpdCapacityLogic.cc
 *
 * Section of  LpdBusinessLogicFacade.cc related to capacity calculations
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.3.1
 * Cálculos de capacidades"
 *
 */

#include "LpdBusinessLogicFacade.h"
#include <LplcTypeConstants.h>
#include <LclogStream.h>

#include <iostream>
//#include <ctime>
#include <string>
#include <vector>
#include <iterator>
#include <cassert>
#include <algorithm>    // std::for_each


//--------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::calculateMaxCapacities()

   @brief For each airport, for every interval, calculate airport
          maximum capacities for the pair (airport, interval)

   Caller event:

   - INIT at LpdBusinessLogicFacade::complete(void)
          After init the DB capacity data structures (timelines void values)

   - E_NEW_METEO_NOWCAST at LpdBusinessLogicFacade::updateMeteoNowcast()
          After update the DB with the meteo report received =>
          => timelines populated with actual data.

   - E_NEW_METEO_FORECAST at LpdBusinessLogicFacade::updateMeteoForecast()
          After update the DB with the meteo report received =>
          => timelines populated with actual data.

*/
void LpdBusinessLogicFacade::calculateMaxCapacities(void)
{
  auto calculate = [this](const std::string airport_id)
  {
    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
    assert(airport_table.exists(airport_id));
    if(airport_table.exists(airport_id))
    {
      airport_table[airport_id].calculateMaxCapacity();
    }
    else
    {
      LclogStream::instance(LclogConfig::E_RTP).error()
      << "Bad airport id: " << airport_id
      << ", airport capacities not calculated."
      << std::endl;
    }

  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);
}

//------------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::forwardMaxCapacities(std::string interval)

   @brief for each airport, calculate airport maximum capacities on
   interval 'interval'.

   - E_CLOCK at LpdBusinessLogicFacade::forwardTimeline(void)

*/
void LpdBusinessLogicFacade::forwardMaxCapacities(std::string interval)
{
  auto calculate = [this, interval](const std::string airport_id)
  {
    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
    assert(airport_table.exists(airport_id));
    if(airport_table.exists(airport_id))
    {
      airport_table[airport_id].forwardCapacity(interval);
    }
    else
    {
      LclogStream::instance(LclogConfig::E_RTP).error()
      << "Bad airport id: " << airport_id
      << ", airport capacities not calculated for interval:" << interval
      << std::endl;
    }
  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::testLog_calculateMaxCapacities()
{
#ifdef TRACE_OUT
  

  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@test result <<calculate max_capacities (airport, interval)>>"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;

  // Test code to show only one airport (mim. log file messages)
  // test data (calculate_capacities_Test) prepared for ENRS
  LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
  const std::string airport_id = {"ENRS"};
  if(airport_table.exists(airport_id))
  {
	  LclogStream::instance(LclogConfig::E_RTP).debug()
		   			<< "# Airport: <" << airport_id << ">"
					<< std::endl
					<< "# Airport capacity:"
					<< std::endl
					<< airport_table[airport_id].getCapacity()
					<< std::endl;
  }


// Test code to show all airports (works ok: verified)
//
//  auto log_msg = [this](const std::string airport_id)
//  {
//    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
//    assert(airport_table.exists(airport_id));
//    if(airport_table.exists(airport_id))
//    {
//      LclogStream::instance(LclogConfig::E_RTP).debug()
//  	<< "# Airport: <" << airport_id << ">"
//	<< std::endl
//  	<< "# Airport capacity:"
//	<< std::endl
//	<< airport_table[airport_id].getCapacity()
//	<< std::endl;
//    }
//    else
//    {
//      LclogStream::instance(LclogConfig::E_RTP).debug()
//      << "Bad airport id: " << airport_id
//      << ", airport capacities not calculated."
//      << std::endl;
//    }
//  };//end-lambda
//    std::vector<std::string> airport_keys =
//      LpdbDataBase::Get().getAirportTable().getAllIds();
//    std::for_each(std::begin(airport_keys), std::end(airport_keys), log_msg);


#endif
}

//------------------------------------------------------------------------------

