/*
 * LpdCapacityLogic.cc
 *
 * Section of  LpdBusinessLogicFacade.cc related to capacity calculations
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.3.1 Cálculos de capacidades"
 *
 */
#include <LplcTypeConstants.h>

#include "LpdBusinessLogicFacade.h"

#include <LclogStream.h>

#include <iostream>
#include <ctime>
#include <string>
#include <vector>
#include <iterator>
#include <cassert>
#include <algorithm>    // std::for_each


//#include <boost/foreach.hpp>
//#include <boost/optional.hpp>
//#include <boost/math/distributions/normal.hpp>
//
////For random numbers generation (only for testing)
//#include <boost/random/random_device.hpp>
//#include <boost/random/mersenne_twister.hpp>
//#include <boost/random/uniform_int.hpp>
//
//#include <boost/algorithm/string/trim.hpp>
//
////For execution time measuring
//#include <boost/chrono/thread_clock.hpp>



//--------------------------------------------------------------

/**@void LpdBusinessLogicFacade::calculateMaxCapacities(void)

   @brief For 'airport_id', for each interval: calculate capacities
   of TMA and Taxiways.

   @param TMA: Terminal Maneuvering Area
*/
/**@fn void LpdBusinessLogicFacade::calculateMaxCapacities()

   @brief For each airport, for every interval, calculate airport maximum capacities
          for the pair (airport, interval)

   - Event: INIT => LpdBusinessLogicFacade::complete(void): init capacities values

*/
void LpdBusinessLogicFacade::calculateMaxCapacities(void)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


  auto calculate = [this](const std::string airport_id)
  {
	  LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
	  assert(airport_table.exists(airport_id));
	  if(airport_table.exists(airport_id))
	  {
		  airport_table[airport_id].calculateMaxCapacity();

		    //calculateTMATWYsMaxCapacities(airport_id);
		    // calculateRunwaysMaxCapacities(airport_id); ///@todo RTP uses airport_id
		    // calculateRSMaxCapacities(airport_id); ///@todo RTP uses airport_id
	  }
	  else
	  {
		  LclogStream::instance(LclogConfig::E_RTP).error()
		    		<< "Bad airport id: " << airport_id
					<< ", airport capacities not calculated."
					<< std::endl;
	  }

  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif

//#ifdef TRACE_OUT
//    //Logging
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Runways Calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getRunwaysCapacitiesAsString() << std::endl;
//
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Runways in Runway System Calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getRunwaySystemRunwaysCapacitiesAsString() << std::endl;
//
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Runway System Calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getRunwaySystemsCapacitiesAsString() << std::endl;
//#endif
}

//------------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::calculateMaxCapacities(std::string interval)

   @brief for each airport, calculate airport maximum capacities on interval 'interval'.

   - Event: CLOCK => LpdBusinessLogicFacade::forwardTimeline(void): forward capacities

*/
void LpdBusinessLogicFacade::forwardMaxCapacities(std::string interval)
{
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " ; interval:" << interval
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


  auto calculate = [this, interval](const std::string airport_id)
  {
	  LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
	  assert(airport_table.exists(airport_id));
	  if(airport_table.exists(airport_id))
	  {
		  airport_table[airport_id].forwardCapacity(interval);
	  }
	  else
	  {
		  LclogStream::instance(LclogConfig::E_RTP).error()
		    		<< "Bad airport id: " << airport_id
					<< ", airport capacities not calculated for interval:" << interval
					<< std::endl;
	  }

	  //calculateTMATWYsMaxCapacities(airport_id, interval);
	  // calculateRunwaysMaxCapacities(airport_id, interval); ///@todo
	  // calculateRSMaxCapacities(airport_id, interval); ///@todo
  };

  std::vector<std::string> airport_keys = LpdbDataBase::Get().getAirportTable().getAllIds();
  std::for_each(std::begin(airport_keys), std::end(airport_keys), calculate);


#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "TODO: RTP Server's Business Logic completion: Capacity calculations."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


// #ifdef TRACE_OUT
//     //Logging
//     LclogStream::instance(LclogConfig::E_RTP).debug() << "Runways Calculations: " << std::endl;
//     LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getRunwaysCapacitiesAsString() << std::endl;

//     LclogStream::instance(LclogConfig::E_RTP).debug() << "Runways in Runway System Calculations: " << std::endl;
//     LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getRunwaySystemRunwaysCapacitiesAsString() << std::endl;

//     LclogStream::instance(LclogConfig::E_RTP).debug() << "Runway System Calculations: " << std::endl;
//     LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getRunwaySystemsCapacitiesAsString() << std::endl;
// #endif
}

//------------------------------------------------------------------------------

//
//void LpdBusinessLogicFacade::calculateRunwayAndRSMaxCapacities()
//{
//    //calculateRunwaysMaxCapacities();
//    calculateRSMaxCapacities();
//
//#ifdef TRACE_OUT
//    //Logging
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Runways Calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getRunwaysCapacitiesAsString() << std::endl;
//
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Runways in Runway System Calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getRunwaySystemRunwaysCapacitiesAsString() << std::endl;
//
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Runway System Calculations: " << std::endl;
//    LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getRunwaySystemsCapacitiesAsString() << std::endl;
//#endif
//}

//------------------------------------------------------------------------------


//void LpdBusinessLogicFacade::calculateRunwaysMaxCapacities(void)
//{
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Calculating Ruways maximum capacities..." << std::endl;
//#endif
//
//    LpdbDataBase::RunwayTable & rwyTable = LpdbDataBase::Get().getRunwayTable();
//    vector<string> runway_ids = rwyTable.getAllIds();
//
//    //Get thresholds for applying reductions
//    LpiAdaptationMeteothresholdList thresholds;
//    LpiResult thresholds_result;
//
//    //getAdaptationMeteoThresholds(thresholds, thresholds_result);
//
//    //Get minimal capacity reduction
//    LpiAdaptationCapacityReduction reduction;
//    LpiResult reductions_result;
//
//    getAdaptationCapacityReduction(reduction, reductions_result);
//
//    if ((reductions_result.getResult() == LpiResult::E_OK) && (reductions_result.getResult() == LpiResult::E_OK))
//    {
//        BOOST_FOREACH(string id, runway_ids)
//        {
//            if (rwyTable.exists(id))
//            {
//                rwyTable[id].calculateMaximumCapacity();
//                rwyTable[id].calculateNoOperationCapacity();
//                rwyTable[id].calculateManualReductionCapacity();
//                rwyTable[id].calculateILSCapacity();
//
//                if (reductions_result.getResult() == LpiResult::E_OK)
//                {
//                    LpiADOVector<double> crosswind_reduction = reduction.getCrossWindCapacityReduction(id);
//                    LpiADOVector<double> tailwind_reduction = reduction.getTailWindCapacityReduction(id);
//                    LpiADOVector<double> visibility_reduction = reduction.getHorizontalVisibilityReduction(id);
//
//                    rwyTable[id].applyMeteoReductions(crosswind_reduction, tailwind_reduction, visibility_reduction,
//                                                      thresholds);
//                }
//            }
//        }
//    }
//}


//
//void LpdBusinessLogicFacade::calculateRunwaysMaxCapacities(string interval)
//{
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Calculating Ruways maximum capacities..." << interval << std::endl;
//#endif
//
//    LpdbDataBase::RunwayTable & rwyTable = LpdbDataBase::Get().getRunwayTable();
//    vector<string> runway_ids = rwyTable.getAllIds();
//
//    //Get thresholds for applying reductions
//    LpiAdaptationMeteothresholdList thresholds;
//    LpiResult thresholds_result;
//
//    getAdaptationMeteoThresholds(thresholds, thresholds_result);
//
//    //Get minimal capacity reduction
//    LpiAdaptationCapacityReduction reduction;
//    LpiResult reductions_result;
//
//    getAdaptationCapacityReduction(reduction, reductions_result);
//
//    if ((reductions_result.getResult() == LpiResult::E_OK) && (reductions_result.getResult() == LpiResult::E_OK))
//    {
//        BOOST_FOREACH(string id, runway_ids)
//        {
//            if (rwyTable.exists(id))
//            {
//                rwyTable[id].calculateMaximumCapacity(interval);
//                rwyTable[id].calculateNoOperationCapacity(interval);
//                rwyTable[id].calculateManualReductionCapacity(interval);
//                rwyTable[id].calculateILSCapacity(interval);
//
//                if (reductions_result.getResult() == LpiResult::E_OK)
//                {
//                    LpiADOVector<double> crosswind_reduction = reduction.getCrossWindCapacityReduction(id);
//                    LpiADOVector<double> tailwind_reduction = reduction.getTailWindCapacityReduction(id);
//                    LpiADOVector<double> visibility_reduction = reduction.getHorizontalVisibilityReduction(id);
//
//                    rwyTable[id].applyMeteoReductions(interval, crosswind_reduction, tailwind_reduction,
//                                                      visibility_reduction, thresholds);
//                }
//            }
//        }
//    }
//}

//
//void LpdBusinessLogicFacade::calculateRSMaxCapacities(void)
//{
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Calculating Runway System maximum capacities..." << std::endl;
//#endif
//
//    LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();
//    vector<string> rs_ids = rsTable.getAllIds();
//
//    BOOST_FOREACH(string id, rs_ids)
//    {
//        if (rsTable.exists(id))
//        {
//            rsTable[id].calculateMaximumCapacity();
//        }
//    }
//}
//
//void LpdBusinessLogicFacade::calculateRSMaxCapacities(string interval)
//{
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug() << "Calculating Runway System maximum capacities...interval " << interval << std::endl;
//#endif
//
//    LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();
//    vector<string> rs_ids = rsTable.getAllIds();
//
//    BOOST_FOREACH(string id, rs_ids)
//    {
//        if (rsTable.exists(id))
//        {
//            rsTable[id].calculateMaximumCapacity(interval);
//        }
//    }
//}
//
//void LpdBusinessLogicFacade::calculateAirportMaxCapacitiesAndMinDelayedFPs(void)
//{
//    TimeLine<LpdbDCBAirportTimedData> & airportTimeline = LpdbDataBase::Get().getDCBAirportTimeline();
//
//    vector<string> intervals = airportTimeline.getAllIntervalIds();
//
//    BOOST_FOREACH(string interval, intervals)
//    {
//        //calculatePriorityOperation(interval);
//        //calculateAirportMaxCapacitiesForAllRS(interval);
//        //calculateMinDelayedFPs(interval);
//    }
//}
