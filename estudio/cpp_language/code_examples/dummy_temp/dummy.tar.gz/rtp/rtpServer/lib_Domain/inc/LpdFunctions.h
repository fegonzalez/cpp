#ifndef LPD_FUNCTIONS_H__
#define LPD_FUNCTIONS_H__

/*
 * General purpose functions.
 */


#include <string>

	bool managedAirport(std::string airport);

#endif

