/*
 * LpdDefaultSchedule.h
 *
 *  Created on: Oct 29, 2018
 *      Author: srperez
 */

#ifndef LPDDEFAULTSCHEDULE_H_
#define LPDDEFAULTSCHEDULE_H_

#include <vector>
#include <string>
#include <LpmodPartition.h>
#include "LpiAdaptationAssignmentPreference.h"

class LpdDefaultSchedule
{

public:

	static LpdDefaultSchedule& Get(void)
	{
		static LpdDefaultSchedule component;
		return component;
	}

	LpdDefaultSchedule();
	void generateDefaultSchedule ();
	int calculateCost(std::string a1, std::string a2);
	std::vector<std::string> scheduleDefault(std::vector<std::string> listAirports, unsigned int numMrtm);
	std::vector<std::string> getDefaultSchedule();
	static std::vector<std::string> splitString( const std::string& strStringToSplit,
	                                                 const std::string& strDelimiter,
	                                                 const bool keepEmpty = true );
	void setAdaptationPreference(LpiAdaptationAssignmentPreference pref);
private:
//	std::vector<std::string> r_default_schedule;
	std::vector<std::string> default_schedule;
	LpiAdaptationAssignmentPreference preference;
};



#endif /* LPDDEFAULTSCHEDULE_H_ */
