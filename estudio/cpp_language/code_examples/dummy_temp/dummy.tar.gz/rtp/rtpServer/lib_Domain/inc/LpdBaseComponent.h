#ifndef LPDBASECOMPONENT_H
#define LPDBASECOMPONENT_H

#include <LpiConsumers.h>
#include <LpiPublishers.h>
#include <LpiProviders.h>
#include <LpiUsers.h>
#include <LpiInterfaces.h>
#include <LpiEvents.h>
#include <LpiResult.h>
#include <LpiTime.h>
#include <LpiFlightPlan.h>
#include <LpiMeteoInfo.h>
#include <LpiCapacityReductions.h>
#include <LpiOptimizationCriteria.h>
#include <LpiConfigurationCoreParameters.h>
#include <LpiConfigurationConstraints.h>
#include <LpiAdaptationAlert_KPIs.h>
//#include <LpiAdaptationRunway.h>
//#include <LpiAdaptationRunwaySystem.h>
#include <LpiAdaptationAirportsInfo.h>
#include <LpiScheduleActivation.h>
#include <LpiActiveSchedule.h>
#include <LpiAlternativeSchedule.h>
#include <LpiWakeVortexCapacityReductions.h>

#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/make_shared.hpp>

class LpdBaseComponent : public LpiILifeCycle,
                         public LctimIObserver,
                         public LpiIUpdateSystemTimeEvtConsumer,
                         public LpiIGetSystemTimeSrvDelegateUser,
                         public LpiIGetConfigurationCoreParametersSrvDelegateUser,
                         public LpiIGetConfigurationCoreParameters,
                         public LpiIGetConfigurationHmiParametersSrvDelegateUser,
                         public LpiIGetConfigurationHmiParameters,
                         public LpiIGetAdaptationAlert_KPIsSrvDelegateUser,
                         public LpiIGetAdaptationAlert_KPIs,
                         public LpiIUpdateSystemTime,
						 public LpiIGetAdaptationMrtmInfoSrvDelegateUser,
						 public LpiIGetAdaptationMrtmInfo,
						 public LpiIGetAdaptationAssignmentPreferenceSrvDelegateUser,
						 public LpiIGetAdaptationAssignmentPreference,
//                         public LpiIGetAdaptationRunwaySrvDelegateUser,
//                         public LpiIGetAdaptationRunway,
//                         public LpiIGetAdaptationRunwaySystemSrvDelegateUser,
//                         public LpiIGetAdaptationRunwaySystem,
                         public LpiIGetAdaptationAirportsInfoSrvDelegateUser,
                         public LpiIGetAdaptationAirportsInfo,
                         public LpiIGetSystemTime,
                         public LpiIOptimalScheduleEvtDelegatePublisher,
                         public LpiIOptimalCriteriaEvtDelegatePublisher,
                         public LpiIMeteoForecastEvtDelegatePublisher,
                         public LpiIMeteoNowcastEvtDelegatePublisher,
                         public LpiIDemandEvtDelegatePublisher,
						 public LpiIActiveScheduleRTPEvtDelegatePublisher,
                         public LpiIActiveScheduleEvtPublisher,
                         public LpiIGenerateManualScheduleEvtConsumer,
                         public LpiIScheduleDeleteEvtConsumer,
                         public LpiIAlternativeScheduleEvtPublisher,
                         public LpiISchedulesComparisonEvtConsumer,
                         public LpiISchedulesComparisonResponseEvtDelegatePublisher,
                         public LpiIWhatIfRunwayClosureEvtConsumer,
                         public LpiIAutomaticDeletionEvtDelegatePublisher,
                         public LpiIGetPriorityTable,
                         public LpiIGetPriorityTableSrvDelegateUser,
                         public LpiIGetWakeVortexCapacityReductionsSrvDelegateUser,
                         public LpiIGetWakeVortexCapacityReductions
{
public:
   LpdBaseComponent();
   virtual ~LpdBaseComponent();

   // Notification of consumed events
   virtual void consume(const LpiUpdateSystemTimeEvt &event);
   virtual void consume(const LpiCreateDemandEvt &event);
   virtual void consume(const LpiMeteoForecastEvt &event);
   virtual void consume(const LpiMeteoNowcastEvt &event);
   virtual void consume(const LpiOptimizationCriteriaEvt &event);
   virtual void consume(const LpiCapacityReductionsEvt &event);
   virtual void consume(const LpiScheduleActivationEvt &event);
   virtual void consume(const LpiManualEditionEvt &event);
   virtual void consume(const LpiScheduleDeleteEvt &event);
   virtual void consume(const LpiSchedulesComparisonEvt & event);
   virtual void consume(const LpiWhatIfRunwayClosureEvt & event);

   // Notification of required services

   // Subscription to delegated publisher object
   virtual void delegatePublisher(LpiIActiveScheduleRTPEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIOptimalScheduleRTPEvtPublisher &publisher);

   virtual void delegatePublisher(LpiIOptimalScheduleEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIOptimalCriteriaEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIMeteoForecastEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIMeteoNowcastEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIDemandEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIActiveScheduleEvtPublisher &publisher);
   virtual void delegatePublisher(LpiIAlternativeScheduleEvtPublisher &publisher);
   virtual void delegatePublisher(LpiISchedulesComparisonResponseEvtPublisher & publisher);
   virtual void delegatePublisher(LpiIAutomaticDeletionEvtPublisher & publisher);

   // Subscription of delegated user object
   virtual void delegateUser(LpiIGetSystemTimeSrvUser &user);
   virtual void delegateUser(LpiIGetConfigurationCoreParametersSrvUser &user);
   virtual void delegateUser(LpiIGetConfigurationHmiParametersSrvUser &user);
   virtual void delegateUser(LpiIGetAdaptationAlert_KPIsSrvUser &user);
   virtual void delegateUser(LpiIGetAdaptationMrtmInfoSrvUser &user);
   virtual void delegateUser(LpiIGetAdaptationAssignmentPreferenceSrvUser &user);
//   virtual void delegateUser(LpiIGetAdaptationRunwaySrvUser &user);
//   virtual void delegateUser(LpiIGetAdaptationRunwaySystemSrvUser &user);
   virtual void delegateUser(LpiIGetAdaptationAirportsInfoSrvUser &user);
   virtual void delegateUser(LpiIGetPriorityTableSrvUser &user);
//   virtual void delegateUser(LpiIGetRunwaySystemProhibitionsSrvUser &user);
   virtual void delegateUser(LpiIGetWakeVortexCapacityReductionsSrvUser &user);


   // Consumed events
   virtual void updateSystemTime (const LpiTime &time) = 0;
   virtual void updateDemand (const LpiCreateDemandList &demand) = 0;
   virtual void updateMeteoForecast (const LpiCreateMeteoList &meteo) = 0;
   virtual void updateMeteoNowcast (const LpiCreateMeteoList & meteo) = 0;
   virtual void updateOptimizationCriteria (const LpiOptimizationCriteria &optimization) = 0;
   virtual void updateCapacityReductions (const LpiCapacityReductions &reductions) =  0;
   virtual void updateScheduleActivation( const LpiScheduleActivation &scheduleActivation) = 0;
   virtual void generateManualSchedule (const LpiAlternativeSchedule & manualSchedule) = 0;
   virtual void deleteSchedule (int scheduleId) = 0;
   virtual void compareSchedules (const LpiSchedulesComparison & schedulesToCompare) = 0;
   virtual void generateWhatIfRunwayClosures(const LpiWhatIfClosure & clorures) = 0;

   // Published events


   // Provided services


   // Used services
   virtual void getSystemTime(LpiTime &tick, LpiResult &result);

   virtual void getConfigurationCoreParameters(LpiConfigurationCoreParameters &configurationCoreParameters,
                                              LpiResult &result);

   virtual void getConfigurationHmiParameters(LpiConfigurationHmiParameters &configurationHmiParameters,
                                              LpiResult &result);

   virtual void getAdaptationAlert_KPIs(LpiAdaptationAlert_KPIs &configurationAlert_KPIs,
                                           LpiResult &result);

   virtual void getAdaptationMrtmInfo(LpiAdaptationMrtmInfo &mrtmInfo,
                                               LpiResult        &result);

   virtual void getAdaptationAssignmentPreference(LpiAdaptationAssignmentPreference &adaptationAssignmentPreference,
                                              LpiResult &result);

//   virtual void getAdaptationRunway(LpiAdaptationRunwayList &adaptationRunway,
//                                           LpiResult &result);
//   virtual void getAdaptationRunwaySystem(LpiAdaptationRunwaySystemList &adaptationRunwaySystem,
//                                           LpiResult &result);
   virtual void getAdaptationAirportsInfo(LpiAdaptationAirportsInfo &adaptationAirportsInfo,
                                           LpiResult &result);
   virtual void getPriorityTableDepartures(LpiPriorityTable & priorities, LpiResult & result);
   virtual void getPriorityTableArrivals(LpiPriorityTable & priorities, LpiResult & result);

   virtual void getWakeVortexCapacityReductions(LpiWakeVortexCapacityReductions &capacity,
                                                       LpiResult &result);

   virtual void publish(const LpiActiveScheduleRTPEvt &data);
   virtual void publish(const LpiOptimalScheduleRTPEvt &data);

   virtual void publish(const LpiUpdateDemandEvt &data);
   virtual void publish(const LpiOptimalScheduleEvt &data);
   virtual void publish(const LpiOptimalCriteriaEvt &data);
   virtual void publish(const LpiMeteoForecastEvt &data);
   virtual void publish(const LpiMeteoNowcastEvt &data);
   virtual void publish(const LpiActiveScheduleEvt & data);
   virtual void publish(const LpiAlternativeScheduleEvt & data);
   virtual void publish(const LpiSchedulesComparisonResponseEvt & data);
   virtual void publish(const LpiAutomaticDeletionEvt & data);

protected:
   // Published events to delegated publisher


   // Required services to delegated user

   virtual void use(const LpiGetSystemTimeRequest  &request,
                    LpiGetSystemTimeReply          &reply);

   virtual void use(LpiGetConfigurationCoreParametersReply & reply);
   virtual void use(LpiGetConfigurationHmiParametersReply & reply);
   virtual void use(LpiGetAdaptationAlert_KPIsReply & reply);
   virtual void use(LpiGetAdaptationMrtmInfoReply & reply);
   virtual void use(LpiGetAdaptationAssignmentPreferenceReply & reply);
//   virtual void use(LpiGetAdaptationRunwayReply & reply);
//   virtual void use(LpiGetAdaptationRunwaySystemReply & reply);
   virtual void use(LpiGetAdaptationAirportsInfoReply & reply);
   virtual void use(LpiGetPriorityReply & reply);
//   virtual void use(LpiGetRunwaySystemProhibitionsReply & reply);
   virtual void use(LpiGetWakeVortexCapacityReductionsReply & reply);

private:

   boost::shared_ptr<LpiGetSystemTimeSrvDelegateUser>
   	   	   	   	   	   	   	   	   _pGetSystemTimeSrvDelegateUser;
   boost::shared_ptr<LpiGetConfigurationCoreParametersSrvDelegateUser>
                                      _pGetConfigurationCoreParametersSrvDelegateUser;
   boost::shared_ptr<LpiGetConfigurationHmiParametersSrvDelegateUser>
                                      _pGetConfigurationHmiParametersSrvDelegateUser;
   boost::shared_ptr<LpiGetAdaptationAlert_KPIsSrvDelegateUser>
                                   _pGetAdaptationAlert_KPIsSrvDelegateUser;
   boost::shared_ptr<LpiGetAdaptationMrtmInfoSrvDelegateUser>
        	   	   	   	   	   	   	   _pGetAdaptationMrtmInfoSrvDelegateUser;
   boost::shared_ptr<LpiGetAdaptationAssignmentPreferenceSrvDelegateUser>
                                       _pGetAdaptationAssignmentPreferenceSrvDelegateUser;


//   boost::shared_ptr<LpiGetAdaptationRunwaySrvDelegateUser>
//      	   	   	   	   	   	   	   _pGetAdaptationRunwaySrvDelegateUser;

//   boost::shared_ptr<LpiGetAdaptationRunwaySystemSrvDelegateUser>
//      	   	   	   	   	   	   	   _pGetAdaptationRunwaySystemSrvDelegateUser;

   boost::shared_ptr<LpiGetAdaptationAirportsInfoSrvDelegateUser>
                                   _pGetAdaptationAirportsInfoSrvDelegateUser;

   boost::shared_ptr<LpiGetPriorityTableSrvDelegateUser>
   	   	   	   	   	   	   	   	   _pGetPriorityTableSrvDelegateUser;

   boost::shared_ptr<LpiGetWakeVortexCapacityReductionsSrvDelegateUser> 
	_pGetWakeVortexCapacityReductionsSrvDelegateUser;


   //User delegate for sending

   boost::shared_ptr<LpiActiveScheduleRTPEvtDelegatePublisher>
      	   	   	   	   	   	   	   	   _pActiveScheduleRTPEvtDelegatePublisher;
   boost::shared_ptr<LpiOptimalScheduleRTPEvtDelegatePublisher>
      	   	   	   	   	   	   	   	   _pOptimalScheduleRTPEvtDelegatePublisher;

   boost::shared_ptr<LpiOptimalScheduleEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pOptimalScheduleEvtDelegatePublisher;
   boost::shared_ptr<LpiOptimalCriteriaEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pOptimalCriteriaEvtDelegatePublisher;
   boost::shared_ptr<LpiDemandEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pDemanEvtDelegatePublisher;
   boost::shared_ptr<LpiActiveScheduleEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pActiveScheduleEvtDelegatePublisher;
   boost::shared_ptr<LpiMeteoForecastEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pMeteoForecastEvtDelegatePublisher;
   boost::shared_ptr<LpiMeteoNowcastEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pMeteoNowcastEvtDelegatePublisher;
   boost::shared_ptr<LpiAlternativeScheduleEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pAlternativeScheduleEvtDelegatePublisher;
   boost::shared_ptr<LpiSchedulesComparisonResponseEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pSchedulesComparisonResponseEvtDelegatePublisher;
   boost::shared_ptr<LpiAutomaticDeletionEvtDelegatePublisher>
   	   	   	   	   	   	   	   	   _pAutomaticDeletionEvtDelegatePublisher;

 };

#endif // LPDBASECOMPONENT_H
