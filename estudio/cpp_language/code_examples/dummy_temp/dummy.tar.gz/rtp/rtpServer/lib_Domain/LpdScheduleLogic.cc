/*
 * LpdScheduleLogic.cc
 *
 * Section of LpdBusinessLogicFacade.cc related to shedule calculations.
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.4.1"
 
 */

#include <LpdBusinessLogicFacade.h>
#include <LplcTypeConstants.h>
#include <LclogStream.h>
#include <LpdComponent.h>
#include <LpdbScheduleConverter.h>
#include <LpiActiveScheduleRTPEvt.h>
#include <LpiOptimalScheduleRTPEvt.h>

#include <cassert>


//--------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::initDefaultSchedule()

*/
void LpdBusinessLogicFacade::initDefaultSchedule(const LpiAdaptationAssignmentPreference &ass_pref, const LpiAdaptationAirportsInfo &airInfo)
{

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).info() << "DEFAULT SCHEDULE CALCULATION after system setup" <<std::endl;
#endif

  the_schedule_manager.initDefaultSchedule(ass_pref, airInfo);
  the_schedule_manager.initDefaultScheduleDB();
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::sendDefaultSchedule()
{
  assert(the_schedule_manager.existsDefaultSchedule());

  if(the_schedule_manager.existsDefaultSchedule())
  {
	  LpiActiveScheduleRTPEvt actSchEvt;
	  actSchEvt.setSchedule(the_schedule_manager.getDefaultSchedule());

	  LpdComponent::Get().publish(actSchEvt);

	  LpiOptimalScheduleRTPEvt optSchEvt;
	  optSchEvt.setSchedule(the_schedule_manager.getDefaultSchedule());

	  LpdComponent::Get().publish(optSchEvt);
  }

}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::manualActivationOptimalSchedule
    (int schedule_id,
     LpiScheduleActivationType::LpiEnum activation_type)
{

  // case: bad input: show error and return
  assert(schedule_id == rtp_constants::SCHEDULE_ID_OPTIMAL);
  assert(activation_type == LpiScheduleActivationType::E_MANUAL);

  bool invariant = (schedule_id == rtp_constants::SCHEDULE_ID_OPTIMAL);
  if(not invariant)
  {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).error()
      << "Manual activation of the optimal schedule; bad schedule id."
      << " (" << schedule_id << ')'
      << std::endl;
#endif
    
      return;
  }
  invariant = invariant and 
              (activation_type == LpiScheduleActivationType::E_MANUAL);
  if(not invariant)
  {
#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).error()
      << "Manual activation of the optimal schedule; bad activation type"
      << " (" << activation_type << ')'
      << std::endl;
#endif
    
      return;
  }
  
  
  // case: valid input: active schedule = current optimal schedule
 LpdbDataBase::Get().setActiveSchedule
   (LpdbScheduleConverter::convert
    (*LpdbDataBase::Get().getOptimalSchedule().get()));


 testLog_dbDefaultSchedule();

}

//------------------------------------------------------------------------------

///@todo Use case <<Save active & optimal schedules in DB after system setup>> [1].4.4.1
void LpdBusinessLogicFacade::testLog_dbDefaultSchedule()const
{

#ifdef TRACE_OUT

  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@test result <<default schedule in DB>>"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;

///@todo code me: see  testLog_calculateMaxCapacities()

  assert(LpdbDataBase::Get().hasOptimalSchedule());
  assert(LpdbDataBase::Get().hasActiveSchedule());

 LclogStream::instance(LclogConfig::E_RTP).debug()
   << "# System setup, Optimal-Schedule: "
   << *(LpdbDataBase::Get().getOptimalSchedule().get());

 LclogStream::instance(LclogConfig::E_RTP).debug()
   << "# System setup, Active-Schedule: "
   << *(LpdbDataBase::Get().getActiveSchedule().get());

#endif
}




