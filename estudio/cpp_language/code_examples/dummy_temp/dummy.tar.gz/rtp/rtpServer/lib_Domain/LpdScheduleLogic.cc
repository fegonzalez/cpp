/*
 * LpdScheduleLogic.cc
 *
 * Section of LpdBusinessLogicFacade.cc related to shedule calculations.
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.4.1"
 
 */

#include <LpdBusinessLogicFacade.h>
#include <LplcTypeConstants.h>
#include <LclogStream.h>
#include <LpdComponent.h>

//#include <iostream>
//#include <ctime>
// #include <string>
// #include <vector>
// #include <iterator>

#include <cassert>
#include <LpiActiveScheduleRTPEvt.h>

//#include <algorithm>    // std::for_each


//--------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::initDefaultSchedule()

*/
void LpdBusinessLogicFacade::initDefaultSchedule(const LpiAdaptationAssignmentPreference &ass_pref, const LpiAdaptationAirportsInfo &airInfo)
{

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).info() << "DEFAULT SCHEDULE CALCULATION after system setup" <<std::endl;
#endif

  the_schedule_manager.initDefaultSchedule(ass_pref, airInfo);
  the_schedule_manager.initDefaultScheduleDB();
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::sendDefaultSchedule() const
{
  assert(the_schedule_manager.existsDefaultSchedule());

  if(the_schedule_manager.existsDefaultSchedule())
  {
	  LpiActiveScheduleRTPEvt actSchEvt;
	  actSchEvt.setSchedule(the_schedule_manager.getDefaultSchedule());

	  LpdComponent::Get().publish(actSchEvt);

	  LpiOptimalScheduleRTPEvt optSchEvt;
	  optSchEvt.setSchedule(the_schedule_manager.getDefaultSchedule());

	  LpdComponent::Get().publish(optSchEvt);
  }
}

//------------------------------------------------------------------------------

///@todo Use case <<Save active & optimal schedules in DB after system setup>> [1].4.4.1
void LpdBusinessLogicFacade::testLog_dbDefaultSchedule()const
{

#ifdef TRACE_OUT

  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@todo FIXME     @test result <<default schedule in DB>>"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;

///@todo code me: see  testLog_calculateMaxCapacities()


#endif
}
