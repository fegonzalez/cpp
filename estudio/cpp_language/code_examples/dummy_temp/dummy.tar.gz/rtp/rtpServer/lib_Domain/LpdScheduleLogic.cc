/*
 * LpdScheduleLogic.cc
 *
 * Section of LpdBusinessLogicFacade.cc related to shedule calculations.
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter "4.4.1"
 
   Requirements extracted from doc [1]:
 
   - R441.1: Función “Buscar la combinación preferente
     aeropuerto-módulo”. HINT: esto es una programación (en DB)

   - R441.2 Inicializar programación activa al arrancar RTP.
   - R441.2-1 Programación activa inicial = combinación preferente
     aeropuerto-módulo.
   - R441.2-2 Almacenar programación activa en DB

   - R441.3 Inicializar programación óptima al arrancar RTP.
   - R441.3-1 Programación óptima inicial = Programación activa inicial.
   - R441.3-2 Almacenar programación activa en DB


  DUDA: relación programación – módulos
        Programación = lista de módulos?
        Qué se guarda en DB?   Tabla módulo + tabla programación?


   - R441.4 Enviar la programación activa al HMI
   - R441.4-1 Crear IDL con datos de programación activa
   - R441.4-2 Crear evento “sendProgActiva” en server.
   - R441.4-3 Crear evento “readdProgActiva” en HMI.

   - R441.5 Enviar la programación óptima al HMI
   - R441.5-1 Crear IDL con datos de programación óptima
   - R441.5-2 Crear evento “sendProgOptim” en server.
   - R441.5-3 Crear evento “readdProgOptim” en HMI.

 */

#include "LpdBusinessLogicFacade.h"
#include <LplcTypeConstants.h>
#include <LclogStream.h>
#include "LpiDefaultScheduleEvt.h"
#include "LpdComponent.h"

//#include <iostream>
//#include <ctime>
// #include <string>
// #include <vector>
// #include <iterator>

#include <cassert>

//#include <algorithm>    // std::for_each


//--------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::initDefaultSchedule()

*/
void LpdBusinessLogicFacade::initDefaultSchedule(const LpiAdaptationAssignmentPreference &ass_pref, const LpiAdaptationAirportsInfo &airInfo)
{
  assert(existsScheduleManager());
  the_schedule_manager->initDefaultSchedule(ass_pref, airInfo);
  
    
   ///@todo R441.2-2 Store initial schedule in the DB.
   ///@todo R441.3-2 Store optimal schedule in the DB.



  //   #ifdef TRACE_OUT
  //      LclogStream::instance(LclogConfig::E_RTP).debug()
  //        << "Default schedule generated." << std::endl;
  //   #endif


  ////////////////////////////////////////////////////////////////////

  
  /**@todo FIXME check RMAN actions: calcular costes para inicializar programación inicial.


   ///@todo transitionsTable to schedule

  LclogStream::instance(LclogConfig::E_RTP).warning()
    << "@TODO  STEP-4: DB initialization: transitionsTable ..."
    << std::endl;


   // RMAN code bellow:
   //

//  LriRSChangeCostTable transitionsTable;
//  getRSChangeCosts(transitionsTable, result);
//
//  generateRunwaySystemTransitionCosts(transitionsTable);
//
//#ifdef TRACE_OUT
//  LclogStream::instance(LclogConfig::E_RMAN).debug() << "RS change table generated: " << std::endl;
//  LclogStream::instance(LclogConfig::E_RMAN).debug() << transitionsTable << std::endl;
//
//  LclogStream::instance(LclogConfig::E_RMAN).debug() << "DataBase initialized." << std::endl;
//
   //    LpiAdaptationRunwaySystemPreferenceList preferences;
   //    getAdaptationRunwaySystemPreference(preferences, result);


// #ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).debug()
//      << "@TODO  STEP-4: DB initialization: transitionsTable ..."
//      << std::endl;
// #endif
//    LpiAdaptationMrtmTransitionCostTable transitionsTable;
//    getAdaptationMrtmTransitionCosts(transitionsTable, result);
//
//    generateMrtmTransitionCosts(transitionsTable);
// #ifdef TRACE_OUT
//     LclogStream::instance(LclogConfig::E_RTP).debug()
//       << "@todo RS change table generated: " << std::endl;
//     LclogStream::instance(LclogConfig::E_RTP).debug()
//       << transitionsTable << std::endl;
//     LclogStream::instance(LclogConfig::E_RTP).debug()
//       << "DataBase initialized." << std::endl;
// #endif


//    _schedules_generator->setCalculationParameters();
//    _schedules_generator->setPreferentialLevels(preferences);
//    _schedules_generator->setStabilityCostMatrix(transitionsTable);


//    _schedules_generator->generateDefaultSchedule();  /// EQUIVALE a  rtp_default_schedule->generateDefaultSchedule();

   */
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::sendDefaultSchedule() const
{
  assert(existsScheduleManager());
  assert(the_schedule_manager->existsDefaultSchedule());

  if(existsScheduleManager() and the_schedule_manager->existsDefaultSchedule())
  {
    LpiDefaultScheduleEvt defSchEvt;
    
    defSchEvt.setDefaultSchedule(the_schedule_manager->getDefaultSchedule());

    LpdComponent::Get().publish(defSchEvt);
  }
}

//------------------------------------------------------------------------------

