#ifndef LPDCOMPONENT_H__
#define LPDCOMPONENT_H__

#include "LpiCalculationReason.h"
#include "LpdBaseComponent.h"
#include "LpdBusinessLogicFacade.h"
#include "LpiCreateDemandEvt.h"

#include <boost/thread.hpp>
#include <boost/bind.hpp>


class LpdComponent : public LpdBaseComponent
{
public:
   static LpdComponent& Get(void)
   {
      static LpdComponent component;
      return component;
   }

   // Eventos consumidos
   virtual void updateSystemTime(const LpiTime &time);
   virtual void updateDemand(const LpiCreateDemandList  &demand);
   virtual void updateMeteoForecast(const LpiCreateMeteoList &meteolist);
   virtual void updateMeteoNowcast(const LpiCreateMeteoList &meteolist);
   virtual void updateOptimizationCriteria (const LpiOptimizationCriteria &optimization);

   /**
    * @warning Activated by the HMI after a manual update  (not in actual RTP phase)
    *          Handled by the server in LpcCapacityReductionsEvtConsumer.
    */
   virtual void updateCapacityReductions (const LpiCapacityReductions &reductions);

   virtual void updateScheduleActivation( const LpiScheduleActivation &scheduleActivation);
   virtual void generateManualSchedule (const LpiAlternativeSchedule & manualSchedule);
   virtual void deleteSchedule (int scheduleId);
   virtual void compareSchedules (const LpiSchedulesComparison & schedulesToCompare);
   virtual void generateWhatIfRunwayClosures(const LpiWhatIfClosure & clorures);

   // Servicios Proporcionados
   virtual void create(void);
   virtual void initialise(void);
   virtual void complete(void);

   virtual void notify(void);
   virtual void test(void);


protected:

private:
   LpdComponent() {}
   LpdComponent(const LpdComponent&);
   LpdComponent& operator=(const LpdComponent&);
   LpdBusinessLogicFacade _businessLogic;

   //To ensure one calculation on event reception at a time
   boost::mutex r_mutex;
};

#endif // LPDCOMPONENT_H__
