/*
 * LpdDemandLogic.cc
 *
 * Section of  LpdBusinessLogicFacade.cc related to demand & FP calculations
 *
 * Note.- The demand message and the initial LpiCreateDemandList is handled in
 * the consumer (LpcCreateDemandEvtConsumer::on_data_available)
 *
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx",
 *
 */

#include <LpdBusinessLogicFacade.h>
#include <LpdComponent.h>
#include <LplcTypeConstants.h>
#include <LpdbCommon.h>
#include <LpdbDataBase.h>
#include <LpdbDemand.h>
#include <LclogStream.h>
#include <LctimVirtualClock.h>
#include <LpiFlightPlan.h>

#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <cassert>
#include <algorithm>    // std::for_each

#include <boost/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>



//------------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::updateDemand(const LpiCreateDemandList &demand)
 *
 *@brief RTP server manages a new received demand input.
 *
 * DOC Reference: [1] "RTP Diseño Funcional.docx", chapter 4.2.1
 * Demanda prevista.
 *
 * - (R421.1) Use case: "Recibir Input demanda desde RTP Server"
 * - (R421.2) Use case: "Transmitir Input demanda al HMI desde el RTP Server"
 * - (R421.3) Use case: "Almacenar en la Base de datos cada plan de
 *                       vuelo, al recibir nuevo input de demanda"
 *
 *
 *
 *  @test R421.3-5 AND  R421.3-7  ya se hizo en el consumer:  LpcCreateDemandEvtConsumer::on_data_available

    @test R421.3-6  AND  R421.3-8: validTime()
 */
void LpdBusinessLogicFacade::updateDemand(const LpiCreateDemandList &input)
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "updateDemand event."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif


  // Handle every FP for each airport.
  for(unsigned int airport_in_input  = 0;
      airport_in_input  < input.size();
      ++airport_in_input)
  {

    // Use case (R421.1): Update DB with the new data for each airport
    updateDB_demand(input.at(airport_in_input));
  
    /// deleteNotReceivedFPs(receivedFPKeys); //no se paque se hace esto en rMAN


    // (collect data to be sent to the HMI for each airport)
    updateHMIDemand(LpiCalculationReason::E_NEW_DEMAND, input.at(airport_in_input));
  }

  LpdbDataBase::Get().setInputReceivedInLastInterval(true);


  // Use case (R421.2): Send demand data to the HMI
  publishUpdateDemandToHmi();


  /// Use case: calculate complexity for each airport, for each interval
  ///           after (E_NEW_DEMAND) [1].4.3.2
  /// (must be here, after save_fp_in_DB
  calculateComplexity(); // impl. at LpdComplexityLogic.cc
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
 << "@test Use case <<complexity after E_NEW_DEMAND event>> [1].4.3.2"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
testLog_calculateComplexity();
#endif



///@todo FIXME Update schedules: see RMAN code



///@test Demand information in the DB
#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
 << "@test Use case <<demand after E_NEW_DEMAND event>> [1].4.2.1"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
 testLog_updateDemand();
#endif

}


//------------------------------------------------------------------------------
// Demnad's DB logic
//------------------------------------------------------------------------------

///@brief update DB with the new demand data received for ONE airport
void LpdBusinessLogicFacade::updateDB_demand(const LpiCreateDemand &input)
{
  LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();

  // already validated at LpcCreateDemandEvtConsumer::on_data_available
  assert(airport_table.exists(input.getNameAirport()));

  airport_table[getAirportId()].updateDemand(input);
}


//------------------------------------------------------------------------------
// Demand's HMI logic
//------------------------------------------------------------------------------

/**
 * @brief Update 'demandUpdateList' with the new demand data to send to the HMI
 */
void LpdBusinessLogicFacade::updateHMIDemand(const LpiCalculationReason::LpiEnum &reason,
		                                     const LpiCreateDemand &demandL)
{
    LpiDemand lpiDemand;
    LpdbAirport::FPTable & fp_table = LpdbDataBase::Get().getFPTable(demandL.getNameAirport());

    vector<string> fp_keys = fp_table.getAllIds();

	LpdbDemand & demand = LpdbDataBase::Get().getDemand(demandL.getNameAirport());
	vector<string> intervals = demand.getTimeLine().getAllIntervalIds();

	lpiDemand.setmessageTimeandDate(demand.getmessageTimeandDate());
	lpiDemand.setCalculationReason(reason);

	std::vector<Demand_list> demandList;
	std::vector<FPs_ADO> FpsLista;

	BOOST_FOREACH(string ti, intervals)
	{
		FPs_ADO fpAdo;

		Demand_list demandforecast;

		demandforecast.setIntervalName(ti);

		demandforecast.setdemandForecastScheduled(
				LpiADOConverter::Convert2Interface(demand.getTimeLine()[ti].getDemandForecast()));

		demandforecast.setDemandRatio(LpiADOConverter::Convert2Interface(demand[ti].getPonderatedDemand()));

		demandforecast.setStartTime(LctimTimeUtils::formatTime(demand.getTimeLine().getTimeInterval(ti).begin));
		demandforecast.setEndTime(LctimTimeUtils::formatTime(demand.getTimeLine().getTimeInterval(ti).end));

		demandList.push_back(demandforecast);

		int type = E_ARR;
		while (type <= E_DEP)
		{
			for (unsigned int j = 0; j < demand.getTimeLine()[ti].getDemandForecastFps()[type].size(); j++)
			{
				Fps_list fplist;
				fplist.reset();

				std::string name(demand.getTimeLine()[ti].getDemandForecastFps()[type][j]);

				for (unsigned int k = 0; k < fp_keys.size(); k++)
				{
				if (fp_table[fp_keys[k]].getUniqueKey() == name)
					{
						string callsign = fp_table[fp_keys[k]].getCallsign();
						boost::algorithm::trim(callsign);

						LpiFlightPlan fp = fp_table[fp_keys[k]];
						fplist.setdemandForecastFpsScheduled(fp.getCallsign());

						boost::optional<posix_time::ptime> intentional = fp.getIntentionalTime();
						if (intentional)
						{
							fplist.setItotIldt(*intentional);
						}
						fplist.setAircraftType(fp.getAircraftType());
						fplist.setOperationType(fp.getOperationType());

						if (type == E_DEP)
						{
							//Assign times
							LpiDepartureTimes dep_times = fp.getDepartureTimes();
							boost::optional<posix_time::ptime> fp_dep_time;

							fp_dep_time = dep_times.getCtot();
							if (fp_dep_time)
							{
								fplist.setCtotSibt(*fp_dep_time);
							}

							fp_dep_time = dep_times.getEtot();
							if (fp_dep_time)
							{
								fplist.setEtotEldt(*fp_dep_time);
							}

							fp_dep_time = dep_times.getStot();
							if (fp_dep_time)
							{
								fplist.setStotSldt(*fp_dep_time);
							}

							fp_dep_time = dep_times.getTtot();
							if (fp_dep_time)
							{
								fplist.setTtotTldt(*fp_dep_time);
							}

							fp_dep_time = dep_times.getUtot();
							if (fp_dep_time)
							{
								fplist.setUtotUldt(*fp_dep_time);
							}

							fplist.setSIDSTAR(fp.getSID());
							fpAdo.departure.push_back(fplist);
						}
						else
						{
							//Assign times
							LpiArrivalTimes arr_times = fp.getArrivalTimes();

							boost::optional<posix_time::ptime> fp_arr_time;

							fp_arr_time = arr_times.getSibt();
							if (fp_arr_time)
							{
								fplist.setCtotSibt(*fp_arr_time);
							}

							fp_arr_time = arr_times.getEldt();
							if (fp_arr_time)
							{
								fplist.setEtotEldt(*fp_arr_time);
							}

							fp_arr_time = arr_times.getSldt();
							if (fp_arr_time)
							{
								fplist.setStotSldt(*fp_arr_time);
							}

							fp_arr_time = arr_times.getTldt();
							if (fp_arr_time)
							{
								fplist.setTtotTldt(*fp_arr_time);
							}

							fp_arr_time = arr_times.getUldt();
							if (fp_arr_time)
							{
								fplist.setUtotUldt(*fp_arr_time);
							}

							fplist.setSIDSTAR(fp.getSTAR());
							fpAdo.arrivals.push_back(fplist);
						}

						fpAdo.overall.push_back(fplist);
						break;
					}
				}
			}
			type++;
		}
		FpsLista.push_back(fpAdo);
		fpAdo.arrivals.clear();
		fpAdo.departure.clear();
		fpAdo.overall.clear();
	}

	NumberDemand numberDemand;
	numberDemand.setDemand(demandList);

	numberDemand.settotalDemandForecast(LpiADOConverter::Convert2Interface(demand.getTotalDemandForecast()));

	numberDemand.setTotalDemandRatio(LpiADOConverter::Convert2Interface(demand.getTotalDemandRatio()));

	numberDemand.setTotalDemandVFR(LpiADOConverter::Convert2Interface(demand.getTotalDemandVFR()));

	lpiDemand.setDemand(numberDemand);

	lpiDemand.setFps(FpsLista);

	lpiDemand.setNameAirport(demandL.getNameAirport());
	lpiDemand.setDemandStartTimeAndDate(demandL.getDemandStartTimeAndDate());
	lpiDemand.setDemandEndTimeAndDate(demandL.getDemandEndTimeAndDate());

	LpiFlightPlanList fpList;
	for(unsigned int x = 0; x < demandL.getFlightPlanList().size(); x++)
	{
		LpiFlightPlan fp;
		fp = demandL.getFlightPlanList().at(x);
		fpList.push_back(fp);
	}
	lpiDemand.setFlightPlanList(fpList);

	demandUpdateList.push_back(lpiDemand);
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::publishUpdateDemandToHmi()
{

#ifdef TRACE_OUT
  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "updateDemand event, send data to HMI."
    << " : File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif
	LpiUpdateDemandEvt demandevt;
	demandevt.setDemand(demandUpdateList);
	demandUpdateList.clear();
	LpdComponent::Get().publish(demandevt);
}



//------------------------------------------------------------------------------
// [CLOCK_EVENT] demand's forwarding logic
//------------------------------------------------------------------------------

/**@fn void LpdBusinessLogicFacade::updateDemand(const LpiCreateDemandList &demand)
 *
 *  (called from void LpdBusinessLogicFacade::forwardTimeline(void))
 *
 *  @todo step 1: create new interval (within  void LpdbDataBase::forwardTimeline())
 *
 *
 *
 *
 *  @todo step 2: forward demand information (here)
 *
 *  @todo step 2.a: R421.10-1 Use case "Eliminar de la base de datos los planes de vuelo obsoletos, tras un avance de reloj interno."
 *
 *  @todo step 2.b: R421.9 Use case “Actualizar en la Base de datos la demanda calculada para cada par (Aeropuerto, Intervalo) tras un avance de reloj interno”

    FIXME: Do the equivalent to void LpdBusinessLogicFacade::reviewMeteoInfo(std::string new_interval)

    @todo For all the managed airports, check demand info on clock event (add stored info to new interval)

    @todo - Update demand info in the DB after a CLOCK event (for all airports);
    @todo - Send demand info for the new interval to the HMI (for all airports)


 */
void LpdBusinessLogicFacade::forwardDemand(std::string new_interval)
{
//current code in Facade

#ifdef TRACE_OUT
    LclogStream::instance(LclogConfig::E_RTP).debug() << "\todo Calculate Demand Data for new interval..." << new_interval
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;
#endif



    ///@todo step 2.a:  R421.10-1 Use case "Eliminar de la base de datos los planes de vuelo obsoletos, tras un avance de reloj interno."
    #ifdef TRACE_OUT
        LclogStream::instance(LclogConfig::E_RTP).debug() << "[CLOCK EVENT] Removing obsolete FPs (use cse R421.10-1) ..." << std::endl;
    #endif

        ///@warning RMAN code below (update for RTP)

        //
        //     double cancelation_threshold = LpdbDataBase::Get().getGlobalParameters().getFPExpirationTime();
        //
        ////   reviewObsoleteFlightPlans(cancelation_threshold);
        //    reviewObsoleteFlightPlansByAssignedTime(cancelation_threshold);




///@todo step 2.a: R421.9 Use case “Actualizar en la Base de datos la demanda calculada para cada par (Aeropuerto, Intervalo) tras un avance de reloj interno”


///@todo For each airport calculateTimedDemand(new_interval, airportName)
// calculateTimedDemand(new_interval, airport_name);


///@todo For each airport   LpdbDemand::updateTotalDemandForecast()
//
///@WARNING RMAN code, hacer lo mismo que en reviewMeteoInfo instead
//
//#ifdef TRACE_OUT
//    LclogStream::instance(LclogConfig::E_RTP).info() << "Demand Forecast:" << std::endl;
//#endif
//    for(unsigned int a = 0; a < parameters.getAirport().size(); a++)
//    	LpdbDataBase::Get().getDemand(parameters.getAirport().at(0).getAirportName()).updateTotalDemandForecast();



}


//------------------------------------------------------------------------------
// auxiliar demand functions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// demand test
//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::testLog_updateDemand()const
{

#ifdef TRACE_OUT

  LclogStream::instance(LclogConfig::E_RTP).debug()
    << "@test result <<update demand (airport, interval)>>"
    << " ; File: " << __FILE__
    << " ; fn: " << __func__
    << " ; line: " << __LINE__
    << std::endl;

  // Test code to show only one airport (mim. log file messages)
  // test data should be prepared for airport_id.

  // a) forecasted demand information (airport, interval)
  LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
  const std::string airport_id = {"ENNA"};
  if(airport_table.exists(airport_id))
  {
    LclogStream::instance(LclogConfig::E_RTP).debug()
      << "# Airport: <" << airport_id << ">"
      << std::endl
      << "# Airport demand inf:"
      << std::endl
      << airport_table[airport_id].getDemand()
	  //<< airport_table[airport_id].getFPTable()
      << std::endl;
  }

  // Test code to show all airports (works ok: verified)
  //
  //  auto log_msg = [this](const std::string airport_id)
  //  {
  //    LpdbDataBase::AirportTable & airport_table = LpdbDataBase::Get().getAirportTable();
  //    assert(airport_table.exists(airport_id));
  //    if(airport_table.exists(airport_id))
  //    {
  //    	LclogStream::instance(LclogConfig::E_RTP).debug()
  //    	    		  << "# Airport: <" << airport_id << ">"
  //					  << std::endl
  //					  << "# Airport demand inf:"
  //					  << std::endl
  //					  << airport_table[airport_id].getDemand()
  //					  << std::endl;
  //    }
  //  };//end-lambda
  //    std::vector<std::string> airport_keys =
  //      LpdbDataBase::Get().getAirportTable().getAllIds();
  //    std::for_each(std::begin(airport_keys), std::end(airport_keys), log_msg);



  // b) FP list
  LclogStream::instance(LclogConfig::E_RTP).debug() << "DataBase FPs:" << std::endl;
  LclogStream::instance(LclogConfig::E_RTP).debug() << LpdbDataBase::Get().getFPTable() << std::endl;

#endif


  // RMAN's oldie
//
// #ifdef TRACE_OUT
//   LclogStream::instance(LclogConfig::E_RTP).info() << "FPs DataBase:" << std::endl;
//   LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getFPTable() << std::endl;
//   LclogStream::instance(LclogConfig::E_RTP).info() << "Demand Forecast:" << std::endl;
//   LclogStream::instance(LclogConfig::E_RTP).info() << LpdbDataBase::Get().getDemand() << std::endl;
//   #endif

}






//======================================================================================
// RMAN code to be validated for RTP
//======================================================================================

///@todo FIXME Código RMAN, Validar para RTP
void LpdBusinessLogicFacade::calculateTimedDemand(std::string interval, std::string airport)
{
//    //Iterate Through all FPs and update data only if ITOT or ILDT is in given interval
//    LpdbDataBase::FPTable & fp_table = LpdbDataBase::Get().getFPTable();
//    LpdbDemand & demand = LpdbDataBase::Get().getDemand(airport);
//
//    vector<string> fp_keys = fp_table.getAllIds();
//
//    BOOST_FOREACH (string fp_key, fp_keys)
//    {
//        if (fp_table.exists(fp_key))
//        {
//            LpiFlightPlan fp = fp_table[fp_key];
//
//            boost::optional<posix_time::ptime> former_intentional;
//            boost::optional<posix_time::ptime> intentional = fp.getIntentionalTime();
//
//            if (intentional)
//            {
//                boost::optional<std::string> fp_interval = demand.getTimeLine().getInterval(*intentional);
//
//                //Update Demand timed data only if FP has ITOT or ILDT and any of them is in interval
//                if (fp_interval == interval)
//                {
//                    //In this case we don't have to update, former intentional will not store a value
//                    calculateTimedDemand(fp, former_intentional);
//                }
//            }
//        }
//    }
}



//------------------------------------------------------------------------------
///@todo FIXME RMAN code not yet used in the RTP: solve RTP required? auxiliar
//------------------------------------------------------------------------------

/// Borra de  LpdbDataBase::FPTable  todos los planes no contenidos en 'receivedFPKeys'
//void LpdBusinessLogicFacade::deleteNotReceivedFPs(vector<string> & receivedFPKeys)
//{
//    LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();
//    LpdbDemand & demandForecast = LpdbDataBase::Get().getDemand("");  // assertion fails
//
//    vector<string> allFlightPlansInDB = fpTable.getAllIds();
//
//    std::sort(allFlightPlansInDB.begin(), allFlightPlansInDB.end());
//    std::sort(receivedFPKeys.begin(), receivedFPKeys.end());
//
//    vector<string> fpsToDelete;
//    std::set_difference(allFlightPlansInDB.begin(), allFlightPlansInDB.end(), receivedFPKeys.begin(),
//                        receivedFPKeys.end(), back_inserter(fpsToDelete));
//
//    if (fpsToDelete.size() > 0)
//    {
//        for (unsigned int i = 0; i < fpsToDelete.size(); ++i)
//        {
//            //Delete also from demand forecast
//            std::string flightPlanKey = fpsToDelete[i];
//            LpiFlightPlan & fp = fpTable[flightPlanKey];
//
//            demandForecast.deleteFromForecast(fp);  /// borra 'fp' de la demanda (aeropuerto, intervalo)
//        }
//
//        fpTable.deleteElements(fpsToDelete);
//    }
//}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::reviewObsoleteFlightPlans(int minutes_threshold)
{
    //Iterate Through all FPs and delete data only if ITOT or ILDT is in given interval

//     LpdbDataBase::FPTable & fp_table = LpdbDataBase::Get().getFPTable();
//     vector<string> fp_keys = fp_table.getAllIds();

//     boost::posix_time::ptime now_timestamp = LctimVirtualClock::Get().getTime();

//     BOOST_FOREACH (string fp_key, fp_keys)
//     {
//         if (fp_table.exists(fp_key))
//         {
//             LpiFlightPlan fp = fp_table[fp_key];

//             boost::optional<posix_time::ptime> intentional = fp.getIntentionalTime();

//             if (intentional)
//             {
//                 if ((now_timestamp - *intentional).total_seconds() >= minutes_threshold * 60)
//                 {
// #ifdef TRACE_OUT
//                     LclogStream::instance(LclogConfig::E_RTP).debug() << "Deleting obsolete FP " << fp_key
//                     << ", intentional time= " << *intentional << std::endl;
// #endif

//                     fp_table.deleteElement(fp_key);
//                 }
//             }
//         }
//     }
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::reviewObsoleteFlightPlansByAssignedTime(int minutes_threshold)
{
//     LpdbDataBase::FPTable & fp_table = LpdbDataBase::Get().getFPTable();
//     vector<string> fp_keys = fp_table.getAllIds();

//     boost::posix_time::ptime now_timestamp = LctimVirtualClock::Get().getTime();

//     BOOST_FOREACH (string fp_key, fp_keys)
//     {
//         if (fp_table.exists(fp_key))
//         {
//             LpiFlightPlan fp = fp_table[fp_key];

//             boost::optional<posix_time::ptime> timeToCheck = boost::none;

//             //1 - Check deletion by assigned time
//             LpdbAlternativeSchedule & active = LpdbDataBase::Get().getActiveSchedule();

//             string timeTypeForLog;

//          if (active.isPlannedFP(fp_key))
//             {
//             timeToCheck = active.getAssignedTime(fp_key);
//                 timeTypeForLog = "assigned";
// #ifdef TRACE_OUT
//             /*
//             std::cout << "Checking time for scheduled FP in active: " << fp_key << "assignedTime = " << timeToCheck;
//             if (timeToCheck)
//             {
//                std::cout << " *assignedTime = " << *timeToCheck << std::endl;
//             }
//             */
// #endif
//             }
//             else
//             {
//                 //2 - Check deletion by intentional time
//                 timeToCheck = fp.getIntentionalTime();
//                 timeTypeForLog = "intentional";
//             }

//             if (timeToCheck)
//             {
// #ifdef TURN_ROUND
//                 //reviewTurnRound(fp_key);
// #endif
//                 if ((now_timestamp - *timeToCheck).total_seconds() >= minutes_threshold * 60)
//                 {
//                     LclogStream::instance(LclogConfig::E_RTP).debug() << "Deleting obsolete FP " << fp_key
//                                  << ", " << timeTypeForLog << " time= " << *timeToCheck << std::endl;

//                     fp_table.deleteElement(fp_key);
//                 }
//             }
//         }
//     }
}

//------------------------------------------------------------------------------

void LpdBusinessLogicFacade::reviewTurnRound(string fpKey)
{
    // LpdbDataBase::FPTable & fpTable = LpdbDataBase::Get().getFPTable();
    // boost::posix_time::ptime timeLineBegin = LpdbDataBase::Get().getTimeLineBase();

    // if (fpTable.exists(fpKey))
    // {
    //     LpiFlightPlan & fp = fpTable[fpKey];

    //     if ((fp.getOperationType() == LpiOperationType::E_ARRIVAL) && (fp.getTurnRoundKey() != ""))
    //     {
    //         boost::optional<posix_time::ptime> fpIldt = fp.getArrivalTimes().getIldt();

    //         if (fpIldt && (*fpIldt < timeLineBegin))
    //         {
    //             string associatedDEPFP = fp.getTurnRoundKey();
    //             LpiFlightPlan & associatedFP = fpTable[fpKey];

    //             fp.setTurnRoundKey("");
    //             fp.setClosedTurnRound(false);

    //             associatedFP.setTurnRoundKey("");
    //             associatedFP.setClosedTurnRound(false);
    //         }
    //     }
    // }
}



//------------------------------------------------------------------------------

