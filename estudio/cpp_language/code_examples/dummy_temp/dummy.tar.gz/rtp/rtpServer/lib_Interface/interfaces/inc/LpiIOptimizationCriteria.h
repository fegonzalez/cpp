#if !defined(__LPI_I_OPTIMIZATIONCRITERIA__)

#define __LPI_I_OPTIMIZATIONCRITERIA__

#include "LpiOptimizationCriteria.h"

class LpiIOptimizationCriteria
{
public:
   virtual ~LpiIOptimizationCriteria() {}
   virtual void getOptimizationCriteria(const LpiOptimizationCriteria &optimizationCriteria) = 0;
};

#endif // __LPI_I_OPTIMIZATIONCRITERIA__
