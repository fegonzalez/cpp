#if !defined(__LPI_I_EVENT_CONSUMERS__)
#define __LPI_I_EVENT_CONSUMERS__

#include "LpiEvents.h"
#include "LpiIEventConsumer.h"


typedef LpiIEventConsumer<
   LpiUpdateSystemTimeEvt
> LpiIUpdateSystemTimeEvtConsumer;


typedef LpiIEventConsumer<
   LpiManualEditionEvt
> LpiIGenerateManualScheduleEvtConsumer;

typedef LpiIEventConsumer<
   LpiScheduleDeleteEvt
> LpiIScheduleDeleteEvtConsumer;


typedef LpiIEventConsumer<
   LpiSchedulesComparisonEvt
> LpiISchedulesComparisonEvtConsumer;


typedef LpiIEventConsumer<
   LpiWhatIfRunwayClosureEvt
> LpiIWhatIfRunwayClosureEvtConsumer;

#endif // __LPI_I_EVENT_CONSUMERS__
