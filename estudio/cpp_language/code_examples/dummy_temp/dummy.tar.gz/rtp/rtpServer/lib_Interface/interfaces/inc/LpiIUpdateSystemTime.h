#if !defined(__LPIIUPDATESYSTEMTIME__)
#define __LPIIUPDATESYSTEMTIME__

#include "LpiTime.h"

class LpiIUpdateSystemTime
{
public:
   virtual ~LpiIUpdateSystemTime() {}
   virtual void updateSystemTime(const LpiTime &time) = 0;
};

#endif // __LPIIUPDATESYSTEMTIME__
