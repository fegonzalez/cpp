/*
 * LpiIGetAdaptationAirportsInfo.h
 *
 */

#ifndef LPIIGETADAPTATIONMRTMSINFO_H_
#define LPIIGETADAPTATIONMRTMSINFO_H_

#include "LpiAdaptationMrtmInfo.h"
#include "LpiResult.h"


class LpiIGetAdaptationMrtmInfo
{
public:
   virtual ~LpiIGetAdaptationMrtmInfo() {}
   virtual void getAdaptationMrtmInfo(LpiAdaptationMrtmInfo &amrtmInfo,
                                            LpiResult        &result) = 0;
};


#endif /* LPIIGETADAPTATIONAIRPORTSINFO_H_ */
