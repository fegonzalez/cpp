#if !defined(__LPI_EVENT_DELEGATE_PUBLISHER_IMPL__)
#define __LPI_EVENT_DELEGATE_PUBLISHER_IMPL__

template<typename TEvent>
class LpiEventDelegatePublisherImpl : public LpiIEventDelegatePublisher<TEvent >
{
public:
   LpiEventDelegatePublisherImpl() {}
   virtual ~LpiEventDelegatePublisherImpl() {}

   virtual void delegatePublisher(LpiIEventPublisher<TEvent> &delegate)
   {
      this->_pDelegate = &delegate;
   }

   virtual void publish(const TEvent &data)
   {
      this->_pDelegate->publish(data);
   }

private:
   LpiIEventPublisher<TEvent> *_pDelegate;
};

#endif // __LPI_EVENT_DELEGATE_PUBLISHER_IMPL__
