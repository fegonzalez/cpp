#if !defined(__LPI_CONSUMERS__)
#define __LPI_CONSUMERS__

#include "LpiIEventConsumers.h"

#endif // __LPI_CONSUMERS__
