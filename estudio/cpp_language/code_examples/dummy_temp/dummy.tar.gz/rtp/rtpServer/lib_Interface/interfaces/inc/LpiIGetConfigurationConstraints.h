/*
 * LpiIGetConfigurationConstraints.h
 *
 */

#ifndef LPIIGETCONFIGURATIONCONSTRAINTS_H_
#define LPIIGETCONFIGURATIONCONSTRAINTS_H_

#include "LpiConfigurationConstraints.h"
#include "LpiResult.h"

class LpiIGetConfigurationConstraints
{
public:
   virtual ~LpiIGetConfigurationConstraints() {}
   virtual void getConfigurationConstraints(LpiConfigurationConstraints &parameters,
                                            LpiResult        &result) = 0;
};



#endif /* LPIIGETCONFIGURATIONCONSTRAINTS_H_ */
