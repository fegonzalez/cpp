// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 21 Jun 11:07:48 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIIGETADAPTATIONASSIGNMENTPREFERENCE_H_
#define LPIIGETADAPTATIONASSIGNMENTPREFERENCE_H_

#include "LpiAdaptationAssignmentPreference.h"
#include "LpiResult.h"

class LpiIGetAdaptationAssignmentPreference
{
public:
    virtual ~LpiIGetAdaptationAssignmentPreference() {}
    virtual void getAdaptationAssignmentPreference(LpiAdaptationAssignmentPreference &assPref,
                                                   LpiResult & result) = 0;
};

#endif /* LPIIGETADAPTATIONASSIGNMENTPREFERENCE_H_ */
