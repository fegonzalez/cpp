#if !defined(__LPI_I_CALCULATE_RUNWAY_MAX_CAPACITY_H__)
#define __LPI_I_CALCULATE_RUNWAY_MAX_CAPACITY_H__

#include <string>

class LpiICalculateRunwayMaxCapacity
{
public:
   LpiICalculateRunwayMaxCapacity() {}
   virtual ~LpiICalculateRunwayMaxCapacity() {}

   virtual void calculateRunwayMaxCapacity(void) = 0;
   virtual void calculateRunwayMaxCapacity(std::string) = 0;

};

#endif // __LPI_I_CALCULATE_RUNWAY_MAX_CAPACITY_H__
