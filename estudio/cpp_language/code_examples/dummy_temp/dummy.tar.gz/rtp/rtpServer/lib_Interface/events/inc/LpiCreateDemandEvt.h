#if !defined(__LPI_CREATE_DEMAND_EVT__)
#define __LPI_CREATE_DEMAND_EVT__

#include <LpiFlightPlan.h>

class LpiCreateDemandEvt
{
public:
   const LpiCreateDemandList & getCreateDemand(void) const {return this->_demand;}
   void setCreateDemand(LpiCreateDemandList &demand) {_demand = demand;}
private:
   LpiCreateDemandList _demand;
};

#endif // __LPI_CREATE_DEMAND_EVT__
