#if !defined(__LPIUPDATEASYSTEMTIMEEVT__)
#define __LPIUPDATEASYSTEMTIMEEVT__

#include <LpiTime.h>

class LpiUpdateSystemTimeEvt
{
public:
   const LpiTime& getSystemTime(void) const
      {return this->_time;}
   void setSystemTime(const LpiTime &value)
      {this->_time = value;}

private:
   LpiTime _time;
};

#endif // __LPIUPDATEASYSTEMTIMEEVT__
