#if !defined(__LPI_OPTIMAL_SCHEDULE_EVT__)
#define __LPI_OPTIMAL_SCHEDULE_EVT__

#include <LpiSchedule.h>


class LpiOptimalScheduleEvt
{
   public:
      const LpiSchedule & getSchedule (void) const
      { return this->_schedule; }

      void setSchedule (const LpiSchedule & schedule)
      { this->_schedule = schedule;}

   private:
      LpiSchedule _schedule;
};


#endif // __LPI_OPTIMAL_SCHEDULE_EVT__
