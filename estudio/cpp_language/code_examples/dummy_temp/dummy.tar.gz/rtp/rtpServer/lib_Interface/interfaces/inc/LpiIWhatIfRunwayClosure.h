#ifndef __LPI_I_WHATIF_RUNWAYCLOSURES__
#define __LPI_I_WHATIF_RUNWAYCLOSURES__

#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiWhatIfClosure.h"

class LpiIWhatIfRunwayClosures
{
   public:
      virtual ~LpiIWhatIfRunwayClosures() {}

      virtual void generateWhatIfClosuresforActive(const LpiWhatIfClosure & closures) = 0;
      virtual void generateWhatIfClosuresforOptimal(const LpiWhatIfClosure & closures) = 0;

      virtual void setExpirationDateForWhatIfs(boost::posix_time::ptime expirationDate,
                                               int idWhatIfToExclude = -1) = 0;
};

#endif // __LPI_I_WHATIF_RUNWAYCLOSURES__
