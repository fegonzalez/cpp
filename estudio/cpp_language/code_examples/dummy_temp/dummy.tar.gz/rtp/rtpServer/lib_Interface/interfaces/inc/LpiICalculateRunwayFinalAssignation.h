#if !defined(__LPI_I_CALCULATE_RUNWAY_FINAL_ASSIGNATION_H__)
#define __LPI_I_CALCULATE_RUNWAY_FINAL_ASSIGNATION_H__

class LpiICalculateRunwayFinalAssignation
{
public:
   LpiICalculateRunwayFinalAssignation() {}
   virtual ~LpiICalculateRunwayFinalAssignation() {}

   virtual void calculateRunwayFinalAssignation(void) = 0;
   virtual void calculateRunwayFinalAssignation(std::string) = 0;
};

#endif // __LPI_I_CALCULATE_RUNWAY_FINAL_ASSIGNATION_H__
