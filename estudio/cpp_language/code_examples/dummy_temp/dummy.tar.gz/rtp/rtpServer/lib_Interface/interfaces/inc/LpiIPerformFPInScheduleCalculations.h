#if !defined(__LPI_I_PERFORM_FP_SCHEDULE_CALCULATIONS_H__)
#define __LPI_I_PERFORM_FP_SCHEDULE_CALCULATIONS_H__

class LpiIPerformFPInScheduleCalculations
{
   public:
      LpiIPerformFPInScheduleCalculations() {}
      virtual ~LpiIPerformFPInScheduleCalculations() {}

      virtual void performFPInScheduleCalculations() = 0;
};


#endif // __LPI_I_PERFORM_FP_SCHEDULE_CALCULATIONS_H__
