/*
 * LpiDefaultScheduleEvt.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPIDEFAULTSCHEDULEEVT_H_
#define LPIDEFAULTSCHEDULEEVT_H_
#include <string>
#include <vector>

//#include <LpiDefaultSchedule.h>

class LpiDefaultScheduleEvt
{
public:
   const std::vector<std::vector<std::string>> & getDefaultSchedule(void) const {return this->_defaultSchedule;}
   void setDefaultSchedule(const std::vector<std::vector<std::string>> &defSchedule) {this->_defaultSchedule = defSchedule;}
private:
   std::vector<std::vector<std::string>> _defaultSchedule;
};



#endif /* LPIDEFAULTSCHEDULEEVT_H_ */
