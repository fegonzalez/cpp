#ifndef __LPI_SCHEDULE_DELETE_EVT__
#define __LPI_SCHEDULE_DELETE_EVT__

class LpiScheduleDeleteEvt
{
   public:

      int getScheduleId(void) const
      { return r_schedule_id; }

      void setManualSchedule(int scheduleId)
      { r_schedule_id = scheduleId; }

   private:

      int r_schedule_id;
};

#endif // __LPI_SCHEDULE_DELETE_EVT__
