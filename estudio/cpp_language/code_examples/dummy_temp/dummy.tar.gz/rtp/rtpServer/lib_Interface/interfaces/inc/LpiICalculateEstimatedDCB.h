#if !defined(__LPI_I_CALCULATE_ESTIMATED_DCB_H__)
#define __LPI_I_CALCULATE_ESTIMATED_DCB_H__

class LpiICalculateEstimatedDCB
{
public:
   LpiICalculateEstimatedDCB() {}
   virtual ~LpiICalculateEstimatedDCB() {}

   virtual void calculateEstimatedDCB(void) = 0;
   virtual void calculateEstimatedDCB(std::string) = 0;

};

#endif // __LPI_I_CALCULATE_ESTIMATED_DCB_H__
