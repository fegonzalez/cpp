#if !defined(__LPI_I_CAPACITYREDUCTIONS__)

#define __LPI_I_CAPACITYREDUCTIONS__

#include "LpiCapacityReductions.h"

class LpiICapacityReductions
{
public:
   virtual ~LpiICapacityReductions() {}
   virtual void getCapacityReductions(const LpiCapacityReductions &capacityReductions) = 0;
};

#endif // __LPI_I_CAPACITYREDUCTIONS__
