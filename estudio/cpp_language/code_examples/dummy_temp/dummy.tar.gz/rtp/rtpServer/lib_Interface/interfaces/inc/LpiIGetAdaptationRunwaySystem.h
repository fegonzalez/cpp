/*
 * LpiIGetAdaptationRunwaySystem.h
 *
 */

#ifndef LPIIGETADAPTATIONRUNWAYSYSTEM_H_
#define LPIIGETADAPTATIONRUNWAYSYSTEM_H_

#include "LpiAdaptationRunwaySystem.h"
#include "LpiResult.h"

class LpiIGetAdaptationRunwaySystem
{
public:
   virtual ~LpiIGetAdaptationRunwaySystem() {}
   virtual void getAdaptationRunwaySystem(LpiAdaptationRunwaySystemList &runwaySystem,
                                          LpiResult        &result) = 0;
};



#endif /* LPIIGETADAPTATIONRUNWAYSYSTEM_H_ */
