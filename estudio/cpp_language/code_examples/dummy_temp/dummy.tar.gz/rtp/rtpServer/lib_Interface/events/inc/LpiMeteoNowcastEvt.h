#if !defined(__LPI_METEO_NOW_CAST_EVT__)
#define __LPI_METEO_NOW_CAST_EVT__

#include <LpiMeteoInfo.h>

class LpiMeteoNowcastEvt
{
public:
   const LpiCreateMeteoList & getMeteoNowcast(void) const {return this->_meteolist;}
   void setMeteoNowcast(const LpiCreateMeteoList &meteo) {this->_meteolist = meteo;}
private:
   LpiCreateMeteoList _meteolist;
};

#endif // __LPI_METEO_NOW_CAST_EVT__
