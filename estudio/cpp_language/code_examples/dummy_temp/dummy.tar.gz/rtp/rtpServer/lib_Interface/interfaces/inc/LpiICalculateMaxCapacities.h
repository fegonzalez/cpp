#if !defined(__LPI_I_CALCULATE_MAX_CAPACITIES_H__)
#define __LPI_I_CALCULATE_MAX_CAPACITIES_H__

class LpiICalculateMaxCapacities
{
   public:

      LpiICalculateMaxCapacities() {}
      virtual ~LpiICalculateMaxCapacities() {}

      virtual void calculateMaxCapacities(void) = 0;
      //virtual void calculateRunwayAndRSMaxCapacities() = 0;

      //virtual void calculateAirportMaxCapacitiesAndMinDelayedFPs() = 0;
      //virtual void calculatePriorityOperation(string interval) = 0;
      //virtual void calculateAirportMaxCapacitiesForAllRS(const string &) = 0;
      //virtual void calculateMinDelayedFPs(const string &) = 0;
};

#endif // __LPI_I_CALCULATE_MAX_CAPACITIES_H__
