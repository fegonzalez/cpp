#if !defined(__LPI_I_DELEGATE_PUBLISHER__)
#define __LPI_I_DELEGATE_PUBLISHER__

template<typename TDelegate>
class LpiIDelegatePublisher
{
public:
   LpiIDelegatePublisher() {}
   virtual ~LpiIDelegatePublisher() {}
   virtual void delegatePublisher(TDelegate &data) = 0;
};

#endif // __LPI_I_DELEGATE_PUBLISHER__
