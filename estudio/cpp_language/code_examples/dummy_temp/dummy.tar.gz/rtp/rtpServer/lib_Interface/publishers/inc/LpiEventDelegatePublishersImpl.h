#if !defined(__LPI_EVENT_DELEGATE_PUBLISHERS_IMPL__)
#define __LPI_EVENT_DELEGATE_PUBLISHERS_IMPL__

#include "LpiEventDelegatePublisherImpl.h"
#include "LpiEvents.h"

typedef LpiEventDelegatePublisherImpl<
   LpiOptimalScheduleEvt
> LpiOptimalScheduleEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiMeteoForecastEvt
> LpiMeteoForecastEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiMeteoNowcastEvt
> LpiMeteoNowcastEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiUpdateDemandEvt
> LpiDemandEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiOptimalCriteriaEvt
> LpiOptimalCriteriaEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiActiveScheduleEvt
> LpiActiveScheduleEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiAlternativeScheduleEvt
> LpiAlternativeScheduleEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
   LpiSchedulesComparisonResponseEvt
> LpiSchedulesComparisonResponseEvtDelegatePublisher;

typedef LpiEventDelegatePublisherImpl<
      LpiAutomaticDeletionEvt
> LpiAutomaticDeletionEvtDelegatePublisher;

#endif // __LPI_EVENT_DELEGATE_PUBLISHERS_IMPL__
