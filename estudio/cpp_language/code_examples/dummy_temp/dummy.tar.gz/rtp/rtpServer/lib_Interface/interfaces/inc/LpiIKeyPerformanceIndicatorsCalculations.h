#if !defined(__LPI_I_KEY_PERFORMANCE_INDICATORS_CALCULATIONS_H__)
#define __LPI_I_KEY_PERFORMANCE_INDICATORS_CALCULATIONS_H__


class LpiIKeyPerformanceIndicatorsCalculations
{
   public:
      LpiIKeyPerformanceIndicatorsCalculations() {}
      virtual ~LpiIKeyPerformanceIndicatorsCalculations() {}

      virtual void calculateSchedulesKPIs(bool isClockForwarding, bool isInitialization = false) = 0;
};

#endif // __LPI_I_KEY_PERFORMANCE_CALCULATIONS_H__
