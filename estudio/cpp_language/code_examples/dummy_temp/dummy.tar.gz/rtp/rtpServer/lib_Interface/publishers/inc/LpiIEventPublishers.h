#if !defined(__LPI_EVENT_PUBLISHERS__)
#define __LPI_EVENT_PUBLISHERS__

#include "LpiIEventPublisher.h"
#include "LpiEvents.h"


typedef LpiIEventPublisher<
   LpiOptimalScheduleEvt
> LpiIOptimalScheduleEvtPublisher;

typedef LpiIEventPublisher<
  LpiMeteoForecastEvt
> LpiIMeteoForecastEvtPublisher;

typedef LpiIEventPublisher<
  LpiMeteoNowcastEvt
> LpiIMeteoNowcastEvtPublisher;

typedef LpiIEventPublisher<
   LpiUpdateDemandEvt
> LpiIDemandEvtPublisher;

typedef LpiIEventPublisher<
   LpiOptimalCriteriaEvt
> LpiIOptimalCriteriaEvtPublisher;

typedef LpiIEventPublisher<
   LpiActiveScheduleEvt
> LpiIActiveScheduleEvtPublisher;

typedef LpiIEventPublisher<
   LpiAlternativeScheduleEvt
> LpiIAlternativeScheduleEvtPublisher;

typedef LpiIEventPublisher<
   LpiSchedulesComparisonResponseEvt
> LpiISchedulesComparisonResponseEvtPublisher;

typedef LpiIEventPublisher<
   LpiSchedulesComparisonResponseEvt
> LpiISchedulesComparisonResponseEvtPublisher;

typedef LpiIEventPublisher<
   LpiSchedulesComparisonResponseEvt
> LpiISchedulesComparisonResponseEvtPublisher;

typedef LpiIEventPublisher<
   LpiAutomaticDeletionEvt
> LpiIAutomaticDeletionEvtPublisher;

#endif // __LPI_EVENT_PUBLISHERS__
