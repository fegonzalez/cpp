#if !defined(__LPI_I_CALCULATE_REAL_DCB_RUNWAY_ALLOCATION_H__)
#define __LPI_I_CALCULATE_REAL_DCB_RUNWAY_ALLOCATION_H__

class LpiICalculateRealDCBAndRunwayAllocation
{
public:
   LpiICalculateRealDCBAndRunwayAllocation() {}
   virtual ~LpiICalculateRealDCBAndRunwayAllocation() {}

   virtual void calculateRealDCBAndRunwayAllocation(void) = 0;
   virtual void calculateActiveRealDCBAndRunwayAllocation(void) = 0;
   virtual void calculateRealDCBAndRunwayAllocation(std::string) = 0;

};

#endif // __LPI_I_CALCULATE_REAL_DCB_RUNWAY_ALLOCATION_H__
