#if !defined(__LPIIGETSYSTEMTIME__)
#define __LPIIGETSYSTEMTIME__

#include "LpiTime.h"
#include "LpiResult.h"

class LpiIGetSystemTime
{
public:
   virtual ~LpiIGetSystemTime() {}
   virtual void getSystemTime(LpiTime &tick, LpiResult &result) = 0;
};

#endif // __LPIIGETSYSTEMTIME__
