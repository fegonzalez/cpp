#if !defined(__LPI_I_PERFORM_ACTIVE_SCHEDULE_CALCULATIONS_H__)
#define __LPI_I_PERFORM_ACTIVE_SCHEDULE_CALCULATIONS_H__

#include "LpiCalculationReason.h"

class LpiIPerformActiveScheduleCalculations
{
   public:
      LpiIPerformActiveScheduleCalculations() {}
      virtual ~LpiIPerformActiveScheduleCalculations() {}

      virtual void performActiveScheduleCalculations(bool isClockForwarding, bool isInitialization = false) = 0;
};

#endif // __LPI_I_PERFORM_ACTIVE_SCHEDULE_CALCULATIONS_H__
