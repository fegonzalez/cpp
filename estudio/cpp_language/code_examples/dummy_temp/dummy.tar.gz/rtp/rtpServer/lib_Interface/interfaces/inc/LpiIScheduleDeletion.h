#if !defined(__LPI_I_SCHEDULE_DELETION__)
#define __LPI_I_SCHEDULE_DELETION__


class LpiIScheduleDeletion
{
   public:
      virtual ~LpiIScheduleDeletion() {}
      virtual void deleteSchedule(int scheduleId) = 0;
};

#endif // __LPI_I_SCHEDULE_DELETION__
