#if !defined(__LPI_SCHEDULE_ACTIVATION_EVT__)
#define __LPI_SCHEDULE_ACTIVATION_EVT__

#include <LpiScheduleActivation.h>

class LpiScheduleActivationEvt
{
public:
   const LpiScheduleActivation& getScheduleActivation(void) const {return this->scheduleActivation;}
   void setScheduleActivation(const LpiScheduleActivation &_scheduleActivation)
      {this->scheduleActivation= _scheduleActivation;}
private:
   LpiScheduleActivation scheduleActivation;
};

#endif //__LPI_SCHEDULE_ACTIVATION_EVT__
