#ifndef __LPI_ALTERNATIVE_SCHEDULE_EVT__
#define __LPI_ALTERNATIVE_SCHEDULE_EVT__


#include <vector>
#include <LpiRunwayClosure.h>
#include <LpiAlternativeSchedule.h>

using std::vector;


class LpiAlternativeScheduleEvt
{
   public:

      LpiAlternativeSchedule getAlternativeSchedule (void) const
      { return r_alternativeSchedule; }

      void setAlternativeSchedule(const LpiAlternativeSchedule & altSchedule)
      { r_alternativeSchedule = altSchedule; }

      const vector<LpiRunwayClosure> getClosures() const
      { return r_runwayClosures; }

      void setClosures(const vector<LpiRunwayClosure> & closures)
      { r_runwayClosures = closures; }

      void addClosure (const LpiRunwayClosure & closure)
      { r_runwayClosures.push_back(closure); }

   private:

      LpiAlternativeSchedule r_alternativeSchedule;
      vector<LpiRunwayClosure> r_runwayClosures;
};


#endif //__LPI_ALTERNATIVE_SCHEDULE_EVT__
