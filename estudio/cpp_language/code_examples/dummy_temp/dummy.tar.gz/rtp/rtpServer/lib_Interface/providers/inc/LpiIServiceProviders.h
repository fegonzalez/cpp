#if !defined(__LPI_I_SERVICE_PROVIDERS__)
#define __LPI_I_SERVICE_PROVIDERS__

#include "LpiIServiceProvider.h"
#include "LpiRequests.h"
#include "LpiReplies.h"


#endif // __LPI_I_SERVICE_PROVIDERS__
