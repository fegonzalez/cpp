#ifndef __LPI_MANUAL_EDITION_EVT__
#define __LPI_MANUAL_EDITION_EVT__

#include <LpiAlternativeSchedule.h>

class LpiManualEditionEvt
{
public:

   LpiAlternativeSchedule getManualSchedule(void) const
   { return r_manual_schedule; }

   void setManualSchedule(const LpiAlternativeSchedule & manualSchedule)
   { r_manual_schedule = manualSchedule; }

private:

   LpiAlternativeSchedule r_manual_schedule;
};

#endif // __LPI_MANUAL_EDITION_EVT__
