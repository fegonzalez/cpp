#if !defined(__LPI_SCHEDULES_COMPARISON_EVT__)
#define __LPI_SCHEDULES_COMPARISON_EVT__

#include <LpiSchedulesComparison.h>


class LpiSchedulesComparisonEvt
{
   public:

      const LpiSchedulesComparison & getSchedulesComparison (void) const
      { return this->r_schedulesComparison; }

      void setSchedulesComparison (const LpiSchedulesComparison & comparisonData)
      { this->r_schedulesComparison = comparisonData; }

   private:

      LpiSchedulesComparison r_schedulesComparison;
};


class LpiSchedulesComparisonResponseEvt
{
   public:

      const LpiSchedulesComparisonResponse & getSchedulesComparisonResponse (void) const
      { return this->r_schedulesComparisonResponse; }

      void setSchedulesComparisonResponse (const LpiSchedulesComparisonResponse & comparisonData)
      { this->r_schedulesComparisonResponse = comparisonData; }

   private:

      LpiSchedulesComparisonResponse r_schedulesComparisonResponse;
};

#endif // __LPI_SCHEDULES_COMPARISON_EVT__
