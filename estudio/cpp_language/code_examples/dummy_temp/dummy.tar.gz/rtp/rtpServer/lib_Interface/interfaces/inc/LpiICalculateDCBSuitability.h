#if !defined(__LPI_I_CALCULATE_DCB_SUITABILITY_H__)
#define __LPI_I_CALCULATE_DCB_SUITABILITY_H__

class LpiICalculateDCBSuitability
{
public:
   LpiICalculateDCBSuitability() {}
   virtual ~LpiICalculateDCBSuitability() {}

   virtual void calculateDCBSuitability(void) = 0;

};

#endif // __LPI_I_CALCULATE_DCB_SUITABILITY_H__
