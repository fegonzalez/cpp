#if !defined(__LPI_I_SCHEDULE_ACTIVATION_H__)
#define __LPI_I_SCHEDULE_ACTIVATION_H__

#include "LpiScheduleActivationType.h"

class LpiIScheduleActivation
{
public:
   LpiIScheduleActivation () {}
   virtual ~LpiIScheduleActivation () {}


};

#endif // __LPI_I_SCHEDULE_ACTIVATION_H__
