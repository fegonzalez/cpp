#if !defined(__LPI_I_CALCULATE_RUNWAY_ALLOCATION_H__)
#define __LPI_I_CALCULATE_RUNWAY_ALLOCATION_H__

class LpiICalculateRunwayAllocation
{
public:
   LpiICalculateRunwayAllocation() {}
   virtual ~LpiICalculateRunwayAllocation() {}

   virtual void calculateRunwayAllocation(void) = 0;
   virtual void calculateRunwayAllocation(std::string) = 0;

};

#endif // __LPI_I_CALCULATE_RUNWAY_ALLOCATION_H__
