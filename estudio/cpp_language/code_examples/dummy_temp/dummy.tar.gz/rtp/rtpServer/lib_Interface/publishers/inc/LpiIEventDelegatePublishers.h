#if !defined(__LPI_EVENT_DELEGATE_PUBLISHERS__)
#define __LPI_EVENT_DELEGATE_PUBLISHERS__

#include "LpiIEventDelegatePublisher.h"
#include "LpiEvents.h"

typedef LpiIEventDelegatePublisher<
   LpiOptimalScheduleEvt
> LpiIOptimalScheduleEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
   LpiMeteoForecastEvt
>LpiIMeteoForecastEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
   LpiMeteoNowcastEvt
>LpiIMeteoNowcastEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
    LpiUpdateDemandEvt
>LpiIDemandEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
   LpiOptimalCriteriaEvt
> LpiIOptimalCriteriaEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
   LpiActiveScheduleEvt
> LpiIActiveScheduleEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
   LpiSchedulesComparisonResponseEvt
> LpiISchedulesComparisonResponseEvtDelegatePublisher;

typedef LpiIEventDelegatePublisher<
   LpiAutomaticDeletionEvt
> LpiIAutomaticDeletionEvtDelegatePublisher;

#endif // __LPI_EVENT_DELEGATE_PUBLISHERS__
