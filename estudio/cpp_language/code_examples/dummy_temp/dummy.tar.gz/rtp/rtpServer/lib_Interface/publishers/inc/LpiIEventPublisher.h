#if !defined(__LPI_EVENT_PUBLISHER__)
#define __LPI_EVENT_PUBLISHER__

template<typename TEvent>
class LpiIEventPublisher
{
public:
   LpiIEventPublisher() {}
   virtual ~LpiIEventPublisher() {}
   virtual void publish(const TEvent &data) = 0;
};

#endif // __LPI_EVENT_PUBLISHER__
