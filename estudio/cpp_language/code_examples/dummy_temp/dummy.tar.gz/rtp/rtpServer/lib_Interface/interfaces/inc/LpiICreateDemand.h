#if !defined(__LPI_I_CREATEDEMAND__)
#define __LPI_I_CREATEDEMAND__

#include "LpiFlightPlan.h"

class LpiICreateDemand
{
public:
   virtual ~LpiICreateDemand() {}
   virtual void getCreateDemand(const LpiCreateDemand &fp) = 0;
};

#endif // __LPI_I_CREATEDEMAND__
