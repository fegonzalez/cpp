#if !defined(__LPI_I_GENERATE_MANUAL_SCHEDULE__)
#define __LPI_I_GENERATE_MANUAL_SCHEDULE__

#include "LpiAlternativeSchedule.h"

class LpiIGenerateManualSchedule
{
public:
   virtual ~LpiIGenerateManualSchedule() {}
   virtual void generateManualSchedule(const LpiAlternativeSchedule & manualSchedule) = 0;
};

#endif // __LPI_I_GENERATE_MANUAL_SCHEDULE__
