#if !defined(__LPI_METEO_FORECAST_EVT__)
#define __LPI_METEO_FORECAST_EVT__

#include <LpiMeteoInfo.h>

class LpiMeteoForecastEvt
{
public:
   const LpiCreateMeteoList & getMeteoForecast(void) const {return this->_meteolist;}
   void setMeteoForecast(const LpiCreateMeteoList &meteo) {this->_meteolist = meteo;}
private:
   LpiCreateMeteoList _meteolist;
};

#endif // __LPI_METEO_FORECAST_EVT__
