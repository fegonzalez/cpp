#if !defined(__LPI_UPDATE_DEMAND_EVT__)
#define __LPI_UPDATE_DEMAND_EVT__

#include <LpiDemand.h>
#include <LpiFlightPlan.h>

class LpiUpdateDemandEvt
{
public:
   const LpiUpdateDemandList& getDemand(void) const {return this->_demand;}
   void setDemand(const LpiUpdateDemandList &demand) {this->_demand = demand;}
private:
   LpiUpdateDemandList _demand;
};

#endif // __LPI_UPDATE_DEMAND_EVT__
