#ifndef __LPI_WHATIF_RUNWAYCLOSURE_EVT__
#define __LPI_WHATIF_RUNWAYCLOSURE_EVT__

#include <LpiWhatIfClosure.h>

class LpiWhatIfRunwayClosureEvt
{
   public:

      LpiWhatIfClosure getClosures(void) const
      { return r_closures; }

      void setClosures(const LpiWhatIfClosure & closures)
      { r_closures = closures; }

   private:

      LpiWhatIfClosure r_closures;
};

#endif // __LPI_WHATIF_RUNWAYCLOSURE_EVT__
