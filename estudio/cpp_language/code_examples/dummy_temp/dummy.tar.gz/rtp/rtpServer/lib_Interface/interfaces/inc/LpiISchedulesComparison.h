#if !defined(__LPI_I_SCHEDULES_COMPARISON__)
#define __LPI_I_SCHEDULES_COMPARISON__

#include "LpiSchedulesComparison.h"

class LpiISchedulesComparison
{
   public:
      virtual ~LpiISchedulesComparison() {}
      virtual void compareSchedules(const LpiSchedulesComparison & schedulesToCompare) = 0;
};

#endif // __LPI_I_SCHEDULES_COMPARISON__
