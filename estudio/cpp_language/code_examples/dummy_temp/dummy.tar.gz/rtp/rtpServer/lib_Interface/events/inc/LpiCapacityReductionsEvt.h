#if !defined(__LPI_CAPACITY_REDUCTIONS_EVT__)
#define __LPI_CAPACITY_REDUCTIONS_EVT__

#include <LpiCapacityReductions.h>

class LpiCapacityReductionsEvt
{
public:
   const LpiCapacityReductions& getCapacityReductions(void) const {return this->capacityReductions;}
   void setCapacityReductions(const LpiCapacityReductions &_capacityReductions)
      {this->capacityReductions= _capacityReductions;}
private:
   LpiCapacityReductions capacityReductions;
};

#endif // __LPI_CAPACITY_REDUCTIONS_EVT__
