/*
 * LpiIGetFileCapacityReductions.h
 *
 */

#ifndef LPIIGETFILECAPACITYREDUCTIONS_H_
#define LPIIGETFILECAPACITYREDUCTIONS_H_

#include "LpiFileCapacityReductions.h"
#include "LpiResult.h"

class LpiIGetFileCapacityReductions
{
public:
   virtual ~LpiIGetFileCapacityReductions() {}
   virtual void getFileCapacityReductions(LpiFileCapacityReductions &runways,
                                          LpiResult        &result) = 0;
};



#endif /* LPIIGETFILECAPACITYREDUCTIONS_H_ */
