// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 16:04:37 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIIGETCONFIGURATIONHMIPARAMETERS_H_
#define LPIIGETCONFIGURATIONHMIPARAMETERS_H_


#include "LpiConfigurationHmiParameters.h"
#include "LpiResult.h"

class LpiIGetConfigurationHmiParameters
{
public:
   virtual ~LpiIGetConfigurationHmiParameters() {}
   virtual void getConfigurationHmiParameters(LpiConfigurationHmiParameters &parameters,
                                            LpiResult        &result) = 0;
};


#endif /* LPIIGETCONFIGURATIONHMIPARAMETERS_H_ */
