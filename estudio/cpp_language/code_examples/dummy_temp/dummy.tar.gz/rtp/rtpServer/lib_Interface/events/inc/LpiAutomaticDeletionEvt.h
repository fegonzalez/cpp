#ifndef __LPI_AUTOMATIC_DELETION_EVT__
#define __LPI_AUTOMATIC_DELETION_EVT__

#include <vector>

class LpiAutomaticDeletionEvt
{
   public:

      const std::vector<int> & getDeletedScheduleIds() const
      { return r_deletedScheduleIds; }


      void setDeletedScheduleIds(const std::vector<int> & idList)
      { r_deletedScheduleIds = idList; }

   private:

      std::vector<int> r_deletedScheduleIds;
};


#endif //__LPI_ALTERNATIVE_SCHEDULE_EVT__
