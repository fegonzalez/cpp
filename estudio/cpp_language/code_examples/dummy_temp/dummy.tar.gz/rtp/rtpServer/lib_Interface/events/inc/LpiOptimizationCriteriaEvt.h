#if !defined(__LPI_OPTIMIZATION_CRITERIA_EVT__)
#define __LPI_OPTIMIZATION_CRITERIA_EVT__

#include <LpiOptimizationCriteria.h>

class LpiOptimizationCriteriaEvt
{
public:

   const LpiOptimizationCriteria & getOptimizationCriteria(void) const
   { return this->r_optimizationCriteria; }

   void setOptimizationCriteria(const LpiOptimizationCriteria & _optimizationCriteria)
   { this->r_optimizationCriteria = _optimizationCriteria; }

private:

   LpiOptimizationCriteria r_optimizationCriteria;
};

#endif // __LPI_CREATE_DEMAND_EVT__
