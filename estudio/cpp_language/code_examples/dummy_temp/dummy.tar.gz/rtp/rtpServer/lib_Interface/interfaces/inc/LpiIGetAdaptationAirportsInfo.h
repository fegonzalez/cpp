/*
 * LpiIGetAdaptationAirportsInfo.h
 *
 */

#ifndef LPIIGETADAPTATIONAIRPORTSINFO_H_
#define LPIIGETADAPTATIONAIRPORTSINFO_H_

#include "LpiAdaptationAirportsInfo.h"
#include "LpiResult.h"


class LpiIGetAdaptationAirportsInfo
{
public:
   virtual ~LpiIGetAdaptationAirportsInfo() {}
   virtual void getAdaptationAirportsInfo(LpiAdaptationAirportsInfo &airportsInfo,
                                            LpiResult        &result) = 0;
};


#endif /* LPIIGETADAPTATIONAIRPORTSINFO_H_ */
