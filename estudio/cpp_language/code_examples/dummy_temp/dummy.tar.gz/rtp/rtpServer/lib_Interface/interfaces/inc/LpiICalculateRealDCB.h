#if !defined(__LPI_I_CALCULATE_REAL_DCB_H__)
#define __LPI_I_CALCULATE_REAL_DCB_H__

class LpiICalculateRealDCB
{
public:
   LpiICalculateRealDCB() {}
   virtual ~LpiICalculateRealDCB() {}

   virtual void calculateRealDCB(void) = 0;
   virtual void calculateRealDCB(std::string) = 0;

};

#endif // __LPI_I_CALCULATE_REAL_DCB_H__
