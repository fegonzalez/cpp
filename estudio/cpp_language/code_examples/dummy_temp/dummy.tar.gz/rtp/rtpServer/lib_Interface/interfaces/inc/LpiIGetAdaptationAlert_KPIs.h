// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 10:57:37 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIIGETADAPTATIONALERT_KPIS_H_
#define LPIIGETADAPTATIONALERT_KPIS_H_

#include "LpiAdaptationAlert_KPIs.h"
#include "LpiResult.h"

class LpiIGetAdaptationAlert_KPIs
{
public:
   virtual ~LpiIGetAdaptationAlert_KPIs() {}
   virtual void getAdaptationAlert_KPIs(LpiAdaptationAlert_KPIs &parameters,
                                            LpiResult        &result) = 0;
};



#endif /* LPIIGETCONFIGURATIONALERT_KPIS_H_ */
