#if !defined(__LPI_I_EVENT_DELEGATE_PUBLISHER__)
#define __LPI_I_EVENT_DELEGATE_PUBLISHER__

#include "LpiIEventPublisher.h"
#include "LpiIDelegatePublisher.h"

template<typename TEvent>
class LpiIEventDelegatePublisher : public LpiIEventPublisher<TEvent>,
                                   public LpiIDelegatePublisher<LpiIEventPublisher<TEvent> >
{
public:
   LpiIEventDelegatePublisher() {}
   virtual ~LpiIEventDelegatePublisher() {}
   virtual void delegatePublisher(LpiIEventPublisher<TEvent> &data) = 0;
   virtual void publish(const TEvent &data) = 0;
};

#endif // __LPI_I_EVENT_DELEGATE_PUBLISHER__
