#if !defined(__LPI_I_CALCULATE_RS_MAX_CAPACITY_H__)
#define __LPI_I_CALCULATE_RS_MAX_CAPACITY_H__

#include <string>

class LpiICalculateRSMaxCapacity
{
public:
   LpiICalculateRSMaxCapacity() {}
   virtual ~LpiICalculateRSMaxCapacity() {}

   virtual void calculateRSMaxCapacity(void) = 0;
   virtual void calculateRSMaxCapacity(std::string) = 0;

};

#endif // __LPI_I_CALCULATE_RS_MAX_CAPACITY_H__
