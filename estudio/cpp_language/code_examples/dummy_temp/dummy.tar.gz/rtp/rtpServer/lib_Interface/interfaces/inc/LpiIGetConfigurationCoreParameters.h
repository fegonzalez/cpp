// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 25 Jun 08:52:15 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIIGETCONFIGURATIONCOREPARAMETERS_H_
#define LPIIGETCONFIGURATIONCOREPARAMETERS_H_


#include "LpiConfigurationCoreParameters.h"
#include "LpiResult.h"

class LpiIGetConfigurationCoreParameters
{
public:
   virtual ~LpiIGetConfigurationCoreParameters() {}
   virtual void getConfigurationCoreParameters(LpiConfigurationCoreParameters &parameters,
                                            LpiResult        &result) = 0;
};




#endif /* LPIIGETCONFIGURATIONCOREPARAMETERS_H_ */
