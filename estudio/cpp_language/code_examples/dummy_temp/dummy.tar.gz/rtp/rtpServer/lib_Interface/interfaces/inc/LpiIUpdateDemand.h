#ifndef LPIIUPDATEDEMAND_H_
#define LPIIUPDATEDEMAND_H_

#include <vector>
#include <string>

using std::vector;
using std::string;


class LpiIUpdateDemand
{
   public:

      virtual ~LpiIUpdateDemand() {}
      virtual void deleteNotReceivedFPs(vector<string> & receivedFPKeys) = 0;
      virtual void calculateTurnRound(LpiFlightPlan & fp) = 0;
      virtual void calculatePriority(LpiFlightPlan & fp) = 0;
};

#endif // LPIIUPDATEDEMAND_H_
