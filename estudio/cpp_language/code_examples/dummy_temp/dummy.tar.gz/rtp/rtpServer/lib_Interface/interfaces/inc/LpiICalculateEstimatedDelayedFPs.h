#if !defined(__LPI_I_CALCULATE_ESTIMATED_DELAYED_FPS_H__)
#define __LPI_I_CALCULATE_ESTIMATED_DELAYED_FPS_H__

class LpiICalculateEstimatedDelayedFPs
{
public:
   LpiICalculateEstimatedDelayedFPs() {}
   virtual ~LpiICalculateEstimatedDelayedFPs() {}

   virtual void calculateEstimatedDelayedFPs(void) = 0;

};

#endif // __LPI_I_CALCULATE_ESTIMATED_DELAYED_FPS_H__
