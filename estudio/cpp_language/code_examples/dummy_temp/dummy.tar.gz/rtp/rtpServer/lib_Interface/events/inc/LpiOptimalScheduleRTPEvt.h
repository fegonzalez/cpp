/*
 * LpiDefaultScheduleEvt.h
 *
 *  Created on: Nov 9, 2018
 *      Author: srperez
 */

#ifndef LPIOPTIMALSCHEDULEEVT_H_
#define LPIOPTIMALSCHEDULEEVT_H_
#include <string>
#include <vector>
#include "LpiScheduleRTP.h"

//#include <LpiDefaultSchedule.h>

class LpiOptimalScheduleRTPEvt
{
public:
   const LpiScheduleRTP & getSchedule(void) const {return this->_schedule;}
   void setSchedule(const LpiScheduleRTP &schedule) {this->_schedule = schedule;}
private:
   LpiScheduleRTP _schedule;
};



#endif /* LPIDEFAULTSCHEDULEEVT_H_ */
