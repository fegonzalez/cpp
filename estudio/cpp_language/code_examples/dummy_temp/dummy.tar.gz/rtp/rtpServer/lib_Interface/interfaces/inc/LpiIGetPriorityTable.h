/*
 * LpiIGetPriorityTable.h
 * created: 25/06/2015
 *
 */

#ifndef LPIIGETPRIORITYTABLE_H_
#define LPIIGETPRIORITYTABLE_H_

#include "LpiPriorityTable.h"
#include "LpiResult.h"

class LpiIGetPriorityTable
{
   public:

      virtual ~LpiIGetPriorityTable() {}
      virtual void getPriorityTableDepartures(LpiPriorityTable & priorities, LpiResult & result) = 0;
      virtual void getPriorityTableArrivals(LpiPriorityTable & priorities, LpiResult & result) = 0;
};



#endif /* LPIIGETPRIORITYTABLE_H_ */
