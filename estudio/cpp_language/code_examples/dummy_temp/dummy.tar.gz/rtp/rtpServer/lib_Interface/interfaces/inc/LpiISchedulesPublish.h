#if !defined(__LPI_I_SCHEDULES_PUBLISH_H__)
#define __LPI_I_SCHEDULES_PUBLISH_H__

#include "LpiCalculationReason.h"

class LpiISchedulesPublish
{
   public:
      LpiISchedulesPublish() {}
      virtual ~LpiISchedulesPublish() {}

      virtual void publishOptimalAndActiveSchedules(const LpiCalculationReason::LpiEnum & reason) = 0;
      virtual void publishOptimalSchedule(const LpiCalculationReason::LpiEnum & reason) = 0;
      virtual void publishActiveSchedule(const LpiCalculationReason::LpiEnum & reason) = 0;
};

#endif // __LPI_I_SCHEDULES_SENDING_H__
