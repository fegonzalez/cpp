/*
 * LpiIGetAdaptationRunway.h
 *
 */

#ifndef LPIIGETADAPTATIONRUNWAY_H_
#define LPIIGETADAPTATIONRUNWAY_H_

#include "LpiAdaptationRunway.h"
#include "LpiResult.h"

class LpiIGetAdaptationRunway
{
public:
   virtual ~LpiIGetAdaptationRunway() {}
   virtual void getAdaptationRunway(LpiAdaptationRunwayList &runways,
                                    LpiResult        &result) = 0;
};



#endif /* LPIIGETADAPTATIONRUNWAY_H_ */
