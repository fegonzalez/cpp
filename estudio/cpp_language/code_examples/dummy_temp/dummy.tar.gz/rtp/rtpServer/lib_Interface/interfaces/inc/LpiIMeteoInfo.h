#if !defined(__LPI_I_METEOINFO__)
#define __LPI_I_METEOINFO__

#include "LpiMeteoInfo.h"

class LpiIMeteoInfo
{
public:
   virtual ~LpiIMeteoInfo() {}
   virtual void getMeteoInfo(const LpiMeteoInfoList &meteo) = 0;
};

#endif // __LPI_I_METEOINFO__
