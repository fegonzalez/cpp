#if !defined(__LPI_I_EVENT_CONSUMER__)
#define __LPI_I_EVENT_CONSUMER__

// Interface abstracto para un consumidor de eventos
template<typename TEvent>
class LpiIEventConsumer
{
public:
   LpiIEventConsumer() {}
   virtual ~LpiIEventConsumer() {}
   virtual void consume(const TEvent &data) = 0;
};

#endif // __LPI_I_EVENT_CONSUMER__
