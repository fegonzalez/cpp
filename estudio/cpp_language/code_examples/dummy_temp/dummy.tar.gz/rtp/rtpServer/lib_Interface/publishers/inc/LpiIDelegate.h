#if !defined(__LPI_I_DELEGATE__)
#define __LPI_I_DELEGATE__

template<typename TDelegate>
class LpiIDelegate
{
public:
   LpiIDelegate() {}
   virtual ~LpiIDelegate() {}
   virtual void delegate(TDelegate &data) = 0;
};

#endif // __LPI_I_DELEGATE__
