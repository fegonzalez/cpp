#if !defined(__LPI_PROVIDERS__)
#define __LPI_PROVIDERS__

#include "LpiIServiceProviders.h"

#endif // __LPI_PROVIDERS__
