#if !defined(__LPI_I_GENERATE_SCHEDULES_H__)
#define __LPI_I_GENERATE_SCHEDULES_H__

class LpiIGenerateSchedules
{
   public:

      LpiIGenerateSchedules() {}
      virtual ~LpiIGenerateSchedules() {}

      virtual void generateSchedulesForAllIntervals(void) = 0;
      virtual void generateSchedulesForLastInterval(string new_interval) = 0;
      virtual void generateSchedulesForClock(int minutesFrozenForClock) = 0;
};

#endif // __LPI_I_GENERATE_SCHEDULES_H__
