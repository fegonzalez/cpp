/*
 * LpiKPIs.cc
 *
 *  Created on: 26/02/2015
 *      Author: mbegega
 */


#include "LpiKPIs.h"

LpiRunwayIntervalKPIs::LpiRunwayIntervalKPIs (const LpiRunwayIntervalKPIs &source)
: rwyName(source.rwyName),
  rwyRealAcceptedFps(source.rwyRealAcceptedFps),
  rwyRealAcceptedFpsWA(source.rwyRealAcceptedFpsWA),
  rwyShortage(source.rwyShortage),
  rwyShortageWA(source.rwyShortageWA),
  rwyAverageDelay_DelayedFPs(source.rwyAverageDelay_DelayedFPs),
  rwyAverageDelay_DelayedFPsWA(source.rwyAverageDelay_DelayedFPsWA),
  rwyMaxForecastedDelay(source.rwyMaxForecastedDelay),
  rwyMaxForecastedDelayWA(source.rwyMaxForecastedDelayWA),
  rwyPercentagePunctuality(source.rwyPercentagePunctuality),
  rwyPercentagePunctualityWA(source.rwyPercentagePunctualityWA),
  rwyPunctualFlights(source.rwyPunctualFlights),
  rwyAverageForecastedDelay(source.rwyAverageForecastedDelay),
  rwyDemandForecast(source.rwyDemandForecast),
  rwyAcceptedFpsOwnInterval(source.rwyAcceptedFpsOwnInterval),
  rwyNotPunctualFlights(source.rwyNotPunctualFlights),
  rwyNumberOfDelayedFlights(source.rwyNumberOfDelayedFlights)
{
}


LpiRunwayIntervalKPIs & LpiRunwayIntervalKPIs::operator= (const LpiRunwayIntervalKPIs & source)
{
   if (this != &source)
   {
      rwyName              = source.rwyName;
      rwyRealAcceptedFps   = source.rwyRealAcceptedFps;
      rwyRealAcceptedFpsWA = source.rwyRealAcceptedFpsWA;
      rwyShortage          = source.rwyShortage;
      rwyShortageWA        = source.rwyShortageWA;

      rwyAverageDelay_DelayedFPs = source.rwyAverageDelay_DelayedFPs;
      rwyAverageDelay_DelayedFPsWA = source.rwyAverageDelay_DelayedFPsWA;
      rwyMaxForecastedDelay = source.rwyMaxForecastedDelay;
      rwyMaxForecastedDelayWA = source.rwyMaxForecastedDelayWA;
      rwyPercentagePunctuality = source.rwyPercentagePunctuality;
      rwyPercentagePunctualityWA =source.rwyPercentagePunctualityWA;
      rwyPunctualFlights = source.rwyPunctualFlights;
      rwyAverageForecastedDelay = source.rwyAverageForecastedDelay;
      rwyDemandForecast = source.rwyDemandForecast;
      rwyAcceptedFpsOwnInterval = source.rwyAcceptedFpsOwnInterval;
      rwyNotPunctualFlights = source.rwyNotPunctualFlights;
      rwyNumberOfDelayedFlights = source.rwyNumberOfDelayedFlights;
   }

   return *this;
}


LpiAirportIntervalKPIs::LpiAirportIntervalKPIs(const LpiAirportIntervalKPIs &source)
: realAcceptedFps(source.realAcceptedFps),
  realAcceptedFpsWA(source.realAcceptedFpsWA),
  shortage(source.shortage),
  shortageWA(source.shortageWA),
  totalRunwaysDemandForecast(source.totalRunwaysDemandForecast),
  averageForecastedDelay_DelayedFPs(source.averageForecastedDelay_DelayedFPs),
  averageForecastedDelay_DelayedFPsWA(source.averageForecastedDelay_DelayedFPsWA),
  maxForecastedDelay(source.maxForecastedDelay),
  maxForecastedDelayWA(source.maxForecastedDelayWA),
  punctuality(source.punctuality),
  punctualityWA(source.punctualityWA),
  percentagePunctuality(source.percentagePunctuality),
  percentagePunctualityWA(source.percentagePunctualityWA)
{
}


LpiAirportIntervalKPIs & LpiAirportIntervalKPIs::operator= (const LpiAirportIntervalKPIs & source)
{
   if (this != & source)
   {
      realAcceptedFps   = source.realAcceptedFps;
      realAcceptedFpsWA = source.realAcceptedFpsWA;
      shortage          = source.shortage;
      shortageWA        = source.shortageWA;
      totalRunwaysDemandForecast = source.totalRunwaysDemandForecast;
      averageForecastedDelay_DelayedFPs = source.averageForecastedDelay_DelayedFPs;
      averageForecastedDelay_DelayedFPsWA = source.averageForecastedDelay_DelayedFPsWA;
      maxForecastedDelay = source.maxForecastedDelay;
      maxForecastedDelayWA = source.maxForecastedDelayWA;
      punctuality = source.punctuality;
      punctualityWA = source.punctualityWA;
      percentagePunctuality = source.percentagePunctuality;
      percentagePunctualityWA = source.percentagePunctualityWA;
   }

   return *this;
}



LpiAirportTotalKPIs::LpiAirportTotalKPIs(const LpiAirportTotalKPIs & source)
: r_totalAccepted(source.r_totalAccepted),
  r_totalShortage(source.r_totalShortage),
  maxForecastedDelay(source.maxForecastedDelay),
  maxForecastedDelayWA(source.maxForecastedDelayWA),
  averageForecastedDelay(source.averageForecastedDelay),
  averageForecastedDelayWA(source.averageForecastedDelayWA),
  maxPunctualityDelay(source.maxPunctualityDelay),
  maxPunctualityDelayWA(source.maxPunctualityDelayWA),
  averagePunctualityDelay(source.averagePunctualityDelay),
  averagePunctualityDelayWA(source.averagePunctualityDelayWA),
  punctualFPs(source.punctualFPs),
  delayedFPs(source.delayedFPs),
  percentagePunctual(source.percentagePunctual),
  percentagePunctualWA(source.percentagePunctualWA),
  averageForecastedDelayDelayedFPs(source.averageForecastedDelayDelayedFPs),
  averageForecastedDelayDelayedFPsWA(source.averageForecastedDelayDelayedFPsWA)
{
}


LpiAirportTotalKPIs & LpiAirportTotalKPIs::operator= (const LpiAirportTotalKPIs & source)
{
   if (this != &source)
   {
      r_totalAccepted = source.r_totalAccepted;
      r_totalShortage = source.r_totalShortage;
      maxForecastedDelay        = source.maxForecastedDelay;
      maxForecastedDelayWA      = source.maxForecastedDelayWA;
      averageForecastedDelay    = source.averageForecastedDelay;
      averageForecastedDelayWA  = source.averageForecastedDelayWA;
      maxPunctualityDelay       = source.maxPunctualityDelay;
      maxPunctualityDelayWA     = source.maxPunctualityDelayWA;
      averagePunctualityDelay   = source.averagePunctualityDelay;
      averagePunctualityDelayWA = source.averagePunctualityDelayWA;
      punctualFPs               = source.punctualFPs;
      delayedFPs                = source.delayedFPs;
      percentagePunctual        = source.percentagePunctual;
      percentagePunctualWA      = source.percentagePunctualWA;
      averageForecastedDelayDelayedFPs = source.averageForecastedDelayDelayedFPs;
      averageForecastedDelayDelayedFPsWA = source.averageForecastedDelayDelayedFPsWA;
   }
   return *this;
}


LpiPerformanceIntervalData::LpiPerformanceIntervalData (const LpiPerformanceIntervalData & source)
: r_name(source.r_name),
  r_begin_time(source.r_begin_time),
  r_end_time(source.r_end_time),
  r_runwaysKPIs(source.r_runwaysKPIs),
  r_airportKPIs(source.r_airportKPIs)
{
}


LpiPerformanceIntervalData & LpiPerformanceIntervalData::operator= (const LpiPerformanceIntervalData & source)
{
   if (this != &source)
   {
      r_name = source.r_name;
      r_begin_time = source.r_begin_time;
      r_end_time = source.r_end_time;
      r_runwaysKPIs = source.r_runwaysKPIs;
      r_airportKPIs = source.r_airportKPIs;
   }

   return *this;
}


LpiRunwayIntervalKPIs LpiPerformanceIntervalData::getRwysKPIs(int i) const
{
   return r_runwaysKPIs[i];
}


std::vector<LpiRunwayIntervalKPIs> LpiPerformanceIntervalData::getRwysKPIs() const
{
   return r_runwaysKPIs;
}


void LpiPerformanceIntervalData::setRwysKPIs(int i, const LpiRunwayIntervalKPIs source)
{
   r_runwaysKPIs[i] = source;
}


void LpiPerformanceIntervalData::setRwysKPIs(const std::vector<LpiRunwayIntervalKPIs> source)
{
   r_runwaysKPIs.resize(source.size());

   for(unsigned int i = 0; i< source.size(); i++)
   {
      r_runwaysKPIs[i] = source[i];
   }
}


LpiPerformanceIntervalData LpiPerformanceInfo::getPerformanceIntervalData(int i) const
{
   return r_performanceTimeLine[i];
}


void LpiPerformanceInfo::setPerformanceIntervalData(int i, const LpiPerformanceIntervalData & source)
{
   r_performanceTimeLine[i] = source;
}


void LpiPerformanceInfo::setAllPerformanceIntervalData(const std::vector<LpiPerformanceIntervalData> & source)
{
   r_performanceTimeLine.resize(source.size());

   for(unsigned int i = 0; i< source.size(); i++)
   {
      r_performanceTimeLine[i] = source[i];
   }
}


std::ostream & operator<<(std::ostream & os, const LpiAirportTotalKPIs & delays)
{
   os << "[DELAYS KPIs: "
      << "\nTotal Accepted: " << delays.getTotalAccepted()
      << " | Total Shortage: " << delays.getTotalShortage()
      << "\nAverageForecastedDelay: " << delays.getaverageForecastedDelay()
      << " | " << delays.getaverageForecastedDelayWA()

      << "\nAveragePunctualityDelay: " << delays.getaveragePunctualityDelay()
      << " | " << delays.getaveragePunctualityDelayWA()

      << "\nDelayedFPs:" << delays.getdelayedFPs()

      << "\nMaxForecastedDelay: " << delays.getmaxForecastedDelay()
      << " | " << delays.getmaxForecastedDelayWA()

      << "\nMaxPunctualityDelay: " << delays.getmaxPunctualityDelay()
      << " | " << delays.getmaxPunctualityDelayWA()

      << "\nPercentagePunctual: " << delays.getpercentagePunctual()
      << " | : " << delays.getpercentagePunctualWA()

      << "\nPunctualFPs: " << delays.getpunctualFPs()
      << ']';

   return os;
}


