
#include "LpiRunwayMeteoInfo.h"


LpiRunwayMeteoInfo::LpiRunwayMeteoInfo()
: r_rwyId(), r_crosswind(0.0), r_tailwind(0.0)
{
}


LpiRunwayMeteoInfo::LpiRunwayMeteoInfo(const string& rwyId)
: r_rwyId(rwyId), r_crosswind(0.0), r_tailwind(0.0)
{
}


LpiRunwayMeteoInfo::LpiRunwayMeteoInfo(const string& rwyId, double cw, double tw)
: r_rwyId(rwyId), r_crosswind(cw), r_tailwind(tw)
{
}


LpiRunwayMeteoInfo::LpiRunwayMeteoInfo(const LpiRunwayMeteoInfo& source)
: r_rwyId(source.r_rwyId), r_crosswind(source.r_crosswind), r_tailwind(source.r_tailwind)
{
}


LpiRunwayMeteoInfo& LpiRunwayMeteoInfo::operator =(const LpiRunwayMeteoInfo& source)
{
   if (this != &source)
   {
      r_rwyId = source.r_rwyId;
      r_crosswind = source.r_crosswind;
      r_tailwind = source.r_tailwind;
   }

   return *this;
}


double LpiRunwayMeteoInfo::getCrosswind() const
{
   return r_crosswind;
}


void LpiRunwayMeteoInfo::setCrosswind(double crosswind)
{
   r_crosswind = crosswind;
}


string LpiRunwayMeteoInfo::getRwyId() const
{
   return r_rwyId;
}


void LpiRunwayMeteoInfo::setRwyId(string rwyId)
{
   r_rwyId = rwyId;
}


double LpiRunwayMeteoInfo::getTailwind() const
{
   return r_tailwind;
}


void LpiRunwayMeteoInfo::setTailwind(double tailwind)
{
   r_tailwind = tailwind;
}


std::ostream& operator <<(std::ostream &os,
                          const LpiRunwayMeteoInfo &obj)
{
   return os << "[RWY: " << obj.getRwyId()
              << " |CW: " << obj.getCrosswind()
              << " |TW: " << obj.getTailwind()
              << ']';
}


