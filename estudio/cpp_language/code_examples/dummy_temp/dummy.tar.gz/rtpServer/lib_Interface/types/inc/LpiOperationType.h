#ifndef LPIOPERATION_TYPE_H_
#define LPIOPERATION_TYPE_H_

#include <iostream>

class LpiOperationType
{
public:
   enum LpiEnum
   {
      E_NONE = 0,
      E_ARRIVAL,
      E_DEPARTURE
  };
};


std::ostream& operator <<(std::ostream &os,
                                         const LpiOperationType::LpiEnum &obj);


#endif
