/*
 * LpiFlightPlan.h
 *
 *  Created on: 12/12/2013
 *      Author: mbegega
 */

#ifndef LPIFLIGHTPLAN_H_
#define LPIFLIGHTPLAN_H_

#include <string>
#include <vector>
#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/foreach.hpp>
#include <map>
#include <iostream>

#include "LpiOperationType.h"
#include "LpiFPCharacteristic.h"

using namespace boost;
using std::string;
using std::vector;

typedef std::map<string, string > LpiPreferentialRunway;


class LpiDepartureTimes
{
   public:
      LpiDepartureTimes ();
      LpiDepartureTimes(posix_time::ptime eobt, posix_time::ptime sobt,
                        posix_time::ptime tobt, posix_time::ptime etot,
                        posix_time::ptime ttot, posix_time::ptime stot,
                        posix_time::ptime atot, posix_time::ptime ctot,
                        posix_time::ptime utot);

      LpiDepartureTimes (const LpiDepartureTimes & source);
      virtual ~LpiDepartureTimes () {}

      LpiDepartureTimes & operator= (const LpiDepartureTimes & source);

      void setEobt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getEobt() const;

      void setSobt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getSobt() const;

      void setTobt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getTobt() const;

      void setEtot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getEtot() const;

      void setTtot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getTtot() const;

      void setStot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getStot() const;

      void setAtot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getAtot() const;

      void setCtot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getCtot() const;

      void setUtot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getUtot() const;

      void setItot (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getItot() const;

   protected:
      //Off-Block Times
      boost::optional<posix_time::ptime> r_eobt;
      boost::optional<posix_time::ptime> r_sobt;
      boost::optional<posix_time::ptime> r_tobt;

      //Take-Off Times
      boost::optional<posix_time::ptime> r_etot;
      boost::optional<posix_time::ptime> r_ttot;
      boost::optional<posix_time::ptime> r_stot;
      boost::optional<posix_time::ptime> r_atot;
      boost::optional<posix_time::ptime> r_ctot;

      //User assigned Take-Off Time
      boost::optional<posix_time::ptime> r_utot;

      //Intentional Time
      boost::optional<posix_time::ptime> r_itot; //set to null invoking ".reset()"
};

std::ostream& operator<< (std::ostream & out, const LpiDepartureTimes & dep);


class LpiArrivalTimes
{
   public:
      LpiArrivalTimes ();
      LpiArrivalTimes(posix_time::ptime eldt, posix_time::ptime tldt,
                      posix_time::ptime aldt, posix_time::ptime sldt,
                      posix_time::ptime sibt, posix_time::ptime uldt);
      LpiArrivalTimes(const LpiArrivalTimes& source);
      virtual ~LpiArrivalTimes (){}

      LpiArrivalTimes & operator= (const LpiArrivalTimes & source);

      void setIldt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getIldt() const;
      void setEldt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getEldt() const;
      void setTldt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getTldt() const;
      void setAldt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getAldt() const;
      void setSldt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getSldt() const;
      void setSibt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getSibt() const;
      void setUldt (posix_time::ptime timestamp);
      const boost::optional<posix_time::ptime> & getUldt() const;

   protected:
      //Landing Times
      boost::optional<posix_time::ptime> r_eldt;
      boost::optional<posix_time::ptime> r_tldt;
      boost::optional<posix_time::ptime> r_aldt;
      boost::optional<posix_time::ptime> r_sldt;

      //In-Block Times
      boost::optional<posix_time::ptime> r_sibt;

      //User assigned Landing Time
      boost::optional<posix_time::ptime> r_uldt;

      //Intentional Time
      boost::optional<posix_time::ptime> r_ildt; //set to null invoking ".reset()"
};


std::ostream& operator<< (std::ostream & out, const LpiArrivalTimes & arr);


class LpiFlightPlan
{
public:

   LpiFlightPlan ();
   LpiFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome);
   LpiFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome, int demand_order);
   LpiFlightPlan (const LpiFlightPlan & source);

   virtual ~LpiFlightPlan () {}

   LpiFlightPlan & operator= (const LpiFlightPlan & source);

   //Getters and Setters
   string getAircraftType() const;
   void setAircraftType(string aircraftType);

   string getArrivalAerodrome() const;
   void setArrivalAerodrome(string arrivalAerodrome);

   LpiArrivalTimes getArrivalTimes() const;
   void setArrivalTimes(LpiArrivalTimes arrivalTimes);

   string getCallsign() const;
   void setCallsign(string callsign);

   string getDepartureAerodrome() const;
   void setDepartureAerodrome(string departureAerodrome);

   LpiDepartureTimes getDepartureTimes() const;
   void setDepartureTimes(LpiDepartureTimes departureTimes);

   LpiOperationType::LpiEnum getOperationType() const;
   void setOperationType(LpiOperationType::LpiEnum flightType);
   void setOperationType(string local_aerodrome);

   string getRegistration() const;
   void setRegistration(string registration);

   string getWtc() const;
   void setWtc(string wtc);

   string getSID() const;
   void setSID(string sid);

   string getSTAR() const;
   void setSTAR(string star);

   string getVFR() const;
   void setVFR(string star);

   LpiPreferentialRunway getPreferentialRunways () const;
   void setPreferentialRunways(LpiPreferentialRunway runways);
   void addPreferentialRunway(string key, string value);

   vector<string> getPreferentialRunwaysNames (string runwaySystemName) const;

   const boost::optional<posix_time::ptime> & getItot() const;
   const boost::optional<posix_time::ptime> & getIldt() const;
   boost::optional<posix_time::ptime> getIntentionalTime() const;

   int  getDemandOrder () const;
   void setDemandOrder (int order);

   //Returns an unique identification, for example, for DB storing
   //Consist in a string "callsign departure arrival"
   string getUniqueKey() const;

   //Checks if FP is of interest (dep or arr) to a given airport
   bool   isOfInterest(string airport_name) const;

   void calculateIntentionalTimes(int default_taxi_time);
//   void calculatePreferentialRunway(LpiPreferentialAllocation preferential,
//         const vector<string> & rs_keys);

   void setNotAllowedRunways (const vector<string> & runway_list);
   vector<string> getNotAllowedRunways () const;

   void setDepartureRunway (const string & runway);
   string getDepartureRunway () const;

   void setArrivalRunway (const string & runway);
   string getArrivalRunway () const;

   void setTurnRoundKey(const string & anotherFPKey);
   string getTurnRoundKey() const;

   void setClosedTurnRound(bool isClosedTurnRound);
   bool isClosedTurnRound() const;

   int getPriorityDepartures() const;
   void setPriorityDepartures(int priority);

   int getPriorityArrivals() const;
   void setPriorityArrivals(int priority);

   bool hasCharacteristic(const LpiFPCharacteristic::LpiEnum & characteristic) const;

protected:

   string             r_callsign;
   string             r_departure_aerodrome;
   string             r_arrival_aerodrome;
   string             r_aircraft_type;
   string             r_registration;
   string             r_wtc;    // "Light, Medium, Heavy"
   string             r_sid;
   string             r_star;
   string 	          r_vfr;

   LpiOperationType::LpiEnum r_operation_type;

   LpiDepartureTimes r_departure_times;
   LpiArrivalTimes   r_arrival_times;

   LpiPreferentialRunway r_preferential_runways;
   vector<string> r_not_allowed_runways;
   int r_demand_order;

   string r_departure_runway;
   string r_arrival_runway;

   // For Turn-Round calculations
   string r_turnRoundKey;
   bool   r_isClosedTurnRound;

   int r_priorityDepartures;
   int r_priorityArrivals;
};


typedef std::vector<LpiFlightPlan> LpiFlightPlanList;

class LpiCreateDemand
{

public:    

   LpiCreateDemand ();
   virtual ~LpiCreateDemand () {}

   LpiCreateDemand & operator= (const LpiCreateDemand & source);
  
   // Get and Set
	void setNameAirport(const std::string & nameAirport) {
		r_nameAirport = nameAirport;
	}
	const std::string & getNameAirport() const {
		return r_nameAirport;
	}

	void setDemandStartTimeAndDate(const posix_time::ptime & startTime) {
		r_demandStartTimeAndDate = startTime;
	}
	const posix_time::ptime & getDemandStartTimeAndDate() const {
		return r_demandStartTimeAndDate;
	}

	void setDemandEndTimeAndDate(const posix_time::ptime & endTime) {
		r_demandEndTimeAndDate = endTime;
	}
	const posix_time::ptime & getDemandEndTimeAndDate() const {
		return r_demandEndTimeAndDate;
	}


   posix_time::ptime getmessageTimeandDate() const;
   void setmessageTimeandDate(posix_time::ptime _messageTimeandDate);

   LpiFlightPlanList getFlightPlanList() const;
   void setFlightPlanList(LpiFlightPlanList flightPlanList);


private:
	std::string 				r_nameAirport;
	posix_time::ptime 			r_demandStartTimeAndDate;
	posix_time::ptime 			r_demandEndTimeAndDate;
	LpiFlightPlanList          r_flightPlanList;

   posix_time::ptime          r_messageTimeandDate; //??????¿¿¿¿¿¿

};

typedef std::vector<LpiCreateDemand> LpiCreateDemandList;

std::ostream& operator<< (std::ostream & out, const LpiCreateDemand & dm);
std::ostream& operator<< (std::ostream & out, const LpiFlightPlan & fp);
bool operator< (const LpiFlightPlan & fp1, const LpiFlightPlan & fp2);
bool operator>= (const LpiFlightPlan & fp1, const LpiFlightPlan & fp2);

#endif /* LPIFLIGHTPLAN_H_ */
