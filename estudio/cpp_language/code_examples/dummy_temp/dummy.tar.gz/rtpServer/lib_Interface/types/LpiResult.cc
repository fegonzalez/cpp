
#include "LpiResult.h"


LpiResult::LpiResult(): _result(E_NONE)
{}


std::ostream & operator<<(std::ostream & os, const LpiResult & result)
{
   os << "Result: " <<result.getResult();
   return os;
}

