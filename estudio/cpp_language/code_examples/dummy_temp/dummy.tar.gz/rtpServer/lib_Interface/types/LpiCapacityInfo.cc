/*
 * LpiCapacityInfo.cc
 *
 *  Created on: 26/02/2015
 *      Author: mbegega
 */

#include "LpiCapacityInfo.h"

LpiRunwayIntervalCapacityInfo::LpiRunwayIntervalCapacityInfo (const LpiRunwayIntervalCapacityInfo & source)
: r_rwyName(source.r_rwyName),
  r_rwyCapacity(source.r_rwyCapacity),
  r_rwyCapacityWA(source.r_rwyCapacityWA)
{
}


LpiRunwayIntervalCapacityInfo & LpiRunwayIntervalCapacityInfo::operator= (const LpiRunwayIntervalCapacityInfo & source)
{
   if (this != &source)
   {
      r_rwyName = source.r_rwyName;
      r_rwyCapacity = source.r_rwyCapacity;
      r_rwyCapacityWA = source.r_rwyCapacityWA;
   }

   return *this;
}


LpiAirportIntervalCapacityInfo::LpiAirportIntervalCapacityInfo (const LpiAirportIntervalCapacityInfo & source)
: r_maxCapacity(source.r_maxCapacity),
  r_maxCapacityWA(source.r_maxCapacityWA),
  r_twyCapacity(source.r_twyCapacity),
  r_twyCapacityWA(source.r_twyCapacityWA),
  r_rsCapacity(source.r_rsCapacity),
  r_rsCapacityWA(source.r_rsCapacityWA)
{
}


LpiAirportIntervalCapacityInfo & LpiAirportIntervalCapacityInfo::operator= (const LpiAirportIntervalCapacityInfo & source)
{
   if (this != &source)
   {
      r_maxCapacity = source.r_maxCapacity;
      r_maxCapacityWA = source.r_maxCapacityWA;
      r_twyCapacity   = source.r_twyCapacity;
      r_twyCapacityWA = source.r_twyCapacityWA;
      r_rsCapacity    = source.r_rsCapacity;
      r_rsCapacityWA  = source.r_rsCapacityWA;
   }

   return *this;
}


LpiRunwayIntervalCapacityInfo LpiCapacityIntervalData::getRwysCapacities(int i) const
{
   return r_runwaysCapacities[i];
}


std::vector<LpiRunwayIntervalCapacityInfo> LpiCapacityIntervalData::getAllRwysCapacities() const
{
   return r_runwaysCapacities;
}


void LpiCapacityIntervalData::setRwysCapacities(int i, const LpiRunwayIntervalCapacityInfo & source)
{
   r_runwaysCapacities[i] = source;
}


void LpiCapacityIntervalData::setAllRwysCapacities(const std::vector<LpiRunwayIntervalCapacityInfo> source)
{
   r_runwaysCapacities.resize(source.size());

   for(unsigned int i = 0; i< source.size(); i++)
   {
      r_runwaysCapacities[i] = source[i];
   }
}


LpiCapacityIntervalData LpiCapacityInfo::getCapacityIntervalData(int i) const
{
   return r_capacityTimeLine[i];
}


void LpiCapacityInfo::setCapacityIntervalData(int i, const LpiCapacityIntervalData & source)
{
   r_capacityTimeLine[i] = source;
}


void LpiCapacityInfo::setAllCapacityIntervalData(const std::vector<LpiCapacityIntervalData> & source)
{
   r_capacityTimeLine.resize(source.size());

   for(unsigned int i = 0; i< source.size(); i++)
   {
      r_capacityTimeLine[i] = source[i];
   }
}
