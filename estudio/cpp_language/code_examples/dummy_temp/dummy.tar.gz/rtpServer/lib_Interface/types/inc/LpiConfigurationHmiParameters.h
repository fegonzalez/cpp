// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 14:23:48 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPICONFIGURATIONHMIPARAMETERS_H_
#define LPICONFIGURATIONHMIPARAMETERS_H_


#include <iostream>

class AlarmColors
{
public:
	AlarmColors(){}
    ~AlarmColors(){}

    // getters
    std::string getColorAlarmThreshold(void) const { return this->_colorAlarmThreshold; }
    std::string getColorWarningThreshold(void) const { return this->_colorWarningThreshold; }

    // setters
    void setColorAlarmThreshold(const std::string value) { this->_colorAlarmThreshold=value; }
    void setColorWarningThreshold(const std::string value) { this->_colorWarningThreshold=value; }

private:
    std::string _colorAlarmThreshold;
    std::string _colorWarningThreshold;
};


class ModuleColors
{
public:
    ModuleColors(){}
    ~ModuleColors(){}

    // getters
    std::string getColorModule1(void) const { return this->_colorModule1; }
    std::string getColorModule2(void) const { return this->_colorModule2; }
    std::string getColorModule3(void) const { return this->_colorModule3; }
    std::string getColorModule4(void) const { return this->_colorModule4; }
    std::string getColorModule5(void) const { return this->_colorModule5; }

    // setters
    void setColorModule1(const std::string value) { this->_colorModule1=value; }
    void setColorModule2(const std::string value) { this->_colorModule2=value; }
    void setColorModule3(const std::string value) { this->_colorModule3=value; }
    void setColorModule4(const std::string value) { this->_colorModule4=value; }
    void setColorModule5(const std::string value) { this->_colorModule5=value; }

private:
    std::string _colorModule1;
    std::string _colorModule2;
    std::string _colorModule3;
    std::string _colorModule4;
    std::string _colorModule5;
};

class GraphicRtpColors
{
public:
    GraphicRtpColors(){}
    ~GraphicRtpColors(){}

    // getters
    std::string getColorGraphicComplexity(void) const { return this->_colorGraphicComplexity; }
    std::string getColorGraphicSimOps(void) const { return this->_colorGraphicSimOps; }
    std::string getColorGraphicTotalMov(void) const { return this->_colorGraphicTotalMov; }
    std::string getColorGraphicVFR(void) const { return this->_colorGraphicVFR; }

    // setters
    void setColorGraphicComplexity(const std::string value) { this->_colorGraphicComplexity=value; }
    void setColorGraphicSimOps(const std::string value) { this->_colorGraphicSimOps=value; }
    void setColorGraphicTotalMov(const std::string value) { this->_colorGraphicTotalMov=value; }
    void setColorGraphicVFR(const std::string value) { this->_colorGraphicVFR=value; }

private:
    std::string _colorGraphicComplexity;
    std::string _colorGraphicSimOps;
    std::string _colorGraphicTotalMov;
    std::string _colorGraphicVFR;
};

class ColorsRtpHmi
{
public:
    ColorsRtpHmi(){}
    ~ColorsRtpHmi(){}

    // getters
    GraphicRtpColors getGraphicRtpColors(void) const { return this->_graphicRtpColors; }
    ModuleColors getModuleColors(void) const { return this->_moduleColors; }
    AlarmColors getAlarmColors(void) const { return this->_alarmColors; }

    // setters
    void setGraphicRtpColors(const GraphicRtpColors value) { this->_graphicRtpColors=value; }
    void setModuleColors(const ModuleColors value) { this->_moduleColors=value; }
    void setAlarmColors(const AlarmColors value) { this->_alarmColors=value; }

private:
    GraphicRtpColors _graphicRtpColors;
    ModuleColors _moduleColors;
    AlarmColors _alarmColors;
};

class GraphicRtpMaxRepresentation
{
public:
    GraphicRtpMaxRepresentation(){}
    ~GraphicRtpMaxRepresentation(){}

    // getters
    int getGraphicRtpMaxDArr(void) const { return this->_graphicRtpMaxDArr; }
    int getGraphicRtpMaxDDep(void) const { return this->_graphicRtpMaxDDep; }

    // setters
    void setGraphicRtpMaxDArr(const int value) { this->_graphicRtpMaxDArr=value; }
    void setGraphicRtpMaxDDep(const int value) { this->_graphicRtpMaxDDep=value; }


private:
    int _graphicRtpMaxDArr;
    int _graphicRtpMaxDDep;

};

class TimeRtpHmiParameters
{
public:
    TimeRtpHmiParameters(){}
    ~TimeRtpHmiParameters(){}

    // getters
    int getHoursRtpHmiWindow(void) const { return this->_hoursRtpHmiWindow; }

    // setters
    void setHoursRtpHmiWindow(const int value) { this->_hoursRtpHmiWindow=value; }

private:
    int _hoursRtpHmiWindow;

};

class LpiConfigurationHmiParameters
{
public:
    LpiConfigurationHmiParameters() {}
    ~LpiConfigurationHmiParameters() {}

    // getters
    TimeRtpHmiParameters getTimeRtpHmiParameters(void) const { return this->_timeRtpHmiParameters; }
    GraphicRtpMaxRepresentation getGraphicRtpMaxRepresentation(void) const { return this->_graphicRtpMax; }
    int getMinRtpIntervalsForScrolling(void) const { return this->_minRtpIntervalsForScrolling; }
    ColorsRtpHmi getColorsRtpHmi(void) const { return this->_colorsRtpHmi; }

    // setters
    void setTimeRtpHmiParameters(const TimeRtpHmiParameters value) { this->_timeRtpHmiParameters=value; }
    void setGraphicRtpMaxRepresentation(const GraphicRtpMaxRepresentation value) { this->_graphicRtpMax=value; }
    void setMinRtpIntervalsForScrolling(const int value) { this->_minRtpIntervalsForScrolling=value; }
    void setColorsRtpHmi(const ColorsRtpHmi value) { this->_colorsRtpHmi=value; }

private:
    TimeRtpHmiParameters _timeRtpHmiParameters;
    GraphicRtpMaxRepresentation _graphicRtpMax;
    int _minRtpIntervalsForScrolling;
    ColorsRtpHmi _colorsRtpHmi;
};

std::ostream & operator<<(std::ostream & out,
                          const LpiConfigurationHmiParameters & hmiParams);

#endif /* LPICONFIGURATIONHMIPARAMETERS_H_ */
