/*
 *  LpiScheduleActivation.cc
 *
 *  Created on: 14/07/2014
 *
 *  Author: gpfernandez
 */

#include "LpiScheduleActivation.h"


std::ostream & operator<<(std::ostream & os, const LpiScheduleActivation & scheduleActivation)
{
   os << "[Id Schedule: " << scheduleActivation.getScheduleId() << "]";
   return os;
}
