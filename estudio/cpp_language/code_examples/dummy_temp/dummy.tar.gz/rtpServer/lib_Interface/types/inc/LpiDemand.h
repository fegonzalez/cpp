/*
 * LpiDemand.h
 *
 *  Created on: 24/02/2014
 *      Author: gpfernandez
 */

#ifndef LPIDEMAND_H_
#define LPIDEMAND_H_

#include <string>
#include <vector>
#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiADO.h"
#include "LpiOperationType.h"
#include "LpiCalculationReason.h"
#include "LpiFlightPlan.h"

using namespace boost;
using std::string;
using std::vector;


typedef  boost::optional<posix_time::ptime> times;


class Demand_list
{
   public:
      Demand_list ();
      virtual ~Demand_list () {}

      std::string getIntervalName() const;
      void setIntervalName(std::string name);

      LpiADO  getdemandForecastScheduled() const;
      void setdemandForecastScheduled(LpiADO _demandForecastScheduled);

      LpiADO  getDemandRatio () const;
      void    setDemandRatio (LpiADO ratio);

      LpiADO  getDemandVFR () const;
      void    setDemandVFR (LpiADO vfr);

      std::string getStarTime() const;
      void setStartTime(std::string start_time);

      std::string getEndTime() const;
      void setEndTime(std::string end_time);

      Demand_list & operator= ( const Demand_list & source);


   private:
      std::string r_interval_name;

      LpiADO      r_demand_forecast_scheduled;
      LpiADO      r_demand_ratio;
      LpiADO      r_demand_vfr;

      std::string r_start_time;
      std::string r_end_time;
};


class NumberDemand
{
   public:
      NumberDemand ();
      virtual ~NumberDemand () {}

      vector<Demand_list> getDemand() const;
      void setDemand(vector<Demand_list> _demand);
     
      LpiADO gettotalDemandForecast() const;
      void settotalDemandForecast(LpiADO totals);

      LpiADO getTotalDemandRatio () const;
      void   setTotalDemandRatio (LpiADO total_ratio);

      LpiADO getTotalDemandVFR () const;
      void   setTotalDemandVFR (LpiADO total_vfr);

      NumberDemand & operator= (const NumberDemand & source);

   private:
      vector<Demand_list>  r_demand;
      LpiADO               r_total_demand_forecast;
      LpiADO               r_total_demand_ratio;
      LpiADO               r_total_demand_vfr;
};


class Fps_list
{
  public:
      Fps_list ();
      virtual ~Fps_list () {}

      std::string  getdemandForecastFpsScheduled() const;
      void setdemandForecastFpsScheduled(std::string _demandForecastFpsScheduled);

      void setItotIldt (times timestamp);
      times getItotIldt () const;

      void setCtotSibt (times timestamp);
      times getCtotSibt () const;

      void setEtotEldt (times timestamp);
      times getEtotEldt () const;

      void setStotSldt (times timestamp);
      times getStotSldt () const;

      void setTtotTldt (times timestamp);
      times getTtotTldt () const;

      void setUtotUldt (times timestamp);
      times getUtotUldt () const;

      std::string getSIDSTAR() const;
      void setSIDSTAR(std::string sid_star);

      std::string getAircraftType() const;
      void setAircraftType(std::string aircraftType);

      LpiOperationType::LpiEnum getOperationType() const;
      void setOperationType(LpiOperationType::LpiEnum flightType);

      void reset();

  private:
      std::string               r_demand_forecast_fps_scheduled;
      times                     r_itot_ildt;
      times                     r_ctot_sibt;
      times                     r_etot_eldt;
      times                     r_stot_sldt;
      times                     r_ttot_tldt;
      times                     r_utot_uldt;

      std::string               r_sid_star;
      std::string               r_aircraft_type; 
      LpiOperationType::LpiEnum r_operation_type;

};

std::ostream& operator<< (std::ostream & out, const Fps_list & fp);


class FPs_ADO
{
   public:
      FPs_ADO (){};
      virtual ~FPs_ADO () {}

      vector<Fps_list>   arrivals;
      vector<Fps_list>   departure;
      vector<Fps_list>   overall;
};

class LpiDemand
{
   public:
      LpiDemand ();

      LpiDemand (const LpiDemand & source);
      virtual ~LpiDemand () {}

      LpiDemand & operator= (const LpiDemand & source);

      posix_time::ptime getmessageTimeandDate() const;
      void setmessageTimeandDate(posix_time::ptime _messageTimeandDate);

      NumberDemand getDemand() const;
      void setDemand(NumberDemand _demand);

      const vector<FPs_ADO> & getFps() const;
      void setFps(vector<FPs_ADO> _fps);

      void setCalculationReason(const LpiCalculationReason::LpiEnum & value)
      { calculationReason = value; }

      LpiCalculationReason::LpiEnum getCalculationReason() const
      { return calculationReason; }



      void setNameAirport(const std::string & nameAirport) {
    	  r_nameAirport = nameAirport;
      }
      const std::string & getNameAirport() const {
    	  return r_nameAirport;
      }

      void setDemandStartTimeAndDate(const posix_time::ptime & startTime) {
    	  r_demandStartTimeAndDate = startTime;
      }
      const posix_time::ptime & getDemandStartTimeAndDate() const {
    	  return r_demandStartTimeAndDate;
      }

      void setDemandEndTimeAndDate(const posix_time::ptime & endTime) {
    	  r_demandEndTimeAndDate = endTime;
      }
      const posix_time::ptime & getDemandEndTimeAndDate() const {
    	  return r_demandEndTimeAndDate;
      }

      const LpiFlightPlanList & getFlightPlanList() const;
      void setFlightPlanList(const LpiFlightPlanList & fpList);

   protected:
      posix_time::ptime      messageTimeandDate;
      LpiCalculationReason::LpiEnum calculationReason;
      NumberDemand           r_demand;
      vector<FPs_ADO>        r_fps;

      std::string 				r_nameAirport;
      posix_time::ptime 		r_demandStartTimeAndDate;
      posix_time::ptime 		r_demandEndTimeAndDate;
      LpiFlightPlanList         r_flightPlanList;
};

typedef std::vector<LpiDemand> LpiUpdateDemandList;

std::ostream& operator<< (std::ostream & out, const LpiDemand & dep);


#endif /* LPIDEMAND_H_ */
