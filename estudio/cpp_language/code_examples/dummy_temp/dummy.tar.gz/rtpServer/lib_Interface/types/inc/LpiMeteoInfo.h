/*
 * LpiMeteoInfo.h
 *
 *  DOC Reference: [1] "RTP Diseño Funcional.docx"
 */

#ifndef LPIMETEOINFO_H_
#define LPIMETEOINFO_H_

#include "LpiOperationType.h"
#include "LpiCalculationReason.h"
#include "LpiTime.h"
#include "LpiMeteoTimeline.h"
#include <LcmetConstants.h>
//#include <IOMeteoInfo.h>

#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <string>
#include <vector>
#include <utility>      // std::pair

using namespace boost;
using std::string;
using std::vector;

class RVRPerRunway
{
   public:
     RVRPerRunway ();
     virtual  ~RVRPerRunway () {}

     RVRPerRunway & operator= (const RVRPerRunway & source);

     //Getters and Setters
     const std::string & getName(void) const {return this->_name;};
     void setName (const std::string & name) {this->_name=name;};
    
     const boost::optional<unsigned int> & getRvr(void) const
     {return this->_rvr;};
     void setRvr(unsigned int rvr) {this->_rvr=rvr;};

     // IOUpdateMeteoInfo code
      const double  getCrossWind(void) const {return this->_crosswind;};
      void setCrossWind(const double crosswind) {this->_crosswind=crosswind;};
      const double getTailWind(void) const {return this->_tailwind;};
      void setTailWind(const double tailwind) {this->_tailwind=tailwind;};


 private:
     std::string                   _name;
     boost::optional<unsigned int> _rvr;

     double                       _crosswind;
     double                       _tailwind;
};

//typedef  std::vector<RVRPerRunway> RVRPerRunwayList;

class RVRPerRunwayList
{
  public:
   RVRPerRunwayList ();
   virtual  ~RVRPerRunwayList () {}

   RVRPerRunwayList & operator=(const RVRPerRunwayList & source);
   // getters
   const std::vector<RVRPerRunway>& getRVRPerRunway(void) const {return this->_RVRPerRunway;}
   const RVRPerRunway& getRVRPerRunway(unsigned int index) const {return this->_RVRPerRunway[index];}

   const unsigned int size()const {return _RVRPerRunway.size(); }
   // setters
   void setRVRPerRunway(const RVRPerRunway &value) {_RVRPerRunway.push_back(value);}
  private:
      std::vector<RVRPerRunway> _RVRPerRunway;
};


/**class LpiMeteoInfo

   Stores one IOUpdateMeteoInfo::BodyInformation
*/
class LpiMeteoInfo
{
public:
  
   LpiMeteoInfo ();
   LpiMeteoInfo (const LpiMeteoInfo & source);
   virtual ~LpiMeteoInfo () {}

   LpiMeteoInfo & operator= (const LpiMeteoInfo & source);

   //Getters and Setters
   
   posix_time::ptime getStartTimeAndDate() const;
   void setStartTimeAndDate(posix_time::ptime _time);

   posix_time::ptime getEndTimeAndDate() const;
   void setEndTimeAndDate(posix_time::ptime _time);

   double getProbability() const;
   void setProbability(double _probability);

   const boost::optional<lcmeteo::TYPE_WIND_SPEED> & getWindSpeed () const;
   void setWindSpeed (lcmeteo::TYPE_WIND_SPEED windSpeed);

   const boost::optional<lcmeteo::TYPE_WIND_DIRECTION> & getWindDirection () const;
   void setWindDirection (lcmeteo::TYPE_WIND_DIRECTION _windDirection);

   const boost::optional<lcmeteo::TYPE_GUST_SPEED> & getGustSpeed () const;
   void setGustSpeed (lcmeteo::TYPE_GUST_SPEED _gustSpeed);

   const boost::optional<lcmeteo::TYPE_GUST_DIRECTION> & getGustDirection () const;
   void setGustDirection (lcmeteo::TYPE_GUST_DIRECTION _gustDirection);

   const boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE> & getDewPointTemperature () const;
   void setDewPointTemperature (lcmeteo::TYPE_DEW_POINT_TEMPERATURE _dewPointTemperature);

   const boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE> & getAirTemperature () const;
   void setAirTemperature (lcmeteo::TYPE_AIR_TEMPERATURE _airTemperature);

   const boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY> & getHorizontalVisibility() const;
   void setHorizontalVisibility (lcmeteo::TYPE_HORIZONTAL_VISIVILITY _horizontalVisibility);

   const boost::optional<lcmeteo::TYPE_QNH> & getQnh () const;
   void setQnh (lcmeteo::TYPE_QNH _qnh);

   const boost::optional<lcmeteo::TYPE_CLOUD_BASE> & getCloudbase () const;
   void setCloudbase (lcmeteo::TYPE_CLOUD_BASE _cloudbase);

   std::string getSignificantWeather() const;
   void setSignificantWeather(std::string _significantWeather);

   const boost::optional<std::string> & getSignificantWeatherQualifier()const ;
   void setSignificantWeatherQualifier(std::string _significantWeatherQualifier);

   const boost::optional<std::string> & getSignificantWeatherPhenomenon() const;
   void setSignificantWeatherPhenomenon(std::string _significantWeatherPhenomenon);

   std::string getWetness() const;
   void setWetness(std::string _Wetness);

   const boost::optional<std::string> & getRequiredILSCategory() const;
   void setRequiredILSCategory(std::string _requiredILSCategory);

   bool getDeicing() const;
   void setDeicing(bool _deicing);

   bool getLvpActivation() const;
   void setLvpActivation(bool _lvpActivation);


   /* std::vector<unsigned int> getWindVector() const; */
   /* void setWindVector(std::vector<unsigned int> _windvector); */
   std::pair<unsigned int, unsigned int> getWindVector() const;
   void setWindVector(unsigned int windSpeed, unsigned int windDirection);


   const RVRPerRunwayList& getRvrperRunway() const {return rvrperRunway;};
   void setRvrperRunway(const RVRPerRunwayList& _rvrperRunway) {rvrperRunway=_rvrperRunway;};

   
   //data area

 protected:

   // IOUpdateMeteoInfo::BodyInformation::periodInformation
   posix_time::ptime  startTimeAndDate;
   posix_time::ptime  endTimeAndDate;
   double              probability;

   // IOUpdateMeteoInfo::BodyInformation::meteorologicalInformation
   //
   // IOUpdateMeteoInfo::BodyInformation::
   //   meteorologicalInformation::meterological
   boost::optional<lcmeteo::TYPE_WIND_DIRECTION>            windDirection;
   boost::optional<lcmeteo::TYPE_WIND_SPEED>            	windSpeed;
   boost::optional<lcmeteo::TYPE_GUST_SPEED>            	gustSpeed;
   boost::optional<lcmeteo::TYPE_GUST_DIRECTION>            gustDirection;
   boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE>           airTemperature;
   boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE>     dewPointTemperature;
   boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY>     horizontalVisibility;
   boost::optional<lcmeteo::TYPE_QNH>                       qnh;
   boost::optional<lcmeteo::TYPE_CLOUD_BASE>            	cloudbase;
   std::string                     significantWeather;
   boost::optional<std::string>    significantWeatherQualifier;
   boost::optional<std::string>    significantWeatherPhenomenon;

   //
   // IOUpdateMeteoInfo::BodyInformation::meteorologicalInformation::
   std::string                     wetness;
   bool                            lvpActivation;
   boost::optional<std::string>    requiredILSCategory;
   bool                            deicing;
   RVRPerRunwayList                rvrperRunway;

   // inner calculations
   //   std::vector<unsigned int>                windVector;

   /*@param wind vector = (W, ø)  
     W: wind speed [kt]
     ø: Wind geographic orientation [deg]

     See [1].4.2.2
    */
   std::pair<unsigned int, unsigned int> windVector; // (W, ø)
};


/**class LpiMeteoInfoList

   Stores one IOUpdateMeteoInfo::Meteo element
*/
class LpiMeteoInfoList
{
public:
   LpiMeteoInfoList (){}
   virtual ~LpiMeteoInfoList () {}

   posix_time::ptime getMessageTimeandDate() const;
   void setMessageTimeandDate(posix_time::ptime _messageTimeandDate);

   std::string getAirport() const;
   void setAirport(std::string _airport);

   //std::vector<LpiMeteoInfo>  getMeteoInfo() const;
   const std::vector<LpiMeteoInfo>  & getMeteoInfo() const;
   
   void setMeteoInfo(const std::vector<LpiMeteoInfo> &newval);
   void addMeteoInfoElement(const LpiMeteoInfo &newval);

   
   void setCalculationReason(const LpiCalculationReason::LpiEnum & value)
   { calculationReason = value; }

   LpiCalculationReason::LpiEnum getCalculationReason() const
   { return calculationReason; }

   LpiMeteoTimeline getTimeline() const
   { return timeline; }

   void setTimeline (const LpiMeteoTimeline & t)
   { timeline = t; }

protected:
   
   posix_time::ptime  messageTimeandDate; //MessageIndentificacion::timeAndDate
   std::string        airport;            //MessageIndentificacion::airport
  
   LpiCalculationReason::LpiEnum   calculationReason; 
   std::vector<LpiMeteoInfo>       meteoInfo; // bodyInformation
   LpiMeteoTimeline                timeline;
};


typedef LpiMeteoInfoList LpiCreateMeteo; // IOMeteoInfo::Meteo at IOMeteo.idl
typedef LpiMeteoInfoList LpiUpdateMeteo; // IOMeteoInfo::Meteo at IOMeteo.idl
typedef std::vector<LpiCreateMeteo> LpiCreateMeteoList;
typedef std::vector<LpiUpdateMeteo> LpiUpdateMeteoList;


std::ostream& operator<< (std::ostream & out, const LpiCreateMeteoList & obj);

std::ostream& operator<< (std::ostream & out, const LpiMeteoInfoList & obj);

std::ostream& operator<< (std::ostream & out,
			  const std::vector<unsigned int> & windvect);

std::ostream& operator<< (std::ostream & out, const LpiMeteoInfo & meteoInfo);


std::ostream& operator<< (std::ostream & out, const RVRPerRunwayList & rvrrunway);


std::ostream& operator<< (std::ostream & out, const RVRPerRunway & runway);

#endif /* LPIMETEOINFO_H_ */
