// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 09:59:03 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIADAPTATIONALERT_KPIS_H_
#define LPIADAPTATIONALERT_KPIS_H_

#include <iostream>

class NegativeAlert
{
public:

  NegativeAlert(){}
  ~NegativeAlert(){}

  // getters
  const unsigned int getAlarmThreshold(void) const 
  { return this->_alarmThreshold;}
  const unsigned int getWarningThreshold(void) const 
  { return this->_warningThreshold;}

  // setters
  void setAlarmThreshold (const unsigned int value) 
  {this->_alarmThreshold = value;}
  void setWarningThreshold (const unsigned int value) 
  {this->_warningThreshold = value;}

private:
  unsigned int _alarmThreshold;
  unsigned int _warningThreshold;
};

class AbsoluteKPIs
{
public:
    AbsoluteKPIs(){}
    ~AbsoluteKPIs(){}

    // getters
    const NegativeAlert getNegativeAlert(void) const {return this->_negativeAlert;}

    // setters
    void setNegativeAlert(const NegativeAlert value) {this->_negativeAlert = value;}

private:
    NegativeAlert _negativeAlert;
};


class Complexity
{
public:
    Complexity(){}
    ~Complexity(){}

    // getters
    const AbsoluteKPIs getAirportsComplexity(void) const {return this->_airportsComplexity;}
    const AbsoluteKPIs getModulesComplexity(void) const {return this->_modulesComplexity;}

    // setters
    void setAirportsComplexity(const AbsoluteKPIs value) {this->_airportsComplexity = value;}
    void setModulesComplexity(const AbsoluteKPIs value) {this->_modulesComplexity = value;}


private:
    AbsoluteKPIs _airportsComplexity;
    AbsoluteKPIs _modulesComplexity;
};

class LpiAdaptationAlert_KPIs
{

public:
    LpiAdaptationAlert_KPIs() {}
    ~LpiAdaptationAlert_KPIs() {}

    // getters
    const AbsoluteKPIs getSimultaneousOpsHour(void) const {return this->_simultaneousOpsHour;}
    const AbsoluteKPIs getTotalMov(void) const {return this->_totalMov;}
    const Complexity getComplexity(void) const {return this->_complexity;}
    const AbsoluteKPIs getVfr(void) const {return this->_vfr;}

    // setters
    void setSimultaneousOpsHour(const AbsoluteKPIs value) {this->_simultaneousOpsHour = value;}
    void setTotalMov(const AbsoluteKPIs value) {this->_totalMov = value;}
    void setComplexity(const Complexity value) {this->_complexity = value;}
    void setVfr(const AbsoluteKPIs value) {this->_vfr = value;}

private:
    AbsoluteKPIs _simultaneousOpsHour;
    AbsoluteKPIs _totalMov;
    Complexity _complexity;
    AbsoluteKPIs _vfr;
};

std::ostream & operator<<(std::ostream & out, const LpiAdaptationAlert_KPIs & confParams);

#endif /* LPICONFIGURATIONALERT_KPIS_H_ */
