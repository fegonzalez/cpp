/*
 * LpiCapacityInfo.h
 *
 *  Created on: 26/02/2015
 *      Author: mbegega
 */

#ifndef LPICAPACITYINFO_H_
#define LPICAPACITYINFO_H_

#include <string>
#include <vector>

#include "LpiADO.h"
#include "LpiWarningsAlerts.h"

using std::string;
using std::vector;


class LpiRunwayIntervalCapacityInfo
{
   public:
      LpiRunwayIntervalCapacityInfo() {}
      LpiRunwayIntervalCapacityInfo (const LpiRunwayIntervalCapacityInfo &source);
      virtual ~LpiRunwayIntervalCapacityInfo () {}

      LpiRunwayIntervalCapacityInfo & operator= (const LpiRunwayIntervalCapacityInfo & source);

      //Getters
      const string          & getrwyName             () const { return r_rwyName; }
      const LpiADO          & getrwyCapacity         () const { return r_rwyCapacity; }
      const Warnings_alerts & getrwyCapacityWA       () const { return r_rwyCapacityWA; }

      //Setters
      void setrwyName             (const string          &name) { r_rwyName = name; }
      void setrwyCapacity         (const LpiADO          &aux)  { r_rwyCapacity = aux; }
      void setrwyCapacityWA       (const Warnings_alerts &aux)  { r_rwyCapacityWA = aux; }

   private:

      string              r_rwyName;
      LpiADO              r_rwyCapacity;
      Warnings_alerts     r_rwyCapacityWA;
};


class LpiAirportIntervalCapacityInfo
{
   public:
      LpiAirportIntervalCapacityInfo() {}
      LpiAirportIntervalCapacityInfo (const LpiAirportIntervalCapacityInfo &source);
      virtual ~LpiAirportIntervalCapacityInfo () {}

      LpiAirportIntervalCapacityInfo & operator= (const LpiAirportIntervalCapacityInfo & source);

      //Getters
      const LpiADO          & getmaxCapacity      () const { return r_maxCapacity;      }
      const Warnings_alerts & getmaxCapacityWA    () const { return r_maxCapacityWA;    }
      const LpiADO          & gettwyCapacity      () const { return r_twyCapacity;      }
      const Warnings_alerts & gettwyCapacityWA    () const { return r_twyCapacityWA;    }
      const LpiADO          & getrsCapacity       () const { return r_rsCapacity;       }
      const Warnings_alerts & getrsCapacityWA     () const { return r_rsCapacityWA;     }

      //Setters
      void setmaxCapacity      (const LpiADO          &aux) { r_maxCapacity = aux;       }
      void setmaxCapacityWA    (const Warnings_alerts &aux) { r_maxCapacityWA = aux;     }
      void settwyCapacity      (const LpiADO          &aux) { r_twyCapacity = aux;       }
      void settwyCapacityWA    (const Warnings_alerts &aux) { r_twyCapacityWA = aux;     }
      void setrsCapacity       (const LpiADO          &aux) { r_rsCapacity = aux;        }
      void setrsCapacityWA     (const Warnings_alerts &aux) { r_rsCapacityWA = aux;      }

   private:
      LpiADO              r_maxCapacity;
      Warnings_alerts     r_maxCapacityWA;
      LpiADO              r_twyCapacity;
      Warnings_alerts     r_twyCapacityWA;
      LpiADO              r_rsCapacity;
      Warnings_alerts     r_rsCapacityWA;
};


class LpiCapacityIntervalData
{
   public:
      LpiCapacityIntervalData() {}

      //Getters
      const string & getName() const
      { return r_name; }

      const string & getBeginTime() const
      { return r_begin_time; }

      const string & getEndTime() const
      { return r_end_time; }

      LpiRunwayIntervalCapacityInfo getRwysCapacities(int i) const;
      std::vector<LpiRunwayIntervalCapacityInfo> getAllRwysCapacities() const;

      LpiAirportIntervalCapacityInfo getAirportCapacities() const
      { return r_airportCapacities; }

      //Setters
      void setName(const string & name)
      { r_name = name; }

      void setBeginTime(const string & begin_time)
      { r_begin_time = begin_time; }

      void setEndTime(const string & end_time)
      { r_end_time = end_time; }

      void setRwysCapacities(int i, const LpiRunwayIntervalCapacityInfo & source);
      void setAllRwysCapacities(const std::vector<LpiRunwayIntervalCapacityInfo> source);

      void setAirportIntervalCapacities(const LpiAirportIntervalCapacityInfo & source)
      { r_airportCapacities = source; }

   private:

      string r_name;
      string r_begin_time;
      string r_end_time;

      vector<LpiRunwayIntervalCapacityInfo> r_runwaysCapacities;
      LpiAirportIntervalCapacityInfo r_airportCapacities;
};


class LpiCapacityInfo
{
   public:
      LpiCapacityInfo() {}

      //Getters
      std::vector<LpiCapacityIntervalData> getCapacityTimeLine() const
      { return r_capacityTimeLine; }

      LpiCapacityIntervalData getCapacityIntervalData(int i) const;

      //Setters
      void setCapacityIntervalData(int i, const LpiCapacityIntervalData & source);
      void setAllCapacityIntervalData(const std::vector<LpiCapacityIntervalData> & source);

   private:

      std::vector<LpiCapacityIntervalData> r_capacityTimeLine;
};


#endif /* LPICAPACITYINFO_H_ */
