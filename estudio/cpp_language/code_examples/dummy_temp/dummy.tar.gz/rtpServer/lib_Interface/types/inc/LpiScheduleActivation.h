#if !defined(__LPISCHEDULEACTIVATION__)
#define __LPISCHEDULEACTIVATION__


#include <iostream>

class LpiScheduleActivation
{
public:
   LpiScheduleActivation () {}
   virtual  ~LpiScheduleActivation () {}

   // getters
   const int getScheduleId() const{ return _sch_id; }

   // setters
   void setScheduleId(const int sch_id){ _sch_id = sch_id; }


   // testers

private:

   int                _sch_id;

};
#endif // __LPISCHEDULEACTIVATION__
