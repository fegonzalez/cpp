/*
 * LpiWhatIfClosure.h
 *
 *  Created on: 18/05/2015
 *      Author: mbegega
 *
 *  Data model for what if received inputs
 *
 */

#ifndef LPIWHATIFCLOSURE_H_
#define LPIWHATIFCLOSURE_H_

#include <string>
#include <vector>
#include <boost/optional.hpp>

#include "LpiCalculationReason.h"
#include "LpiRunwayClosure.h"

class LpiBestPointClosure
{
   public:

      LpiBestPointClosure();

      const LpiRunwayClosure & getClosure() const
      { return r_closure; }

      unsigned int getDuration() const
      { return r_duration; }

      unsigned int getMinutesSubInterval() const
      { return r_minutesSubInterval;}

      void setClosure(const LpiRunwayClosure & closure)
      { r_closure = closure; }

      void setDuration(unsigned int duration)
      { r_duration = duration; }

      void setMinutesSubInterval(unsigned int minutes)
      { r_minutesSubInterval = minutes; }

      int getNumberOfOptions() const;
      boost::optional<LpiRunwayClosure> getOption(int optionId) const;

   protected:

      LpiRunwayClosure r_closure;
      unsigned int r_duration;
      unsigned int r_minutesSubInterval;
};

std::ostream & operator<< (std::ostream & os, const LpiBestPointClosure & closure);


class LpiWhatIfClosure
{
   public:

      enum LpiWhatIfClosureType { E_UNKNOWN = 0,
                                  E_APPLY_ON_ACTIVE,
                                  E_NEW_OPTIMAL,
                                  E_BEST_POINT_FOR_CLOSURE,
                                  E_BEST_POINT_CLOSURE_FOR_ACTIVE };

      LpiWhatIfClosure();

      void setId(int id)
      { r_id = id; }

      void setName(const std::string & name)
      { r_name = name; }

      void setAvoidAutoDelete(bool value)
      { r_avoidAutomaticDeletion = value; }

      void setWhatIfClosureType(const LpiWhatIfClosure::LpiWhatIfClosureType & closureType)
      { r_closureType = closureType; }

      void setRunwayClosures(const std::vector<LpiRunwayClosure> & closures)
      { r_runwayClosures = closures; }

      void setBestPointClosure(const LpiBestPointClosure & closure)
      { r_bestPointClosure = closure; }

      int getId() const
      { return r_id; }

      const std::string & getName() const
      { return r_name; }

      bool getAvoidAutomaticDeletion() const
      { return r_avoidAutomaticDeletion; }

      const LpiWhatIfClosure::LpiWhatIfClosureType & getClosureType() const
      { return r_closureType; }

      const std::vector<LpiRunwayClosure> & getClosures() const
      { return r_runwayClosures; }

      const LpiBestPointClosure & getBestPointClosure() const
      { return r_bestPointClosure; }

      int getNumberOfRunways() const
      { return r_runwayClosures.size(); }

      bool isBestPointClosureType() const;

      LpiCalculationReason::LpiEnum getAssociatedCalculationReason() const;
      LpiCalculationReason::LpiEnum getAssociatedCalculationReasonForUpdate() const;

      static std::string ClosureTypeToString(const LpiWhatIfClosure::LpiWhatIfClosureType & closureType);

   protected:

      int r_id;
      std::string r_name;
      bool r_avoidAutomaticDeletion;
      LpiWhatIfClosureType r_closureType;

      std::vector<LpiRunwayClosure> r_runwayClosures;
      LpiBestPointClosure r_bestPointClosure;
};


std::ostream & operator<< (std::ostream & os, const LpiWhatIfClosure & closures);

#endif /* LPIWHATIFCLOSURE_H_ */
