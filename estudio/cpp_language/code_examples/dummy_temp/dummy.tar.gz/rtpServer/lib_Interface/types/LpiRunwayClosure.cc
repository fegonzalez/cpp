/*
 * LpiRunwayClosure.cc
 *
 *  Created on: 18/05/2015
 *      Author: mbegega
 */

#include "LpiRunwayClosure.h"


LpiRunwayClosure::LpiRunwayClosure()
: r_runwayId(),
  r_startTime(),
  r_endTime(),
  r_reason(LpiClosureReason::E_NONE)
{
}


LpiRunwayClosure::LpiRunwayClosure(const std::string & runway,
                                   const boost::posix_time::ptime & startTime,
                                   const boost::posix_time::ptime & endTime,
                                   const LpiClosureReason::LpiEnum & reason)
: r_runwayId(runway),
  r_startTime(startTime),
  r_endTime(endTime),
  r_reason(reason)
{
}


LpiRunwayClosure::LpiRunwayClosure(const LpiRunwayClosure & source)
: r_runwayId(source.r_runwayId),
  r_startTime(source.r_startTime),
  r_endTime(source.r_endTime),
  r_reason(source.r_reason)
{
}


LpiRunwayClosure::~LpiRunwayClosure()
{
}


LpiRunwayClosure & LpiRunwayClosure::operator= (const LpiRunwayClosure & source)
{
   if (this != &source)
   {
      r_runwayId = source.r_runwayId;
      r_startTime = source.r_startTime;
      r_endTime = source.r_endTime;
      r_reason = source.r_reason;
   }

   return *this;
}


const std::string & LpiRunwayClosure::getRunwayId() const
{
   return r_runwayId;
}


const boost::posix_time::ptime & LpiRunwayClosure::getStartTime() const
{
   return r_startTime;
}


const boost::posix_time::ptime & LpiRunwayClosure::getEndTime() const
{
   return r_endTime;
}


const LpiClosureReason::LpiEnum & LpiRunwayClosure::getReason() const
{
   return r_reason;
}


std::ostream & operator<<(std::ostream &os, const LpiRunwayClosure & closure)
{
   return os << "[RWY : " << closure.getRunwayId()
             << " | START: "<< closure.getStartTime()
             << " | END: "<< closure.getEndTime()
             << " | REASON: " << closure.getReason() << ']';
}
