/*
 *
 *
 *  Created on: 05/06/2018
 *      Author: ctudela
 */

#include <iostream>
#include "LpiAdaptationMrtmInfo.h"


std::ostream& operator<< (std::ostream & out, const LpiAdaptationMrtmInfo & mrtm)
{
	out << "File: " << __FILE__
	    << " ; fn: " << __func__
	    << " ; line: " << __LINE__
		<< "\n";

	out << "[mrtmAvailable: " << mrtm.getMrtmAvailable() << "\n"
	       << " |mrtmAfisAirports: " << mrtm.getMrtmAfisAirports() << "\n"
	       << " |mrtmAtsAirports: " << mrtm.getMrtmAtsAirports() << "\n"
	       << " |maxTotalMov: " << mrtm.getMaxTotalMov() << "\n"
	       << " |maxSimultaneousOpsHour: " << mrtm.getMaxSimultaneousOpsHour() << "\n"
	       << " |simultaneousOpsTime: " << mrtm.getSimultaneousOpsTime() << "\n"
	       << " |mrtmStayTime: " << mrtm.getMrtmStayTime() << "\n"
	       << " |complexityThresholds: " << "\n";

	ComplexityThresholds wt = mrtm.getWorkloadThresholds();
	out << " \t|totalMovMrtmUpperThreshold: " << wt.getTotalMovMrtmUpperThreshold() << "\n"
	       << " \t|totalMovMrtmLowerThreshold: " << wt.getTotalMovMrtmLowerThreshold() << "\n"
	       << " \t|simultaneousOpsHour: \n";

	SimultaneousOpsHour sim = wt.getSimultaneousOpsHour();
	out << " \t\t|complexityDEPDEP: " << sim.getComplexityDEPDEP() << "\n"
        << " \t\t|complexityARRDEP: " << sim.getComplexityARRDEP() << "\n"
        << " \t\t|complexityARRARR: " << sim.getComplexityARRARR() << "\n";

	out << " \t|vfrMrtmUpperThreshold: " << wt.getVfrMrtmUpperThreshold() << "\n"
        << " \t|vfrMrtmLowerThreshold: " << wt.getVfrMrtmLowerThreshold() << "]\n";


	return out;
}


