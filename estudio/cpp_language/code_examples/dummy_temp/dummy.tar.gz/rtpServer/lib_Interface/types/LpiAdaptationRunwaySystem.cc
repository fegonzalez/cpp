#include <string>
#include "LpiAdaptationRunwaySystem.h"

LpiAdaptationRunwaySystem::LpiAdaptationRunwaySystem() {
    _name = "";
    _LVPFeasibility = false;
    _configuration = "";
    _runwaySystem.clear();
}

std::ostream & operator<<(std::ostream & out, const OperationType::Enum & op)
{
   std::string type;

   switch (op)
   {
      case OperationType::E_INVALID_RWY_OPERATION_TYPE:
         type= "NONE";
      break;
      case OperationType::E_DEPARTURES:
         type= "DEP";
      break;
      case OperationType::E_ARRIVALS:
         type= "ARR";
      break;
      case OperationType::E_MIXED:
         type= "MIX";
      break;
   }

   return out << type;
}


std::ostream & operator<<(std::ostream & out, const LpiAdaptationRunwaySystemList & runwSystemList)
{
   for(unsigned int i = 0; i < runwSystemList.size(); i++)
   {
      out << "\nCONFIG: " << runwSystemList[i].getConfiguration() <<
            " | RS: " << runwSystemList[i].getNameRunwaySystem() <<
            " | RWYS: [";

      for(unsigned int j = 0; j < runwSystemList[i].getRunwaySystem().size(); j++)
      {
         out << "(RWY: " << runwSystemList[i].getRunwaySystemByIndex(j).getrunwayId() <<
               " | OP: " << runwSystemList[i].getRunwaySystemByIndex(j).getNameOperation() << ") | ";
      }

      out << "]";
   }

   return out;
}
