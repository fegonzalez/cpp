
#include "LpiRunwaySystemUse.h"


std::ostream& operator <<(std::ostream &os,
                          const LpiRunwaySystemUse::LpiEnum &obj)
{
   switch (obj)
   {
      case LpiRunwaySystemUse::E_ONE_SEGREGATED_EACH_USE:
         os << "1ARR-1DEP";
      break;

      case LpiRunwaySystemUse::E_MULTIPLE_SEGREGATED_EACH_USE:
         os << "XARR-YDEP";
      break;

      case LpiRunwaySystemUse::E_MIXED:
         os << "MIXED";
      break;

      case LpiRunwaySystemUse::E_SEGREGATED_AND_MIXED:
         os << "SEGREGATED AND MIXED";
      break;

      default:
         os << "UNKNOWN";
      break;
   }

   return os;
}
