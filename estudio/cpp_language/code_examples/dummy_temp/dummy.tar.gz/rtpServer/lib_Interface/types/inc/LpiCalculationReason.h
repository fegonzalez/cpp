#ifndef LPICALCULATION_REASON_H_
#define LPICALCULATION_REASON_H_

#include <iostream>

class LpiCalculationReason
{
   public:
      enum LpiEnum
      {
         E_INIT = 0,
         E_NEW_METEO_NOWCAST,
         E_NEW_METEO_FORECAST,
         E_NEW_DEMAND,
         E_CLOCK,
         E_MANUAL_ACTIVATION,
         E_AIRPORT_OPERATIONAL_STATUS_CHANGE,
         E_WHAT_IF_NEW_CRITERIA,
         E_WHAT_IF_NEW_CRITERIA_UPDATE,
         E_WHAT_IF_MANUAL_EDITION,
         E_WHAT_IF_MANUAL_EDITION_UPDATE,
         E_WHAT_IF_DELETION,
         E_WHAT_IF_APPLY_ON_ACTIVE,
         E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE,
         E_WHAT_IF_NEW_OPTIMAL,
         E_WHAT_IF_NEW_OPTIMAL_UPDATE,
         E_WHAT_IF_BEST_POINT_CLOSURE,
         E_WHAT_IF_BEST_POINT_CLOSURE_UPDATE,
         E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE,
         E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE_UPDATE
      };
};


std::ostream& operator << (std::ostream &os,
                           const LpiCalculationReason::LpiEnum &obj);


#endif
