/*
 * LpiPriorityTable.h
 *
 *  Created on: 24/06/2015
 *      Author: mbegega
 */

#ifndef __LPIPRIORITYTABLE_H__
#define __LPIPRIORITYTABLE_H__

#include <iostream>
#include <map>
#include <vector>
#include "LpiFPCharacteristic.h"

using std::ostream;
using std::map;
using std::vector;

class LpiFlightPlan;

class LpiPriorityTable
{
   public:

      LpiPriorityTable();

      LpiPriorityTable & addCharacteristicDepartures(int priorityLevel,
                                           const LpiFPCharacteristic::LpiEnum & characteristic);
      vector<LpiFPCharacteristic::LpiEnum> getCharacteristicsDepartures (int priorityLevel);

      int getPriorityOfCharacteristicDepartures(const LpiFPCharacteristic::LpiEnum & characteristic);

      const map<int, vector<LpiFPCharacteristic::LpiEnum> > & getPrioritiesTableDepartures() const;

      int calculatePriorityDepartures(const LpiFlightPlan & fp);


      LpiPriorityTable & addCharacteristicArrivals(int priorityLevel,
                                                 const LpiFPCharacteristic::LpiEnum & characteristic);
      vector<LpiFPCharacteristic::LpiEnum> getCharacteristicsArrivals (int priorityLevel);

      int getPriorityOfCharacteristicArrivals(const LpiFPCharacteristic::LpiEnum & characteristic);

      const map<int, vector<LpiFPCharacteristic::LpiEnum> > & getPrioritiesTableArrivals() const;

      int calculatePriorityArrivals(const LpiFlightPlan & fp);

   private:

      //This map will store all characteristics grouped by priority level (key)
      //used to find characteristics by level
      map<int, vector<LpiFPCharacteristic::LpiEnum> > r_prioritiesTableDepartures;

      //This map will store characteristics (key) and their priorities, used for O(1) access to priority
      //by characteristic
      map<LpiFPCharacteristic::LpiEnum, int>          r_characteristicsDepartures;


      //This map will store all characteristics grouped by priority level (key)
      //used to find characteristics by level
      map<int, vector<LpiFPCharacteristic::LpiEnum> > r_prioritiesTableArrivals;

      //This map will store characteristics (key) and their priorities, used for O(1) access to priority
      //by characteristic
      map<LpiFPCharacteristic::LpiEnum, int>          r_characteristicsArrivals;
};


ostream & operator<< (ostream & out, const LpiPriorityTable & table);

#endif /* __LPIPRIORITYTABLE_H__ */
