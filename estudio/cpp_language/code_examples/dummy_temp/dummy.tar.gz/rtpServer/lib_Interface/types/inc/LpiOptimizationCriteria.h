/*
 * LpiOptimizationCriteria.h
 *
 *  Created on: 06/03/2014
 *      Author: gpfernandez
 */

#ifndef LPIOPTIMIZATIONCRITERIA_H_
#define LPIOPTIMIZATIONCRITERIA_H_

#include <iostream>
#include <string>
#include <LctimTimeLine.h>

#include "LpiOptimizationCriteriaTimedData.h"
#include "LpiTimeParameters.h"


using std::string;

class LpiOptimizationCriteria
   {
   public:

      LpiOptimizationCriteria();
      LpiOptimizationCriteria(const LpiOptimizationCriteria & source);
      virtual ~LpiOptimizationCriteria() {}

      void init(const LpiTimeParameters & parameters,
                boost::posix_time::ptime begin_timestamp);

      LpiOptimizationCriteria & operator= (const LpiOptimizationCriteria & source);

      //Check if has data associated to one given interval name
      bool has_data(const string & interval_name);

      //Get one element from internal timeline for modification
      LpiOptimizationCriteriaTimedData & operator[] (const string & interval_name);

      int getId() const
      {
         return r_id;
      }

      void setId(int newId)
      {
         r_id = newId;
      }

      string getName() const
      {
         return r_name;
      }

      void setName(string name)
      {
         r_name = name;
      }

      double getDcbWeight() const
      {
         return r_dcb_weight;
      }

      void setDcbWeight(double dcbWeight)
      {
         r_dcb_weight = dcbWeight;
      }

      double getRsPreferenceWeight() const
      {
         return r_rs_preference_weight;
      }

      void setRsPreferenceWeight(double rsPreferenceWeight)
      {
         r_rs_preference_weight = rsPreferenceWeight;
      }

      double getSuitabilityWeight() const
      {
         return r_suitability_weight;
      }

      void setSuitabilityWeight(double suitabilityWeight)
      {
         r_suitability_weight = suitabilityWeight;
      }

      bool getAvoidAutomaticDeletion() const
      { return r_avoidAutomaticDeletion; }

      void setAvoidAutomaticDeletion(bool deletion)
      { r_avoidAutomaticDeletion = deletion; }

      TimeLine<LpiOptimizationCriteriaTimedData> & getTimeLine ();
      const TimeLine<LpiOptimizationCriteriaTimedData> & getTimeLine () const;

   private:

      int r_id;
      string r_name;
      double r_dcb_weight;
      double r_suitability_weight;
      double r_rs_preference_weight;
      bool r_avoidAutomaticDeletion;

      TimeLine<LpiOptimizationCriteriaTimedData> r_timeLine;
   };


std::ostream & operator<<(std::ostream & out, const LpiOptimizationCriteria & criteria);

#endif
