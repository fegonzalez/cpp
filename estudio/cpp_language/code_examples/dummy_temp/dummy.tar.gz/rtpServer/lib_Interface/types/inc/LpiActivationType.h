// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):     icima
 Created:   10/4/2015 11:01:51 2015
 Release:   $Revision$
 Modified:  $Date$
 Path:      $Source$
*/
//---------------------------------------------------------------------------
#ifndef LPIACTIVATIONTYPE_H_
#define LPIACTIVATIONTYPE_H_

#include <string>
#include <iostream>

class LpiActivationType
{
   public:
        enum ActivationType{
            E_PREFERENTIAL = 0,
            E_OPTIMAL,
            E_WHAT_IF_1,
            E_WHAT_IF_2,
            E_WHAT_IF_3_ACTIVE,
            E_WHAT_IF_3_NEW_SOLUTION,
            E_WHAT_IF_3_BEST_POINT,
            E_WHAT_IF_3_BEST_POINT_FOR_ACTIVE
        };
};


inline std::ostream & operator<< (std::ostream & out, const LpiActivationType::ActivationType & activation)
{
   std::string result;

   switch (activation)
   {
      case LpiActivationType::E_PREFERENTIAL:
         result = "PREFERENTIAL";
      break;
      case LpiActivationType::E_OPTIMAL:
         result = "OPTIMAL";
      break;
      case LpiActivationType::E_WHAT_IF_1:
         result = "WHAT-IF NEW CRITERIA";
      break;
      case LpiActivationType::E_WHAT_IF_2:
         result = "WHAT-IF MANUAL EDITION";
      break;
      case LpiActivationType::E_WHAT_IF_3_ACTIVE:
         result = "WHAT-IF CLOSURES, ACTIVE";
      break;
      case LpiActivationType::E_WHAT_IF_3_NEW_SOLUTION:
         result = "WHAT-IF CLOSURES, NEW SOLUTION";
      break;
      case LpiActivationType::E_WHAT_IF_3_BEST_POINT:
         result = "WHAT-IF CLOSURES, BEST POINT";
      break;
      case LpiActivationType::E_WHAT_IF_3_BEST_POINT_FOR_ACTIVE:
         result = "WHAT-IF CLOSURES, BEST POINT FOR ACTIVE SCHEDULE";
      break;
      default:
      break;
   }

   return out << result;
}


#endif /* LPIACTIVATIONTYPE_H_ */
