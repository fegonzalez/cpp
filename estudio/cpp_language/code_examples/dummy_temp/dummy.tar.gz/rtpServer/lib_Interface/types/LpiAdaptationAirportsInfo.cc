#include <string>

#include "LpiAdaptationAirportsInfo.h"


//-----------------------------------------------------------------------------

Max_ILS_Category::Max_ILS_Category(const std::string & value)
{
  if(value == "NO_ILS")
    _enumMax_ILS_Category = Max_ILS_Category::NO_ILS;
  else if(value == "CAT_I")
    _enumMax_ILS_Category = Max_ILS_Category::CAT_I;
  else if(value == "CAT_II")
    _enumMax_ILS_Category = Max_ILS_Category::CAT_II;
  else if(value == "CAT_III_A")
    _enumMax_ILS_Category = Max_ILS_Category::CAT_III_A;
  else if(value == "CAT_III_B")
    _enumMax_ILS_Category = Max_ILS_Category::CAT_III_B;
  else if(value == "CAT_III_C")
    _enumMax_ILS_Category = Max_ILS_Category::CAT_III_C;
  //error inoput => default value
  else
  {
    _enumMax_ILS_Category = Max_ILS_Category::NO_ILS;
    std::cerr << "INVALID ILS:" << value << std::endl;
    assert(false);//for development debug purpose only
  }
}

//-----------------------------------------------------------------------------

// Convert Enum to string
std::string Max_ILS_Category::toString() const
{
  std::string result;
  switch(EnumMax_ILS_Category())
    {
    case Max_ILS_Category::NO_ILS:
      result = "NO_ILS";
      break;
    case Max_ILS_Category::CAT_I:
      result = "CAT_I";
      break;
    case Max_ILS_Category::CAT_II:
      result = "CAT_II";
      break;
    case Max_ILS_Category::CAT_III_A:
      result = "CAT_III_A";
      break;
    case Max_ILS_Category::CAT_III_B:
      result = "CAT_III_B";
      break;
    case Max_ILS_Category::CAT_III_C:
      result = "CAT_III_C";
      break;
    }
  return result;
}

//-----------------------------------------------------------------------------

bool Max_ILS_Category::operator<(const EnumMax_ILS_Category &other) const
{
  if (EnumMax_ILS_Category() == other)
    return false;

  switch(EnumMax_ILS_Category())
  {
  case Max_ILS_Category::NO_ILS:
    return true;
    break;

  case Max_ILS_Category::CAT_I:
    return (not (other == Max_ILS_Category::NO_ILS));
    break;

  case Max_ILS_Category::CAT_II:
    return ( (not (other == Max_ILS_Category::NO_ILS)) and 
	     (not (other == Max_ILS_Category::CAT_I)) );
    break;
    
  case Max_ILS_Category::CAT_III_A:
    return ( (not (other == Max_ILS_Category::NO_ILS)) and 
	     (not (other == Max_ILS_Category::CAT_I))  and 
	     (not (other == Max_ILS_Category::CAT_II)) );
    break;
    
  case Max_ILS_Category::CAT_III_B: 
    return (other == Max_ILS_Category::CAT_III_C);
    break;

  case Max_ILS_Category::CAT_III_C:
    return false;
    break;
  };
}

//=============================================================================

bool LpiAdaptationAirportsInfo::exists (const std::string & id) const
{
  bool retval =  false;
  
   for (unsigned int i = 0; i < _airport.size(); ++i)
   {
       if(id.compare(_airport[i].getAirportName()) == 0)
       {
	 retval = true;
	 break;
       }
   }
   return retval;
}

//-----------------------------------------------------------------------------

const Airport LpiAdaptationAirportsInfo::operator[](const std::string & id) const
{
  Airport  notFoundValue;

   for (unsigned int i = 0; i < _airport.size(); ++i)
   {
       if(id.compare(_airport[i].getAirportName()) == 0)
       {
	      return _airport[i];
       }
   }

   return notFoundValue;
}


//-----------------------------------------------------------------------------

std::ostream & operator<<(std::ostream & out, 
			  const LpiAdaptationAirportsInfo & airportInfo)
{

    AirportVector list = airportInfo.getAirport();
    for (unsigned int i = 0; i < list.size(); i++){
         out << "[AIRPORT: \n";

         Airport airport = airportInfo.getAirport().at(i);
         out << " \t|airportName: " << airport.getAirportName() << "\n";

         AirportType airportType = airport.getAirportType();
         AirportType::EnumAirportType type = airportType.operator enum AirportType::EnumAirportType();
         if (type == 0)
             out << " \t|airportType: " << "AFIS \n";
         else if (type == 1)
         out << " \t|airportType: " << "ATS \n";

         out << " \t|airportMaxNominalCapacity: \n"
             << " \t\t|arrivalsValue: " << airportInfo.getAirport().at(i).getAirportMaxNominal().getArrivalsValue() << "\n"
             << " \t\t|departuresValue: " << airportInfo.getAirport().at(i).getAirportMaxNominal().getDeparturesValue() << "\n"
             << " \t\t|overallValue: " << airportInfo.getAirport().at(i).getAirportMaxNominal().getOverallValue() << "\n";

         out << " \t|taxywaysMaxNominalCapacity: " << airportInfo.getAirport().at(i).getTaxywaysMaxNominalCapacity() << "\n";
         out << " \t|tmaMaxNominalCapacity: " << airportInfo.getAirport().at(i).getTmaMaxNominalCapacity() << "\n";

         Max_ILS_Category::EnumMax_ILS_Category maxIls = airportInfo.getAirport().at(i).getAirportMaxILsCategory().operator enum Max_ILS_Category::EnumMax_ILS_Category();
         if (maxIls == Max_ILS_Category::EnumMax_ILS_Category::NO_ILS)
             out << " \t|airportMaxILsCategory: " << "NO_ILS\n";
         else if(maxIls == Max_ILS_Category::EnumMax_ILS_Category::CAT_I)
             out << " \t|airportMaxILsCategory: " << "CAT_I\n";
         else if(maxIls == Max_ILS_Category::EnumMax_ILS_Category::CAT_II)
             out << " \t|airportMaxILsCategory: " << "CAT_II\n";
         else if(maxIls == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_A)
             out << " \t|airportMaxILsCategory: " << "CAT_III_A\n";
         else if(maxIls == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_B)
             out << " \t|airportMaxILsCategory: " << "CAT_III_B\n";
         else if(maxIls == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_C)
                       out << " \t\t|idCatILs: " << "CAT_III_C\n";

         out << " \t|runways: \n";
         RunwaysAirportsList rList = airport.getRunways();
         for(unsigned int j = 0; j < airport.getRunways().size(); j++)
         {
             double la1 = *rList.at(j).getRunwayThreshold1Latitude();
             double lo1 = *rList.at(j).getRunwayThreshold1Longitude();
             double la2 = *rList.at(j).getRunwayThreshold2Latitude();
             double lo2 = *rList.at(j).getRunwayThreshold2Longitude();

             out << " \t\t|runway: \n"
                 << " \t\t\t|runwayName: " << rList.at(j).getRunwayName() << "\n";
                 if(la1 > 0 && (lo1 > 0))
                 {
                     out << " \t\t\t|runwayThreshold1Latitude: " << la1 << "\n"
                             << " \t\t\t|runwayThreshold1Longitude: " << lo1 << "\n";
                 }
                 if(la2 > 0 && lo2 > 0){
                     out << " \t\t\t|runwayThreshold2Latitude: " << la2 << "\n"
                             << " \t\t\t|runwayThreshold2Longitude: " << lo2 << "\n";
                 }
                 out << " \t\t\t|crosswindUpperThresholdDry: " << rList.at(j).getCrosswindUpperThresholdDry() << "\n"
                 << " \t\t\t|crosswindLowerThresholdDry: " << rList.at(j).getCrosswindLowerThresholdDry() << "\n"
                 << " \t\t\t|crosswindUpperThresholdWet: " << rList.at(j).getCrosswindUpperThresholdWet() << "\n"
                 << " \t\t\t|crosswindLowerThresholdWet: " << rList.at(j).getCrosswindLowerThresholdWet() << "\n"
                 << " \t\t\t|crosswindMinReduction: " << rList.at(j).getCrosswindMinReduction() << "\n"
                 << " \t\t\t|tailwindUpperThresholdDry: " << rList.at(j).getTailwindUpperThresholdDry() << "\n"
                 << " \t\t\t|tailwindLowerThresholdDry: " << rList.at(j).getTailwindLowerThresholdDry() << "\n"
                 << " \t\t\t|tailwindUpperThresholdWet: " << rList.at(j).getTailwindUpperThresholdWet() << "\n"
                 << " \t\t\t|tailwindLowerThresholdWet: " << rList.at(j).getTailwindLowerThresholdWet() << "\n"
                 << " \t\t\t|tailwindMinReduction: " << rList.at(j).getTailwindMinReduction() << "\n"
                 << " \t\t\t|horizontalVisibilityUpperThreshold: " << rList.at(j).getHorizontalVisibilityUpperThreshold() << "\n"
                 << " \t\t\t|horizontalVisibilityLoweThreshold: " << rList.at(j).getHorizontalVisibilityLoweThreshold() << "\n"
                 << " \t\t\t|horizontalMinReduction: " << rList.at(j).getHorizontalMinReduction() << "\n";
         }
         out << " \t|lvpActivationConditions: \n";
         LvpActivacionConditonsList lpiLvpActivacionConditonsList = airport.getLvpActivationConditions();
         for(unsigned int j = 0; j < lpiLvpActivacionConditonsList.size(); j++)
         {
             out << " \t\t|condition: \n"
                 << " \t\t\t|conditionName: " << lpiLvpActivacionConditonsList.at(j).getConditionName() << "\n"
                 << " \t\t\t|conditionValue: " << lpiLvpActivacionConditonsList.at(j).getConditionValue() << "\n";
         }

         out << " \t|catILs: \n";

         CatILsList catILs = airport.getCatILs();
         for(unsigned int j = 0; j < catILs.size(); j++)
         {
             out << " \t\t|catIL: \n";
             Max_ILS_Category::EnumMax_ILS_Category max = catILs.at(j).getIdCatILs().operator enum Max_ILS_Category::EnumMax_ILS_Category();
              if (max == Max_ILS_Category::EnumMax_ILS_Category::NO_ILS)
                  out << " \t\t\t|idCatILs: " << "NO_ILS\n";
              else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_I)
                  out << " \t\t\t|idCatILs: " << "CAT_I\n";
              else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_II)
                  out << " \t\t\t|idCatILs: " << "CAT_II\n";
              else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_A)
                  out << " \t\t\t|idCatILs: " << "CAT_III_A\n";
              else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_B)
                  out << " \t\t\t|idCatILs: " << "CAT_III_B\n";
              else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_C)
                  out << " \t\t\t|idCatILs: " << "CAT_III_C\n";

             if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_I)
             {
                  Bound cloudBase = *catILs.at(j).getCloudBase();
                  out << " \t\t\t|cloudBase: \n"
                      << " \t\t\t\t|upperBound: " << cloudBase.getUpperBound() << "\n"
                      << " \t\t\t\t|lowerBound: " << cloudBase.getLowerBound() << "\n"
                      << " \t\t\t|rvrType: \n";

                  Bound rvrType = catILs.at(j).getRvrType();
                  out << " \t\t\t\t|upperBound: " << rvrType.getUpperBound() << "\n"
                      << " \t\t\t\t|lowerBound: " << rvrType.getLowerBound() << "\n"
                      << " \t\t\t|horizontalVisibility: \n";

                  Bound horizontalVisibility = *catILs.at(j).getHorizontalVisibility();
                  out << " \t\t\t\t|upperBound: " << horizontalVisibility.getUpperBound() << "\n"
                      << " \t\t\t\t|lowerBound: " << horizontalVisibility.getLowerBound() << "\n";
             }
             else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_II
                     || max == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_A
                     || max == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_B)
             {
                  Bound cloudBase = *catILs.at(j).getCloudBase();

                  out << " \t\t\t|cloudBase: \n"
                      << " \t\t\t\t|upperBound: " << cloudBase.getUpperBound() << "\n"
                      << " \t\t\t\t|lowerBound: " << cloudBase.getLowerBound() << "\n"
                      << " \t\t\t|rvrType: \n";

                  Bound rvrType = catILs.at(j).getRvrType();
                  out << " \t\t\t\t|upperBound: " << rvrType.getUpperBound() << "\n"
                      << " \t\t\t\t|lowerBound: " << rvrType.getLowerBound() << "\n";
             }
             else if(max == Max_ILS_Category::EnumMax_ILS_Category::CAT_III_C)
             {
                  Bound rvrType = catILs.at(j).getRvrType();
                  out << " \t\t\t|rvrType: \n"
                      << " \t\t\t\t|upperBound: " << rvrType.getUpperBound() << "\n"
                      << " \t\t\t\t|lowerBound: " << rvrType.getLowerBound() << "\n";
             }
         }

         ComplexityAirportsThresholds comp = airport.getComplexityThresholds();
         out << " \t|WorkloadThresholds: \n"
             << " \t\t|totalMovAirportUpperThreshold: " << comp.getTotalMovAirportUpperThreshold() << "\n"
             << " \t\t|totalMovAirportLowerThreshold: " << comp.getTotalMovAirportLowerThreshold() << "\n"
             << " \t\t|vfrAirportUpperThreshold: " << comp.getVfrAirportUpperThreshold() << "\n"
             << " \t\t|vfrAirportLowerThreshold: " << comp.getVfrAirportLowerThreshold() << "]\n\n";
    }
   return out;
}
