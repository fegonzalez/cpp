/*
 * LpiGetWakeVortexCapacityReductions.h
 *
 *  Created on: 23 ago. 2017
 *      Author: cgudin
 */

#ifndef C___LPIWAKEVORTEXCAPACITYREDUCTIONS_H_
#define C___LPIWAKEVORTEXCAPACITYREDUCTIONS_H_

#include <map>
#include <string>
#include <vector>
#include <iostream>

#include "LpiComposedKey.h"
#include "LpiADOVector.h"

#include <LcuDataTypeUtils.h>

using std::map;
using std::string;
using std::vector;




//Wake Vortex Conditions Internal Block

class LpiWakeVortexConditions
{
   public:
      LpiWakeVortexConditions();
      LpiWakeVortexConditions(float maxValue,
                         float minValue,
                         string wtc_type);

      LpiWakeVortexConditions(const LpiWakeVortexConditions & source);

      LpiWakeVortexConditions & operator= (const LpiWakeVortexConditions & source);
      bool operator== (const LpiWakeVortexConditions & source) const;

      float getMaxValue() const;
      float getMinValue() const;
      string getWtcType() const;

   protected:
      float _maxValue;
      float _minValue;
      string _wtcType;
};


ostream & operator<< (ostream & os, const LpiWakeVortexConditions & conditions);


// Individual file reduction: WakeVortex conditions block + composed key map

class LpiWTCReduction
{
   public:
      LpiWTCReduction();
      LpiWTCReduction(vector<LpiWakeVortexConditions> conditions, float reduction);
      LpiWTCReduction(const LpiWTCReduction & source);


      LpiWTCReduction & operator= (const LpiWTCReduction & source);
      bool operator== (const vector<LpiWakeVortexConditions> & source);

      vector<LpiWakeVortexConditions>   getWakeVortexConditions() const;
      float getReduction () const;

   protected:

      vector<LpiWakeVortexConditions> _conditions;
      float _reduction;
};


ostream & operator<< (ostream & os, const LpiWTCReduction & reduction);


// File capacity reductions: Vector of -> Meteo conditions block + composed key map

class LpiWakeVortexCapacityReductions
{
   public:
      //Create
      LpiWakeVortexCapacityReductions();
      LpiWakeVortexCapacityReductions(const LpiWakeVortexCapacityReductions & source);

      //Get ADO Vector with reduction from WakeVortex Condition RS, and RWY
      float getReductionARR (const vector<LpiWakeVortexConditions> & conditionsARR) const;
      float getReductionDEP (const vector<LpiWakeVortexConditions> & conditionsDEP) const;
      float getReductionOVA (const vector<LpiWakeVortexConditions> & conditionsOVA) const;


      //Add rule to WTC Block and RS-RWY
      void addWTCReductionARR(
                           const vector<LpiWakeVortexConditions> &conditionsARR,
                           const float &reduction);
      void addWTCReductionDEP(
                           const vector<LpiWakeVortexConditions> &conditionsDEP,
                           const float &reduction);
      void addWTCReductionOVA(
                           const vector<LpiWakeVortexConditions> &conditionsOVA,
                           const float &reduction);

      vector<LpiWTCReduction> getReductionsARR() const;
      vector<LpiWTCReduction> getReductionsDEP() const;
      vector<LpiWTCReduction> getReductionsOVA() const;


   protected:
      vector<LpiWTCReduction> _reductionsARR;
      vector<LpiWTCReduction> _reductionsDEP;
      vector<LpiWTCReduction> _reductionsOVA;
};


ostream & operator<< (ostream & os, const LpiWakeVortexCapacityReductions & reductions);


#endif /* C___LPIWAKEVORTEXCAPACITYREDUCTIONS_H_ */
