/*
 * LpiRunway.cc
 *
 *  Created on: 02/12/2013
 *      Author: gpfernandez
 */
#include "LpiRunway.h"

std::ostream & operator<<(std::ostream & os, const LpiRunway &obj )
{
   os << "NameRunway: " <<obj._name;
   os << "IdRunway: " <<obj._id;
   return os;
}



