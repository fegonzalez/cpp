#if !defined(__LPITIMEPARAMETERS__)
#define __LPITIMEPARAMETERS__

#include <LplcTypeConstants.h>

#include <iostream>

class LpiTimeParameters
{
   public:

      const unsigned int getHoursWindow(void) const {return this->r_hoursWindow;}
      const unsigned int getMinutesSubinterval(void) const {return this->r_minutesSubinterval;}
      const unsigned int getMinutesFrozen(void) const {return this->r_minutesFrozen;}
      const unsigned int getMinutesFrozenForClock(void) const {return this->r_minutesFrozenForClock;}

      // setters
      void setHoursWindow(unsigned int HoursWindow)  {this->r_hoursWindow= HoursWindow;}
      void setMinutesSubinterval(unsigned int MinutesSubinterval)  {this->r_minutesSubinterval= MinutesSubinterval;}
      void setMinutesFrozen(unsigned int MinutesFrozen)  {this->r_minutesFrozen = MinutesFrozen;}
      void setMinutesFrozenForClock(unsigned int MinutesFrozen)  {this->r_minutesFrozenForClock = MinutesFrozen;}

   private:

      unsigned int r_hoursWindow = rtp_constants::CORECONFIG_HOURS_WINDOW_DEFAULT_VALUE;
      unsigned int r_minutesSubinterval = rtp_constants::CORECONFIG_MINUTES_SUBINTERVAL_DEFAULT_VALUE;
      unsigned int r_minutesFrozen = rtp_constants::CORECONFIG_MINUTES_FROZEN_DEFAULT_VALUE;
      unsigned int r_minutesFrozenForClock = rtp_constants::CORECONFIG_MINUTES_FROZEN_FOR_CLOCK_DEFAULT_VALUE;
};

std::ostream & operator<<(std::ostream & out,
                          const LpiTimeParameters & timeParameters);

#endif // __LPITIMEPARAMETERS__
