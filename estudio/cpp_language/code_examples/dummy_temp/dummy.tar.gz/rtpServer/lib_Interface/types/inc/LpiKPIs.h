/*
 * LpiKPIs.h
 *
 *  Created on: 26/02/2015
 *      Author: mbegega
 */

#ifndef LPIKPIS_H_
#define LPIKPIS_H_

#include "LpiADO.h"
#include "LpiWarningsAlerts.h"
#include "LpiComparativeKpis.h"

class LpiRunwayIntervalKPIs
{
   public:

      LpiRunwayIntervalKPIs (){}
      LpiRunwayIntervalKPIs (const LpiRunwayIntervalKPIs &source);
      virtual  ~LpiRunwayIntervalKPIs () {}

      LpiRunwayIntervalKPIs & operator= (const LpiRunwayIntervalKPIs & source);

      //getters
      const string          & getrwyName             () const { return rwyName; }

      const LpiADO          & getrwyRealAcceptedFps  () const { return rwyRealAcceptedFps; }
      const Warnings_alerts & getrwyRealAcceptedFpsWA() const { return rwyRealAcceptedFpsWA; }
      const LpiADO          & getrwyShortage         () const { return rwyShortage; }
      const Warnings_alerts & getrwyShortageWA       () const { return rwyShortageWA; }

      const LpiADO          & getRwyAverageDelay_DelayedFPs() const { return rwyAverageDelay_DelayedFPs; }
      const Warnings_alerts & getRwyAverageDelay_DelayedFPsWA() const { return rwyAverageDelay_DelayedFPsWA; }
      const LpiADO          & getRwyMaxForecastedDelay() const { return rwyMaxForecastedDelay; }
      const Warnings_alerts & getRwyMaxForecastedDelayWA() const { return rwyMaxForecastedDelayWA; }
      const LpiADO          & getRwyPercentagePunctuality() const { return rwyPercentagePunctuality; }
      const Warnings_alerts & getRwyPercentagePunctualityWA() const { return rwyPercentagePunctualityWA; }
      const LpiADO          & getRwyPunctualFlights() const { return rwyPunctualFlights;       }
      const LpiADO          & getRwyAverageForecastedDelay() const { return rwyAverageForecastedDelay;}
      const LpiADO          & getRwyDemandForecast() const { return rwyDemandForecast;}
      const LpiADO          & getRwyAcceptedFpsOwnInterval() const { return rwyAcceptedFpsOwnInterval; }
      const LpiADO          & getRwyNotPunctualFlights() const { return rwyNotPunctualFlights;       }
      const LpiADO          & getRwyNumberOfDelayedFlights() const { return rwyNumberOfDelayedFlights; }

      //setters
      void setrwyName             (const string          &name) { rwyName = name; }

      void setrwyRealAcceptedFps  (const LpiADO          &aux)  { rwyRealAcceptedFps = aux; }
      void setrwyRealAcceptedFpsWA(const Warnings_alerts &aux)  { rwyRealAcceptedFpsWA = aux; }
      void setrwyShortage         (const LpiADO          &aux)  { rwyShortage = aux; }
      void setrwyShortageWA       (const Warnings_alerts &aux)  { rwyShortageWA = aux; }

      void setRwyAverageDelay_DelayedFPs   (const LpiADO & aux)  { rwyAverageDelay_DelayedFPs = aux; }
      void setRwyAverageDelay_DelayedFPsWA (const Warnings_alerts & aux)  { rwyAverageDelay_DelayedFPsWA = aux; }
      void setRwyMaxForecastedDelay   (const LpiADO & aux)  { rwyMaxForecastedDelay = aux; }
      void setRwyMaxForecastedDelayWA (const Warnings_alerts & aux)  { rwyMaxForecastedDelayWA = aux; }
      void setRwyPercentagePunctuality (const LpiADO & aux)  { rwyPercentagePunctuality = aux; }
      void setRwyPercentagePunctualityWA (const Warnings_alerts &aux)  { rwyPercentagePunctualityWA = aux; }
      void setRwyPunctualFlights (const LpiADO & aux) { rwyPunctualFlights = aux; }
      void setRwyAverageForecastedDelay (const LpiADO & aux) { rwyAverageForecastedDelay = aux; }
      void setRwyDemandForecast (const LpiADO & aux) { rwyDemandForecast = aux; }
      void setRwyAcceptedFpsOwnInterval (const LpiADO & aux) { rwyAcceptedFpsOwnInterval = aux; }
      void setRwyNotPunctualFlights (const LpiADO & aux) { rwyNotPunctualFlights = aux; }
      void setRwyNumberOfDelayedFlights (const LpiADO & aux) { rwyNumberOfDelayedFlights = aux; }

   private:

      string              rwyName;

      LpiADO              rwyRealAcceptedFps;
      Warnings_alerts     rwyRealAcceptedFpsWA;
      LpiADO              rwyShortage;
      Warnings_alerts     rwyShortageWA;

      //Phase II
      LpiADO              rwyAverageDelay_DelayedFPs;
      Warnings_alerts     rwyAverageDelay_DelayedFPsWA;
      LpiADO              rwyMaxForecastedDelay;
      Warnings_alerts     rwyMaxForecastedDelayWA;
      LpiADO              rwyPercentagePunctuality;
      Warnings_alerts     rwyPercentagePunctualityWA;

      LpiADO              rwyPunctualFlights;
      LpiADO              rwyAverageForecastedDelay;
      LpiADO              rwyDemandForecast;
      LpiADO              rwyAcceptedFpsOwnInterval;
      LpiADO              rwyNotPunctualFlights;
      LpiADO              rwyNumberOfDelayedFlights;
};


class LpiAirportIntervalKPIs
{
   public:

     LpiAirportIntervalKPIs () {}
     LpiAirportIntervalKPIs (const LpiAirportIntervalKPIs & source);

     virtual  ~LpiAirportIntervalKPIs () {}

     LpiAirportIntervalKPIs & operator= (const LpiAirportIntervalKPIs & source);

     //getters
     const LpiADO          & getshortage         () const { return shortage;         }
     const Warnings_alerts & getshortageWA       () const { return shortageWA;       }
     const LpiADO          & getrealAcceptedFps  () const { return realAcceptedFps;  }
     const Warnings_alerts & getrealAcceptedFpsWA() const { return realAcceptedFpsWA;}

     const LpiADO          & getTotalRunwaysDemandForecast         ()const { return totalRunwaysDemandForecast;         }
     const LpiADO          & getAverageForecastedDelay_DelayedFPs  ()const { return averageForecastedDelay_DelayedFPs;  }
     const Warnings_alerts & getAverageForecastedDelay_DelayedFPsWA()const { return averageForecastedDelay_DelayedFPsWA;}
     const LpiADO          & getMaxForecastedDelay                 ()const { return maxForecastedDelay;                 }
     const Warnings_alerts & getMaxForecastedDelayWA               ()const { return maxForecastedDelayWA;               }
     const LpiADO          & getPunctuality                        ()const { return punctuality;                        }
     const Warnings_alerts & getPunctualityWA                      ()const { return punctualityWA;                      }
     const LpiADO          & getPercentagePunctuality              ()const { return percentagePunctuality;              }
     const Warnings_alerts & getPercentagePunctualityWA            ()const { return percentagePunctualityWA;            }

     //setters
     void setrealAcceptedFps  (const LpiADO          &aux) { realAcceptedFps = aux;   }
     void setrealAcceptedFpsWA(const Warnings_alerts &aux) { realAcceptedFpsWA = aux; }
     void setshortage         (const LpiADO          &aux) { shortage = aux;          }
     void setshortageWA       (const Warnings_alerts &aux) { shortageWA = aux;        }

     void setTotalRunwaysDemandForecast         (const LpiADO & aux) { totalRunwaysDemandForecast = aux; }
     void setAverageForecastedDelay_DelayedFPs  (const LpiADO & aux) { averageForecastedDelay_DelayedFPs  = aux; }
     void setAverageForecastedDelay_DelayedFPsWA(const Warnings_alerts & aux) { averageForecastedDelay_DelayedFPsWA= aux; }
     void setMaxForecastedDelay                 (const LpiADO & aux) { maxForecastedDelay                 = aux; }
     void setMaxForecastedDelayWA               (const Warnings_alerts & aux) { maxForecastedDelayWA      = aux; }
     void setPunctuality                        (const LpiADO & aux) { punctuality                        = aux; }
     void setPunctualityWA                      (const Warnings_alerts & aux) { punctualityWA             = aux; }
     void setPercentagePunctuality              (const LpiADO & aux) { percentagePunctuality              = aux; }
     void setPercentagePunctualityWA            (const Warnings_alerts & aux) { percentagePunctualityWA   = aux; }

   private:

     LpiADO              realAcceptedFps;
     Warnings_alerts     realAcceptedFpsWA;
     LpiADO              shortage;
     Warnings_alerts     shortageWA;

     //Phase II
     LpiADO              totalRunwaysDemandForecast;
     LpiADO              averageForecastedDelay_DelayedFPs;
     Warnings_alerts     averageForecastedDelay_DelayedFPsWA;
     LpiADO              maxForecastedDelay;
     Warnings_alerts     maxForecastedDelayWA;
     LpiADO              punctuality;
     Warnings_alerts     punctualityWA;
     LpiADO              percentagePunctuality;
     Warnings_alerts     percentagePunctualityWA;

};


std::ostream& operator<< (std::ostream &os, const LpiAirportIntervalKPIs & kpis);


class LpiAirportTotalKPIs
{
   public:

      LpiAirportTotalKPIs () {}
      LpiAirportTotalKPIs (const LpiAirportTotalKPIs & source);
      virtual ~LpiAirportTotalKPIs () {}

      LpiAirportTotalKPIs & operator= (const LpiAirportTotalKPIs & source);

      //Getters
      const LpiADO          & getTotalAccepted               () const { return r_totalAccepted; }
      const LpiADO          & getTotalShortage               () const { return r_totalShortage; }
      const LpiADO          & getmaxForecastedDelay          () const { return maxForecastedDelay; }
      const Warnings_alerts & getmaxForecastedDelayWA        () const { return maxForecastedDelayWA; }
      const LpiADO          & getaverageForecastedDelay      () const { return averageForecastedDelay; }
      const Warnings_alerts & getaverageForecastedDelayWA    () const { return averageForecastedDelayWA; }
      const LpiADO          & getmaxPunctualityDelay         () const { return maxPunctualityDelay; }
      const Warnings_alerts & getmaxPunctualityDelayWA       () const { return maxPunctualityDelayWA; }
      const LpiADO          & getaveragePunctualityDelay     () const { return averagePunctualityDelay; }
      const Warnings_alerts & getaveragePunctualityDelayWA   () const { return averagePunctualityDelayWA; }
      const LpiADO          & getpunctualFPs                 () const { return punctualFPs; }
      const LpiADO          & getdelayedFPs                  () const { return delayedFPs; }
      const LpiADO          & getpercentagePunctual          () const { return percentagePunctual; }
      const Warnings_alerts & getpercentagePunctualWA        () const { return percentagePunctualWA; }
      const LpiADO          & getAverageForecastedDelayDelayedFps  () const { return averageForecastedDelayDelayedFPs; }
      const Warnings_alerts & getAverageForecastedDelayDelayedFpsWA() const { return averageForecastedDelayDelayedFPsWA; }


      //Setters
      void setTotalAccepted               (const LpiADO & aux) { r_totalAccepted = aux; }
      void setTotalShortage               (const LpiADO & aux) { r_totalShortage = aux; }
      void setmaxForecastedDelay          (const LpiADO          &aux) { maxForecastedDelay = aux; }
      void setmaxForecastedDelayWA        (const Warnings_alerts &aux) { maxForecastedDelayWA = aux; }
      void setaverageForecastedDelay      (const LpiADO          &aux) { averageForecastedDelay = aux; }
      void setaverageForecastedDelayWA    (const Warnings_alerts &aux) { averageForecastedDelayWA = aux; }
      void setmaxPunctualityDelay         (const LpiADO          &aux) { maxPunctualityDelay = aux; }
      void setmaxPunctualityDelayWA       (const Warnings_alerts &aux) { maxPunctualityDelayWA = aux; }
      void setaveragePunctualityDelay     (const LpiADO          &aux) { averagePunctualityDelay = aux; }
      void setaveragePunctualityDelayWA   (const Warnings_alerts &aux) { averagePunctualityDelayWA = aux; }
      void setpunctualFPs                 (const LpiADO          &aux) { punctualFPs = aux; }
      void setdelayedFPs                  (const LpiADO          &aux) { delayedFPs = aux; }
      void setpercentagePunctual          (const LpiADO          &aux) { percentagePunctual = aux; }
      void setpercentagePunctualWA        (const Warnings_alerts &aux) { percentagePunctualWA = aux; }
      void setaverageForecastedDelayDelayedFPs   (const LpiADO     &aux) { averageForecastedDelayDelayedFPs = aux; }
      void setaverageForecastedDelayDelayedFPsWA (const Warnings_alerts &aux) { averageForecastedDelayDelayedFPsWA = aux; }

   private:

      LpiADO              r_totalAccepted;
      LpiADO              r_totalShortage;
      LpiADO              maxForecastedDelay;
      Warnings_alerts     maxForecastedDelayWA;
      LpiADO              averageForecastedDelay;
      Warnings_alerts     averageForecastedDelayWA;
      LpiADO              maxPunctualityDelay;
      Warnings_alerts     maxPunctualityDelayWA;
      LpiADO              averagePunctualityDelay;
      Warnings_alerts     averagePunctualityDelayWA;
      LpiADO              punctualFPs;
      Warnings_alerts     punctualFPsWA;
      LpiADO              delayedFPs;
      Warnings_alerts     delayedFPsWA;
      LpiADO              percentagePunctual;
      Warnings_alerts     percentagePunctualWA;
      LpiADO              averageForecastedDelayDelayedFPs;
      Warnings_alerts     averageForecastedDelayDelayedFPsWA;
};


class LpiPerformanceIntervalData
{
   public:

      LpiPerformanceIntervalData () {}
      LpiPerformanceIntervalData (const LpiPerformanceIntervalData &source);
      virtual  ~LpiPerformanceIntervalData () {}

      LpiPerformanceIntervalData & operator= (const LpiPerformanceIntervalData & source);

      //getters
      const string & getName() const
      { return r_name; }

      const string & getBeginTime() const
      { return r_begin_time; }

      const string & getEndTime() const
      { return r_end_time; }

      LpiRunwayIntervalKPIs getRwysKPIs(int i) const;
      std::vector<LpiRunwayIntervalKPIs> getRwysKPIs() const;

      LpiAirportIntervalKPIs getAirportIntevalKPIs() const
      { return r_airportKPIs; }

      //setters
      void setName(const string & name)
      { r_name = name; }

      void setBeginTime(const string & begin_time)
      { r_begin_time = begin_time; }

      void setEndTime(const string & end_time)
      { r_end_time = end_time; }

      void setRwysKPIs(int i, const LpiRunwayIntervalKPIs source);
      void setRwysKPIs(const std::vector<LpiRunwayIntervalKPIs> source);

      void setAirportIntervalKPIs(const LpiAirportIntervalKPIs & source)
      { r_airportKPIs = source; }

   private:
      string r_name;
      string r_begin_time;
      string r_end_time;

      std::vector<LpiRunwayIntervalKPIs> r_runwaysKPIs;
      LpiAirportIntervalKPIs    r_airportKPIs;
};


class LpiPerformanceInfo
{
   public:

      LpiPerformanceInfo() {}

      //Getters
      LpiAirportTotalKPIs getAirportTotalKPIs() const
      { return r_airportTotalKPIs; }

      LpiComparativeKpis getComparativeKPIs() const
      { return r_comparativeKPIs; }

      std::vector<LpiPerformanceIntervalData> getPerformanceTimeLine() const
      { return r_performanceTimeLine; }

      LpiPerformanceIntervalData getPerformanceIntervalData(int i) const;

      //Setters
      void setAirportTotalKPIs(const LpiAirportTotalKPIs & source)
      { r_airportTotalKPIs = source; }

      void setComparativeKPIs(const LpiComparativeKpis & source)
      { r_comparativeKPIs = source; }

      void setPerformanceIntervalData(int i, const LpiPerformanceIntervalData & source);
      void setAllPerformanceIntervalData(const std::vector<LpiPerformanceIntervalData> & source);

   private:

      LpiAirportTotalKPIs  r_airportTotalKPIs;
      LpiComparativeKpis   r_comparativeKPIs;
      std::vector<LpiPerformanceIntervalData> r_performanceTimeLine;
};


#endif /* LPIKPIS_H_ */
