/*
 * LpiMeteoTimeline.h
 *
 *  Created on: 19/03/2015
 *      Author: mbegega
 */

#ifndef LPIMETEOTIMELINE_H_
#define LPIMETEOTIMELINE_H_

#include <vector>
#include <string>
#include <iostream>

#include <boost/optional.hpp>

using std::vector;
using std::string;
using boost::optional;

class LpiMeteoIntervalData
{
   public:

      LpiMeteoIntervalData(optional<double> horizontalVisibility,
                           string wetness,
                           string ilsCategory,
                           optional<bool> lvpActivation,
                           optional<bool> deicingRequired,
                           /* optional<double> crosswind, */
                           /* optional<double> tailwind, */
                           optional<unsigned int> windSpeed,
                           optional<unsigned int> windDirection
                           );

      const optional<double> & getHorizontalVisibility() const
      { return r_horizontalVisibility; }

      const string & getWetness() const
      { return r_wetness; }

      const string & getILSCategory() const
      { return r_ilsCategory; }

      const optional<bool> & getLVPActivation() const
      { return r_lvpActivation; }

      const optional<bool> & getDeicingRequired() const
      { return r_deicingRequired; }

//      const optional<double> & getCrosswind() const
//      { return r_crosswind; }
//
//      const optional<double> & getTailwind() const
//      { return r_tailwind; }

      const optional<unsigned int> & getWindSpeed() const
      { return r_windSpeed; }

      const optional<unsigned int> & getWindDirection() const
      { return r_windDirection; }

   private:

      optional<double> r_horizontalVisibility;
      string r_wetness;
      string r_ilsCategory;

      optional<bool>  r_lvpActivation;
      optional<bool>  r_deicingRequired;
//      optional<double> r_crosswind;
//      optional<double> r_tailwind;

      optional<unsigned int> r_windSpeed;
      optional<unsigned int> r_windDirection;

      //AKI: habría que meter  RVR info para tener cross y tailwind
      //  por pista  o HMI lo puede leer del report normal (LpiMeteoInfo) ?

};



class LpiMeteoInterval
{
   public:

  LpiMeteoInterval(const std::string & name,
		   const std::string & beginTime,
		   const std::string & endTime,
		   const LpiMeteoIntervalData & data);

      //Getters
      const string & getName() const
      { return r_name; }

      const string & getBeginTime() const
      { return r_beginTime; }

      const string & getEndTime() const
      { return r_endTime; }

      const LpiMeteoIntervalData & getData() const
      { return r_data; }

   private:

      string r_name;
      string r_beginTime;
      string r_endTime;

      LpiMeteoIntervalData r_data;
};


class LpiMeteoTimeline
{
   public:

      LpiMeteoTimeline();

      const LpiMeteoInterval & operator[] (unsigned int index) const;
      //      void setValue(const unsigned int &index, const LpiMeteoInterval& value);
      LpiMeteoInterval & operator[] (unsigned int index);

      void push_back(const LpiMeteoInterval &);

      
      const vector<LpiMeteoInterval> & getAllScheduleIntervals() const
      { return r_meteoIntervals; }

      void setAllScheduleIntervals(const vector<LpiMeteoInterval> & source)
      { r_meteoIntervals = source; }

      void clear();

      size_t size()const { return r_meteoIntervals.size(); }
  
   private:

      vector<LpiMeteoInterval> r_meteoIntervals;
};


std::ostream& operator<< (std::ostream & out, const LpiMeteoTimeline & obj);
std::ostream& operator<< (std::ostream & out, const LpiMeteoInterval & obj);
std::ostream& operator<< (std::ostream & out, const LpiMeteoIntervalData & obj);

#endif /* LPIMETEOTIMELINE_H_ */
