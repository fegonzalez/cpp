#ifndef LPIRUNWAYSYSTEM_USE_H_
#define LPIRUNWAYSYSTEM_USE_H_

#include <iostream>

class LpiRunwaySystemUse
{
public:
   enum LpiEnum
   {
      E_ONE_SEGREGATED_EACH_USE = 0,
      E_MULTIPLE_SEGREGATED_EACH_USE,
      E_MIXED,
      E_SEGREGATED_AND_MIXED,
      E_UNKNOWN
  };
};


std::ostream& operator <<(std::ostream &os,
                                         const LpiRunwaySystemUse::LpiEnum &obj);


#endif
