/*
 * LxiADO.h
 *
 *  Created on: 02/12/2013
 *      Author: gpfernandez
 */

#ifndef LPIADO_H_
#define LPIADO_H_

#include <iostream>
#include <vector>
#include "LpiADOVector.h"
#include "LpiAdaptationRunwaySystem.h"
#include <LcuDataTypeUtils.h>


class LpiADO
{
public:

   LpiADO (float initialValue = 0.0);

   LpiADO (float arrivals, float departures, float overall)
   : _arrivalsValue(arrivals), _departuresValue(departures), _overallValue(overall)
   {}

   float & operator[] (int index);
   float   operator[] (int index) const;

   // getters
   float getarrivalsValue(void) const {return this->_arrivalsValue;}
   float getdeparturesValue(void) const {return this->_departuresValue;}
   float getoverallValue(void) const {return this->_overallValue;}

   // setters
   void setarrivalsValue(float value) {this->_arrivalsValue = value;}
   void setdeparturesValue(float value) {this->_departuresValue = value;}
   void setoverallValue(float value) {this->_overallValue = value;}

   void setAllValues (float value);

   LpiADO & operator= (const LpiADO & source);

   operator LpiADOVector<int>()
   {
      int arrivals   = static_cast<int>(_arrivalsValue);
      int departures = static_cast<int>(_departuresValue);
      int overall    = static_cast<int>(_overallValue);

      return LpiADOVector<int>(arrivals, departures, overall);
   }

   operator LpiADOVector<double>()
   {
      return LpiADOVector<double>(_arrivalsValue, _departuresValue, _overallValue);
   }
   operator LpiADOVector<long>()
   {
      return LpiADOVector<long>(_arrivalsValue, _departuresValue, _overallValue);
   }

   static LpiADO convert2Interface (const LpiADOVector<int> & in);
   static LpiADO convert2Interface (const LpiADOVector<double> & in);

   //Sets a special tag (-1) in "not used" components
   static LpiADO tagNoUsageComponents (const OperationType::Enum & runway_usage,
                                       const LpiADO & in);

private:
   float _arrivalsValue;
   float _departuresValue;
   float _overallValue;

};


inline bool operator== (const LpiADO & left, const LpiADO & right)
{
   bool result = false;

   if (LcuDataTypeUtils::double_equals(left.getarrivalsValue(),right.getarrivalsValue())
   	   && LcuDataTypeUtils::double_equals(left.getdeparturesValue(), right.getdeparturesValue())
       && LcuDataTypeUtils::double_equals(left.getoverallValue(), right.getoverallValue()))
   {
      result = true;
   }

   return result;
}

inline bool operator!= (const LpiADO & left, const LpiADO & right)
{
   return !(left == right);
}


inline LpiADO operator+ (const LpiADO & left, const LpiADO & right)
{
   LpiADO result = left;
   result[E_ARR]+= right[E_ARR];
   result[E_DEP]+= right[E_DEP];
   result[E_OVA]+= right[E_OVA];

   return result;
}


std::ostream & operator<<(std::ostream & out, const LpiADO & obj);


class LpiADOConverter
{
   public:
      static LpiADO Convert2Interface(const LpiADOVector<int> & in)
      {
         LpiADO out;

         out.setarrivalsValue(static_cast<float>(in[E_ARR]));
         out.setdeparturesValue(static_cast<float>(in[E_DEP]));
         out.setoverallValue(static_cast<float>(in[E_OVA]));

         return out;
      };

      static LpiADO Convert2Interface(const LpiADOVector<double> & in)
      {
         LpiADO out;

         out.setarrivalsValue(static_cast<float>(in[E_ARR]));
         out.setdeparturesValue(static_cast<float>(in[E_DEP]));
         out.setoverallValue(static_cast<float>(in[E_OVA]));

         return out;
      };
};

#endif /* LPIADO_H_ */
