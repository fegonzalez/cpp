

#include "LpiSchedulesComparison.h"


LpiSchedulesComparison::LpiSchedulesComparison(int leftOperandId,  string leftOperandName,
                                               int rightOperandId, string rightOperandName)
: r_left_operand_id(leftOperandId),
  r_left_operand_name(leftOperandName),
  r_right_operand_id(rightOperandId),
  r_right_operand_name(rightOperandName)
{
}


LpiSchedulesComparison::LpiSchedulesComparison(const LpiSchedulesComparison& source)
: r_left_operand_id(source.r_left_operand_id),
  r_left_operand_name(source.r_left_operand_name),
  r_right_operand_id(source.r_right_operand_id),
  r_right_operand_name(source.r_right_operand_name)
{
}


LpiSchedulesComparison & LpiSchedulesComparison::operator= (const LpiSchedulesComparison& source)
{
   if (this != &source)
   {
      r_left_operand_id = source.r_left_operand_id;
      r_left_operand_name = source.r_left_operand_name;
      r_right_operand_id = source.r_right_operand_id;
      r_right_operand_name = source.r_right_operand_name;
   }

   return *this;
}


std::ostream & operator<< (std::ostream & out, const LpiSchedulesComparison & operands)
{
   out << "[LEFT ID : " << operands.getLeftOperandId()
       << " | NAME : "  << operands.getLeftOperandName()
       << " | RIGHT ID: " << operands.getRightOperandId()
       << " | NAME : "    << operands.getRightOperandName()
       << ']';

   return out;
}


std::ostream & operator<< (std::ostream & out, const LpiSchedulesComparisonResponse & operands)
{
   out << static_cast<LpiSchedulesComparison>(operands) << '\n'
       << operands.getKpis();

   return out;
}
