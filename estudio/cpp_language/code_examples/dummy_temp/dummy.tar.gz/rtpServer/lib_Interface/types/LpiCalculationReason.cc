
#include "LpiCalculationReason.h"


std::ostream& operator << (std::ostream &os,
                           const LpiCalculationReason::LpiEnum & obj)
{
   switch (obj)
   {
      case LpiCalculationReason::E_INIT:
         os << "Initialization";
      break;

      case LpiCalculationReason::E_NEW_METEO_NOWCAST:
         os << "Meteo Nowcast Reception";
      break;

      case LpiCalculationReason::E_NEW_METEO_FORECAST:
         os << "Meteo Forecast Reception";
      break;

      case LpiCalculationReason::E_NEW_DEMAND:
         os << "Demand Reception";
      break;

      case LpiCalculationReason::E_CLOCK:
         os << "Clock Event";
      break;

      case LpiCalculationReason::E_MANUAL_ACTIVATION:
         os << "Optimal Schedule Activation";
      break;

      case LpiCalculationReason::E_AIRPORT_OPERATIONAL_STATUS_CHANGE:
         os << "Airport Operational Status Change";
      break;

      case LpiCalculationReason::E_WHAT_IF_NEW_CRITERIA:
         os << "What if: New Criteria";
      break;

      case LpiCalculationReason::E_WHAT_IF_NEW_CRITERIA_UPDATE:
         os << "What if: New Criteria Update";
      break;

      case LpiCalculationReason::E_WHAT_IF_MANUAL_EDITION:
         os << "What if: Manual Edition";
      break;

      case LpiCalculationReason::E_WHAT_IF_MANUAL_EDITION_UPDATE:
         os << "What if: Manual Edition Update";
      break;

      case LpiCalculationReason::E_WHAT_IF_DELETION:
         os << "What if: Deletion";
      break;

      case LpiCalculationReason::E_WHAT_IF_APPLY_ON_ACTIVE:
         os << "What if: Apply closures on Active";
      break;

      case LpiCalculationReason::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE:
         os << "What if: Apply closures on Active Update";
      break;

      case LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE:
         os << "What if: Best point for closure selection";
      break;

      case LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_UPDATE:
         os << "What if: Best point for closure selection update";
      break;

      default:
         os << "Unknown";
      break;
   }

   return os;
}
