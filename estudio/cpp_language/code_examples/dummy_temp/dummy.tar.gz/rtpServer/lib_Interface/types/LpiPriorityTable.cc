/*
 * LpiPriorityTable.cc
 *
 *  Created on: 24/06/2015
 *      Author: mbegega
 */

#include <sstream>
#include <algorithm>
#include <boost/foreach.hpp>
#include "LpiPriorityTable.h"
#include "LpiFlightPlan.h"


LpiPriorityTable::LpiPriorityTable ()
: r_prioritiesTableDepartures(),
  r_characteristicsDepartures(),
  r_prioritiesTableArrivals(),
  r_characteristicsArrivals()
{
}


LpiPriorityTable & LpiPriorityTable::addCharacteristicDepartures(int priorityLevel,
                                                       const LpiFPCharacteristic::LpiEnum & characteristic)
{
   if (r_prioritiesTableDepartures.find(priorityLevel) == r_prioritiesTableDepartures.end())
   {
      vector<LpiFPCharacteristic::LpiEnum> characteristics;
      characteristics.push_back(characteristic);
      r_prioritiesTableDepartures[priorityLevel] = characteristics;
   }
   else
   {
      vector<LpiFPCharacteristic::LpiEnum> characteristics = r_prioritiesTableDepartures[priorityLevel];

      vector<LpiFPCharacteristic::LpiEnum>::iterator it = std::find(r_prioritiesTableDepartures[priorityLevel].begin(),
                                              r_prioritiesTableDepartures[priorityLevel].end(),
                                              characteristic);
      if (it == r_prioritiesTableDepartures[priorityLevel].end())
      {
         r_prioritiesTableDepartures[priorityLevel].push_back(characteristic);
      }
   }

   r_characteristicsDepartures[characteristic] = priorityLevel;

   return *this;
}

LpiPriorityTable & LpiPriorityTable::addCharacteristicArrivals(int priorityLevel,
                                                       const LpiFPCharacteristic::LpiEnum & characteristic)
{
   if (r_prioritiesTableArrivals.find(priorityLevel) == r_prioritiesTableArrivals.end())
   {
      vector<LpiFPCharacteristic::LpiEnum> characteristics;
      characteristics.push_back(characteristic);
      r_prioritiesTableArrivals[priorityLevel] = characteristics;
   }
   else
   {
      vector<LpiFPCharacteristic::LpiEnum> characteristics = r_prioritiesTableArrivals[priorityLevel];

      vector<LpiFPCharacteristic::LpiEnum>::iterator it = std::find(r_prioritiesTableArrivals[priorityLevel].begin(),
                                              r_prioritiesTableArrivals[priorityLevel].end(),
                                              characteristic);
      if (it == r_prioritiesTableArrivals[priorityLevel].end())
      {
         r_prioritiesTableArrivals[priorityLevel].push_back(characteristic);
      }
   }

   r_characteristicsArrivals[characteristic] = priorityLevel;

   return *this;
}


vector<LpiFPCharacteristic::LpiEnum> LpiPriorityTable::getCharacteristicsDepartures(int priorityLevel)
{
   if (r_prioritiesTableDepartures.find(priorityLevel) == r_prioritiesTableDepartures.end())
   {
      return vector<LpiFPCharacteristic::LpiEnum>();
   }

   return r_prioritiesTableDepartures[priorityLevel];
}

vector<LpiFPCharacteristic::LpiEnum> LpiPriorityTable::getCharacteristicsArrivals(int priorityLevel)
{
   if (r_prioritiesTableArrivals.find(priorityLevel) == r_prioritiesTableArrivals.end())
   {
      return vector<LpiFPCharacteristic::LpiEnum>();
   }

   return r_prioritiesTableArrivals[priorityLevel];
}


int LpiPriorityTable::getPriorityOfCharacteristicDepartures(const LpiFPCharacteristic::LpiEnum & characteristic)
{
   int result = 0;

   if (r_characteristicsDepartures.find(characteristic) != r_characteristicsDepartures.end())
   {
      result = r_characteristicsDepartures[characteristic];
   }

   return result;
}

int LpiPriorityTable::getPriorityOfCharacteristicArrivals(const LpiFPCharacteristic::LpiEnum & characteristic)
{
   int result = 0;

   if (r_characteristicsArrivals.find(characteristic) != r_characteristicsArrivals.end())
   {
      result = r_characteristicsArrivals[characteristic];
   }

   return result;
}


const map<int, vector<LpiFPCharacteristic::LpiEnum> > & LpiPriorityTable::getPrioritiesTableDepartures () const
{
   return r_prioritiesTableDepartures;
}

const map<int, vector<LpiFPCharacteristic::LpiEnum> > & LpiPriorityTable::getPrioritiesTableArrivals () const
{
   return r_prioritiesTableArrivals;
}


int LpiPriorityTable::calculatePriorityDepartures(const LpiFlightPlan & fp)
{
   int calculatedPriority = 0;

   typedef map<int, vector<LpiFPCharacteristic::LpiEnum> >::value_type priorityElement;

   BOOST_FOREACH (const priorityElement & element, r_prioritiesTableDepartures)
   {
      vector<LpiFPCharacteristic::LpiEnum> characteristics = element.second;

      for (unsigned int i = 0; i < characteristics.size(); ++i)
      {
         if (fp.hasCharacteristic(characteristics[i]))
         {
            calculatedPriority = element.first;

            return calculatedPriority;
         }
      }
   }

   return calculatedPriority;
}


int LpiPriorityTable::calculatePriorityArrivals(const LpiFlightPlan & fp)
{
   int calculatedPriority = 0;

   typedef map<int, vector<LpiFPCharacteristic::LpiEnum> >::value_type priorityElement;

   BOOST_FOREACH (const priorityElement & element, r_prioritiesTableArrivals)
   {
      vector<LpiFPCharacteristic::LpiEnum> characteristics = element.second;

      for (unsigned int i = 0; i < characteristics.size(); ++i)
      {
         if (fp.hasCharacteristic(characteristics[i]))
         {
            calculatedPriority = element.first;

            return calculatedPriority;
         }
      }
   }

   return calculatedPriority;
}


ostream & operator<< (ostream & out, const LpiPriorityTable & table)
{
   const map<int, vector<LpiFPCharacteristic::LpiEnum> > & prioritiesTableDepartures = table.getPrioritiesTableDepartures();

   typedef map<int, vector<LpiFPCharacteristic::LpiEnum> >::value_type priorityElementDepartures;

   const map<int, vector<LpiFPCharacteristic::LpiEnum> > & prioritiesTableArrivals = table.getPrioritiesTableArrivals();

   typedef map<int, vector<LpiFPCharacteristic::LpiEnum> >::value_type priorityElementArrivals;

   BOOST_FOREACH (const priorityElementDepartures & element, prioritiesTableDepartures)
   {
      std::stringstream characteristicsStream;
      std::copy(element.second.begin(),
                element.second.end(),
                std::ostream_iterator<LpiFPCharacteristic::LpiEnum>(characteristicsStream, " "));

      out << element.first
          << ":[" << characteristicsStream.str()
          << "]\n";
   }

   BOOST_FOREACH (const priorityElementArrivals & element, prioritiesTableArrivals)
   {
       std::stringstream characteristicsStream;
       std::copy(element.second.begin(),
                 element.second.end(),
                 std::ostream_iterator<LpiFPCharacteristic::LpiEnum>(characteristicsStream, " "));

       out << element.first
               << ":[" << characteristicsStream.str()
               << "]\n";
   }

   return out;
}
