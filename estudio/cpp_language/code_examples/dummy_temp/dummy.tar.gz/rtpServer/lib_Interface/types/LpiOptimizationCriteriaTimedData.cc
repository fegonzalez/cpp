/*
 * LpiOptimizationCriteriaTimedData.cc
 *
 *  Created on: 12/09/2014
 *      Author: mbegega
 */

#include "LpiOptimizationCriteriaTimedData.h"

LpiOptimizationCriteriaTimedData::LpiOptimizationCriteriaTimedData()
: r_arrivals_priority(0.0),
  r_departures_priority(0.0),
  r_type(E_AUTO)
{

}


LpiOptimizationCriteriaTimedData::LpiOptimizationCriteriaTimedData(float arrivalsPriority,
                                                                   float departuresPriority,
                                                                   CriteriaType type)
: r_arrivals_priority(arrivalsPriority),
  r_departures_priority(departuresPriority),
  r_type(type)
{

}


LpiOptimizationCriteriaTimedData::LpiOptimizationCriteriaTimedData(const LpiOptimizationCriteriaTimedData & source)
: r_arrivals_priority(source.r_arrivals_priority),
  r_departures_priority(source.r_departures_priority),
  r_type(source.r_type)
{

}


LpiOptimizationCriteriaTimedData & LpiOptimizationCriteriaTimedData::operator= (const LpiOptimizationCriteriaTimedData & source)
{
   if (this != &source)
   {
      r_arrivals_priority = source.r_arrivals_priority;
      r_departures_priority = source.r_departures_priority;
      r_type = source.r_type;
   }

   return *this;
}

string LpiOptimizationCriteriaTimedData::criteriaTypeToString(const CriteriaType & type)
{
   string result;

   switch(type)
   {
      case E_MANUAL:
         result = "MANUAL";
      break;
      case E_AUTO:
      default:
         result = "AUTO";
      break;
   }

   return result;
}


std::ostream& operator<<(std::ostream &os, const LpiOptimizationCriteriaTimedData &info)
{
   return os << "[TYPE :" << LpiOptimizationCriteriaTimedData::criteriaTypeToString(info.getCriteriaType())
             << ", ARR_PRIO:"  << info.getArrivalsPriority()
             << ", DEP_PRIO:" << info.getDeparturesPriority() << "]";
}
