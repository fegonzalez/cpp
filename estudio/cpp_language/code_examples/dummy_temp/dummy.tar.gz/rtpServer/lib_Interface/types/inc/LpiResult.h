
#if !defined(__LPI_RESULT__)
#define __LPI_RESULT__


#include <iostream>

class LpiResult
{
public:
   LpiResult();

   enum LpiEnum
   {
      E_NONE = 0,
      E_OK,
      E_NO_OK
   };

   const LpiResult::LpiEnum getResult(void) const {return this->_result;}
   void setResult(LpiResult::LpiEnum value) {this->_result = value;}

private:
       LpiEnum _result;
};



std::ostream & operator<<(std::ostream & os, const LpiResult & result);


#endif // __LPI_RESULT__
