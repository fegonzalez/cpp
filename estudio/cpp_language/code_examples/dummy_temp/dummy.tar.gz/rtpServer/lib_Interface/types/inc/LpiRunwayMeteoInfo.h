#ifndef LPI_RUNWAY_METEO_INFO_H_
#define LPI_RUNWAY_METEO_INFO_H_

#include <iostream>
#include <string>

using std::string;

class LpiRunwayMeteoInfo
{
public:
    LpiRunwayMeteoInfo();
    LpiRunwayMeteoInfo(const string& rwyId);
    LpiRunwayMeteoInfo(const string& rwyId, double cw, double tw);
    LpiRunwayMeteoInfo(const LpiRunwayMeteoInfo& source);

    LpiRunwayMeteoInfo& operator =(const LpiRunwayMeteoInfo& source);

    double getCrosswind() const;
    void   setCrosswind(double crosswind);

    string getRwyId() const;
    void   setRwyId(string rwyId);

    double getTailwind() const;
    void   setTailwind(double tailwind);

protected:
    string r_rwyId;
    double r_crosswind;
    double r_tailwind;
};


std::ostream& operator <<(std::ostream &os,
                                         const LpiRunwayMeteoInfo &obj);


#endif
