
#ifndef LPIADAPTATIONRUNWAY_H_
#define LPIADAPTATIONRUNWAY_H_

#include <vector>
#include <iostream>
#include "LpiMaxILSCategory.h"
#include "LpiRunway.h"
#include "LpiADO.h"
#include <boost/lexical_cast.hpp>


class LpiAdaptationRunway
{
public:

   LpiAdaptationRunway() {}
   ~LpiAdaptationRunway() {}

    // getters
    const LpiNameRunway getNameRunway(void)const {return this->r_name;}

    const  LpiMaxILSCategory::LpiEnumCatILS getILSRunway(void)const {return this->r_maxILSCategory;}
    const LpiADO getCapacityNominal(void)const {return this->r_maxNominalCapacity;}
    const double getThreshold1Latitude(void)const {return this->r_runwayThreshold1Latitude;}
    const double getThreshold2Latitude(void)const {return this->r_runwayThreshold2Latitude;}
    const double getThreshold1Longitude(void)const {return this->r_runwayThreshold1Longitude;}
    const double getThreshold2Longitude(void)const {return this->r_runwayThreshold2Longitude;}


    // setters
    void setNameRunway(const LpiNameRunway &name) {this->r_name = name;}

    void setILSRunway(const LpiMaxILSCategory::LpiEnumCatILS  &maxILS){this->r_maxILSCategory= maxILS;}

    void setCapacityNominal(const LpiADO  &maxNominalCapacity){this-> r_maxNominalCapacity= maxNominalCapacity;}
    void setThreshold1Latitude(const double &value){this->r_runwayThreshold1Latitude = value;}
    void setThreshold2Latitude(const double &value){this->r_runwayThreshold2Latitude = value;}
    void setThreshold1Longitude(const double &value){this->r_runwayThreshold1Longitude = value;}
    void setThreshold2Longitude(const double &value){this->r_runwayThreshold2Longitude = value;}

private:

    LpiNameRunway                       r_name;
    LpiMaxILSCategory::LpiEnumCatILS    r_maxILSCategory;
    LpiADO                              r_maxNominalCapacity;
    double                               r_runwayThreshold1Latitude;
    double                               r_runwayThreshold2Latitude;
    double                               r_runwayThreshold1Longitude;
    double                               r_runwayThreshold2Longitude;

};
 


typedef std::vector<LpiAdaptationRunway> LpiAdaptationRunwayList;

std::ostream & operator<<(std::ostream & out,
                          const LpiAdaptationRunwayList &obj);


#endif /* LPIADAPTATIONRUNWAY_H_ */
