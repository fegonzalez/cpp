/*
 * LpiSchedulesComparison.h
 *
 *  Created on: 07/01/2015
 *      Author: mbegega
 */

#ifndef LPISCHEDULESCOMPARISON_H_
#define LPISCHEDULESCOMPARISON_H_

#include <iostream>
#include <string>

#include "LpiComparativeKpis.h"

using std::string;

class LpiSchedulesComparison
{
   public:

      LpiSchedulesComparison () {}
      LpiSchedulesComparison(int leftOperandId,  string leftOperandName,
                             int rightOperandId, string rightOperandName);

      LpiSchedulesComparison(const LpiSchedulesComparison& source);

      virtual ~LpiSchedulesComparison()
      {
      }

      LpiSchedulesComparison & operator= (const LpiSchedulesComparison & source);

      int getLeftOperandId() const
      {
         return r_left_operand_id;
      }

      void setLeftOperandId(int leftOperandId)
      {
         r_left_operand_id = leftOperandId;
      }

      string getLeftOperandName() const
      {
         return r_left_operand_name;
      }

      void setLeftOperandName(string leftOperandName)
      {
         r_left_operand_name = leftOperandName;
      }

      int getRightOperandId() const
      {
         return r_right_operand_id;
      }

      void setRightOperandId(int rightOperandId)
      {
         r_right_operand_id = rightOperandId;
      }

      string getRightOperandName() const
      {
         return r_right_operand_name;
      }

      void setRightOperandName(string rightOperandName)
      {
         r_right_operand_name = rightOperandName;
      }

   protected:

      int r_left_operand_id;
      string r_left_operand_name;
      int r_right_operand_id;
      string r_right_operand_name;
};


class LpiSchedulesComparisonResponse : public LpiSchedulesComparison
{
   public:

      LpiSchedulesComparisonResponse() {}

      LpiSchedulesComparisonResponse(const LpiSchedulesComparison & source)
      : LpiSchedulesComparison(source)
      {
      }

      LpiComparativeKpis getKpis() const
      {
         return r_kpis;
      }

      void setKpis (const LpiComparativeKpis & kpis)
      {
         r_kpis = kpis;
      }

   protected:

      LpiComparativeKpis r_kpis;
};


std::ostream & operator<< (std::ostream & out, const LpiSchedulesComparison & operands);
std::ostream & operator<< (std::ostream & out, const LpiSchedulesComparisonResponse & operands);

#endif
