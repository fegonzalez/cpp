/*
 * LpiADOVector.h
 *
 *
 */

#ifndef LPIADOVECTOR_H_
#define LPIADOVECTOR_H_

#include <algorithm>
#include <vector>

#define E_ARR 0
#define E_DEP 1
#define E_OVA 2


template <class T>
class LpiADOVector
{
   public:

      enum MaxSize { E_MAX_SIZE = 3 };

      LpiADOVector();
      LpiADOVector(T data_array[LpiADOVector::E_MAX_SIZE]);
      LpiADOVector(T arr_element, T dep_element, T ova_element);
      LpiADOVector(const LpiADOVector & source);
      virtual ~LpiADOVector() {}

      T & operator[] (const int i);
      const T & operator[](const int i) const;
      LpiADOVector & operator= (const LpiADOVector & source);

      void reset();

      int size() const;

   protected:

      T r_data[LpiADOVector::E_MAX_SIZE];
      int r_numberOfElements;
};


template <class T>
LpiADOVector<T>::LpiADOVector()
: r_numberOfElements(LpiADOVector::E_MAX_SIZE)
{
   for (int i= 0; i < r_numberOfElements ; ++i)
   {
      r_data[i]= T();
   }
}


template <class T>
LpiADOVector<T>::LpiADOVector(T arr_element, T dep_element, T ova_element)
: r_numberOfElements(LpiADOVector::E_MAX_SIZE)
{
   r_data[E_ARR]= arr_element;
   r_data[E_DEP]= dep_element;
   r_data[E_OVA]= ova_element;
}


template <class T>
LpiADOVector<T>::LpiADOVector(T data_array[LpiADOVector::E_MAX_SIZE])
: r_numberOfElements(LpiADOVector::E_MAX_SIZE)
{
   std::copy(data_array, data_array + r_numberOfElements, r_data);
}


template <class T>
LpiADOVector<T>::LpiADOVector(const LpiADOVector<T> & source)
:r_numberOfElements(source.r_numberOfElements)
{
   std::copy(source.r_data, source.r_data + source.r_numberOfElements, r_data);
}


template <class T>
T & LpiADOVector<T>::operator[] (const int i)
{
   return r_data[i];
}

template <class T>
const T & LpiADOVector<T>::operator[] (const int i) const
{
   return r_data[i];
}

template <class T>
LpiADOVector<T> & LpiADOVector<T>::operator= (const LpiADOVector & source)
{
   if (this != &source)
   {
      //Another way for copying data without loop:
      //std::copy(source.r_data, source.r_data + source.r_number_of_elements, r_data);
      for (int i= E_ARR; i <= E_OVA; ++i)
      {
         r_data[i]= source.r_data[i];
      }
   }

   return *this;
}


template <class T>
void LpiADOVector<T>::reset()
{
   std::fill(r_data, r_data + LpiADOVector::E_MAX_SIZE, T());
}



template <class T>
int LpiADOVector<T>::size() const
{
   return r_numberOfElements;
}


template <class T>
inline std::ostream& operator<< (std::ostream & out, const LpiADOVector<T> & adoVector)
{
	out << std::string("[A: ");
	out << adoVector[E_ARR];
	out << std::string("|D: ");
	out << adoVector[E_DEP];
	out << std::string("|O: ");
	out << adoVector[E_OVA];
	out << std::string("] ");
    return out;
}


//Specialization only in case of ADO vectors of integers
inline LpiADOVector<double> toDouble (const LpiADOVector<int> & source)
{
   LpiADOVector<double> result;
   for (int i = E_ARR; i <= E_OVA; ++i)
   {
      result[i] = static_cast<double>(source[i]);
   }

   return result;
}


inline LpiADOVector<int> operator- (const LpiADOVector<int> & left, const LpiADOVector<int> & right)
{
   LpiADOVector<int> result= left;
   result[E_ARR]-= right[E_ARR];
   result[E_DEP]-= right[E_DEP];
   result[E_OVA]-= right[E_OVA];

   return result;
}


inline LpiADOVector<double> operator- (const LpiADOVector<double> & left, const LpiADOVector<double> & right)
{
   LpiADOVector<double> result= left;
   result[E_ARR]-= right[E_ARR];
   result[E_DEP]-= right[E_DEP];
   result[E_OVA]-= right[E_OVA];

   return result;
}


inline LpiADOVector<int> operator+ (const LpiADOVector<int> & left, const LpiADOVector<int> & right)
{
   LpiADOVector<int> result= left;
   result[E_ARR]+= right[E_ARR];
   result[E_DEP]+= right[E_DEP];
   result[E_OVA]+= right[E_OVA];

   return result;
}


inline LpiADOVector<double> operator+ (const LpiADOVector<double> & left, const LpiADOVector<double> & right)
{
   LpiADOVector<double> result= left;
   result[E_ARR]+= right[E_ARR];
   result[E_DEP]+= right[E_DEP];
   result[E_OVA]+= right[E_OVA];

   return result;
}


template <class T>
inline LpiADOVector<T> operator* (const LpiADOVector<T> & left, double N)
{
   LpiADOVector<T> result;

   for (int i = E_ARR; i <= E_OVA; ++i)
   {
      result[i]= left[i] * N;
   }

   return result;
}


template <class T>
inline LpiADOVector<T> operator/ (const LpiADOVector<T> & left, double N)
{
   LpiADOVector<T> result= left;
   result[E_ARR]= (N > 0.0) ? (left[E_ARR] / N) : 0.0;
   result[E_DEP]= (N > 0.0) ? (left[E_DEP] / N) : 0.0;
   result[E_OVA]= (N > 0.0) ? (left[E_OVA] / N) : 0.0;

   return result;
}


template <class T>
inline LpiADOVector<T> operator/ (const LpiADOVector<T> & left, const LpiADOVector<T> & right)
{
   LpiADOVector<T> result= left;
   result[E_ARR]= (right[E_ARR] > 0) ? (left[E_ARR] / right[E_ARR]) : T();
   result[E_DEP]= (right[E_DEP] > 0) ? (left[E_DEP] / right[E_DEP]) : T();
   result[E_OVA]= (right[E_OVA] > 0) ? (left[E_OVA] / right[E_OVA]) : T();

   return result;
}


template <class T>
inline LpiADOVector<T> max (const LpiADOVector<T> & left, const LpiADOVector<T> & right)
{
   LpiADOVector<T> result;
   for (int i = E_ARR ; i <= E_OVA ; ++i)
   {
      result[i] = std::max(left[i] , right[i]);
   }

   return result;
}


template <class T>
inline bool operator== (const LpiADOVector<T> & left, const LpiADOVector<T> & right)
{
   bool result = true;

   for (int i = E_ARR ; i <= E_OVA ; ++i)
   {
      result = result && (left[i] == right[i]);
   }

   return result;
}


template <class T>
inline bool operator!= (const LpiADOVector<T> & left, const LpiADOVector<T> & right)
{
   return !(left == right);
}

#endif /* LPIADOVECTOR_H_ */
