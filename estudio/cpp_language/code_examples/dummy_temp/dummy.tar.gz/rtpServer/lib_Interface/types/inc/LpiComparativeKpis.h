#ifndef __LPI_COMPARATIVE_KPIS__
#define __LPI_COMPARATIVE_KPIS__

#include <vector>
#include <string>
#include <iostream>

#include "LpiADO.h"
#include "LpiWarningsAlerts.h"


using std::vector;
using std::string;


class LpiIntervalDataKpis
{
   public:

      LpiIntervalDataKpis();
      LpiIntervalDataKpis (const LpiIntervalDataKpis & source);
      virtual  ~LpiIntervalDataKpis () {}

      LpiIntervalDataKpis & operator= (const LpiIntervalDataKpis & source);

      LpiADO getShortage           () const { return r_shortage;         }
      LpiADO getAirportCapacity    () const { return r_airportCapacity;  }
      LpiADO getRSCapacity         () const { return r_rsCapacity;       }

      LpiADO getMaxForecastedDelay () const { return r_maxForecastedDelay; }
      LpiADO getPercentagePunctual () const { return r_percentagePunctual; }
      LpiADO getAverageForecastedDelay_DelayedFPs () const { return r_averageForecastedDelay_DelayedFPs; }

      Warnings_alerts getShortageWA           () const { return r_shortageWA;         }
      Warnings_alerts getAirportCapacityWA    () const { return r_airportCapacityWA;  }
      Warnings_alerts getRSCapacityWA         () const { return r_rsCapacityWA;       }

      Warnings_alerts getMaxForecastedDelayWA () const { return r_maxForecastedDelayWA; }
      Warnings_alerts getPercentagePunctualWA () const { return r_percentagePunctualWA; }
      Warnings_alerts getAverageForecastedDelay_DelayedFPsWA () const { return r_averageForecastedDelay_DelayedFPsWA; }

      //Setters with fluent interface

      LpiIntervalDataKpis & setShortage        (const LpiADO & shortage) { r_shortage = shortage; return *this; }
      LpiIntervalDataKpis & setAirportCapacity (const LpiADO & capacity) { r_airportCapacity = capacity; return *this; }
      LpiIntervalDataKpis & setRSCapacity      (const LpiADO & capacity) { r_rsCapacity = capacity; return *this; }

      LpiIntervalDataKpis & setShortageWA        (const Warnings_alerts & alerts) { r_shortageWA = alerts; return *this; }
      LpiIntervalDataKpis & setAirportCapacityWA (const Warnings_alerts & alerts) { r_airportCapacityWA = alerts; return *this; }
      LpiIntervalDataKpis & setRSCapacityWA      (const Warnings_alerts & alerts) { r_rsCapacityWA = alerts; return *this; }

      LpiIntervalDataKpis & setMaxForecastedDelay (const LpiADO & maxdelay) { r_maxForecastedDelay = maxdelay; return *this; }
      LpiIntervalDataKpis & setPercentagePunctual (const LpiADO & percentage) { r_percentagePunctual = percentage; return *this; }
      LpiIntervalDataKpis & setAverageForecastedDelay_DelayedFPs (const LpiADO & average)
      { r_averageForecastedDelay_DelayedFPs = average; return *this; }

      LpiIntervalDataKpis & setMaxForecastedDelayWA (const Warnings_alerts & alerts) { r_maxForecastedDelayWA = alerts; return *this; }
      LpiIntervalDataKpis & setPercentagePunctualWA (const Warnings_alerts & alerts) { r_percentagePunctualWA = alerts; return *this; }
      LpiIntervalDataKpis & setAverageForecastedDelay_DelayedFPsWA (const Warnings_alerts & alerts)
      { r_averageForecastedDelay_DelayedFPsWA = alerts; return *this; }

   private:

      LpiADO            r_shortage;
      Warnings_alerts   r_shortageWA;

      LpiADO            r_airportCapacity;
      Warnings_alerts   r_airportCapacityWA;

      LpiADO            r_rsCapacity;
      Warnings_alerts   r_rsCapacityWA;

      LpiADO            r_maxForecastedDelay;
      Warnings_alerts   r_maxForecastedDelayWA;

      LpiADO            r_percentagePunctual;
      Warnings_alerts   r_percentagePunctualWA;

      LpiADO            r_averageForecastedDelay_DelayedFPs;
      Warnings_alerts   r_averageForecastedDelay_DelayedFPsWA;
};

std::ostream& operator<<(std::ostream &os, const LpiIntervalDataKpis & kpi);


class LpiIntervalKpi
{
   public:

      LpiIntervalKpi();
      LpiIntervalKpi (const LpiIntervalKpi &source);
      virtual  ~LpiIntervalKpi () {}

      LpiIntervalKpi & operator= (const LpiIntervalKpi & source);

      string getStartTimeAndDate () const { return r_startTimeAndDate; }
      string getEndTimeAndDate   () const { return r_endTimeAndDate;   }

      LpiIntervalDataKpis getDeltaKpis () const { return r_deltaKpis; }
      LpiIntervalDataKpis getRelativeKpis () const { return r_relativeKpis; }

      //Setters with fluent interface
      LpiIntervalKpi & setStartTimeAndDate (const string & time) { r_startTimeAndDate = time; return *this; }
      LpiIntervalKpi & setEndTimeAndDate   (const string & time) { r_endTimeAndDate = time; return *this; }

      LpiIntervalKpi & setDeltaKpis    (const LpiIntervalDataKpis & kpis) { r_deltaKpis = kpis; return *this; }
      LpiIntervalKpi & setRelativeKpis (const LpiIntervalDataKpis & kpis) { r_relativeKpis = kpis; return *this; }

   private:

      string     r_startTimeAndDate;
      string     r_endTimeAndDate;

      LpiIntervalDataKpis r_deltaKpis;
      LpiIntervalDataKpis r_relativeKpis;
};

std::ostream& operator<<(std::ostream &os, const LpiIntervalKpi & kpi);


class LpiComparativeKpis
{
   public:

      LpiComparativeKpis ();
      LpiComparativeKpis (const LpiComparativeKpis &source);
      virtual  ~LpiComparativeKpis () {}

      LpiComparativeKpis & operator= (const LpiComparativeKpis & source);

      vector<LpiIntervalKpi> getKpisPerInterval () const { return r_kpisPerInterval; }
      void addKpiPerInterval(const LpiIntervalKpi &kpi);

      std::string getRelativeKpisAsString() const;

   private:

      vector<LpiIntervalKpi> r_kpisPerInterval;

};

std::ostream& operator<<(std::ostream &os, const vector<LpiIntervalKpi> & kpi_collection);
std::ostream& operator<<(std::ostream &os, const LpiComparativeKpis & kpis);


#endif // __LPI_COMPARATIVE_KPIS__
