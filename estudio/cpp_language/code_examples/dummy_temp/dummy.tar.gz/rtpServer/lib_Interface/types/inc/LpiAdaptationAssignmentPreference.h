// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 21 Jun 10:11:39 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIADAPTATIONASSIGNMENTPREFERENCE_H_
#define LPIADAPTATIONASSIGNMENTPREFERENCE_H_

#include <LpiAdapProhibConstants.h>
#include <LpiAdapPrefsConstants.h>

#include <vector>

#include <boost/date_time/posix_time/posix_time.hpp>

class TimeInterval;



class LpiAllocation
{
public:
    LpiAllocation() {}
    ~LpiAllocation() {}

    // getters
    const std::string getAirport1(void) const {return this->_airport1;}
    const std::string getAirport2(void) const {return this->_airport2;}
    const std::string getStartTime(void) const {return this->_startTime;}
    const std::string getEndTime(void) const {return this->_endTime;}

    // setters
    void setAirport1(const std::string value) {_airport1=value;}
    void setAirport2(const std::string value) {_airport2=value;}
    void setStartTime(const std::string value) {_startTime=value;}
    void setEndTime(const std::string value) {_endTime=value;}

  /**@return True if the Allocation is forbidden in 'interval', thus
     if [_startTime, _endTime) intersects with 'interval'.

     // note.- equivalent to RMAN's 
     //    set<string> LriRunwaySystemProhibitions::getProhibitedRunwaySystems()
     */
  bool forbidden(const TimeInterval & interval,
		 const boost::posix_time::ptime & timeReference) const;


private:
    std::string _airport1;
    std::string _airport2;
    std::string _startTime;
    std::string _endTime;
};

typedef std::vector <LpiAllocation> LpiAllocationVector;

class LpiAllocationLevel
{
public:
    LpiAllocationLevel() {}
    ~LpiAllocationLevel() {}

    // getters
    const std::string getAirport1(void) const {return this->_airport1;}
    const std::string getAirport2(void) const {return this->_airport2;}
    const std::string getStartTime(void) const {return this->_startTime;}
    const std::string getEndTime(void) const {return this->_endTime;}
    const PREF_LEVEL_TYPE getPreferentialLevel(void) const 
          {return this->_preferentialLevel;}

    // setters
    void setAirport1(const std::string value) {_airport1=value;}
    void setAirport2(const std::string value) {_airport2=value;}
    void setStartTime(const std::string value) {_startTime=value;}
    void setEndTime(const std::string value) {_endTime=value;}
    void setPreferentialLevel(const PREF_LEVEL_TYPE value) 
         {_preferentialLevel=value;}

  /**@return True if the Allocation is forbidden in 'interval', thus
     if [_startTime, _endTime) intersects with 'interval'.
  */
  bool forbidden(const TimeInterval & interval,
		 const boost::posix_time::ptime & timeReference) const;

private:
    std::string _airport1;
    std::string _airport2;
    std::string _startTime;
    std::string _endTime;
    PREF_LEVEL_TYPE _preferentialLevel;
};

typedef std::vector <LpiAllocationLevel> LpiAllocationVectorLevel;


class LpiAllocationList
{
public:
    LpiAllocationList() {}
    ~LpiAllocationList() {}

    // getters
    LpiAllocationVector getAllocation(void) const {return this->_allocation;}

    // setters
    void setAllocation(const LpiAllocationVector value) {_allocation=value;}


  ProhibitionElementList getAllocations
  (const TimeInterval & interval,
   const boost::posix_time::ptime & timeReference) const;

    LpiAllocationVector _allocation;
};

class LpiAllocationListLevel
{
public:
    LpiAllocationListLevel() {}
    ~LpiAllocationListLevel() {}

    // getters
    LpiAllocationVectorLevel getAllocation(void) const {return this->_allocation;}

    // setters
    void setAllocation(const LpiAllocationVectorLevel value) {_allocation=value;}


  PreferenceElementList getAllocations
  (const TimeInterval & interval,
   const boost::posix_time::ptime & timeReference) const;

    LpiAllocationVectorLevel _allocation;
};


class LpiAdaptationAssignmentPreference
{

public:
    LpiAdaptationAssignmentPreference() {}
    ~LpiAdaptationAssignmentPreference() {}


    // getters
    const LpiAllocationList getNotAllowedAllocation(void) const {return this->_notAllowedAllocation;}
    const LpiAllocationListLevel getPreferentialAllocation(void) const {return this->_preferentialAllocation;}

    // setters
    void setNotAllowedAllocation(const LpiAllocationList value) { _notAllowedAllocation=value;}
    void setPreferentialAllocation(const LpiAllocationListLevel value) { _preferentialAllocation=value;}

  ProhibitionElementList getNotAllowedAllocations
  (const TimeInterval & interval,
   const boost::posix_time::ptime & timeReference) const;

  PreferenceElementList getPrefAllocations
  (const TimeInterval & interval,
   const boost::posix_time::ptime & timeReference) const;

private:
    LpiAllocationList _notAllowedAllocation;
    LpiAllocationListLevel _preferentialAllocation;
};

std::ostream& operator<< (std::ostream & out, const LpiAdaptationAssignmentPreference & ap);


#endif /* LPIADAPTATIONASSIGNMENTPREFERENCE_H_ */
