/*
 * LpiADO.cc
 *
 *  Created on: 02/12/2013
 *      Author: gpfernandez
 */

#include "LpiADO.h"


LpiADO::LpiADO (float initialValue)
: _arrivalsValue(initialValue),
  _departuresValue(initialValue),
  _overallValue(initialValue)
{
}


float & LpiADO::operator[] (int index)
{
   switch (index)
   {
      case E_ARR:
         return _arrivalsValue;
      break;
      case E_DEP:
         return _departuresValue;
      break;
      default:
         return _overallValue;
   }
}


float LpiADO::operator[] (int index) const
{
   switch (index)
   {
      case E_ARR:
         return _arrivalsValue;
      break;
      case E_DEP:
         return _departuresValue;
      break;
      default:
         return _overallValue;
   }
}



void LpiADO::setAllValues (float value)
{
   _arrivalsValue   = value;
   _departuresValue = value;
   _overallValue    = value;
}


LpiADO & LpiADO::operator= (const LpiADO & source)
{
   if (this != &source)
   {
      _arrivalsValue   = source._arrivalsValue;
      _departuresValue = source._departuresValue;
      _overallValue    = source._overallValue;
   }

   return *this;
}


LpiADO LpiADO::convert2Interface (const LpiADOVector<int> & in)
{
   LpiADO out;

   out.setarrivalsValue(in[E_ARR]);
   out.setdeparturesValue(in[E_DEP]);
   out.setoverallValue(in[E_OVA]);

   return out;
}


LpiADO LpiADO::convert2Interface (const LpiADOVector<double> & in)
{
   LpiADO out;

   out.setarrivalsValue(in[E_ARR]);
   out.setdeparturesValue(in[E_DEP]);
   out.setoverallValue(in[E_OVA]);

   return out;
}


//Sets a special tag (-1) in "not used" components
LpiADO LpiADO::tagNoUsageComponents (const OperationType::Enum & runway_usage,
                                     const LpiADO & in)
{
   LpiADO result = in;

   switch (runway_usage)
   {
      //Marks NOT used component as -1, in case of ARR, not used is DEP
      case OperationType::E_ARRIVALS:
         result.setdeparturesValue(-1);
      break;
      case OperationType::E_DEPARTURES:
         result.setarrivalsValue(-1);
      break;
      case OperationType::E_MIXED:
      case OperationType::E_INVALID_RWY_OPERATION_TYPE:
      default:
      break;
   }

   return result;
}


std::ostream & operator<<(std::ostream & os, const LpiADO & obj)
{
   return os<< "(" 
            << obj.getarrivalsValue()
            << ", "
            << obj.getdeparturesValue()
            << ", "
            << obj.getoverallValue()
            << ")" ;
}
