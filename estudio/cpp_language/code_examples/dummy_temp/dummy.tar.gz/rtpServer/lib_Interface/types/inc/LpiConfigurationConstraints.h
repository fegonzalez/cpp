
#ifndef LPICONFIGURATIONCONSTRAINTS_H_
#define LPICONFIGURATIONCONSTRAINTS_H_

#include <vector>
#include <iostream>


class StabilityList
{

public:

   // getters
   long long getMinRSMainteinanceMinutes(void) const {return this->_minRSMainteinanceMinutes;};
   long long getMinConfigurationMainteinanceMinutes(void) const {return this->_minConfigurationMainteinanceMinutes;};

   // setters
   void setMinRSMainteinanceMinutes(long long value) {this->_minRSMainteinanceMinutes = value;};
   void setMinConfigurationMainteinanceMinutes(long long value) {this->_minConfigurationMainteinanceMinutes = value;};


private:
   long long _minRSMainteinanceMinutes;
   long long _minConfigurationMainteinanceMinutes;
}; // StabilityList

class GoodnessList
{

public:

   // getters
   long long getMaxDelayedFPs(void) const {return this->_maxDelayedFPs;};
   long long getMinMeteorologicalSuitability(void) const {return this->_minMeteorologicalSuitability;};

   // setters
   void setMaxDelayedFPs(long long value) {this->_maxDelayedFPs = value;};
   void setMinMeteorologicalSuitability(long long value) {this->_minMeteorologicalSuitability = value;};

private:
   long long _maxDelayedFPs;
   long long _minMeteorologicalSuitability;
}; // GoodnessList

class KPIList
{

public:

   // getters
   long long getWeightMinimizeArrivalsShortage(void) const {return this->_weightMinimizeArrivalsShortage;};
   long long getWeightMinimizeDeparturesShortage(void) const {return this->_weightMinimizeDeparturesShortage;};
   long long getWeightMinimizeOverallShortage(void) const {return this->_weightMinimizeOverallShortage;};
   long long getWeightMinimizeArrivalsAverageDelay(void) const {return this->_weightMinimizeArrivalsAverageDelay;};
   long long getWeightMinimizeDeparturesAverageDelay(void) const {return this->_weightMinimizeDeparturesAverageDelay;};
   long long getWeightMinimizeOverallAverageDelay(void) const {return this->_weightMinimizeOverallAverageDelay;};
   long long getWeightMaximizeArrivalsPunctuality(void) const {return this->_weightMaximizeArrivalsPunctuality;};
   long long getWeightMaximizeDeparturesPunctuality(void) const {return this->_weightMaximizeDeparturesPunctuality;};
   long long getWeightMaximizeOverallPunctuality(void) const {return this->_weightMaximizeOverallPunctuality;};


   // setters
   void setWeightMinimizeArrivalsShortage(long long value) {this->_weightMinimizeArrivalsShortage = value;};
   void setWeightMinimizeDeparturesShortage(long long value) {this->_weightMinimizeDeparturesShortage = value;};
   void setWeightMinimizeOverallShortage(long long value) {this->_weightMinimizeOverallShortage = value;};
   void setWeightMinimizeArrivalsAverageDelay(long long value) {this->_weightMinimizeArrivalsAverageDelay = value;};
   void setWeightMinimizeDeparturesAverageDelay(long long value) {this->_weightMinimizeDeparturesAverageDelay = value;};
   void setWeightMinimizeOverallAverageDelay(long long value) {this->_weightMinimizeOverallAverageDelay = value;};
   void setWeightMaximizeArrivalsPunctuality(long long value) {this->_weightMaximizeArrivalsPunctuality = value;};
   void setWeightMaximizeDeparturesPunctuality(long long value) {this->_weightMaximizeDeparturesPunctuality = value;};
   void setWeightMaximizeOverallPunctuality(long long value) {this->_weightMaximizeOverallPunctuality = value;};



private:
   long long _weightMinimizeArrivalsShortage;
   long long _weightMinimizeDeparturesShortage;
   long long _weightMinimizeOverallShortage;
   long long _weightMinimizeArrivalsAverageDelay;
   long long _weightMinimizeDeparturesAverageDelay;
   long long _weightMinimizeOverallAverageDelay;
   long long _weightMaximizeArrivalsPunctuality;
   long long _weightMaximizeDeparturesPunctuality;
   long long _weightMaximizeOverallPunctuality;
}; // KPIList

class LpiConfigurationConstraints
{

public:
   LpiConfigurationConstraints() {}
   ~LpiConfigurationConstraints() {}

   // getters
   long long getMaxPossibleRSScheduled(void) const {return this->_maxPossibleRSScheduled;};
   const StabilityList& getStability(void) const {return this->_stability;};
   const GoodnessList& getGoodness(void) const {return this->_goodness;};
   const KPIList& getKpi(void) const {return this->_kpi;};

   // setters
   void setMaxPossibleRSScheduled(long long value) {this->_maxPossibleRSScheduled = value;};
   void setStability(const StabilityList& value) {this->_stability = value;};
   void setGoodness(const GoodnessList& value) {this->_goodness = value;};
   void setKpi(const KPIList& value) {this->_kpi = value;};

private:
   long long _maxPossibleRSScheduled;
   StabilityList _stability;
   GoodnessList _goodness;
   KPIList _kpi;
};

std::ostream & operator<<(std::ostream & out, const KPIList & kpiList);
std::ostream & operator<<(std::ostream & out, const LpiConfigurationConstraints & confParams);


#endif /* LPICONFIGURATIONCONSTRAINTS_H_ */
