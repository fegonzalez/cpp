#if !defined(__LPIWEIGHTPONDERATIONPARAMETERS__)
#define __LPIWEIGHTPONDERATIONPARAMETERS__

#include <iostream>

class LpiWeightPonderationParameters
{
public:
   double getWeightDcbs() const { return r_weightDcbs; }
   void setWeightDcbs(double weightDcbs) { r_weightDcbs = weightDcbs; }

   double getWeightStability() const { return r_weightStability; }
   void setWeightStability(double weightStability) { r_weightStability = weightStability; }

   double getWeightPreferentialRs() const { return r_weightPreferentialRs; }
   void setWeightPreferentialRs(double weightPreferentialRs) { r_weightPreferentialRs = weightPreferentialRs; }

private:

   double r_weightDcbs;
   double r_weightStability;
   double r_weightPreferentialRs;
};

std::ostream & operator<<(std::ostream & out,
                          const LpiWeightPonderationParameters & parameters);

#endif // __LPIWEIGHTPONDERATIONPARAMETERS__
