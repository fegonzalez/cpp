
#include "LpiAdaptationRunway.h"


std::ostream & operator<<(std::ostream & out, const LpiAdaptationRunwayList &adapParams)
{
   out << "RunwayList " ;
   
   for (unsigned int i = 0; i< adapParams.size(); i++)
   {
      out << "[Name: " << adapParams[i].getNameRunway() 
          << "\n catILS:" <<  adapParams[i].getILSRunway()
          << "\n Capacity Nominal: " << adapParams[i].getCapacityNominal()
          << "\n Threshold1Latitude: " << adapParams[i].getThreshold1Latitude()
          << "\n Threshold2Latitude: " << adapParams[i].getThreshold2Latitude()
          << "\n Threshold1Longitude: " << adapParams[i].getThreshold1Longitude()
          << "\n Threshold2Longitude: " << adapParams[i].getThreshold2Longitude()
          <<"]\n"; 


      
   }

   return out << "RtpParameters:\n" << '\n';
           //   << confParams.getTimeParameters() << '\n';
}
