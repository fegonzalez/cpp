#ifndef __LPI_SCHEDULE_ACTIVATION_TYPE_H__
#define __LPI_SCHEDULE_ACTIVATION_TYPE_H__

#include <iostream>

class LpiScheduleActivationType
{
   public:
      enum LpiEnum
      {
         E_AUTO = 0,
         E_MANUAL
      };
};


std::ostream & operator << (std::ostream &os, const LpiScheduleActivationType::LpiEnum & obj);


#endif
