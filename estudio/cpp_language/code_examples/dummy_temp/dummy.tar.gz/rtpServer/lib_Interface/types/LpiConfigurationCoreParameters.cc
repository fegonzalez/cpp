// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 25 Jun 08:38:36 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------


#include "LpiConfigurationCoreParameters.h"

std::ostream & operator<<(std::ostream & out, const LpiConfigurationCoreParameters & confParams)
{
	out << "File: " << __FILE__
	    << " ; fn: " << __func__
	    << " ; line: " << __LINE__
		<< "\n";

   out << "[parameters: " << "\n";

   LpiTimeParameters time = confParams.getTimeParameters();
   out << " \t|timeParameters: \n"
       << " \t\t|hoursWindow: " << time.getHoursWindow() << "\n"
       << " \t\t|minutesSubinterval: " << time.getMinutesSubinterval() << "\n"
       << " \t\t|minutesFrozen: " << time.getMinutesFrozen() << "\n"
       << " \t\t|minutesFrozenForClock: " << time.getMinutesFrozenForClock() << "\n";

   out << " \t|fpExpirationTime: " << confParams.getFpExpirationTime() << "\n";

   out << " \t|transitionWeightPonderation: " << "\n";

   Ponderation pond = confParams.getTransitionWeightsPonderation();
   out << " \t\t|weightComplexity: " << pond.getWeightComplexity() << "\n"
       << " \t\t|weightStability: " << pond.getWeightStability() << "\n"
       << " \t\t|weightPreferentialAllocation: " << pond.getWeightPreferentialAllocation() << "\n"
       << " \t\t|weightSelectMinMrtm: " << pond.getWeightSelectMinMrtm() << "\n"
       << " \t\t|weightBalance: " << pond.getWeightBalance() << "\n";

   PonderationAirports pAirports = confParams.getComplexityWeightPonderationAirports();
   out << "\t|complexityWeightPonderationAirports: \n"
       << "\t\t|weightLVP: " << pAirports.getWeightLVP() << "\n"
       << "\t\t|weightIce: " << pAirports.getWeightIce() << "\n"
       << "\t\t|weightTotalMovAirport: " << pAirports.getWeightTotalMovAirport() << "\n"
       << "\t\t|weightVfrAirport: " << pAirports.getWeightVfrAirport() << "\n";

   PonderationMrtm pMrtm = confParams.getComplexityWeightPonderationMrtm();
   out << "\t|complexityWeightPonderationMrtm: \n"
       << "\t\t|weightComplexityAirports: " << pMrtm.getWeightComplexityAirports() << "\n"
       << "\t\t|weightSimultaneousMov: " << pMrtm.getWeightSimultaneousMov() << "\n"
       << "\t\t|weightTotalMovMrtm: " << pMrtm.getWeightTotalMovMrtm() << "\n"
       << "\t\t|weightVfrMrtm: " << pMrtm.getWeightVfrMrtm() << "\n";

   PonderationSimMov pSimMov = confParams.getComplexityWeightPonderationSimMov();
      out << "\t|complexityWeightPonderationSimMov: \n"
          << "\t\t|weightMean: " << pSimMov.getWeightMean() << "\n"
          << "\t\t|weightNumSimMov: " << pSimMov.getWeightNumSimMov() << "\n";

   out << "\t|alternativeAllocationExpirationours: " << confParams.getAlternativeAllocationsExpirationHours() << "\n";

   out << "\t |Use_WTC_Vortex_Reductions: "  << confParams.getUseWakeVortexCapacityReductions()
	   << "]\n";

   return out;


}
