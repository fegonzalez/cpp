// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 10:11:55 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------


#include "LpiAdaptationAlert_KPIs.h"


std::ostream & operator<<(std::ostream & out, const LpiAdaptationAlert_KPIs & confParams)
{
    out << "[absoluteKPIs: \n"
        << " \t|simultaneousOpsHour: " << "\n"
        << " \t\t|negativeAlert: " << "\n";

    AbsoluteKPIs sim = confParams.getSimultaneousOpsHour();
    out << " \t\t\t|alarmThreshold: " << sim.getNegativeAlert().getAlarmThreshold() << "\n"
        << " \t\t\t|warningThreshold: " << sim.getNegativeAlert().getWarningThreshold() << "\n"
        << " \t|totalMov: \n"
        << " \t\t|negativeAlert: " << "\n";;

    AbsoluteKPIs move = confParams.getTotalMov();
    out << " \t\t\t|alarmThreshold: " << move.getNegativeAlert().getAlarmThreshold() << "\n"
        << " \t\t\t|warningThreshold: " << move.getNegativeAlert().getWarningThreshold() << "\n"
        << " \t|complexity: \n"
        << " \t\t|airportsComplexity: \n"
        << " \t\t\t|negativeAlert: \n";

    Complexity compA = confParams.getComplexity();
    out << " \t\t\t\t|alarmThreshold: " << compA.getAirportsComplexity().getNegativeAlert().getAlarmThreshold() << "\n"
        << " \t\t\t\t|warningThreshold: " << compA.getAirportsComplexity().getNegativeAlert().getWarningThreshold() << "\n"
        << " \t\t|modulesComplexity: \n"
        << " \t\t\t|negativeAlert: \n";

    Complexity compM = confParams.getComplexity();
    out << " \t\t\t\t|alarmThreshold: " << compM.getModulesComplexity().getNegativeAlert().getAlarmThreshold() << "\n"
        << " \t\t\t\t|warningThreshold: " << compM.getModulesComplexity().getNegativeAlert().getWarningThreshold() << "\n";


    AbsoluteKPIs vfr = confParams.getVfr();
	out << " \t\t\t|alarmThreshold: " << vfr.getNegativeAlert().getAlarmThreshold() << "\n"
		<< " \t\t\t|warningThreshold: " << vfr.getNegativeAlert().getWarningThreshold() << "]\n";

    return out;
}
