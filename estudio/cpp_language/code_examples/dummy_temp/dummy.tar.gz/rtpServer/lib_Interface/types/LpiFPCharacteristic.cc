/*
 * LpiFPCharacteristic.cc
 *
 *  Created on: 15/07/2015
 *      Author: mbegega
 */

#include "LpiFPCharacteristic.h"

std::ostream & operator <<(std::ostream & os,
                           const LpiFPCharacteristic::LpiEnum & characteristic)
{
   switch (characteristic)
   {
      case LpiFPCharacteristic::E_UNKNOWN:
         os << "UNKNOWN";
      break;
      case LpiFPCharacteristic::E_EOBT:
         os << "EOBT";
      break;
      case LpiFPCharacteristic::E_SOBT:
         os << "SOBT";
      break;
      case LpiFPCharacteristic::E_TOBT:
         os << "TOBT";
      break;
      case LpiFPCharacteristic::E_ETOT:
         os << "ETOT";
      break;
      case LpiFPCharacteristic::E_TTOT:
         os << "TTOT";
      break;
      case LpiFPCharacteristic::E_STOT:
         os << "STOT";
      break;
      case LpiFPCharacteristic::E_ATOT:
         os << "ATOT";
      break;
      case LpiFPCharacteristic::E_CTOT:
         os << "CTOT";
      break;
      case LpiFPCharacteristic::E_UTOT:
         os << "UTOT";
      break;
      case LpiFPCharacteristic::E_ELDT:
         os << "ELDT";
      break;
      case LpiFPCharacteristic::E_TLDT:
         os << "TLDT";
      break;
      case LpiFPCharacteristic::E_ALDT:
         os << "ALDT";
      break;
      case LpiFPCharacteristic::E_SLDT:
         os << "SLDT";
      break;
      case LpiFPCharacteristic::E_ULDT:
         os << "ULDT";
      break;
      case LpiFPCharacteristic::E_SIBT:
         os << "SIBT";
      break;
      case LpiFPCharacteristic::E_AIRCRAFT_TYPE:
         os << "AIRCRAFT_TYPE";
      break;
      case LpiFPCharacteristic::E_REGISTRATION:
         os << "REGISTRATION";
      break;
      case LpiFPCharacteristic::E_WTC:
         os << "WTC";
      break;
      case LpiFPCharacteristic::E_SID:
         os << "SID";
      break;
      case LpiFPCharacteristic::E_STAR:
         os << "STAR";
      break;
      case LpiFPCharacteristic::E_CLOSED_TURNROUND:
         os << "CLOSED_TURN-ROUND";
      break;
      case LpiFPCharacteristic::E_NOT_ALLOWED_RWYS:
         os << "NOT_ALLOWED_RUNWAYS";
      break;
      default:
         os << "UNKNOWN";
      break;
   }

   return os;
}
