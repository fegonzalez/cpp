// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 21 Jun 10:27:34 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------

#include "LpiAdaptationAssignmentPreference.h"
#include <LpiAdapProhibConstants.h>
#include <LpiAdapPrefsConstants.h>
#include <LctimTimeLine.h>
#include <LclogStream.h>

#include <boost/date_time/posix_time/posix_time.hpp>

#include <iostream>


//==============================================================================

namespace{


  ///equivalente a  RMAN's et<string> LriRunwaySystemProhibitions::getProhibitedRunwaySystems
  bool isForbidden(const TimeInterval & interval,
		   const boost::posix_time::ptime & timeReference,
		   const std::string & startTime,
		   const std::string & endTime);

  bool isForbidden(const TimeInterval & interval,
		 const boost::posix_time::ptime & timeReference,
		 const std::string & startTime,
		 const std::string & endTime) 
{
  bool result  = false;
  const bool ERROR_EMPTY_RESULT = false;
  const std::string ERROR_MSG_BAD_FORMAT =
    {"No se han podido asignar los RS prohibidos: (horas en formato erroneo)."};

  boost::posix_time::ptime startPTimeToday;//warning: ptimes not initialised!
  boost::posix_time::ptime endPTimeToday;
  boost::posix_time::ptime startPTimeYesterday;
  boost::posix_time::ptime endPTimeTomorrow;
  //initialising times
  bool converted_start_time = LctimTimeUtils::getFromTodayHour
    (startTime, timeReference, startPTimeToday);
  bool converted_end_time = LctimTimeUtils::getFromTodayHour
    (endTime, timeReference, endPTimeToday);
  bool converted_yesterday_time = LctimTimeUtils::getFromYesterdayHour
    (startTime, timeReference, startPTimeYesterday);
  bool converted_tomorrow_time = LctimTimeUtils::getFromTomorrowHour
    (endTime, timeReference, endPTimeTomorrow);
  //error case: bad time conversion: return "No prohibitions" value
  if(not(converted_start_time and converted_end_time and 
	 converted_yesterday_time and converted_tomorrow_time))
  {
    LclogStream::instance(LclogConfig::E_RMAN).error()
      << ERROR_MSG_BAD_FORMAT
      << "\tFile: " << __FILE__ << " ; Fn: " << __func__ << " ; Ln"  << __LINE__
      << std::endl;
    return ERROR_EMPTY_RESULT;
  }

   //Check day change from yesterday to today
   if (endPTimeToday < startPTimeToday) 
   {
     if (((interval.begin >= startPTimeYesterday) && (interval.begin < endPTimeToday)) ||
         ((interval.end > startPTimeYesterday) && (interval.end <= endPTimeToday)))
     {
       result = true;
     }

      //Check day change from today to tomorrow: endPTimeTomorrow;
      if (((interval.begin >= startPTimeToday) && (interval.begin < endPTimeTomorrow)) ||
         ((interval.end > startPTimeToday) && (interval.end <= endPTimeTomorrow)))
      {
         result = true;
     }
   }
   else // endPTimeToday >= startPTimeToday
   {
     TimeInterval interval_to_check = interval;

     //WARNING: case: (endPTimeToday >= startPTimeToday) AND (begin.day() > timeRef.day())
     //         error: taking begin as day that follows timeRef
     //         solution: setting begin.day() equal to timeRef.day()
     if(interval.begin.date() > timeReference.date())
     {
       interval_to_check.begin = boost::posix_time::ptime (timeReference.date(), interval.begin.time_of_day());
       interval_to_check.end = boost::posix_time::ptime (timeReference.date(), interval.end.time_of_day());
     }


     if (((interval_to_check.begin >= startPTimeToday) && (interval_to_check.begin < endPTimeToday)) ||
         ((interval_to_check.end > startPTimeToday) && (interval_to_check.end <= endPTimeToday)))
     {
       result = true;
     }
   }
   
  return result;
}

} //end-of-namespace

//==============================================================================



//-----------------------------------
// Prohibitions
//-----------------------------------

ProhibitionElementList
LpiAdaptationAssignmentPreference::getNotAllowedAllocations
(const TimeInterval & interval,
 const boost::posix_time::ptime & timeReference) const
{
  return _notAllowedAllocation.getAllocations(interval, timeReference);
}

//-----------------------------------

ProhibitionElementList
LpiAllocationList::getAllocations
(const TimeInterval & interval,
 const boost::posix_time::ptime & timeReference) const
{
  ProhibitionElementList result;

  for (unsigned int i = 0; i < _allocation.size(); ++i)
  {
    if(_allocation[i].forbidden(interval, timeReference))
    {
      result.push_back(std::make_pair(_allocation[i].getAirport1(),
				      _allocation[i].getAirport2()));
    }
  }

  return result;
}

//-----------------------------------

bool LpiAllocation::forbidden
(const TimeInterval & interval,
 const boost::posix_time::ptime & timeReference) const
{
  return isForbidden(interval, timeReference, 
		     this->getStartTime(), this->getEndTime());
}

//-----------------------------------
// Preferences
//-----------------------------------

PreferenceElementList 
LpiAdaptationAssignmentPreference::getPrefAllocations
(const TimeInterval & interval,
 const boost::posix_time::ptime & timeReference) const
{
  return _preferentialAllocation.getAllocations(interval, timeReference);
}

//-----------------------------------

PreferenceElementList 
LpiAllocationListLevel::getAllocations
(const TimeInterval & interval,
 const boost::posix_time::ptime & timeReference) const
{
  PreferenceElementList  result;

  for (unsigned int i = 0; i < _allocation.size(); ++i)
  {
    if(_allocation[i].forbidden(interval, timeReference))
    {
      result.push_back(std::make_tuple(_allocation[i].getPreferentialLevel(),
				       _allocation[i].getAirport1(),
				       _allocation[i].getAirport2()));
    }
  }

  return result;
}

//-----------------------------------

bool LpiAllocationLevel::forbidden
(const TimeInterval & interval,
 const boost::posix_time::ptime & timeReference) const
{
  return isForbidden(interval, timeReference, 
		     this->getStartTime(), this->getEndTime());
}

//-----------------------------------

std::ostream& operator<< (std::ostream & out, const LpiAdaptationAssignmentPreference & ap)
{
    out << " [notAllowedAllocation: " << "\n";

    LpiAllocationList listNotAllowed = ap.getNotAllowedAllocation();

    for(unsigned int i = 0; i < listNotAllowed.getAllocation().size(); i++){
        out << " \t|allocation: \n"
            << " \t\t|airport1: " << listNotAllowed.getAllocation().at(i).getAirport1() << "\n"
            << " \t\t|airport2: " << listNotAllowed.getAllocation().at(i).getAirport2() << "\n"
            << " \t\t|startTime: " << listNotAllowed.getAllocation().at(i).getStartTime() << "\n"
            << " \t\t|endTime: " << listNotAllowed.getAllocation().at(i).getEndTime() << "\n";
    }


    out << " preferentialAllocation: " << "\n";

    LpiAllocationListLevel listPreferential = ap.getPreferentialAllocation();

    for(unsigned int i = 0; i < listPreferential.getAllocation().size(); i++){
        out << " \t|allocation: \n"
            << " \t\t|airport1: " << listPreferential.getAllocation().at(i).getAirport1() << "\n"
            << " \t\t|airport2: " << listPreferential.getAllocation().at(i).getAirport2() << "\n"
            << " \t\t|startTime: " << listPreferential.getAllocation().at(i).getStartTime() << "\n"
            << " \t\t|endTime: " << listPreferential.getAllocation().at(i).getEndTime() << "\n"
            << " \t\t|preferentialLevel: " << listPreferential.getAllocation().at(i).getPreferentialLevel() << "\n";
    }

    out << ']' << "\n";

    return out;
}


