
#include "LpiEmulatorMode.h"

std::ostream & operator<<(std::ostream & out,
                          const LpiEmulatorMode::LpiEnum & emulMode)
{
   switch (emulMode)
   {
   case LpiEmulatorMode::E_MODE_ON:
      out << "MODE_ON";
      break;
   case LpiEmulatorMode::E_MODE_OFF:
      out << "MODE_OFF";
      break;
   default:
      out << "NONE";
   }
   return out;
}

