
#ifndef LPIADAPTATIONRUNWAYSYSTEM_H_
#define LPIADAPTATIONRUNWAYSYSTEM_H_

#include <vector>
#include <iostream>
#include <algorithm>


typedef std::string LpiRunwaySystemName;

class OperationType
{
public:
   enum Enum
   {
      E_INVALID_RWY_OPERATION_TYPE, 
      E_DEPARTURES, 
      E_ARRIVALS, 
      E_MIXED
   };

   OperationType() : _enum(Enum(0)) {}
   OperationType(Enum value) : _enum(value) {}
   bool operator==(Enum value) const {return _enum == value;}
   operator Enum(void) const {return _enum;}

   static std::string getEnumToString(Enum value)
   {
       std::string result;
       switch(value){
       case E_DEPARTURES:
           result = "DEP";
           break;
       case E_ARRIVALS:
           result = "ARR";
           break;
       case E_MIXED:
           result = "MIX";
           break;
       default:
           result = "";
           break;
       }
       return result;
   }


private:
   Enum _enum;
}; // OperationType

std::ostream & operator<<(std::ostream & out, const OperationType::Enum & op);


class Runway
{
public:
   Runway() {}
   Runway(const Runway & source) : _runwayId(source._runwayId),
                                   _operation(source._operation)
   {}
   // getters
   const std::string& getrunwayId(void) const {return this->_runwayId;}
   const OperationType& getoperation(void) const {return this->_operation;}

   // setters
   void setrunwayId(const std::string& value) {this->_runwayId = value;}
   void setoperation(const OperationType& value) {this->_operation = value;}

   Runway & operator= (const Runway & source)
   {
      if (this != &source)
      {
         _runwayId = source._runwayId;
         _operation= source._operation;
      }
      return *this;
   }
   const std::string getNameOperation(void) const {return OperationType::getEnumToString(_operation);}

private:
   std::string _runwayId;
   OperationType _operation;

};
typedef std::vector<Runway> LpiRunwaySystem;

class LpiAdaptationRunwaySystem
{
public:
   LpiAdaptationRunwaySystem();
   LpiAdaptationRunwaySystem(const LpiAdaptationRunwaySystem & source)
   : _name(source._name), _LVPFeasibility(source._LVPFeasibility),
    _configuration(source._configuration),_runwaySystem(source._runwaySystem)
   {}
   ~LpiAdaptationRunwaySystem() {}

    // getters
   const std::string& getNameRunwaySystem(void) const{return this->_name;}
   const bool           getLVPFeasibility(void) const {return this->_LVPFeasibility;}
   const std::string& getConfiguration(void) const{return this->_configuration;}
   const LpiRunwaySystem getRunwaySystem(void) const {return this->_runwaySystem;}
   const Runway getRunwaySystemByIndex(unsigned int index) const {return this->_runwaySystem[index];}
   const LpiRunwaySystem& getRunwaySystem(void) {return this->_runwaySystem;}

    // setters
   void setNameRunwaySystem(const std::string &nameRunwaySystem) {this->_name = nameRunwaySystem;}
   void setLVPFeasibility(bool LVPFeasibility){this->_LVPFeasibility = LVPFeasibility;}
   void setConfiguration(const std::string &configuration) { this->_configuration =  configuration;}
   void setRunwaySystem(LpiRunwaySystem &runways) {this->_runwaySystem = runways;}

private:
    std::string          _name;
    bool                 _LVPFeasibility;
    std::string          _configuration;
    LpiRunwaySystem      _runwaySystem;
    
};


typedef std::vector<LpiAdaptationRunwaySystem> LpiAdaptationRunwaySystemList;


std::ostream & operator<<(std::ostream & out,
                          const LpiAdaptationRunwaySystemList & runwSystemList);


class LpiConfigurationGetter
{
   public:
      static std::vector<std::string> getConfigurationList (LpiAdaptationRunwaySystemList & rsList)
      {
         std::vector<std::string> result;
         for(unsigned int i = 0; i < rsList.size(); i++)
         {
            if(std::find(result.begin(), result.end(),
                     rsList[i].getConfiguration()) == result.end())
            {
               result.push_back(rsList[i].getConfiguration());
            }
         }

         return result;
      }
};



#endif /* LPIADAPTATIONRUNWAYSYSTEM_H_ */
