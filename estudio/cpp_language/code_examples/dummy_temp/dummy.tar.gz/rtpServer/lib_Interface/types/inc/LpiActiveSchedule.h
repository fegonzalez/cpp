#if !defined(__LPIACTIVESCHEDULE__)
#define __LPIACTIVESCHEDULE__

#include "LpiADO.h"
#include "LpiSchedule.h"

#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>


class LpiActiveSchedule : public LpiSchedule
{
   public:

      LpiActiveSchedule ();

      LpiActiveSchedule(const LpiActiveSchedule & source);
      LpiActiveSchedule(const LpiSchedule & source);

      virtual  ~LpiActiveSchedule () {}

      LpiActiveSchedule & operator= (const LpiActiveSchedule & source);

      // getters
      int getId() const
      { return r_id; }

      string getName() const
      { return r_name; }

      string getActivationTime() const
      { return r_activation_time; }

      bool getAvoidAutomaticDeletion() const
      { return r_avoidAutomaticDeletion; }

      // setters
      void setId(int newId)
      { r_id = newId; }

      void setName(string name)
      { r_name = name; }

      void setActivationTime (string timestamp)
      { r_activation_time = timestamp; }

      void setAvoidAutomaticDeletion(bool deletion)
      { r_avoidAutomaticDeletion = deletion; }

      void storeTimestamp (boost::posix_time::ptime timestamp);

   private:

      int     r_id;
      string  r_name;
      string  r_activation_time;
      bool r_avoidAutomaticDeletion;

};

std::ostream & operator<< (std::ostream & os, const LpiActiveSchedule & info);


#endif // __LPIACTIVESCHEDULE__
