
#include "LpiScheduleOrigin.h"


std::ostream& operator << (std::ostream &os,
                           const LpiScheduleOrigin::LpiEnum & obj)
{
   switch (obj)
   {
      case LpiScheduleOrigin::E_PREFERENTIAL:
         os << "Preferential Schedule";
      break;
      case LpiScheduleOrigin::E_OPTIMAL:
         os << "Optimal Schedule";
      break;
      case LpiScheduleOrigin::E_NEW_CRITERIA:
         os << "New Criteria";
      break;
      case LpiScheduleOrigin::E_MANUAL_EDITION:
         os << "Manual Edition";
      break;
      case LpiScheduleOrigin::E_RWY_CLOSURES_ACTIVE:
         os << "Runway Closures on Active Schedule";
      break;
      case LpiScheduleOrigin::E_SOLUTION_RWY_CLOSURES:
         os << "New Solution with Runway Closures";
      break;
      default:
         os << "Unknown";
      break;
   }

   return os;
}
