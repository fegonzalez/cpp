/*
 * LpiWarningsAlerts.h
 *
 *  Created on: 23/09/2014
 *      Author: mbegega
 */

#ifndef LPIWARNINGSALERTS_H_
#define LPIWARNINGSALERTS_H_

#include <string>
#include <iostream>

using std::string;

class Warnings_alerts
{
   public:
      enum LpiEnum
      { E_NO_ALERT = 0, E_WARNING, E_ALARM, E_SLIGHT_IMPROVEMENT, E_IMPROVEMENT };

      Warnings_alerts ()
      : arrivals(Warnings_alerts::E_NO_ALERT),
        departures(Warnings_alerts::E_NO_ALERT),
        overall(Warnings_alerts::E_NO_ALERT)
      {}

      Warnings_alerts (Warnings_alerts::LpiEnum arr,
                       Warnings_alerts::LpiEnum dep,
                       Warnings_alerts::LpiEnum ove)
      : arrivals(arr), departures(dep), overall(ove)
      {}

      Warnings_alerts (const Warnings_alerts & source);

      virtual  ~Warnings_alerts () {}

      Warnings_alerts::LpiEnum & operator[] (int index);
      Warnings_alerts::LpiEnum   operator[] (int index) const;

      Warnings_alerts & operator= (const Warnings_alerts & source);

      void reset();

      //getters
      const Warnings_alerts::LpiEnum & getarrivals   () const { return arrivals;   }
      const Warnings_alerts::LpiEnum & getdepartures () const { return departures; }
      const Warnings_alerts::LpiEnum & getoverall    () const { return overall;    }

      //setters
      void setarrivals   (const Warnings_alerts::LpiEnum & name) { arrivals = name;   }
      void setdepartures (const Warnings_alerts::LpiEnum & name) { departures = name; }
      void setoverall    (const Warnings_alerts::LpiEnum & name) { overall = name;    }

      static string ToString (const Warnings_alerts::LpiEnum & value);
      static Warnings_alerts::LpiEnum FromString(const string & value);

   private:

      Warnings_alerts::LpiEnum arrivals;
      Warnings_alerts::LpiEnum departures;
      Warnings_alerts::LpiEnum overall;
};


std::ostream & operator<<(std::ostream & os, const Warnings_alerts & warnings);


#endif /* LPIWARNINGSALERTS_H_ */
