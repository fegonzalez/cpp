/*
 * LpiWhatIfClosure.cc
 *
 *  Created on: 18/05/2015
 *      Author: mbegega
 */

#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiWhatIfClosure.h"


LpiBestPointClosure::LpiBestPointClosure()
: r_closure(),
  r_duration(0),
  r_minutesSubInterval(0)
{
}


int LpiBestPointClosure::getNumberOfOptions() const
{
   int options = 0;

   if (r_minutesSubInterval > 0)
   {
      boost::posix_time::ptime searchWindowStart = r_closure.getStartTime();
      boost::posix_time::ptime searchWindowEnd = r_closure.getEndTime();

      int minutesDiff = (searchWindowEnd - searchWindowStart).total_seconds() / 60;

      options = ((minutesDiff - r_duration) / r_minutesSubInterval) + 1;
   }

   return options;
}


boost::optional<LpiRunwayClosure> LpiBestPointClosure::getOption(int optionId) const
{
   if (optionId <= 0)
   {
      return boost::none;
   }
   else
   {
      boost::posix_time::ptime searchWindowStart = r_closure.getStartTime();
      boost::posix_time::ptime searchWindowEnd = r_closure.getEndTime();

      boost::posix_time::ptime startTime = searchWindowStart + boost::posix_time::minutes((optionId - 1) * r_minutesSubInterval);
      boost::posix_time::ptime endTime = startTime + boost::posix_time::minutes(r_duration);

      if (endTime > searchWindowEnd)
      {
         return boost::none;
      }
      return LpiRunwayClosure(r_closure.getRunwayId(), startTime, endTime, r_closure.getReason());
   }
}


std::ostream & operator<< (std::ostream & os, const LpiBestPointClosure & closure)
{
   os << "[ CLOSURE: " << closure.getClosure() << "\n"
      << "| DUR: " << closure.getDuration()
      << ']' << std::endl;

   return os;
}


LpiWhatIfClosure::LpiWhatIfClosure()
: r_id(-1),
  r_name(),
  r_avoidAutomaticDeletion(false),
  r_closureType(E_UNKNOWN),
  r_runwayClosures()
{
}


bool LpiWhatIfClosure::isBestPointClosureType() const
{
   return (r_closureType == LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE) ||
          (r_closureType == LpiWhatIfClosure::E_BEST_POINT_CLOSURE_FOR_ACTIVE);
}


LpiCalculationReason::LpiEnum LpiWhatIfClosure::getAssociatedCalculationReason() const
{
   LpiCalculationReason::LpiEnum reason = LpiCalculationReason::E_INIT;

   switch (r_closureType)
   {
      case LpiWhatIfClosure::E_APPLY_ON_ACTIVE:
         reason = LpiCalculationReason::E_WHAT_IF_APPLY_ON_ACTIVE;
      break;
      case LpiWhatIfClosure::E_NEW_OPTIMAL:
         reason = LpiCalculationReason::E_WHAT_IF_NEW_OPTIMAL;
      break;
      case LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE:
         reason = LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE;
      break;
      case LpiWhatIfClosure::E_BEST_POINT_CLOSURE_FOR_ACTIVE:
         reason = LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE;
      break;
      case LpiWhatIfClosure::E_UNKNOWN:
      default:
      break;
   }

   return reason;
}


LpiCalculationReason::LpiEnum LpiWhatIfClosure::getAssociatedCalculationReasonForUpdate() const
{
   LpiCalculationReason::LpiEnum reason = LpiCalculationReason::E_INIT;

   switch (r_closureType)
   {
      case LpiWhatIfClosure::E_APPLY_ON_ACTIVE:
         reason = LpiCalculationReason::E_WHAT_IF_APPLY_ON_ACTIVE_UPDATE;
      break;
      case LpiWhatIfClosure::E_NEW_OPTIMAL:
         reason = LpiCalculationReason::E_WHAT_IF_NEW_OPTIMAL_UPDATE;
      break;
      case LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE:
         reason = LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_UPDATE;
      break;
      case LpiWhatIfClosure::E_BEST_POINT_CLOSURE_FOR_ACTIVE:
         reason = LpiCalculationReason::E_WHAT_IF_BEST_POINT_CLOSURE_FOR_ACTIVE_UPDATE;
      break;
      case LpiWhatIfClosure::E_UNKNOWN:
      default:
      break;
   }

   return reason;
}


std::string LpiWhatIfClosure::ClosureTypeToString(const LpiWhatIfClosure::LpiWhatIfClosureType & closureType)
{
   std::string result;

   switch (closureType)
   {
      case LpiWhatIfClosure::E_UNKNOWN:
         result = "Unknown";
      break;
      case LpiWhatIfClosure::E_APPLY_ON_ACTIVE:
         result = "Apply on Active";
      break;
      case LpiWhatIfClosure::E_NEW_OPTIMAL:
         result = "New Optimal";
      break;
      case LpiWhatIfClosure::E_BEST_POINT_FOR_CLOSURE:
         result = "Best Point for Applying Closure";
      break;
      case LpiWhatIfClosure::E_BEST_POINT_CLOSURE_FOR_ACTIVE:
         result = "Best Point Closure for Active Schedule";
      break;
      default:
         result = "Unknown";
      break;
   }

   return result;
}


std::ostream & operator<< (std::ostream & os, const LpiWhatIfClosure & closures)
{
   os << "[ID: " << closures.getId()
      << " | NAME: " << closures.getName()
      << " | AVOID_DEL: " << "false\0true" + (6 * closures.getAvoidAutomaticDeletion())
      << " | TYPE: " << LpiWhatIfClosure::ClosureTypeToString(closures.getClosureType());

      if (closures.isBestPointClosureType())
      {
         os << " | BEST POINT:\n";
         os << closures.getBestPointClosure() << "\n";
      }
      else
      {
         os << " | RWY CLOSURES:\n";
         std::vector<LpiRunwayClosure> runwayClosures = closures.getClosures();
         std::copy(runwayClosures.begin(), runwayClosures.end(), std::ostream_iterator<LpiRunwayClosure>(os, "\n"));
      }
   os << ']';

   return os;
}
