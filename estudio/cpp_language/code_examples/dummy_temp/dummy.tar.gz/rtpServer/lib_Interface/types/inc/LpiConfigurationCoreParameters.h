// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 14:30:15 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPICONFIGURATIONCOREPARAMETERS_H_
#define LPICONFIGURATIONCOREPARAMETERS_H_

#include <LpiTimeParameters.h>

#include <iostream>

class PonderationSimMov
{
public:
    PonderationSimMov(){}
    ~PonderationSimMov(){}

    // getters
    double getWeightMean() const { return weightMean; }
    double getWeightNumSimMov() const { return weightNumSimMov; }

    // setters
    void setWeightMean(double value) { this->weightMean = value; }
    void setWeightNumSimMov(double value) { this->weightNumSimMov = value; }

private:
    double weightMean;
    double weightNumSimMov;

};


class PonderationMrtm
{
public:
    PonderationMrtm(){}
    ~PonderationMrtm(){}

    // getters
    double getWeightComplexityAirports() const { return _weightComplexityAirports; }
    double getWeightSimultaneousMov() const { return _weightSimultaneousMov; }
    double getWeightTotalMovMrtm() const { return _weightTotalMovMrtm; }
    double getWeightVfrMrtm() const { return _weightVfrMrtm; }

    // setters
    void setWeightComplexityAirports(double value) { this->_weightComplexityAirports = value; }
    void setWeightSimultaneousMov(double value) { this->_weightSimultaneousMov = value; }
    void setWeightTotalMovMrtm(double value) { this->_weightTotalMovMrtm = value; }
    void setWeightVfrMrtm(double value) { this->_weightVfrMrtm = value; }

private:
    double _weightComplexityAirports;
    double _weightSimultaneousMov;
    double _weightTotalMovMrtm;
    double _weightVfrMrtm;

};


class PonderationAirports
{
public:
    PonderationAirports(){}
    ~PonderationAirports(){}

    // getters
    double getWeightLVP() const { return _weightLVP; }
    double getWeightIce() const { return _weightIce; }
    double getWeightTotalMovAirport() const { return _weightTotalMovAirport; }
    double getWeightVfrAirport() const { return _weightVfrAirport; }

    // setters
    void setWeightLVP(double value) { this->_weightLVP = value; }
    void setWeightIce(double value) { this->_weightIce = value; }
    void setWeightTotalMovAirport(double value) { this->_weightTotalMovAirport = value; }
    void setWeightVfrAirport(double value) { this->_weightVfrAirport = value; }

private:
    double _weightLVP;
    double _weightIce;
    double _weightTotalMovAirport;
    double _weightVfrAirport;
};


class Ponderation
{
public:
    Ponderation() {}
    ~Ponderation() {}

    // getters
    double getWeightComplexity() const { return _weightComplexity; }
    double getWeightStability() const { return _weightStability; }
    double getWeightPreferentialAllocation() const { return _weightPreferentialAllocation; }
    double getWeightSelectMinMrtm() const { return _weightSelectMinMrtm; }
    double getWeightBalance() const { return _weightBalance; }

    // setters
    void setWeightComplexity(double value) { this->_weightComplexity = value; }
    void setWeightStability(double value) { this->_weightStability = value; }
    void setWeightPreferentialAllocation(double value) { this->_weightPreferentialAllocation = value; }
    void setWeightSelectMinMrtm(double value) { this->_weightSelectMinMrtm = value; }
    void setWeightBalance(double value) { this->_weightBalance = value; }

private:
    double _weightComplexity;
    double _weightStability;
    double _weightPreferentialAllocation;
    double _weightSelectMinMrtm;
    double _weightBalance;
};

//class TimeParameters
//{
//public:
//    TimeParameters() {}
//    ~TimeParameters() {}
//
//    // getters
//    int getHoursWindow() const { return this->_hoursWindow; }
//    int getMinutesSubinterval() const { return this->_minutesSubinterval; }
//    int getMinutesFrozen() const { return this->_minutesFrozen; }
//    int getMinutesFrozenForClock() const { return this->_minutesFrozenForClock; }
//
//    // setters
//    void setHoursWindow(int value) { this->_hoursWindow = value; }
//    void setMinutesSubinterval(int value) { this->_minutesSubinterval = value; }
//    void setMinutesFrozen(int value) { this->_minutesFrozen = value; }
//    void setMinutesFrozenForClock(int value) { this->_minutesFrozenForClock = value; }
//
//private:
//    int _hoursWindow;
//    int _minutesSubinterval;
//    int _minutesFrozen;
//    int _minutesFrozenForClock;
//
//};


class LpiConfigurationCoreParameters
{
public:
    LpiConfigurationCoreParameters() {}
    ~LpiConfigurationCoreParameters() {}


    // getters
    LpiTimeParameters getTimeParameters(void) const {return this->_timeParameters;}
    int getFpExpirationTime(void) const {return this->_fpExpirationTime;}
    Ponderation getTransitionWeightsPonderation(void) const {return this->_transitionWeightPonderation;}
    PonderationAirports getComplexityWeightPonderationAirports(void) const {return this->_complexityWeightPonderationAirports;}
    PonderationMrtm getComplexityWeightPonderationMrtm(void) const {return this->_complexityWeightPonderationMrtm;}
    PonderationSimMov getComplexityWeightPonderationSimMov(void) const {return this->_complexityWeightPonderationSimMov;}
    double getAlternativeAllocationsExpirationHours(void) const {return this->_alternativeAllocationsExpirationHours;}

    bool getUseWakeVortexCapacityReductions () const
    { return _useWakeVortexCapacityReductions; }

    // setters
    void setTimeParameters(const LpiTimeParameters value) { this->_timeParameters = value; }
    void setFpExpirationTime(const int value) { this->_fpExpirationTime = value; }
    void setPonderationParameters(const Ponderation value) { this->_transitionWeightPonderation = value; }
    void setComplexityWeightPonderationAirports(const PonderationAirports value) { this->_complexityWeightPonderationAirports = value; }
    void setComplexityWeightPonderationMrtm(const PonderationMrtm value) { this->_complexityWeightPonderationMrtm = value; }
    void setComplexityWeightPonderationSimMov(const PonderationSimMov value) { this->_complexityWeightPonderationSimMov = value; }
    void setAlternaticaAllocation(const double value) { this->_alternativeAllocationsExpirationHours = value; }

    void setUseWakeVortexCapacityReductions (bool value)
    { _useWakeVortexCapacityReductions = value; }

private:
    LpiTimeParameters _timeParameters;
    int _fpExpirationTime = rtp_constants::CORECONFIG_MINUTES_FP_EXPIRATION_TIME_DEFAULT_VALUE;
    Ponderation _transitionWeightPonderation;
    PonderationAirports _complexityWeightPonderationAirports;
    PonderationMrtm _complexityWeightPonderationMrtm;
    PonderationSimMov _complexityWeightPonderationSimMov;
    double _alternativeAllocationsExpirationHours;
    bool _useWakeVortexCapacityReductions;
};

std::ostream & operator<<(std::ostream & out,
                          const LpiConfigurationCoreParameters & confParams);



#endif /* LPICONFIGURATIONCOREPARAMETERS_H_ */
