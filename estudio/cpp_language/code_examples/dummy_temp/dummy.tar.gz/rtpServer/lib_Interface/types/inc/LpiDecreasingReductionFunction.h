/*
 * LpiDecreaseingReductionFunction.h
 *
 *  Created on: 19/02/2014
 *      Author: mbegega
 */

#ifndef LPIDECREASINGREDUCTIONFUNCTION_H_
#define LPIDECREASINGREDUCTIONFUNCTION_H_

#include <LcuDataTypeUtils.h>


//Functor Object, operator(double) returns reduced value,
//Parameters for reduction given on object construction

class LpiDecreasingReductionFunction
{
   public:

      LpiDecreasingReductionFunction() : r_lowerThreshold(0),
                                         r_upperThreshold(0),
                                         r_minimalReduction(0)
      {}

      LpiDecreasingReductionFunction(
                     double lower_threshold,
                     double upper_threshold,
                     double minimal_reduction):
                        r_lowerThreshold(lower_threshold),
                        r_upperThreshold(upper_threshold),
                        r_minimalReduction(minimal_reduction)
      {}

      double operator()(double X)
      {
         double capacity_reduction = 0.0;

         if (LcuDataTypeUtils::double_equals(r_lowerThreshold,0) && LcuDataTypeUtils::double_equals(r_upperThreshold,0) && LcuDataTypeUtils::double_equals(r_minimalReduction,0))
         {
            return 0.0;
         }
         else if (X < r_lowerThreshold)
         {
            capacity_reduction = 1.0;
         }
         else if (X > r_upperThreshold)
         {
            capacity_reduction = 0.0;
         }
         else
         {
            //Avoid infinites/Nan's
            if (LcuDataTypeUtils::double_equals(r_lowerThreshold,r_upperThreshold))
            {
               capacity_reduction = 1.0;
            }
            else
            {
               capacity_reduction = (((1.0 - r_minimalReduction) / (r_lowerThreshold - r_upperThreshold))
                                  * ( X - r_lowerThreshold)) + 1;
            }
         }
         return capacity_reduction;
      }

      double getLowerThreshold () const
      { return r_lowerThreshold; }

      double getUpperThreshold () const
      { return r_upperThreshold; }

      double getMinimalReduction () const
      { return r_minimalReduction; }

      LpiDecreasingReductionFunction & operator= (const LpiDecreasingReductionFunction & source)
      {
         if (this != &source)
         {
            r_lowerThreshold = source.r_lowerThreshold;
            r_upperThreshold = source.r_upperThreshold;
            r_minimalReduction = source.r_minimalReduction;
         }

         return *this;
      }

   private:

      double r_lowerThreshold;
      double r_upperThreshold;
      double r_minimalReduction;

};

#endif /* LPIDECREASINGREDUCTIONFUNCTION_H_ */
