
#ifndef LPIEMULATORMODE_H_
#define LPIEMULATORMODE_H_

#include <iostream>

class LpiEmulatorMode
{
public:

   enum LpiEnum
   {
      E_NONE = 0,
      E_MODE_ON,
      E_MODE_OFF
   };

};


std::ostream & operator<<(std::ostream & out,
                          const LpiEmulatorMode::LpiEnum & emulMode);


#endif /* LPIEMULATORMODE_H_ */
