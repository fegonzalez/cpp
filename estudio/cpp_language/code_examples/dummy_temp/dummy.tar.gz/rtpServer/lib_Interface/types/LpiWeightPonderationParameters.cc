/*
 * LpiWeightPonderationParameters.cc
 *
 *  Created on: 05/03/2014
 *      Author: mbegega
 */


#include "LpiWeightPonderationParameters.h"


std::ostream & operator<< (std::ostream & os, const LpiWeightPonderationParameters & parameters)
{
   return os << "[ DCB_S : " << parameters.getWeightDcbs()
             << "; ESTABILITY : " << parameters.getWeightStability()
             << "; PREF_RS : " << parameters.getWeightPreferentialRs() << "]";
}


