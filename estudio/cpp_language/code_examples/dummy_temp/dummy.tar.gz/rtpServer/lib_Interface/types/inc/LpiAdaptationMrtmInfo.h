
#ifndef LPIADAPTATIONMRTMINFO_H
#define LPIADAPTATIONMRTMINFO_H

#include <LplcTypeConstants.h>

#include <vector>
#include <iostream>

class SimultaneousOpsHour
{
public:
    SimultaneousOpsHour(){}
    ~SimultaneousOpsHour(){}

    // getters
    const double getComplexityDEPDEP(void) const {return this->_complexityDEPDEP;}
    const double getComplexityARRDEP(void) const {return this->_complexityARRDEP;}
    const double getComplexityARRARR(void) const {return this->_complexityARRARR;}

    // setters
   void setComplexityDEPDEP(const double value)  {_complexityDEPDEP=value;}
   void setComplexityARRDEP(const double value)  {_complexityARRDEP=value;}
   void setComplexityARRARR(const double value)  {_complexityARRARR=value;}


private:
    double _complexityDEPDEP;
    double _complexityARRDEP;
    double _complexityARRARR;
};

class ComplexityThresholds
{
public:
    ComplexityThresholds() {}
   ~ComplexityThresholds() {}

    // getters
   const unsigned int getTotalMovMrtmUpperThreshold(void) const {return this->_totalMovMrtmUpperThreshold;}
   const unsigned int getTotalMovMrtmLowerThreshold(void) const {return this->_totalMovMrtmLowerThreshold;}
   const SimultaneousOpsHour getSimultaneousOpsHour(void) const {return this->_simultaneousOpsHour;}
   const unsigned int getVfrMrtmUpperThreshold(void) const {return this->_vfrMrtmUpperThreshold;}
   const unsigned int getVfrMrtmLowerThreshold(void) const {return this->_vfrMrtmLowerThreshold;}

   // setters
   void setTotalMovMrtmUpperThreshold(const unsigned int value)  {_totalMovMrtmUpperThreshold=value;}
   void setTotalMovMrtmLowerThreshold(const unsigned int value)  {_totalMovMrtmLowerThreshold=value;}
   void setSimultaneousOpsHour(const SimultaneousOpsHour value)  {_simultaneousOpsHour=value;}
   void setVfrMrtmUpperThreshold(const unsigned int value)  {_vfrMrtmUpperThreshold=value;}
   void setVfrMrtmLowerThreshold(const unsigned int value)  {_vfrMrtmLowerThreshold=value;}


private:
   unsigned int _totalMovMrtmUpperThreshold;
   unsigned int _totalMovMrtmLowerThreshold;
   SimultaneousOpsHour _simultaneousOpsHour;
   unsigned int _vfrMrtmUpperThreshold;
   unsigned int _vfrMrtmLowerThreshold;
};


class LpiAdaptationMrtmInfo
{
public:
	LpiAdaptationMrtmInfo() {}
   ~LpiAdaptationMrtmInfo() {}

    // getters
   const unsigned int getMrtmAvailable(void) const {return this->_mrtmAvailable;}
   const unsigned int getMrtmAfisAirports(void) const {return this->_mrtmAfisAirports;}
   const unsigned int getMrtmAtsAirports(void) const {return this->_mrtmAtsAirports;}
   const unsigned int getMaxTotalMov(void) const {return this->_maxTotalMov;}
   const unsigned int getMaxSimultaneousOpsHour(void) const {return this->_maxSimultaneousOpsHour;}
   const unsigned int getSimultaneousOpsTime(void) const {return this->_simultaneousOpsTime;}
   const unsigned int getMrtmStayTime(void) const {return this->_mrtmStayTime;}
   const ComplexityThresholds getWorkloadThresholds(void) const {return this->_workloadThresholds;}

   // setters
   void setMrtmAvailable(const unsigned int value)  {_mrtmAvailable=value;}
   void setMrtmAfisAirports(const unsigned int value)  {_mrtmAfisAirports=value;}
   void setMrtmAtsAirports(const unsigned int value)  {_mrtmAtsAirports=value;}
   void setMaxTotalMov(const unsigned int value)  {_maxTotalMov=value;}
   void setMaxSimultaneousOpsHour(const unsigned int value)  {_maxSimultaneousOpsHour=value;}
   void setSimultaneousOpsTime(const unsigned int value)  {_simultaneousOpsTime=value;}
   void setMrtmStayTime(const unsigned int value)  {_mrtmStayTime=value;}
   void setWorkloadThresholds(const ComplexityThresholds value)  {_workloadThresholds=value;}


private:
   unsigned int _mrtmAvailable;
   unsigned int _mrtmAfisAirports;
   unsigned int _mrtmAtsAirports;
   unsigned int _maxTotalMov;
   unsigned int _maxSimultaneousOpsHour;
   unsigned int _simultaneousOpsTime;
   unsigned int _mrtmStayTime = rtp_constants::ADAP_MINUTES_MRTM_STAY_TIME_DEFAULT_VALUE;
   ComplexityThresholds _workloadThresholds;

};

std::ostream& operator<< (std::ostream & out, const LpiAdaptationMrtmInfo & mrtm);


#endif /* LPIADAPTATIONMRTMINFO_H */
