/*
 * LxiMaxILSCategory.cc
 *
 *  Created on: 02/12/2013
 *      Author: gpfernandez
 */
#include "LpiMaxILSCategory.h"



//------------------------------------------------------------------------------

/**@warning RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory
            EQUIVALENT_TO LpiMaxILSCategory::LpiEnumCatILS


   // IDEA: Possible conversion functions



#include <LpiAdaptationAirportsInfo.h>



LpiMaxILSCategory:: convert(const &RunwayMaxIlsCategory input)
{
  LpiMaxILSCategory::LpiEnumCatILS retvalValue = LpiMaxILSCategory::E_NO_ILS;
  
  switch(input.EnumRunwayMaxIlsCategory())
    {
    case RunwayMaxIlsCategory::NO_ILS:
      retvalValue = LpiMaxILSCategory::E_NO_ILS;
      break;
    case RunwayMaxIlsCategory::CAT_I:
      retvalValue = LpiMaxILSCategory::E_CAT_I;
      break;
    case RunwayMaxIlsCategory::CAT_II:
      retvalValue = LpiMaxILSCategory::E_CAT_II;
      break;
    case RunwayMaxIlsCategory::CAT_III_A:
      retvalValue = LpiMaxILSCategory::E_CAT_III_A;
      break;
    case RunwayMaxIlsCategory::CAT_III_B:
      retvalValue = LpiMaxILSCategory::E_CAT_III_B;
      break;
    case RunwayMaxIlsCategory::CAT_III_C:
      retvalValue = LpiMaxILSCategory::E_CAT_III_C;
      break;
    }

  return LpiMaxILSCategory(retvalValue);
}

//------------------------------------------------------------------------------

RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory
convert(const &LpiMaxILSCategory input)
{
  RunwayMaxIlsCategory::EnumRunwayMaxIlsCategory retvalValue =
    RunwayMaxIlsCategory::NO_ILS;
  
  switch(input.LpiEnumCatILS())
    {
    case LpiMaxILSCategory::E_NO_ILS:
      retvalValue = RunwayMaxIlsCategory::NO_ILS;
      break;
    case LpiMaxILSCategory::E_CAT_I:
      retvalValue = RunwayMaxIlsCategory::CAT_I;
      break;
    case LpiMaxILSCategory::E_CAT_II:
      retvalValue = RunwayMaxIlsCategory::CAT_II;
      break;
    case LpiMaxILSCategory::E_CAT_III_A:
      retvalValue = RunwayMaxIlsCategory::CAT_III_A;
      break;
    case LpiMaxILSCategory::E_CAT_III_B:
      retvalValue = RunwayMaxIlsCategory::CAT_III_B;
      break;
    case LpiMaxILSCategory::E_CAT_III_C:
      retvalValue = RunwayMaxIlsCategory::CAT_III_C;
      break;
    }

  return retvalValue;
}

*/

//------------------------------------------------------------------------------

std::ostream & operator<<(std::ostream &os,
                          const LpiMaxILSCategory::LpiEnumCatILS &obj)
{
   os << LpiMaxILSCategory::getEnumAsString(obj);
   return os;
}

