/*
 * LpiDemand.cpp
 *
 *  Created on: 24/02/2014
 *      Author: gpfernandez
 */

#include <iostream>
#include <sstream>
#include "LpiDemand.h"


//LpiDemand method implementations


//Demand_list
Demand_list::Demand_list()
{
}


std::string Demand_list::getIntervalName() const
{
    return r_interval_name;
}


void Demand_list::setIntervalName(std::string interval_name)
{
   r_interval_name = interval_name;
}


LpiADO Demand_list::getdemandForecastScheduled() const
{
   return r_demand_forecast_scheduled;
}


void Demand_list::setdemandForecastScheduled(LpiADO _demand_forecast_scheduled)
{
  r_demand_forecast_scheduled =  _demand_forecast_scheduled;
}


LpiADO Demand_list::getDemandRatio () const
{
   return r_demand_ratio;
}


void Demand_list::setDemandRatio (LpiADO ratio)
{
   r_demand_ratio = ratio;
}

LpiADO Demand_list::getDemandVFR () const
{
   return r_demand_vfr;
}


void Demand_list::setDemandVFR (LpiADO vfr)
{
   r_demand_vfr = vfr;
}



std::string Demand_list::getStarTime() const
{
    return r_start_time;
}


void Demand_list::setStartTime(std::string start_time)
{
   r_start_time = start_time;
}


std::string Demand_list::getEndTime() const
{
   return r_end_time;
}


void Demand_list::setEndTime(std::string end_time)
{
   r_end_time= end_time;
}


Demand_list & Demand_list::operator= ( const Demand_list & source)
{
   if (this != &source)
   {
      r_demand_forecast_scheduled = source.r_demand_forecast_scheduled;
      r_start_time = source.r_start_time;
      r_end_time   = source.r_end_time;
      r_demand_ratio = source.r_demand_ratio;
      r_demand_vfr = source.r_demand_vfr;
   }

   return *this;
}


//NumberDemand

NumberDemand::NumberDemand()
{
}


LpiADO NumberDemand::gettotalDemandForecast() const
{
   return r_total_demand_forecast;
}


void NumberDemand::settotalDemandForecast(LpiADO _totalDemandForecast)
{
    r_total_demand_forecast=_totalDemandForecast;
}


LpiADO NumberDemand::getTotalDemandRatio () const
{
   return r_total_demand_ratio;
}


void NumberDemand::setTotalDemandRatio (LpiADO total_ratio)
{
   r_total_demand_ratio = total_ratio;
}

LpiADO NumberDemand::getTotalDemandVFR () const
{
   return r_total_demand_vfr;
}


void NumberDemand::setTotalDemandVFR (LpiADO total_vfr)
{
   r_total_demand_vfr = total_vfr;
}


vector<Demand_list> NumberDemand::getDemand() const
{
   return r_demand;
}


void NumberDemand::setDemand(vector<Demand_list> _demand)
{
   r_demand = _demand;
}


NumberDemand & NumberDemand::operator= (const NumberDemand & source)
{
   if (this != &source)
   {
      r_demand = source.r_demand;
      r_total_demand_forecast = source.r_total_demand_forecast;
      r_total_demand_ratio = source.r_total_demand_ratio;
      r_total_demand_vfr = source.r_total_demand_vfr;
   }

   return *this;
}


//Fps_list

Fps_list::Fps_list()
{
}


std::string  Fps_list::getdemandForecastFpsScheduled() const
{
   return r_demand_forecast_fps_scheduled;
}
void Fps_list::setdemandForecastFpsScheduled(std::string _demand_forecast_fps_scheduled)
{
   
   r_demand_forecast_fps_scheduled = _demand_forecast_fps_scheduled;
}

std::string  Fps_list::getAircraftType() const
{
   return r_aircraft_type;
}
void Fps_list::setAircraftType(std::string _aircraft_type)
{
   
   r_aircraft_type = _aircraft_type;
}


//Flight Plan Times

void Fps_list::setItotIldt (times timestamp)
{
   r_itot_ildt = timestamp;
  
}


times Fps_list::getItotIldt () const
{
   return r_itot_ildt;
}


void Fps_list::setCtotSibt (times timestamp)
{
   r_ctot_sibt = timestamp;

}


times Fps_list::getCtotSibt () const
{
   return r_ctot_sibt;
}


void Fps_list::setEtotEldt (times timestamp)
{
   r_etot_eldt = timestamp;
}


times Fps_list::getEtotEldt () const
{
   return r_etot_eldt;
}


void Fps_list::setStotSldt (times timestamp)
{
   r_stot_sldt = timestamp;
}


times Fps_list::getStotSldt () const
{
   return r_stot_sldt;
}


void Fps_list::setTtotTldt (times timestamp)
{
   r_ttot_tldt = timestamp;
}


times Fps_list::getTtotTldt () const
{
   return r_ttot_tldt;
}


void Fps_list::setUtotUldt (times timestamp)
{
   r_utot_uldt = timestamp;
}


times Fps_list::getUtotUldt () const
{
   return r_utot_uldt;
}


LpiOperationType::LpiEnum Fps_list::getOperationType() const
{
   return r_operation_type;
}

void Fps_list::setOperationType(LpiOperationType::LpiEnum flightType)
{
   r_operation_type = flightType;
}

std::string Fps_list::getSIDSTAR() const
{
   return r_sid_star;
}

void Fps_list::setSIDSTAR(std::string sid_star)
{
   r_sid_star = sid_star;
}


void Fps_list::reset()
{
   r_itot_ildt = boost::none;
   r_ctot_sibt = boost::none;
   r_etot_eldt = boost::none;
   r_stot_sldt = boost::none;
   r_ttot_tldt = boost::none;
   r_utot_uldt = boost::none;
}


std::ostream & operator<< (std::ostream & out, const Fps_list & fp)
{
   out << "[CSG:" << fp.getdemandForecastFpsScheduled()
       << "| ITOT/ILDT: " <<  fp.getItotIldt()
       << "| CTOT/SIBT: " << fp.getCtotSibt()
       << "| ETOT/ELDT: " << fp.getEtotEldt()
       << "| STOT/SLDT: " << fp.getStotSldt()
       << "| TTOT/TLDT: " << fp.getTtotTldt()
       << "| UTOT/ULDT: " << fp.getUtotUldt();

   return out;
}


//LpiDemand
LpiDemand::LpiDemand ()
{
}

LpiDemand::LpiDemand(LpiDemand const&) = default;

LpiDemand& LpiDemand::operator =(const LpiDemand& source)
{
   
   unsigned int i=0;
   messageTimeandDate = source.messageTimeandDate;
   calculationReason = source.calculationReason;
   r_demand = source.r_demand;
   
   //r_fps.resize(source.r_fps.size());
   for ( i = 0; i < source.r_fps.size(); i++)
   {
      r_fps.push_back( source.r_fps[i]);
   }

   return *this;
}

posix_time::ptime LpiDemand::getmessageTimeandDate() const
{
   return messageTimeandDate;
}

void LpiDemand::setmessageTimeandDate(posix_time::ptime _messageTimeandDate)
{
   messageTimeandDate=_messageTimeandDate;
}


const vector<FPs_ADO> & LpiDemand::getFps() const
{
   return r_fps;
}

void LpiDemand::setFps(vector<FPs_ADO> _fps)
{
   //r_fps.resize(_fps.size());
   for(unsigned int i = 0; i< _fps.size(); i++)
   {
      r_fps.push_back(_fps[i]);
   }
}

NumberDemand LpiDemand::getDemand() const
{
   return r_demand;
}

void LpiDemand::setDemand(NumberDemand _demand)
{
   r_demand = _demand;
}

const LpiFlightPlanList & LpiDemand::getFlightPlanList() const {
	return r_flightPlanList;
}

void LpiDemand::setFlightPlanList(const LpiFlightPlanList & fpList)
{
	for(unsigned int i = 0; i< fpList.size(); i++)
	{
		r_flightPlanList.push_back(fpList[i]);
	}
}


std::ostream& operator<< (std::ostream & out, const LpiDemand & demand)
{
   
   return out << "[messageTimeandDate: " << demand.getmessageTimeandDate()
                         << "]" << std::endl;


}


