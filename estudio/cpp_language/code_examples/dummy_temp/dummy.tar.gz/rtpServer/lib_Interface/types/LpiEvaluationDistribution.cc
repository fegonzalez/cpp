
#include "LpiEvaluationDistribution.h"


std::ostream & operator<<(std::ostream & out,
                          const LpiEvaluationDistribution & distribution)
{
   return out << "[M: "
              << distribution.getMean()
              << ", SIGMA: "
              << distribution.getStandardDeviation() << ']';
}

