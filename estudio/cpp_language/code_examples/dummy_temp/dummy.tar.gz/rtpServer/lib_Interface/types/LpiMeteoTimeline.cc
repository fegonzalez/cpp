/*
 * LpiMeteoTimeLine.cc
 *
 *  Created on: 19/03/2015
 *      Author: mbegega
 */

#include "LpiMeteoTimeline.h"

LpiMeteoIntervalData::LpiMeteoIntervalData
(optional<double> horizontalVisibility,
 string wetness,
 string ilsCategory,
 optional<bool> lvpActivation,
 optional<bool> deicingRequired,
 // optional<double> crosswind,
 // optional<double> tailwind,
 optional<unsigned int> windSpeed,
 optional<unsigned int> windDirection)
  : r_horizontalVisibility(horizontalVisibility),
    r_wetness(wetness),
    r_ilsCategory(ilsCategory),
    r_lvpActivation(lvpActivation),
    r_deicingRequired(deicingRequired),
    // r_crosswind(crosswind),
    // r_tailwind(tailwind),
    r_windSpeed(windSpeed),
    r_windDirection(windDirection)
{
}


LpiMeteoInterval::LpiMeteoInterval(const std::string & name,
				   const std::string & beginTime,
				   const std::string & endTime,
				   const LpiMeteoIntervalData & data)
: r_name(name),
  r_beginTime(beginTime),
  r_endTime(endTime),
  r_data(data)
{
}


LpiMeteoTimeline::LpiMeteoTimeline()
: r_meteoIntervals()
{
}

// get operator
const LpiMeteoInterval & LpiMeteoTimeline::operator[] (unsigned int index) const
{
  assert(index < size());
  return r_meteoIntervals[index];
}

// set operator:
LpiMeteoInterval & LpiMeteoTimeline::operator[] (unsigned int index)
{
  assert(index < size());
  return r_meteoIntervals[index];
}



void LpiMeteoTimeline::push_back(const LpiMeteoInterval &newdata)
{
	r_meteoIntervals.push_back(newdata);
}

// void LpiMeteoTimeline::setValue(const unsigned int &index, const LpiMeteoInterval& value)
// {
//   assert(index < size());
//   r_meteoIntervals[i] = value;
// }


void LpiMeteoTimeline::clear()
{
  r_meteoIntervals.clear();
}

//------------------------------------------------------------------------------

std::ostream& operator<< (std::ostream & out, const LpiMeteoTimeline & obj)
{
	std::for_each(std::begin(obj.getAllScheduleIntervals()),
		  	  	    std::end(obj.getAllScheduleIntervals()),
					[&out](const LpiMeteoInterval &val)
	              { out << val << "\n"; });

	return out;
}

//------------------------------------------------------------------------------

std::ostream& operator<< (std::ostream & out, const LpiMeteoInterval & obj)
{
  out << "\n[INTERVAL: <" << obj.getName() << ">\n"
      << " | r_beginTime: " << obj.getBeginTime() << "\n"
      << " | r_endTime: " << obj.getEndTime() << "\n"
      << " | LpiMeteoIntervalData: [ " << obj.getData() << " ]\n";

  out << ']' << "\n";

  return out;
}

//------------------------------------------------------------------------------

std::ostream& operator<< (std::ostream & out, const LpiMeteoIntervalData & obj)
{

  if (obj.getHorizontalVisibility())
  {
	  out << ",\n horizontalVisibility: " << *obj.getHorizontalVisibility();
  }
  else
  {
	  out << ",\n horizontalVisibility: ---";
  }

  out << ",\n getWetness: " << obj.getWetness();
  out << ",\n getILSCategory: " << obj.getILSCategory();

  if (obj.getLVPActivation())
  {
	  out << ",\n getLVPActivation: " << *obj.getLVPActivation();
  }
  else
  {
	  out << ",\n getLVPActivation: ---";
  }

  if (obj.getDeicingRequired())
  {
	  out << ",\n getDeicingRequired: " << *obj.getDeicingRequired();
  }
  else
  {
	  out << ",\n getDeicingRequired: ---";
  }

  // if (obj.getCrosswind())
  // {
  // 	  out << ",\n getCrosswind: " << *obj.getCrosswind();
  // }
  // else
  // {
  // 	  out << ",\n getCrosswind: ---";
  // }

  // if (obj.getTailwind())
  // {
  // 	  out << ",\n getTailwind: " << *obj.getTailwind();
  // }
  // else
  // {
  // 	  out << ",\n getTailwind: ---";
  // }

  if (obj.getWindSpeed())
  {
	  out << ",\n getWindSpeed: " << *obj.getWindSpeed();
  }
  else
  {
	  out << ",\n getWindSpeed: ---";
  }

  if (obj.getWindDirection())
  {
	  out << ",\n getWindDirection: " << *obj.getWindDirection();
  }
  else
  {
	  out << ",\n getWindDirection: ---";
  }

  return out;
}


