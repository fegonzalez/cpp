/*
 *
 *  DOC Reference: [1] "RTP Diseño Funcional.docx"
 */

#ifndef LPIADAPTATIONAIRPORTSINFO_H_
#define LPIADAPTATIONAIRPORTSINFO_H_


#include <LpiADO.h>
#include <vector>
#include <iostream>
#include <string>
#include <boost/optional.hpp>

class ActivationConditions
{

public:
    ActivationConditions() {}
    ~ActivationConditions() {}
    //getters
    const std::string getConditionName(void) const { return this->_conditionName; }
    const unsigned int getConditionValue(void) const { return this->_conditionValue; }

    // setters
    void setConditionName(const std::string value) { this->_conditionName=value; }
    void setTotalConditionValue(const unsigned int value) { this->_conditionValue=value; }
private:
   std::string _conditionName;
   unsigned int _conditionValue;

};

typedef std::vector<ActivationConditions> LvpActivacionConditonsList;

class ComplexityAirportsThresholds
{
public:
    ComplexityAirportsThresholds() {}
    ~ComplexityAirportsThresholds() {}

    // getters
    const unsigned int getTotalMovAirportUpperThreshold(void) const { return this->_totalMovAirportUpperThreshold; }
    const unsigned int getTotalMovAirportLowerThreshold(void) const { return this->_totalMovAirportLowerThreshold; }
    const unsigned int getVfrAirportUpperThreshold(void) const { return this->_vfrAirportUpperThreshold; }
    const unsigned int getVfrAirportLowerThreshold(void) const { return this->_vfrAirportLowerThreshold; }

    // setters
    void setTotalMovAirportUpperThreshold(const unsigned int value) { this->_totalMovAirportUpperThreshold=value; }
    void setTotalMovAirportLowerThreshold(const unsigned int value) { this->_totalMovAirportLowerThreshold=value; }
    void setVfrAirportUpperThreshold(const unsigned int value) { this->_vfrAirportUpperThreshold=value; }
    void setVfrAirportLowerThreshold(const unsigned int value) { this->_vfrAirportLowerThreshold=value; }

private:
    unsigned int _totalMovAirportUpperThreshold;
    unsigned int _totalMovAirportLowerThreshold;
    unsigned int _vfrAirportUpperThreshold;
    unsigned int _vfrAirportLowerThreshold;
};

/**@class Max_ILS_Category
 *
 * @warning Data type equivalent to LpiMaxILSCategory at
 *               "rtpServer/lib_Interface/types/INC/LpiMaxILSCategory.h"
 *
 *
 * @warning Restriction order, most restrictive to less restrictive:
 *          NO_ILS, CAT_I, ..., CAT_III_C
 *
 * @warning Restriction order and NO_ILS: NO_ILS means that the
 *          airport doesn't have an ILS equipment.  Although not an
 *          actual ILS category, it is taken as the most restrictive
 *          value, because if the airport actual value is NO_ILS then
 *          the airport will only work at full capacity when the
 *          REQUIRED conditions are also NO_ILS.
 *
 * @warning operator<() meaning:   X < Y =>  X is more restrictive than Y:
 *          (e.g.: CAT_I < CAT_II  is true, because CAT_I is more restrictive.)
 *          (e.g.: NO_ILS < CAT_I  is true, because NO_ILS is more restrictive.)
 *
 */
class Max_ILS_Category
{
public:
    enum EnumMax_ILS_Category
    {
        NO_ILS,    // the most restrictive ()
        CAT_I,
        CAT_II,
        CAT_III_A,
        CAT_III_B,
        CAT_III_C   // the less restrictive
    };

    Max_ILS_Category() 
      : _enumMax_ILS_Category(EnumMax_ILS_Category(0)) {}
    Max_ILS_Category(EnumMax_ILS_Category value) 
      : _enumMax_ILS_Category(value) {}
    
    ///@warning set as 'NO_ILS' if value isn't a valid EnumMax_ILS_Category
    Max_ILS_Category(const std::string & value);

    bool operator==(EnumMax_ILS_Category value) const 
    {return _enumMax_ILS_Category == value;}
    bool operator<(const EnumMax_ILS_Category &value) const;
    operator EnumMax_ILS_Category(void) const 
    {return _enumMax_ILS_Category;}

    std::string toString() const;

private:
    EnumMax_ILS_Category _enumMax_ILS_Category;

};

class Bound
{
public:
    Bound() {}
    ~Bound() {}

    // getters
    const unsigned int getUpperBound(void) const { return this->_upperBound; }
    const unsigned int getLowerBound(void) const { return this->_lowerBound; }

    // setters
    void setUpperBound(const unsigned int value) { this->_upperBound = value; }
    void setLowerBound(const unsigned int value) { this->_lowerBound = value; }

private:
    unsigned int _upperBound;
    unsigned int _lowerBound;
};


class CatILs
{
public:
    CatILs() {}
    ~CatILs() {}

    // getters
    const Max_ILS_Category getIdCatILs(void) const { return this->_idCatILs; }
    const boost::optional<Bound> getCloudBase(void) const { return this->_cloudBase; }
    const Bound getRvrType(void) const { return this->_rvrType; }
    const boost::optional<Bound> getHorizontalVisibility(void) const { return this->_horizontalVisibility; }

    // setters
    void setIdCatILs(const Max_ILS_Category value) { this->_idCatILs = value; }
    void setCloudBase(const boost::optional<Bound> value) { this->_cloudBase = value; }
    void setRvrType(const Bound value) { this->_rvrType = value; }
    void setHorizontalVisibility(const boost::optional<Bound> value) { this->_horizontalVisibility = value; }

private:
    Max_ILS_Category _idCatILs;
    boost::optional<Bound> _cloudBase;
    Bound _rvrType;
    boost::optional<Bound> _horizontalVisibility;
};
typedef std::vector<CatILs> CatILsList;


class RunwaysAirports
{
public:
    ~RunwaysAirports() {}
    RunwaysAirports() = default;
    RunwaysAirports(const RunwaysAirports & source) = default;
    RunwaysAirports & operator= (const RunwaysAirports & source) = default;

    // getters
    const std::string getRunwayName(void) const { return this->_runwayName; }
    const boost::optional<double> getRunwayThreshold1Latitude(void) const { return this->_runwayThreshold1Latitude; }
    const boost::optional<double> getRunwayThreshold1Longitude(void) const { return this->_runwayThreshold1Longitude; }
    const boost::optional<double> getRunwayThreshold2Latitude(void) const { return this->_runwayThreshold2Latitude; }
    const boost::optional<double> getRunwayThreshold2Longitude(void) const { return this->_runwayThreshold2Longitude; }
    const unsigned int getCrosswindUpperThresholdDry(void) const { return this->_crosswindUpperThresholdDry; }
    const unsigned int getCrosswindLowerThresholdDry(void) const { return this->_crosswindLowerThresholdDry; }
    const unsigned int getCrosswindUpperThresholdWet(void) const { return this->_crosswindUpperThresholdWet; }
    const unsigned int getCrosswindLowerThresholdWet(void) const { return this->_crosswindLowerThresholdWet; }
    const double getCrosswindMinReduction(void) const { return this->_crosswindMinReduction; }
    const unsigned int getTailwindUpperThresholdDry(void) const { return this->_tailwindUpperThresholdDry; }
    const unsigned int getTailwindLowerThresholdDry(void) const { return this->_tailwindLowerThresholdDry; }
    const unsigned int getTailwindUpperThresholdWet(void) const { return this->_tailwindUpperThresholdWet; }
    const unsigned int getTailwindLowerThresholdWet(void) const { return this->_tailwindLowerThresholdWet; }
    const double getTailwindMinReduction(void) const { return this->_tailwindMinReduction; }
    const unsigned int getHorizontalVisibilityUpperThreshold(void) const { return this->_horizontalVisibilityUpperThreshold; }
    const unsigned int getHorizontalVisibilityLoweThreshold(void) const { return this->_horizontalVisibilityLoweThreshold; }
    const double getHorizontalMinReduction(void) const { return this->_horizontalMinReduction; }


    // setters
    void setRunwayName(const std::string &value) { this->_runwayName = value; }
    void setRunwayThreshold1Latitude(const boost::optional<double> &value) { this->_runwayThreshold1Latitude=value; }
    void setRunwayThreshold1Longitude(const boost::optional<double> &value) { this->_runwayThreshold1Longitude=value; }
    void setRunwayThreshold2Latitude(const boost::optional<double> &value) { this->_runwayThreshold2Latitude=value; }
    void setRunwayThreshold2Longitude(const boost::optional<double> &value) { this->_runwayThreshold2Longitude=value; }
    void setCrosswindUpperThresholdDry(const unsigned int &value) { this->_crosswindUpperThresholdDry=value; }
    void setCrosswindLowerThresholdDry(const unsigned int &value) { this->_crosswindLowerThresholdDry=value; }
    void setCrosswindUpperThresholdWet(const unsigned int &value) { this->_crosswindUpperThresholdWet=value; }
    void setCrosswindLowerThresholdWet(const unsigned int &value) { this->_crosswindLowerThresholdWet=value; }
    void setCrosswindMinReduction(const double &value) { this->_crosswindMinReduction=value; }
    void setTailwindUpperThresholdDry(const unsigned int &value) { this->_tailwindUpperThresholdDry=value; }
    void setTailwindLowerThresholdDry(const unsigned int &value) { this->_tailwindLowerThresholdDry=value; }
    void setTailwindUpperThresholdWet(const unsigned int &value) { this->_tailwindUpperThresholdWet=value; }
    void setTailwindLowerThresholdWet(const unsigned int &value) { this->_tailwindLowerThresholdWet=value; }
    void setTailwindMinReduction(const double &value) { this->_tailwindMinReduction=value; }
    void setHorizontalVisibilityUpperThreshold(const unsigned int &value) { this->_horizontalVisibilityUpperThreshold=value; }
    void setHorizontalVisibilityLoweThreshold(const unsigned int &value) { this->_horizontalVisibilityLoweThreshold=value; }
    void setHorizontalMinReduction(const double &value) { this->_horizontalMinReduction=value; }

private:
    std::string _runwayName;

    // [deg] threshold1 (inicio la/lon), threshold2 (fin la/lon), for each runway
    boost::optional<double> _runwayThreshold1Latitude;   
    boost::optional<double> _runwayThreshold1Longitude;
    boost::optional<double> _runwayThreshold2Latitude;
    boost::optional<double> _runwayThreshold2Longitude;

    // [1].4.2.2. - Viento
    unsigned int _crosswindUpperThresholdDry;
    unsigned int _crosswindLowerThresholdDry;
    unsigned int _crosswindUpperThresholdWet;
    unsigned int _crosswindLowerThresholdWet;
    double _crosswindMinReduction;
    unsigned int _tailwindUpperThresholdDry;
    unsigned int _tailwindLowerThresholdDry;
    unsigned int _tailwindUpperThresholdWet;
    unsigned int _tailwindLowerThresholdWet;
    double _tailwindMinReduction;
    unsigned int _horizontalVisibilityUpperThreshold;
    unsigned int _horizontalVisibilityLoweThreshold;
    double _horizontalMinReduction;

};

typedef std::vector<RunwaysAirports> RunwaysAirportsList;

class AirportMaxNominalCapacity
{
public:
    AirportMaxNominalCapacity(){}
    ~AirportMaxNominalCapacity(){}

    // getters
    const unsigned int getArrivalsValue(void) const { return this->_arrivalsValue; }
    const unsigned int getDeparturesValue(void) const { return this->_departuresValue; }
    const unsigned int getOverallValue(void) const { return this->_overallValue; }

    // setters
    void setArrivalsValue(const unsigned int value) { this->_arrivalsValue = value; }
    void setDeparturesValue(const unsigned int value) { this->_departuresValue = value; }
    void setOverallValue(const unsigned int value) { this->_overallValue = value; }

private:
    unsigned int _arrivalsValue;
    unsigned int _departuresValue;
    unsigned int _overallValue;
};

class AirportType
{
public:
    enum EnumAirportType
    {
        AFIS,
        ATS
    };

    AirportType() : _enumAirportType(EnumAirportType(0)) {}
    AirportType(EnumAirportType value) : _enumAirportType(value) {}
    bool operator==(EnumAirportType value) const {return _enumAirportType == value;}
    operator EnumAirportType(void) const {return _enumAirportType;}

private:
    EnumAirportType _enumAirportType;
};


class Airport
{
public:
    Airport() {}
    ~Airport() {}

    // getters
    const std::string getAirportName(void) const { return this->_airportName; }
    const AirportType getAirportType(void) const {return this->_airportType; }
    const AirportMaxNominalCapacity getAirportMaxNominal(void) const { return this->_airportMaxNominal; }
    const LpiADOVector<unsigned int> getTaxywaysMaxNominalCapacity(void) const 
    { return this->_taxywaysMaxNominalCapacity; }
    const LpiADOVector<unsigned int> getTmaMaxNominalCapacity(void) const 
    { return this->_tmaMaxNominalCapacity; }
    const Max_ILS_Category getAirportMaxILsCategory(void) const { return this->_airportMaxILsCategory; }
    const RunwaysAirportsList getRunways(void) const {return this->_runway; }
    const LvpActivacionConditonsList getLvpActivationConditions(void) const {return this->_lvpActivationConditions; }
    const CatILsList getCatILs(void) const {return this->_catILs; }
    const ComplexityAirportsThresholds getComplexityThresholds(void) const {return this->_complexityThresholds; }

    // setters
    void setAirportName(const std::string value) { this->_airportName = value; }
    void setAirportType(const AirportType value) { this->_airportType = value; }
    void setAirportMaxNominal(const AirportMaxNominalCapacity value) { this->_airportMaxNominal=value; }
    void setTaxywaysMaxNominalCapacity(const LpiADOVector<unsigned int> &value) 
    { this->_taxywaysMaxNominalCapacity = value; }
    void setTmaMaxNominalCapacity(const LpiADOVector<unsigned int> &value) 
    { this->_tmaMaxNominalCapacity = value; }
    void setAirportMaxILsCategory(const Max_ILS_Category value) { this->_airportMaxILsCategory=value; }
    void setRunway(const RunwaysAirportsList value) { this->_runway = value; }
    void setLvpActivationConditions(const LvpActivacionConditonsList value) { this->_lvpActivationConditions = value; }
    void setCatILs(const CatILsList value) { this->_catILs = value; }
    void setComplexityThresholds(const ComplexityAirportsThresholds value) { this->_complexityThresholds = value; }

private:
    std::string _airportName;
    AirportType _airportType;
    AirportMaxNominalCapacity _airportMaxNominal;
    LpiADOVector<unsigned int> _taxywaysMaxNominalCapacity;
    LpiADOVector<unsigned int> _tmaMaxNominalCapacity;
    Max_ILS_Category _airportMaxILsCategory;
    RunwaysAirportsList _runway;
    LvpActivacionConditonsList _lvpActivationConditions;
    CatILsList _catILs;
    ComplexityAirportsThresholds _complexityThresholds;

};

typedef std::vector <Airport> AirportVector;

class LpiAdaptationAirportsInfo
{
public:
   LpiAdaptationAirportsInfo() {}
   ~LpiAdaptationAirportsInfo() {};

   // getters
   const AirportVector getAirport(void) const { return this->_airport; }

   ///@return empty Airport (id="") if 'id' not found
   ///@warning exists() SHOULD be called before to assert that the airport exists
   const Airport operator[](const std::string & id) const;

   bool exists(const std::string & id) const;

   // setters
   void setAirport(const AirportVector value) {_airport = value; }

private:
   AirportVector _airport;

};

std::ostream& operator<< (std::ostream & out, const LpiAdaptationAirportsInfo & ap);

#endif /* LPIADAPTATIONAIRPORTSINFO_H_ */
