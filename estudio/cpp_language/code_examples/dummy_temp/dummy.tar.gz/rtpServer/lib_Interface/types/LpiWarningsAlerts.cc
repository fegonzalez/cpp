/*
 * LpiWarningsAlerts.cc
 *
 *  Created on: 23/09/2014
 *      Author: mbegega
 */

#include "LpiADO.h"
#include "LpiWarningsAlerts.h"

Warnings_alerts::Warnings_alerts (const Warnings_alerts & source)
: arrivals(source.getarrivals()),
  departures(source.getdepartures()),
  overall(source.getoverall())
{
}


Warnings_alerts::LpiEnum & Warnings_alerts::operator[] (int index)
{
   switch (index)
   {
      case E_ARR:
         return arrivals;
      break;
      case E_DEP:
         return departures;
      break;
      default:
         return overall;
   }
}


Warnings_alerts::LpiEnum   Warnings_alerts::operator[] (int index) const
{
   switch (index)
   {
      case E_ARR:
         return arrivals;
      break;
      case E_DEP:
         return departures;
      break;
      default:
         return overall;
   }
}


void Warnings_alerts::reset()
{
   arrivals = Warnings_alerts::E_NO_ALERT;
   departures = Warnings_alerts::E_NO_ALERT;
   overall = Warnings_alerts::E_NO_ALERT;
}


Warnings_alerts & Warnings_alerts::operator= (const Warnings_alerts & source)
{
   if (this != &source)
   {
      arrivals  = source.getarrivals();
      departures= source.getdepartures();
      overall   = source.getoverall();
   }

   return *this;
}


string Warnings_alerts::ToString (const Warnings_alerts::LpiEnum & value)
{
   string result = "No Alert";

   switch(value)
   {
      case Warnings_alerts::E_NO_ALERT:
         result = "No Alert";
      break;
      case Warnings_alerts::E_WARNING:
         result = "Warning";
      break;
      case Warnings_alerts::E_ALARM:
         result = "Alarm";
      break;
      case Warnings_alerts::E_SLIGHT_IMPROVEMENT:
         result = "Slight Improvement";
      break;
      case Warnings_alerts::E_IMPROVEMENT:
         result = "Improvement";
      break;
      default:
      break;
   }

   return result;
}


Warnings_alerts::LpiEnum Warnings_alerts::FromString(const string & value)
{
   Warnings_alerts::LpiEnum result = Warnings_alerts::E_NO_ALERT;

   if (value == "No Alert")
   {
      result = Warnings_alerts::E_NO_ALERT;
   }
   else if (value == "Warning")
   {
      result = Warnings_alerts::E_WARNING;
   }
   else if (value == "Alarm")
   {
      result = Warnings_alerts::E_ALARM;
   }
   else if (value == "Slight Improvement")
   {
      result = Warnings_alerts::E_SLIGHT_IMPROVEMENT;
   }
   else if (value == "Improvement")
   {
      result = Warnings_alerts::E_IMPROVEMENT;
   }
   return result;
}


std::ostream & operator<<(std::ostream & os, const Warnings_alerts & warnings)
{

   os << "("  << Warnings_alerts::ToString(warnings.getarrivals())
      << ", " << Warnings_alerts::ToString(warnings.getdepartures())
      << ", " << Warnings_alerts::ToString(warnings.getoverall()) << ')';

   return os;
}

