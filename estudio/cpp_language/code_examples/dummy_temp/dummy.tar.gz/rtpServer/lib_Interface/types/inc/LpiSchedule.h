#if !defined(__LPISCHEDULE__)
#define __LPISCHEDULE__

#include <vector>
#include <iostream>
#include <string>
#include <boost/optional/optional.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiADO.h"
#include "LpiCalculationReason.h"
#include "LpiComparativeKpis.h"
#include "LpiKPIs.h"
#include "LpiCapacityInfo.h"
#include "LpiActivationType.h"


using std::string;
using namespace boost;


class LpiScheduleDemand
{
   public:
      LpiADO rIntentionalDemand;
      LpiADO rInheritedDemand;
      LpiADO rTotalDemand;
};


class LpiRS_Scheduled
{
   public:

     LpiRS_Scheduled () {}
     LpiRS_Scheduled (string rs,
                      string arr_rwys,
                      string dep_rwys,
                      string cfg);

     LpiRS_Scheduled (const LpiRS_Scheduled &source);

     virtual ~LpiRS_Scheduled () {}

     LpiRS_Scheduled & operator= (const LpiRS_Scheduled & source);

     // getters

     const string & getRunwaySystem () const  { return r_runway_system; }
     const string & getRunwayArr () const     { return r_runwayArr; }
     const string & getRunwayDep () const     { return r_runwayDep; }
     const string & getConfiguration () const { return r_configuration; }

     // setters

     void setRunwaySystem (const string & runway_system)  { r_runway_system = runway_system; }
     void setRunwayArr    (const string & runway )        { r_runwayArr = runway; }
     void setRunwayDep    (const string & runway )        { r_runwayDep = runway; }
     void setConfiguration (const string & configuration) { r_configuration = configuration; }

   private:

     string r_runway_system;
     string r_runwayArr;
     string r_runwayDep;
     string r_configuration;
};


class LpiTimeIntervalData
{
   public:
      LpiTimeIntervalData() {}
      LpiTimeIntervalData(string name, string beginTime, string endTime);
      LpiTimeIntervalData(const LpiTimeIntervalData & source);

      LpiTimeIntervalData & operator= (const LpiTimeIntervalData & source);

      //Getters
      const string & getName() const
      { return r_name; }

      const string & getBeginTime() const
      { return r_begin_time; }

      const string & getEndTime() const
      { return r_end_time; }

      const LpiRS_Scheduled & getRSScheduled() const
      { return r_rsScheduled; }

      const LpiScheduleDemand & getDemand() const
      { return r_demand; }

      //Setters
      void setName(const string & name)
      { r_name = name; }

      void setBeginTime(const string & begin_time)
      { r_begin_time = begin_time; }

      void setEndTime(const string & end_time)
      { r_end_time = end_time; }

      void setRSScheduled (const LpiRS_Scheduled & data)
      { r_rsScheduled = data; }

      void setDemand (const LpiScheduleDemand & data)
      { r_demand = data; }

   private:
      string r_name;
      string r_begin_time;
      string r_end_time;

      LpiRS_Scheduled   r_rsScheduled;
      LpiScheduleDemand r_demand;
};


class LpiScheduleTimeLine
{
   public:

      LpiScheduleTimeLine () {}
      LpiScheduleTimeLine (const LpiScheduleTimeLine &source);

      virtual  ~LpiScheduleTimeLine () {}

      LpiScheduleTimeLine & operator= (const LpiScheduleTimeLine & source);

      //getters
      LpiTimeIntervalData getScheduleInterval(int i) const;
      std::vector<LpiTimeIntervalData> getAllScheduleIntervals() const;

      //setters
      void setScheduleInterval(int i, const LpiTimeIntervalData & source);
      void setAllScheduleIntervals(const std::vector<LpiTimeIntervalData> & source);

   private:

      std::vector<LpiTimeIntervalData> r_scheduleIntervals;
};


class DepartureInfo
{
   public:

      DepartureInfo (){}
      DepartureInfo (const DepartureInfo & source);
      virtual  ~DepartureInfo () {}

      DepartureInfo & operator= (const DepartureInfo & source);

      posix_time::ptime getitot() const {return itot;}
      void setitot(posix_time::ptime _time) {itot =_time;}

      posix_time::ptime getstot() const {return stot;}
      void setstot(posix_time::ptime _time) {stot =_time;}

      posix_time::ptime getftot() const {return ftot;}
      void setftot(posix_time::ptime _time) {ftot =_time;}

      const boost::optional<posix_time::ptime> & getEobt() const { return r_eobt; }
      void setEobt(const posix_time::ptime & _time) { r_eobt =_time; }

   private:

      posix_time::ptime itot;
      posix_time::ptime stot;
      posix_time::ptime ftot;
      boost::optional<posix_time::ptime> r_eobt;
};


class ArrivalInfo
{
   public:

      ArrivalInfo () {}
      ArrivalInfo (const ArrivalInfo & source);
      virtual  ~ArrivalInfo () {}

      ArrivalInfo & operator= (const ArrivalInfo & source);

      posix_time::ptime getildt() const {return ildt;}
      void setildt(posix_time::ptime _time) {ildt =_time;}

      posix_time::ptime getsldt() const {return sldt;}
      void setsldt(posix_time::ptime _time) {sldt =_time;}

      posix_time::ptime getfldt() const {return fldt;}
      void setfldt(posix_time::ptime _time) {fldt =_time;}

      const boost::optional<posix_time::ptime> & getEobt() const { return r_eobt; }
      void setEobt(const posix_time::ptime & _time) { r_eobt =_time; }

   private:

      posix_time::ptime ildt;
      posix_time::ptime sldt;
      posix_time::ptime fldt;
      boost::optional<posix_time::ptime> r_eobt;
};


class LpiScheduledFlightPlan
{
   public:

      LpiScheduledFlightPlan () {}
      LpiScheduledFlightPlan(const LpiScheduledFlightPlan & source);
      virtual  ~LpiScheduledFlightPlan () {}

      LpiScheduledFlightPlan & operator= (const LpiScheduledFlightPlan & source);

      //getters
      const string        & getcallsign        () const {return callsign;}
      const string        & getdepAerodrome    () const {return depAerodrome;}
      const string        & getarrAerodrome    () const {return arrAerodrome;}
      const string        & getopType          () const {return opType;}
      const DepartureInfo & getdepartureTimes  () const {return departureTimes;}
      const ArrivalInfo   & getarrivalTimes    () const {return arrivalTimes;}
      const long          & getforecastDelay   () const {return forecastDelay;}
      const int           & getpunctualityDelay() const {return punctualityDelay;}
      const string        & getAssignedRunway  () const {return r_assigned_runway;}
      const bool          & getTurnRoundDelayed() const {return r_turnRoundDelayed;}

      //setters
      void setcallsign        (const string        &aux) {callsign=aux;}
      void setdepAerodrome    (const string        &aux) {depAerodrome=aux;}
      void setarrAerodrome    (const string        &aux) {arrAerodrome=aux;}
      void setopType          (const string        &aux) {opType=aux;}
      void setdepartureTimes  (const DepartureInfo &aux) {departureTimes=aux;}
      void setarrivalTimes    (const ArrivalInfo   &aux) {arrivalTimes=aux;}
      void setforecastDelay   (const long          &aux) {forecastDelay=aux;}
      void setpunctualityDelay(const int           &aux) {punctualityDelay=aux;}
      void setAssignedRunway  (const string        &rwy) {r_assigned_runway = rwy;}
      void setTurnRoundDelayed(const bool          &tr)  {r_turnRoundDelayed = tr;}

   private:

      string        callsign;
      string        depAerodrome;
      string        arrAerodrome;
      string        opType;

      string        r_assigned_runway;
      DepartureInfo departureTimes;
      ArrivalInfo   arrivalTimes;

      long          forecastDelay;
      int           punctualityDelay;
      bool          r_turnRoundDelayed;
};


class LpiFPList
{
   public:

      LpiFPList () : r_FpList() {}
      LpiFPList (const LpiFPList &source);
      virtual  ~LpiFPList () {}

      LpiFPList & operator= (const LpiFPList & source);

      //getters
      LpiScheduledFlightPlan getFpList(int i) const;
      std::vector<LpiScheduledFlightPlan> getFpList() const;

      //setters
      void setFpList(int i,const LpiScheduledFlightPlan source);
      void setFpList(const std::vector<LpiScheduledFlightPlan> source) ;

   private:

      std::vector<LpiScheduledFlightPlan> r_FpList;
};


class LpiSchedule
{
   public:

      LpiSchedule () {}
      LpiSchedule (const LpiSchedule & source);
      virtual  ~LpiSchedule () {}

      LpiSchedule & operator= (const LpiSchedule & source);

      //Getters
      posix_time::ptime getMessageTimeandDate() const
      { return r_messageTimeAndDate; }

      LpiCalculationReason::LpiEnum getCalculationReason() const
      { return r_calculationReason; }

      int getFrozenPeriod() const
      { return r_frozenPeriod; }

      const LpiScheduleTimeLine & getScheduleTimeLine() const
      { return r_timeLineScheduled; }

      const LpiScheduleDemand & getDemandData() const
      { return r_demand; }

      const LpiFPList & getFPList() const
      { return r_FPList; }

      const LpiPerformanceInfo & getPerformanceInfo() const
      { return r_performanceInfo; }

      const LpiCapacityInfo & getCapacityInfo() const
      { return r_capacityInfo; }

      const LpiActivationType::ActivationType & getOrigin() const
      { return r_origin; }

      //Setters
      void setMessageTimeAndDate(posix_time::ptime messageTimeandDate)
      { r_messageTimeAndDate = messageTimeandDate; }

      void setCalculationReason(const LpiCalculationReason::LpiEnum & value)
      { r_calculationReason = value; }

      void setFrozenPeriod(int numberOfIntervals)
      { r_frozenPeriod = numberOfIntervals; }

      void setScheduleTimeLine (const LpiScheduleTimeLine & aux)
      { r_timeLineScheduled = aux; }

      void setDemandData (const LpiScheduleDemand & aux)
      { r_demand = aux; }

      void setFPList(const LpiFPList & aux)
      { r_FPList = aux; }

      void setPerformanceInfo (const LpiPerformanceInfo & info)
      { r_performanceInfo = info; }

      void setCapacityInfo (const LpiCapacityInfo & info)
      { r_capacityInfo = info; }

      void setOrigin(const LpiActivationType::ActivationType & origin)
      { r_origin = origin; }

   private:

      posix_time::ptime   r_messageTimeAndDate;
      LpiCalculationReason::LpiEnum r_calculationReason;

      int                 r_frozenPeriod;
      LpiScheduleTimeLine r_timeLineScheduled;

      LpiFPList           r_FPList;
      LpiScheduleDemand   r_demand;

      LpiPerformanceInfo r_performanceInfo;
      LpiCapacityInfo    r_capacityInfo;

      LpiActivationType::ActivationType r_origin;
};


std::ostream & operator<<(std::ostream & os, const LpiRS_Scheduled & rsData);


#endif // __LPISCHEDULE__
