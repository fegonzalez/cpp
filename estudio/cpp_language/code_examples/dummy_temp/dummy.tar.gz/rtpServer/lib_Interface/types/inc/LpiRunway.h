/*
 * LxiRunway.h
 *
 *  Created on: 02/12/2013
 *      Author: gpfernandez
 */

#ifndef LXIRUNWAY_H_
#define LXIRUNWAY_H_

#include <iostream>
typedef  std::string  LpiNameRunway;
typedef  unsigned int LpiIdSegmentRunway;
typedef std::string   LpiAreaDeicing;


class LpiRunway
{
public:

  LpiNameRunway       _name;
  LpiIdSegmentRunway  _id;
private:
  
};
std::ostream & operator<<(std::ostream &out,
                          const LpiRunway &obj);




#endif /* LXIRUNWAY_H_ */
