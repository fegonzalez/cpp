
#include "LpiOperationType.h"


std::ostream& operator <<(std::ostream &os,
                          const LpiOperationType::LpiEnum &obj)
{
   switch (obj)
   {
   case LpiOperationType::E_ARRIVAL:
      os << "ARR";
      break;

   case LpiOperationType::E_DEPARTURE:
      os << "DEP";
      break;
   default:
      os << "NONE";
      break;
   }
   return os;
}
