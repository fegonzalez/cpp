/*
 * LpiFlightPlan.cpp
 *
 *  Created on: 12/12/2013
 *      Author: mbegega
 */

#include <iostream>
#include <LctimTimeUtils.h>
#include "LpiFlightPlan.h"

// LpiDepartureTimes method implementations

LpiDepartureTimes::LpiDepartureTimes()
:  r_eobt(), r_sobt(), r_tobt(),
   r_etot(), r_ttot(), r_stot(),
   r_atot(), r_ctot(), r_utot(),
   r_itot()
{
}


LpiDepartureTimes::LpiDepartureTimes(const LpiDepartureTimes& source)
:  r_eobt(source.r_eobt), r_sobt(source.r_sobt), r_tobt(source.r_tobt),
   r_etot(source.r_etot), r_ttot(source.r_ttot), r_stot(source.r_stot),
   r_atot(source.r_atot), r_ctot(source.r_ctot), r_utot(source.r_utot),
   r_itot(source.r_itot)
{
}


LpiDepartureTimes::LpiDepartureTimes(posix_time::ptime eobt,
      posix_time::ptime sobt, posix_time::ptime tobt, posix_time::ptime etot,
      posix_time::ptime ttot, posix_time::ptime stot, posix_time::ptime atot,
      posix_time::ptime ctot, posix_time::ptime utot)
:  r_eobt(eobt), r_sobt(sobt), r_tobt(tobt),
   r_etot(etot), r_ttot(ttot), r_stot(stot),
   r_atot(atot), r_ctot(ctot), r_utot(utot)
{
}


LpiDepartureTimes& LpiDepartureTimes::operator =(const LpiDepartureTimes& source)
{
   if (this != &source)
   {
     if(source.r_eobt) { r_eobt= source.r_eobt; }
     if(source.r_sobt) { r_sobt= source.r_sobt; }
     if(source.r_tobt) { r_tobt= source.r_tobt; }
     if(source.r_etot) { r_etot= source.r_etot; }
     if(source.r_ttot) { r_ttot= source.r_ttot; }
     if(source.r_stot) { r_stot= source.r_stot; }
     if(source.r_atot) { r_atot= source.r_atot; }
     if(source.r_ctot) { r_ctot= source.r_ctot; }
     if(source.r_itot) { r_itot= source.r_itot; }
     if(source.r_utot) { r_utot= source.r_utot; }
   }
   return *this;
}


void LpiDepartureTimes::setEobt (posix_time::ptime timestamp)
{
   r_eobt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getEobt () const
{
   return r_eobt;
}


void LpiDepartureTimes::setSobt (posix_time::ptime timestamp)
{
   r_sobt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getSobt () const
{
   return r_sobt;
}

void LpiDepartureTimes::setTobt (posix_time::ptime timestamp)
{
   r_tobt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getTobt () const
{
   return r_tobt;
}

void LpiDepartureTimes::setEtot (posix_time::ptime timestamp)
{
   r_etot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getEtot () const
{
   return r_etot;
}

void LpiDepartureTimes::setTtot (posix_time::ptime timestamp)
{
   r_ttot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getTtot () const
{
   return r_ttot;
}



void LpiDepartureTimes::setStot (posix_time::ptime timestamp)
{
   r_stot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getStot () const
{
   return r_stot;
}

void LpiDepartureTimes::setAtot (posix_time::ptime timestamp)
{
   r_atot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getAtot () const
{
   return r_atot;
}

void LpiDepartureTimes::setCtot (posix_time::ptime timestamp)
{
   r_ctot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getCtot () const
{
   return r_ctot;
}


void LpiDepartureTimes::setUtot (posix_time::ptime timestamp)
{
   r_utot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getUtot () const
{
   return r_utot;
}


void LpiDepartureTimes::setItot (posix_time::ptime timestamp)
{
   r_itot= timestamp;
}


const boost::optional<posix_time::ptime> & LpiDepartureTimes::getItot () const
{
   return r_itot;
}


std::ostream& operator<< (std::ostream & out, const LpiDepartureTimes & dep)
{
   boost::optional<posix_time::ptime> eobt = dep.getEobt();
   boost::optional<posix_time::ptime> sobt = dep.getSobt();
   boost::optional<posix_time::ptime> tobt = dep.getTobt();
   boost::optional<posix_time::ptime> etot = dep.getEtot();
   boost::optional<posix_time::ptime> ttot = dep.getTtot();
   boost::optional<posix_time::ptime> stot = dep.getStot();
   boost::optional<posix_time::ptime> atot = dep.getAtot();
   boost::optional<posix_time::ptime> ctot = dep.getCtot();
   boost::optional<posix_time::ptime> utot = dep.getUtot();
   boost::optional<posix_time::ptime> itot = dep.getItot();

   out << '[';
   if (eobt) { out << "EOBT: "   << LctimTimeUtils::formatTime(*eobt, "%d/%m/%Y %H:%M:%S"); }
   if (sobt) { out << " |SOBT: " << LctimTimeUtils::formatTime(*sobt, "%d/%m/%Y %H:%M:%S"); }
   if (tobt) { out << " |TOBT: " << LctimTimeUtils::formatTime(*tobt, "%d/%m/%Y %H:%M:%S"); }
   if (etot) { out << " |ETOT: " << LctimTimeUtils::formatTime(*etot, "%d/%m/%Y %H:%M:%S"); }
   if (ttot) { out << " |TTOT: " << LctimTimeUtils::formatTime(*ttot, "%d/%m/%Y %H:%M:%S"); }
   if (stot) { out << " |STOT: " << LctimTimeUtils::formatTime(*stot, "%d/%m/%Y %H:%M:%S"); }
   if (atot) { out << " |ATOT: " << LctimTimeUtils::formatTime(*atot, "%d/%m/%Y %H:%M:%S"); }
   if (ctot) { out << " |CTOT: " << LctimTimeUtils::formatTime(*ctot, "%d/%m/%Y %H:%M:%S"); }
   if (utot) { out << " |UTOT: " << LctimTimeUtils::formatTime(*utot, "%d/%m/%Y %H:%M:%S"); }
   if (itot) { out << " |ITOT: " << LctimTimeUtils::formatTime(*itot, "%d/%m/%Y %H:%M:%S"); }
   out << ']';

   return out;
}


// LpiArrivalTimes method implementations

LpiArrivalTimes::LpiArrivalTimes()
:  r_eldt(), r_tldt(), r_aldt(),
   r_sldt(), r_sibt(), r_uldt(),
   r_ildt()
{
}


LpiArrivalTimes::LpiArrivalTimes(const LpiArrivalTimes& source)
:  r_eldt(source.r_eldt), r_tldt(source.r_tldt), r_aldt(source.r_aldt),
   r_sldt(source.r_sldt), r_sibt(source.r_sibt), r_uldt(source.r_uldt),
   r_ildt(source.r_ildt)
{
}


LpiArrivalTimes::LpiArrivalTimes(posix_time::ptime eldt, posix_time::ptime tldt,
                                 posix_time::ptime aldt, posix_time::ptime sldt,
                                 posix_time::ptime sibt, posix_time::ptime uldt)
:  r_eldt(eldt), r_tldt(tldt), r_aldt(aldt),
   r_sldt(sldt), r_sibt(sibt), r_uldt(uldt)
{
}

LpiArrivalTimes& LpiArrivalTimes::operator =(const LpiArrivalTimes& source)
{
   if (this != &source)
   {
      if(source.r_eldt){r_eldt= source.r_eldt;}
      if(source.r_tldt){r_tldt= source.r_tldt;}
      if(source.r_aldt){r_aldt= source.r_aldt;}
      if(source.r_sldt){r_sldt= source.r_sldt;}
      if(source.r_sibt){r_sibt= source.r_sibt;}
      if(source.r_ildt){r_ildt= source.r_ildt;}
      if(source.r_uldt){r_uldt= source.r_uldt;}
   }

   return *this;
}


void LpiArrivalTimes::setIldt (posix_time::ptime timestamp)
{
   r_ildt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getIldt () const
{
   return r_ildt;
}


void LpiArrivalTimes::setEldt (posix_time::ptime timestamp)
{
   r_eldt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getEldt () const
{
   return r_eldt;
}

void LpiArrivalTimes::setTldt (posix_time::ptime timestamp)
{
   r_tldt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getTldt () const
{
   return r_tldt;
}

void LpiArrivalTimes::setAldt (posix_time::ptime timestamp)
{
   r_aldt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getAldt () const
{
   return r_aldt;
}

void LpiArrivalTimes::setSibt (posix_time::ptime timestamp)
{
   r_sibt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getSibt () const
{
   return r_sibt;
}


void LpiArrivalTimes::setSldt (posix_time::ptime timestamp)
{
   r_sldt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getSldt () const
{
   return r_sldt;
}


void LpiArrivalTimes::setUldt (posix_time::ptime timestamp)
{
   r_uldt= timestamp;
}


const boost::optional<posix_time::ptime> & LpiArrivalTimes::getUldt () const
{
   return r_uldt;
}


std::ostream& operator<< (std::ostream & out, const LpiArrivalTimes & dep)
{
   boost::optional<posix_time::ptime> eldt = dep.getEldt();
   boost::optional<posix_time::ptime> tldt = dep.getTldt();
   boost::optional<posix_time::ptime> aldt = dep.getAldt();
   boost::optional<posix_time::ptime> sldt = dep.getSldt();
   boost::optional<posix_time::ptime> sibt = dep.getSibt();
   boost::optional<posix_time::ptime> ildt = dep.getIldt();
   boost::optional<posix_time::ptime> uldt = dep.getUldt();

   out << '[';
   if (eldt) { out << "ELDT: "   << LctimTimeUtils::formatTime(*eldt, "%d/%m/%Y %H:%M:%S"); }
   if (tldt) { out << " |TLDT: " << LctimTimeUtils::formatTime(*tldt, "%d/%m/%Y %H:%M:%S"); }
   if (aldt) { out << " |ALDT: " << LctimTimeUtils::formatTime(*aldt, "%d/%m/%Y %H:%M:%S"); }
   if (sldt) { out << " |SLDT: " << LctimTimeUtils::formatTime(*sldt, "%d/%m/%Y %H:%M:%S"); }
   if (sibt) { out << " |SIBT: " << LctimTimeUtils::formatTime(*sibt, "%d/%m/%Y %H:%M:%S"); }
   if (uldt) { out << " |ULDT: " << LctimTimeUtils::formatTime(*uldt, "%d/%m/%Y %H:%M:%S"); }
   if (ildt) { out << " |ILDT: " << LctimTimeUtils::formatTime(*ildt, "%d/%m/%Y %H:%M:%S"); }
   out << ']';

   return out;
}


//LpdbFlightPlan method implementations

LpiFlightPlan::LpiFlightPlan()
:  r_callsign(""),
   r_departure_aerodrome(""),
   r_arrival_aerodrome(""),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_operation_type(),
   r_departure_times(),
   r_arrival_times(),
   r_preferential_runways(),
   r_not_allowed_runways(),
   r_demand_order(0),
   r_departure_runway(""),
   r_arrival_runway(""),
   r_turnRoundKey(""),
   r_isClosedTurnRound(false),
   r_priorityDepartures(0),
   r_priorityArrivals(0)
{
}


LpiFlightPlan::LpiFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome)
:  r_callsign(callsign),
   r_departure_aerodrome(dep_aerodrome),
   r_arrival_aerodrome(arr_aerodrome),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_operation_type(),
   r_departure_times(),
   r_arrival_times(),
   r_preferential_runways(),
   r_not_allowed_runways(),
   r_demand_order(0),
   r_departure_runway(""),
   r_arrival_runway(""),
   r_turnRoundKey(""),
   r_isClosedTurnRound(false),
   r_priorityDepartures(0),
   r_priorityArrivals(0)
{
}


LpiFlightPlan::LpiFlightPlan (string callsign, string dep_aerodrome, string arr_aerodrome, int demand_order)
:  r_callsign(callsign),
   r_departure_aerodrome(dep_aerodrome),
   r_arrival_aerodrome(arr_aerodrome),
   r_aircraft_type(""),
   r_registration(""),
   r_wtc(""),
   r_sid(""),
   r_star(""),
   r_operation_type(),
   r_departure_times(),
   r_arrival_times(),
   r_preferential_runways(),
   r_not_allowed_runways(),
   r_demand_order(demand_order),
   r_departure_runway(""),
   r_arrival_runway(""),
   r_turnRoundKey(""),
   r_isClosedTurnRound(false),
   r_priorityDepartures(0),
   r_priorityArrivals(0)
{
}


LpiFlightPlan::LpiFlightPlan(const LpiFlightPlan& source)
:  r_callsign(source.r_callsign),
   r_departure_aerodrome(source.r_departure_aerodrome),
   r_arrival_aerodrome(source.r_arrival_aerodrome),
   r_aircraft_type(source.r_aircraft_type),
   r_registration(source.r_registration),
   r_wtc(source.r_wtc),
   r_sid(source.r_sid),
   r_star(source.r_star),
   r_operation_type(source.r_operation_type),
   r_departure_times(source.r_departure_times),
   r_arrival_times(source.r_arrival_times),
   r_preferential_runways(source.r_preferential_runways),
   r_not_allowed_runways(source.r_not_allowed_runways),
   r_demand_order(source.r_demand_order),
   r_departure_runway(source.r_departure_runway),
   r_arrival_runway(source.r_arrival_runway),
   r_turnRoundKey(source.r_turnRoundKey),
   r_isClosedTurnRound(source.r_isClosedTurnRound),
   r_priorityDepartures(source.r_priorityDepartures),
   r_priorityArrivals(source.r_priorityArrivals)
{
}


LpiFlightPlan& LpiFlightPlan::operator=(const LpiFlightPlan& source)
{
   if (this != &source)
   {
      r_callsign = source.r_callsign;
      r_departure_aerodrome = source.r_departure_aerodrome;
      r_arrival_aerodrome = source.r_arrival_aerodrome;
      r_aircraft_type = source.r_aircraft_type;
      r_registration = source.r_registration;
      r_wtc = source.r_wtc;
      r_sid = source.r_sid;
      r_star = source.r_star;
      r_operation_type = source.r_operation_type;
      r_departure_times = source.r_departure_times;
      r_arrival_times = source.r_arrival_times;
      r_preferential_runways = source.r_preferential_runways;
      r_not_allowed_runways = source.r_not_allowed_runways;
      r_demand_order = source.r_demand_order;
      r_departure_runway = source.r_departure_runway;
      r_arrival_runway = source.r_arrival_runway;
      r_turnRoundKey = source.r_turnRoundKey;
      r_isClosedTurnRound = source.r_isClosedTurnRound;
      r_priorityDepartures = source.r_priorityDepartures;
      r_priorityArrivals = source.r_priorityArrivals;
   }

   return *this;
}


string LpiFlightPlan::getAircraftType() const
{
   return r_aircraft_type;
}

void LpiFlightPlan::setAircraftType(string aircraftType)
{
   r_aircraft_type = aircraftType;
}


string LpiFlightPlan::getArrivalAerodrome() const
{
   return r_arrival_aerodrome;
}


void LpiFlightPlan::setArrivalAerodrome(string arrivalAerodrome)
{
   r_arrival_aerodrome = arrivalAerodrome;
}


LpiArrivalTimes LpiFlightPlan::getArrivalTimes() const
{
   return r_arrival_times;
}


void LpiFlightPlan::setArrivalTimes(LpiArrivalTimes arrivalTimes)
{
   r_arrival_times = arrivalTimes;
}

string LpiFlightPlan::getCallsign() const
{
   return r_callsign;
}


void LpiFlightPlan::setCallsign(string callsign)
{
   r_callsign = callsign;
}


string LpiFlightPlan::getDepartureAerodrome() const
{
   return r_departure_aerodrome;
}


void LpiFlightPlan::setDepartureAerodrome(string departureAerodrome)
{
   r_departure_aerodrome = departureAerodrome;
}


LpiDepartureTimes LpiFlightPlan::getDepartureTimes() const
{
   return r_departure_times;
}


void LpiFlightPlan::setDepartureTimes(LpiDepartureTimes departureTimes)
{
   r_departure_times = departureTimes;
}


LpiOperationType::LpiEnum LpiFlightPlan::getOperationType() const
{
   return r_operation_type;
}

void LpiFlightPlan::setOperationType(LpiOperationType::LpiEnum flightType)
{
   r_operation_type = flightType;
}


void LpiFlightPlan::setOperationType(string local_aerodrome)
{
   if (r_departure_aerodrome == local_aerodrome)
   {
      r_operation_type= LpiOperationType::E_DEPARTURE;
   }
   else if (r_arrival_aerodrome == local_aerodrome)
   {
      r_operation_type= LpiOperationType::E_ARRIVAL;
   }
}


string LpiFlightPlan::getRegistration() const
{
   return r_registration;
}


void LpiFlightPlan::setRegistration(string registration)
{
   r_registration = registration;
}


string LpiFlightPlan::getWtc() const
{
   return r_wtc;
}


void LpiFlightPlan::setWtc(string wtc) {
   r_wtc = wtc;
}


string LpiFlightPlan::getSID() const
{
   return r_sid;
}


void LpiFlightPlan::setSID(string sid)
{
   r_sid = sid;
}


string LpiFlightPlan::getSTAR() const
{
   return r_star;
}


void LpiFlightPlan::setSTAR(string star)
{
   r_star = star;
}

string LpiFlightPlan::getVFR() const
{
   return r_vfr;
}


void LpiFlightPlan::setVFR(string vfr)
{
   r_vfr = vfr;
}


LpiPreferentialRunway LpiFlightPlan::getPreferentialRunways () const
{
   return r_preferential_runways;
}


void LpiFlightPlan::setPreferentialRunways(LpiPreferentialRunway runways)
{
   r_preferential_runways= runways;
}


void LpiFlightPlan::addPreferentialRunway(string key ,string value)
{
   r_preferential_runways[key] = value;
}


vector<string> LpiFlightPlan::getPreferentialRunwaysNames (string runwaySystemName) const
{ 
   vector<string> runway_names;

   if (r_preferential_runways.size() > 0)
   {
      typedef const std::map<string, string>::value_type preferential_pair;

      BOOST_FOREACH (preferential_pair & data, r_preferential_runways)
      {
         //data.first = "runway system name", data.second= "runway name";
         if (data.first == runwaySystemName)
         {
            runway_names.push_back(data.second);
         }
      }
   }

   return runway_names;
}


const boost::optional<posix_time::ptime> & LpiFlightPlan::getItot() const
{
   return r_departure_times.getItot();
}


const boost::optional<posix_time::ptime> & LpiFlightPlan::getIldt() const
{
   return r_arrival_times.getIldt();
}


boost::optional<posix_time::ptime> LpiFlightPlan::getIntentionalTime() const
{
   if (getOperationType() == LpiOperationType::E_DEPARTURE)
   {
      return getItot();
   }
   else if (getOperationType() == LpiOperationType::E_ARRIVAL)
   {
      return getIldt();
   }
   else
   {
      return boost::optional<posix_time::ptime>();
   }
}


string LpiFlightPlan::getUniqueKey() const
{
   string key = r_callsign;
   key += r_departure_aerodrome;
   key += r_arrival_aerodrome;

   string stringifiedEobt;

   if (r_departure_times.getEobt())
   {
      posix_time::ptime eobt = *(r_departure_times.getEobt());

      unsigned long epoch = LctimTimeUtils::toEpoch(eobt);

      try
      {
         stringifiedEobt = boost::lexical_cast<std::string>(epoch);
      }
      catch(...)
      {
         stringifiedEobt = "";
      }
   }

   if (stringifiedEobt.size() > 0)
   {
      key += stringifiedEobt;
   }

   return key;
}


int  LpiFlightPlan::getDemandOrder () const
{
   return r_demand_order;
}


void LpiFlightPlan::setDemandOrder (int order)
{
   r_demand_order = order;
}


bool LpiFlightPlan::isOfInterest(string airport_name) const
{
   return (airport_name == r_departure_aerodrome) ||
          (airport_name == r_arrival_aerodrome);
}

/*
void LpiFlightPlan::calculatePreferentialRunway(LpiPreferentialAllocation preferential,
      const vector<string> & rs_keys)
{
   std::string SID("SID");
   std::string STAR("STAR");
   std::string procedim;
   std::string value;

   if(this->getOperationType() == LpiOperationType::E_ARRIVAL)
   {
      procedim = STAR;
      value    = this->getSTAR();
   }
   else if(this->getOperationType()== LpiOperationType::E_DEPARTURE)
   {
      procedim = SID;
      value    = this->getSID();
   }
   LpiPreferentialRunway runways;

   BOOST_FOREACH(string nameRS, rs_keys)
   {
      LpiPreferentialAllocationKey composed_key(procedim, value, nameRS);
      std::string namerunway;
      namerunway = preferential[composed_key];
      if(namerunway.length() > 0)
      {
        runways[nameRS] = namerunway;
      }
   }

   this->setPreferentialRunways(runways);
}
*/

void LpiFlightPlan::calculateIntentionalTimes(int default_taxi_time)
{
   posix_time::ptime intentional;

   if (r_operation_type == LpiOperationType::E_DEPARTURE)
   {
      if (r_departure_times.getUtot())
      {
         intentional = *(r_departure_times.getUtot());
         r_departure_times.setItot(intentional);
      }
      else if (r_departure_times.getCtot())
      {
         intentional = *(r_departure_times.getCtot());
         r_departure_times.setItot(intentional);
      }
      else if (r_departure_times.getEtot())
      {
         intentional = *(r_departure_times.getEtot());
         r_departure_times.setItot(intentional);
      }
      else if (r_departure_times.getTtot())
      {
         intentional = *(r_departure_times.getTtot());
         r_departure_times.setItot(intentional);
      }
      else if (r_departure_times.getStot())
      {
         intentional = *(r_departure_times.getStot());
         r_departure_times.setItot(intentional);
      }
      else if (r_departure_times.getTobt())
      {
         intentional = *(r_departure_times.getTobt());
         r_departure_times.setItot(intentional +
                                   posix_time::minutes(default_taxi_time));
      }
      else if (r_departure_times.getEobt())
      {
         intentional = *(r_departure_times.getEobt()) ;
         r_departure_times.setItot(intentional +
                                   posix_time::minutes(default_taxi_time));
      }
      else if (r_departure_times.getSobt())
      {
         intentional = *(r_departure_times.getSobt()) ;
         r_departure_times.setItot(intentional +
                                   posix_time::minutes(default_taxi_time));
      }
   }
   else if (r_operation_type == LpiOperationType::E_ARRIVAL)
   { 
      if (r_arrival_times.getUldt())
      {
         intentional = *(r_arrival_times.getUldt());
         r_arrival_times.setIldt(intentional);
      }
      else if (r_arrival_times.getTldt())
      {
         intentional = *(r_arrival_times.getTldt());
         r_arrival_times.setIldt(*r_arrival_times.getTldt());
      }
      else if (r_arrival_times.getEldt())
      {
         intentional = *(r_arrival_times.getEldt());
         r_arrival_times.setIldt(*(r_arrival_times.getEldt()));
      }
      else if (r_arrival_times.getSldt())
      {
         intentional = *(r_arrival_times.getSldt());
         r_arrival_times.setIldt(*(r_arrival_times.getSldt()));
      }
      else if (r_arrival_times.getSibt())
      {
         intentional = *(r_arrival_times.getSibt());
         r_arrival_times.setIldt(intentional -
                                 posix_time::minutes(default_taxi_time));
      }
   }
}


void LpiFlightPlan::setNotAllowedRunways (const vector<string> & runway_list)
{
   r_not_allowed_runways = runway_list;
}


vector<string> LpiFlightPlan::getNotAllowedRunways () const
{
   return r_not_allowed_runways;
}


void LpiFlightPlan::setDepartureRunway (const string & runway)
{
   r_departure_runway = runway;
}


string LpiFlightPlan::getDepartureRunway () const
{
   return r_departure_runway;
}


void LpiFlightPlan::setArrivalRunway (const string & runway)
{
   r_arrival_runway = runway;
}


string LpiFlightPlan::getArrivalRunway () const
{
   return r_arrival_runway;
}


void LpiFlightPlan::setTurnRoundKey(const string & anotherFPKey)
{
   r_turnRoundKey = anotherFPKey;
}


string LpiFlightPlan::getTurnRoundKey() const
{
   return r_turnRoundKey;
}


void LpiFlightPlan::setClosedTurnRound(bool isClosedTurnRound)
{
   r_isClosedTurnRound = isClosedTurnRound;
}


bool LpiFlightPlan::isClosedTurnRound() const
{
   return r_isClosedTurnRound;
}


int LpiFlightPlan::getPriorityDepartures() const
{
   return r_priorityDepartures;
}


void LpiFlightPlan::setPriorityDepartures(int priority)
{
   r_priorityDepartures = priority;
}

int LpiFlightPlan::getPriorityArrivals() const
{
   return r_priorityArrivals;
}


void LpiFlightPlan::setPriorityArrivals(int priority)
{
   r_priorityArrivals = priority;
}


bool LpiFlightPlan::hasCharacteristic(const LpiFPCharacteristic::LpiEnum & characteristic) const
{
   bool hasCharacteristic = false;

   switch (characteristic)
   {
      case LpiFPCharacteristic::E_UNKNOWN:
         hasCharacteristic = false;
      break;
      case LpiFPCharacteristic::E_EOBT:
         hasCharacteristic = r_departure_times.getEobt();
      break;
      case LpiFPCharacteristic::E_SOBT:
         hasCharacteristic = r_departure_times.getSobt();
      break;
      case LpiFPCharacteristic::E_TOBT:
         hasCharacteristic = r_departure_times.getTobt();
      break;
      case LpiFPCharacteristic::E_ETOT:
         hasCharacteristic = r_departure_times.getEtot();
      break;
      case LpiFPCharacteristic::E_TTOT:
         hasCharacteristic = r_departure_times.getTtot();
      break;
      case LpiFPCharacteristic::E_STOT:
         hasCharacteristic = r_departure_times.getStot();
      break;
      case LpiFPCharacteristic::E_ATOT:
         hasCharacteristic = r_departure_times.getAtot();
      break;
      case LpiFPCharacteristic::E_CTOT:
         hasCharacteristic = r_departure_times.getCtot();
      break;
      case LpiFPCharacteristic::E_UTOT:
         hasCharacteristic = r_departure_times.getUtot();
      break;
      case LpiFPCharacteristic::E_ELDT:
         hasCharacteristic = r_arrival_times.getEldt();
      break;
      case LpiFPCharacteristic::E_TLDT:
         hasCharacteristic = r_arrival_times.getTldt();
      break;
      case LpiFPCharacteristic::E_ALDT:
         hasCharacteristic = r_arrival_times.getAldt();
      break;
      case LpiFPCharacteristic::E_SLDT:
         hasCharacteristic = r_arrival_times.getSldt();
      break;
      case LpiFPCharacteristic::E_ULDT:
         hasCharacteristic = r_arrival_times.getUldt();
      break;
      case LpiFPCharacteristic::E_SIBT:
         hasCharacteristic = r_arrival_times.getSibt();
      break;
      case LpiFPCharacteristic::E_AIRCRAFT_TYPE:
         hasCharacteristic = !r_aircraft_type.empty();
      break;
      case LpiFPCharacteristic::E_REGISTRATION:
         hasCharacteristic = !r_registration.empty();
      break;
      case LpiFPCharacteristic::E_WTC:
         hasCharacteristic = !r_wtc.empty();
      break;
      case LpiFPCharacteristic::E_SID:
         hasCharacteristic = !r_sid.empty();
      break;
      case LpiFPCharacteristic::E_STAR:
         hasCharacteristic = !r_star.empty();
      break;
      case LpiFPCharacteristic::E_CLOSED_TURNROUND:
         hasCharacteristic = r_isClosedTurnRound;
      break;
      case LpiFPCharacteristic::E_NOT_ALLOWED_RWYS:
         hasCharacteristic = (r_not_allowed_runways.size() > 0);
      break;
      default:
         hasCharacteristic = false;
      break;
   }

   return hasCharacteristic;
}



LpiCreateDemand::LpiCreateDemand(void)
{

}

LpiCreateDemand & LpiCreateDemand::operator= (const LpiCreateDemand & source)
{
   if (this != &source)
   {
      r_flightPlanList     = source.r_flightPlanList;
      r_messageTimeandDate = source.r_messageTimeandDate;
   }

   return *this;
}



LpiFlightPlanList LpiCreateDemand::getFlightPlanList() const
{
   return r_flightPlanList;
}

void LpiCreateDemand::setFlightPlanList(LpiFlightPlanList flightPlanList)
{
   r_flightPlanList=flightPlanList;
}


posix_time::ptime LpiCreateDemand::getmessageTimeandDate() const
{
   return r_messageTimeandDate;
}

void LpiCreateDemand::setmessageTimeandDate(posix_time::ptime _messageTimeandDate)
{
   r_messageTimeandDate=_messageTimeandDate;
}



std::ostream& operator<< (std::ostream & out, const LpiCreateDemand & dm)
{
	out << "[AIRPORT: " << dm.getNameAirport() << "\n"
	       << " |TIME_START: " << dm.getDemandStartTimeAndDate() << "\n"
	       << " |TIME_END: " << dm.getDemandEndTimeAndDate() << "\n";

	for(unsigned int i = 0; i<dm.getFlightPlanList().size(); i++)
	{
		out << " |FP: " << dm.getFlightPlanList()[i] << "\n";
	}

	out << ']' << "\n";

	return out;
}

std::ostream& operator<< (std::ostream & out, const LpiFlightPlan & fp)
{
	std::stringstream out_stream;

	if (fp.getAircraftType().size() > 0)
	{
		out_stream << "\n \t|AT: " << fp.getAircraftType();
	}

	if (fp.getWtc().size() > 0)
	{
		out_stream << "\n \t|WTC: " << fp.getWtc();
	}

	if (fp.getOperationType() == LpiOperationType::E_DEPARTURE)
	{
		out_stream << "\n \t|SID: " << fp.getSID();
	} else if (fp.getOperationType() == LpiOperationType::E_ARRIVAL)
	{
		out_stream << "\n \t|STAR: " << fp.getSTAR();
	}

   /*vector<string> not_allowed_runways = fp.getNotAllowedRunways();

   out_stream << " |NOT_ALL_RWYS: [";
   if (not_allowed_runways.size() > 0)
   {
      BOOST_FOREACH (const string & runway, not_allowed_runways)
      {
         out_stream << runway << ' ';
      }
   }
   else
   {
      out_stream << "-";
   }
   out_stream << "]";


   LpiPreferentialRunway pref_runways = fp.getPreferentialRunways();
   out_stream << " |PREF_RWYS: [";

   if (pref_runways.size() > 0)
   {
      typedef std::map<string, string>::value_type preferential_pair;
      BOOST_FOREACH (preferential_pair & data, pref_runways)
      {
         out_stream << data.first << ": " << data.second << "| ";
      }
   }
   else
   {
      out_stream << "-";
   }
   out_stream << "]";

   std::stringstream turnRoundStream;
   if (!fp.getTurnRoundKey().empty())
   {
      turnRoundStream << " |TURN-ROUND: " << fp.getTurnRoundKey()
                      << " |CLOSED_TURN-ROUND: " << "false\0true" + 6*fp.isClosedTurnRound();
   }
*/
   out << "[KEY: "   << fp.getUniqueKey()
       << "[CSGN: " << fp.getCallsign()
       << "\n \t|DEP: " << fp.getDepartureAerodrome()
       << "\n \t|ARR: " << fp.getArrivalAerodrome()
       << "\n \t|REG: " << fp.getRegistration()
       << "\n \t|DEP_TIMES: " << fp.getDepartureTimes()
       << "\n \t|ARR_TIMES: " << fp.getArrivalTimes()
       << out_stream.str()
       //<< turnRoundStream.str()
       << "\n \t|PRIORITYDEPARTURES: " << fp.getPriorityDepartures()
       << "\n \t|PRIORITYARRIVALS: " << fp.getPriorityArrivals();
   out << "\t]" << "\n";

   return out;
}


//Compares 2 Flight Plans in terms of their intentional time

bool operator< (const LpiFlightPlan & fp1, const LpiFlightPlan & fp2)
{
   bool result = false;

   const boost::optional<posix_time::ptime> & intentional_fp1 = fp1.getIntentionalTime();
   const boost::optional<posix_time::ptime> & intentional_fp2 = fp2.getIntentionalTime();

   if (intentional_fp1 && intentional_fp2)
   {
      if (*intentional_fp1 < *intentional_fp2)
      {
         result = true;
      }
   }

   return result;
}


bool operator>= (const LpiFlightPlan & fp1, const LpiFlightPlan & fp2)
{
   return !(fp1 < fp2);
}


