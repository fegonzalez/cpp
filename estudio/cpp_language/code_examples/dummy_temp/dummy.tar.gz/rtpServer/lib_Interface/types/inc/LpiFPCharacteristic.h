/*
 * LpiFPCharacteristic.h
 *
 *  Created on: 15/07/2015
 *      Author: mbegega
 */

#ifndef __LPIFPCHARACTERISTIC_H__
#define __LPIFPCHARACTERISTIC_H__

#include <iostream>

using std::ostream;

class LpiFPCharacteristic
{
   public:
      enum LpiEnum
      {
         E_UNKNOWN = 0,
         E_EOBT,
         E_SOBT,
         E_TOBT,
         E_ETOT,
         E_TTOT,
         E_STOT,
         E_ATOT,
         E_CTOT,
         E_UTOT,
         E_ELDT,
         E_TLDT,
         E_ALDT,
         E_SLDT,
         E_ULDT,
         E_SIBT,
         E_AIRCRAFT_TYPE,
         E_REGISTRATION,
         E_WTC,
         E_SID,
         E_STAR,
         E_CLOSED_TURNROUND,
         E_NOT_ALLOWED_RWYS
      };
};


std::ostream& operator <<(std::ostream &os,
                          const LpiFPCharacteristic::LpiEnum & characteristic);


#endif /* __LPIFPCHARACTERISTIC_H__ */
