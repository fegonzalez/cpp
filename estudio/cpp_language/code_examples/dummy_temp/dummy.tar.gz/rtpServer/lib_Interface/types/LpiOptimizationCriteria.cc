
#include <boost/date_time/posix_time/posix_time.hpp>

#include "LpiOptimizationCriteria.h"


using std::vector;
using namespace boost::posix_time;


LpiOptimizationCriteria::LpiOptimizationCriteria  ()
{
}


LpiOptimizationCriteria::LpiOptimizationCriteria(const LpiOptimizationCriteria & source)
: r_id(source.r_id),
  r_name(source.r_name),
  r_dcb_weight(source.r_dcb_weight),
  r_suitability_weight(source.r_suitability_weight),
  r_rs_preference_weight(source.r_rs_preference_weight),
  r_timeLine(source.r_timeLine)
{
}


void LpiOptimizationCriteria::init(const LpiTimeParameters & parameters,
                                   boost::posix_time::ptime begin_timestamp)
{
   //Creates timeline with no data associated to interval contents
   r_timeLine.initialize(parameters.getMinutesSubinterval(),
                         parameters.getHoursWindow(),
                         parameters.getMinutesFrozen(),
                         begin_timestamp
                         );

   //Populates whole timeline with 0's
   r_timeLine.fill();
}


LpiOptimizationCriteria & LpiOptimizationCriteria::operator= (const LpiOptimizationCriteria & source)
{
   if (this != &source)
   {
      r_id = source.r_id;
      r_name = source.r_name;
      r_dcb_weight = source.r_dcb_weight;
      r_suitability_weight = source.r_suitability_weight;
      r_rs_preference_weight = source.r_rs_preference_weight;
      r_timeLine = source.r_timeLine;
   }

   return *this;
}


bool LpiOptimizationCriteria::has_data(const string& interval_name)
{
   return r_timeLine.hasData(interval_name);
}


LpiOptimizationCriteriaTimedData & LpiOptimizationCriteria::operator[] (const string & interval_name)
{
   return r_timeLine[interval_name];
}

TimeLine<LpiOptimizationCriteriaTimedData> & LpiOptimizationCriteria::getTimeLine ()
{
   return r_timeLine;
}


const TimeLine<LpiOptimizationCriteriaTimedData> & LpiOptimizationCriteria::getTimeLine () const
{
   return r_timeLine;
}


std::ostream & operator<<(std::ostream & out, const LpiOptimizationCriteria & criteria)
{
   out << "[ID : " <<
         criteria.getId() << "\n";

   out << "NAME : " <<
         criteria.getName() << "\n";

   out << "DCB_WEIGHT: " <<
         criteria.getDcbWeight() << "\n";

   out << "SUIT_WEIGHT: " <<
         criteria.getSuitabilityWeight() << "\n";

   out << "PREF_RS_SUIT_WEIGHT: " <<
         criteria.getRsPreferenceWeight() << "\n";

   out << "TIMELINE:" << std::endl <<
         criteria.getTimeLine() << "\n";

   out << ']';

   return out;
}
