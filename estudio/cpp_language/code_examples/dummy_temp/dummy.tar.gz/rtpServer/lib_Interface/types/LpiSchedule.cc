
#include <vector>
#include <algorithm>
#include <iterator>
#include <iostream>

#include "LpiSchedule.h"
#include <LclogUtils.h>


LpiRS_Scheduled::LpiRS_Scheduled (string rs,
                                  string arr_rwys,
                                  string dep_rwys,
                                  string cfg)
: r_runway_system(rs),
  r_runwayArr(arr_rwys),
  r_runwayDep(dep_rwys),
  r_configuration(cfg)
{
}


LpiRS_Scheduled::LpiRS_Scheduled (const LpiRS_Scheduled &source)
: r_runway_system(source.r_runway_system),
  r_runwayArr(source.r_runwayArr),
  r_runwayDep(source.r_runwayDep),
  r_configuration(source.r_configuration)
{
}


LpiRS_Scheduled & LpiRS_Scheduled::operator= (const LpiRS_Scheduled & source)
{
   if (this != &source)
   {
      r_runway_system = source.r_runway_system;
      r_runwayArr     = source.r_runwayArr;
      r_runwayDep     = source.r_runwayDep;
      r_configuration = source.r_configuration;
   }

   return *this;
}


LpiTimeIntervalData::LpiTimeIntervalData(string name, string beginTime, string endTime)
: r_name(name),
  r_begin_time(beginTime),
  r_end_time(endTime),
  r_rsScheduled(),
  r_demand()
{
}


LpiTimeIntervalData::LpiTimeIntervalData (const LpiTimeIntervalData & source)
: r_name (source.r_name),
  r_begin_time(source.r_begin_time),
  r_end_time(source.r_end_time),
  r_rsScheduled(source.r_rsScheduled),
  r_demand(source.r_demand)
{
}


LpiTimeIntervalData & LpiTimeIntervalData::operator= (const LpiTimeIntervalData & source)
{
   if (this != &source)
   {
      r_name = source.r_name;
      r_begin_time = source.r_begin_time;
      r_end_time = source.r_end_time;
      r_rsScheduled = source.r_rsScheduled;
      r_demand = source.r_demand;
   }

   return *this;
}


LpiScheduleTimeLine::LpiScheduleTimeLine (const LpiScheduleTimeLine & source)
: r_scheduleIntervals(source.r_scheduleIntervals)
{
}


LpiScheduleTimeLine & LpiScheduleTimeLine::operator= (const LpiScheduleTimeLine & source)
{
   if (this != &source)
   {
      r_scheduleIntervals.resize(source.getAllScheduleIntervals().size());

      for (unsigned int i = 0; i < source.getAllScheduleIntervals().size(); i++)
      {
         r_scheduleIntervals[i] = source.getScheduleInterval(i);
      }
   }

   return *this;
}


LpiTimeIntervalData  LpiScheduleTimeLine::getScheduleInterval(int i) const
{
   return r_scheduleIntervals[i];
}


std::vector<LpiTimeIntervalData> LpiScheduleTimeLine::getAllScheduleIntervals() const
{
   return r_scheduleIntervals;
}


void LpiScheduleTimeLine::setScheduleInterval(int i, const LpiTimeIntervalData & source)
{
   r_scheduleIntervals[i] = source;
}


void LpiScheduleTimeLine::setAllScheduleIntervals(const std::vector<LpiTimeIntervalData> & source)
{
   r_scheduleIntervals = source;
}


DepartureInfo::DepartureInfo (const DepartureInfo & source)
: itot(source.itot),
  stot(source.stot),
  ftot(source.ftot),
  r_eobt(source.r_eobt)
{
}


DepartureInfo & DepartureInfo::operator= (const DepartureInfo & source)
{
   if (this != &source)
   {
      itot = source.itot;
      stot = source.stot;
      ftot = source.ftot;
      r_eobt = source.r_eobt;
   }

   return *this;
}


ArrivalInfo::ArrivalInfo(const ArrivalInfo & source)
: ildt(source.ildt),
  sldt(source.sldt),
  fldt(source.fldt),
  r_eobt(source.r_eobt)
{
}


ArrivalInfo & ArrivalInfo::operator= (const ArrivalInfo & source)
{
   if (this != &source)
   {
      ildt = source.ildt;
      sldt = source.sldt;
      fldt = source.fldt;
      r_eobt = source.r_eobt;
   }

   return *this;
}


LpiScheduledFlightPlan::LpiScheduledFlightPlan(const LpiScheduledFlightPlan & source)
: callsign(source.callsign),
  depAerodrome(source.depAerodrome),
  arrAerodrome(source.arrAerodrome),
  opType(source.opType),
  r_assigned_runway(source.r_assigned_runway),
  departureTimes(source.departureTimes),
  arrivalTimes(source.arrivalTimes),
  forecastDelay(source.forecastDelay),
  punctualityDelay(source.punctualityDelay),
  r_turnRoundDelayed(source.r_turnRoundDelayed)
{
}


LpiScheduledFlightPlan & LpiScheduledFlightPlan::operator= (const LpiScheduledFlightPlan & source)
{
   if (this != &source)
   {
      callsign         = source.callsign;
      depAerodrome     = source.depAerodrome;
      arrAerodrome     = source.arrAerodrome;
      opType           = source.opType;
      r_assigned_runway = source.r_assigned_runway;
      departureTimes   = source.departureTimes;
      arrivalTimes     = source.arrivalTimes;
      forecastDelay    = source.forecastDelay;
      punctualityDelay = source.punctualityDelay;
      r_turnRoundDelayed = source.r_turnRoundDelayed;
   }

   return *this;
}


LpiFPList::LpiFPList (const LpiFPList & source)
{
   r_FpList = source.r_FpList;
}


LpiFPList & LpiFPList::operator= (const LpiFPList & source)
{
   if (this != &source)
   {
      r_FpList = source.r_FpList;
   }

   return *this;
}


LpiScheduledFlightPlan LpiFPList::getFpList(int i) const
{
   return r_FpList[i];
}


std::vector<LpiScheduledFlightPlan> LpiFPList::getFpList() const
{
   return r_FpList;
}


void LpiFPList::setFpList(int i, const LpiScheduledFlightPlan source)
{
   r_FpList[i] = source;
}


void LpiFPList::setFpList(const std::vector<LpiScheduledFlightPlan> source)
{
   r_FpList = source;
}


LpiSchedule::LpiSchedule(const LpiSchedule& source)
: r_messageTimeAndDate(source.r_messageTimeAndDate),
  r_calculationReason(source.r_calculationReason),
  r_frozenPeriod(source.r_frozenPeriod),
  r_timeLineScheduled(source.r_timeLineScheduled),
  r_FPList(source.r_FPList),
  r_demand(source.r_demand),
  r_performanceInfo(source.r_performanceInfo),
  r_capacityInfo(source.r_capacityInfo),
  r_origin(source.r_origin)
{
}


LpiSchedule & LpiSchedule::operator= (const LpiSchedule & source)
{
   if (this != &source)
   {
      r_messageTimeAndDate = source.r_messageTimeAndDate;
      r_calculationReason  = source.r_calculationReason;
      r_frozenPeriod = source.r_frozenPeriod;
      r_timeLineScheduled  = source.r_timeLineScheduled;
      r_FPList = source.r_FPList;
      r_demand             = source.r_demand;
      r_performanceInfo    = source.r_performanceInfo;
      r_capacityInfo = source.r_capacityInfo;
      r_origin = source.r_origin;
   }
   return *this;
}


// Output operators section

std::ostream & operator<<(std::ostream & os, const LpiRS_Scheduled & rsData)
{
   return os << "[ RS: "   << rsData.getRunwaySystem()
             << " | RWY ARR: "  << rsData.getRunwayArr()
             << " | RWY DEP: "  << rsData.getRunwayDep()
             << " | CFG: "  << rsData.getConfiguration()
             << ']';
}


