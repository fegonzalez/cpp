
#include <algorithm>
#include <iterator>
#include <iostream>
#include <sstream>

#include "LpiComparativeKpis.h"


LpiIntervalDataKpis::LpiIntervalDataKpis()
{}

LpiIntervalDataKpis::LpiIntervalDataKpis (const LpiIntervalDataKpis & source)
: r_shortage(source.r_shortage),
  r_shortageWA(source.r_shortageWA),
  r_airportCapacity(source.r_airportCapacity),
  r_airportCapacityWA(source.r_airportCapacityWA),
  r_rsCapacity(source.r_rsCapacity),
  r_rsCapacityWA(source.r_rsCapacityWA),
  r_maxForecastedDelay(source.r_maxForecastedDelay),
  r_maxForecastedDelayWA(source.r_maxForecastedDelayWA),
  r_percentagePunctual(source.r_percentagePunctual),
  r_percentagePunctualWA(source.r_percentagePunctualWA),
  r_averageForecastedDelay_DelayedFPs(source.r_averageForecastedDelay_DelayedFPs),
  r_averageForecastedDelay_DelayedFPsWA(source.r_averageForecastedDelay_DelayedFPsWA)
{
}


LpiIntervalDataKpis & LpiIntervalDataKpis::operator= (const LpiIntervalDataKpis & source)
{
   if (this != &source)
   {
      r_shortage = source.r_shortage;
      r_shortageWA = source.r_shortageWA;
      r_airportCapacity = source.r_airportCapacity;
      r_airportCapacityWA = source.r_airportCapacityWA;
      r_rsCapacity = source.r_rsCapacity;
      r_rsCapacityWA = source.r_rsCapacityWA;
      r_maxForecastedDelay = source.r_maxForecastedDelay;
      r_maxForecastedDelayWA = source.r_maxForecastedDelayWA;
      r_percentagePunctual = source.r_percentagePunctual;
      r_percentagePunctualWA = source.r_percentagePunctualWA;
      r_averageForecastedDelay_DelayedFPs = source.r_averageForecastedDelay_DelayedFPs;
      r_averageForecastedDelay_DelayedFPsWA = source.r_averageForecastedDelay_DelayedFPsWA;
   }

   return *this;
}


LpiIntervalKpi::LpiIntervalKpi()
: r_startTimeAndDate(),
  r_endTimeAndDate(),
  r_deltaKpis(),
  r_relativeKpis()
{
}


LpiIntervalKpi::LpiIntervalKpi (const LpiIntervalKpi &source)
: r_startTimeAndDate(source.r_startTimeAndDate),
  r_endTimeAndDate(source.r_endTimeAndDate),
  r_deltaKpis(source.r_deltaKpis),
  r_relativeKpis(source.r_relativeKpis)
{
}


LpiIntervalKpi & LpiIntervalKpi::operator= (const LpiIntervalKpi & source)
{
   if (this != &source)
   {
      r_startTimeAndDate = source.r_startTimeAndDate;
      r_endTimeAndDate = source.r_endTimeAndDate;
      r_deltaKpis = source.r_deltaKpis;
      r_relativeKpis = source.r_relativeKpis;
   }
   return *this;
}


LpiComparativeKpis::LpiComparativeKpis ()
: r_kpisPerInterval()
{
}


LpiComparativeKpis::LpiComparativeKpis (const LpiComparativeKpis &source)
: r_kpisPerInterval(source.r_kpisPerInterval)
{
}


LpiComparativeKpis & LpiComparativeKpis::operator= (const LpiComparativeKpis & source)
{
   if (this != &source)
   {
      r_kpisPerInterval = source.r_kpisPerInterval;
   }
   return *this;
}


void LpiComparativeKpis::addKpiPerInterval(const LpiIntervalKpi &kpi)
{
   r_kpisPerInterval.push_back(kpi);
}


std::string LpiComparativeKpis::getRelativeKpisAsString() const
{
   std::stringstream relativeKPIsStream;

   for(unsigned int i = 0; i < r_kpisPerInterval.size() ; i++)
   {
      LpiIntervalKpi data = r_kpisPerInterval[i];

      relativeKPIsStream << "t" << i << ":[ " << data.getStartTimeAndDate() << ", " << data.getEndTimeAndDate() << "]\n";

      LpiIntervalDataKpis relativeKPIs = data.getRelativeKpis();
      relativeKPIsStream << "\t[RELAT KPIs: " << relativeKPIs << "]\n";
   }

   return relativeKPIsStream.str();
}


// Output operators section
std::ostream& operator<<(std::ostream &os, const LpiIntervalDataKpis & kpi)
{
   return os << "[SHORT: " << kpi.getShortage() << "-" << kpi.getShortageWA()
             << " | AIRP_CAP: " << kpi.getAirportCapacity() << "-" << kpi.getAirportCapacityWA()
             << " | RS_CAP: "   << kpi.getRSCapacity() << "-" << kpi.getRSCapacityWA()
             << " | MAX_FCST_DELAY: " << kpi.getMaxForecastedDelay() << "-" << kpi.getMaxForecastedDelayWA()
             << " | PCTG_PUNCT: " << kpi.getPercentagePunctual() << "-" << kpi.getPercentagePunctualWA()
             << " | AVG_FCST_DLY_DELAYED: " << kpi.getAverageForecastedDelay_DelayedFPs() << "-" << kpi.getAverageForecastedDelay_DelayedFPsWA()
             << ']';
}


std::ostream & operator<< (std::ostream & os, const LpiIntervalKpi & kpi)
{
   return os << '[' << kpi.getStartTimeAndDate()
             << "-"  << kpi.getEndTimeAndDate()
             << " | DELTA:\n" << kpi.getDeltaKpis() << '\n'
             << " | REL:\n"   << kpi.getRelativeKpis() << '\n'
             << ']';
}


std::ostream & operator<<(std::ostream & os, const LpiComparativeKpis & kpis)
{
   vector<LpiIntervalKpi> kpis_collection = kpis.getKpisPerInterval();

   std::copy(kpis_collection.begin(), kpis_collection.end(), std::ostream_iterator<LpiIntervalKpi>(os, "\n"));

   return os;
}

