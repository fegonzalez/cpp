/*
 * LxiMaxILSCategory.h
 *
 *  Created on: 12/12/2013
 *      Author: gpfernandez
 */

#ifndef LpiMaxILSCategory_H_
#define LpiMaxILSCategory_H_

#include <iostream>
#include <string>
#include <boost/algorithm/string/trim.hpp>



/**@class LpiMaxILSCategory
 *
 * @warning Data type equivalent to Max_ILS_Category at 
 *          "rtpServer/lib_Interface/types/LpiAdaptationAirportsInfo.h"
 *
 */
class LpiMaxILSCategory
{
public:
   enum LpiEnumCatILS
   {
       E_NO_ILS=0,
       E_CAT_I,
       E_CAT_II,
       E_CAT_III_A,
       E_CAT_III_B,
       E_CAT_III_C
   };

   LpiMaxILSCategory() : _enum(LpiEnumCatILS(0)) {}
   LpiMaxILSCategory(LpiEnumCatILS value) : _enum(value) {}
   bool operator==(LpiEnumCatILS value) const {return _enum == value;}
   operator LpiEnumCatILS(void) const {return _enum;}

   static std::string getEnumAsString(LpiEnumCatILS value)
   {
       std::string response;
       switch(value){
       case E_NO_ILS:
          response = "NO_ILS";
          break;
       case E_CAT_I:
           response = "CAT_I";
           break;
       case E_CAT_II:
           response = "CAT_II";
           break;
       case E_CAT_III_A:
           response = "CAT_III_A";
           break;
       case E_CAT_III_B:
           response = "CAT_III_B";
           break;
       case E_CAT_III_C:
           response = "CAT_III_C";
           break;
       default:
           response = "---";
           break;
       }
       return response;
   }

   //ISE#392
   static std::string getEnumAsStringToHmi(std::string value)
   {
       std::string response;
       if (value == "NO_ILS")
          response = "NO";
       else if (value == "CAT_I")
           response = "CAT I";
       else if (value == "CAT_II")
           response = "CAT II";
       else if (value == "CAT_III_A")
           response = "CAT III-A";
       else if (value == "CAT_III_B")
           response = "CAT III-B";
       else if (value == "CAT_III_C")
           response = "CAT III-C";
       else
           response = "---";

       return response;
   }

   static LpiEnumCatILS getEnumFromString(std::string value)
   {
      LpiEnumCatILS response = E_NO_ILS;

      std::string category = value;

      boost::algorithm::trim(category);

      if (category == "NO_ILS")
      {
         response = E_NO_ILS;
      }
      else if (category == "CAT_I")
      {
         response = E_CAT_I;
      }
      else if (category == "CAT_II")
      {
         response = E_CAT_II;
      }
      else if (category == "CAT_III_A")
      {
         response = E_CAT_III_A;
      }
      else if (category == "CAT_III_B")
      {
         response = E_CAT_III_B;
      }
      else if (category == "CAT_III_C")
      {
         response = E_CAT_III_C;
      }

      return response;
   }

private:
   LpiEnumCatILS _enum;
};

std::ostream & operator<<(std::ostream &os,
                          const LpiMaxILSCategory::LpiEnumCatILS &obj);


#endif /* LpiMaxILSCategory_H_ */
