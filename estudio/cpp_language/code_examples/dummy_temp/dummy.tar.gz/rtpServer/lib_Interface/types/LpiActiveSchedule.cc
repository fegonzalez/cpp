/*
 *  LpiActiveSchedule.cc
 *
 *  Created on: 14/07/2014
 *
 *  Author: gpfernandez
 */

#include <LctimTimeUtils.h>
#include "LpiActiveSchedule.h"


LpiActiveSchedule::LpiActiveSchedule ()
: LpiSchedule(),
  r_id(-1),
  r_name("")
{
}


LpiActiveSchedule::LpiActiveSchedule(const LpiActiveSchedule & source)
: LpiSchedule(source),
  r_id(source.r_id),
  r_name(source.r_name),
  r_activation_time(source.r_activation_time)
{
}


LpiActiveSchedule::LpiActiveSchedule(const LpiSchedule & source)
: LpiSchedule(source),
  r_id(-1),
  r_name("")
{
}


LpiActiveSchedule & LpiActiveSchedule::operator= (const LpiActiveSchedule & source)
{
   if (this != &source)
   {
      LpiSchedule::operator=(source);
      r_id = source.r_id;
      r_name = source.r_name;
      r_activation_time = source.r_activation_time;
   }

   return *this;
}


void LpiActiveSchedule::storeTimestamp (boost::posix_time::ptime timestamp)
{
   r_activation_time = LctimTimeUtils::formatTime(timestamp, "%H%M/%d%m%y");
}


std::ostream & operator<< (std::ostream & os, const LpiActiveSchedule & info)
{
   os << "[ID: " << info.getId()
      << " | NAME: " << info.getName()
      << " | ACT_TIME: " << info.getActivationTime()
//      << static_cast<const LpiSchedule &>(info)
      << ']';

   return os;
}
