// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 15:58:39 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------


#include "LpiConfigurationHmiParameters.h"

std::ostream & operator<<(std::ostream & out, const LpiConfigurationHmiParameters & confParams)
{

    TimeRtpHmiParameters time = confParams.getTimeRtpHmiParameters();
    out << "[hmiRtpParameters: " << "\n"
        << " \t|hoursRtpHmiWindow: " << time.getHoursRtpHmiWindow() << "\n"
        << " \t|graphicRtpMaxRepresentation: \n";

    GraphicRtpMaxRepresentation graphicMax = confParams.getGraphicRtpMaxRepresentation();
    out << " \t\t|graphicRtpMaxDArr: " << graphicMax.getGraphicRtpMaxDArr() << "\n"
        << " \t\t|graphicRtpMaxDDep: " << graphicMax.getGraphicRtpMaxDDep() << "\n";

    out << " \t|minRtpIntervalForScrolling: " << confParams.getMinRtpIntervalsForScrolling() << "\n"
        << " \tcolorsRtpHmi: \n";

    ColorsRtpHmi colors = confParams.getColorsRtpHmi();
    out << " \t\t|colorGraphicComplexity: " << colors.getGraphicRtpColors().getColorGraphicComplexity() << "\n"
        << " \t\t|colorGrapchiSimOps: " << colors.getGraphicRtpColors().getColorGraphicSimOps() << "\n"
        << " \t\t|colorGraphicTotalMov: " << colors.getGraphicRtpColors().getColorGraphicTotalMov() << "\n"
        << " \t\t|colorGraohicVFR: " << colors.getGraphicRtpColors().getColorGraphicVFR() << "\n"
        << " \tmoduleColors: \n";

    out << " \t\t|colorModule1: " << colors.getModuleColors().getColorModule1() << "\n"
        << " \t\t|colorModule2: " << colors.getModuleColors().getColorModule2() << "\n"
        << " \t\t|colorModule3: " << colors.getModuleColors().getColorModule3() << "\n"
        << " \t\t|colorModule4: " << colors.getModuleColors().getColorModule4() << "\n"
        << " \t\t|colorModule5: " << colors.getModuleColors().getColorModule5() << "\n";

	out << " \t|AlarmColors: \n"
		<< " \t\t|colorAlarmThreshold: " << colors.getAlarmColors().getColorAlarmThreshold() << "\n"
		<< " \t\t|colorWarningThreshold: " << colors.getAlarmColors().getColorWarningThreshold() << "\n";

   return out;


}

