
#include "LpiTime.h"

#include <LclogConfig.h>
#include <ctime>
//#include <cstdio>
#include <boost/lexical_cast.hpp>


std::string toTimeString(const LpiTime & seconds)
{
   return (boost::lexical_cast<std::string>(seconds) + "->") +
          toTimeStringShort(seconds);
}


std::string toTimeStringShort(const LpiTime & seconds)
{
   std::time_t v_time_t = seconds;
   struct std::tm * ptm = localtime(&v_time_t);
   char buffer[LclogConfig::timeShortBufferSize];
   memset(buffer, 0, sizeof(buffer));
   std::strftime (buffer,
                  LclogConfig::timeShortBufferSize,
                  "%H.%M.%S",
                  ptm);
   return buffer;
}
