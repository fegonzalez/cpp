
#if !defined(__LPI_ADAP_PREFS_CONSTANTS__) 
#define __LPI_ADAP_PREFS_CONSTANTS__

/**@file LpiAdapPrefsConstants.h

   @brief types & constants used in the management of the 'preference'
   information related to the "FILENAME_DAORTP_ASSIGNMENT_PREFERENCE"
   adaption file.

   @warning Using this file to avoid multiple include directories in
   the user files.
 */


#include <utility>      // std::pair
#include <tuple>
#include <vector>
#include <string>

//typedef std::pair<std::string, std::string> PreferenceElement;

typedef unsigned int PREF_LEVEL_TYPE;
typedef std::string PREF_AIRPORT_TYPE;
typedef PREF_AIRPORT_TYPE PREF_AIRPORT1_TYPE;
typedef PREF_AIRPORT_TYPE PREF_AIRPORT2_TYPE;
typedef std::tuple<PREF_LEVEL_TYPE,PREF_AIRPORT1_TYPE, PREF_AIRPORT2_TYPE>
  PreferenceElement;
typedef std::vector<PreferenceElement> PreferenceElementList;


#endif // __LPI_ADAP_PREFS_CONSTANTS__
