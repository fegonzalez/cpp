/*
 * LpiOptimizationCriteriaTimedData.h
 *
 *  Created on: 12/09/2014
 *      Author: mbegega
 */

#ifndef LPIOPTIMIZATIONCRITERIATIMEDDATA_H_
#define LPIOPTIMIZATIONCRITERIATIMEDDATA_H_

#include <iostream>
#include <string>

using std::string;

class LpiOptimizationCriteriaTimedData
{
   public:

      enum CriteriaType { E_AUTO, E_MANUAL };

      LpiOptimizationCriteriaTimedData();
      LpiOptimizationCriteriaTimedData(float arrivalsPriority, float departuresPriority, CriteriaType type);

      LpiOptimizationCriteriaTimedData(const LpiOptimizationCriteriaTimedData & source);

      virtual ~LpiOptimizationCriteriaTimedData() {}

      LpiOptimizationCriteriaTimedData & operator= (const LpiOptimizationCriteriaTimedData & source);

      float getArrivalsPriority() const
      {
         return r_arrivals_priority;
      }

      void setArrivalsPriority(float arrivalsPriority)
      {
         r_arrivals_priority = arrivalsPriority;
      }

      float getDeparturesPriority() const
      {
        return r_departures_priority;
      }

      void setDeparturesPriority(float departuresPriority)
      {
        r_departures_priority = departuresPriority;
      }

      void setCriteriaType (CriteriaType newType)
      {
         r_type = newType;
      }

      CriteriaType getCriteriaType() const
      {
         return r_type;
      }

      static string criteriaTypeToString(const CriteriaType & type);

   protected:

    float r_arrivals_priority;
    float r_departures_priority;

    CriteriaType r_type;
};


std::ostream& operator<<(std::ostream &os, const LpiOptimizationCriteriaTimedData &info);

#endif /* LPIOPTIMIZATIONCRITERIATIMEDDATA_H_ */
