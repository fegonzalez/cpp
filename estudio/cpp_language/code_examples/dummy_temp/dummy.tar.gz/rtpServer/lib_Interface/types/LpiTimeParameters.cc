
#include "LpiTimeParameters.h"

std::ostream & operator<<(std::ostream & out,
                          const LpiTimeParameters & timeParameters)
{
   out << "\nTotal window (h):           " <<
         timeParameters.getHoursWindow();
   out << "\nSubinterval duration (min): " <<
         timeParameters.getMinutesSubinterval();
   out << "\nFrozen period (min):        " <<
         timeParameters.getMinutesFrozen();
   out << "\nFrozen period for clock forwarding (min):        " <<
         timeParameters.getMinutesFrozenForClock();

   return out;
}


