/*
 * LpiComposedKey.h
 *
 *  Created on: 18/02/2014
 *      Author: mbegega
 */

#ifndef LPICOMPOSEDKEY_H_
#define LPICOMPOSEDKEY_H_

#include <string>
#include <map>
#include <iostream>
#include <boost/foreach.hpp>


using std::string;
using std::map;
using std::ostream;

//With Generic (Templates)
//Only implemented 2 y 3 tuples. N-Tuples implemented in variadic templates in C++ 11


template <typename K1, typename K2>
class LpiComposedKeyPair
{
   public:
      K1 _pair_key1;
      K2 _pair_key2;

      LpiComposedKeyPair(
            K1 pair_key1,
            K2 pair_key2):
            _pair_key1(pair_key1),
            _pair_key2(pair_key2)
      {}

      K1 getFirstElement () const
      { return _pair_key1; }

      K2 getSecondElement () const
      { return _pair_key2; }
};


template <typename K1, typename K2>
inline ostream & operator<< (ostream & out, const LpiComposedKeyPair<K1, K2> & key);


template <typename K1, typename K2>
class LpiComposedKeyPairComparer
{
public:
    bool operator()(const LpiComposedKeyPair<K1, K2> & leftOperand,
                    const LpiComposedKeyPair<K1, K2> & rightOperand) const
    {
       if (leftOperand._pair_key1 != rightOperand._pair_key1)
       {
          return leftOperand._pair_key1 < rightOperand._pair_key1;
       }
       else
       {
          return leftOperand._pair_key2 < rightOperand._pair_key2;
       }
    }
};


template <typename K1, typename K2, typename K3>
class LpiComposedKey
{
   public:
      K1 _characteristic_name;
      K2 _characteristic_value;
      K3 _element;

      LpiComposedKey(
            K1 characteristic_name,
            K2 characteristic_value,
            K3 element):
            _characteristic_name(characteristic_name),
            _characteristic_value(characteristic_value),
            _element(element)
      {}

      K1 getFirstElement () const
      { return _characteristic_name; }

      K2 getSecondElement () const
      { return _characteristic_value; }

      K3 getThirdElement () const
      { return _element; }
};


template <typename K1, typename K2, typename K3>
inline ostream & operator<< (ostream & out, const LpiComposedKey<K1, K2, K3> & key);


template <typename K1, typename K2, typename K3>
class LpiComposedKeyComparer {
public:

    bool operator()(const LpiComposedKey<K1, K2, K3> & leftOperand, const LpiComposedKey<K1, K2, K3> & rightOperand) const
    {
       if (leftOperand._characteristic_name != rightOperand._characteristic_name)
       {
          return leftOperand._characteristic_name < rightOperand._characteristic_name;
       }
       else if (leftOperand._characteristic_value != rightOperand._characteristic_value)
       {
          return leftOperand._characteristic_value < rightOperand._characteristic_value;
       }
       else
       {
          return leftOperand._element < rightOperand._element;
       }
    }
};

#endif /* LPICOMPOSEDKEY_H_ */
