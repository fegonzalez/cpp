#ifndef LPISCHEDULEORIGIN_H_
#define LPISCHEDULEORIGIN_H_

#include <iostream>

class LpiScheduleOrigin
{
   public:
      enum LpiEnum
      {
         E_UNKNOWN = 0,
         E_PREFERENTIAL,
         E_OPTIMAL,
         E_NEW_CRITERIA,
         E_MANUAL_EDITION,
         E_RWY_CLOSURES_ACTIVE,
         E_SOLUTION_RWY_CLOSURES
      };
};


std::ostream& operator << (std::ostream &os,
                           const LpiScheduleOrigin::LpiEnum &obj);


#endif
