/*
 * LpiMeteoInfo.cpp
 *
 *  Created on: 21/01/2014
 *      Author: gpfernandez
 */


#include "LpiMeteoInfo.h"
#include <LplcTypeConstants.h>

#include <iostream>
#include <sstream>
#include <iterator>


RVRPerRunwayList::RVRPerRunwayList ()
{
}

RVRPerRunway::RVRPerRunway ()
{
}
RVRPerRunway & RVRPerRunway::operator= (const RVRPerRunway & source)
{
   _name      = source._name;
   _rvr       = source._rvr;
   _crosswind = source._crosswind;
    _tailwind  = source._tailwind;
   return *this;
}

RVRPerRunwayList & RVRPerRunwayList::operator=(const RVRPerRunwayList & source)
{
   _RVRPerRunway.clear();
   for(unsigned int i=0; i<source.getRVRPerRunway().size(); i++)
   {
     _RVRPerRunway.push_back(source.getRVRPerRunway(i));
   }
   return *this;
}


//LpiMeteoInfo method implementations

LpiMeteoInfo::LpiMeteoInfo ()
{
}

LpiMeteoInfo::LpiMeteoInfo (const LpiMeteoInfo & source):
startTimeAndDate     (source.startTimeAndDate),
endTimeAndDate       (source.endTimeAndDate),
probability          (source.probability),
windDirection        (source.windDirection),
windSpeed            (source.windSpeed),
gustSpeed            (source.gustSpeed),
gustDirection        (source.gustDirection),
airTemperature       (source.airTemperature),
dewPointTemperature  (source.dewPointTemperature),
horizontalVisibility (source.horizontalVisibility),
qnh                  (source.qnh),
cloudbase            (source.cloudbase),
significantWeather   (source.significantWeather),
wetness              (source.wetness),
lvpActivation        (source.lvpActivation),
deicing              (source.deicing),
rvrperRunway         (source.rvrperRunway)
{

    if(source.significantWeatherQualifier )
    {
      significantWeatherQualifier  = *source.significantWeatherQualifier;
    }

    if(source.significantWeatherPhenomenon)
    {
      significantWeatherPhenomenon = *source.significantWeatherPhenomenon;
    }

    if(source.requiredILSCategory)
    {
      requiredILSCategory  = *source.requiredILSCategory;
    }

    windVector = source.windVector;
    // windVector.clear();
    // for (unsigned int i= 0; i<source.windVector.size(); i++)
    // {
    //   windVector.push_back(source.windVector[i]);
    // }
}


LpiMeteoInfo& LpiMeteoInfo::operator =(const LpiMeteoInfo& source)
{
  if(this != &source)
  {
    startTimeAndDate     = source.startTimeAndDate;
    endTimeAndDate       = source.endTimeAndDate;
    probability          = source.probability;
    windDirection        = source.windDirection;
    windSpeed            = source.windSpeed;
    gustSpeed            = source.gustSpeed;
    gustDirection        = source.gustDirection;
    airTemperature       = source.airTemperature;
    dewPointTemperature  = source.dewPointTemperature;
    horizontalVisibility = source.horizontalVisibility;
    qnh                  = source.qnh;
    cloudbase            = source.cloudbase;
    significantWeather   = source.significantWeather;
    if(source.significantWeatherQualifier )
    {
      significantWeatherQualifier  = *source.significantWeatherQualifier;
    }
    if(source.significantWeatherPhenomenon)
    {
      significantWeatherPhenomenon = *source.significantWeatherPhenomenon;
    }

    wetness              = source.wetness;
    lvpActivation        = source.lvpActivation;
    if(source.requiredILSCategory)
    {
      requiredILSCategory  = *source.requiredILSCategory;
    }
    deicing              = source.deicing;
    rvrperRunway = source.rvrperRunway;


    windVector = source.windVector;
    // windVector.clear();
    // for (unsigned int i= 0; i<source.windVector.size(); i++)
    // {
    //   windVector.push_back(source.windVector[i]);
    // }
  }
  
   return *this;
}

posix_time::ptime LpiMeteoInfoList::getMessageTimeandDate() const
{
   return messageTimeandDate;
}

void LpiMeteoInfoList::setMessageTimeandDate(posix_time::ptime _messageTimeandDate)
{
   messageTimeandDate=_messageTimeandDate;
}

std::string LpiMeteoInfoList::getAirport () const
{
   return airport;
}
void LpiMeteoInfoList::setAirport(std::string _airport)
{
   airport = _airport;
}

// std::vector<LpiMeteoInfo>  LpiMeteoInfoList::getMeteoInfo() const
// {
//    return meteoInfo;
// }

const std::vector<LpiMeteoInfo>  & LpiMeteoInfoList::getMeteoInfo() const
{
   return meteoInfo;
}

void LpiMeteoInfoList::setMeteoInfo(const std::vector<LpiMeteoInfo> &newval)
{
   meteoInfo = newval;
}

void LpiMeteoInfoList::addMeteoInfoElement(const LpiMeteoInfo &newval)
{
  meteoInfo.push_back(newval);
}

posix_time::ptime LpiMeteoInfo::getStartTimeAndDate() const
{
   return startTimeAndDate;
}

void LpiMeteoInfo::setStartTimeAndDate(posix_time::ptime _startTimeandDate)
{
   startTimeAndDate=_startTimeandDate;
}
posix_time::ptime LpiMeteoInfo::getEndTimeAndDate() const
{
   return endTimeAndDate;
}

void LpiMeteoInfo::setEndTimeAndDate(posix_time::ptime _endTimeandDate)
{
   endTimeAndDate=_endTimeandDate;
}

double  LpiMeteoInfo::getProbability () const
{
   return probability;
}

void LpiMeteoInfo::setProbability(double _probability)
{
   probability = _probability;
}

std::string  LpiMeteoInfo::getSignificantWeather () const
{
   return significantWeather;
}
void LpiMeteoInfo::setSignificantWeather( std::string _significantWeather)
{
   significantWeather = _significantWeather;
}

const boost::optional<lcmeteo::TYPE_WIND_SPEED> & LpiMeteoInfo::getWindSpeed () const
{
   return windSpeed;
}
void LpiMeteoInfo::setWindSpeed(lcmeteo::TYPE_WIND_SPEED _windSpeed)
{
   windSpeed = _windSpeed;
}

const boost::optional<lcmeteo::TYPE_WIND_DIRECTION> & LpiMeteoInfo::getWindDirection () const
{
   return windDirection;
}
void LpiMeteoInfo::setWindDirection(lcmeteo::TYPE_WIND_DIRECTION _windDirection)
{
   windDirection = _windDirection;
}

const boost::optional<lcmeteo::TYPE_GUST_SPEED> & LpiMeteoInfo::getGustSpeed () const
{
   return gustSpeed;
}
void LpiMeteoInfo::setGustSpeed(lcmeteo::TYPE_GUST_SPEED _gustSpeed)
{
   gustSpeed = _gustSpeed;
}

const boost::optional<lcmeteo::TYPE_GUST_DIRECTION> & LpiMeteoInfo::getGustDirection () const
{
   return gustDirection;
}

void LpiMeteoInfo::setGustDirection(lcmeteo::TYPE_GUST_DIRECTION _gustDirection)
{
   gustDirection = _gustDirection;
}

const boost::optional<lcmeteo::TYPE_DEW_POINT_TEMPERATURE> & LpiMeteoInfo::getDewPointTemperature () const
{
   return dewPointTemperature;
}
void LpiMeteoInfo::setDewPointTemperature (lcmeteo::TYPE_DEW_POINT_TEMPERATURE _dewPointTemperature)
{
    dewPointTemperature=_dewPointTemperature;
}

const boost::optional<lcmeteo::TYPE_AIR_TEMPERATURE> & LpiMeteoInfo::getAirTemperature () const
{
   return airTemperature;
}

void LpiMeteoInfo::setAirTemperature (lcmeteo::TYPE_AIR_TEMPERATURE _airTemperature)
{
    airTemperature =_airTemperature;
}

const boost::optional<lcmeteo::TYPE_HORIZONTAL_VISIVILITY> & LpiMeteoInfo::getHorizontalVisibility() const
{
   return horizontalVisibility;
}
void LpiMeteoInfo::setHorizontalVisibility (lcmeteo::TYPE_HORIZONTAL_VISIVILITY _horizontalVisibility)
{
   horizontalVisibility = _horizontalVisibility;
}

const boost::optional<lcmeteo::TYPE_QNH> & LpiMeteoInfo::getQnh () const
{
   return qnh;
}
void LpiMeteoInfo::setQnh(lcmeteo::TYPE_QNH _qnh)
{
   qnh = _qnh;
}

const boost::optional<lcmeteo::TYPE_CLOUD_BASE> & LpiMeteoInfo::getCloudbase () const
{
   return cloudbase; 
}

void LpiMeteoInfo::setCloudbase(lcmeteo::TYPE_CLOUD_BASE _cloudbase)
{
   cloudbase = _cloudbase;
}

const boost::optional<std::string> & LpiMeteoInfo::getSignificantWeatherQualifier() const
{
   return significantWeatherQualifier;
}
void LpiMeteoInfo::setSignificantWeatherQualifier(std::string _significantWeatherQualifier)
{
   significantWeatherQualifier = _significantWeatherQualifier;
}

const boost::optional<std::string> & LpiMeteoInfo::getSignificantWeatherPhenomenon() const
{
   return significantWeatherPhenomenon;
}
void LpiMeteoInfo::setSignificantWeatherPhenomenon(std::string _significantWeatherPhenomenon)
{
  significantWeatherPhenomenon = _significantWeatherPhenomenon;
}

std::string LpiMeteoInfo::getWetness() const
{
   return wetness;
}
void LpiMeteoInfo::setWetness(std::string _Wetness)
{
   this->wetness=_Wetness;
}

bool LpiMeteoInfo::getDeicing() const
{
   return deicing;
}
void LpiMeteoInfo::setDeicing(bool _deicing)
{
   this->deicing=_deicing;
}

bool LpiMeteoInfo::getLvpActivation() const
{
   return lvpActivation;
}
void LpiMeteoInfo::setLvpActivation(bool _lvpActivation)
{
   this->lvpActivation=_lvpActivation;
}

const boost::optional<std::string> & LpiMeteoInfo::getRequiredILSCategory() const
{
   return requiredILSCategory;
}
void LpiMeteoInfo::setRequiredILSCategory(std::string _requiredILSCategory)
{
   requiredILSCategory=_requiredILSCategory;
}



// std::vector<unsigned int> LpiMeteoInfo::getWindVector() const
// {
//    return windVector;
// }
// void LpiMeteoInfo::setWindVector(std::vector<unsigned int> _windvector)
// {
//    windVector.clear();
//    for (unsigned int i = 0; i<_windvector.size(); i++)
//    {
//       windVector.push_back(_windvector[i]);
//    }   
// }

std::pair<unsigned int, unsigned int> LpiMeteoInfo::getWindVector() const
{
   return windVector;
}

void LpiMeteoInfo::setWindVector(unsigned int windSpeed,
				 unsigned int windDirection)
{
  windVector = std::make_pair (windSpeed, windDirection);
}



std::ostream& operator<< (std::ostream & out, const std::vector<unsigned int> & windvect)
{
    if (windvect.size()==2)
    {
        out <<"("
            <<windvect[0]
            <<", "
            <<windvect[1]
            <<")";
     }
     else
     {
         out << "Wrong dimension vector";
     }
     return out;
}

std::ostream& operator<< (std::ostream & out, const LpiMeteoInfo & meteo) //IOUpdateMeteoInfo::Meteo::BodyInformation
{
   std::stringstream out_stream;
   out_stream << "[\n startTimeAndDate: " << meteo.getStartTimeAndDate()
         << ",\n endTimeAndDate: " << meteo.getEndTimeAndDate()
         << ",\n probability: " << meteo.getProbability();

   if (meteo.getWindSpeed())
   {
      out_stream <<  ",\n windSpeed: " << *meteo.getWindSpeed();
   }
   else
   {
      out_stream <<  ",\n windSpeed: ---";
   }

   if (meteo.getWindDirection())
   {
      out_stream << ",\n windDirection: " << *meteo.getWindDirection();
   }
   else
   {
      out_stream <<  ",\n windDirection: ---";
   }

   if (meteo.getGustSpeed())
   {
      out_stream << ",\n gustSpeed: " << *meteo.getGustSpeed();
   }
   else
   {
      out_stream << ",\n gustSpeed: ---";
   }

   if (meteo.getGustDirection())
   {
      out_stream << ",\n gustDirection: " << *meteo.getGustDirection();
   }
   else
   {
      out_stream << ",\n gustDirection: ---";
   }

   if (meteo.getAirTemperature())
   {
      out_stream << ",\n airTemperature: " << *meteo.getAirTemperature();
   }
   else
   {
      out_stream << ",\n airTemperature: ---";
   }

   if (meteo.getDewPointTemperature())
   {
      out_stream << ",\n dewPointTemperature: " << *meteo.getDewPointTemperature();
   }
   else
   {
      out_stream << ",\n dewPointTemperature: ---";
   }

   if (meteo.getHorizontalVisibility())
   {
      out_stream << ",\n horizontalVisibility: " << *meteo.getHorizontalVisibility();
   }
   else
   {
      out_stream << ",\n horizontalVisibility: ---";
   }

   if (meteo.getQnh())
   {
      out_stream << ",\n qnh: " << *meteo.getQnh();
   }
   else
   {
      out_stream << ",\n qnh: ---";
   }

   if (meteo.getCloudbase())
   {
      out_stream << ",\n cloudBase: " << *meteo.getCloudbase();
   }
   else
   {
      out_stream << ",\n cloudBase: ---";
   }

   out_stream << ",\n significantWeather: " << meteo.getSignificantWeather();

   if (meteo.getSignificantWeatherQualifier())
   {
      out_stream << ",\n significantWeatherQualifier: " << *meteo.getSignificantWeatherQualifier();
   }
   else
   {
      out_stream << ",\n significantWeatherQualifier: ---";
   }

   if(meteo.getSignificantWeatherPhenomenon())
   {
      out_stream << ",\n significantWeatherPhenomenon: " << *meteo.getSignificantWeatherPhenomenon();
   }
   else
   {
      out_stream << ",\n significantWeatherPhenomenon: ---";
   }

   out_stream << ",\n wetness: " << meteo.getWetness();

   if (meteo.getRequiredILSCategory())
   {
      out_stream << ",\n requiredIlsCategory: " << *meteo.getRequiredILSCategory();
   }
   else
   {
      out_stream << ",\n requiredIlsCategory: ---";
   }

   out_stream << ",\n deicing: " << meteo.getDeicing()
	      << ",\n lvpActivation: " << meteo.getLvpActivation()
	      << ",\n windVector: " << '(' << meteo.getWindVector().first 
	      << ',' << meteo.getWindVector().second << ')';

   out_stream << ",\n runwayList: " << meteo.getRvrperRunway()
	      << "]";

   out_stream << std::endl;

   out << out_stream.str();

   return out;
}

//------------------------------------------------------------------------------

std::ostream& operator<< (std::ostream & out, const LpiMeteoInfoList & obj)  //IOUpdateMeteoInfo::Meteo
{
  out << "\n[AIRPORT: <" << obj.getAirport() << ">\n"
      << " | messageTimeandDate: " << obj.getMessageTimeandDate() << "\n"
      << " | calculationReason: " << obj.getCalculationReason() << "\n"
      << " | timeline: " << obj.getTimeline() << "\n";

  for(unsigned int i = 0; i<obj.getMeteoInfo().size(); i++)
  {
      out << " |MeteoInfo: " << obj.getMeteoInfo()[i] << "\n";
  }

  out << ']' << "\n";

  return out;
}

//------------------------------------------------------------------------------

std::ostream& operator<< (std::ostream & out, const LpiCreateMeteoList & obj)
{

  std::for_each(std::begin(obj),
	  	  	    std::end(obj),
				[&out](const LpiMeteoInfoList &val)
                { out << val << "\n"; });

  return out;
}

//------------------------------------------------------------------------------

std::ostream& operator<< (std::ostream & out, const RVRPerRunwayList & rvrrunway)
{
   out << "(RVR list size: " << rvrrunway.size() << ") : " ;

   for (unsigned int i = 0; i < rvrrunway.getRVRPerRunway().size(); i++)
   {
      out << rvrrunway.getRVRPerRunway(i);
   }
   return out;
}
//
//
//std::ostream& operator<< (std::ostream & out, const RVRPerRunway & runway)
//{
//	out << '(';
//	out << runway.getName() << ", ";
//	if(runway.getRvr())
//	{
//		out << runway.getRvr().get();
//	}
//	else
//	{
//	   out << "-";
//	}
//	out << runway.getCrossWind() << ", ";
//	out << runway.getTailWind() << ", ";
//	out << ')';
//	out << std::endl;
//}



std::ostream& operator<< (std::ostream & out, const RVRPerRunway & runway)
{
   std::stringstream out_stream;

   out_stream <<"\n   (Name: " << runway.getName();

   if (runway.getRvr())
   {
      out_stream << ", RVR: " << *runway.getRvr();
   }
   else
   {
      out_stream << ", RVR: ---";
   }

    out_stream << ", Crosswind: " << runway.getCrossWind()
        <<", Tailwind: " << runway.getTailWind()
        <<")" ;

   out << out_stream.str();

   return out;
}
//------------------------------------------------------------------------------
