#if !defined(__LPIEVALUATIONDISTRIBUTION__)
#define __LPIEVALUATIONDISTRIBUTION__

#include <iostream>

class LpiEvaluationDistribution
{
   public:
      const int getMean () const
      { return r_mean; }

      const int getStandardDeviation () const
      { return r_standardDeviation; }

      // setters
      void setMean (int mean)
      { r_mean = mean; }

      void setStandardDeviation (int standardDeviation)
      { r_standardDeviation = standardDeviation; }

   private:

      int r_mean;
      int r_standardDeviation;
};


std::ostream & operator<<(std::ostream & out,
                          const LpiEvaluationDistribution & distribution);

#endif // __LPIEVALUATIONDISTRIBUTION__
