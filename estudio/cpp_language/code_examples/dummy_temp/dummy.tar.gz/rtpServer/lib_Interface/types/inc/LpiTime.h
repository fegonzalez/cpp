
#if !defined(__LPITIME__)
#define __LPITIME__

typedef unsigned long LpiTime;
typedef unsigned int LpiSeconds;
typedef unsigned int LpiDuration;

#include <string>

std::string toTimeString(const LpiTime &);

std::string toTimeStringShort(const LpiTime &);


#endif // __LPITIME__
