/*
 * LpiRunwayClosure.h
 *
 *  Created on: 18/05/2015
 *      Author: mbegega
 *
 *  Data model for a non availability long period, independent
 *  of timeline configuration
 */

#ifndef LPIRUNWAYCLOSURE_H_
#define LPIRUNWAYCLOSURE_H_

#include <string>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "LpiClosureReason.h"


class LpiRunwayClosure
{
   public:

      LpiRunwayClosure();

      LpiRunwayClosure(const std::string & runway,
                       const boost::posix_time::ptime & startTime,
                       const boost::posix_time::ptime & endTime,
                       const LpiClosureReason::LpiEnum & reason);

      LpiRunwayClosure(const LpiRunwayClosure & source);

      virtual ~LpiRunwayClosure();

      LpiRunwayClosure & operator= (const LpiRunwayClosure & source);

      const std::string & getRunwayId() const;
      const boost::posix_time::ptime & getStartTime() const;
      const boost::posix_time::ptime & getEndTime() const;
      const LpiClosureReason::LpiEnum & getReason() const;

   protected:

      std::string r_runwayId;

      boost::posix_time::ptime r_startTime;
      boost::posix_time::ptime r_endTime;

      LpiClosureReason::LpiEnum r_reason;
};

std::ostream& operator<<(std::ostream &os, const LpiRunwayClosure &info);

#endif /* LPIRUNWAYCLOSURE_H_ */
