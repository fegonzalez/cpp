
#ifndef LPICAPACITYREDUCTIONS_H_
#define LPICAPACITYREDUCTIONS_H_

#include "LpiADO.h"
#include "LpiClosureReason.h"
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>

using namespace boost;

class CapacityReductionsADO
{
   public:
      CapacityReductionsADO() {}
      ~CapacityReductionsADO() {}

      posix_time::ptime getstartTimeAndDate() const{return startTimeAndDate;};
      void setstartTimeAndDate(posix_time::ptime _time){startTimeAndDate=_time;};

      posix_time::ptime getendTimeAndDate() const{return endTimeAndDate;};
      void setendTimeAndDate(posix_time::ptime _time){endTimeAndDate=_time;};

      const LpiADO & getvectorADO() const {return vectorADO;};
      void setvectorADO(const LpiADO& _vector) {vectorADO = _vector;};


   private:
      posix_time::ptime  startTimeAndDate;
      posix_time::ptime  endTimeAndDate;
      LpiADO             vectorADO;

};
//typedef std::vector<CapacityReductionsADO>  CapacityReductions;
class CapacityReductions
{
   public:
      CapacityReductions() {}
      ~CapacityReductions() {}

      const  std::vector<CapacityReductionsADO> & getCapacityReductions() const {return vCapacity;};

      const CapacityReductionsADO & getCapacityReductions(int i) const {return vCapacity[i];};

      void  setCapacityReductionsADO(CapacityReductionsADO v_capacity, int i) {vCapacity[i] = v_capacity;};
      void  setCapacityReductionsADO(CapacityReductionsADO v_capacity) { vCapacity.push_back(v_capacity);};
      
   private:
      std::vector<CapacityReductionsADO> vCapacity;

};

class CapacityReductionsRW
{
   public:
      CapacityReductionsRW() {}
      ~CapacityReductionsRW() {}

      posix_time::ptime getstartTimeAndDate() const{return startTimeAndDate;};
      void setstartTimeAndDate(posix_time::ptime _time){startTimeAndDate=_time;};

      posix_time::ptime getendTimeAndDate() const{return endTimeAndDate;};
      void setendTimeAndDate(posix_time::ptime _time){endTimeAndDate=_time;};

      const LpiADO & getvectorADO() const {return vectorADO;};
      void setvectorADO( const LpiADO& _vector) {vectorADO = _vector;};

      std::string getrunway() const{return runway;};
      void setrunway(std::string _runway){runway= _runway;};

   private:
      posix_time::ptime  startTimeAndDate;
      posix_time::ptime  endTimeAndDate;
      std::string        runway;
      LpiADO             vectorADO;

};
typedef std::vector<CapacityReductionsRW>  CapacityReductionsRWYS;

class RunwaysNonPeriods
{
   public:

      RunwaysNonPeriods()  {}
      ~RunwaysNonPeriods() {}

      posix_time::ptime getstartTimeAndDate() const
      { return startTimeAndDate; }

      void setstartTimeAndDate(posix_time::ptime _time)
      { startTimeAndDate=_time; }

      posix_time::ptime getendTimeAndDate() const
      { return endTimeAndDate; }

      void setendTimeAndDate(posix_time::ptime _time)
      { endTimeAndDate=_time; }

      std::string getrunway() const
      { return runway; }

      void setrunway(std::string _runway)
      { runway= _runway; }

      LpiClosureReason::LpiEnum getReason() const
      { return reason; }

      void setReason(const LpiClosureReason::LpiEnum & newReason)
      { reason = newReason; }

   private:

      posix_time::ptime  startTimeAndDate;
      posix_time::ptime  endTimeAndDate;
      std::string        runway;
      LpiClosureReason::LpiEnum reason;
};


typedef std::vector<RunwaysNonPeriods> RunwaysNonPeriodsList;
class LpiCapacityReductions
{
   public:
      LpiCapacityReductions() {}
      ~LpiCapacityReductions() {}


      const CapacityReductionsRWYS & getcapacityReductionsRUNWY() const  { return capacityReductionsRUNWY;};
      void setcapacityReductionsRUNWY(const CapacityReductionsRWYS & _capacityReductionsRUNWY){capacityReductionsRUNWY=_capacityReductionsRUNWY;}; 

      const RunwaysNonPeriodsList & getnonAvailabilityRUNWY() const  { return nonAvailabilityRUNWY;};
      void setnonAvailabilityRUNWY(const RunwaysNonPeriodsList & _nonAvailabilityRUNWY){nonAvailabilityRUNWY=_nonAvailabilityRUNWY;}; 



   private:
      CapacityReductionsRWYS capacityReductionsRUNWY;
      RunwaysNonPeriodsList  nonAvailabilityRUNWY;
};
#endif  /*LPICAPACITYREDUCTIONS_H_*/

