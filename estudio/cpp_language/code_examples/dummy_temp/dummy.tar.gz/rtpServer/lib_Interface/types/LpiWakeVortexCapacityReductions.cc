/*
 * LpiGetWakeVortexCapacityReductions.cc
 *
 *  Created on: 23 ago. 2017
 *      Author: cgudin
 */

#include "LpiWakeVortexCapacityReductions.h"
#include "LpiCapacityReductions.h"

#include <boost/foreach.hpp>
#include <sstream>
#include <iostream>



//WakeVortex Conditions Internal Block

LpiWakeVortexConditions::LpiWakeVortexConditions()
: _maxValue(0.0),
  _minValue(1.0),
  _wtcType("")
{}


LpiWakeVortexConditions::LpiWakeVortexConditions(float maxValue,
                                       float minValue,
                                       string wtcType)
: _maxValue(maxValue),
  _minValue(minValue),
  _wtcType(wtcType)
{}


LpiWakeVortexConditions::LpiWakeVortexConditions(const LpiWakeVortexConditions & source)
: _maxValue(source._maxValue),
  _minValue(source._minValue),
  _wtcType(source._wtcType)
{}


LpiWakeVortexConditions & LpiWakeVortexConditions::operator= (const LpiWakeVortexConditions & source)
{
   if (this != &source)
   {
      _maxValue = source._maxValue;
      _maxValue = source._maxValue;
      _wtcType = source._wtcType;
   }

   return *this;
}

bool LpiWakeVortexConditions::operator== (const LpiWakeVortexConditions & source) const
{
    bool result = false;
    if (LcuDataTypeUtils::double_equals(_maxValue, source._maxValue) &&
        LcuDataTypeUtils::double_equals(_minValue, source._minValue) &&
        _wtcType == source._wtcType)
    {
        result = true;
    }
    return result;
}

bool LpiWTCReduction::operator== (const vector<LpiWakeVortexConditions> & source)
{
     bool result = false;
     if (_conditions == source)
     {
         result = true;
     }
     return result;
}


float LpiWakeVortexConditions::getMaxValue() const
{
   return _maxValue;
}


float LpiWakeVortexConditions::getMinValue() const
{
   return _minValue;
}


string LpiWakeVortexConditions::getWtcType() const
{
   return _wtcType;
}


ostream & operator<< (ostream & os, const LpiWakeVortexConditions & conditions)
{
   return os << "[MAX_VALUE: "   << conditions.getMaxValue()
             << " | MIN_VALUE: " << conditions.getMinValue()
             << " | WTC_TYPE: " << conditions.getWtcType() << "]";
}


// Individual file reduction: Meteo conditions block + composed key map


LpiWTCReduction::LpiWTCReduction()
: _conditions(),
  _reduction()
{
}


LpiWTCReduction::LpiWTCReduction(vector<LpiWakeVortexConditions> conditions, float reduction)
: _conditions(conditions),
  _reduction(reduction)
{
}


LpiWTCReduction::LpiWTCReduction(const LpiWTCReduction & source)
: _conditions(source._conditions),
  _reduction(source._reduction)
{}


LpiWTCReduction & LpiWTCReduction::operator= (const LpiWTCReduction & source)
{
   if (this != &source)
   {
      _conditions = source._conditions;
      _reduction = source._reduction;
   }

   return *this;
}


vector<LpiWakeVortexConditions> LpiWTCReduction::getWakeVortexConditions() const
{
   return _conditions;
}


float LpiWTCReduction::getReduction () const
{
   return _reduction;
}


ostream & operator<< (ostream & os, const LpiWTCReduction & reduction)
{
   std::stringstream out_stream;

   vector<LpiWakeVortexConditions> conditions = reduction.getWakeVortexConditions();
   out_stream << "Conditions:\n";
   for (unsigned int i=0; i < conditions.size(); i++)
   {
        out_stream << conditions[i] << '\n';
   }

   out_stream << "Reduction: " << reduction.getReduction() << "\n\n";

   return os << out_stream.str();
}


// File capacity reductions: Vector of -> Meteo conditions block + composed key map

LpiWakeVortexCapacityReductions::LpiWakeVortexCapacityReductions()
: _reductionsARR(),
  _reductionsDEP(),
  _reductionsOVA()
{
}


LpiWakeVortexCapacityReductions::LpiWakeVortexCapacityReductions(const LpiWakeVortexCapacityReductions & source)
: _reductionsARR(source._reductionsARR),
  _reductionsDEP(source._reductionsDEP),
  _reductionsOVA(source._reductionsOVA)
{
}


//Get reduction for ARRIVALS from WakeVortex Condition RS, and RWY
float LpiWakeVortexCapacityReductions::getReductionARR (const vector<LpiWakeVortexConditions> & conditionsARR) const
{
   float reductionARR = 0;

   for (unsigned int j= 0; j < _reductionsARR.size(); j++)
   {
       vector<LpiWakeVortexConditions> wvcondARR = _reductionsARR[j].getWakeVortexConditions();
       if ((wvcondARR[0] == conditionsARR[0]) && (wvcondARR[1] == conditionsARR[1]) && (wvcondARR[2] == conditionsARR[2]) && (wvcondARR[3] == conditionsARR[3]))
       {
              reductionARR = _reductionsARR[j].getReduction();
       }
   }

   return reductionARR;
}

//Get reduction for DEPARTURES from WakeVortex Condition RS, and RWY
float LpiWakeVortexCapacityReductions::getReductionDEP (const vector<LpiWakeVortexConditions> & conditionsDEP) const
{
   float reductionDEP = 0;

   for (unsigned int j= 0; j < _reductionsDEP.size(); j++)
   {
       vector<LpiWakeVortexConditions> wvcondDEP = _reductionsDEP[j].getWakeVortexConditions();
       if ((wvcondDEP[0] == conditionsDEP[0]) && (wvcondDEP[1] == conditionsDEP[1]) && (wvcondDEP[2] == conditionsDEP[2]) && (wvcondDEP[3] == conditionsDEP[3]))
       {
              reductionDEP = _reductionsDEP[j].getReduction();
       }
   }

   return reductionDEP;
}

//Get reduction for OVERALL from WakeVortex Condition RS, and RWY
float LpiWakeVortexCapacityReductions::getReductionOVA (const vector<LpiWakeVortexConditions> & conditionsOVA) const
{
   float reductionOVA = 0;

   for (unsigned int j= 0; j < _reductionsOVA.size(); j++)
   {
       vector<LpiWakeVortexConditions> wvcondOVA = _reductionsOVA[j].getWakeVortexConditions();
       if ((wvcondOVA[0] == conditionsOVA[0]) && (wvcondOVA[1] == conditionsOVA[1]) && (wvcondOVA[2] == conditionsOVA[2]) && (wvcondOVA[3] == conditionsOVA[3]))
       {
              reductionOVA = _reductionsOVA[j].getReduction();
       }
   }

   return reductionOVA;
}

//Add rule to Wake Vortex Block and RS-RWY

void LpiWakeVortexCapacityReductions::addWTCReductionARR(const vector<LpiWakeVortexConditions> &condition_ARR,
                                                      const float & reduction)
{

      LpiWTCReduction wtcReduction(condition_ARR, reduction);
      _reductionsARR.push_back(wtcReduction);
}

void LpiWakeVortexCapacityReductions::addWTCReductionDEP(const vector<LpiWakeVortexConditions> &condition_DEP,
                                                      const float & reduction)
{

      LpiWTCReduction wtcReduction(condition_DEP, reduction);
      _reductionsDEP.push_back(wtcReduction);
}

void LpiWakeVortexCapacityReductions::addWTCReductionOVA(const vector<LpiWakeVortexConditions> &condition_OVA,
                                                      const float & reduction)
{

      LpiWTCReduction wtcReduction(condition_OVA, reduction);
      _reductionsOVA.push_back(wtcReduction);
}


vector<LpiWTCReduction> LpiWakeVortexCapacityReductions::getReductionsARR() const
{
   return _reductionsARR;
}

vector<LpiWTCReduction> LpiWakeVortexCapacityReductions::getReductionsDEP() const
{
   return _reductionsDEP;
}

vector<LpiWTCReduction> LpiWakeVortexCapacityReductions::getReductionsOVA() const
{
   return _reductionsOVA;
}


ostream & operator<< (ostream & os, const LpiWakeVortexCapacityReductions & reductions)
{
   std::stringstream out_stream;


   vector<LpiWTCReduction> reductionsARR = reductions.getReductionsARR();
   vector<LpiWTCReduction> reductionsDEP = reductions.getReductionsDEP();
   vector<LpiWTCReduction> reductionsOVA = reductions.getReductionsOVA();

   out_stream << "[WTC_REDs_ARR:\n";

   BOOST_FOREACH(const LpiWTCReduction & reduction_element, reductionsARR)
   {
      out_stream << reduction_element;
   }
   out_stream << "]\n";
   out_stream << "[WTC_REDs_DEP:\n";

   BOOST_FOREACH(const LpiWTCReduction & reduction_element, reductionsDEP)
   {
      out_stream << reduction_element;
   }
   out_stream << "]\n";
   out_stream << "[WTC_REDs_OVA:\n";

   BOOST_FOREACH(const LpiWTCReduction & reduction_element, reductionsOVA)
   {
      out_stream << reduction_element;
   }

   out_stream << "]";

   return os << out_stream.str() << std::endl;
}


