
#if !defined(__LPI_ADAP_PROHIB_CONSTANTS__) 
#define __LPI_ADAP_PROHIB_CONSTANTS__

/**@file LpiAdapProhibConstants.h

   @brief types & constants used in the management of the
   'prohibition' information related to the
   "FILENAME_DAORTP_ASSIGNMENT_PREFERENCE" adaption file.

   @warning Using this file to avoid multiple include directories in
   the user files.
 */

#include <utility>      // std::pair
#include <vector>
#include <string>

typedef std::pair<std::string, std::string> ProhibitionElement;
typedef std::vector<ProhibitionElement> ProhibitionElementList;


#endif // __LPI_ADAP_PROHIB_CONSTANTS__
