#ifndef LPICLOSURE_REASON_H_
#define LPICLOSURE_REASON_H_

#include <iostream>
#include <string>

class LpiClosureReason
{
   public:
      enum LpiEnum
      {
         E_NONE = 0,
         E_PLANNED_MAINTENANCE,
         E_PLANNED_SNOW_REMOVAL,
         E_PLANNED_RWY_INSPECTION,
         E_ACCIDENT,
         E_INCIDENT,
         E_MANUAL_OPEN_CROSSWIND,
         E_MANUAL_CLOSE_CROSSWIND,
         E_TECHNICAL_FAILURE_ILS,
         E_OTHER
      };
};


inline std::ostream & operator << (std::ostream &os,
                                   const LpiClosureReason::LpiEnum & obj)
{
   std::string reasonStrings[LpiClosureReason::E_OTHER + 1] = {
         "",
         "Planned maintenance",
         "Planned snow removal",
         "Planned runway inspection",
         "Accident",
         "Incident",
         "Manual open crosswind",
         "Manual close crosswind",
         "Technical failure ILS",
         "Other"
   };

   os << reasonStrings[obj];
   return os;
}


#endif
