
#include "LpiScheduleActivationType.h"


std::ostream& operator <<(std::ostream &os,
                          const LpiScheduleActivationType::LpiEnum &obj)
{
   switch (obj)
   {
   case LpiScheduleActivationType::E_AUTO:
      os << "AUTO";
      break;

   case LpiScheduleActivationType::E_MANUAL:
      os << "MANUAL";
      break;

   default:
      os << "UNKNOWN";
      break;
   }
   return os;
}
