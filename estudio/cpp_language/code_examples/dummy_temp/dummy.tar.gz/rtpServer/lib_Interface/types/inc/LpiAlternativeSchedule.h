#if !defined(__LPI_ALTERNATIVE_SCHEDULE__)
#define __LPI_ALTERNATIVE_SCHEDULE__

#include "LpiActiveSchedule.h"

typedef LpiActiveSchedule LpiAlternativeSchedule;

#endif // __LPI_ALTERNATIVE_SCHEDULE__
