/*
 * LpiComposedKey.cc
 *
 *  Created on: 18/02/2014
 *      Author: mbegega
 */

#include "LpiComposedKey.h"


template <typename K1, typename K2>
ostream & operator<< (ostream & out, const LpiComposedKeyPair<K1, K2> & key)
{
   return out << key._pair_key1  << " "
              << key._pair_key2;
}


template <typename K1, typename K2, typename K3>
ostream & operator<< (ostream & out, const LpiComposedKey<K1, K2, K3> & key)
{
   return out << key._characteristic_name  << " "
              << key._characteristic_value << " "
              << key._element;
}

