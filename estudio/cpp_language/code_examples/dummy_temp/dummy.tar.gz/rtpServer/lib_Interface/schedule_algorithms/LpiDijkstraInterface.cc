/*
 * LpiDijkstraInterface.cc
 *
 */

#include <iostream>

#include "LpiDijkstraInterface.h"

#include <sys/types.h>
#include <LcpfFacade.h>


//------------------------------------------------------------------------------

int LpiDijkstraInterface::processRSScheduleRequest
(const std::vector<RSNode> &nodes,
 const std::vector<RSTransitionSegment> &segments,
 const RSScheduleRequest &request,
 std::vector<RSScheduleResponse> &response) const
{
  
  std::vector<path_finding::TypeUserEdgeData> remote_edges;
  for(std::vector<RSTransitionSegment>::const_iterator citr = 
	segments.begin();
      citr != segments.end();
      ++citr)
  {
    remote_edges.push_back(path_finding::TypeUserEdgeData
			   (citr->originRSNode_, 
			    citr->destinationRSNode_, 
			    citr->weight_, 
			    citr->id_));
  }

  /*path_finding::PathfindingSolutionData solution =
    path_finding::dijkstra_shortest_path_directed_graph(
    request.start_node_id_,
     request.end_node_id_,
     remote_edges);*/

  //convert_response(solution, response);
  return 0;
}

//------------------------------------------------------------------------------

void LpiDijkstraInterface::convert_response
(const path_finding::PathfindingSolutionData &src_value,
 std::vector<RSScheduleResponse> &response) const
{
  
    response.clear();

    RSScheduleResponse new_sche;
    new_sche.id_ = "";
    for(std::list<path_finding::UserVertexId>::const_iterator citr =
    src_value.the_path.begin();
    citr != src_value.the_path.end();
    ++citr)
    {
    new_sche.nodes_.push_back(static_cast<std::string>(*citr));
    }

    /// @todo no edges id info in the current version of the Dijkstra algorithm
    // std::vector<std::string> segments_;  
    // new_sche.segments_;  


    response.push_back(new_sche);    
  
}

//------------------------------------------------------------------------------
