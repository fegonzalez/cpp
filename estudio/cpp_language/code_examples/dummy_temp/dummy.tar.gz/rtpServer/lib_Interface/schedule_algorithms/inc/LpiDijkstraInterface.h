/*
 * LpiDijkstraInterface.h
 *
 */

#ifndef __LPIDIJKSTRA_INTERFACE_H__

#define __LPIDIJKSTRA_INTERFACE_H__


#include <vector>
#include "LpiMessages.h"


namespace path_finding {
  struct PathfindingSolutionData; //forward declaration
}

class LpiDijkstraInterface
{
 public:

  explicit LpiDijkstraInterface(){};
  ~LpiDijkstraInterface(){};
 
  int processRSScheduleRequest
    (const std::vector<RSNode> &nodes,
     const std::vector<RSTransitionSegment> &segments,
     const RSScheduleRequest &request,
     std::vector<RSScheduleResponse> &response) const;

 private:

  explicit LpiDijkstraInterface(const LpiDijkstraInterface&);
  LpiDijkstraInterface& operator=(const LpiDijkstraInterface&);

  void convert_response
    (const path_finding::PathfindingSolutionData &src_value,
     std::vector<RSScheduleResponse> &response)const;
};

#endif /* __LPIDIJKSTRA_INTERFACE_H__ */
