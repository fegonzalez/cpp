// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 12:57:41 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETADAPTATIONALERT_KPISREQUEST_H_
#define LPIGETADAPTATIONALERT_KPISREQUEST_H_


#include "LpiAdaptationAlert_KPIs.h"

class LpiGetAdaptationAlert_KPIsRequest
{
public:
   // getters
   const LpiAdaptationAlert_KPIs& getAdaptationAlert_KPIs(void) const {return this->_adaptationAlert_KPIs;}

   // setters
   void setAdaptationAlert_KPIs(const LpiAdaptationAlert_KPIs &adaptationAlert_KPIs)
      {this->_adaptationAlert_KPIs = adaptationAlert_KPIs;}

private:
   LpiAdaptationAlert_KPIs _adaptationAlert_KPIs;
};


#endif /* LPIGETCONFIGURATIONALERT_KPISREQUEST_H_ */
