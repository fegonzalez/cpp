// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 25 Jun 09:00:01 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETCONFIGURATIONCOREPARAMETERSREQUEST_H_
#define LPIGETCONFIGURATIONCOREPARAMETERSREQUEST_H_


#include "LpiConfigurationCoreParameters.h"

class LpiGetConfigurationCoreParametersRequest
{
public:
   // getters
   const LpiConfigurationCoreParameters& getConfigurationCoreParameters(void) const {return this->_configurationCoreParameters;}

   // setters
   void setConfigurationCoreParameters(const LpiConfigurationCoreParameters &configurationCoreParameters)
      {this->_configurationCoreParameters = configurationCoreParameters;}

private:
   LpiConfigurationCoreParameters _configurationCoreParameters;
};


#endif /* LPIGETCONFIGURATIONCOREPARAMETERSREQUEST_H_ */
