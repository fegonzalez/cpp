#if !defined(__LPIGETSYSTEMTIMEREQUEST__)
#define __LPIGETSYSTEMTIMEREQUEST__

class LpiGetSystemTimeRequest
{
public:
private:
};

#endif // __LPIGETSYSTEMTIMEREQUEST__
