
#ifndef LPIGETCONFIGURATIONCONSTRAINTSREQUEST_H_
#define LPIGETCONFIGURATIONCONSTRAINTSREQUEST_H_

#include "LpiConfigurationConstraints.h"

class LpiGetConfigurationConstraintsRequest
{
public:
   // getters
   const LpiConfigurationConstraints& getConfigurationConstraints(void) const {return this->_configurationConstraints;}

   // setters
   void setConfigurationConstraints(const LpiConfigurationConstraints &configurationConstraints)
      {this->_configurationConstraints = configurationConstraints;}

private:
   LpiConfigurationConstraints _configurationConstraints;
};


#endif /* LPIGETCONFIGURATIONCONSTRAINTSREQUEST_H_ */
