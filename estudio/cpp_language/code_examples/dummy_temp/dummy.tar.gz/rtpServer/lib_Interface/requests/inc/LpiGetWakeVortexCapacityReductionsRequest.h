/*
 * LpiWakeVortexCapacityReductionsRequest.h
 *
 *  Created on: 23 ago. 2017
 *      Author: cgudin
 */

#ifndef C___LPIWAKEVORTEXCAPACITYREDUCTIONSREQUEST_H_
#define C___LPIWAKEVORTEXCAPACITYREDUCTIONSREQUEST_H_

#include "LpiWakeVortexCapacityReductions.h"

class LpiGetWakeVortexCapacityReductionsRequest
{
public:
   // getters
   const LpiWakeVortexCapacityReductions& getWakeVortexCapacityReductions(void) const {return this->_capacity;}

   // setters
   void setWakeVortexCapacityReductions(const LpiWakeVortexCapacityReductions &configurationParameters)
      {this->_capacity = configurationParameters;}

private:
   LpiWakeVortexCapacityReductions _capacity;
};


#endif /* C___LPIWAKEVORTEXCAPACITYREDUCTIONSREQUEST_H_ */
