// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Mon 25 Jun 13:56:24 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETADAPTATIONAIRPORTSINFOREQUEST_H_
#define LPIGETADAPTATIONAIRPORTSINFOREQUEST_H_


#include "LpiAdaptationAirportsInfo.h"

class LpiGetAdaptationAirportsInfoRequest
{
public:
   // getters
   const LpiAdaptationAirportsInfo& getAdaptationAirportsInfo(void) const {return this->_airportsInfo;}

   // setters
   void setAdaptationAirportsInfo(const LpiAdaptationAirportsInfo &airportsInfo)
      {this->_airportsInfo = airportsInfo;}

private:
   LpiAdaptationAirportsInfo _airportsInfo;
};



#endif /* LPIGETADAPTATIONAIRPORTSINFOREQUEST_H_ */
