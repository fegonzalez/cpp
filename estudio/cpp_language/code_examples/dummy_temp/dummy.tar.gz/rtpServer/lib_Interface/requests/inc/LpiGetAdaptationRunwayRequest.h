
#ifndef LPIGETADAPTATIONRUNWAYREQUEST_H_
#define LPIGETADAPTATIONRUNWAYREQUEST_H_

#include "LpiAdaptationRunway.h"

class LpiGetAdaptationRunwayRequest
{
public:
   // getters
   const LpiAdaptationRunway& getAdaptationRunway(void) const {return this->_adaptationRunway;}

   // setters
   void setAdaptationRunway(const LpiAdaptationRunway &configurationParameters)
      {this->_adaptationRunway = configurationParameters;}

private:
   LpiAdaptationRunway _adaptationRunway;
};


#endif /* LPIGETADAPTATIONRUNWAYREQUEST_H_ */
