// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 16:06:46 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETCONFIGURATIONHMIPARAMETERSREQUEST_H_
#define LPIGETCONFIGURATIONHMIPARAMETERSREQUEST_H_


#include "LpiConfigurationHmiParameters.h"

class LpiGetConfigurationHmiParametersRequest
{
public:
   // getters
   const LpiConfigurationHmiParameters& getConfigurationHmiParameters(void) const {return this->_configurationHmiParameters;}

   // setters
   void setConfigurationHmiParameters(const LpiConfigurationHmiParameters &configurationHmiParameters)
      {this->_configurationHmiParameters = configurationHmiParameters;}

private:
   LpiConfigurationHmiParameters _configurationHmiParameters;
};



#endif /* LPIGETCONFIGURATIONHMIPARAMETERSREQUEST_H_ */
