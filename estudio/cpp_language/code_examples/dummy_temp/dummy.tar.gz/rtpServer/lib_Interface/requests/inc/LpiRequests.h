#if !defined(__LPI_REQUESTS__)
#define __LPI_REQUESTS__

#include "LpiGetSystemTimeRequest.h"
#include "LpiGetAdaptationAlert_KPIsRequest.h"
#include "LpiGetConfigurationCoreParametersRequest.h"
#include "LpiGetConfigurationHmiParametersRequest.h"
#include "LpiGetAdaptationRunwayRequest.h"
#include "LpiGetAdaptationRunwaySystemRequest.h"
#include "LpiGetAdaptationAirportsInfoRequest.h"

#include "LpiGetWakeVortexCapacityReductionsRequest.h"

#endif // __LPI_REQUESTS__
