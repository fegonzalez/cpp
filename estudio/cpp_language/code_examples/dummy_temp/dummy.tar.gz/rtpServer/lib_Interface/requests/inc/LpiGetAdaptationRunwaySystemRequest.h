
#ifndef LPIGETADAPTATIONRUNWAYSYSTEMREQUEST_H_
#define LPIGETADAPTATIONRUNWAYSYSTEMREQUEST_H_

#include "LpiAdaptationRunwaySystem.h"

class LpiGetAdaptationRunwaySystemRequest
{
public:
   // getters
   const LpiAdaptationRunwaySystem& getAdaptationRunwaySystem(void) const {return this->_adaptationRunwaySystem;}

   // setters
   void setAdaptationRunwaySystem(const LpiAdaptationRunwaySystem &runwaySystem)
      {this->_adaptationRunwaySystem = runwaySystem;}

private:
   LpiAdaptationRunwaySystem _adaptationRunwaySystem;
};


#endif /* LPIGETADAPTATIONRUNWAYSYSTEMREQUEST_H_ */
