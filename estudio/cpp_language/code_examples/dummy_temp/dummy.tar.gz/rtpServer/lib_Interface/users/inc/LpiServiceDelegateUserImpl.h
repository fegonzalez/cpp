#if !defined(__LPI_SERVICE_DELEGATE_USER_IMPL__)
#define __LPI_SERVICE_DELEGATE_USER_IMPL__

#include "LpiIServiceUser.h"
#include "LpiIDelegateUser.h"
#include <iostream>

template<typename TRequest, typename TReply>
class LpiServiceDelegateUserImpl : public LpiIServiceUser<TRequest, TReply>,
                                   public LpiIDelegateUser<LpiIServiceUser<TRequest, TReply> >
{
public:
   LpiServiceDelegateUserImpl() {}
   virtual ~LpiServiceDelegateUserImpl() {}

   virtual void delegateUser(LpiIServiceUser<TRequest, TReply> &user)
   {
      this->_pUser = &user;
   }

   virtual void use(const TRequest &request, TReply &reply)
   {
      this->_pUser->use(request, reply);
   }

private:
   LpiIServiceUser<TRequest, TReply>* _pUser;
};


template<typename TReply>
class LpiReplyServiceDelegateUserImpl : public LpiIReplyServiceUser<TReply>,
                                        public LpiIDelegateUser<LpiIReplyServiceUser<TReply> >
{
   public:

      LpiReplyServiceDelegateUserImpl() {}
      virtual ~LpiReplyServiceDelegateUserImpl() {}

      virtual void delegateUser(LpiIReplyServiceUser<TReply> &user)
      {
         this->_pUser = &user;
      }

      virtual void use(TReply &reply)
      {
         this->_pUser->use(reply);
      }

   private:

      LpiIReplyServiceUser<TReply>* _pUser;
};


#endif // __LPI_SERVICE_DELEGATE_USER_IMPL__
