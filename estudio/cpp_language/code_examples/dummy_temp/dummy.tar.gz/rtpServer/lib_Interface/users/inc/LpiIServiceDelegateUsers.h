#if !defined(__LPI_I_SERVICE_DELEGATE_USERS__)
#define __LPI_I_SERVICE_DELEGATE_USERS__

#include "LpiIServiceDelegateUser.h"
#include "LpiRequests.h"
#include "LpiReplies.h"


typedef LpiIServiceDelegateUser<
   LpiGetSystemTimeRequest,
   LpiGetSystemTimeReply
> LpiIGetSystemTimeSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
    LpiGetAdaptationAlert_KPIsReply
> LpiIGetAdaptationAlert_KPIsSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
    LpiGetConfigurationCoreParametersReply
> LpiIGetConfigurationCoreParametersSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
    LpiGetConfigurationHmiParametersReply
> LpiIGetConfigurationHmiParametersSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
		LpiGetAdaptationAirportsInfoReply
>LpiIGetAdaptationAirportsInfoSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
        LpiGetAdaptationMrtmInfoReply
>LpiIGetAdaptationMrtmInfoSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
        LpiGetAdaptationAssignmentPreferenceReply
>LpiIGetAdaptationAssignmentPreferenceSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
   LpiGetAdaptationRunwayReply
>LpiIGetAdaptationRunwaySrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
   LpiGetAdaptationRunwaySystemReply
>LpiIGetAdaptationRunwaySystemSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
    LpiGetPriorityReply
> LpiIGetPriorityTableSrvDelegateUser;

typedef LpiIReplyServiceDelegateUser<
   LpiGetWakeVortexCapacityReductionsReply
> LpiIGetWakeVortexCapacityReductionsSrvDelegateUser;

#endif // __LPI_I_SERVICE_DELEGATE_USERS__
