#if !defined(__LPI_I_SERVICE_USER__)
#define __LPI_I_SERVICE_USER__

#include <iostream>

template<typename TRequest, typename TReply>
class LpiIServiceUser
{
public:
   LpiIServiceUser() { }
   virtual ~LpiIServiceUser() {}

   virtual void use(const TRequest& request, TReply &reply) = 0;
};


template<typename TReply>
class LpiIReplyServiceUser
{
   public:
   LpiIReplyServiceUser() { }
   virtual ~LpiIReplyServiceUser() {}

   virtual void use(TReply &reply) = 0;
};


#endif // __LPI_I_SERVICE_USER__
