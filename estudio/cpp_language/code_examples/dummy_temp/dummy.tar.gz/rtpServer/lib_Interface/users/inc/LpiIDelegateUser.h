#if !defined(__LPI_I_DELEGATE_USER__)
#define __LPI_I_DELEGATE_USER__

template<typename TDelegate>
class LpiIDelegateUser
{
public:
   LpiIDelegateUser() {}
   virtual ~LpiIDelegateUser() {}
   virtual void delegateUser(TDelegate &data) = 0;
};

#endif // __LPI_I_DELEGATE_USER__
