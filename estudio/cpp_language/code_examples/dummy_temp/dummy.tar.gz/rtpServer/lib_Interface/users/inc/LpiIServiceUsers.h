#if !defined(__LPI_I_SERVICE_USERS__)
#define __LPI_I_SERVICE_USERS__

#include "LpiIServiceUser.h"
#include "LpiRequests.h"
#include "LpiReplies.h"

typedef LpiIReplyServiceUser<
   LpiGetAdaptationAlert_KPIsReply
> LpiIGetAdaptationAlert_KPIsSrvUser;

typedef LpiIReplyServiceUser<
   LpiGetConfigurationCoreParametersReply
> LpiIGetConfigurationCoreParametersSrvUser;

typedef LpiIReplyServiceUser<
   LpiGetConfigurationHmiParametersReply
> LpiIGetConfigurationHmiParametersSrvUser;

typedef LpiIServiceUser<
   LpiGetSystemTimeRequest,
   LpiGetSystemTimeReply
> LpiIGetSystemTimeSrvUser;


typedef LpiIReplyServiceUser<
   LpiGetAdaptationAirportsInfoReply
>LpiIGetAdaptationAirportsInfoSrvUser;

typedef LpiIReplyServiceUser<
   LpiGetAdaptationMrtmInfoReply
>LpiIGetAdaptationMrtmInfoSrvUser;

typedef LpiIReplyServiceUser<
   LpiGetAdaptationAssignmentPreferenceReply
>LpiIGetAdaptationAssignmentPreferenceSrvUser;


typedef LpiIReplyServiceUser<
   LpiGetAdaptationRunwayReply
>LpiIGetAdaptationRunwaySrvUser;

typedef LpiIReplyServiceUser<
   LpiGetAdaptationRunwaySystemReply
>LpiIGetAdaptationRunwaySystemSrvUser;

typedef LpiIReplyServiceUser<
   LpiGetPriorityReply
>LpiIGetPriorityTableSrvUser;

typedef LpiIReplyServiceUser<
   LpiGetWakeVortexCapacityReductionsReply
>LpiIGetWakeVortexCapacityReductionsSrvUser;

#endif // __LPI_I_SERVICE_USERS__
