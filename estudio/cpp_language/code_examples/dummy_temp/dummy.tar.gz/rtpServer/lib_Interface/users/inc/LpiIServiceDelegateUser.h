#if !defined(__LPI_I_SERVICE_DELEGATE_USER__)
#define __LPI_I_SERVICE_DELEGATE_USER__

#include "LpiIServiceUser.h"
#include "LpiIDelegateUser.h"

template<typename TRequest, typename TReply>
class LpiIServiceDelegateUser : public LpiIServiceUser<TRequest, TReply>,
                                public LpiIDelegateUser<LpiIServiceUser<TRequest, TReply> >
{
public:
   LpiIServiceDelegateUser() {}
   virtual ~LpiIServiceDelegateUser() {}
   virtual void delegateUser(LpiIServiceUser<TRequest, TReply> &data) = 0;
   virtual void use(const TRequest& request, TReply &reply) = 0;
};


template<typename TReply>
class LpiIReplyServiceDelegateUser : public LpiIReplyServiceUser<TReply>,
                                     public LpiIDelegateUser<LpiIReplyServiceUser<TReply> >
{
   public:

      LpiIReplyServiceDelegateUser() {}
      virtual ~LpiIReplyServiceDelegateUser() {}
      virtual void delegateUser(LpiIReplyServiceUser<TReply> &data) = 0;
      virtual void use(TReply &reply) = 0;
};

#endif // __LPI_I_SERVICE_DELEGATE_USER__
