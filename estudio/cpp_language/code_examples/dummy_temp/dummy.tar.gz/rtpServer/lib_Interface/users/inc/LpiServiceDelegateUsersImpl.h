#if !defined(__LPI_SERVICE_DELEGATE_USERS_IMPL__)
#define __LPI_SERVICE_DELEGATE_USERS_IMPL__

#include "LpiServiceDelegateUserImpl.h"
#include "LpiRequests.h"
#include "LpiReplies.h"


typedef LpiServiceDelegateUserImpl<
   LpiGetSystemTimeRequest,
   LpiGetSystemTimeReply
> LpiGetSystemTimeSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAdaptationAlert_KPIsReply
> LpiGetAdaptationAlert_KPIsSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetConfigurationCoreParametersReply
> LpiGetConfigurationCoreParametersSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetConfigurationHmiParametersReply
> LpiGetConfigurationHmiParametersSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAdaptationAirportsInfoReply
>LpiGetAdaptationAirportsInfoSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAdaptationMrtmInfoReply
>LpiGetAdaptationMrtmInfoSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAdaptationAssignmentPreferenceReply
>LpiGetAdaptationAssignmentPreferenceSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAdaptationRunwayReply
>LpiGetAdaptationRunwaySrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetAdaptationRunwaySystemReply
>LpiGetAdaptationRunwaySystemSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetPriorityReply
>LpiGetPriorityTableSrvDelegateUser;

typedef LpiReplyServiceDelegateUserImpl<
   LpiGetWakeVortexCapacityReductionsReply
>LpiGetWakeVortexCapacityReductionsSrvDelegateUser;

#endif // __LPI_SERVICE_DELEGATE_USERS_IMPL__
