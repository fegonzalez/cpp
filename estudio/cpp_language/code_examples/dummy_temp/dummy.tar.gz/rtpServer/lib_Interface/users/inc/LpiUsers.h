#if !defined(__LPI_USERS__)
#define __LPI_USERS__

#include "LpiIServiceUsers.h"
#include "LpiIServiceDelegateUsers.h"
#include "LpiServiceDelegateUsersImpl.h"

#endif // __LPI_USERS__

