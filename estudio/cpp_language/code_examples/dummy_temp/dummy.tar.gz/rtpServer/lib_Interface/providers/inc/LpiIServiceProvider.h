#if !defined(__LPI_I_SERVICE_PROVIDER__)
#define __LPI_I_SERVICE_PROVIDER__

template<typename TRequest, typename TReply>
class LpiIServiceProvider
{
public:
   LpiIServiceProvider() {}
   virtual ~LpiIServiceProvider() {}
   virtual void provide(const TRequest& request, TReply &reply) = 0;
};

#endif // __LPI_I_SERVICE_PROVIDER__
