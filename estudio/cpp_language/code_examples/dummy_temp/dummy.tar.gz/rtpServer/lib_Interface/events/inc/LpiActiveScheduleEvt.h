#ifndef __LPI_ACTIVE_SCHEDULE_EVT__
#define __LPI_ACTIVE_SCHEDULE_EVT__

#include <LpiActiveSchedule.h>

class LpiActiveScheduleEvt
{
   public:

      const LpiActiveSchedule& getActiveSchedule(void) const
      { return this->activeSchedule; }


      void setActiveSchedule(const LpiActiveSchedule &_activeSchedule)
      { this->activeSchedule= _activeSchedule; }

   private:

      LpiActiveSchedule activeSchedule;
};


#endif //__LPI_ACTIVE_SCHEDULE_EVT__
