#if !defined(__LPI_EVENTS_H__)
#define __LPI_EVENTS_H__

#include "LpiUpdateSystemTimeEvt.h"
#include "LpiCreateDemandEvt.h"
#include "LpiUpdateDemandEvt.h"
#include "LpiMeteoForecastEvt.h"
#include "LpiMeteoNowcastEvt.h"
#include "LpiCapacityReductionsEvt.h"
#include "LpiOptimalScheduleEvt.h"
#include "LpiOptimalCriteriaEvt.h"
#include "LpiOptimizationCriteriaEvt.h"
#include "LpiScheduleActivationEvt.h"
#include "LpiActiveScheduleEvt.h"
#include "LpiManualEditionEvt.h"
#include "LpiScheduleDeleteEvt.h"
#include "LpiAlternativeScheduleEvt.h"
#include "LpiSchedulesComparisonEvt.h"
#include "LpiWhatIfRunwayClosureEvt.h"
#include "LpiAutomaticDeletionEvt.h"

#endif // __LPI_EVENTS_H__
