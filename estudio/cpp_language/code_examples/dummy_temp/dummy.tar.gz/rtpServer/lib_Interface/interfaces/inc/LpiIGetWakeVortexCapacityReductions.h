/*
 * LpiIGetWakeVortexCapacityReductions.h
 *
 *  Created on: 24 ago. 2017
 *      Author: cgudin
 */

#ifndef C___LPIIGETWAKEVORTEXCAPACITYREDUCTIONS_H_
#define C___LPIIGETWAKEVORTEXCAPACITYREDUCTIONS_H_

#include "LpiWakeVortexCapacityReductions.h"
#include "LpiResult.h"

class LpiIGetWakeVortexCapacityReductions
{
public:
   virtual ~LpiIGetWakeVortexCapacityReductions() {}
   virtual void getWakeVortexCapacityReductions(
                               LpiWakeVortexCapacityReductions &runways,
                                          LpiResult        &result) = 0;
};


#endif /* C___LPIIGETWAKEVORTEXCAPACITYREDUCTIONS_H_ */
