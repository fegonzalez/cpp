#if !defined(__LPI_I_LIFE_CYCLE_H__)
#define __LPI_I_LIFE_CYCLE_H__

class LpiILifeCycle
{
public:
   LpiILifeCycle() {}
   virtual ~LpiILifeCycle() {}

   virtual void create(void) = 0;
   virtual void initialise(void) = 0;
   virtual void complete(void) = 0;
};

#endif // __LPI_I_LIFE_CYCLE_H__
