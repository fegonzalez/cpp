#if !defined(__LPI_I_FORWARD_TIMELINE_H__)
#define __LPI_I_FORWARD_TIMELINE_H__

class LpiIForwardTimeline
{
public:
   LpiIForwardTimeline() {}
   virtual ~LpiIForwardTimeline() {}

   virtual void forwardTimeline(void) = 0;

};

#endif // __LPI_I_FORWARD_TIMELINE_H__
