#if !defined(__LPIGETSYSTEMTIMEREPLY__)
#define __LPIGETSYSTEMTIMEREPLY__

#include <LpiTime.h>
#include <LpiResult.h>

class LpiGetSystemTimeReply
{
public:
   // getters
   const LpiTime& getTime(void) const {return this->_time;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setTime(const LpiTime &value) {this->_time = value;}
   void setResult(const LpiResult::LpiEnum &value) {this->_result = value;}

private:
   LpiTime     _time;
   LpiResult::LpiEnum   _result;
};

#endif // __LXIGETSYSTEMTIMEREPLY__
