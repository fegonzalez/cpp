/*
 * LpiGetWakeVortexCapacityReductionsReply.h
 *
 *  Created on: 23 ago. 2017
 *      Author: cgudin
 */

#ifndef C___LPIGETWAKEVORTEXCAPACITYREDUCTIONSREPLY_H_
#define C___LPIGETWAKEVORTEXCAPACITYREDUCTIONSREPLY_H_

#include <LpiWakeVortexCapacityReductions.h>
#include <LpiResult.h>


class LpiGetWakeVortexCapacityReductionsReply
{
public:
   // getters
   const LpiWakeVortexCapacityReductions & getWakeVortexCapacityReductions(void) const {return this->_capacityReduction;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setWakeVortexCapacityReductions(const LpiWakeVortexCapacityReductions &value) {this->_capacityReduction = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiWakeVortexCapacityReductions    _capacityReduction;
   LpiResult::LpiEnum            _result;
};


#endif /* C___LPIGETWAKEVORTEXCAPACITYREDUCTIONSREPLY_H_ */
