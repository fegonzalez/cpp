
#ifndef LPIGETADAPTATIONAIRPORSTINFOREPLY_H_
#define LPIGETADAPTATIONAIRPORSTINFOREPLY_H_

#include <LpiAdaptationAirportsInfo.h>
#include <LpiResult.h>


class LpiGetAdaptationAirportsInfoReply
{
public:
   // getters
   const LpiAdaptationAirportsInfo & getAdaptationAirportsInfo(void) const {return this->_airportsInfo;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setAdaptationAirportsInfo(const LpiAdaptationAirportsInfo &value) {this->_airportsInfo = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiAdaptationAirportsInfo    _airportsInfo;
   LpiResult::LpiEnum            _result;
};


#endif /* LPIGETADAPTATIONAIRPORTSINFOREPLY_H_ */
