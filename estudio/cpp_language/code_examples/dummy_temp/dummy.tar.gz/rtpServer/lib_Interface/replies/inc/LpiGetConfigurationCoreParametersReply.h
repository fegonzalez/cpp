// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 14:28:41 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETCONFIGURATIONCOREPARAMETERSREPLY_H_
#define LPIGETCONFIGURATIONCOREPARAMETERSREPLY_H_


#include <LpiConfigurationCoreParameters.h>
#include <LpiResult.h>


class LpiGetConfigurationCoreParametersReply
{
public:
   // getters
   const LpiConfigurationCoreParameters & getConfigurationCoreParameters(void) const {return this->_configurationCoreParameters;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setConfigurationCoreParameters(const LpiConfigurationCoreParameters &value) {this->_configurationCoreParameters = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiConfigurationCoreParameters    _configurationCoreParameters;
   LpiResult::LpiEnum            _result;
};


#endif /* LPIGETCONFIGURATIONCOREPARAMETERSREPLY_H_ */
