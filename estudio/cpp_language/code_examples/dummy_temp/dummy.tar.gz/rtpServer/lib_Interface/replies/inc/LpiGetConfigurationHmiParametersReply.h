// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 28 Jun 16:01:36 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETCONFIGURATIONHMIPARAMETERSREPLY_H_
#define LPIGETCONFIGURATIONHMIPARAMETERSREPLY_H_


#include <LpiConfigurationHmiParameters.h>
#include <LpiResult.h>


class LpiGetConfigurationHmiParametersReply
{
public:
   // getters
   const LpiConfigurationHmiParameters & getConfigurationHmiParameters(void) const {return this->_configurationHmiParameters;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setConfigurationHmiParameters(const LpiConfigurationHmiParameters &value) {this->_configurationHmiParameters = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiConfigurationHmiParameters    _configurationHmiParameters;
   LpiResult::LpiEnum            _result;
};



#endif /* LPIGETCONFIGURATIONHMIPARAMETERSREPLY_H_ */
