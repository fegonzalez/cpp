// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Thu 21 Jun 10:03:31 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETADAPTATIONASSIGNMENTPREFERENCEREPLY_H_
#define LPIGETADAPTATIONASSIGNMENTPREFERENCEREPLY_H_

#include <LpiAdaptationAssignmentPreference.h>
#include <LpiResult.h>


class LpiGetAdaptationAssignmentPreferenceReply
{
public:
   // getters
   const LpiAdaptationAssignmentPreference & getAdaptationAssignmentPreference(void) const {return this->_ap;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setAdaptationAssignmentPreference(const LpiAdaptationAssignmentPreference &value) {this->_ap = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiAdaptationAssignmentPreference       _ap;
   LpiResult::LpiEnum           _result;
};


#endif /* LPIGETADAPTATIONASSIGNMENTPREFERENCEREPLY_H_ */
