
#ifndef __LPI_PRIORITY_REPLY_H__
#define __LPI_PRIORITY_REPLY_H__

#include "LpiPriorityTable.h"
#include "LpiResult.h"

class LpiGetPriorityReply
{
   public:

      const LpiPriorityTable & getPriorityTableDepartures () const
      { return r_priorityTableDepartures; }

      const LpiPriorityTable & getPriorityTableArrivals () const
      { return r_priorityTableArrivals; }


      const LpiResult::LpiEnum & getResult () const
      { return r_result; }


      void setPriorityTableDepartures (const LpiPriorityTable & priorities)
      { r_priorityTableDepartures = priorities;}

      void setPriorityTableArrivals (const LpiPriorityTable & priorities)
      { r_priorityTableArrivals = priorities;}

      void setResult(const LpiResult::LpiEnum & result)
      { r_result = result; }

   private:

      LpiPriorityTable     r_priorityTableDepartures;
      LpiPriorityTable     r_priorityTableArrivals;
      LpiResult::LpiEnum   r_result;
};


#endif /* __LPI_PRIORITY_REPLY_H__ */
