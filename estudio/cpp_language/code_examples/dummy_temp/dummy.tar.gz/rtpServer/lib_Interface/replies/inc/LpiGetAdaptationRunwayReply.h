
#ifndef LPIGETADAPTATIONRUNWAYREPLY_H_
#define LPIGETADAPTATIONRUNWAYREPLY_H_

#include <LpiAdaptationRunway.h>
#include <LpiResult.h>


class LpiGetAdaptationRunwayReply
{
public:
   // getters
   const LpiAdaptationRunwayList & getAdaptationRunway(void) const {return this->_runway;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setAdaptationRunway(const LpiAdaptationRunwayList &value) {this->_runway = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiAdaptationRunwayList      _runway;
   LpiResult::LpiEnum           _result;
};


#endif /* LPIGETADAPTATIONRUNWAYREPLY_H_ */
