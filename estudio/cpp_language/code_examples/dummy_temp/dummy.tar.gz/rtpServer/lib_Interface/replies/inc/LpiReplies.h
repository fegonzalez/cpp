#if !defined(__LPI_REPLIES__)
#define __LPI_REPLIES__


#include "LpiGetAdaptationAirportsInfoReply.h"
#include "LpiGetAdaptationMrtmInfoReply.h"
#include "LpiGetAdaptationAssignmentPreferenceReply.h"

#include "LpiGetSystemTimeReply.h"
#include "LpiGetAdaptationAlert_KPIsReply.h"
#include "LpiGetConfigurationCoreParametersReply.h"
#include "LpiGetConfigurationHmiParametersReply.h"
#include "LpiGetAdaptationRunwayReply.h"
#include "LpiGetAdaptationRunwaySystemReply.h"
#include "LpiGetAdaptationAirportsInfoReply.h"
#include "LpiGetPriorityReply.h"

#include "LpiGetWakeVortexCapacityReductionsReply.h"

#endif // __LPI_REPLIES__
