
#ifndef LPIGETADAPTATIONRUNWAYSYSTEMREPLY_H_
#define LPIGETADAPTATIONRUNWAYSYSTEMREPLY_H_

#include <LpiAdaptationRunwaySystem.h>
#include <LpiResult.h>


class LpiGetAdaptationRunwaySystemReply
{
public:
   // getters
   const LpiAdaptationRunwaySystemList & getAdaptationRunwaySystem(void) const {return this->_runwaySystem;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setAdaptationRunwaySystem(const LpiAdaptationRunwaySystemList &value) {this->_runwaySystem = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiAdaptationRunwaySystemList    _runwaySystem;
   LpiResult::LpiEnum            _result;
};


#endif /* LPIGETADAPTATIONRUNWAYSYSTEMREPLY_H_ */
