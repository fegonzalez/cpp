
#ifndef LPIGETADAPTATIONMRTMINFOREPLY_H_
#define LPIGETADAPTATIONMRTMINFOREPLY_H_

#include <LpiAdaptationMrtmInfo.h>
#include <LpiResult.h>


class LpiGetAdaptationMrtmInfoReply
{
public:
   // getters
   const LpiAdaptationMrtmInfo & getAdaptationMrtmInfo(void) const {return this->_mrtm;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setAdaptationMrtmInfo(const LpiAdaptationMrtmInfo &value) {this->_mrtm = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiAdaptationMrtmInfo       _mrtm;
   LpiResult::LpiEnum           _result;
};


#endif /* LPIGETADAPTATIONRUNWAYREPLY_H_ */
