// -*-C++-*-
//-----------------------------------------------------------------------------
/*
 Author(s):    srperez
 Created:      Fri 22 Jun 09:56:13 2018
 Release:      $Revision$
 Modified:     $Date$
 Path:         $Source$

 Code Review by: <name, date>

 (c) Copyright 2018, Indra Navia AS, Div. NOVA, all rights reserved.*/
//---------------------------------------------------------------------------
#ifndef LPIGETADAPTATIONALERT_KPISREPLY_H_
#define LPIGETADAPTATIONALERT_KPISREPLY_H_

#include <LpiAdaptationAlert_KPIs.h>
#include <LpiResult.h>


class LpiGetAdaptationAlert_KPIsReply
{
public:
   // getters
   const LpiAdaptationAlert_KPIs & getAdaptationAlert_KPIs(void) const {return this->_adaptationAlert_KPIs;}
   const LpiResult::LpiEnum& getResult(void) const {return this->_result;}

   // setters
   void setAdaptationAlert_KPIs(const LpiAdaptationAlert_KPIs &value) {this->_adaptationAlert_KPIs = value;}
   void setResult(const LpiResult::LpiEnum &result) {this->_result = result;}

private:
   LpiAdaptationAlert_KPIs    _adaptationAlert_KPIs;
   LpiResult::LpiEnum           _result;
};




#endif /* LPIGETCONFIGURATIONALERT_KPISREPLY_H_ */
