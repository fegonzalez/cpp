/*
 * LpaAdaptationMrtmInfo.h
 *
 */
#ifndef LPAADAPTATIONMRTMINFO_H_
#define LPAADAPTATIONMRTMINFO_H_

#include <daortp_smmrtminfo_xsd.h>
#include "LpiAdaptationMrtmInfo.h"
#include <LclogStream.h>

class LpaAdaptationMrtmInfo
{
public:

   
    static void convert2AdaptationMrtmInfo(const SmMrtmInfo::MrtmElement &mrtmElement,
    										LpiAdaptationMrtmInfo  &output);
   
};


#endif /* LPAADAPTATIONAIRPORTINFO_H_ */
