/*
 * LpschDynamicDemandSchedulesGenerator.cc
 *
 *  Created on: 29/09/2014
 *      Author: mbegega
 */

#include <sstream>
#include <algorithm>
#include <boost/math/distributions/normal.hpp>

#include <LpiEvaluationDistribution.h>

#include <LpdbDemand.h>
#include <LpdbDataBase.h>
#include "LpschDynamicDemandSchedulesGenerator.h"
#include <LpiADOVector.h>

LpschDynamicDemandSchedulesGenerator::LpschDynamicDemandSchedulesGenerator ()
: LpschAbstractSchedulesGenerator(),
  r_dcbWeight(1.0 / 3.0),
  r_stabilityWeight(1.0 / 3.0),
  r_preferentialWeight(1.0 / 3.0),
  r_statisticDistribution(boost::math::normal(0.0, 1.0)),
  r_max_suitabilities(),
  DISCONNECT(std::numeric_limits<double>::max())
{
}


LpschDynamicDemandSchedulesGenerator::LpschDynamicDemandSchedulesGenerator (const LpschDynamicDemandSchedulesGenerator & source)
: LpschAbstractSchedulesGenerator(source),
  r_dcbWeight(source.r_dcbWeight),
  r_stabilityWeight(source.r_stabilityWeight),
  r_preferentialWeight(source.r_preferentialWeight),
  r_statisticDistribution(source.r_statisticDistribution),
  r_max_suitabilities(source.r_max_suitabilities),
  DISCONNECT(std::numeric_limits<double>::max())
{
}


boost::shared_ptr<LpschDynamicDemandSchedulesGenerator> & LpschDynamicDemandSchedulesGenerator::Get()
{
   static boost::shared_ptr<LpschDynamicDemandSchedulesGenerator> instance;

   if (!instance)
   {
      instance.reset(new LpschDynamicDemandSchedulesGenerator());
   }

   return instance;
}


 void LpschDynamicDemandSchedulesGenerator::setCalculationParameters()
{
  ///@warning RMAN only: distribution: Parámetros de la distribución Normal usada en la DCB Suitability
  ///
  // int minutes_subinterval = LpdbDataBase::Get().getGlobalParameters().getTimeParameters().getMinutesSubinterval();
  //  LpiEvaluationDistribution distribution;
  //   double factor = minutes_subinterval / 60.0;
  //   distribution= LpdbDataBase::Get().getGlobalParameters().getEvaluationDistribution();
  //   double mean = static_cast<double>(distribution.getMean() * factor);
  //   double standard_deviation = static_cast<double>(distribution.getStandardDeviation() * factor);
  //   r_statisticDistribution = boost::math::normal(mean, standard_deviation);

   r_dcbWeight = LpdbDataBase::Get().getGlobalParameters().getWeightPonderations().getWeightDcbs();
   r_stabilityWeight = LpdbDataBase::Get().getGlobalParameters().getWeightPonderations().getWeightStability();
   r_preferentialWeight = LpdbDataBase::Get().getGlobalParameters().getWeightPonderations().getWeightPreferentialRs();
}


void LpschDynamicDemandSchedulesGenerator::calculateTransitionCosts()
{
   reset();

   calculateDCBCosts();

   calculateStabilityPreferentialAndTotalCosts();
}


void LpschDynamicDemandSchedulesGenerator::reset()
{
   r_max_suitabilities.clear();
}


void LpschDynamicDemandSchedulesGenerator::calculateDCBCosts()
{
   typedef LpschTransitionSegmentCollection::value_type collectionElement;

   BOOST_FOREACH (collectionElement & element, r_transition_segments)
   {
      LpschTransitionSegmentKey segmentId = element.first;

      calculateAccDCMargin (segmentId);

      calculateAccDCBSuitability (segmentId);

      updateMaxDCBSuitabilitiesByInterval(segmentId);
   }

   BOOST_FOREACH (collectionElement & element, r_transition_segments)
   {
      LpschTransitionSegmentKey segmentId = element.first;

      normalizeDCBSuitability(segmentId);

      calculateAccDCBSuitabilityWeighted(segmentId);

      if (r_transition_segments.count(segmentId) > 0)
      {
         double weighted_suitability = r_transition_segments[segmentId].getAccDCBSuitabilityWeighted();

         r_transition_segments[segmentId].setDCBCost(1.0 - weighted_suitability);
      }
   }
}


void LpschDynamicDemandSchedulesGenerator::calculateStabilityPreferentialAndTotalCosts()
{
   typedef LpschTransitionSegmentCollection::value_type collectionElement;

   BOOST_FOREACH (collectionElement & element, r_transition_segments)
   {
      LpschTransitionSegmentKey segmentId = element.first;

      calculateStabilityCost      (segmentId);

	///@todo FIXME RMAN code commented
      //calculatePreferentialRSCost (segmentId);

      calculateTotalCost          (segmentId);
   }
}


void LpschDynamicDemandSchedulesGenerator::calculateDCBCost (LpschTransitionSegmentKey segmentId)
{
   calculateAccDCMargin (segmentId);

   calculateAccDCBSuitability (segmentId);

   calculateAccDCBSuitabilityWeighted (segmentId);
}

///@todo FIXME RMAN code commented
void LpschDynamicDemandSchedulesGenerator::calculateStabilityCost (LpschTransitionSegmentKey segmentId)
{
//   if (r_transition_segments.count(segmentId) > 0)
//   {
//      string originNode = segmentId.getFirstElement();
//      string destinationNode = segmentId.getSecondElement();

//      if (r_stability_table.existsTransition(originNode, destinationNode))
//      {
//         double rs_change_cost = r_stability_table.getMrtmTransitionCost(originNode, destinationNode);
//
//         r_transition_segments[segmentId].setStabilityCost(rs_change_cost);
//      }
//   }
}

///@todo FIXME RMAN code commented
//void LpschDynamicDemandSchedulesGenerator::calculatePreferentialRSCost (LpschTransitionSegmentKey segmentId)
//{
//   LpdbDataBase::RunwaySystemTable & rs_table = LpdbDataBase::Get().getRunwaySystemTable();
//
//   if (r_transition_segments.count(segmentId) > 0)
//   {
//      string destinationNode = segmentId.getSecondElement();
//      string interval = segmentId.getThirdElement();
//
//      if (rs_table.exists(destinationNode))
//      {
//         LpdbRunwaySystem & runway_system = rs_table[destinationNode];
//
//         if (runway_system.has_data(interval))
//         {
//            TimeInterval interval_times = runway_system.getTimeInterval(interval);
//
//            double preferential_cost = 1.0;
//            boost::optional<double> level = LpiRSPreferenceCalendar::getPonderatedLevel(destinationNode, interval_times, r_preferential_levels);
//
//            if (level)
//            {
//               preferential_cost = *level;
//            }
//
//            r_transition_segments[segmentId].setPreferentialCost(preferential_cost);
//         }
//      }
//   }
//}


void LpschDynamicDemandSchedulesGenerator::calculateTotalCost (LpschTransitionSegmentKey segmentId)
{
   //Default parameters (configuration)
   double dcbWeight = r_dcbWeight;
   double dcbStabilityWeight = r_stabilityWeight;
   double preferentialWeight = r_preferentialWeight;

   //What-if parameters have been set

   if (r_ponderation_criteria)
   {
      double accumulatedWeights = (r_ponderation_criteria->getDcbWeight() / 100.0) +
                                  (r_ponderation_criteria->getSuitabilityWeight() / 100.0) +
                                  (r_ponderation_criteria->getRsPreferenceWeight() / 100.0);

      if (accumulatedWeights > 0.0)
      {
         dcbWeight = r_ponderation_criteria->getDcbWeight() / 100.0;

         dcbStabilityWeight = r_ponderation_criteria->getSuitabilityWeight() / 100.0;

         preferentialWeight = r_ponderation_criteria->getRsPreferenceWeight() / 100.0;
      }
   }

   if (r_transition_segments.count(segmentId) > 0)
   {
      string destinationNode = segmentId.getSecondElement();

      if (destinationNode == "END")
      {
         r_transition_segments[segmentId].setTotalCost(0.0);
         return;
      }

      if (!checkNoCapacityNode(segmentId) && !isProhibitedNode(segmentId))
      {
         double total_cost = r_transition_segments[segmentId].getDCBCost() * dcbWeight +
                             r_transition_segments[segmentId].getStabilityCost() * dcbStabilityWeight +
                             r_transition_segments[segmentId].getPreferentialCost() * preferentialWeight;

         r_transition_segments[segmentId].setTotalCost(total_cost);
      }
      else
      {
         r_transition_segments[segmentId].setTotalCost(DISCONNECT);
      }
   }
}


bool LpschDynamicDemandSchedulesGenerator::checkNoCapacityNode (LpschTransitionSegmentKey segmentId)
{
   LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   if (r_transition_segments.count(segmentId) > 0)
   {
      string destinationNode = segmentId.getSecondElement();
      string interval = segmentId.getThirdElement();

      if (rsTable.exists(destinationNode))
      {
         LpdbRunwaySystem & rs_destination = rsTable[destinationNode];
         LpiADOVector<int> capacity = rs_destination[interval].getMaxCapacity();

         if (capacity == LpiADOVector<int>(0, 0, 0))
         {
            return true;
         }
      }
   }

   return false;
}


bool LpschDynamicDemandSchedulesGenerator::isProhibitedNode (LpschTransitionSegmentKey segmentId)
{
return false;

/**@warning RMAN code: forbidden RS
 *
 * @todo update RTP code to use ASssoc. prohibitions

   TimeLine<LpdbProhibitions> & prohibitionTimeLine = LpdbDataBase::Get().getProhibitionsTimeline();

   if (r_transition_segments.count(segmentId) > 0)
   {
      string destinationNode = segmentId.getSecondElement();
      string interval = segmentId.getThirdElement();

      if (prohibitionTimeLine.hasData(interval))
      {
         const set<string> & prohibitedRS = prohibitionTimeLine[interval].getProhibitions();

         set<string>::const_iterator itr = prohibitedRS.find(destinationNode);
         if (itr != prohibitedRS.end())
         {
            return true;
         }

      }
   }

   return false;
*/
}


void LpschDynamicDemandSchedulesGenerator::calculateAccDCMargin (LpschTransitionSegmentKey segmentId)
{
   LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   if (r_transition_segments.count(segmentId) > 0)
   {
      string originNode = segmentId.getFirstElement();
      string destinationNode = segmentId.getSecondElement();
      string interval = segmentId.getThirdElement();

      LpiADOVector<int> estimated_delayed;
      LpiADOVector<int> estimated_dc_margin;

      if (!interval.empty())
      {
         if (interval == "t0")
         {
            estimated_delayed = r_initial_delayed;
         }
         else
         {
            if (rsTable.exists(originNode))
            {
               string previous_interval = getPreviousInterval(interval);

               LpdbRunwaySystem & rs_origin = rsTable[originNode];
               estimated_delayed = rs_origin[previous_interval].getEstimatedDelayedFps();
            }
         }

         if (rsTable.exists(destinationNode))
         {
            LpdbRunwaySystem & rs_destination = rsTable[destinationNode];
            estimated_dc_margin = rs_destination[interval].getEstimatedDcMargin();
         }
      }

      LpiADOVector<double> margin = toDouble(estimated_delayed + estimated_dc_margin);

      //Add estimated not allowed delayed FPs in ti-1
      LpiADOVector<double> estimatedNotAllowed = getEstimatedNotAllowed(originNode, destinationNode, interval);

      margin = margin + estimatedNotAllowed;

      //Check for mixed runways case
      if (rsTable.exists(destinationNode))
      {
         LpdbRunwaySystem & rs_destination = rsTable[destinationNode];

         if (rs_destination.hasMixedRunways())
         {
            double SOd = std::max(0.0, margin[E_OVA]) -
                         std::max(0.0, margin[E_ARR]) -
                         std::max(0.0, margin[E_DEP]);

            if (SOd > 0.0)
            {
               r_transition_segments[segmentId].setSOd(SOd);
               margin[E_OVA] = SOd;
            }
         }
      }

      r_transition_segments[segmentId].setEstimatedNotAllowed(estimatedNotAllowed);
      r_transition_segments[segmentId].setAccDCMargin(margin);
   }
}

///@warning RMAN only: distribution: Parámetros de la distribución Normal usada en la DCB Suitability
void LpschDynamicDemandSchedulesGenerator::calculateAccDCBSuitability (LpschTransitionSegmentKey segmentId)
{
   if (r_transition_segments.count(segmentId) > 0)
   {
      LpiADOVector<double> acc_dc_margin = r_transition_segments[segmentId].getAccDCMargin();

      LpiADOVector<double> acc_dcb_suitability;

      for (int i = E_ARR; i <= E_OVA; i++)
      {
         acc_dcb_suitability[i] = boost::math::pdf(r_statisticDistribution, acc_dc_margin[i]) /
                                  boost::math::pdf(r_statisticDistribution, r_statisticDistribution.mean());
      }

      r_transition_segments[segmentId].setAccDCBSuitability(acc_dcb_suitability);
   }
}


void LpschDynamicDemandSchedulesGenerator::calculateAccDCBSuitabilityWeighted (LpschTransitionSegmentKey segmentId)
{
/*
   LpdbDemand & demand = LpdbDataBase::Get().getDemand();

   if (r_transition_segments.count(segmentId) > 0)
   {
      string interval = segmentId.getThirdElement();

      LpiADOVector<double> ponderated_demand;

      //Check if manual ponderation has been assigned (via what-if)

      if (!interval.empty())
      {
         if (r_ponderation_criteria && (*r_ponderation_criteria).has_data(interval))
         {
            if ((*r_ponderation_criteria)[interval].getCriteriaType() == LpiOptimizationCriteriaTimedData::E_MANUAL)
            {
               ponderated_demand[E_ARR] = (*r_ponderation_criteria)[interval].getArrivalsPriority() / 100.0;
               ponderated_demand[E_DEP] = (*r_ponderation_criteria)[interval].getDeparturesPriority() / 100.0;
            }
            else
            {
               //No data has been manually set, use received demand in current interval
               ponderated_demand = demand[interval].getPonderatedDemand();
            }
         }
         else if (demand.has_data(interval)) //Default case, get ponderated demand in current interval
         {
            ponderated_demand = demand[interval].getPonderatedDemand();
         }
      }

      LpiADOVector<double> acc_dcb_norm_suitability = r_transition_segments[segmentId].getAccDCBNormalizedSuitability();

      double weighted_suitability = acc_dcb_norm_suitability[E_ARR] * ponderated_demand[E_ARR] +
                                    acc_dcb_norm_suitability[E_DEP] * ponderated_demand[E_DEP];

      //Check mixed runways case
      double SOd = r_transition_segments[segmentId].getSOd();
      if (SOd > 0.0)
      {
         weighted_suitability *= acc_dcb_norm_suitability[E_OVA];
      }

      r_transition_segments[segmentId].setAccDCBSuitabilityWeighted(weighted_suitability);
   }*/
}


void LpschDynamicDemandSchedulesGenerator::updateMaxDCBSuitabilitiesByInterval(LpschTransitionSegmentKey segmentId)
{
   if (r_transition_segments.count(segmentId) > 0)
   {
      string originNode = segmentId.getFirstElement();
      string destinationNode = segmentId.getSecondElement();
      string interval = segmentId.getThirdElement();

      LpiADOVector<double> accumulatedDCBSuitability = r_transition_segments[segmentId].getAccDCBSuitability();

      LpschOriginRSAndIntervalKey key(originNode, interval);

      if (r_max_suitabilities.count(key) > 0)
      {
         LpiADOVector<double> maxCalculatedDCBSuitability = r_max_suitabilities[key];

         r_max_suitabilities[key] = max(accumulatedDCBSuitability, maxCalculatedDCBSuitability);
      }
      else
      {
         r_max_suitabilities[key] = accumulatedDCBSuitability;
      }
   }
}


void LpschDynamicDemandSchedulesGenerator::normalizeDCBSuitability(LpschTransitionSegmentKey segmentId)
{
   if (r_transition_segments.count(segmentId) > 0)
   {
      string originNode = segmentId.getFirstElement();
      string destinationNode = segmentId.getSecondElement();
      string interval = segmentId.getThirdElement();

      LpiADOVector<double> accumulatedDCBSuitability = r_transition_segments[segmentId].getAccDCBSuitability();

      LpschOriginRSAndIntervalKey key(originNode, interval);

      LpiADOVector<double> normalizedSuitability(1.0, 1.0, 1.0);
      if (r_max_suitabilities.count(key) > 0)
      {
         LpiADOVector<double> maxAccDCBSuitability = r_max_suitabilities[key];

         //Division by 0 checked in operator / code
         normalizedSuitability = accumulatedDCBSuitability / maxAccDCBSuitability;
      }

      r_transition_segments[segmentId].setAccDCBNormalizedSuitability(normalizedSuitability);
   }
}


LpiADOVector<double> LpschDynamicDemandSchedulesGenerator::getEstimatedNotAllowed(const string & originNode,
                                                                                const string & destinationNode,
                                                                                const string & interval)
{
   LpiADOVector<double> result;

   LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   if (rsTable.exists(originNode) && rsTable.exists(destinationNode) && (interval != "t0"))
   {
      string previousInterval = getPreviousInterval(interval);

      LpdbRunwaySystem & rsOrigin = rsTable[originNode];
      LpdbRunwaySystem & rsDestination = rsTable[destinationNode];

      LpiADOVector<int> notAllowedEstimated = rsOrigin[previousInterval].getNotAllowedEstimatedFPs();

      OperationType::Enum usages[3] = { OperationType::E_ARRIVALS, OperationType::E_DEPARTURES, OperationType::E_MIXED };

      for (int i = E_ARR; i <= E_DEP; ++i)
      {
         if (rsOrigin.hasRunwaysOfSameUse(rsDestination, usages[i]))
         {
            result[i] += notAllowedEstimated[i];
         }
      }

      //Overall component (check mixed use)
      if (rsOrigin.hasMixedRunways())
      {
         if (rsOrigin.hasRunwaysOfSameUse(rsDestination, OperationType::E_MIXED))
         {
            result[E_OVA] += notAllowedEstimated[E_OVA];
         }
      }
      else
      {
         result[E_OVA] = result[E_ARR] + result[E_DEP];
      }
   }

   return result;
}


void LpschDynamicDemandSchedulesGenerator::printTransitionMatrix () const
{
   typedef const LpschTransitionSegmentCollection::value_type collectionElement;

   //unsigned int i = 1;
   BOOST_FOREACH (collectionElement & element, r_transition_segments)
   {
      LpschTransitionSegmentKey segmentId = element.first;
      //LclogStream::instance(LclogConfig::E_RTP).info() << i++ << ": " << '[' << segmentId << "]: " << element.second << std::endl;
   }
}


std::string LpschDynamicDemandSchedulesGenerator::getTransitionMatrixAsString () const
{
   std::stringstream out_stream;

   typedef const LpschTransitionSegmentCollection::value_type collectionElement;

   //unsigned int i = 1;
   BOOST_FOREACH (collectionElement & element, r_transition_segments)
   {
      LpschTransitionSegmentKey segmentId = element.first;
      //out_stream << i++ << ": " << '[' << segmentId << "]: " << element.second << std::endl;
   }

   return out_stream.str();
}


std::string LpschDynamicDemandSchedulesGenerator::getMaxDCBSuitabilitiesAsString() const
{
   std::stringstream out_stream;

   typedef const map<LpschOriginRSAndIntervalKey,
               LpiADOVector<double>,
               LpschOriginRSAndIntervalKeyComparer>::value_type collectionElement;

   //unsigned int i = 1;
   BOOST_FOREACH (collectionElement & element, r_max_suitabilities)
   {
      LpschOriginRSAndIntervalKey elementId = element.first;
      //out_stream << i++ << ": " << '[' << elementId << "]: " << element.second << std::endl;
   }

   return out_stream.str();
}
