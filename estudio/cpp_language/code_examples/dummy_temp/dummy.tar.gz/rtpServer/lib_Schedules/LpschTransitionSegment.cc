/*
 * LpschTransitionSegment.cc
 *
 *  Created on: 29/09/2014
 *      Author: mbegega
 */

#include "LpschTransitionSegment.h"

LpschTransitionSegment::LpschTransitionSegment()
: r_acc_dc_margin(),
  r_acc_dcb_suitability(),
  r_acc_dcb_normalized_suitability(),
  r_estimated_not_allowed(),
  r_acc_dcb_suituability_weighted(0.0),
  r_cost_dcb(0.0),
  r_cost_stab(0.0),
  r_cost_pref(0.0),
  r_cost_tot(0.0),
  r_SOd(0.0)
{
}


LpschTransitionSegment::LpschTransitionSegment(const LpschTransitionSegment & source)
{
   r_acc_dc_margin = source.r_acc_dc_margin;
   r_acc_dcb_suitability = source.r_acc_dcb_suitability;
   r_acc_dcb_normalized_suitability = source.r_acc_dcb_normalized_suitability;
   r_estimated_not_allowed = source.r_estimated_not_allowed;
   r_acc_dcb_suituability_weighted = source.r_acc_dcb_suituability_weighted;
   r_cost_dcb = source.r_cost_dcb;
   r_cost_stab = source.r_cost_stab;
   r_cost_pref = source.r_cost_pref;
   r_cost_tot = source.r_cost_tot;
   r_SOd = source.r_SOd;
}


LpschTransitionSegment & LpschTransitionSegment::operator= (const LpschTransitionSegment & source)
{
   if (this != & source)
   {
      r_acc_dc_margin = source.r_acc_dc_margin;
      r_acc_dcb_suitability = source.r_acc_dcb_suitability;
      r_acc_dcb_normalized_suitability = source.r_acc_dcb_normalized_suitability;
      r_estimated_not_allowed = source.r_estimated_not_allowed;
      r_acc_dcb_suituability_weighted = source.r_acc_dcb_suituability_weighted;
      r_cost_dcb = source.r_cost_dcb;
      r_cost_stab = source.r_cost_stab;
      r_cost_pref = source.r_cost_pref;
      r_cost_tot = source.r_cost_tot;
      r_SOd = source.r_SOd;
   }
   return *this;
}


LpiADOVector<double> LpschTransitionSegment::getAccDCMargin() const
{
   return r_acc_dc_margin;
}


LpiADOVector<double> LpschTransitionSegment::getAccDCBSuitability() const
{
   return r_acc_dcb_suitability;
}


LpiADOVector<double> LpschTransitionSegment::getAccDCBNormalizedSuitability() const
{
   return r_acc_dcb_normalized_suitability;
}


LpiADOVector<double> LpschTransitionSegment::getEstimatedNotAllowed() const
{
   return r_estimated_not_allowed;
}


double LpschTransitionSegment::getAccDCBSuitabilityWeighted() const
{
   return r_acc_dcb_suituability_weighted;
}


double LpschTransitionSegment::getDCBCost() const
{
   return r_cost_dcb;
}


double LpschTransitionSegment::getStabilityCost() const
{
   return r_cost_stab;
}


double LpschTransitionSegment::getPreferentialCost() const
{
   return r_cost_pref;
}


double LpschTransitionSegment::getTotalCost() const
{
   return r_cost_tot;
}


double LpschTransitionSegment::getSOd() const
{
   return r_SOd;
}


LpschTransitionSegment & LpschTransitionSegment::setAccDCMargin (const LpiADOVector<double> & cost)
{
   r_acc_dc_margin = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setAccDCBSuitability(const LpiADOVector<double> & cost)
{
   r_acc_dcb_suitability = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setAccDCBNormalizedSuitability(const LpiADOVector<double> & cost)
{
   r_acc_dcb_normalized_suitability = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setEstimatedNotAllowed(const LpiADOVector<double> & estimatedNotAllowed)
{
   r_estimated_not_allowed = estimatedNotAllowed;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setAccDCBSuitabilityWeighted(double & cost)
{
   r_acc_dcb_suituability_weighted = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setDCBCost(double cost)
{
   r_cost_dcb = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setStabilityCost(double cost)
{
   r_cost_stab = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setPreferentialCost(double cost)
{
   r_cost_pref = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setTotalCost(double cost)
{
   r_cost_tot = cost;

   return *this;
}


LpschTransitionSegment & LpschTransitionSegment::setSOd(double value)
{
   r_SOd = value;

   return *this;
}


ostream & operator<< (ostream & out, const LpschTransitionSegment & segment)
{
   out << "[ACC_DC_MRG: " << segment.getAccDCMargin()
       << " | EST_NOT_ALLWD: " << segment.getEstimatedNotAllowed()
       << " | ACC_DCB_SUIT: " << segment.getAccDCBSuitability()
       << " | ACC_DCB_SUIT_N: " << segment.getAccDCBNormalizedSuitability()
       << " | ACC_DCB_SUIT_WGT: " << segment.getAccDCBSuitabilityWeighted()
       << " | DCB COST: " << segment.getDCBCost()
       << " | STAB COST: " << segment.getStabilityCost()
       << " | PREF COST: " << segment.getPreferentialCost()
       << " | TOT COST: " << segment.getTotalCost();

       if (segment.getSOd() > 0.0)
       {
          out << " | SOd: " << segment.getSOd();
       }

       out << ']';

   return out;
}


bool LpschOriginRSAndIntervalKeyComparer::operator()(const LpschOriginRSAndIntervalKey & leftOperand, const LpschOriginRSAndIntervalKey & rightOperand) const
{
   string timeIntervalLeft  = leftOperand.getSecondElement();
   string timeIntervalRight = rightOperand.getSecondElement();

   string rsOriginLeft  = leftOperand.getFirstElement();
   string rsOriginRight = rightOperand.getFirstElement();

   if (timeIntervalLeft != timeIntervalRight)
   {
      return timeIntervalLeft < timeIntervalRight;
   }
   else
   {
      return rsOriginLeft < rsOriginRight;
   }
}


bool LpschTransitionSegmentComparer::operator()(const LpschTransitionSegmentKey & leftOperand, const LpschTransitionSegmentKey & rightOperand) const
{
   string timeIntervalLeft  = leftOperand.getThirdElement();
   string timeIntervalRight = rightOperand.getThirdElement();

   string rsOriginLeft  = leftOperand.getFirstElement();
   string rsOriginRight = rightOperand.getFirstElement();

   string rsDestinationLeft  = leftOperand.getSecondElement();
   string rsDestinationRight = rightOperand.getSecondElement();

   if (timeIntervalLeft != timeIntervalRight)
   {
      return timeIntervalLeft < timeIntervalRight;
   }
   else if (rsOriginLeft != rsOriginRight)
   {
      return rsOriginLeft < rsOriginRight;
   }
   else
   {
      return rsDestinationLeft < rsDestinationRight;
   }
}
