/*
 * LpschAbstractSchedulesGenerator.cc
 *
 *  Created on: 29/09/2014
 *      Author: mbegega
 */

#include <sstream>
#include <fstream>
#include <iostream>
#include <algorithm>

#include <boost/foreach.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string/erase.hpp>
#include <boost/assign/list_of.hpp>


#include "LpschAbstractSchedulesGenerator.h"
#include "LpiMessages.h"
#include <LpiDijkstraInterface.h>
#include <LpdbDataBase.h>


using std::stringstream;
using namespace boost::posix_time;


LpschAbstractSchedulesGenerator::LpschAbstractSchedulesGenerator()
: r_runway_systems(),
  r_time_intervals(),
  r_transition_segments(),
  r_default_schedule(),
  r_nodes(),
  r_transitions(),
  r_algorithm_result(),
  //r_preferential_levels(),
  r_ponderation_criteria(),
  //r_stability_table(),
  r_initial_node("BEGIN"),
  r_initial_delayed()
{
}


LpschAbstractSchedulesGenerator::LpschAbstractSchedulesGenerator(const LpschAbstractSchedulesGenerator & source)
: r_runway_systems(source.r_runway_systems),
  r_time_intervals(source.r_time_intervals),
  r_transition_segments(source.r_transition_segments),
  r_default_schedule(source.r_default_schedule),
  r_nodes(source.r_nodes),
  r_transitions(source.r_transitions),
  r_algorithm_result(source.r_algorithm_result),
  //r_preferential_levels(source.r_preferential_levels),
  r_ponderation_criteria(source.r_ponderation_criteria),
  //r_stability_table(source.r_stability_table),
  r_initial_node(source.r_initial_node),
  r_initial_delayed(source.r_initial_delayed)
{
}


void LpschAbstractSchedulesGenerator::createGraph ()
{
   reset();

   obtainRunwaySystems();
   obtainTimeIntervals();

   createNodes();
   createTransitions();

   calculateTransitionCosts();
   copyCostsToTransitionNodes();
}


void LpschAbstractSchedulesGenerator::createGraph (vector<string> runway_systems,
                                                 vector<string> time_intervals,
                                                 string initial_node,
                                                 LpiADOVector<int> initial_delayed)
{
   reset();

   r_runway_systems = runway_systems;
   r_time_intervals = time_intervals;
   r_initial_node   = initial_node;
   r_initial_delayed= initial_delayed;

   createNodes(initial_node);

   createTransitions(initial_node);

   calculateTransitionCosts();

   copyCostsToTransitionNodes();
}


void LpschAbstractSchedulesGenerator::generateSchedules (string initial_node, int number_of_schedules)
{
   clearPonderationCriteria();

   string final_fictitious_node = "END";

   //Generate request for schedules
   RSScheduleRequest request;
   request.id_ = 1;
   request.num_schedules_ = number_of_schedules;

   if (initial_node.length() == 0)
   {
      request.start_node_id_ = "BEGIN";
   }
   else
   {
      request.start_node_id_ = initial_node;
   }

   request.end_node_id_ = final_fictitious_node;


   //ptime start = microsec_clock::universal_time();

   //Expected response
   r_algorithm_result.clear();

   LpiDijkstraInterface alg_iface;
   alg_iface.processRSScheduleRequest(r_nodes, 
   				      r_transitions, 
   				      request, 
   				      r_algorithm_result);

   //   ptime stop = microsec_clock::universal_time();
   //   time_duration elapsed = stop - start;

//   std::cout << "Total execution time for generating " << request.num_schedules_ << " schedules= " << elapsed.total_milliseconds() << " msec." << std::endl;


// ///@debug Dijkstra: 
//    printInputInterface(request);
//    printOutputInterface();
//    printTransitionMatrix ();
}


void LpschAbstractSchedulesGenerator::reset ()
{
   r_runway_systems.clear();
   r_time_intervals.clear();
   r_nodes.clear();
   r_transitions.clear();
   r_algorithm_result.clear();
   r_transition_segments.clear();
   r_initial_node = "BEGIN";
}


//void LpschAbstractSchedulesGenerator::setPreferentialLevels (const LpiAdaptationRunwaySystemPreferenceList & preferential_levels)
//{
//   r_preferential_levels = preferential_levels;
//}


void LpschAbstractSchedulesGenerator::setPonderationCriteria (const LpiOptimizationCriteria & ponderations)
{
   r_ponderation_criteria = ponderations;
}


void LpschAbstractSchedulesGenerator::clearPonderationCriteria()
{
   r_ponderation_criteria = boost::none;
}


boost::optional<LpiOptimizationCriteria> LpschAbstractSchedulesGenerator::getPonderationCriteria() const
{
   return r_ponderation_criteria;
}


void LpschAbstractSchedulesGenerator::getPonderationsInInterval(string interval,
                                                              double & arrival_ponderation,
                                                              double & departure_ponderation)
{
	/*
   arrival_ponderation = 0.5;
   departure_ponderation = 0.5;

   LpdbDemand & demand = LpdbDataBase::Get().getDemand();

   //Check if manual ponderation has been assigned (via what-if)
   if (!interval.empty())
   {
      if (r_ponderation_criteria && (*r_ponderation_criteria).has_data(interval))
      {
         if ((*r_ponderation_criteria)[interval].getCriteriaType() == LpiOptimizationCriteriaTimedData::E_MANUAL)
         {
            arrival_ponderation = (*r_ponderation_criteria)[interval].getArrivalsPriority();
            departure_ponderation = (*r_ponderation_criteria)[interval].getDeparturesPriority();
         }
         else
         {
            //No data has been manually set, use received demand in current interval
            LpiADOVector<double> ponderated_demand = demand[interval].getPonderatedDemand();
            arrival_ponderation = ponderated_demand[E_ARR];
            departure_ponderation = ponderated_demand[E_DEP];
         }
      }
      else if (demand.has_data(interval)) //Default case, get ponderated demand in current interval
      {
         LpiADOVector<double> ponderated_demand = demand[interval].getPonderatedDemand();
         arrival_ponderation = ponderated_demand[E_ARR];
         departure_ponderation = ponderated_demand[E_DEP];
      }
   }*/
}

/*
void LpschAbstractSchedulesGenerator::setStabilityCostMatrix (const LpiAdaptationMrtmTransitionCostTable & stability_table)
{
   r_stability_table = stability_table;
}
*/

void LpschAbstractSchedulesGenerator::obtainRunwaySystems ()
{
   LpdbDataBase::RunwaySystemTable & rs_table = LpdbDataBase::Get().getRunwaySystemTable();
   vector<string> rs_ids = rs_table.getAllIds();

   r_runway_systems.clear();

   BOOST_FOREACH(string rs_identifier, rs_ids)
   {
      r_runway_systems.push_back(rs_identifier);
   }
}


void LpschAbstractSchedulesGenerator::obtainTimeIntervals ()
{
   LpdbDataBase::RunwaySystemTable & rs_table = LpdbDataBase::Get().getRunwaySystemTable();
   vector<string> rs_ids = rs_table.getAllIds();

   //Timeline intervals are the same for all runway systems
   if (rs_ids.size() > 0)
   {
      r_time_intervals.clear();

      string rs_identifier = rs_ids[0];
      LpdbRunwaySystem runway_system = rs_table[rs_identifier];
      r_time_intervals = runway_system.getTimeLine().getAllIntervalIds();
   }
}


//void LpschAbstractSchedulesGenerator::generateDefaultSchedule ()
//{
//   clearPonderationCriteria();
//
//   LpdbSchedule default_schedule;
//
//   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();
//   LpiTimeParameters parameters = LpdbDataBase::Get().getGlobalParameters().getTimeParameters();
//
//   //Initialize internal timeline
//   default_schedule.init (parameters,
//                          LpdbDataBase::Get().getTimeLineBase());
//
//   vector<string> intervals = default_schedule.getTimeLine().getAllIntervalIds();
//
//   BOOST_FOREACH(string interval, intervals)
//   {
//      if (default_schedule.has_data(interval))
//      {
//         TimeInterval ti = default_schedule.getTimeLine().getTimeInterval(interval);
//
//         boost::optional<string> runway_system = LpiRSPreferenceCalendar::getPreferentialRunwaySystem(ti, r_preferential_levels);
//
//         if (runway_system)
//         {
//            LpdbRunwaySystem rs = rsTable[*runway_system];
//
//            LpdbRSScheduled rs_scheduled(rs);
//
//            default_schedule[interval].setRsScheduled(rs);
//         }
//         else
//         {
//            r_default_schedule=  boost::none;
//         }
//      }
//   }
//
//   r_default_schedule = default_schedule;
//}


//void LpschAbstractSchedulesGenerator::forwardDefaultSchedule ()
//{
//   if (r_default_schedule)
//   {
//      LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();
//
//      //Moves all timeline forward and adds an empty interval at the end
//      (*r_default_schedule).forward();
//
//      //Gets new interval default RS from preferences calendar
//      std::string new_interval = (*r_default_schedule).getTimeLine().getLastInterval();
//      TimeInterval ti = (*r_default_schedule).getTimeLine().getTimeInterval(new_interval);
//
//      boost::optional<string> runway_system = LpiRSPreferenceCalendar::getPreferentialRunwaySystem(ti, r_preferential_levels);
//
//      if (runway_system)
//      {
//         LpdbRunwaySystem rs = rsTable[*runway_system];
//
//         LpdbRSScheduled rs_scheduled(rs);
//
//         (*r_default_schedule)[new_interval].setRsScheduled(rs_scheduled);
//      }
//   }
//}


boost::optional<LpdbSchedule> LpschAbstractSchedulesGenerator::getDefaultSchedule ()
{
   return r_default_schedule;
}


//boost::optional<std::string> LpschAbstractSchedulesGenerator::getDefaultRSInInterval(TimeInterval interval)
//{
//   return LpiRSPreferenceCalendar::getPreferentialRunwaySystem(interval, r_preferential_levels);
//}


vector<LpdbSchedule> LpschAbstractSchedulesGenerator::getSolutions ()
{
   LpiTimeParameters parameters = LpdbDataBase::Get().getGlobalParameters().getTimeParameters();
   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   vector<LpdbSchedule> solutions;

   for (unsigned int i = 0; i < r_algorithm_result.size(); i++)
   {
      LpdbSchedule schedule;

      //Initialize internal timeline
      schedule.init (parameters,
                     LpdbDataBase::Get().getTimeLineBase());

      //Extract RS and ti
      for (unsigned int j = 0; j < r_algorithm_result[i].nodes_.size(); j++)
      {
         string runway_system;
         string interval;

         bool converted = getRSandIntervalFromNode (r_algorithm_result[i].nodes_[j], runway_system, interval);

         if (converted)
         {
            if (schedule.has_data(interval) && rsTable.exists(runway_system))
            {
               LpdbRunwaySystem rs = rsTable[runway_system];

               LpdbRSScheduled rs_scheduled(rs);

               schedule[interval].setRsScheduled(rs_scheduled);
            }
         }
      }

      solutions.push_back(schedule);
   }

   return solutions;
}


LpdbSchedule LpschAbstractSchedulesGenerator::getBestSolution()
{
   LpdbSchedule best;

   LpiTimeParameters parameters = LpdbDataBase::Get().getGlobalParameters().getTimeParameters();

   //Initialize internal timeline
   best.init (parameters,
              LpdbDataBase::Get().getTimeLineBase());

   if (r_algorithm_result.size() > 0)
   {
      LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

      int best_schedule_index = 0; // Pathfinding returns best solution first

      //Extract RS and ti
      for (unsigned int j = 0; j < r_algorithm_result[best_schedule_index].nodes_.size(); j++)
      {
         string runway_system;
         string interval;

         bool converted = getRSandIntervalFromNode (r_algorithm_result[best_schedule_index].nodes_[j], runway_system, interval);

         if (converted)
         {
            if (best.has_data(interval))
            {
               LpdbRunwaySystem rs = rsTable[runway_system];

               LpdbRSScheduled rs_scheduled(rs);

               if ((interval.find('t', 0)) != string::npos)
               {
                   best[interval].setRsScheduled(rs_scheduled);
               }
            }
         }
      }
   }

   return best;
}


LpdbSCHTimedData LpschAbstractSchedulesGenerator::getSolutionForInterval()
{
   LpdbSCHTimedData interval_data;

   if (r_algorithm_result.size() > 0)
   {
      LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

      int best_schedule_index = 0; // Pathfinding returns best solution first

      //Extract RS and ti
      for (unsigned int j = 0; j < r_algorithm_result[best_schedule_index].nodes_.size(); j++)
      {
         string runway_system;
         string interval;

         bool converted = getRSandIntervalFromNode (r_algorithm_result[best_schedule_index].nodes_[j], runway_system, interval);

         if (converted && !empty(runway_system) && rsTable.exists(runway_system))
         {
            LpdbRunwaySystem rs = rsTable[runway_system];

            LpdbRSScheduled rs_scheduled(rs);
            interval_data.setRsScheduled(rs_scheduled);
         }
      }
   }

   return interval_data;
}


LpdbSchedule LpschAbstractSchedulesGenerator::getSolution(const vector<string> & frozenIntervals,
                                                       const vector<string> & frozenOfActive,
                                                       LpdbSchedule::ScheduleType whichSchedule)
{
   LpdbSchedule best;

   LpiTimeParameters parameters = LpdbDataBase::Get().getGlobalParameters().getTimeParameters();
   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   //Initialize internal timeline
   best.init (parameters,
              LpdbDataBase::Get().getTimeLineBase());

   //Add frozen nodes to solution first
   if (frozenIntervals.size() > 0)
   {
      vector<string> frozenNodes;
      vector<string> frozenNodesOfActive;

      switch (whichSchedule)
      {
         case LpdbSchedule::E_ACTIVE:
            frozenNodesOfActive = getFrozenNodesOfActiveSchedule(frozenIntervals);
         break;
         case LpdbSchedule::E_OPTIMAL:
            frozenNodes = getFrozenNodesOfOptimalSchedule(frozenIntervals);
            frozenNodesOfActive = getFrozenNodesOfActiveSchedule(frozenOfActive);
         break;
         case LpdbSchedule::E_ALTERNATIVE:
         default:
         break;
      }


      if (frozenNodes.size() > 0)
      {
         for (unsigned int i = 0; i < frozenNodes.size(); ++i)
         {
            string frozenNode = frozenNodes[i]; //Internal representation: RSi-tj

            string runwaySystemId;
            string interval;

            bool converted = getRSandIntervalFromNode(frozenNode, runwaySystemId, interval);

            if (converted)
            {
               if (best.has_data(interval))
               {
                  LpdbRunwaySystem rs = rsTable[runwaySystemId];

                  LpdbRSScheduled scheduledRS(rs);

                  best[interval].setRsScheduled(scheduledRS);
               }
            }
         }
      }


      //Only for clock forwarding: overwrite with frozen of active
      if ((frozenNodesOfActive.size() > 0) && (frozenIntervals != frozenNodesOfActive))
      {
         for (unsigned int i = 0; i < frozenNodesOfActive.size(); ++i)
         {
            string frozenNode = frozenNodesOfActive[i]; //Internal representation: RSi-tj

            string runwaySystemId;
            string interval;

            bool converted = getRSandIntervalFromNode(frozenNode, runwaySystemId, interval);

            if (converted)
            {
               if (best.has_data(interval))
               {
                  LpdbRunwaySystem rs = rsTable[runwaySystemId];

                  LpdbRSScheduled scheduledRS(rs);

                  best[interval].setRsScheduled(scheduledRS);
               }
            }
         }
      }

   }


   //Add algorithm result to the not frozen part of the schedule

   if (r_algorithm_result.size() > 0)
   {
      int best_schedule_index = 0; //Pathfinding returns best solution first

      //Extract RS and ti
      for (unsigned int j = 0; j < r_algorithm_result[best_schedule_index].nodes_.size(); j++)
      {
         string runwaySystemId;
         string interval;

         bool converted = getRSandIntervalFromNode(r_algorithm_result[best_schedule_index].nodes_[j], runwaySystemId, interval);

         if (converted)
         {
            if (best.has_data(interval))
            {
               LpdbRunwaySystem rs = rsTable[runwaySystemId];

               LpdbRSScheduled scheduledRS(rs);


               if ((interval.find('t', 0)) != string::npos)
               {
                   best[interval].setRsScheduled(scheduledRS);
               }
            }
         }
      }
   }

   return best;
}




void LpschAbstractSchedulesGenerator::createNodes (string initial_node)
{
   string initial = (initial_node.size() == 0) ? "BEGIN" : initial_node;
   string final = "END";    //final fictitious node

   RSNode graph_node;

   BOOST_FOREACH(string interval_name, r_time_intervals)
   {
      BOOST_FOREACH(string rs, r_runway_systems)
      {
         string node_name = getNodeAlias(rs, interval_name);

         graph_node.type_ = RSNode::Normal;

         graph_node.id_ = node_name;
         graph_node.runwaySystem_id_ = rs;
         graph_node.configuration_id_= rs;
         graph_node.alias_ = graph_node.id_ ;

         r_nodes.push_back(graph_node);
      }
   }

   //initial node
   graph_node.id_ = initial;
   graph_node.runwaySystem_id_ = initial;
   graph_node.configuration_id_= initial;
   graph_node.type_ = RSNode::Normal;

   graph_node.alias_ = graph_node.id_ ;

   r_nodes.insert(r_nodes.begin(), graph_node);

   //final node
   graph_node.id_ = final;
   graph_node.runwaySystem_id_ = final;
   graph_node.configuration_id_= final;
   graph_node.type_ = RSNode::Normal;
   graph_node.alias_ = graph_node.id_ ;

   r_nodes.push_back(graph_node);

}


void LpschAbstractSchedulesGenerator::createTransitions (string initial_node)
{
   string initial = (initial_node.size() == 0) ? "BEGIN" : initial_node;
   string final = "END";    //final fictitious node

   RSTransitionSegment graph_transition;

   unsigned int transition_number = 1;

   //Generate initial node transitions
   if ((r_time_intervals.size() > 0) && (r_runway_systems.size() > 0))
   {
      BOOST_FOREACH(string rs, r_runway_systems)
      {
         graph_transition.id_ = boost::lexical_cast<string>(transition_number);

         graph_transition.type_ = RSTransitionSegment::Normal;
         graph_transition.originRSNode_ = initial;
         graph_transition.destinationRSNode_ = getNodeAlias(rs, r_time_intervals[0]);
         graph_transition.weight_ = 0.0;

         r_transitions.push_back(graph_transition);

         transition_number++;

         //Insert also in map for costs calculations
         LpschTransitionSegmentKey key(initial,
                                     rs,
                                     r_time_intervals[0]);

         r_transition_segments[key] = LpschTransitionSegment();
      }
   }

   //Generate intermediate transitions
   if (r_time_intervals.size() > 1)
   {
      for (unsigned int interval =1 ; interval < r_time_intervals.size(); interval++)
      {
         BOOST_FOREACH(string rs_previous, r_runway_systems)
         {
               BOOST_FOREACH(string rs, r_runway_systems)
               {
                  string previous_interval = r_time_intervals[interval-1];
                  string actual_interval = r_time_intervals[interval];

                  string origin_node_name = getNodeAlias(rs_previous, previous_interval);
                  string destination_node_name = getNodeAlias(rs, actual_interval);

                  graph_transition.id_ = boost::lexical_cast<string>(transition_number);

                  graph_transition.type_ = RSTransitionSegment::Normal;
                  graph_transition.originRSNode_ = origin_node_name;
                  graph_transition.destinationRSNode_ = destination_node_name;
                  graph_transition.weight_ = 0.0;

                  r_transitions.push_back(graph_transition);

                  transition_number++;

                  //Insert also in map for costs calculations
                  LpschTransitionSegmentKey key(rs_previous,
                                              rs,
                                              actual_interval);

                  r_transition_segments[key] = LpschTransitionSegment();
               }
         }
      }
   }

   //Generate final node transitions
   if ((r_time_intervals.size() > 0) && (r_runway_systems.size() > 0))
   {
      int last_interval = r_time_intervals.size() - 1;

      BOOST_FOREACH(string rs, r_runway_systems)
      {
         graph_transition.id_ = boost::lexical_cast<string>(transition_number);

         graph_transition.type_ = RSTransitionSegment::Normal;
         graph_transition.originRSNode_ = getNodeAlias(rs, r_time_intervals[last_interval]);
         graph_transition.destinationRSNode_ = final;
         graph_transition.weight_ = 0.0;

         r_transitions.push_back(graph_transition);

         transition_number++;

         //Insert also in map for costs calculations
         LpschTransitionSegmentKey key(rs,
                                     final,
                                     "");

         r_transition_segments[key] = LpschTransitionSegment();
      }
   }
}


void LpschAbstractSchedulesGenerator::filterFrozenNodes (vector<string> frozen_intervals, vector<string> frozen_nodes)
{
   LpschTransitionSegmentCollection::iterator segments_iterator = r_transition_segments.begin();

   while(segments_iterator != r_transition_segments.end())
   {
      LpschTransitionSegmentKey segmentId = segments_iterator->first;
      LpschTransitionSegment transition = segments_iterator->second;

      string originRS = segmentId.getFirstElement();
      string destinationRS = segmentId.getSecondElement();
      string interval = segmentId.getThirdElement();

      string origin_node = originRS;


      string previous_interval;
      vector<string>::iterator itr_intervals_previous = frozen_intervals.end();

      if (!interval.empty() && (interval != "t0"))
      {
         previous_interval = getPreviousInterval(interval);
         itr_intervals_previous = std::find(frozen_intervals.begin(), frozen_intervals.end(), previous_interval);

         origin_node = originRS + "-" + previous_interval;
      }

      string destination_node = destinationRS + "-" + interval;

      vector<string>::iterator itr_intervals = std::find(frozen_intervals.begin(), frozen_intervals.end(), interval);

      if (itr_intervals != frozen_intervals.end())
      {
            vector<string>::iterator itr_nodes_origin = std::find(frozen_nodes.begin(),
                                                                  frozen_nodes.end(),
                                                                  origin_node);

            vector<string>::iterator itr_nodes_destination = std::find(frozen_nodes.begin(),
                                                                       frozen_nodes.end(),
                                                                       destination_node);

            if (previous_interval.empty() && (itr_nodes_destination != frozen_nodes.end()))
            {
               ++segments_iterator;
            }
            else if (!previous_interval.empty() &&
                    (itr_nodes_origin != frozen_nodes.end()) &&
                    (itr_nodes_destination != frozen_nodes.end()))
            {
               ++segments_iterator;
            }
            else
            {
               r_transition_segments.erase(segments_iterator++);
            }
      }
      else if ((itr_intervals == frozen_intervals.end()) &&
               (itr_intervals_previous != frozen_intervals.end()))
      {
         vector<string>::iterator itr_nodes_origin = std::find(frozen_nodes.begin(),
                                                               frozen_nodes.end(),
                                                               origin_node);
         if (itr_nodes_origin != frozen_nodes.end())
         {
            ++segments_iterator;
         }
         else
         {
            r_transition_segments.erase(segments_iterator++);
         }

      }
      else
      {
         ++segments_iterator;
      }
   }
}


void LpschAbstractSchedulesGenerator::copyCostsToTransitionNodes ()
{
   for (unsigned int i = 0; i < r_transitions.size(); i++)
   {
      string originRS;
      string destinationRS;
      string interval;

      if (r_transitions[i].originRSNode_ == r_initial_node)
      {
         originRS = r_initial_node;
      }
      else
      {
         getRSandIntervalFromNode (r_transitions[i].originRSNode_, originRS, interval);
      }

      if (r_transitions[i].destinationRSNode_ == "END")
      {
         destinationRS = "END";
         interval = "";
      }
      else
      {
         getRSandIntervalFromNode (r_transitions[i].destinationRSNode_, destinationRS, interval);
      }

      LpschTransitionSegmentKey key(originRS, destinationRS, interval);

      if (r_transition_segments.count(key) > 0)
      {
         double total_cost = r_transition_segments[key].getTotalCost();
         r_transitions[i].weight_ = total_cost;
      }
   }
}


vector<RSNode> LpschAbstractSchedulesGenerator::getNodes() const
{
   return r_nodes;
}


vector<RSTransitionSegment> LpschAbstractSchedulesGenerator::getTransitions() const
{
   return r_transitions;
}


bool LpschAbstractSchedulesGenerator::getRSandIntervalFromNode (string node, string & rs_id, string & interval_name)
{
   bool splitted = false;

   unsigned int start = 0, end = 0;
   if ((end = node.find('-', start)) != string::npos)
   {
     string rs_part = node.substr(start, end - start);
     string subinterval_part = node.substr(end + 1, node.size() - end);

     rs_id = rs_part;

     interval_name = subinterval_part;

     splitted = true;
   }

   return splitted;
}


string LpschAbstractSchedulesGenerator::getNodeName (unsigned int position) const
{
   string result = "";

   if ((position > 0) && (position < r_nodes.size()))
   {
      result = r_nodes[position].id_;
   }

   return result;
}


string LpschAbstractSchedulesGenerator::getNodeAlias (string rs_id, string interval_name)
{
   stringstream os;

   os << rs_id << "-" << interval_name;

   return os.str();
}


string LpschAbstractSchedulesGenerator::getPreviousInterval (string interval_name)
{
   //Extract a interval number
   string tmp_name(interval_name);
   boost::erase_all(tmp_name, "t");

   unsigned int interval_number= boost::lexical_cast<unsigned int>(tmp_name);

   string previous_interval = interval_name;

   if (interval_number > 0)
   {
      previous_interval.clear();
      previous_interval.append("t");
      previous_interval.append(boost::lexical_cast<std::string>(interval_number - 1));
   }

   return previous_interval;
}


LpdbAlternativeSchedule LpschAbstractSchedulesGenerator::generateManualSchedule(const LpiAlternativeSchedule & input)
{
   LpiTimeParameters parameters = LpdbDataBase::Get().getGlobalParameters().getTimeParameters();
   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   LpdbAlternativeSchedule generated;

   //Initialize internal timeline
   generated.init (parameters,
                   LpdbDataBase::Get().getTimeLineBase());

   std::vector<LpiTimeIntervalData> intervals_data = input.getScheduleTimeLine().getAllScheduleIntervals();

   if (intervals_data.size() > 0)
   {
      BOOST_FOREACH(LpiTimeIntervalData & interval, intervals_data)
      {
         string interval_name = interval.getName();

         string planned_rs = interval.getRSScheduled().getRunwaySystem();

         if (generated.has_data(interval_name) && rsTable.exists(planned_rs))
         {
            LpdbRunwaySystem rs = rsTable[planned_rs];
            LpdbRSScheduled rs_scheduled(rs);
            generated[interval_name].setRsScheduled(rs_scheduled);
         }
      }
   }

   return generated;
}


LpdbAlternativeSchedule LpschAbstractSchedulesGenerator::generateAlternativeSchedule(const LpiOptimizationCriteria & criteria)
{
   clearPonderationCriteria();

   LpdbDataBase::RunwaySystemTable & rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   vector<string> runway_systems = rsTable.getAllIds();

   string id = runway_systems[0];

   vector<string> intervals = rsTable[id].getTimeLine().getAllIntervalIds();
   vector<string> frozen = rsTable[id].getTimeLine().getFrozenIntervals();
   vector<string> notFrozen = rsTable[id].getTimeLine().getNotFrozenIntervals();

   string initial_node = "BEGIN";

   bool hasFrozenNodes = false;

   bool existsActiveSchedule = LpdbDataBase::Get().hasActiveSchedule();

   if (existsActiveSchedule)
   {
      LpdbAlternativeSchedule & active = LpdbDataBase::Get().getActiveSchedule();

      if (active.isManuallyActivated() && (frozen.size() > 0))
      {
         string lastFrozenInterval = frozen.back();

         TimeLine<LpdbSCHTimedData> schedule_timeline = active.getTimeLine();

         if (schedule_timeline.hasData(lastFrozenInterval))
         {
            initial_node = schedule_timeline[lastFrozenInterval].getRsScheduled().getRunwaySystemId();
            intervals = notFrozen;

            hasFrozenNodes = true;
         }
      }
   }

   setPonderationCriteria(criteria);

   createGraph(runway_systems, intervals, initial_node);

#ifdef TRACE_OUT
   //Logging
   if (hasFrozenNodes)
   {
      LclogStream::instance(LclogConfig::E_RTP).debug() << "[FROZEN DATA]: " << std::endl;
      LclogStream::instance(LclogConfig::E_RTP).debug() << "Active schedule has been manually activated, and there is frozen period." << std::endl;

      LclogStream::instance(LclogConfig::E_RTP).debug() << "Initial node: " << initial_node << ", Frozen intervals: ";
   
     // std::copy(frozen.begin(), frozen.end(), 
     // 	       std::ostream_iterator<std::string>(//rlog.debug(), " "));
      LclogStream::instance(LclogConfig::E_RTP).debug() << std::endl;
   }
   else
   {
      LclogStream::instance(LclogConfig::E_RTP).debug() << "[FROZEN DATA]: " << std::endl;
      LclogStream::instance(LclogConfig::E_RTP).debug() << "Active schedule has not been manually activated, or there is no frozen period." << std::endl;
   }

   LclogStream::instance(LclogConfig::E_RTP).debug() << "[ALGORITHM TRANSITION MATRIX WHAT-IF: NEW CRITERIA]: " << std::endl;
   LclogStream::instance(LclogConfig::E_RTP).debug() << getTransitionMatrixAsString() << std::endl;
#endif

   generateSchedules(initial_node, 1);

   LpdbSchedule solution;

   if (hasFrozenNodes)
   {
      vector<string> frozenOfActive(frozen);

      solution = getSolution(frozen, frozenOfActive, LpdbSchedule::E_ACTIVE);
   }
   else
   {
      solution = getBestSolution();
   }

   LpdbAlternativeSchedule alternative(solution);

   return alternative;
}


vector<string> LpschAbstractSchedulesGenerator::getFrozenNodesOfActiveSchedule(vector<string> frozenIntervals)
{
   vector<string> frozenNodes;

   LpdbDataBase & db = LpdbDataBase::Get();

   if (db.hasActiveSchedule())
   {
      LpdbAlternativeSchedule & active = db.getActiveSchedule();

      if (active.isManuallyActivated())
      {
         BOOST_FOREACH(string interval, frozenIntervals)
         {
            if (active.has_data(interval))
            {
               string plannedRS = active[interval].getRsScheduled().getRunwaySystemId();
               string node = getNodeAlias(plannedRS, interval);

               frozenNodes.push_back(node);
            }
         }
      }
   }

   return frozenNodes;
}


vector<string> LpschAbstractSchedulesGenerator::getFrozenNodesOfOptimalSchedule(vector<string> frozenIntervals)
{
   vector<string> frozenNodes;

   LpdbDataBase & db = LpdbDataBase::Get();

   if (db.hasOptimalSchedule())
   {
      LpdbSchedule & optimal = db.getOptimalSchedule();

      BOOST_FOREACH(string interval, frozenIntervals)
      {
         if (optimal.has_data(interval))
         {
            string plannedRS = optimal[interval].getRsScheduled().getRunwaySystemId();
            string node = getNodeAlias(plannedRS, interval);

            frozenNodes.push_back(node);
         }
      }
   }

   return frozenNodes;
}


LpdbAlternativeSchedule LpschAbstractSchedulesGenerator::generateAlternativeFromActive(LpdbAlternativeSchedule & active)
{
   LpiTimeParameters parameters = LpdbDataBase::Get().getGlobalParameters().getTimeParameters();
   LpdbDataBase::RunwaySystemTable rsTable = LpdbDataBase::Get().getRunwaySystemTable();

   LpdbAlternativeSchedule generated;

   //Initialize internal timeline
   generated.init (parameters,
                   LpdbDataBase::Get().getTimeLineBase());

   std::vector<std::string> intervals_data = active.getTimeLine().getAllIntervalIds();

   if (intervals_data.size() > 0)
   {
      BOOST_FOREACH(string & interval_name, intervals_data)
      {
         if (active.has_data(interval_name))
         {
            string planned_rs = active[interval_name].getRsScheduled().getRunwaySystemId();

            if (rsTable.exists(planned_rs))
            {
               LpdbRunwaySystem rs = rsTable[planned_rs];
               LpdbRSScheduled rs_scheduled(rs);
               generated[interval_name].setRsScheduled(rs_scheduled);
            }
         }
      }
   }

   return generated;
}


double LpschAbstractSchedulesGenerator::getTotalCost(LpdbSchedule & schedule)
{
   vector<string> intervals = schedule.getTimeLine().getAllIntervalIds();

   double totalCost = 0.0;

   for (unsigned int i = 0; i < intervals.size(); i++)
   {
      string interval = intervals[i];

      string previousInterval = "";
      string originRS = "BEGIN";
      string destinationRS = "";

      if (interval != "t0")
      {
         previousInterval = getPreviousInterval(interval);

         if (schedule.has_data(previousInterval))
         {
            LpdbRSScheduled plannedRS = schedule[previousInterval].getRsScheduled();
            originRS = plannedRS.getRunwaySystemId();
         }
      }

      if (schedule.has_data(interval))
      {
         LpdbRSScheduled plannedRS = schedule[interval].getRsScheduled();
         destinationRS = plannedRS.getRunwaySystemId();
      }

      LpschTransitionSegmentKey key(originRS, destinationRS, interval);

      if (r_transition_segments.count(key) > 0)
      {
         totalCost += r_transition_segments[key].getTotalCost();
      }
   }

   return totalCost;
}


void LpschAbstractSchedulesGenerator::printInputInterface(const RSScheduleRequest & request)
{
   std::ofstream output_log;

   std::string filename_base = "generator_input_interface_";
   std::string filename_extension = ".xml";

   static unsigned int filename_version = 0;

   filename_version++;

   std::string filename = filename_base + boost::lexical_cast<std::string>(filename_version) + filename_extension;

   output_log.open(filename.c_str(), std::ios::out | std::ios::trunc);

   //Print request data
   output_log << "Request: [ID: " << request.id_ << " | NUM_SCH: " << request.num_schedules_
              << " | START_NODE: " << request.start_node_id_<< " | END_NODE: " << request.end_node_id_ << "]" << std::endl;

   //Print Nodes
   output_log << "[NODES]\nNumber of nodes in interface: " << r_nodes.size() << std::endl;
   for (unsigned int i = 0; i < r_nodes.size(); ++i)
   {
      output_log << "Node: [ID: " << r_nodes[i].id_
                 << " | RS_ID: "  << r_nodes[i].runwaySystem_id_
                 << " | CONF_ID: "<< r_nodes[i].configuration_id_
                 << " | TYPE: "   << r_nodes[i].type_
                 << " | ALIAS: "  << r_nodes[i].alias_
                 << "]" << std::endl;
   }

   //Print Transitions
   output_log << "[TRANSITIONS]\nNumber of transitions in interface: " << r_transitions.size() << std::endl;
   for (unsigned int j = 0; j < r_transitions.size(); ++j)
   {
      output_log << "Transition: [ID: " << r_transitions[j].id_
                    << " | ORIG_RS_ID: " << r_transitions[j].originRSNode_
                    << " | DEST_RS_ID: " << r_transitions[j].destinationRSNode_
                    << " | TYPE: "       << r_transitions[j].type_
                    << " | WEIGHT: "     << r_transitions[j].weight_
                 << "]" << std::endl;
   }

   output_log.close();

}


void LpschAbstractSchedulesGenerator::printOutputInterface()
{
   std::ofstream output_log;

   std::string filename_base = "generator_output_interface_";
   std::string filename_extension = ".xml";

   static unsigned int filename_version = 0;

   filename_version++;

   std::string filename = filename_base + boost::lexical_cast<std::string>(filename_version) + filename_extension;

   output_log.open(filename.c_str(), std::ios::out | std::ios::trunc);

   //Print response data
   output_log << "[RESPONSE]\nNumber of schedules: " << r_algorithm_result.size() << std::endl;

   for (unsigned int i = 0; i < r_algorithm_result.size(); ++i)
   {
      output_log << "Schedule: [ID: "   << r_algorithm_result[i].id_
                 << " | NUM_NODES: "    << r_algorithm_result[i].nodes_.size()
                 << " | NUM_SEGMENTS: " << r_algorithm_result[i].segments_.size() << "\n";

      output_log << "[NODES]:\n";
      RSScheduleResponse response_data = r_algorithm_result[i];

      for (unsigned int j = 0; j < response_data.nodes_.size(); ++j)
      {
         output_log << "Node: " << response_data.nodes_[j] << "\n";
      }

      output_log << "[SEGMENTS]:\n";
      for (unsigned int j = 0; j < response_data.segments_.size(); ++j)
      {
         output_log << "Segment: " << response_data.segments_[j] << "\n";
      }

      output_log << "]" << std::endl;
   }

   output_log.close();
}
