/*
 * LpschAbstractSchedulesGenerator.h
 *
 *  Created on: 29/09/2014
 *      Author: mbegega
 */

#ifndef __LPSABSTRACT_SCHEDULES_GENERATOR_H__
#define __LPSABSTRACT_SCHEDULES_GENERATOR_H__


#include <vector>
#include <string>

#include <LpiAlternativeSchedule.h>
#include <LpiOptimizationCriteria.h>

#include <LpdbAlternativeSchedule.h>

#include "LpdbSchedule.h"
#include "LpschTransitionSegment.h"

#include "LpiMessages.h"

using std::vector;
using std::string;



//Template method design pattern

class LpschAbstractSchedulesGenerator
{
   public:

      LpschAbstractSchedulesGenerator ();
      LpschAbstractSchedulesGenerator (const LpschAbstractSchedulesGenerator & source);
      virtual ~LpschAbstractSchedulesGenerator () {}

      //Public interface
      void createGraph ();
      void createGraph (vector<string> runway_systems,
                        vector<string> time_intervals,
                        string initial_node = "",
                        LpiADOVector<int> initial_delayed = LpiADOVector<int>(0, 0, 0));

      void generateSchedules (string initial_node = "", int number_of_schedules = 1);

      //Common implemented interface
      void reset();
      //void setPreferentialLevels  (const LpiAdaptationRunwaySystemPreferenceList & preferential_levels);
      void setPonderationCriteria (const LpiOptimizationCriteria & ponderations);
      void clearPonderationCriteria();
      boost::optional<LpiOptimizationCriteria> getPonderationCriteria() const;

      void getPonderationsInInterval(string interval, double & arrival_ponderation, double & departure_ponderation);

      //void setStabilityCostMatrix (const LpiAdaptationMrtmTransitionCostTable & stability_table);

      void obtainRunwaySystems ();
      void obtainTimeIntervals ();

      //Default Schedule management
      //void generateDefaultSchedule ();
      //void forwardDefaultSchedule  ();

      boost::optional<LpdbSchedule> getDefaultSchedule ();
      //boost::optional<std::string> getDefaultRSInInterval(TimeInterval interval);


      //Solutions management
      vector<LpdbSchedule> getSolutions ();
      LpdbSchedule         getBestSolution ();
      LpdbSCHTimedData     getSolutionForInterval ();
      LpdbSchedule         getSolution(const vector<string> & frozenIntervals,
                                      const vector<string> & frozenOfActive,
                                      LpdbSchedule::ScheduleType whichSchedule);

      virtual void setCalculationParameters() = 0;
      virtual string getGeneratorName () const = 0;
      vector<RSNode> getNodes() const;
      vector<RSTransitionSegment> getTransitions() const;

      virtual void calculateTransitionCosts() = 0;
      virtual void printTransitionMatrix () const = 0;
      virtual std::string getTransitionMatrixAsString () const = 0;
      virtual std::string getMaxDCBSuitabilitiesAsString() const = 0;

      LpdbAlternativeSchedule generateManualSchedule(const LpiAlternativeSchedule & input);
      LpdbAlternativeSchedule generateAlternativeSchedule(const LpiOptimizationCriteria & criteria);
      LpdbAlternativeSchedule generateAlternativeFromActive(LpdbAlternativeSchedule & active);

      double getTotalCost(LpdbSchedule & schedule);

   protected:   //Internal auxiliary methods

      //Interface Methods to be implemented by concrete subclasses
      void copyCostsToTransitionNodes ();

      void createNodes       (string initial_node = "");
      void createTransitions (string initial_node = "");

      void filterFrozenNodes (vector<string> frozen_intervals, vector<string> frozen_nodes);

      bool getRSandIntervalFromNode (string node, string & rs_id, string & interval_name);
      string getNodeName (unsigned int position) const;
      string getNodeAlias (string rs_id, string interval_name);
      string getPreviousInterval (string interval_name);

      vector<string> getFrozenNodesOfActiveSchedule(vector<string> frozenIntervals);
      vector<string> getFrozenNodesOfOptimalSchedule(vector<string> frozenIntervals);

   protected:

      vector<string> r_runway_systems;
      vector<string> r_time_intervals;
      LpschTransitionSegmentCollection r_transition_segments;

      boost::optional<LpdbSchedule> r_default_schedule;

      //Interface with pathfinding library
      vector<RSNode> r_nodes;
      vector<RSTransitionSegment> r_transitions;
      vector<RSScheduleResponse>  r_algorithm_result;

      //Configuration and adaptation parameters
      //LpiAdaptationRunwaySystemPreferenceList  r_preferential_levels;

      //Manual parameters from what-if requests
      boost::optional<LpiOptimizationCriteria> r_ponderation_criteria;

      //LpiAdaptationMrtmTransitionCostTable r_stability_table;

      string r_initial_node;
      LpiADOVector<int> r_initial_delayed;

      void printInputInterface(const RSScheduleRequest & request);
      void printOutputInterface();
};


#endif /* __LPSABSTRACT_SCHEDULES_GENERATOR_H__ */
