/*
 * LpschTransitionSegment.h
 *
 *  Created on: 29/09/2014
 *      Author: mbegega
 */

#ifndef __LPSTRANSITION_SEGMENT_H__
#define __LPSTRANSITION_SEGMENT_H__

#include <map>
#include <iostream>
#include <LpiComposedKey.h>
#include <LpiADOVector.h>

using std::ostream;

class LpschTransitionSegment
{
   public:
      LpschTransitionSegment();
      LpschTransitionSegment(const LpschTransitionSegment & source);
      virtual ~LpschTransitionSegment() {}

      LpschTransitionSegment & operator= (const LpschTransitionSegment & source);

      LpiADOVector<double> getAccDCMargin() const;
      LpiADOVector<double> getAccDCBSuitability() const;
      LpiADOVector<double> getAccDCBNormalizedSuitability() const;
      LpiADOVector<double> getEstimatedNotAllowed() const;

      double getAccDCBSuitabilityWeighted() const;
      double getDCBCost() const;
      double getStabilityCost() const;
      double getPreferentialCost() const;
      double getTotalCost() const;
      double getSOd() const;

      LpschTransitionSegment & setAccDCMargin (const LpiADOVector<double> & cost);
      LpschTransitionSegment & setAccDCBSuitability(const LpiADOVector<double> & cost);
      LpschTransitionSegment & setAccDCBNormalizedSuitability(const LpiADOVector<double> & cost);
      LpschTransitionSegment & setEstimatedNotAllowed(const LpiADOVector<double> & estimatedNotAllowed);

      LpschTransitionSegment & setAccDCBSuitabilityWeighted(double & cost);
      LpschTransitionSegment & setDCBCost(double cost);
      LpschTransitionSegment & setStabilityCost(double cost);
      LpschTransitionSegment & setPreferentialCost(double cost);
      LpschTransitionSegment & setTotalCost(double cost);
      LpschTransitionSegment & setSOd(double value);

   protected:

      LpiADOVector<double> r_acc_dc_margin;
      LpiADOVector<double> r_acc_dcb_suitability;
      LpiADOVector<double> r_acc_dcb_normalized_suitability;
      LpiADOVector<double> r_estimated_not_allowed;

      double r_acc_dcb_suituability_weighted;

      double r_cost_dcb;
      double r_cost_stab;
      double r_cost_pref;

      double r_cost_tot;
      double r_SOd;         //Excess in case of mixed runways
 };


typedef LpiComposedKey<string, string, string> LpschTransitionSegmentKey; //<Origin RS, Destination RS, interval>
typedef LpiComposedKeyPair<string, string> LpschOriginRSAndIntervalKey;   //<Origin RS, interval>

class LpschOriginRSAndIntervalKeyComparer {
public:

    bool operator()(const LpschOriginRSAndIntervalKey & leftOperand, const LpschOriginRSAndIntervalKey & rightOperand) const;
};



class LpschTransitionSegmentComparer {
public:

    bool operator()(const LpschTransitionSegmentKey & leftOperand, const LpschTransitionSegmentKey & rightOperand) const;

};


typedef std::map<LpschTransitionSegmentKey, LpschTransitionSegment, LpschTransitionSegmentComparer> LpschTransitionSegmentCollection;

ostream & operator<< (ostream & out, const LpschTransitionSegment & segment);

#endif /* __LPSTRANSITION_SEGMENT_H__ */
