/*
 * LpschDynamicDemandSchedulesGenerator.h
 *
 *  Created on: 29/09/2014
 *      Author: mbegega
 */

#ifndef __LPSDYNAMICDEMAND_SCHEDULES_GENERATOR_H__
#define __LPSDYNAMICDEMAND_SCHEDULES_GENERATOR_H__

#include <vector>
#include <string>
#include <map>
#include <limits>
#include <boost/optional.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/math/distributions/normal.hpp>

#include "LpschAbstractSchedulesGenerator.h"
#include <LpiADOVector.h>

using std::vector;
using std::string;


//Singleton design pattern

class LpschDynamicDemandSchedulesGenerator : public LpschAbstractSchedulesGenerator
{
   public:

      LpschDynamicDemandSchedulesGenerator (const LpschDynamicDemandSchedulesGenerator & source);
      virtual ~LpschDynamicDemandSchedulesGenerator () { }

      static boost::shared_ptr<LpschDynamicDemandSchedulesGenerator> & Get ();

      virtual std::string getMaxDCBSuitabilitiesAsString() const;

   protected: //Internal auxiliary methods

      LpschDynamicDemandSchedulesGenerator ();

      //Interface method redefined from AbstractSchedulesGenerator
      virtual void setCalculationParameters();
      virtual void calculateTransitionCosts();

      void reset();
      void calculateDCBCosts();
      void calculateStabilityPreferentialAndTotalCosts();

      void calculateDCBCost            (LpschTransitionSegmentKey segmentId);
      void calculateStabilityCost      (LpschTransitionSegmentKey segmentId);

      ///@todo FIXME RMAN code commented
      //void calculatePreferentialRSCost (LpschTransitionSegmentKey segmentId);

      void calculateTotalCost          (LpschTransitionSegmentKey segmentId);

      bool checkNoCapacityNode         (LpschTransitionSegmentKey segmentId);
      bool isProhibitedNode            (LpschTransitionSegmentKey segmentId);

      ///@warning RMAN only: DCB Suitability
      //For internal DCB costs calculations
      void calculateAccDCMargin                (LpschTransitionSegmentKey segmentId);
      void calculateAccDCBSuitability          (LpschTransitionSegmentKey segmentId);
      void calculateAccDCBSuitabilityWeighted  (LpschTransitionSegmentKey segmentId);

      void updateMaxDCBSuitabilitiesByInterval(LpschTransitionSegmentKey segmentId);
      void normalizeDCBSuitability(LpschTransitionSegmentKey segmentId);

      LpiADOVector<double> getEstimatedNotAllowed(const string & originNode,
                                                  const string & destinationNode,
                                                  const string & interval);

      virtual string getGeneratorName () const { return "LpschDynamicDemandSchedulesGenerator"; }

      //For testing purposes
      virtual void printTransitionMatrix () const;
      virtual std::string getTransitionMatrixAsString () const;

   protected:

      double r_dcbWeight;
      double r_stabilityWeight;
      double r_preferentialWeight;

      boost::math::normal r_statisticDistribution;

      map<LpschOriginRSAndIntervalKey, LpiADOVector<double>, LpschOriginRSAndIntervalKeyComparer> r_max_suitabilities;
      const double DISCONNECT;
};


#endif /* __LPSDYNAMICDEMAND_SCHEDULES_GENERATOR_H__ */
