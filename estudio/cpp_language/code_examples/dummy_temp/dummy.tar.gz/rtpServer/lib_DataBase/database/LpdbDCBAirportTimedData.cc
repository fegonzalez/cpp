/*
 * LpdbDCBAirportTimedData.cc
 *
 *  Created on: 09/04/2015
 *      Author: mbegega
 *
 *  Description:
 *      Data used in Estimated DCB for schedules generation algorithm improvements in Phase III
 */


#include "LpdbDCBAirportTimedData.h"


LpdbDCBAirportTimedData::LpdbDCBAirportTimedData()
: r_maxAirportCapacity(),
  r_minDelayedFPs(),
  r_priorityOperation(E_ARR)
{

}


LpdbDCBAirportTimedData::LpdbDCBAirportTimedData(const LpdbDCBAirportTimedData & source)
: r_maxAirportCapacity(source.r_maxAirportCapacity),
  r_minDelayedFPs(source.r_minDelayedFPs),
  r_priorityOperation(E_ARR)
{

}


LpdbDCBAirportTimedData::~LpdbDCBAirportTimedData()
{

}


LpdbDCBAirportTimedData & LpdbDCBAirportTimedData::operator =(const LpdbDCBAirportTimedData & source)
{
   if (this != &source)
   {
      r_maxAirportCapacity = source.r_maxAirportCapacity;
      r_minDelayedFPs = source.r_minDelayedFPs;
      r_priorityOperation = source.r_priorityOperation;
   }

   return *this;
}


LpiADOVector<int> LpdbDCBAirportTimedData::getMaxAirportCapacity() const
{
   return r_maxAirportCapacity;
}


void LpdbDCBAirportTimedData::setMaxAirportCapacity(LpiADOVector<int> capacity)
{
   r_maxAirportCapacity = capacity;
}


LpiADOVector<int> LpdbDCBAirportTimedData::getMinDelayedFPs() const
{
   return r_minDelayedFPs;
}


void LpdbDCBAirportTimedData::setMinDelayedFPs(LpiADOVector<int> minimumDelayedFPs)
{
   r_minDelayedFPs = minimumDelayedFPs;
}


int LpdbDCBAirportTimedData::getPriorityOperation() const
{
   return r_priorityOperation;
}


void LpdbDCBAirportTimedData::setPriorityOperation(int operation)
{
   r_priorityOperation = operation;
}

std::ostream & operator<<(std::ostream & os, const LpdbDCBAirportTimedData & info)
{
   return os << " [ MAX_AIRPT_CAP: " << info.getMaxAirportCapacity()
             << " | MIN_DLYD_FPs: " << info.getMinDelayedFPs()
             << " | PRIORITY OP: " << ((info.getPriorityOperation() == E_ARR) ? "E_ARR" : "E_DEP")
             << ']';
}


