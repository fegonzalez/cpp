/*
 * LpdbAirport.cc
 *
 */

#include "LpdbAirport.h"
#include <LpiConfigurationCoreParameters.h>
#include <LclogStream.h>

#include <iostream>
#include <string>
#include <algorithm>    // std::for_each
#include <functional>   // bind
#include <cassert>
#include <boost/optional.hpp>

	  
LpdbAirport::LpdbAirport(std::string id,
			 unsigned int totalMovAirportUpperThreshold,
			 unsigned int totalMovAirportLowerThreshold,
			 unsigned int vfrAirportUpperThreshold,
			 unsigned int vfrAirportLowerThreshold,
			 unsigned int N1,
			 const AirportMaxNominalCapacity &airportNominal,
			 const LpiADOVector<unsigned int> &taxywaysMaxNominal,
			 const LpiADOVector<unsigned int> &tmaMaxNominal,
			 const Max_ILS_Category &maxILS,
	 		 const RunwaysAirportsList &runways,
			 const PonderationAirports & complexityWeights)
  : theAirportName(id),
    theTotalMovAirportUpperThreshold(totalMovAirportUpperThreshold / N1),
    theTotalMovAirportLowerThreshold(totalMovAirportLowerThreshold / N1),
    theVfrAirportUpperThreshold(vfrAirportUpperThreshold / N1),
    theVfrAirportLowerThreshold(vfrAirportLowerThreshold / N1),
    theMaxILsCategory(maxILS),
    the_capacity(airportNominal, taxywaysMaxNominal, tmaMaxNominal, id),
    the_complexity(id,
		   theTotalMovAirportUpperThreshold,
		   theTotalMovAirportLowerThreshold,
		   theVfrAirportUpperThreshold,
		   theVfrAirportLowerThreshold,
		   complexityWeights.getWeightLVP(),
		   complexityWeights.getWeightIce(),
		   complexityWeights.getWeightTotalMovAirport(),
		   complexityWeights.getWeightVfrAirport())
{
  setRunways(runways);
}


unsigned int LpdbAirport::getTotalMovAirportUpperThreshold()const
{return theTotalMovAirportUpperThreshold; }

unsigned int LpdbAirport::getTotalMovAirportLowerThreshold()const
{return theTotalMovAirportLowerThreshold; }

unsigned int LpdbAirport::getVfrAirportUpperThreshold()const
{ return theVfrAirportUpperThreshold; }

unsigned int LpdbAirport::getVfrAirportLowerThreshold()const
{ return theVfrAirportLowerThreshold; }

Max_ILS_Category LpdbAirport::getMaxILS()const
{ return theMaxILsCategory; }

void LpdbAirport::setAirportId(std::string id)
{
  theAirportName = id;
}


void LpdbAirport::forwardTimeline()
{
  forwardTimeLineMeteo();
  forwardTimeLineDemand();
  forwardCapacity();
  forwardComplexity();
}


////////////////////////////////////////
/// Capacity data
////////////////////////////////////////

LpiADOVector<unsigned int> LpdbAirport::get_taxywaysNominalCapacity()const
{ return the_capacity.get_taxywaysNominalCapacity(); }

LpiADOVector<unsigned int> LpdbAirport::get_tmaNominalCapacity()const
{ return the_capacity.get_tmaNominalCapacity(); }

LpiADOVector<unsigned int> LpdbAirport::getNominalCapacity()const
{ return the_capacity.getNominalCapacity(); }



//--------------------------------------------------------------
// INIT EVENT

// INIT event, step 1; called from LpdbDataBase::init()
void LpdbAirport::initCapacity(const LpiTimeParameters & timeData,
			       const boost::posix_time::ptime &begin_timestamp)
{
  // note.- nominal airport, TMA, and TWY were created in the constructor.
  the_capacity.init(timeData,
		    begin_timestamp,
		    get_tmaNominalCapacity(),
		    get_taxywaysNominalCapacity());
}


// INIT event, step 2: called from  LpdBusinessLogicFacade::complete(void)
//
// (also called upon events: update meteo nowcast, update meteo forecast)
//
void LpdbAirport::calculateMaxCapacity()
{
  the_capacity.calculateMaxCapacity();
}

//--------------------------------------------------------------
// CLOCK EVENT

// CLOCK event, step 1; called from LpdbDataBase::forwardTimeline()
void LpdbAirport::forwardCapacity()
{
  the_capacity.forward();
}

// CLOCK event, step 2; called from 
//       LpdBusinessLogicFacade::calculateMaxCapacities(std::string interval)
void LpdbAirport::forwardCapacity (std::string interval)
{
  the_capacity.forward(interval);
}


////////////////////////////////////////
/// Complexity data
////////////////////////////////////////


//--------------------------------------------------------------
// INIT EVENT

// INIT event, step 1; called from LpdbDataBase::init()
void LpdbAirport::initComplexity(const LpiTimeParameters & timeData,
				 const boost::posix_time::ptime &begin_timestamp)
{
	  std::clog << "Test complexity (sequence diagram)"
	      << " ; File: " << __FILE__
	      << " ; fn: " << __func__
	      << " ; line: " << __LINE__
	      << std::endl;

  the_complexity.init(timeData, begin_timestamp);
}


// INIT event, step 2: called from  LpdBusinessLogicFacade::complete(void)
//
// (also called upon events: update meteo nowcast, 
//                           update meteo forecast, 
//                           update demand)
//
void LpdbAirport::calculateComplexity()
{
	  std::clog << "Test complexity (sequence diagram)"
	      << " ; File: " << __FILE__
	      << " ; fn: " << __func__
	      << " ; line: " << __LINE__
	      << std::endl;

  the_complexity.calculateComplexity();
}

//--------------------------------------------------------------
// CLOCK EVENT

// CLOCK event, step 1; called from LpdbDataBase::forwardTimeline()
void LpdbAirport::forwardComplexity()
{
	  std::clog << "Test complexity (sequence diagram)"
	      << " ; File: " << __FILE__
	      << " ; fn: " << __func__
	      << " ; line: " << __LINE__
	      << std::endl;

  the_complexity.forward();
}

// CLOCK event, step 2; called from 
//       LpdBusinessLogicFacade::calculateMaxComplexities(std::string interval)
void LpdbAirport::forwardComplexity (std::string interval)
{
	  std::clog << "Test complexity (sequence diagram)"
	      << " ; File: " << __FILE__
	      << " ; fn: " << __func__
	      << " ; line: " << __LINE__
	      << std::endl;
  the_complexity.forward(interval);
}



////////////////////////////////////////
/// Meteo data
////////////////////////////////////////


unsigned int LpdbAirport::getNumberOfMeteoReportsReceived ()// const
{
   return r_meteoReports.size();
}


std::vector<LpiMeteoInfo> LpdbAirport::getReceivedMeteoReports () //const
{
   return r_meteoReports;
}

///@warning: assert index < getNumberOfMeteoReportsReceived() before call
LpiMeteoInfo LpdbAirport::getMeteoReport (const unsigned int index)
{
  assert(index < getNumberOfMeteoReportsReceived());
  return r_meteoReports[index];
}


void LpdbAirport::addMeteoReport (const LpiMeteoInfo &report)
{
   r_meteoReports.push_back(report);
}

void LpdbAirport::deleteMeteoReport (unsigned int index)
{
   if (index < r_meteoReports.size())
   {
      r_meteoReports.erase(r_meteoReports.begin() + index);
   }
}

void LpdbAirport::deleteObsoleteMeteoReports()
{
  auto condition = [this](const LpiMeteoInfo &meteo )
  {
    return( getMeteoForecast().getInitialTime().is_initialized() and
	    (meteo.getEndTimeAndDate() <= 
	     getMeteoForecast().getInitialTime().get()) );
  };

  r_meteoReports.erase( std::remove_if(r_meteoReports.begin(), 
				       r_meteoReports.end(), 
				       condition), r_meteoReports.end() );
}


/**@warning getLastReceivedMeteoReport: UNUSED in RMAN
boost::optional<LpiMeteoInfo> LpdbAirport::getLastReceivedMeteoReport () const
{
   boost::optional<LpiMeteoInfo> meteo_report;

   if (r_meteoReports.size() > 0)
   {
      int last_element = r_meteoReports.size() - 1;
      meteo_report = r_meteoReports[last_element];
   }

   return meteo_report;
}
*/


void LpdbAirport::forwardTimeLineMeteo()
{
  r_meteoLine.forward();
  
  //   Creates default element in newly created interval
  r_meteoLine.createElement(r_meteoLine.getLastInterval());
}


////////////////////////////////////////
/// Demand data
////////////////////////////////////////


void LpdbAirport::forwardTimeLineDemand()
{
  r_demand.forward();
}


////////////////////////////////////////
/// Runways data
////////////////////////////////////////


void LpdbAirport::setRunways(const RunwaysAirportsList &runways)
{
  theRunways.clear();
  std::for_each(std::begin(runways),
		std::end(runways),
		[this](const RunwaysAirports &new_rwy)
  {
    theRunways.addElement(new_rwy.getRunwayName(), new_rwy);
  });
  
  assert(runways.size()==static_cast<size_t>(theRunways.getNumberOfElements()));
}

//-----------------------------------------------------------------------------

std::ostream& operator<<(std::ostream & os, const LpdbAirport & obj)
{
  return os << "[ID: " << obj.getAirportId() 
	    << " | totalMovAirportUpperThreshold: "
	    << obj.getTotalMovAirportUpperThreshold()
	    << " | totalMovAirportLowerThreshold: "
	    << obj.getTotalMovAirportLowerThreshold()
	    << " | VfrAirportUpperThreshold: "
	    << obj.getVfrAirportUpperThreshold()
	    << " | VfrAirportLowerThreshold: "
	    << obj.getVfrAirportLowerThreshold()
	    << ']';
}

//-----------------------------------------------------------------------------

