/**@file LpdbAirportComplexityTimedData.h
 * 
 * complexity per interval data for a concrete airport.
 */

#ifndef LPDBAIRPORTCOMPLEXITYTIMEDDATA_H_
#define LPDBAIRPORTCOMPLEXITYTIMEDDATA_H_

#include <LplcTypeConstants.h>
//#include <LpiADOVector.h>
#include <iosfwd>


class LpdbAirportComplexityTimedData
{

public:

  LpdbAirportComplexityTimedData() = default;
  LpdbAirportComplexityTimedData(const LpdbAirportComplexityTimedData & source) = default;
  LpdbAirportComplexityTimedData & operator= (const LpdbAirportComplexityTimedData & source) = default;
  virtual ~LpdbAirportComplexityTimedData() {};

  //  LpiADOVector<rtp_constants::TYPE_COMPLEXITY> getComplexity() const { return r_complexity; }
  rtp_constants::TYPE_COMPLEXITY getComplexity() const
    { return r_complexity;}
  
    //  void setComplexity(const LpiADOVector<rtp_constants::TYPE_COMPLEXITY> &new_val)
  void setComplexity(const rtp_constants::TYPE_COMPLEXITY &new_val)
  { r_complexity = new_val; }

  void initComplexity()
  { r_complexity = rtp_constants::DEFAULT_COMPLEXITY_VALUE; }

 protected:

  //  LpiADOVector<rtp_constants::TYPE_COMPLEXITY> r_complexity =
  rtp_constants::TYPE_COMPLEXITY r_complexity =
    rtp_constants::DEFAULT_COMPLEXITY_VALUE;
};

std::ostream& operator<<(std::ostream &os,const LpdbAirportComplexityTimedData &);


#endif /* LPDBRUNWAYSYSTEMTIMEDDATA_H_ */
