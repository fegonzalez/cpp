/*
 * LpdbRunwaySystemRunwayTimedData.h
 *
 *  Created on: 17/02/2014
 *  Author: mbegega
 */

#ifndef RUNWAYSYSTEMRUNWAYTIMEDDATA_H_
#define RUNWAYSYSTEMRUNWAYTIMEDDATA_H_

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <LpiADOVector.h>


using std::vector;
using std::string;


class LpdbRunwaySystemRunwayTimedData
{
public:

   LpdbRunwaySystemRunwayTimedData();

   LpdbRunwaySystemRunwayTimedData(const LpdbRunwaySystemRunwayTimedData & source);

   virtual ~LpdbRunwaySystemRunwayTimedData();

   LpdbRunwaySystemRunwayTimedData & operator= (const LpdbRunwaySystemRunwayTimedData & source);


   //Getters and Setters
   std::string get_name () const;

   LpiADOVector<int> getMaxCapacity() const;
   void setMaxCapacity(LpiADOVector<int> maxCapacity);

   LpiADOVector<int> getMaxCapacityCalculated() const;
   void setMaxCapacityCalculated(LpiADOVector<int> maxCapacity);

   LpiADOVector<double> getDependencyCapacityReduction() const;
   void setDependencyCapacityReduction(LpiADOVector<double> capacity);

   LpiADOVector<double> getFileCapacityReduction() const;
   void setFileCapacityReduction(LpiADOVector<double> capacity);

   LpiADOVector<double> getWakeVortexCapacityReduction() const;
   void setWakeVortexCapacityReduction(LpiADOVector<double> capacity);

protected:

   std::string r_name;

   LpiADOVector<int> r_max_capacity;
   LpiADOVector<int> r_max_capacity_calculated;
   LpiADOVector<double> r_dependency_capacity_reduction;
   LpiADOVector<double> r_file_capacity_reduction;
   LpiADOVector<double> r_wtc_capacity_reduction;
};


std::ostream& operator<<(std::ostream &os, const LpdbRunwaySystemRunwayTimedData &info);

#endif /* RUNWAYSYSTEMRUNWAYTIMEDDATA_H_ */
