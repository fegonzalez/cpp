/*
 * LpdbAirport.h
 *
 * @warning LpdbAirport: process info from DAORTP_AirportsInfo.xml.
 *
 * DOC Reference: [1] "2018-08-03 RTP Diseño Funcional.docx"
 *
 */

#ifndef LPDBAIRPORT_H_
#define LPDBAIRPORT_H_

#include <LplcTypeConstants.h>
#include <LpiADOVector.h>
#include <LpiAdaptationAirportsInfo.h>
#include <LpdbMeteoTimedData.h>
#include <LctimTimeLine.h>
#include <LpdbDemand.h>
#include <LpiMeteoInfo.h>
#include <LpdbAirportCapacity.h>
#include <LpdbAirportComplexity.h>
#include <LpdbTMA.h>
#include <LpdbTWY.h>
#include <LpdbRunway.h>

#include <string>
#include <vector>
#include <boost/optional.hpp>


class PonderationAirports;

class LpdbAirport
{
 public:

  LpdbAirport(std::string id,
	      unsigned int totalMovAirportUpperThreshold,
	      unsigned int totalMovAirportLowerThreshold,
	      unsigned int vfrAirportUpperThreshold,
	      unsigned int vfrAirportLowerThreshold,
	      unsigned int N1,
	      const AirportMaxNominalCapacity &airportNominal,
	      const LpiADOVector<unsigned int> &taxywaysMaxNominal,
	      const LpiADOVector<unsigned int> &tmaMaxNominal,
	      const Max_ILS_Category &maxILS,
	      const RunwaysAirportsList &runways,
	      const PonderationAirports & complexityWeights);

  LpdbAirport()=default;
  LpdbAirport(const LpdbAirport & source)=default;
  LpdbAirport & operator= (const LpdbAirport & source) = default;
  virtual ~LpdbAirport() {}

  std::string getAirportId() const  { return theAirportName; }
  RunwayTable & getRunways() { return theRunways; }

  unsigned int getTotalMovAirportUpperThreshold()const;
  unsigned int getTotalMovAirportLowerThreshold()const;
  unsigned int getVfrAirportUpperThreshold()const;
  unsigned int getVfrAirportLowerThreshold()const;
  Max_ILS_Category getMaxILS()const;


  void setAirportId(std::string id);


  //Forwards internal timeline in one interval
  void forwardTimeline();


  ////////////////////////////////////////
  /// Capacity data
  ////////////////////////////////////////
  LpdbAirportCapacity & getCapacity()
  { return the_capacity; }

  //  inline LpiADOVector<unsigned int> getNominalCapacity()const;
  LpiADOVector<unsigned int> getNominalCapacity()const;
  inline LpiADOVector<unsigned int> get_taxywaysNominalCapacity()const;
  inline LpiADOVector<unsigned int> get_tmaNominalCapacity()const;

  void initCapacity(const LpiTimeParameters & timeData,
		  const boost::posix_time::ptime &begin_timestamp);
  void calculateMaxCapacity ();
  void forwardCapacity();
  void forwardCapacity (std::string interval);


  ////////////////////////////////////////
  /// Complexity data
  ////////////////////////////////////////
  LpdbAirportComplexity & getComplexity()
  { return the_complexity; }

  void initComplexity(const LpiTimeParameters & timeData,
		  const boost::posix_time::ptime &begin_timestamp);
  void calculateComplexity();
  void forwardComplexity();
  void forwardComplexity(std::string interval);



  ////////////////////////////////////////
  /// Demand data
  ////////////////////////////////////////

  LpdbDemand & getDemand()
  { return r_demand; }
  

  ////////////////////////////////////////
  /// Meteo data
  ////////////////////////////////////////

  TimeLine<LpdbMeteoTimedData> & getMeteoForecast()
  {
    return r_meteoLine;
  }

 
  void setMeteoForecast(const TimeLine<LpdbMeteoTimedData> & data)
  {
    r_meteoLine = data;
  }


  //Forwards internal timeline in one interval
  unsigned int getNumberOfMeteoReportsReceived (); //const;
  std::vector<LpiMeteoInfo> getReceivedMeteoReports (); // const;
  LpiMeteoInfo getMeteoReport (const unsigned int index);
  void addMeteoReport (const LpiMeteoInfo &report);
  void deleteMeteoReport (unsigned int index);
  void deleteObsoleteMeteoReports();//remove ALL obsolete reports

  /**@warning getLastReceivedMeteoReport: UNUSED in RMAN
  boost::optional<LpiMeteoInfo> getLastReceivedMeteoReport () const;
  */

  
 protected:

  ///////////////////////////////////////////////////////////////
  ///data area
  ///////////////////////////////////////////////////////////////

  std::string theAirportName;
  RunwayTable theRunways; //note.-  only 1 or 2 in RTP airports


  ////////////////////////////////////////
  /// Adaptation data
  ///
  ////////////////////////////////////////


  // (airport/interval) thresholds & prohibitions (see [1].4.1)
  //
  // ComplexityAirportsThresholds: used for complexity calculations
  //
  // i) total movements (DAORTP_AirportsInfo.xml) 
  unsigned int theTotalMovAirportUpperThreshold;
  unsigned int theTotalMovAirportLowerThreshold;
  // ii) VFR flight (DAORTP_AirportsInfo.xml)
  unsigned int theVfrAirportUpperThreshold;
  unsigned int theVfrAirportLowerThreshold;


  Max_ILS_Category theMaxILsCategory;  //used for capacity calculations


  /*@param theAirportAdapData
    @brief Saves the daptationAirportsInfo loaded for the airport.
    @warning Faster access to the daptationAirportsInfo for the airport,

    LvpActivacionConditonsList _lvpActivationConditions;
    CatILsList _catILs;
    ComplexityAirportsThresholds _complexityThresholds;
   */
  /// Airport theAirportAdapData; ///@todo iff required



  ////////////////////////////////////////
  /// Capacity data
  ///
  ///@param the_capacity: central management of all capacity data for
  ///       the airport (see [1].4.3.1)
  ///
  ////////////////////////////////////////
  LpdbAirportCapacity the_capacity;


  ////////////////////////////////////////
  /// Complexity data
  ///
  ///@param the_complexity: central management of all complexity data for
  ///       the airport (see [1].4.3.2)
  ///
  ////////////////////////////////////////
  LpdbAirportComplexity the_complexity;


  ////////////////////////////////////////
  /// Demand data
  ////////////////////////////////////////
  LpdbDemand                   r_demand;


  ////////////////////////////////////////
  /// Meteo data
  ////////////////////////////////////////

  /**@param r_meteoLine
   *
   * @brief Storing the meteo information actually required for the
   *        RTP's logic calculations (complexity and capacity)
   *        calculations.
   *
   * Stored info: TimeLine<LpdbMeteoTimedData>: one meteo data per
   *              interval, thus every new meteo report received will
   *              replace the current one stored.
   *
   * - Use case: new meteo nowcast received: storage the new data
   *             (substitution of the old one)
   *
   * - Use case: new meteo forecast received: storage the new data
   *             (substitution of the old one)
   *
   * - Use case: forward timeline: remove obsolete data & add data for
   *             the new (last) interval.
   *  
   * @info class LpdbMeteoTimelineConverter: 
   *             converter TimeLine<LpdbMeteoTimedData> => LpiMeteoTimeline
   */
  TimeLine<LpdbMeteoTimedData> r_meteoLine;

  
  /**@param r_meteoReports: last meteo reports received (nowcast or forecast)
   *
   * @brief Used to manage the logic of forwardTimeLine at LpdBusinessLogicFacade::reviewMeteoInfo:
   *        For every report stored, update DB's timeline for that period: period is active
   *                               , remove report: if obsolete
   *
   * @warning (use case: new meteo now/fore msg) Just adds all the new reports received,
   *          thus repeated data can exists for any (airport, interval) pair.
   *          Note/Hint.- the most recent info is stored at the end of the vector.
   *
   */
  vector<LpiMeteoInfo> r_meteoReports;


  ///////////////////////////////////////////////////////////////
  ///methods area
  ///////////////////////////////////////////////////////////////
  
  void forwardTimeLineMeteo();
  void forwardTimeLineDemand();

  void setRunways(const RunwaysAirportsList &runways);

};

std::ostream& operator<<(std::ostream &os, const LpdbAirport &obj);

#endif /* LPDBAIRPORT_H_ */
