/*
 * LpcSchedulesComparison.h
 *
 *  Created on: 07/01/2015
 *      Author: mbegega
 */

#ifndef LPCSCHEDULESCOMPARISON_H_
#define LPCSCHEDULESCOMPARISON_H_

#include <IOComparisonSchedules.h>
#include <LpiSchedulesComparison.h>

class LpcSchedulesComparison
{
   public:
      static void convertIO2Lpi(const IOComparisonSchedules::ComparisonSchedules & in,
                                LpiSchedulesComparison & out);

      static void convertLpi2IO(const LpiSchedulesComparisonResponse & in,
                                IOComparisonSchedules::ComparisonSchedulesCalculate & out);
};


#endif /* LPCSCHEDULESCOMPARISON_H_ */
