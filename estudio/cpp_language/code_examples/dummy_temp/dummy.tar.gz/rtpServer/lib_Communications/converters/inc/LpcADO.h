
#ifndef LPCADO_H
#define LPCADO_H

#include <LclogStream.h>

#include <LpiADO.h>
#include <LpiWarningsAlerts.h>
#include <IOConstant.h>
#include <IOKPIs.h>

class LpcAdo
{
   public:

      static LpiADO IOADO2LpiADO(const IOConst::VectorADO & iOvector)
      {
         LpiADO lpivector;

         lpivector.setarrivalsValue(float(iOvector.arrivals));
         lpivector.setdeparturesValue(float(iOvector.departures));
         lpivector.setoverallValue(float(iOvector.overall));

         return lpivector;
      }

      static IOConst::VectorADO  lpiADO2IOADO(const LpiADO & lpivector)
      {
         IOConst::VectorADO ioAdo;

         ioAdo.arrivals = lpivector.getarrivalsValue();
         ioAdo.departures = lpivector.getdeparturesValue();
         ioAdo.overall = lpivector.getoverallValue();

         return ioAdo;
      }

      static IOConst::VectorADO Lpi2IO(LpiADO vado)
      {
          IOConst::VectorADO vIOAdo;

          vIOAdo.arrivals  = vado.getarrivalsValue();
          vIOAdo.departures= vado.getdeparturesValue();
          vIOAdo.overall   = vado.getoverallValue();

          return vIOAdo;
      }

      static void LpiAlertEnumeration2IO (const Warnings_alerts::LpiEnum & in, IOKPIs::AlertType & out)
      {
         switch (in)
         {
            case Warnings_alerts::E_NO_ALERT:
               out= IOKPIs::E_NO_ALERT;
            break;
            case Warnings_alerts::E_WARNING:
               out= IOKPIs::E_WARNING;
            break;
            case Warnings_alerts::E_ALARM:
               out= IOKPIs::E_ALARM;
            break;
            case Warnings_alerts::E_SLIGHT_IMPROVEMENT:
               out= IOKPIs::E_SLIGHT_IMPROVEMENT;
            break;
            case Warnings_alerts::E_IMPROVEMENT:
               out= IOKPIs::E_IMPROVEMENT;
            break;
            default:
               out= IOKPIs::E_NO_ALERT;
            break;
         }
      }


      static IOKPIs::Warnings_alerts Lpi2IO(Warnings_alerts warningLpi)
      {
         IOKPIs::Warnings_alerts warningIO;

         LpcAdo::LpiAlertEnumeration2IO(warningLpi.getarrivals(),   warningIO.arrivals);
         LpcAdo::LpiAlertEnumeration2IO(warningLpi.getdepartures(), warningIO.departures);
         LpcAdo::LpiAlertEnumeration2IO(warningLpi.getoverall(),    warningIO.overall);

         return warningIO;
      }
};


#endif /* LPCADO_H */
