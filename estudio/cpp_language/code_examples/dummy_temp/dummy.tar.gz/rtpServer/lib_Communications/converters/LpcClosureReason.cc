
#include "LpcClosureReason.h"

void LpcClosureReason::convertLpi2IOClosureReason(const LpiClosureReason::LpiEnum & in,
                                                  IOCommonTypes::ClosureReason & out)
{
   switch (in)
   {
      case LpiClosureReason::E_PLANNED_MAINTENANCE:
         out = IOCommonTypes::E_PLANNED_MAINTENANCE;
         break;
      case LpiClosureReason::E_PLANNED_SNOW_REMOVAL:
         out = IOCommonTypes::E_PLANNED_SNOW_REMOVAL;
         break;
      case LpiClosureReason::E_PLANNED_RWY_INSPECTION:
         out = IOCommonTypes::E_PLANNED_RWY_INSPECTION;
         break;
      case LpiClosureReason::E_ACCIDENT:
         out = IOCommonTypes::E_ACCIDENT;
         break;
      case LpiClosureReason::E_INCIDENT:
         out = IOCommonTypes::E_INCIDENT;
         break;
      case LpiClosureReason::E_MANUAL_OPEN_CROSSWIND:
         out = IOCommonTypes::E_MANUAL_OPEN_CROSSWIND;
         break;
      case LpiClosureReason::E_MANUAL_CLOSE_CROSSWIND:
         out = IOCommonTypes::E_MANUAL_CLOSE_CROSSWIND;
         break;
      case LpiClosureReason::E_TECHNICAL_FAILURE_ILS:
         out = IOCommonTypes::E_TECHNICAL_FAILURE_ILS;
         break;
      case LpiClosureReason::E_OTHER:
         out = IOCommonTypes::E_OTHER;
         break;
      default:
         out = IOCommonTypes::E_NONE;
      break;
   }
}


void LpcClosureReason::convertIO2LpiClosureReason(const IOCommonTypes::ClosureReason & in,
                                                  LpiClosureReason::LpiEnum & out)
{
   switch (in)
   {
      case IOCommonTypes::E_PLANNED_MAINTENANCE:
         out = LpiClosureReason::E_PLANNED_MAINTENANCE;
         break;
      case IOCommonTypes::E_PLANNED_SNOW_REMOVAL:
         out = LpiClosureReason::E_PLANNED_SNOW_REMOVAL;
         break;
      case IOCommonTypes::E_PLANNED_RWY_INSPECTION:
         out = LpiClosureReason::E_PLANNED_RWY_INSPECTION;
         break;
      case IOCommonTypes::E_ACCIDENT:
         out = LpiClosureReason::E_ACCIDENT;
         break;
      case IOCommonTypes::E_INCIDENT:
         out = LpiClosureReason::E_INCIDENT;
         break;
      case IOCommonTypes::E_MANUAL_OPEN_CROSSWIND:
         out = LpiClosureReason::E_MANUAL_OPEN_CROSSWIND;
         break;
      case IOCommonTypes::E_MANUAL_CLOSE_CROSSWIND:
         out = LpiClosureReason::E_MANUAL_CLOSE_CROSSWIND;
         break;
      case IOCommonTypes::E_TECHNICAL_FAILURE_ILS:
         out = LpiClosureReason::E_TECHNICAL_FAILURE_ILS;
         break;
      case IOCommonTypes::E_OTHER:
         out = LpiClosureReason::E_OTHER;
         break;
      default:
         out = LpiClosureReason::E_NONE;
      break;
   }
}
