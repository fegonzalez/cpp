/*
 * LpcScheduleActivationEvtConsumer.cc
 *
 *  Created on: 14/07/2014
 *      Author: gpfernandez
 */
#include "LpcScheduleActivationEvtConsumer.h"
#include <LpiScheduleActivation.h>
#include <LpcScheduleActivation.h>
#include <IOScheduleActivation.h>
#include <LpdComponent.h>
#include <string>
#include <LpdbDataBase.h>


void LpcScheduleActivationEvtConsumer::init(void)
{
   iB::SubscriberId sid("IOScheduleActivationEvents::ScheduleActivationEvent");
   iB::SubscriptionProfile sprofile;

   iBG::IOScheduleActivationEvents::ScheduleActivationEventSubscriber &subscriber =
             iBG::IOScheduleActivationEvents::ScheduleActivationEventCreateSubscriber(sid,
                                                                     sprofile);
   subscriber.addListener(this);
}


void LpcScheduleActivationEvtConsumer::on_data_available(
                        iBG::IOScheduleActivationEvents::ScheduleActivationEventSubscriber &sub)
{
   iBG::IOScheduleActivationEvents::ScheduleActivationEventSubscriber::DataList dl;
   iB::DIList il;
   sub.getData(dl, il);

   iBG::IOScheduleActivationEvents::ScheduleActivationEventSubscriber::DataList::iterator dit
                                                                  = dl.begin();
   iB::DIList::iterator iit = il.begin();
   int pos = 0;

   for(;
       (dit != dl.end()) && (iit != il.end());
       ++dit, ++iit, pos++)
   {
      if(iit->isValid())
      {
         //Obtain data
         IOScheduleActivation::ScheduleActivation dds;
         memset(&dds, 0, sizeof( IOScheduleActivation::ScheduleActivation));
         dds = dit->scheduleActivation;

         //Internal type conversion
         LpiScheduleActivation capacity;
         //Event
         LpiScheduleActivationEvt event;
         LpcScheduleActivation::convertIO2Lpi(dds, capacity);

         event.setScheduleActivation(capacity);

         LpdComponent::Get().consume(event);
      }
   }
}
