
#include <BaseVertex.h>

#include <iostream>


namespace path_finding {
   

  std::ostream& operator<<(std::ostream &out, const BaseVertex &vertex)
  {
    out << "\nuser: " << vertex.user_id()
	<< "\tinner: " << vertex.inner_id()
	<< std::endl;
    
    return out;
  }  


} //end-of namespace path_finding
