#ifndef BASE_EDGE_H
#define BASE_EDGE_H

#include <PathfindingPublicTypes.h>
#include <PathfindingInnerTypes.h>
#include <EdgeDirection.h>

#include <iosfwd>
#include <memory> // std::shared_ptr


namespace path_finding {
  

  /**************************************************************************/
  /** @struct BaseEdge

      @brief Graph's Edge interface class. Inner data structure to be
             used internally in the Graph logic.

      - from(): origin vertex of the edge.
      - to(): destination vertex of the edge.
      - weight(): distance (cost) value of the edge. Negative values allowed.
      - direction(): direction of the edge (directed or undirected G.)
  */
  struct BaseEdge
  {    
    virtual InnerVertexId from()const = 0;
    virtual InnerVertexId to()const = 0;
    virtual TypeDistance weight()const = 0;      
    virtual EdgeDirection direction()const = 0;    

    virtual ~BaseEdge(){};
  };


  /**************************************************************************/

  typedef std::shared_ptr<BaseEdge> BaseEdgePtr;
  /* typedef std::vector<BaseEdgePtr> TypeNeighbors; */

  /**************************************************************************/

  // functions
  std::ostream& operator<<(std::ostream &, const BaseEdge &);
  // std::ostream& operator<<(std::ostream &out, const BaseEdgePtr &edge)


  /**************************************************************************/

} //end-of path_finding

#endif
