#ifndef BASE_GRAPH_H
#define BASE_GRAPH_H


#include <PathfindingPublicTypes.h>
#include <PathfindingInnerTypes.h>
//#include <EdgeDirection.h>
//#include <TypeUserEdgeData.h>


namespace path_finding {


  struct TypeUserEdgeData;


  /**************************************************************************/
  /** class BaseGraph 

      @brief Interface for directed or undirected graphs used as
      inputs for path-finding algorithms.

  */
  /**************************************************************************/
  class BaseGraph
  {

  public:
    
    virtual ~BaseGraph(){};
 

   /**	@brief add a new edge between to vertexes of the graph.

	@error If an edge between the two vertexes already exists.

	@warning If any of the vertex 'from' and/or 'to' does not
	exists yet, they also are created, thus this is the fastest
	way to fill the graph.	

	@warning Generic Graph, thus negative weight are allowed 	
   */    
    virtual void add_edge
      (const UserVertexId &from, 
       const UserVertexId &to, 
       const TypeDistance & weight,
       const UserEdgeId &edge_user_id)=0;

    virtual void add_edge
      (const TypeUserEdgeData &edge)=0;


   /**	
	@warning Recommended to add isolated vertex to the graph.

	@error If the vertex already exists.
   */        
    virtual void add_vertex(const UserVertexId &id)=0;


    /** @return the number of vertex of the Graph */
    virtual unsigned int num_vertex()const=0;

    /// @return true: if the vertex, as is known by the user of the
    /// algorithm, exists in the graph.
    virtual bool validUserVertex(const UserVertexId &id)const=0;    
  };
   
  /**************************************************************************/

} //end-of path_finding
 
#endif
