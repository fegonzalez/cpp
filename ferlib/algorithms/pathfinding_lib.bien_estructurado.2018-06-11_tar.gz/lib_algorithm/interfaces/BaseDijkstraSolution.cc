
  /** @file BaseDijkstraSolution.cc

      @brief Implementation of Dijkstra algorithm 

      [dijkstra-wikipedia] https://en.wikipedia.org/wiki/Dijkstra's_algorithm

  */


#include <BaseDijkstraSolution.h>

#include <iostream>
#include <algorithm>
#include <iterator>    // std::begin
#include <functional>  // std::bind


namespace path_finding {

  //--------------------------------------------------------------------------

  std::ostream& operator<<(std::ostream &out, 
			   const BaseDijkstraSolution &value)
  {
    out << "Distance (cost): " << value.total_distance() << std::endl;
    out << "Shortest-Path's size (n. of vertex): " << value.path()->size() 
	<< std::endl;
    out << "Shortest-Path:   ";
     
    UserVertexId last_element = NOVERTEXUSERID;
    if(not value.path()->empty())
      last_element = value.path()->back();

    std::for_each(std::begin(*value.path()),
		  std::end(*value.path()),
		  [&out, last_element](const UserVertexId & id)
    {
      out << id;
      if(not (id==last_element)) { out << " -> "; }      
    });
  
    return out;
  }

  //--------------------------------------------------------------------------

} //end-of path_finding
