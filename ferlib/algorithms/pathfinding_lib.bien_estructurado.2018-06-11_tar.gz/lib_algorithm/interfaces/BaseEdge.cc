
#include <BaseEdge.h>

#include <iostream>


namespace path_finding {
   

  std::ostream& operator<<(std::ostream &out, const BaseEdge &edge)
  {
    out << "\n" << edge.from()
    	<< "\t" << edge.to()
    	<< "\t"	<< edge.weight()
    	<< "\t";
    const EdgeDirection & aux_dir = edge.direction();
    if (aux_dir==EdgeDirection::FROM_TO)
      out << "FROM_TO";
    else
      out << "BOTH";
    out << std::endl;

    return out;
  }  

  // std::ostream& operator<<(std::ostream &out, const BaseEdgePtr &edge)
  // {
  //   out << "\n" << edge->from()
  //   	<< "\t" << edge->to()
  //   	<< "\t"	<< edge->weight()
  //   	<< "\t";
  //   const EdgeDirection & aux_dir = edge->direction();
  //   if (aux_dir==EdgeDirection::FROM_TO)
  //     out << "FROM_TO";
  //   else
  //     out << "BOTH";
  //   out << std::endl;

  //   return out;
  // }  


} //end-of namespace path_finding
