/** @file TypeUserEdgeData.h

    @brief type TypeUserEdgeData used in the facade to run an algorithm.
*/


#ifndef TYPE_USER_EDGE_DATA_H
#define TYPE_USER_EDGE_DATA_H

#include <PathfindingPublicTypes.h>


namespace path_finding {

  
  //
  // types section
  //


  /** @struct TypeUserEdgeData

      @brief Edge's data for the external user (uses UserVertexId
      instead of BaseEdges's InnerVertexId)

      @param from: src vertex of the edge in directed graphs;
      one of the two edges in undirected.

      @param to: destination vertex of the edge in directed graphs;
      one of the two edges in undirected.		 
  */
  struct TypeUserEdgeData
  {
  TypeUserEdgeData(const UserVertexId &from,
	       const UserVertexId &to,
	       const TypeDistance &weight,
	       const UserEdgeId &id):
    from(from), to(to), weight(weight), id(id)
    {}

    
    UserVertexId from;
    UserVertexId to;
    TypeDistance weight;
    UserEdgeId id;
  };
  

} //end-of path_finding

#endif  /* TYPE_USER_EDGE_DATA_H */
