#ifndef EDGE_DIRECTION_H
#define EDGE_DIRECTION_H


namespace path_finding {
  

  //optimization: for undirected graphs, avoiding duplicate edges.
  enum class EdgeDirection{FROM_TO, // directed graph
                           BOTH};   // undirected graph
    

} //end-of path_finding

#endif
