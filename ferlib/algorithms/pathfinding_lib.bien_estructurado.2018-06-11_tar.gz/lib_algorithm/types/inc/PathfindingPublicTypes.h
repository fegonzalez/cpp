/** @file PathfindingPublicTypes.h

    @brief Basic types of the path_finding library required by an
    external user of the library (client).

    Types required both internally, by the pathfinding classes, and
    externally, by the users of the library.

*/


#ifndef PATHFINDING_PUBLIC_TYPES_H
#define PATHFINDING_PUBLIC_TYPES_H

#include <string>
#include <list>


namespace path_finding {

  
  //
  // types section
  //
  
  typedef std::string UserVertexId;
  typedef std::string UserEdgeId; 
  typedef double TypeDistance;      // distance/weight of an edge.

  /* Data struct returning a list of vertex following a path, where
     the first value is the first node of the path */
  typedef std::list<UserVertexId> VertexPath;



  //
  // constants section
  //
  
  const UserVertexId NOVERTEXUSERID = "";


  
} //end-of path_finding

#endif
