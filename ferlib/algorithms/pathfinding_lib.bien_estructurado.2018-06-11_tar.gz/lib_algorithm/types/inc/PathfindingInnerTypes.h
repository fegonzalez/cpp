/** @file PathfindingInnerTypes.h

    @brief Basic types of the path_finding library used internally by
    the pathfinding classes.

*/


#ifndef PATHFINDING_INNER_TYPES_H
#define PATHFINDING_INNER_TYPES_H

#include <string>
#include <list>


namespace path_finding {

  
  //
  // types section
  //
    
  typedef unsigned int VertexId;
  typedef unsigned int EdgeId;
  typedef VertexId InnerVertexId; // (alias) 1, 2, .. (0 reserved as NOVERTEXID)
//  typedef InnerVertexId FromVertexId; // (alias) 1, 2, ...

  //
  // constants section
  //

  const InnerVertexId NOVERTEXID = 0;
  const EdgeId NOEDGEID = 0;
  const TypeDistance TYPEDISTANCE_ZERO = static_cast<TypeDistance>(0);
  
  
} //end-of path_finding

#endif
