#ifndef EDGE_H
#define EDGE_H

#include <BaseEdge.h>

#include <iosfwd>


namespace path_finding {


  /**************************************************************************/
  /** @struct Edge : public BaseEdge
   */
  struct Edge : public BaseEdge
  {
    friend std::ostream& operator<<(std::ostream &, const BaseEdge &);
    
  public:

    InnerVertexId from()const { return the_from;}
    InnerVertexId to()const { return the_to;}
    TypeDistance weight()const { return the_weight;} 
    EdgeDirection direction()const { return the_direction;}

    Edge(InnerVertexId from,
		 InnerVertexId to,
		 TypeDistance weight,
		 EdgeDirection direction)
      :the_from(from),
      the_to(to),
      the_weight(weight),      
      the_direction(direction)
      { }

    // data area 

  private: 
    InnerVertexId the_from;
    InnerVertexId the_to;
    TypeDistance the_weight;      
    EdgeDirection the_direction;
  };   


} //end-of path_finding
 
#endif
