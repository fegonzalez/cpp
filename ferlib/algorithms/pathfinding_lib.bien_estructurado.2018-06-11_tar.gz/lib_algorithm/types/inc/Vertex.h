#ifndef VERTEX_H
#define VERTEX_H

#include <iosfwd>

#include <PathfindingPublicTypes.h>
#include <PathfindingInnerTypes.h>
#include <BaseVertex.h>
#include <string>     // std::string, std::to_string

namespace path_finding {

  
/**************************************************************************/
  /** @struct Vertex
  */
  struct Vertex: public BaseVertex
  {
    friend class Graph;
    friend std::ostream& operator<<(std::ostream &, const BaseVertex &);
    
  public:
	
    UserVertexId user_id()const {return the_user_id;}
    InnerVertexId inner_id()const {return the_inner_id;}

    /* void add_neighbor(BaseEdgePtr edge) */
    /* { the_neighbourhood.push_back(edge); } */

	
  protected:
    
    Vertex(InnerVertexId inner,
    		   UserVertexId user)
      :the_inner_id(inner), the_user_id(user) {}

    
    // data area
	
  private:
    
    InnerVertexId the_inner_id = NOVERTEXID;
    UserVertexId the_user_id = std::to_string(the_inner_id);

    /** @brief OPTIMIZATION: quick access to neighbors

	- undirected-graph edges: edge.direction() == EdgeDirection::BOTH
	
	- directed-graph edges: edge.direction() == EdgeDirection::BOTH
	
	   - outward edge iff: edge.from() == the_inner_id

	   - inward edge iff: edge.to() == the_inner_id

        - loop edge (both directed & undirected): edge.from() == edge.to()


	// optional optim: split the_neighbourhood in three vectors: 
	// inwards_only, outwards_only, undirected
    */
    //TypeNeighbors the_neighbourhood{}; // unused in this Dijkstra impl.
  };

   
  /**************************************************************************/

} //end-of path_finding
 
#endif
