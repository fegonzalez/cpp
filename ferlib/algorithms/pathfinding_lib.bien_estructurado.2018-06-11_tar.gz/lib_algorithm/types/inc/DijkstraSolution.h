#ifndef DIJKSTRA_SOLUTION_H
#define DIJKSTRA_SOLUTION_H


#include <BaseDijkstraSolution.h>


namespace path_finding {


  /**************************************************************************/
  /** @struct DijkstraSolution

     @brief Basic implementation of a BaseDijkstraSolution
  */
  /**************************************************************************/

  struct DijkstraSolution: public BaseDijkstraSolution
  {
  public:

    TypeDistance total_distance()const { return the_total_distance;}
    const VertexPath *path()const { return &the_path;}
    
    void set_distance(const TypeDistance &newval) 
    { the_total_distance = newval; }

    void push_front(const UserVertexId & newval) 
    { the_path.push_front(newval); }

  private:

    TypeDistance the_total_distance;
    VertexPath the_path;
  };

  
} //end-of path_finding
 
#endif
