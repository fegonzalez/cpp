#ifndef DIRECTED_GRAPH_H
#define DIRECTED_GRAPH_H

#include <Graph.h>

#include <iosfwd>


namespace path_finding {

  
  /**************************************************************************/
  /** class DirectedGraph 

      @brief Directed graph's specialization of a Graph. Instantiable class.
  */
  /**************************************************************************/

  class DirectedGraph: public Graph
  {

    friend std::ostream& operator<<(std::ostream &, const Graph &);
    friend class Dijkstra;

    
  public:
    
    explicit DirectedGraph() = default;
    explicit DirectedGraph(const DirectedGraph&) = delete;
    DirectedGraph& operator=(const DirectedGraph&) = delete;
    explicit DirectedGraph(const DirectedGraph&&) = delete;
    DirectedGraph& operator=(const DirectedGraph&&) = delete;
    
  protected:
    
    BaseEdgePtr insert_edge(const InnerVertexId &from,
			    const InnerVertexId &to, 
			    const TypeDistance & weight,
			    const UserEdgeId &edge_user_id);

    inline void insert_adjacency(const InnerVertexId &from,
				 const InnerVertexId &to, 
				 const AdjacEdge &edge);
  };
  

  /**************************************************************************/

} //end-of path_finding
 
#endif
