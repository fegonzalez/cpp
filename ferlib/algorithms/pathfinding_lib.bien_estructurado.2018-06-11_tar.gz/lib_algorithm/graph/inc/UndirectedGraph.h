#ifndef UNDIRECTED_GRAPH_H
#define UNDIRECTED_GRAPH_H

#include <Graph.h>

#include <iosfwd>


namespace path_finding {

  
  /**************************************************************************/
  /** class UndirectedGraph 

      Undirected graph's specialization of a Graph. Instantiable class.
  */
  /**************************************************************************/

  class UndirectedGraph: public Graph
  {

    friend std::ostream& operator<<(std::ostream &, const Graph &);
    friend class Dijkstra;

  public:
    
    explicit UndirectedGraph() = default;
    explicit UndirectedGraph(const UndirectedGraph&) = delete;
    UndirectedGraph& operator=(const UndirectedGraph&) = delete;
    explicit UndirectedGraph(const UndirectedGraph&&) = delete;
    UndirectedGraph& operator=(const UndirectedGraph&&) = delete;

  protected:
    
    BaseEdgePtr insert_edge(const InnerVertexId &from,
			    const InnerVertexId &to, 
			    const TypeDistance & weight,
			    const UserEdgeId &edge_user_id);

    inline void insert_adjacency(const InnerVertexId &from,
				 const InnerVertexId &to, 
				 const AdjacEdge &edge);
  };
  

  /**************************************************************************/

} //end-of path_finding
 
#endif
