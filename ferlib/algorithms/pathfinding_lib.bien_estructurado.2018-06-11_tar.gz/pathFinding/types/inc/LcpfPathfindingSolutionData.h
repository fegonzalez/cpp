/** @file LcpfSolutionData.h

    @brief Type PathfindingSolutionData used in the facade to run an algorithm.

*/


#ifndef LCPF_PATHFINDING_SOLUTION_DATA_H
#define LCPF_PATHFINDING_SOLUTION_DATA_H

#include <LcpfPublicTypes.h>


namespace path_finding {

  
  //
  // types section
  //


  typedef std::list<UserEdgeId> EdgePath;

  /** @struct PathfindingSolutionData

      @brief Stores the solution of a path finding algorithm execution.

      @param the_total_distance: total distance (cost) of the solution.

      @param the_path: ordered list of nodes of the solution.

      @param the_path_edges: ordered list of edges of the solution.

  */
  struct PathfindingSolutionData
  {
    TypeDistance the_total_distance;
    VertexPath the_path;
    EdgePath the_path_edges;
  };


  //
  // fns. section
  //

  std::ostream& operator<<(std::ostream &out, 
			   const PathfindingSolutionData &value);


  
} //end-of path_finding

#endif  /* PATHFINDING_SOLUTION_DATA_H */
