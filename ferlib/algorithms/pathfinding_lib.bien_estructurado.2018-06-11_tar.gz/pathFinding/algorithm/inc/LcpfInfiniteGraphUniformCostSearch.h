#ifndef LCPF_INFINITE_GRAPH_UNIFORM_COST_SEARCH_H
#define LCPF_INFINITE_GRAPH_UNIFORM_COST_SEARCH_H


#include <LcpfUniformCostSearch.h>


namespace path_finding {

  /**************************************************************************/
  /** @class InfiniteGraphUniformCostSearch

      @brief Specialization of the UniformCostSearch algorithm to
      allow the execution of UCS on infinite graphs or those too large
      to represent in memory. Concrete (instantiable) class.

      Specialization of the UCS algorithm: 'previous' and 'distances'
      are set ONLY to the explored vertexes in the graph.
      
  */
  /**************************************************************************/
  
  class InfiniteGraphUniformCostSearch: public UniformCostSearch
  {
  private:
    
    void init_distances(const Graph &graph,
			const InnerVertexId &start,
			const InnerVertexId &target);

    void init_distance(const InnerVertexId &vertex);

    void init_previous(const Graph &graph,
		       const InnerVertexId &start,
		       const InnerVertexId &target);

  };

  
  /**************************************************************************/

} //end-of path_finding

#endif

