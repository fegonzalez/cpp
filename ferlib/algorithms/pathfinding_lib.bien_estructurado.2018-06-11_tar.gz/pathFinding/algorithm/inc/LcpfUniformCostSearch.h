#ifndef LCPF_UNIFORM_COST_SEARCH_H
#define LCPF_UNIFORM_COST_SEARCH_H


#include <LcpfDijkstraStrategy.h>
#include <LcpfPublicTypes.h>
#include <LcpfInnerTypes.h>
#include <LcpfDijkstraSolution.h>


#include <unordered_map>
#include <limits>       // std::numeric_limits
#include <list>

namespace path_finding {
  
  class Graph;

  struct DijkstraSolution;


  const TypeDistance TYPEDISTANCE_INFINITE = 
    std::numeric_limits<TypeDistance>::infinity();



  
  /**************************************************************************/
  /** @class UniformCostSearch

      @brief Dijkstra's optimization: Implementing the uniform-cost
      search (UCS) variant of Dijkstra for a (direct or undirected)
      Graph. Abstract class.

      [1] dijkstra-wikipedia - 
          https://en.wikipedia.org/wiki/Dijkstra's_algorithm
  */
  /**************************************************************************/
  
  class UniformCostSearch: public DijkstraStrategy
  {
  public:
    DijkstraSolution shortest_path(const Graph &graph, 
				   const UserVertexId &user_start,
				   const UserVertexId &user_target);

  protected:
    
    virtual void init_distances(const Graph &graph,
				const InnerVertexId &start,
				const InnerVertexId &target) = 0;
    
    virtual void init_distance(const InnerVertexId &vertex) = 0;


    virtual void init_previous(const Graph &graph,
				const InnerVertexId &start,
				const InnerVertexId &target) = 0;
      
    //data area

    /// @param distances: total (OPTIMAL) distance from 'start' to the rest.
    typedef std::unordered_map<InnerVertexId, TypeDistance> TDistances;
    TDistances distances{};

    		   
    /** @param previous: prev-vertex in the optimal-path for any
	vertex in graph. 
	(e.g.  Graph (1)-->(2) : previous[1] = NOVERTEXID; previous[2] = 1; )
    */
    typedef std::unordered_map<InnerVertexId, InnerVertexId> TPrevious;
    TPrevious previous{};
    
  };
  

  /**************************************************************************/

} //end-of path_finding

#endif
