
  /** @file InfiniteGraphUniformCostSearch.cc

      @brief Implementation of the InfiniteGraphUniformCostSearch
      algorithm, an specialization of the UniformCostSearch algorithm.

  */


#include <LcpfInfiniteGraphUniformCostSearch.h>
#include <LcpfGraph.h>


namespace path_finding {


  /**************************************************************************/  
  /* InfiniteGraphUniformCostSearch class implementation                    */
  /**************************************************************************/

  // Complexity: Constant.
  void InfiniteGraphUniformCostSearch::init_distances
  (const Graph &graph,
   const InnerVertexId &start,
   const InnerVertexId &target)
  {
    (void) graph;
    distances[start] = TYPEDISTANCE_ZERO;
    distances[target] = TYPEDISTANCE_INFINITE; 
  }

  //--------------------------------------------------------------------------

  // Complexity (distances.find): Constant on average, worst case
  // linear in the size of the container.
  // (http://en.cppreference.com/w/cpp/container/unordered_map/find)
  void InfiniteGraphUniformCostSearch::init_distance
  (const InnerVertexId &vertex)
  {
    if(distances.find(vertex) == distances.end())
      distances[vertex] = TYPEDISTANCE_INFINITE;
  }

  //--------------------------------------------------------------------------

  // Complexity: Constant.
  void InfiniteGraphUniformCostSearch::init_previous
  (const Graph &graph,
   const InnerVertexId &start,
   const InnerVertexId &target)
  {
    (void) graph;    
    previous[start] = NOVERTEXID;
    previous[target] = NOVERTEXID;
  }

  //--------------------------------------------------------------------------

} //end-of path_finding
