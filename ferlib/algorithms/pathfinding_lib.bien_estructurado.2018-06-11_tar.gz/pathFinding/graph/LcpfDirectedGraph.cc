
#include <LcpfDirectedGraph.h>
#include <LcpfEdge.h>


namespace path_finding {



  /**************************************************************************/
  /** DirectedGraph  impl.

      Directed graph specialization of a Graph.
  */
  /**************************************************************************/

  /// @todo aquí añadir el campo edge_id (std::string)
  BaseEdgePtr DirectedGraph::insert_edge(const InnerVertexId &from,
					 const InnerVertexId &to, 
					 const TypeDistance & weight,
					 const UserEdgeId &edge_user_id)
  {
    (void) edge_user_id;
    BaseEdgePtr new_value(new Edge(from, to, weight,
				   EdgeDirection::FROM_TO));    
    the_edge_map[num_edges() + 1] = new_value;
    return new_value;
  }
     
  //--------------------------------------------------------------------------

  void DirectedGraph::insert_adjacency(const InnerVertexId &from,
					       const InnerVertexId &to, 
					       const AdjacEdge &edge)
  {
    the_adjacency_data.the_outward_edges.insert(std::make_pair(from, edge));
    the_adjacency_data.the_inward_edges.insert(std::make_pair(to, edge));
  }

  //--------------------------------------------------------------------------


} //end-of namespace path_finding
