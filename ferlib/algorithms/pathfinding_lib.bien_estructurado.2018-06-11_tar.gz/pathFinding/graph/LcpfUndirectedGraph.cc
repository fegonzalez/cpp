
#include <LcpfUndirectedGraph.h>
#include <LcpfEdge.h>


namespace path_finding {
   

  /**************************************************************************/
  /** UndirectedGraph  impl.

      Undirected graph specialization of a Graph.
  */
  /**************************************************************************/
  
  BaseEdgePtr UndirectedGraph::insert_edge(const InnerVertexId &from,
					   const InnerVertexId &to, 
					   const TypeDistance & weight,
					   const UserEdgeId &edge_user_id)
  {
    (void) edge_user_id;
    BaseEdgePtr new_value(new Edge(from, to, weight,
				   EdgeDirection::BOTH));
    the_edge_map[num_edges() + 1] = new_value;
    return new_value;
  }
     
  //--------------------------------------------------------------------------

  void UndirectedGraph::insert_adjacency(const InnerVertexId &from,
					       const InnerVertexId &to, 
					       const AdjacEdge &edge)
  {
    the_adjacency_data.the_outward_edges.insert(std::make_pair(from, edge));
    the_adjacency_data.the_inward_edges.insert(std::make_pair(to, edge));
    the_adjacency_data.the_outward_edges.insert(std::make_pair(to, edge));
    the_adjacency_data.the_inward_edges.insert(std::make_pair(from, edge));
  }


  //--------------------------------------------------------------------------


} //end-of namespace path_finding
