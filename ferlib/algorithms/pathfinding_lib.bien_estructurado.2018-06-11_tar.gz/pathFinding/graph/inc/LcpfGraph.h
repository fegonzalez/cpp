#ifndef LCPF_GRAPH_H
#define LCPF_GRAPH_H


#include <LcpfPublicTypes.h>
#include <LcpfInnerTypes.h>
#include <LcpfBaseGraph.h>
#include <LcpfBaseEdge.h>
#include <LcpfBaseVertex.h>

#include <iosfwd>
#include <unordered_map>


namespace path_finding {


  struct TypeUserEdgeData;

  
  /**************************************************************************/
  /** class Graph 

      @brief Common data and functions to implement a
      directed/undirected graph. Abstract class.

  */
  /**************************************************************************/
  class Graph: public BaseGraph
  {

    friend std::ostream& operator<<(std::ostream &, const Graph &);
	
    
  public:

    typedef BaseVertexPtr VertexValue;
    typedef BaseEdgePtr EdgeValue;
    typedef BaseEdgePtr AdjacEdge;  
       
    // data-members

    void add_edge
      (const UserVertexId &from, 
       const UserVertexId &to, 
       const TypeDistance & weight,
       const UserEdgeId &edge_user_id);

    virtual void add_edge
      (const TypeUserEdgeData &edge);

    void add_vertex(const UserVertexId &id);

    unsigned int num_vertex()const {return the_vertex_map.size();}


    /// @return true: if the vertex exists in the graph.
    bool validUserVertex(const UserVertexId &id)const
    {
      return(the_useridskeyed_map.find(id) not_eq the_useridskeyed_map.end());
    }

    InnerVertexId get_inner_id(const UserVertexId &id)const;
    UserVertexId get_user_id(const InnerVertexId &id)const;
    

    //  public: 
    //
    // public data area 
    // otherwise "friend" must be added for every new Dijkstra class

    struct
    {
      std::unordered_multimap<InnerVertexId, AdjacEdge> the_outward_edges{};
      std::unordered_multimap<InnerVertexId, AdjacEdge> the_inward_edges{};
    } the_adjacency_data;


  protected:
       
    // data-members

    unsigned int num_inner_indexes()const {return the_vertex_map.size();}
    unsigned int num_edges()const { return the_edge_map.size(); }
    bool repeated_user_edge(const UserVertexId &from,
			    const UserVertexId to)const;


    /** @brief create & add a NEW edge to the data structures.
    */
    virtual BaseEdgePtr insert_edge(const InnerVertexId &from,
				    const InnerVertexId &to, 
				    const TypeDistance & weight,
				    const UserEdgeId &edge_user_id) = 0;


    /** @brief create & add the adjacency information to the data structures
     */
    virtual void insert_adjacency(const InnerVertexId &from,
				 const InnerVertexId &to, 
				 const AdjacEdge &edge) = 0;
    
    // data area
    //
    // protected:

    // vertex storage, keyed by their id.
    std::unordered_map<InnerVertexId, VertexValue> the_vertex_map{};

    // Keeping the relation between user & inner vertex_ids
    // Two maps to optimize the search operations.
    std::unordered_map<UserVertexId, InnerVertexId> the_useridskeyed_map{};
    std::unordered_map<InnerVertexId, UserVertexId> the_inneridskeyed_map{};

    // edge storage, keyed by edge id.
    std::unordered_map<EdgeId, EdgeValue> the_edge_map{};

    
  };
  
  /**************************************************************************/

} //end-of path_finding
 
#endif
