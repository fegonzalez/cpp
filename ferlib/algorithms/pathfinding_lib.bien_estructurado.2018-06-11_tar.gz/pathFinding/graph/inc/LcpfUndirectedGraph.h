#ifndef LCPF_UNDIRECTED_GRAPH_H
#define LCPF_UNDIRECTED_GRAPH_H

#include <LcpfGraph.h>

#include <iosfwd>


namespace path_finding {

  
  /**************************************************************************/
  /** class UndirectedGraph 

      Undirected graph's specialization of a Graph. Instantiable class.
  */
  /**************************************************************************/

  class UndirectedGraph: public Graph
  {

    friend std::ostream& operator<<(std::ostream &, const Graph &);

  public:
    
    explicit UndirectedGraph() = default;
    explicit UndirectedGraph(const UndirectedGraph&) = delete;
    UndirectedGraph& operator=(const UndirectedGraph&) = delete;
    explicit UndirectedGraph(const UndirectedGraph&&) = delete;
    UndirectedGraph& operator=(const UndirectedGraph&&) = delete;

  protected:
    
    virtual BaseEdgePtr insert_edge(const InnerVertexId &from,
				    const InnerVertexId &to, 
				    const TypeDistance & weight,
				    const UserEdgeId &edge_user_id);

    virtual inline void insert_adjacency(const InnerVertexId &from,
					 const InnerVertexId &to, 
					 const AdjacEdge &edge);
  };
  

  /**************************************************************************/

} //end-of path_finding
 
#endif
