#ifndef LCPF_DIRECTED_GRAPH_H
#define LCPF_DIRECTED_GRAPH_H

#include <LcpfGraph.h>

#include <iosfwd>


namespace path_finding {

  
  /**************************************************************************/
  /** class DirectedGraph 

      @brief Directed graph's specialization of a Graph. Instantiable class.
  */
  /**************************************************************************/

  class DirectedGraph: public Graph
  {

    friend std::ostream& operator<<(std::ostream &, const Graph &);

    
  public:
    
    explicit DirectedGraph() = default;
    explicit DirectedGraph(const DirectedGraph&) = delete;
    DirectedGraph& operator=(const DirectedGraph&) = delete;
    explicit DirectedGraph(const DirectedGraph&&) = delete;
    DirectedGraph& operator=(const DirectedGraph&&) = delete;
    
  protected:
    
    virtual BaseEdgePtr insert_edge(const InnerVertexId &from,
				    const InnerVertexId &to, 
				    const TypeDistance & weight,
				    const UserEdgeId &edge_user_id);

    virtual inline void insert_adjacency(const InnerVertexId &from,
					 const InnerVertexId &to, 
					 const AdjacEdge &edge);
  };
  

  /**************************************************************************/

} //end-of path_finding
 
#endif
