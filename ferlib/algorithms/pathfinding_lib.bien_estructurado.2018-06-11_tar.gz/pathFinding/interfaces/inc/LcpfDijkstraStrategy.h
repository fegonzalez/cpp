#ifndef LCPF_DIJKSTRA_STRATEGY_H
#define LCPF_DIJKSTRA_STRATEGY_H


#include <LcpfPublicTypes.h>
#include <LcpfDijkstraSolution.h>


namespace path_finding {


  class Graph;
  


  /**************************************************************************/
  /** @class DijkstraStrategy

      @brief Dijkstra's algorithm implementation interface. Intended
      to be used via strategy pattern.

      [1] dijkstra-wikipedia - 
          https://en.wikipedia.org/wiki/Dijkstra's_algorithm

  */
  /**************************************************************************/

  class DijkstraStrategy
  {
  public:

    /** @ brief Calculation of the shortest path from 'user_start' vertex
	to 'user_target' vertex.

	@param graph: the graph to apply Dijkstra.
	@param user_start: the initial vertex of the path.
	@return The distance from 'user_start' to 'user_target'.
	@return list of nodes from the start to the target node. 
	@ error if 'user_start' or 'user_target' are not vertex of the graph.
    */
    virtual DijkstraSolution shortest_path(const Graph &graph, 
					   const UserVertexId &user_start,
					   const UserVertexId &user_target) = 0;
  };

} //end-of path_finding

#endif
