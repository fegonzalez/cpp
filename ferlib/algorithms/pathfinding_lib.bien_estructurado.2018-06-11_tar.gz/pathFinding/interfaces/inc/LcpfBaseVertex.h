#ifndef LCPF_BASE_VERTEX_H
#define LCPF_BASE_VERTEX_H

#include <LcpfPublicTypes.h>
#include <LcpfInnerTypes.h>

#include <iosfwd>
#include <memory> // std::shared_ptr


namespace path_finding {
  

  
  /**************************************************************************/
  /** @struct BaseVertex

      @brief Graph's Vertex interface class. Inner data structure to
      be used internally in the Graph logic.

      - user_id(): id known by the user (creator) of the Vertex. 
  
      - inner_id(): id to be used internally in the Graph logic.
  */
  struct BaseVertex
  {
  public:
    
    virtual ~BaseVertex(){}

    virtual UserVertexId user_id()const = 0;
    virtual InnerVertexId inner_id()const = 0;
    
    /// @brief (Optimization) Add an edge to connect to a neighbor vertex
    //    virtual void add_neighbor(BaseEdgePtr edge) = 0;

  };


  /**************************************************************************/
 
  typedef std::shared_ptr<BaseVertex> BaseVertexPtr;


  /**************************************************************************/

  // functions
  std::ostream& operator<<(std::ostream &, const BaseVertex &);


  /**************************************************************************/


} //end-of path_finding

#endif
