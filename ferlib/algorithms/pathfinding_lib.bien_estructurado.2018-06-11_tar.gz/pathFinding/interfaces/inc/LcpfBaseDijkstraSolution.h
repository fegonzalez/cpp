#ifndef LCPF_BASE_DIJKSTRA_SOLUTION_H
#define LCPF_BASE_DIJKSTRA_SOLUTION_H


#include <LcpfPublicTypes.h>



namespace path_finding {



  /**************************************************************************/
  /** @struct BaseDijkstraSolution

     @brief Interface class. Used to return the value of a call to
     DijkstraStrategy::shortest_path.

     @param path(): list of vertex of the shortest path. The first
     value of the list is the 'user_start' vertex, and the last one is
     the 'user_target' vertex.

     @warning the ids in the path represent the "user_ids" in a
     BaseVertex, not the "inner_ids".
    
     @sa wikipedia: 1 -> 3 -> 6 -> 5

     @retval: the path is empty when a valid path wasn't found.
  */
  /**************************************************************************/

  struct BaseDijkstraSolution
  {    
  public:
    virtual TypeDistance total_distance()const = 0;

    virtual const VertexPath * path()const = 0;

    virtual void set_distance(const TypeDistance &newval) = 0;

    virtual void push_front(const UserVertexId & newval) = 0;

    virtual ~BaseDijkstraSolution() {}
  };

  /**************************************************************************/

  std::ostream& operator<<(std::ostream &, const BaseDijkstraSolution &);
   
  /**************************************************************************/

} //end-of path_finding
 
#endif
