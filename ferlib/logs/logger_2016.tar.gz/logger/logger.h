#ifndef AW159_MODELS_SYSTEMS_LOGGER_LOGGER_H
#define AW159_MODELS_SYSTEMS_LOGGER_LOGGER_H


/*****************************************************************************/
/*!\file logger.h   
  \brief Common log message definition.
  \Author Fernando Gonzalez Rodriguez.
  \version   2.0
  \date      2006-2013

  \details Logger feature allows multiple log-message output. 
  In this version a ConsoleLogger(standard output), and FileLogger (plain text
  file) are implemented.

  Logger feature defines an standard fixed message format:

  	 [Date] LogLevel : message text

  Logger feature defines a fixed amount of message that are identified as a
  log level. 

  \note The log levels are based on the Severity levels defined in syslog 
  (http://en.wikipedia.org/wiki/Syslog#Severity_levels)

  \note Message format:
  Wed Apr 25 16:08:10 2007    EMERG: this is the logEmerg message.
  EMERG: this is the logEmerg message without date.  

  \note Exception for Loggers:
  A particular exception class (\see LoggerException), has been defined to 
  handle Logger exceptions.
*/
/*****************************************************************************/


#include "logger_types.h"

#include <iosfwd>	 // declaration of stream functions
#include <iomanip>
#include <string>


//class ostringstream;

//============================================
namespace logs{
//============================================



/*****************************************************************/
/*!\class LoggerException logger.h
  \brief Exception class for Logger.
 */	
/*****************************************************************/
class LoggerException
{
 public:
  LoggerException();
  LoggerException(const LoggerException& mine);
  LoggerException(std::string exMessage);
  virtual ~LoggerException(){};
  LoggerException& operator=(const LoggerException& e);
	
  virtual std::string showError()const
  {
    return message;
  }

 protected:
  std::string message;
};
	

/*****************************************************************/
/*!\class FileLoggerException logger.h
  \brief Exception class for FileLogger.
*/	
/*****************************************************************/
 class FileLoggerException : public LoggerException
{
 public:
  FileLoggerException();
  FileLoggerException(const FileLoggerException& mine);
  FileLoggerException(std::string exMessage);
};


	
/***********************************************************************/
/*!\class Logger logger.h
  \brief Logger Interface class. To extend particular loggers from this.

  \note Message format:
  Wed Apr 25 16:08:10 2007    EMERG: this is the logEmerg message.
  EMERG: this is the logEmerg message without date.

  \exception logNone:
  Wed Apr 25 16:08:10 2007    this is the logNone message.
  this is the logNone message without date.
  
  \exception logAny:
  Wed Apr 25 16:08:10 2007   ExampleOfLabel this is the logAny message.
  AnotherExampleOfLabel this is the logAny message without date.

*/	
/***********************************************************************/
 class Logger
 {
 public:

   virtual ~Logger() {}; 
	
   virtual void writeLog(const LogLevel & aLogLevel, 
			 const std::string & message, 
			 bool showDate = true)=0;

   virtual void logEmerg(const std::string & message, bool showDate = true)=0;
   virtual void logAlert(const std::string & message, bool showDate = true)=0;
   virtual void logCrit(const std::string & message, bool showDate = true)=0;
   virtual void logError(const std::string & message, bool showDate = true)=0;
   virtual void logWarning(const std::string & message, 
			   bool showDate = true)=0;
   virtual void logNotice(const std::string & message, bool showDate = true)=0;
   virtual void logInfo(const std::string & message, bool showDate = true)=0;
   virtual void logDebug(const std::string & message, bool showDate = true)=0;
   virtual void logNone(const std::string & message, bool showDate = true)=0;
   virtual void logAny(const std::string & message, 
		       const std::string & logTitle="", 
		       bool showDate = true)=0;

   /*!\fn void dump()
     \brief dump the log messages that could be buffered.
     Used for that Logger classes that don't want to write on the fly but using
     a temporal buffer instead.
     \warning Not buffered-loggers will have this method as void.
     \notice example of buffered loggers: OfflineFileLogger
     \notice example of non-buffered loggers: ConsoleLogger, FileLogger.
    */
   virtual void dump()=0;

   /*!\fn void setDumpLogLevel(const LogLevel & dumpLogLevel)
     \brief Intended to be used as: IF current message LogLevel is greater 
     than dumpLogLevel THEN write the message now ELSE buffer the message
     until dump() is commanded.
     \warning Not buffered-loggers will have this method as void.
     \warning Not buffered-loggers will default dumpLogLevel should be logs::None
    */
   virtual void setDumpLogLevel(const LogLevel & dumpLogLevel)=0;
   virtual LogLevel getDumpLogLevel()const=0;
 };



 /*****************************************************************/
 /*!\class ConsoleLogger logger.h
   \brief standard output log messages. Non-buffered logger.
   The output depends of the LogLevel value:
   cout: None
   cerr: Error
   clog: otherwise
 */	
 /*****************************************************************/

 class ConsoleLogger : public Logger
 {
 public:
	
   ConsoleLogger();
	
   void writeLog(const LogLevel & aLogLevel, const std::string & message, 
		 bool showDate = true);
   void logEmerg(const std::string & message, bool showDate = true);
   void logAlert(const std::string & message, bool showDate = true);
   void logCrit(const std::string & message, bool showDate = true);
   void logError(const std::string & message, bool showDate = true);
   void logWarning(const std::string & message, bool showDate = true);
   void logNotice(const std::string & message, bool showDate = true);
   void logInfo(const std::string & message, bool showDate = true);
   void logDebug(const std::string & message, bool showDate = true);
   void logNone(const std::string & message, bool showDate = true);
   void logAny(const std::string & message, 
	       const std::string & logTitle="", 
	       bool showDate = true);

   virtual void dump(){};
   virtual void setDumpLogLevel(const LogLevel & dumpLogLevel)
   {(void) dumpLogLevel;}
   virtual LogLevel getDumpLogLevel()const
   {return logs::None;}
 };



 /*****************************************************************/
 /*!\class FileLogger logger.h
   \brief file output log messages.
 */	
 /*****************************************************************/

 class FileLogger : public Logger
 {
 public:
	
   /*!\fn FileLogger(std::string fileName, bool overWriteOldFile = false)
    * overWriteOldFile: when true, if the file exists it is overwritten.
    * throw FileLoggerException
    */
   // 
   FileLogger(std::string fileName, bool overWriteOldFile = false);
	

   /*!\fn FileLogger(const FileLogger & aFileLogger);
    * Creates a file with name  <aFileLogger.logFileName>.copy and copies 
      in it the content of the original file.
    * throw FileLoggerException
    */
   FileLogger(const FileLogger & aFileLogger);
	

   virtual ~FileLogger();

   /*!\fn FileLogger & operator=(const FileLogger & aFileLogger);
     \brief Clears the file and copies in it the content of the original file
    */
   virtual FileLogger & operator=(const FileLogger & aFileLogger);


   virtual std::string getlogFileName()
   {
     return logFileName;
   }


   // log methods

   virtual void writeLog(const LogLevel & aLogLevel, 
			 const std::string & message, 
			 bool showDate  =true);
   virtual void logEmerg(const std::string & message, bool showDate = true);
   virtual void logAlert(const std::string & message, bool showDate = true);
   virtual void logCrit(const std::string & message, bool showDate = true);
   virtual void logError(const std::string & message, bool showDate = true);
   virtual void logWarning(const std::string & message, bool showDate = true);
   virtual void logNotice(const std::string & message, bool showDate = true);
   virtual void logInfo(const std::string & message, bool showDate = true);
   virtual void logDebug(const std::string & message, bool showDate = true);
   virtual void logNone(const std::string & message, bool showDate = true);
   virtual void logAny(const std::string & message, 
		       const std::string & logTitle="", 
		       bool showDate = true);
	

   virtual void dump(){};
   virtual void setDumpLogLevel(const LogLevel & dumpLogLevel)
   {(void) dumpLogLevel;}
   virtual LogLevel getDumpLogLevel()const
   {return logs::None;}


   //FileLogger particular log methods
   virtual void blankLine();
	
	
 protected:

   // data area
   std::ofstream * out;
   std::string logFileName;
   // methods
   virtual void copyFile
     (const std::string & fromName, const std::string & toName);
	
 }; // class FileLogger


 /*****************************************************************/
 /*!\class OfflineFileLogger logger.h
   \brief Delay the writing of the message until destruction or
   explicit user order "dump()"

   \param the_dump_loglevel: limit LogLevel to write online / wait until dump
   the log messages.  Only the messages whose level is equal or greater than
   this reference level will be written in the loggers, (having Emerg=0 as the
   superior debug level)

   i.e. 
 */	
 /*****************************************************************/


 class OfflineFileLogger: public FileLogger
 {
 public:

   OfflineFileLogger(std::string fileName,
		     const LogLevel & dumpLogLevel,
		     bool overWriteOldFile = false);

   ~OfflineFileLogger();

   virtual void dump();

   virtual void setDumpLogLevel(const LogLevel & dumpLogLevel) 
   {the_dump_loglevel=dumpLogLevel;}
   
   virtual LogLevel getDumpLogLevel()const
   {return the_dump_loglevel;}
   
   //over write methods
   virtual void logEmerg(const std::string & message, bool showDate = true);
   virtual void logAlert(const std::string & message, bool showDate = true);
   virtual void logCrit(const std::string & message, bool showDate = true);
   virtual void logError(const std::string & message, bool showDate = true);
   virtual void logWarning(const std::string & message, bool showDate = true);
   virtual void logNotice(const std::string & message, bool showDate = true);
   virtual void logInfo(const std::string & message, bool showDate = true);
   virtual void logDebug(const std::string & message, bool showDate = true);
   virtual void logNone(const std::string & message, bool showDate = true);

 protected:

   LogLevel the_dump_loglevel;
   std::ostringstream *the_message_buffer;
 };

//============================================
} //end of namespace logs{
//============================================

#endif
