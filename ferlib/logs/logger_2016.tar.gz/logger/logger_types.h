#ifndef AW159_MODELS_SYSTEMS_LOGGER_LOGGER_TYPES_H
#define AW159_MODELS_SYSTEMS_LOGGER_LOGGER_TYPES_H


/*****************************************************************************/
/*!\file logger_types.h   
  \brief Data types defined to logger functionality.
  \Author Fernando Gonzalez Rodriguez.
  \version   2.0
  \date      2006-2013

  \warning Include this header in other header files without the  need to 
           include logger.h or loggerFunctionality.h
*/
/*****************************************************************************/

#include <iosfwd>


//============================================
namespace logs{
//============================================

	
/*!\enum LogLevel: label, type of messages.
 */
enum LogLevel 
{Emerg = 0,
 Alert, 
 Crit, 
 Error, 
 Warning, 
 Notice, 
 Info, 
 Debug, 
 None //!\warning To be used in the unitary test (cout log)
};

enum OverWriteFile {DONT_OVERWRITE = 0, OVERWRITE_FILE = 1};

std::istream& operator>>(std::istream& in, LogLevel & obj);
std::istream& operator>>(std::istream& in, OverWriteFile & obj);

std::string getLogLevelName(const LogLevel &level);

//============================================
} //end of namespace logs{
//============================================

#endif
