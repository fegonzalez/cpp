#include <sstream> /* ostringstream */ //let here to avoid compilation errors.
#include "logger_types.h"
#include "loggerFunctionalities.h"
#include "logger.h"
#include <iostream>
#include <cassert>
#include <string>
#include <indra/base/here_pathname.h>

namespace{

  //just to make transparent all the assertions and pointer verifications:

  void performNotifyLoggers(logs::LoggerObservableSimpleImpl *the_log_manager,
			    const logs::LogLevel & a_log_level,
  			    const std::string & message, 
  			    bool showDate);



  void performNotifyOneLogger
    (logs::LoggerObservableSimpleImpl *the_log_manager,
     logs::Logger *a_logger, 
     const logs::LogLevel & a_log_level, 
     const std::string & message, 
     bool showDate);

 
  //---------------------------------------------------


  void performNotifyLoggers(logs::LoggerObservableSimpleImpl *the_log_manager, 
			    const logs::LogLevel & a_log_level,
  			    const std::string & message, 
  			    bool showDate)
  {
    assert(the_log_manager); 

    if(the_log_manager)
      the_log_manager->NotifyLoggers(a_log_level, message, showDate);
  }


  //--------------------------------------------------- 
 
  void performNotifyOneLogger
    (logs::LoggerObservableSimpleImpl *the_log_manager,
     logs::Logger *a_logger, 
     const logs::LogLevel & a_log_level, 
     const std::string & message, 
     bool showDate)
  {
    assert(the_log_manager);
    assert(a_logger);

    if((the_log_manager)and(a_logger))
      {
	the_log_manager->NotifyOneLogger(a_logger, 
					 a_log_level, 
					 message, 
					 showDate);
      }
  }
 

  //---------------------------------------------------


}//end of no-named namespace

//=========================================================


int main()
{
  const std::string FILELOGGER_TEST_FILE_NAME = 
    here_pathname("aw159_models/systems/logger")
    + std::string("/filelogger_test.log");


  const std::string OFFLINE_FILELOGGER_TEST_FILE_NAME =
    here_pathname("aw159_models/systems/logger")
    + std::string("/offline_filelogger_test.log");


  //!\param the_logger_observable: logger manager
  logs::LoggerObservableSimpleImpl * the_logger_observable = 0;
  //!\param the_file_logger
  logs::FileLogger * the_file_logger = 0;
  //!\param the_offline_file_logger
  logs::FileLogger * the_offline_file_logger = 0;
 
  try
    {      
      /////////////////////////////////////////////////////////////
      //  FileLogger test
      /////////////////////////////////////////////////////////////

      the_file_logger = new logs::FileLogger(FILELOGGER_TEST_FILE_NAME,
      					     logs::OVERWRITE_FILE);

      assert(the_file_logger);


      /////////////////////////////////////////////////////////////
      //  FileLogger test
      //
      // Log messages of level greater than the second parameter
      // of the class constructor will ot be written online, but
      // after a dump() command, or at file destruction
      //
      /////////////////////////////////////////////////////////////


      the_offline_file_logger = new logs::OfflineFileLogger
      	(OFFLINE_FILELOGGER_TEST_FILE_NAME,
      	 logs::Error,
      	 logs::OVERWRITE_FILE);
      assert(the_offline_file_logger);

      std::ostringstream aux_message;
      

      //\warning The .log file created by this test will have
      //the look of a real ".log" file, that is the reason
      //to only write log records in this test.
      //so all the test steps are as commentaries in the code itself.

      //"1.- Testing the use of a logger directly in a program:\n",
      the_file_logger->logEmerg
	("1st round. Testing Emerg msg. in the_file_logger.",
	 false);

      the_offline_file_logger->logEmerg
	("1st round. Testing Emerg msg. in the_offline_file_logger.",
	 false);



      //replication of the text in "filelogger_test.OK" just to make
      //the operation "diff filelogger_test.OK FILELOGGER_TEST_FILE_NAME"
      aux_message << "EMERG: 1st round. Testing Emerg msg. in the_file_logger. "
		  << "Check you see me only once.";


      aux_message.str("");
      aux_message << "\n----------------------------------------" << std::endl;
      //2.- Testing the use of LoggerObservable to manage"
      //    the logging feature in a program." 
      the_logger_observable = new logs::LoggerObservableSimpleImpl();
      assert(the_logger_observable);
      the_logger_observable->attachLogger(the_file_logger);
      the_logger_observable->attachLogger(the_offline_file_logger);

      //2.1.- Testing NotifyLoggers: one message to all the loggers
      aux_message.str("");
      aux_message << "1st round. Testing Notice msg. in all the loggers.";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Notice, 
	 aux_message.str(),
	 false);

      aux_message.str("");
      aux_message << "1st round. Testing Error msg. in all the loggers."
		  << " Executing dump() after this message. ";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Error, 
	 aux_message.str(),
	 false);

      the_offline_file_logger->dump();

      //2.2.- Testing NotifyOneLogger: one message to an only specific logger."
      aux_message.str("");
      aux_message << "1st round. Testing Info msg. in the_file_logger.",
	performNotifyOneLogger
	(the_logger_observable,
	 the_file_logger,
	 logs::Info,  
	 aux_message.str(),
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_offline_file_logger,
	 logs::Info,  
	 aux_message.str(),
	 false);

      performNotifyOneLogger
	(the_logger_observable,
	 the_file_logger,
	 logs::Alert, 
	 "1st round. Testing Alert msg. in the_file_logger.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_offline_file_logger,
	 logs::Alert, 
	 "1st round. Testing Alert msg. in the_offline_file_logger.",
	 false);


      //Repeting the test with a different dump level will change the 
      //order of the messages in the off-line logger file.
      //      the_offline_file_logger->setDumpLogLevel(logs::Notice);
      assert(the_logger_observable); 
      if(the_logger_observable)
	the_logger_observable->setDumpLogLevel(logs::Notice);


      aux_message.str("");
      aux_message << "dump level changed to logs::Notice. "
		  << "2nd round. Testing Emerg msg. in all the loggers.";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Emerg, 
	 aux_message.str(),
	 false);
      aux_message.str("");
      aux_message << "2nd round. Testing Notice msg. in all the loggers.";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Notice, 
	 aux_message.str(),
	 false);
      aux_message.str("");
      aux_message << "2nd round. Testing Error msg. in all the loggers."
		  << " Executing dump() after this message. ";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Error, 
	 aux_message.str(),
	 false);

      the_offline_file_logger->dump();

      aux_message.str("");
      aux_message << "2nd round. "
		  << "Testing Alert msg. in all the loggers.";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Alert, 
	 aux_message.str(),
	 false);
      aux_message.str("");
      aux_message << "2nd round. Testing Info msg. in all the loggers.";
      performNotifyLoggers
	(the_logger_observable,
	 logs::Info, 
	 aux_message.str(),
	 false);



      /*!\test FileLogger copu operator & operator= 

	\warning it was tested but we can not use it in this automatic test
	system.
       
	logs::FileLogger copy_file_logger(*the_file_logger);
	logs::FileLogger third_file_logger = copy_file_logger;
      */


      //release loggers memory
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_offline_file_logger);
      the_offline_file_logger=0;
      delete(the_file_logger);
      the_file_logger=0;


    std::cout << "\n File Logger Test finished!" 
	      << std::flush << std::endl;

    }//end_of_try
  catch(const logs::FileLoggerException e)
    {
      std::cerr << e.showError();
      std:: cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_file_logger);
      the_file_logger=0;
      delete(the_offline_file_logger);
      the_offline_file_logger=0;
    }
  catch(const logs::LoggerException e)
    {
      std::cerr << e.showError();
      std::cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_file_logger);
      the_file_logger=0;
      delete(the_offline_file_logger);
      the_offline_file_logger=0;
    }
  catch (const std::string  &error) 
    {
      std::cerr << error << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_file_logger);
      the_file_logger=0;
      delete(the_offline_file_logger);
      the_offline_file_logger=0;
    }
  catch(const std::exception& e)
    {
      std::cerr <<  "\nexception:  ANSI exception : "  << e.what();
      std::cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_file_logger);
      the_file_logger=0;
      delete(the_offline_file_logger);
      the_offline_file_logger=0;
    }
  catch(...)
    {  
      std::cerr << "\nlogger_test.cpp: Unknown exception. " << std::endl;
      std:: cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_file_logger);
      the_file_logger=0;
      delete(the_offline_file_logger);
      the_offline_file_logger=0;
    }
  
}//end of main

//EOFILE

