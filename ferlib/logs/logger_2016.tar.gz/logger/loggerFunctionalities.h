#ifndef AW159_MODELS_SYSTEMS_LOGGER_LOGGERFUNCTIONALITIES_H
#define AW159_MODELS_SYSTEMS_LOGGER_LOGGERFUNCTIONALITIES_H

/*****************************************************************************/
/*!\file loggerFunctionalities.h   
  \brief Common log message management.
  \Author Fernando Gonzalez Rodriguez.
  \version   2.0
  \date      2006-2013

  \details 
  The main idea upon this implementation is the separation in the client 
  application of the definition of the logger to use, and the commanding
  of each log message. This way the multiple write log message commands
  are not needed to be modified depending of the Loggers defined in every
  execution of the application.

  The second important idea of this approach is that the client application
  doesn't need to know neither how the log messages are been written, nor
  where (console, file, ...) are they going to be written.
  An interesting side effect is that the client application dose not
  need to hard-code the Loggers to use, if these are loaded via configuration
  file.
  
  \note Implementation under the Observer Design Pattern:
  - Logger object: Observer
  - LoggerObservable object: observable object
  - Object that owns the LoggerObservable object: client application.

  \par
  The management of loggers relies on a LoggerObservable object that can 
  support  a collection of Loggers registered in it.
  - Creation in the client application (\see logger_test.cpp)
  1. The client program shall have a LoggerObservable object. 
  2. The client program shall create as many Loggers as is need and 
  shall register (attachLogger) them into the LoggerObservable.
  - Use by the client application (\see logger_test.cpp)
  1. The client program will command a new message to the LoggerObservable
  object using NotifyLoggers() function to write the log message in all
  the registered Loggers.
  2. The client program will command a new message to the LoggerObservable
  object using NotifyOneLogger() function to write the log message only
  in a determinate Logger.

  \note This software version only implements one LoggerObservable class, 
  the LoggerObservableSimpleImpl class.

*/
/*****************************************************************************/

#include "logger_types.h"
#include "logger.h"
#include <list>
#include <string>


//============================================
namespace logs{
//============================================
	

/***********************************************************************/
/*!\brief Public functions with Loggers */
/***********************************************************************/


	
/***********************************************************************/
/*!\class LoggerObservableInterface loggerFunctionalities.h
  \brief Observer pattern's observable element.

  \warning Every function has a double implementation, exception
  or non exception thrower, to be used in exception-secure programs.
*/
/***********************************************************************/


static const int NO_EXCEPTION_RETURN_VALUE = 1;
static const int EXCEPTION_RETURN_VALUE = -1;
static const int ERROR_INVALID_ARGUMENT = -2;


/*!\class LoggerObservableInterface logger.h
 * 
 * Interface class.
 * To be implemented by objects who need to log information without knowing
 * whether how nor where.
 */	
 class LoggerObservableInterface
 {
 public:
	
   virtual ~LoggerObservableInterface() {};


   /*! 
     \fn virtual void attachLogger(Logger *aLogger)=0;
     \brief Attach a NEW Logger to the LoggerObservable object
     (ala Observer Pattern).
     \exception Duplicate attachement are avoided, so if aLogger 
     is already attached, do nothing and return.
    */
   virtual void attachLogger(Logger *aLogger)=0;	
	

   /*!
     \fn virtual void detachLogger(Logger *aLogger)=0;
     \brief Detach a Logger to the LoggerObservable object
     \warning Dose not call delete() for the detached object.
    * */	
   virtual void detachLogger(Logger *aLogger)=0;
	
	
   /*!
     \fn virtual void NotifyLoggers
     \brief send the message to all the loggers attached.
    */	
   virtual void NotifyLoggers
     (const LogLevel & aLogLevel, 
      const std::string & message, 
      bool showDate =true)=0;
	
	

   /*!
     \fn virtual void NotifyOneLogger
     \brief send the message only to one selected attached logger.
   */
   virtual void NotifyOneLogger
     (Logger * aLogger,
      const LogLevel & aLogLevel, 
      const std::string & message, 
      bool showDate = true)=0;
	
			
   /*!
     \fn virtual size_t numLoggers() const =0;
     \brief send the message to all the loggers attached.
    * \return The number of attached loggers.
    */
   virtual size_t numLoggers() const =0;
	
		
   /*!\fn void detachAll()
   */
   virtual void detachAll()=0;


   /*!\fn virtual void setLogLevel(const LogLevel & new_debug_level)=0;
     \brief Determination of the default debug level for all the attached
     loggers.

     \Details This would be used to make a selective witting of the log
     messages in NotifyLoggers and NotifyOneLogger: only the messages whose
     level is equal or greater than this reference level will be written in the
     loggers, (having Emerg=0 as the superior debug level)

     Each implementation can choose whether to implement this feature or not,
     and the way to to it.
    */
   virtual void setLogLevel(const LogLevel & new_debug_level)=0;

   virtual LogLevel getLogLevel()const=0;

   /*!\fn void dump()
     \brief execute dump() in all the attached loggers.
   */
   virtual void dump()=0;

   /*!\fn virtual void setDumpLogLevel(const LogLevel & dumpLogLevel)=0;
     \brief execute setDumpLogLevel() in all the attached loggers.
   */
   virtual void setDumpLogLevel(const LogLevel & dumpLogLevel)=0;

 }; // class LoggerObservableInterface
	


//============================================================================



/*!\class LoggerObservableSimpleImpl logger.h
 * 
 * Implementation of LoggerObservableInterface.
 * Uses  NotifyLoggers to advertise to it observers.

  \warning The memory of the attached/detached Logger objects is not 
  handled by the LoggerObservable object, but by the client application.
  Detach operations remove a Logger from the LoggerObservable, but dose
  not release its memory (dose not call delete()).
 */	
 class LoggerObservableSimpleImpl: public LoggerObservableInterface
{
 public:
	
  LoggerObservableSimpleImpl();


  /*!\fn ~LoggerObservableSimpleImpl();
    \warning Dose not call delete() for the Logger objects.
   */	
  virtual ~LoggerObservableSimpleImpl();
		

  virtual void attachLogger(Logger *aLogger);

  /*!\fn virtual void detachLogger(Logger *aLogger);
    \warning Dose not call delete() for the Logger objects.
   */			 
  virtual void detachLogger(Logger *aLogger);

  virtual void NotifyLoggers(const LogLevel & aLogLevel, 
		     const std::string & message, 
		     bool showDate =true);
		
  virtual void NotifyOneLogger
    (Logger *aLogger,
     const LogLevel & aLogLevel, 
     const std::string & message, 
     bool showDate=true);	
	
  virtual size_t numLoggers() const 
  {return listaLogs.size();}
  

   /*!\fn void setLogLevel(const LogLevel & new_debug_level);
     Setting the value of the_reference_debug_level.
   */
   virtual void setLogLevel(const LogLevel & new_debug_level)
   {the_reference_debug_level = new_debug_level;}


   virtual LogLevel getLogLevel()const
   {return the_reference_debug_level;}


  /*!\fn void detachAll(); 

    \warning Dose not call delete() for the Logger objects.

    \warning Not public to avoid to allow removing a Logger by any other one
    but its creator. To pass through this wall: make your class a friend of
    LoggerObservableSimpleImpl.
  */
  virtual void detachAll();

  virtual void dump();

  virtual void setDumpLogLevel(const LogLevel & dumpLogLevel) ;

	
 protected:
	
  //!\param listaLogs: list (logic list) of attached observers.
  std::list <Logger *> listaLogs; 

   /*!\param the_reference_debug_level: establish the debug level that
     determines with level of log message is needed going to be sent to the
     attached loggers.

    Criteria: only the messages whose level is equal or greater than
    the_reference_debug_level will be written (having Emerg=0 as the superior

    Example of use: the_reference_debug_level = Emerg
    only writeEmerg() messages will be written.

    Example of use: the_reference_debug_level = Warning
    only Emerg, Alert, Crit, Error, and Warning messages will be written.

    \note the default value is None = write all.

  */
  LogLevel the_reference_debug_level;

}; // class LoggerObservableSimpleImpl


//============================================
} //end of namespace logs{
//============================================

#endif /*AW159_MODELS_SYSTEMS_LOGGER_LOGGERFUNCTIONALITIES_H*/
