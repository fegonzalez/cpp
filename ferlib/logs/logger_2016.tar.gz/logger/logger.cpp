
/*****************************************************************/
/*!\file logger.cpp
  \brief Log message generalised treatment -implementation.
  \Author Fernando Gonzalez Rodriguez.
*/
/*****************************************************************/


#include <sstream> /* ostringstream */ //let here to avoid compilation errors.

#include "logger_types.h"
#include "logger.h"

#include <string>
#include <exception>
#include <time.h>
#include <assert.h>
#include <ostream>
#include <iostream>
#include <fstream>  // logFile
//============================================
namespace logs{
//============================================
	


  /******************************************************************/
  /*!\notice link level functions

    std::string getDate();

  */
  /******************************************************************/

  namespace{

    /*!
      \fn std::string getDate();
      \relates Logger
      \return std::string: The date on the following format: 
      Wed Apr 25 16:08:10 2007
    */
    std::string getDate();


    std::string getDate()
    {
      std::string s;
      time_t tiempo; 
      struct tm * newTime;
      tiempo = time(NULL);
      newTime = localtime( &tiempo );
      if (newTime)					
	{
	  s=asctime( newTime );
	  s=s.substr(0,s.size()-1); //removing EOLN at the end of the date
	}
      return s;
    }

  }//end of no-named namespace



  /******************************************************************/
  /*!\implementation LoggerException
   */
  /******************************************************************/


  LoggerException::LoggerException()
    :message("Error: LoggerException")
  {
  }

  LoggerException::LoggerException(const LoggerException& mine) 
    :message(mine.message)
  {
  }

  LoggerException::LoggerException(std::string exMessage)
    :message(exMessage)
  {
  }


  LoggerException& LoggerException::operator=(const LoggerException& mine)
  {
    if (this!= &mine)	
      message=mine.message;

    return (*this);
  }



  /******************************************************************/
  /*!\implementation FileLoggerException
   */
  /******************************************************************/


  FileLoggerException::FileLoggerException()
 :LoggerException("Error: FileLoggerException")
  {
  }

  FileLoggerException::FileLoggerException(const FileLoggerException& mine)
 :LoggerException(mine.message)
  {
  }

  FileLoggerException::FileLoggerException(std::string exMessage)
 :LoggerException(exMessage)
  {
  }



  /******************************************************************/
  /*!\implementation ConsoleLogger
   */
  /******************************************************************/

  ConsoleLogger::ConsoleLogger()
  {}

  //------------------------------------------------------------------

  void ConsoleLogger::writeLog(const LogLevel & aLogLevel, 
			       const std::string & message, bool showDate)
  {
    switch (aLogLevel)
      {
      case Emerg: logEmerg(message, showDate); break;
      case Alert: logAlert(message, showDate); break;
      case Crit: logCrit(message, showDate); break;
      case Error: logError(message, showDate); break;    
      case Warning: logWarning(message, showDate); break;
      case Notice: logNotice(message, showDate); break;
      case Info: logInfo(message, showDate); break;
      case Debug: logDebug(message, showDate); break;
      case None: logNone(message, showDate); break;
      default: logAny(message, "", showDate); break;
      }
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logAny(const std::string & message, 
			     const std::string & logTitle, 
			     bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      {
	std::clog << getDate() << "\t";
	std::clog << logTitle << ": " << message << std::flush << std::endl;
      }
    else
      {
	std::clog << logTitle << ": " << message << std::flush << std::endl;
      }
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logEmerg(const std::string & message, bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "EMERG: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logAlert(const std::string & message, bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "ALERT: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logCrit(const std::string & message, bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "CRIT: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logError(const std::string & message, bool showDate)
  {
    std::cerr << "\n";
    if (showDate)
      std::cerr << getDate() << "\t";
    std::cerr << "ERROR: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logWarning(const std::string & message, bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "WARNING: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logNotice(const std::string & message, bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "NOTICE: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logInfo(const std::string & message, bool showDate)
  {	
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "INFO: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logDebug(const std::string & message, bool showDate)
  {
    std::clog << "\n";
    if (showDate)
      std::clog << getDate() << "\t";
    std::clog << "DEBUG: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void ConsoleLogger::logNone(const std::string & message, bool showDate)
  {
    std::cout << "\n";
    if (showDate)
      std::cout << getDate() << "\t";
    std::cout << message << std::flush << std::endl;
  }



  /******************************************************************/
  /*!\implementation FileLogger
   */
  /******************************************************************/


  const std::string COULD_NOT_CREATRING_LOGFILE = 
		       "Log file could not be created in this location: ";


  FileLogger::FileLogger(std::string fileName, bool overWriteOldFile)
    :logFileName(fileName)
  {
    if(overWriteOldFile)
      out= new std::ofstream(fileName.c_str(),
			     std::ofstream::out | std::ios::trunc);
    else
      out= new std::ofstream(fileName.c_str(), 
			     std::ofstream::out | std::ios::app);

    if (!out->is_open())	
      {
	delete out;
	out=0;
	std::ostringstream ost;
	ost << COULD_NOT_CREATRING_LOGFILE << "\"" << fileName << "\"";
	throw FileLoggerException(ost.str());
      }
  }

  //------------------------------------------------------------------

  FileLogger::FileLogger(const FileLogger & aFileLogger)
 :logFileName(aFileLogger.logFileName)
  {	 
    assert(aFileLogger.out!=NULL);


    // make new file... 

    logFileName.append(".copy");
    out=new std::ofstream(logFileName.c_str(), std::ios::app);

    // ... and copy aFileLogger in it

    try
      {
	copyFile(aFileLogger.logFileName, logFileName);
      }
    catch (FileLoggerException )
      {
	delete out;
	out=0;
	throw;
      }
  }

  //------------------------------------------------------------------

  FileLogger::~FileLogger()
  {
    delete out;
    out=0;
  }

  //------------------------------------------------------------------

FileLogger & FileLogger::operator=(const FileLogger & aFileLogger)
{

  assert(aFileLogger.out!=NULL);

  if (this!= &aFileLogger)	// 1.- avoid auto-copy
    {
      // 2.- clear old elements
      out->clear();

      // 3.- initialise and copy new elements
      try
	{
	  copyFile(aFileLogger.logFileName, logFileName);
	}
      catch (FileLoggerException )
	{
	  delete out;
	  out=0;
	  throw;
	}
    }

  return (*this);
}

  //------------------------------------------------------------------

  void FileLogger::blankLine()
  // print a blank line in the log file
  {
    assert(out);
    *out << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::writeLog(const LogLevel & aLogLevel, 
			    const std::string & message, 
			    bool showDate)
  {
    switch (aLogLevel)
      {
      case Emerg: logEmerg(message, showDate); break;
      case Alert: logAlert(message, showDate); break;
      case Crit: logCrit(message, showDate); break;
      case Error: logError(message, showDate); break;    
      case Warning: logWarning(message, showDate); break;
      case Notice: logNotice(message, showDate); break;
      case Info: logInfo(message, showDate); break;
      case Debug: logDebug(message, showDate); break;
      case None: logNone(message, showDate); break;
      default: logAny(message, "", showDate); break;
      }
  }

  //------------------------------------------------------------------

  void FileLogger::logAny(const std::string & message, 
			  const std::string & logTitle, 
			  bool showDate)
  {
    assert(out);*out << "\n";    
    if (showDate)
      {
	*out << getDate() << "\t";
	*out << logTitle << ": " << message << std::flush << std::endl;
      }
    else
      {
	*out << logTitle << ": " << message << std::flush << std::endl;
      }
  }

  //------------------------------------------------------------------

  void FileLogger::logEmerg(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "EMERG: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logAlert(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "ALERT: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logCrit(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "CRIT: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logError(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "ERROR: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logWarning(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "WARNING: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logNotice(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "NOTICE: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logInfo(const std::string & message, bool showDate)
  {	
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "INFO: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::logDebug(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << "DEBUG: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------
 
  void FileLogger::logNone(const std::string & message, bool showDate)
  {
    assert(out);
    *out << "\n";
    if (showDate)
      *out << getDate() << "\t";
    *out << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void FileLogger::copyFile
  (const std::string & fromName, const std::string & toName)
  {
    const std::string COULD_NOT_OPENING_FILE = "The file could not be opened: ";

    const std::string COULD_NOT_COPY_FILE = 
      "The file could't be correctly copied: ";

    std::string errorMessage=COULD_NOT_OPENING_FILE;
				
    try
      {
	std::ifstream origin(fromName.c_str());
	if(!origin)
	  {
	    errorMessage.append("\"");
	    errorMessage.append(fromName);
	    errorMessage.append("\"");
	    throw FileLoggerException(); 
	  }
	std::ofstream destination(toName.c_str());
	if(!destination)
	  {
	    errorMessage.append("\"");
	    errorMessage.append(toName);
	    errorMessage.append("\"");
	    throw FileLoggerException(); 
	  }
	char ch;
	while( origin.get(ch)  && destination.put(ch));

	if(!origin.eof() || destination.eof())
	  {
	    errorMessage=COULD_NOT_COPY_FILE;
	    errorMessage.append("\"");
	    errorMessage.append(fromName);
	    errorMessage.append("\" en \"");
	    errorMessage.append(toName);
	    errorMessage.append("\"");
	    throw FileLoggerException(); 
	  }
      }
    catch (...)
      {
	delete out;
	out=0;
	std::ostringstream ost;
	ost << COULD_NOT_CREATRING_LOGFILE << "\"" << toName << "\"";
	throw FileLoggerException(ost.str());
      }
  }






  /******************************************************************/
  /*!\implementation OfflineFileLogger
   */
  /******************************************************************/


  OfflineFileLogger::OfflineFileLogger
  (std::string fileName,
   const LogLevel & dumpLogLevel,
   bool overWriteOldFile):
    FileLogger(fileName, overWriteOldFile),
    the_dump_loglevel(dumpLogLevel),
    the_message_buffer(0)
  {
    the_message_buffer=new std::ostringstream("");
    assert(the_message_buffer);
  }

 
  //------------------------------------------------------------------

  OfflineFileLogger::~OfflineFileLogger()
  {
    try
      {
	dump();
	delete the_message_buffer;
	the_message_buffer=0;
	delete out;
	out=0;
      }
    catch (FileLoggerException e)
      {
	std::cerr << e.showError();
	std::cerr << std::flush << std::endl;
	delete the_message_buffer;
	the_message_buffer=0;
	delete out;
	out=0;
      }
    catch(...)
      {
	std::ostringstream ost;
	ost << "\nError dumping data to log file " << "\"" << logFileName<< "\"";
	delete the_message_buffer;
	the_message_buffer=0;
	delete out;
	out=0;
      }
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::dump()
  {
    assert(out);
    assert(the_message_buffer);
    *out << the_message_buffer->str();
    the_message_buffer->str("");    
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logEmerg(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Emerg <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "EMERG: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logAlert(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Alert <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "ALERT: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logCrit(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Crit <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "CRIT: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logError(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Error <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "ERROR: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logWarning(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Warning <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "WARNING: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logNotice(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Notice <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "NOTICE: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logInfo(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Info <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "INFO: " << message << std::flush << std::endl;
  }

  //------------------------------------------------------------------

  void OfflineFileLogger::logDebug(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::Debug <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "DEBUG: " << message << std::flush << std::endl;
 }

  //------------------------------------------------------------------

  void OfflineFileLogger::logNone(const std::string & message, bool showDate)
  {
    assert(out);
    assert(the_message_buffer);
    std::ostream * aux_out = 0;
    if(logs::None <= the_dump_loglevel) //write now
      aux_out = out;
    else //wait  until dump
      aux_out = the_message_buffer;
    assert(aux_out);


    *aux_out << "\n";
    if (showDate)
      *aux_out << getDate() << "\t";
    *aux_out << "NONE: " << message << std::flush << std::endl;
  }

//============================================
} //end of namespace logs{
//============================================
