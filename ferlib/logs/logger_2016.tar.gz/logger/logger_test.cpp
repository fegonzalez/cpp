#include <sstream> /* ostringstream */ //let here to avoid compilation errors.
#include "logger_types.h"
#include "loggerFunctionalities.h"
#include "logger.h"
#include <iostream>
#include <cassert>
#include <string>


namespace{

  //just to make transparent all the assertions and pointer verifications:

  void performNotifyLoggers(logs::LoggerObservableSimpleImpl *the_log_manager,
			    const logs::LogLevel & a_log_level,
  			    const std::string & message, 
  			    bool showDate);



  void performNotifyOneLogger
    (logs::LoggerObservableSimpleImpl *the_log_manager,
     logs::Logger *a_logger, 
     const logs::LogLevel & a_log_level, 
     const std::string & message, 
     bool showDate);

 
  //---------------------------------------------------


  void performNotifyLoggers(logs::LoggerObservableSimpleImpl *the_log_manager, 
			    const logs::LogLevel & a_log_level,
  			    const std::string & message, 
  			    bool showDate)
  {
    assert(the_log_manager); 

    if(the_log_manager)
      the_log_manager->NotifyLoggers(a_log_level, message, showDate);
  }

 
 
  void performNotifyOneLogger
    (logs::LoggerObservableSimpleImpl *the_log_manager,
     logs::Logger *a_logger, 
     const logs::LogLevel & a_log_level, 
     const std::string & message, 
     bool showDate)
  {
    assert(the_log_manager);
    assert(a_logger);

    if((the_log_manager)and(a_logger))
      {
	the_log_manager->NotifyOneLogger(a_logger, 
					 a_log_level, 
					 message, 
					 showDate);
      }
  }
 

}//end of no-named namespace

//=========================================================


int main()
{
  //!\param the_logger_observable: logger manager
  logs::LoggerObservableSimpleImpl * the_logger_observable = 0;
  //!\param the_std_logger: testing console logger
  logs::ConsoleLogger * the_std_logger = 0;
  //!\param the_std_logger_two: 
  //!\warning A second ConsoleLogger is created for test purposes only.
  logs::ConsoleLogger * the_std_logger_two = 0;
  
  try

    {

      // logs::LogLevel a;
      // std::cout << " Loglevel = " << a << std::flush << std::endl;
      // std::cin >> a;
      // std::cout << " Loglevel = " << a << std::flush << std::endl;
      // assert(false);
      //
      // logs::OverWriteFile a;
      // std::cout << " OverWriteFile = " << a << std::flush << std::endl;
      // std::cin >> a;
      // std::cout << " OverWriteFile  = " << a << std::flush << std::endl;
      // assert(false);

      the_std_logger = new logs::ConsoleLogger();
      assert(the_std_logger);

      std::ostringstream aux_message;
      aux_message <<"\n\n\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
      aux_message << "WARNING !!  WARNING !!  WARNING !!";
      aux_message << "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
      aux_message <<"User, be aware that only the logNone message type" 
		<< " will be written in"
		<< "\n\"logger_test.OK\" file. "
		<<"\nAll the other ConsoleLogger messages are written in the "
		<< "other\nstandard outputs:"
		<< " cerr (logErr), and clog (all the other messages)."
		<< "\nTo learn how to use the logger feature, "
		<< "you must use \"make runlogger_test\"" << std::endl;
      aux_message << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
      the_std_logger->logNone(aux_message.str(),
			      false);


      aux_message.str("");
      aux_message << "\n------------------------------------------------";
      aux_message << "\nREADME USER: "
		  << "Usually, the log messages are \ncreated with the "
		  << " date at the beginning, like this: \n" ;
      the_std_logger->logNone(aux_message.str(),
			      false);
      the_std_logger->logAny("This is the most usual log-message format.", 
			      "Tue Mar 12 19:07:24 2013",
			      false);
      aux_message.str("");
      aux_message  << "\nBut for this unitary test we can not do that "
		   << "because the \n\"logger_test.OK\" file will result "
		   << "different after every execution.\n"
		   << "To do this, do not use the last \"false\" parameter\n"
		   << "in the logger and notifyLogger functions.";
      the_std_logger->logNone(aux_message.str(),
			      false);


      aux_message.str("");
      aux_message << "\n------------------------------------------------";
      aux_message << "\nREADME USER: "
		  << "Here you can see that logNone() is equivalent "
		  << "to std::cout.\n";
      the_std_logger->logNone(aux_message.str(),
			      false);


      the_std_logger->logNone
	("\n------------------------------------------------",
	 false);
      the_std_logger->logNone
	("1.- Testing the use of a logger directly in a program:\n",
	 false);

      the_std_logger->logEmerg
	("Testing Emerg msg. in the_std_logger. Check you see me only once.",
	 false);
      the_std_logger->logAlert
	("Testing Alert msg. in the_std_logger. Check you see me only once.",
	 false);
      the_std_logger->logInfo
	("Testing Info msg. in the_std_logger. Check you see me only once.",
	 false);



      aux_message.str("");
      aux_message << "\n----------------------------------------" << std::endl;
      aux_message << "2.- Testing the use of LoggerObservable to manage"
		  << "\n    the logging feature in a program." 
		  << std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);

      the_logger_observable = new logs::LoggerObservableSimpleImpl();
      assert(the_logger_observable);
      the_std_logger->logNone
	(" > Attaching ConsoleLogger the_std_logger.",
	 false);
      the_logger_observable->attachLogger(the_std_logger);

      //!\warning A second ConsoleLogger is created for test purposes only.
      the_std_logger_two = new logs::ConsoleLogger();
      assert(the_std_logger_two);

      the_std_logger->logNone
	(" > Attaching ConsoleLogger the_std_logger_two.",
	 false);
      the_logger_observable->attachLogger(the_std_logger_two);

      aux_message.str("");
      aux_message << " > Duplicate attachments are ignored."; 
      aux_message << "\n   Attaching the_std_logger again is ignored.";
      aux_message << std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);
      the_logger_observable->attachLogger(the_std_logger);


      aux_message.str("");
      aux_message << "\n----------------------------------------" << std::endl;
      aux_message << "2.1.- Testing NotifyLoggers: one message to all "
		  << "the loggers:\n"
		  << "\nCurrent number of attached loggers = "
		  << the_logger_observable->numLoggers()
		  << std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);
      
      performNotifyLoggers
	(the_logger_observable,
	 logs::Emerg, 
	 "Testing Emerg message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Alert, 
	 "Testing Alert message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Crit, 
	 "Testing Crit message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Error, 
	 "Testing Error message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Warning, 
	 "Testing Warning message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Notice, 
	 "Testing Notice message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Info, 
	 "Testing Info message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Debug, 
	 "Testing Debug message. Check that you can see the message twice.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::None, 
	 "Testing None message. Check that you can see the message twice.",
	 false);


      aux_message.str("");
      aux_message << "\n----------------------------------------" << std::endl;
      aux_message << "2.2.- Testing NotifyOneLogger: one message to a only "
		<< "specific logger."
		<< "\nCurrent number of attached loggers = "
		<< the_logger_observable->numLoggers()
		<< std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);

      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::None, 
	 "Testing None msg. in the_std_logger. Check you see me only once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger_two,
	 logs::Emerg, 
	 "Testing Emerg msg. in the_std_logger_2. Check you see me only once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Alert, 
	 "Testing Alert msg. in the_std_logger. Check you see me only once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger_two,
	 logs::Info, 
	 "Testing Info msg. in the_std_logger_2. Check you see me only once.",
	 false);


      aux_message.str("");
      aux_message << "\n----------------------------------------" << std::endl;
      aux_message << "2.3.- Testing detachLogger() function."
		<<"\nWe will detach one of the ConsoleLoggers and then "
		<<"write some messages."
		<<"\nCheck that you can see each message only once:";
      aux_message << "\nBefore detachLogger. Current loggers attached = "
		<< the_logger_observable->numLoggers()
		<< std::endl;
      the_logger_observable->detachLogger(the_std_logger_two);
      aux_message << "After detachLogger. Current loggers attached = "
		<< the_logger_observable->numLoggers()
		<< std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);


      aux_message.str("");
      aux_message << "\n----------------------------------------" << std::endl;
      aux_message << "3.- Testing Debuglevel: Setting DebugLevel to Crit."
		<< "\nCalling notifyOneLogger for all the debug levels."
		<< "\nCheck that you only can see one message of the types: "
		<< "Emerg, Alert, and Crit."
		<< std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);
      aux_message.str("");
      the_logger_observable->setLogLevel(logs::Crit);
      aux_message << "Checked that debug level is Crit: ";
      aux_message << getLogLevelName(the_logger_observable->getLogLevel());
      the_std_logger_two->logNone(aux_message.str(),
			      false);


      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::None, 
	 "Testing None message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Emerg, 
	 "Testing Emerg message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Alert, 
	 "Testing Alert message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Crit, 
	 "Testing Crit message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Error, 
	 "Testing Error message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Warning, 
	 "Testing Warning message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Notice, 
	 "Testing Notice message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Info, 
	 "Testing Info message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::Debug, 
	 "Testing Debug message. Check that you can see the message once.",
	 false);
      performNotifyOneLogger
	(the_logger_observable,
	 the_std_logger,
	 logs::None, 
	 "Testing None message. Check that you can see the message once.",
	 false);


      the_logger_observable->setLogLevel(logs::None);
      aux_message.str("");
      aux_message << "\nTesting Debuglevel: Setting DebugLevel to None."
		<< std::endl;
      the_std_logger->logNone(aux_message.str(),
			      false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::Emerg, 
	 "Testing Emerg message. Check that you can see the message once.",
	 false);
      performNotifyLoggers
	(the_logger_observable,
	 logs::None, 
	 "Testing None message. Check that you can see the message once.",
	 false);


      the_std_logger->logNone("\n----------------------------------------",
			      false);

      //release loggers memory
      the_std_logger->logNone("\nReleasing loggers...\n",
			      false);
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_std_logger_two);
      the_std_logger_two=0;
      the_std_logger->logNone("\n...logger_test finished.\n",
			      false);
      delete(the_std_logger);
      the_std_logger=0;
    }//end_of_try
  catch(const logs::FileLoggerException e)
    {
      std::cerr << e.showError();
      std:: cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_std_logger);
      the_std_logger=0;
      delete(the_std_logger_two);
      the_std_logger_two=0;
    }
  catch(const logs::LoggerException e)
    {
      std::cerr << e.showError();
      std::cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_std_logger);
      the_std_logger=0;
      delete(the_std_logger_two);
      the_std_logger_two=0;
    }
  catch (const std::string  &error) 
    {
      std::cerr << error << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_std_logger);
      the_std_logger=0;
      delete(the_std_logger_two);
      the_std_logger_two=0;
    }
  catch(const std::exception& e)
    {
      std::cerr <<  "\nexception:  ANSI exception : "  << e.what();
      std::cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_std_logger);
      the_std_logger=0;
      delete(the_std_logger_two);
      the_std_logger_two=0;
    }
  catch(...)
    {  
      std::cerr << "\nlogger_test.cpp: Unknown exception. " << std::endl;
      std:: cerr << std::flush << std::endl;
      the_logger_observable->detachAll();
      delete(the_logger_observable);
      the_logger_observable=0;
      delete(the_std_logger);
      the_std_logger=0;
      delete(the_std_logger_two);
      the_std_logger_two=0;
    }
  
}//end of main

//EOFILE

