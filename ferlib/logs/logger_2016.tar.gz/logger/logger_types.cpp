#include "logger_types.h"
#include <stdexcept>      // std::out_of_range
#include <istream>
#include <sstream> /* istringstream */ //let here to avoid compilation errors.
//============================================
namespace logs{
  //============================================

  const std::string ERROR_MSG_OVERWRITE = std::string
    ("OverWriteFile::operator>> Invalid value for type logs::OverWriteFile.") +
     std::string("\nValid values are: DONT_OVERWRITE, 0, ") +
     std::string("OVERWRITE_FILE, 1.");
     
  const std::string ERROR_MSG_LOGLEVEL = std::string 
    ("LogLevel::operator>> Invalid value for type logs::LogLevel") +
    std::string("\nValid values are: Emerg, 0; Alert, 1; Crit, 2; Error, 3 ") +
    std::string("Warning, 4; Notice, 5; Info, 6; Debug, 7; None, 8 ");

//--------------------------------------------

  std::istream& operator>>(std::istream& in, LogLevel & obj)
  {
    std::string val;

    if (in >> val) 
      {
	if((val=="Emerg") or (val=="0")) obj = logs::Emerg; 
	else if((val=="Alert") or (val=="1")) obj = logs::Alert; 
	else if((val=="Crit") or (val=="2")) obj = logs::Crit; 
	else if((val=="Error") or (val=="3")) obj = logs::Error;
	else if((val=="Warning") or (val=="4")) obj = logs::Warning;
	else if((val=="Notice") or (val=="5")) obj = logs::Notice; 
	else if((val=="Info") or (val=="6")) obj = logs::Info; 
	else if((val=="Debug") or (val=="7")) obj = logs::Debug; 
	else if((val=="None") or (val=="8")) obj = logs::None;
	else
	  {
	    obj = logs::None;
	    throw std::out_of_range(ERROR_MSG_LOGLEVEL.c_str());
	  }

      }//end_if (in>>val)

    return in;
  }

//--------------------------------------------

  std::istream& operator>>(std::istream& in, OverWriteFile & obj)
  {
    std::string val;
    if (in >> val) 
      {
	if((val=="DONT_OVERWRITE") or (val=="0"))
	  obj = logs::DONT_OVERWRITE;

	else if((val=="OVERWRITE_FILE") or (val=="1"))
	  obj = logs::OVERWRITE_FILE;
	else
	  {
	    obj = logs::OVERWRITE_FILE;
	    throw std::out_of_range(ERROR_MSG_OVERWRITE.c_str());
	  }

      }//end_if (in>>val)


    return in;
  }

//--------------------------------------------

  std::string getLogLevelName(const LogLevel &level)
  {
    switch (level)
      {
      case Emerg: return std::string("Emerg");
      case Alert: return std::string("Alert");
      case Crit: return std::string("Crit");
      case Error: return std::string("Error");
      case Warning: return std::string("Warning");
      case Notice: return std::string("Notice");
      case Info: return std::string("Info");
      case Debug: return std::string("Debug");
      case None: return std::string("None");
      }
    return std::string("None");
  }

  //============================================
} //end of namespace logs{
//============================================
