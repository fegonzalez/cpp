
//!\file LoggerFunctionalities.cpp

/*****************************************************************************/
/*!\file loggerFunctionalities.h   
  \brief Common log message management implementation.
  \Author Fernando Gonzalez Rodriguez.
  \version   2.0
  \date      2006-2013
*/
/*****************************************************************************/

#include "logger_types.h"
#include "loggerFunctionalities.h"
#include <cassert>


//============================================
namespace logs{
//============================================



/***********************************************************************/
/*!\brief Public functions with Loggers */
/***********************************************************************/


/***********************************************************************/
/*!\note LoggerObservableInterface implementation                      */
/***********************************************************************/


  LoggerObservableSimpleImpl::LoggerObservableSimpleImpl()
    :listaLogs(),
     the_reference_debug_level(None)
  {
  }

  //-----------------------------------------------------------------------

  LoggerObservableSimpleImpl::~LoggerObservableSimpleImpl()
  {
    dump();
    listaLogs.clear(); // All the attached objects are destroyed.
  }

  //-----------------------------------------------------------------------

  void LoggerObservableSimpleImpl::attachLogger(Logger *aLogger)
  {
    assert(aLogger);

    //avoid duplicate attachements
    std::list<Logger*>::iterator itr;	 
    for (itr=listaLogs.begin(); itr!=listaLogs.end(); ++itr)
      {
	if((*itr)&&(*itr == aLogger))
	  {
	    return; 
	  }
      }

    //insert the NEW element
    listaLogs.insert(itr, aLogger);
  }

  //-----------------------------------------------------------------------

  void LoggerObservableSimpleImpl::detachLogger (Logger *aLogger) 
  {
    assert(aLogger);
    listaLogs.remove(aLogger); // The detached object is destroyed.
  }

  //-------------------------------------------------------------------------

  void LoggerObservableSimpleImpl::NotifyLoggers(const LogLevel & aLogLevel, 
						 const std::string & message, 
						 bool showDate)
  {
    if(aLogLevel > the_reference_debug_level)
      return;


    std::list<Logger*>::iterator itr;
 
    for (itr=listaLogs.begin(); itr!=listaLogs.end(); itr++)
      {
	assert(*itr);
	if(*itr)
	  (*itr)->writeLog(aLogLevel, message, showDate);
      }
  }

  //-----------------------------------------------------------------------

  void LoggerObservableSimpleImpl::NotifyOneLogger
  (Logger *aLogger, 
   const LogLevel & aLogLevel, 
   const std::string & message, 
   bool showDate)
  {
    assert(aLogger);

    if(aLogLevel > the_reference_debug_level)
      return;

    std::list<Logger*>::iterator itr;	 
    for (itr=listaLogs.begin(); itr!=listaLogs.end(); ++itr)
      {
	if((*itr)&&(*itr == aLogger))
	  {
	    (*itr)->writeLog(aLogLevel, message, showDate);
	    break;
	  }
      }
  }

  //--------------------------------------------------------------------------

  void LoggerObservableSimpleImpl::detachAll() 
  {
    listaLogs.clear();
  }

  //--------------------------------------------------------------------------

  void LoggerObservableSimpleImpl::dump()
  {
    std::list<Logger*>::iterator itr;
    for (itr=listaLogs.begin(); itr!=listaLogs.end(); itr++)
      {
	assert(*itr);
	if(*itr)
	  (*itr)->dump();
      }
  }

  //--------------------------------------------------------------------------

  void LoggerObservableSimpleImpl::setDumpLogLevel(const LogLevel & dumpLogLevel)
  {
    std::list<Logger*>::iterator itr;
    for (itr=listaLogs.begin(); itr!=listaLogs.end(); itr++)
      {
	assert(*itr);
	if(*itr)
	  (*itr)->setDumpLogLevel(dumpLogLevel);
      }
  }


  //--------------------------------------------------------------------------

//============================================
} //end of namespace logs{
//============================================

// EOFILE

